package com.common.Notification.Service;

import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

import com.common.Notification.Dto.SmsRequest;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

@Service
public class SmsService {
	
	private final String ACCOUNT_STD = "AC911378159bb2b00af868554b48b92c6c";
	private final String AUTH_TOKEN="b1b33817ac1fe565cd5338205443c9b6";
	private final String FROM_NUMBER="+17743525097";
	
	public String send( SmsRequest sms) {
        Twilio.init(ACCOUNT_STD, AUTH_TOKEN);

        Message message = Message.creator(new PhoneNumber(sms.getTo()), new PhoneNumber(FROM_NUMBER), sms.getMessage())
                .create();
        System.out.println("here is my id:"+message.getSid());// Unique resource ID created to manage this transaction
		return "Message Send Successfully";

    }
	
	public void receive(MultiValueMap<String, String> smscallback) {
		
    }
	
}
