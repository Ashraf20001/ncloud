package com.common.Notification.Controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.common.Notification.Dto.MailResponse;
import com.common.Notification.Dto.ResetPasswordRequest;
import com.common.Notification.Service.EmailSenderService;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class EmailNotification {

	private final EmailSenderService service;
	
	
	@PostMapping("/sendResetMail")
	public MailResponse sendResetEmail(@RequestBody ResetPasswordRequest request) {
		return service.sendResetEmail(request);

	}
}
