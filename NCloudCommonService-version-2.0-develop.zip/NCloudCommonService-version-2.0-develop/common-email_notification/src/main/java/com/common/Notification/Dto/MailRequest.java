package com.common.Notification.Dto;

import java.util.List;

import lombok.Data;

@Data
public class MailRequest {
	
	private String name;
	private List<String> to;
	private String subject;
	private String Template;
	
	public String getTemplate() {
		return Template;
	}
	public void setTemplate(String template) {
		Template = template;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<String> getTo() {
		return to;
	}
	public void setTo(List<String> to) {
		this.to = to;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}

}
