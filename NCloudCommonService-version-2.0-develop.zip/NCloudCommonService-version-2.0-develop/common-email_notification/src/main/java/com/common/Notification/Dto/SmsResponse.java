package com.common.Notification.Dto;

public class SmsResponse {
	private String Message;

}
