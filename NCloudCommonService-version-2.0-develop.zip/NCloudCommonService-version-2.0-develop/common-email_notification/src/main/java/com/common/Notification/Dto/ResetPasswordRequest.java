package com.common.Notification.Dto;

import lombok.Data;

@Data
public class ResetPasswordRequest {

	private String to;
	private String subject;
	private String template;
	private String name;
}
