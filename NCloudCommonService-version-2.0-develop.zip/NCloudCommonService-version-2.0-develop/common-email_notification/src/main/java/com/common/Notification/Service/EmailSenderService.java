package com.common.Notification.Service;


import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.common.Notification.Dto.MailRequest;
import com.common.Notification.Dto.MailResponse;
import com.common.Notification.Dto.ResetPasswordRequest;

import freemarker.template.Configuration;
import freemarker.template.Template;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class EmailSenderService {

	private final JavaMailSender sender;
	
	private final Configuration config;
	
	public static final String Template_Folder_Path = "/mail-template";
    
	public MailResponse sendEmail(MailRequest request) {
		MailResponse response = new MailResponse();
		MimeMessage message = sender.createMimeMessage();
		try {
			// set mediaType
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			String htmls = request.getTemplate();

			StringBuffer stringBuffer = new StringBuffer();
			for (String userId : request.getTo()) {
				stringBuffer.append(userId);
				stringBuffer.append(", ");
			}
			helper.setTo(InternetAddress.parse(stringBuffer.toString()));
			helper.setText(htmls,true);
			helper.setSubject(request.getSubject());
			sender.send(message);

			response.setMessage("mail send successfully");
			response.setStatus(Boolean.TRUE);
			

		} catch (	Exception e) {
			response.setMessage("Mail Sending failure : "+ e.getMessage());
			response.setStatus(Boolean.FALSE);
		}

		return response;
	}
	
	public MailResponse sendResetEmail(ResetPasswordRequest request) {
		MailResponse response = new MailResponse();
		MimeMessage message = sender.createMimeMessage();
		Map<String, Object> model = new HashMap<>();
		model.put("url", request.getTemplate());
		model.put("name",request.getName());
		
		try {
			// set mediaType
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			
			config.setClassForTemplateLoading(this.getClass(), Template_Folder_Path);
			Template template = config.getTemplate("forgetPassword_template.ftl");
			
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(template,model);
			
				helper.setTo(request.getTo());
				helper.setText(html, true);
				helper.setSubject(request.getSubject());
				sender.send(message);
		
			response.setMessage("mail send successfully");
			response.setStatus(Boolean.TRUE);
			

		} catch (Exception e) {
			response.setMessage("Mail Sending failure : "+ e.getMessage());
			response.setStatus(Boolean.FALSE);
		}

		return response;
	}

    

}

