package com.common.Notification;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmailNotificationApplication {
	
	public static void main(String[] args) {

	}

}
