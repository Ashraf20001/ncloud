package comrecoveryportal.Notification.properties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:/environment.properties")
@PropertySource(value = "file:///${ENVIRONMENT_PROPERTIES}/environment.properties", ignoreResourceNotFound = true)
public class environmentproperties {
	
}


