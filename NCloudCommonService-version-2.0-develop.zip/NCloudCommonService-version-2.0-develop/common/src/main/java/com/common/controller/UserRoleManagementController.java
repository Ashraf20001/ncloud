package com.common.controller;

import java.util.List;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.common.aop.annotation.Auditable;
import com.common.config.base.controller.BaseController;
import com.common.config.model.FilterOrSortingVo;
import com.common.exception.core.ApplicationException;
import com.common.service.IUserRoleManagementService;
import com.common.transfer.object.core.ApplicationResponse;
import com.common.transfer.object.dto.AllocationUserTypeDto;
import com.common.transfer.object.dto.AllocationUserTypeList;
import com.common.transfer.object.dto.UserDisableDto;
import com.common.transfer.object.dto.UserRoleCardDto;
import com.common.transfer.object.dto.UserRoleManagementViewDTO;
import com.common.transfer.object.dto.UserRoleSaveOrUpdateDto;
import com.common.utils.core.ApplicationUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Auditable
public class UserRoleManagementController extends BaseController{
	
	private final IUserRoleManagementService userRoleManagementService;

	/**
	 * Retrieves all user role card details with optional filtering and sorting.
	 *
	 * @param min             Minimum value for pagination.
	 * @param max             Maximum value for pagination.
	 * @param searchValue     Optional search string.
	 * @param filterOrSortingVo List of filter/sorting criteria.
	 * @return ResponseEntity containing the user role card details.
	 * @throws ApplicationException if an error occurs.
	 */
	@ApiOperation(value = "Get User Role Cards", notes = "Fetches user role card details with optional filtering and sorting.", response = ApplicationResponse.class)
	@PostMapping("/get-role-card")
	public ApplicationResponse getAllUserRoleCardDetails(
			@ApiParam(value = "Minimum value", required = true) @RequestParam(name = "min") Integer min,
			@ApiParam(value = "Maximum value", required = true) @RequestParam(name = "max") Integer max,
			@ApiParam(value = "Search value") @RequestParam(name = "searchValue") String searchValue,
			@ApiParam(value = "List of filters and sorting options", required = true) @RequestBody List<FilterOrSortingVo> filterOrSortingVo)
			throws ApplicationException {
		return getApplicationResponse(userRoleManagementService.getAllUserRoleCardDetails(null, min, max,searchValue, filterOrSortingVo));
	}
	
	/**
	 * Retrieves the list of user roles for a specific company.
	 *
	 * @param companyId The ID of the company.
	 * @return ResponseEntity containing the list of user roles.
	 * @throws ApplicationException if an error occurs.
	 */
	@ApiOperation(value = "Get User Role List", notes = "Fetches user roles for a given company.", response = List.class)
	@GetMapping("/get-role-list")
	public List<UserRoleCardDto> getUserRoleList(
			@ApiParam(value = "Company ID", required = true) @RequestParam(name = "companyId") Integer companyId)
			throws ApplicationException {
		return userRoleManagementService.getUserRoleListInCompany(companyId);
	}
	
	/**
	 * Downloads the user role card details as an Excel file.
	 *
	 * @param min The minimum value for pagination.
	 * @param max The maximum value for pagination.
	 * @param searchValue The search keyword (optional).
	 * @param filterOrSortingVo The filtering/sorting criteria.
	 * @return ResponseEntity containing the Excel file as a byte array.
	 * @throws ApplicationException if an error occurs.
	 */
	@ApiOperation(value = "Download User Role Card", notes = "Generates and downloads an Excel file with user role details.", response = ResponseEntity.class)
	@PostMapping("/download-role-card")
	public ResponseEntity<ByteArrayResource> downloadUserRole(
			@ApiParam(value = "Minimun value", required = true) @RequestParam(name = "min") Integer min,
			@ApiParam(value = "Maximum value to return", required = true) @RequestParam(name = "max") Integer max,
			@ApiParam(value = "Search Value") @RequestParam(name = "searchValue", required = false) String searchValue,
			@ApiParam(value = "List of FilterOrSortingVo for filter or sorting criteria", required = true) @RequestBody List<FilterOrSortingVo> filterOrSortingVo)
			throws ApplicationException {
		List<UserRoleCardDto> data = userRoleManagementService.getAllUserRoleCardDetails(null, min, max,searchValue,filterOrSortingVo);
		if (Boolean.FALSE.equals(ApplicationUtils.isValidateObject(data))) {
			return null;
		}
		return userRoleManagementService.downloadExcelInUser(data);
	}

	/**
	 * Retrieves the count of user roles based on filtering criteria.
	 *
	 * @param searchValue The search keyword (optional).
	 * @param filter The filtering/sorting criteria.
	 * @return ApplicationResponse containing the count of user roles.
	 * @throws ApplicationException if an error occurs.
	 */
	@ApiOperation(value = "Get User Role List Count", notes = "Returns the count of user roles based on filters.",
			response = ApplicationResponse.class)
	@PostMapping("/get-role-list-count")
	public ApplicationResponse getAllUserRoleListCount(
			@ApiParam(value = "Search Value") @RequestParam(name = "searchValue", required = false) String searchValue,
			@ApiParam(value = "List of FilterOrSortingVo for filter or sorting criteria", required = true) @RequestBody List<FilterOrSortingVo> filter)
			throws ApplicationException {
		Long returnValue = userRoleManagementService.getAllUserRoleListCount(null,filter,searchValue);
		return getApplicationResponse(returnValue);
	}

	/**
	 * Retrieves the role card details for users associated with a given company.
	 *
	 * @param companyId The ID of the company.
	 * @return ApplicationResponse containing user role card details.
	 * @throws ApplicationException if an error occurs.
	 */
	@ApiOperation(value = "Get Association User Role Card Details", notes = "Fetches user role card details for a given company.",
			response = ApplicationResponse.class)
	@GetMapping("/association/get-role-card")
	public ApplicationResponse getAllAssociationUserRoleCardDetails(
			@ApiParam(value = "Company ID", required = true) @RequestParam(name = "company_id") Integer companyId)
			throws ApplicationException {
		return getApplicationResponse(userRoleManagementService.getAllUserRoleCardDetails(companyId, 0, 10,"",null));
	}

	/**
	 * Retrieves user management page information based on the provided page ID and optional role ID.
	 *
	 * @param pageId The ID of the page.
	 * @param roleId (Optional) The role ID.
	 * @return ApplicationResponse containing user management page details.
	 * @throws ApplicationException if an error occurs.
	 */
	@ApiOperation(value = "Get User Management Page Info", notes = "Fetches page details for user management based on page ID and optional role ID.", response = ApplicationResponse.class)
	@GetMapping("/get-role-page-info")
	public ApplicationResponse getUserMgmtPageInfo(@RequestParam(name = "page_id") String pageId,
			@ApiParam(value = "Role ID") @RequestParam(name = "role_id", required = false) String id) throws ApplicationException {
		UserRoleManagementViewDTO userMgmtPageInfo = userRoleManagementService.getUserMgmtPageInfo(pageId, id);
		return getApplicationResponse(userMgmtPageInfo);
	}

	/**
	 * Save or Update a User Role based on the given data in UserRoleSaveOrUpdateDto.
	 *
	 * @param userRoleSaveOrUpdateDto The UserRoleSaveOrUpdateDto containing role details.
	 * @return ApplicationResponse with a success message for save/update.
	 * @throws ApplicationException If an error occurs.
	 */
	@ApiOperation(value = "Save or Update User Role", notes = "Creates a new role or updates an existing role based on the provided data."
			,response = ApplicationResponse.class)
	@PostMapping("/user-role/saveOrUpdate")
	public ApplicationResponse saveUserRole(@RequestBody UserRoleSaveOrUpdateDto userRoleSaveOrUpdateDto)
			throws ApplicationException {
		return getApplicationResponse(userRoleManagementService.saveUserRole(null, userRoleSaveOrUpdateDto));
	}

	/**
	 * Save or Update an Association User Role based on the given data.
	 *
	 * @param companyId                 The ID of the company for which the role is being assigned.
	 * @param userRoleSaveOrUpdateDto    The UserRoleSaveOrUpdateDto containing role details.
	 * @return ApplicationResponse with a success message for save/update.
	 * @throws ApplicationException If an error occurs.
	 */
	@ApiOperation(value = "Save or Update Association User Role", notes = "Creates or updates a user role for an association.",
			response = ApplicationResponse.class)
	@PostMapping("/user-role/association/saveOrUpdate")
	public ApplicationResponse saveAssociationUserRole(
			@ApiParam(value = "Company ID", required = true) @RequestParam(name = "company_id") Integer companyId,
			@RequestBody UserRoleSaveOrUpdateDto userRoleSaveOrUpdateDto) throws ApplicationException {
		return getApplicationResponse(userRoleManagementService.saveUserRole(companyId, userRoleSaveOrUpdateDto));
	}

	/**
	 * Retrieves all menus available for the user's role.
	 *
	 * @return ApplicationResponse containing the menu list.
	 * @throws ApplicationException If an error occurs during retrieval.
	 */
	@ApiOperation(value = "Get All Menus by Role", notes = "Fetches all available menus based on the user's assigned role.",
			response = ApplicationResponse.class)
	@GetMapping("/menu/all")
	public ApplicationResponse getAllMenuByRole() throws ApplicationException {
		return getApplicationResponse(userRoleManagementService.getAllMenuByUserRole());
	}

	/**
	 * Get All privilege based on Role and PageId
	 * 
	 * @param pageId
	 * @return
	 * @throws ApplicationException
	 */
	@ApiOperation(value = "Get All Privilege",
			notes = "Fetch all privilege based on Role and PageId.", response = ApplicationResponse.class)
	@GetMapping("/privillege/all")
	public ApplicationResponse getPrivillegeData(@ApiParam(value = "Page ID", required = true) @RequestParam Integer pageId) throws ApplicationException {
		return getApplicationResponse(userRoleManagementService.getAllPrivillegeByUserRole(pageId));
	}

	/**
     * Retrieves page access details based on the provided page identity.
     *
     * @param pageIdentity Unique identifier for the page.
     * @return ApplicationResponse containing access details.
     * @throws ApplicationException If any error occurs during retrieval.
     */
    @ApiOperation(value = "Get Page Access Data", notes = "Fetches page access details based on user role and page identity.",
    		response = ApplicationResponse.class)
	@GetMapping("/page/access")
	public ApplicationResponse getPageAccessData(
			@ApiParam(value = "Unique Identitfier of Page", required = true) @RequestParam String pageIdentity)
			throws ApplicationException {
		return getApplicationResponse(userRoleManagementService.getPageAccessDetailsByUserRole(pageIdentity));
	}

    /**
     * Deletes a user role based on the provided user disable details.
     *
     * @param userDisableDto DTO containing user role details to be disabled.
     * @return ApplicationResponse indicating the status of the delete operation.
     * @throws ApplicationException If any error occurs during deletion.
     */
    @ApiOperation(value = "Delete User Role", notes = "Deletes a specific user role based on the provided details.",
    		response = ApplicationResponse.class)
	@PostMapping("/user-role/deleteRole")
	public ApplicationResponse deleteRoleData(
			@ApiParam(value = "UserDisableDto Request PayLoad", required = true) @RequestBody UserDisableDto userDisableDto)
			throws ApplicationException {
		return getApplicationResponse(userRoleManagementService.deleteRoleData(userDisableDto));
	}

    /**
     * Downloads the list of roles in an Excel format.
     *
     * @return ResponseEntity containing the Excel file as an InputStreamResource.
     * @throws ApplicationException If any error occurs during the generation of the Excel file.
     */
    @ApiOperation(value = "Download Role List as Excel", 
                  notes = "Generates and downloads the list of user roles in an Excel format.", response = ResponseEntity.class)
	@GetMapping("/user-role/download-excel")
	public ResponseEntity<InputStreamResource> getRoleListExcel() throws ApplicationException {
		return userRoleManagementService.getRoleListExcel();
	}

    /**
     * Retrieves the list of allocation user types based on the provided filter or sorting criteria.
     *
     * @param filterVo A list of filter or sorting criteria (FilterOrSortingVo).
     * @return A ResponseEntity containing the list of allocation user types in AllocationUserTypeList.
     * @throws ApplicationException If any error occurs during the retrieval process.
     */
    @ApiOperation(value = "Get Allocation User Type List", 
                  notes = "Fetches the list of allocation user types based on filter or sorting criteria.",
                  response = ResponseEntity.class)
	@PostMapping("/user-role/get-user-type")
	public ResponseEntity<AllocationUserTypeList> getAllocationUserTypeList(
			@ApiParam(value = "List of FilterOrSortingVo for filter or sorting criteria", required = true) @RequestBody List<FilterOrSortingVo> filterVo)
			throws ApplicationException {
		AllocationUserTypeList list = new AllocationUserTypeList();
		List<AllocationUserTypeDto> allocationUserTypeList = userRoleManagementService.getAllocationUserTypeList(filterVo);
		list.setAllocationUserTypeList(allocationUserTypeList);
		return new ResponseEntity<AllocationUserTypeList>(list,HttpStatus.OK);
	}

	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}

	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	@Override
	protected void registerInterceptor() {

	}
}
