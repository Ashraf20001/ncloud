package com.common.dao;

import java.util.List;

import com.common.transfer.object.entity.Role;

/**
 * The Interface IApiPrivilegeDao.
 */
public interface IApiPrivilegeDao {

	/**
	 * Gets the all role.
	 *
	 * @return the all role
	 */
	List<Role> getallRole();

	/**
	 * All api privilege.
	 *
	 * @return the list
	 */
	List<Object[]>  allApiPrivilege();

	/**
	 * All default page api privilege.
	 *
	 * @return the list
	 */
	List<Object[]> allDefaultPageApiPrivilege();

	/**
	 * All default api privilege.
	 *
	 * @return the list
	 */
	List<Object[]> allDefaultApiPrivilege();

}
