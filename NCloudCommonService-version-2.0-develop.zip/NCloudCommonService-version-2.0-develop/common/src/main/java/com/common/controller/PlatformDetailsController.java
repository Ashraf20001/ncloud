package com.common.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.common.service.IPlatformDetailsService;
import com.common.transfer.object.dto.PlatformDetailsDto;

import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;

/**
 * The Class PlatformDetailsController.
 */
@RestController
@RequiredArgsConstructor
public class PlatformDetailsController {

	/** The platform details service. */
	private final IPlatformDetailsService platformDetailsService;
	
	
	/**
	 * Gets the platform details dto list.
	 *
	 * @return the platform details dto list
	 */
	@ApiOperation(value="Platform details",notes="Get platform details dto list",response = List.class)
	@GetMapping("/getPlatformDetails")
	public List<PlatformDetailsDto> getPlatformDetailsDtoList(){
		return platformDetailsService.getPlatformDetails();
	}
}
