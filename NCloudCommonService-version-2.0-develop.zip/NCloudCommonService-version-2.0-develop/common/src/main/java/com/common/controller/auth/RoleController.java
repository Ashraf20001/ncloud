package com.common.controller.auth;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.common.config.base.controller.BaseController;
import com.common.exception.core.ApplicationException;
import com.common.service.IRoleService;
import com.common.transfer.object.core.ApplicationResponse;
import com.common.transfer.object.dto.AccessDetailsOfUserDto;
import com.common.transfer.object.dto.RoleDto;
import com.common.transfer.object.entity.Role;

import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class RoleController extends BaseController {

	private final IRoleService roleservice;

	private final ModelMapper mapper;

	private static final Logger loggers = LoggerFactory.getLogger(RoleController.class);

	/**
    * Creates a new role based on the provided role details.
    * 
    * @param roledto DTO containing role information.
    * @return ApplicationResponse with the created role details.
    */
   @ApiOperation(value = "Create a Role", 
                 notes = "Creates a new role based on the provided role details and returns the created role.")
	@PostMapping("/role")
	public ApplicationResponse roleCreation(@RequestBody RoleDto roledto) {
		loggers.info("Strating of RoleController roleCreation()");

		RoleDto dto = null;
		try {
			Role rolemap = mapper.map(roledto, Role.class);
			dto = roleservice.createRole(rolemap);
		} catch (Exception e) {
			loggers.error("Error  in RoleController roleCreation() ", e);

		}

		return getApplicationResponse(dto);
	}
	
   /**
    * Retrieves access details for a user based on their roles and page ID.
    *
    * @param pageId     The ID of the page for which access details are required.
    * @param userId     The ID of the user whose access details are to be fetched.
    * @param roleIdList A list of role IDs associated with the user.
    * @return AccessDetailsOfUserDto containing the user's access details for the given page.
    */
   @ApiOperation(value = "Get User Access Details", 
                 notes = "Fetches the access details of a user based on the provided page ID and role IDs.")
	@PostMapping("/get-access-details")
	public AccessDetailsOfUserDto getUserAccessDetails(@RequestParam("page_id") String pageId, @RequestParam("user_id") Integer userId, @RequestBody List<Integer> roleIdList) {
		return roleservice.getAccessDetailsOfUser(pageId, userId, roleIdList);
	}

	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}

	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	@Override
	protected void registerInterceptor() {
	}

}
