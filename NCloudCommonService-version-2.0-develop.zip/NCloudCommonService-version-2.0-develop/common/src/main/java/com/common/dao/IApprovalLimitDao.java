package com.common.dao;

import java.util.List;

import com.common.exception.core.ApplicationException;
import com.common.transfer.object.entity.ApprovalLevel;
import com.common.transfer.object.entity.ApprovalLimit;
import com.common.transfer.object.entity.Role;

/**
 * The Interface IApprovalLimitDao.
 */
public interface IApprovalLimitDao {

   /**
    * Save approval limit.
    *
    * @param approvalLimit the approval limit
    * @return the approval limit
    * @throws ApplicationException the application exception
    */
   public ApprovalLimit saveApprovalLimit(ApprovalLimit approvalLimit) throws ApplicationException;
	
	/**
	 * Save approval level.
	 *
	 * @param approvalLevel the approval level
	 * @return the approval level
	 * @throws ApplicationException the application exception
	 */
	public ApprovalLevel saveApprovalLevel(ApprovalLevel approvalLevel) throws ApplicationException;
	
	/**
	 * Gets the approval limit.
	 *
	 * @param id the id
	 * @return the approval limit
	 */
	public ApprovalLimit getApprovalLimit(Integer id);


	/**
	 * Gets the role details.
	 *
	 * @param roleId the role id
	 * @return the role details
	 */
	public Role getRoleDetails(Integer roleId);

	
	/**
	 * Gets the approval level list.
	 *
	 * @param approvalLimitId the approval limit id
	 * @param fieldId the field id
	 * @return the approval level list
	 */
	public List<ApprovalLevel> getApprovalLevelList(Integer approvalLimitId,Integer fieldId);
	
	/**
	 * Update approval limit.
	 *
	 * @param approvalLimit the approval limit
	 * @return the approval limit
	 */
	public ApprovalLimit updateApprovalLimit(ApprovalLimit approvalLimit);
	
	/**
	 * Update approval level.
	 *
	 * @param approvalLevel the approval level
	 * @return the approval level
	 */
	public ApprovalLevel updateApprovalLevel(ApprovalLevel approvalLevel);
	
	/**
	 * Gets the approval limit list.
	 *
	 * @param companyId the company id
	 * @param min the min
	 * @param max the max
	 * @return the approval limit list
	 */
	public List<ApprovalLimit> getApprovalLimitList(Integer companyId, int min, int max);
	
	/**
	 * Gets the approval limit by field id.
	 *
	 * @param fieldId the field id
	 * @param companyId the company id
	 * @return the approval limit by field id
	 */
	public List<ApprovalLimit> getApprovalLimitByFieldId(Integer fieldId, Integer companyId);

	/**
	 * Gets the approval limit count.
	 *
	 * @param companyId the company id
	 * @return the approval limit count
	 */
	public Long getApprovalLimitCount(Integer companyId);

	

	/**
	 * Gets the approval level for knock check.
	 *
	 * @param fromCompany the from company
	 * @param toCompany the to company
	 * @param currencyType the currency type
	 * @return the approval level for knock check
	 */
	ApprovalLevel getApprovalLevelForKnockCheck(Integer fromCompany, Integer toCompany, String currencyType);

	

	/**
	 * Gets the comp ids of knock.
	 *
	 * @param fromCompany the from company
	 * @return the comp ids of knock
	 */
	List<Integer> getCompIdsOfKnock(Integer fromCompany);

	/**
	 * Gets the approval level list for disable.
	 *
	 * @param approvalLimitId the approval limit id
	 * @return the approval level list for disable
	 */
	List<ApprovalLevel> getApprovalLevelListForDisable(Integer approvalLimitId);

	/**
	 * Gets the rolelist by limit.
	 *
	 * @param fieldId the field id
	 * @param companyId the company id
	 * @param approvalLimitMaxValue the approval limit max value
	 * @param maxOrMin the max or min
	 * @return the rolelist by limit
	 */
	List<ApprovalLevel> getrolelistByLimit(Integer fieldId, int companyId, Double approvalLimitMaxValue,
			String maxOrMin);

	/**
	 * Gets the role limit.
	 *
	 * @param roleId the role id
	 * @param fieldList the field list
	 * @return the role limit
	 */
	List<ApprovalLevel> getroleLimit(List<Integer> roleId, List<Integer> fieldList);

}
