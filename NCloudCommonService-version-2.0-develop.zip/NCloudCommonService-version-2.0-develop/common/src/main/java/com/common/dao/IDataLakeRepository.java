package com.common.dao;

import java.util.List;

import com.common.exception.core.ApplicationException;
import com.common.transfer.object.dto.UserDetailsDto;
import com.common.transfer.object.dto.UserPrivillageDto;
import com.common.transfer.object.entity.SystemProperty;
import com.common.transfer.object.entity.SystemPropertyValue;

/**
 * The Interface IDataLakeRepository.
 */
public interface IDataLakeRepository {
	/**
	 * @param platformIdentity 
	 * @param role
	 * @return
	 */
	List<UserPrivillageDto> getPrivilegeDetails(List<Integer> roleId, Integer platformIdentity);

	/**
	 * @param userIds
	 * @return
	 */
	List<UserDetailsDto> getUserProfileById(List<Integer> userIds);

	/**
	 * @param fieldName
	 * @param platformId
	 * @return
	 */
	SystemProperty getSystemPropertyDeails(String fieldName, Integer platformId);

	/**
	 * @param systemPropertyValue
	 * @throws ApplicationException 
	 */
	void saveSystemPropertyValue(SystemPropertyValue systemPropertyValue) throws ApplicationException;

	/**
	 * @param platformId
	 * @return
	 */
	List<SystemProperty> getSystemPropertyId(Integer platformId);

	/**
	 * @param systemPropertyIds
	 * @return
	 */
	SystemPropertyValue getSystemPropertyValues(Integer systemPropertyIds);
	
	 /**
	 * @param systemPropertyIds
	 * @return
	 */
	List<SystemPropertyValue> getSystemPropertyDetails(List<Integer> systemPropertyIds);

	/**
	 * Update system property value.
	 *
	 * @param systemPropertyValue the system property value
	 * @throws ApplicationException the application exception
	 */
	void updateSystemPropertyValue(SystemPropertyValue systemPropertyValue) throws ApplicationException;
}
