package com.common.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.common.aop.annotation.Auditable;
import com.common.config.base.controller.BaseController;
import com.common.config.model.FilterOrSortingVo;
import com.common.exception.core.ApplicationException;
import com.common.service.IEntityManageMentService;
import com.common.transfer.object.core.ApplicationResponse;
import com.common.transfer.object.dto.CompanyDetailsDto;
import com.common.transfer.object.dto.CompanyDto;
import com.common.transfer.object.dto.CompanyFileSaveDto;
import com.common.transfer.object.dto.FileStorageDetailsDto;
import com.common.transfer.object.dto.GarageDisableDto;
import com.common.transfer.object.dto.GarageDto;
import com.common.transfer.object.dto.MetaDataPageDto;
import com.common.transfer.object.dto.companyViewDto;
import com.common.transfer.object.vo.dto.FieldGroup;
import com.common.utils.core.ApplicationUtils;

import freemarker.core.ParseException;
import freemarker.template.MalformedTemplateNameException;
import freemarker.template.TemplateException;
import freemarker.template.TemplateNotFoundException;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

/**
 * The Class EntityManagementController.
 */
@RestController
@RequiredArgsConstructor
@Auditable
public class EntityManagementController extends BaseController {
	
	/** The entity mangement service. */
	private final IEntityManageMentService entityMangeMentService;
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER= LoggerFactory.getLogger(EntityManagementController.class);

	/**
	 * Gets the page data.
	 *
	 * @param pageId the page id
	 * @param referenceId the reference id
	 * @return the page data
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Company manage info",notes="Get meta data info about company creation page",response=MetaDataPageDto.class)
	@GetMapping("/entitymanagement/getpageinfo")
	public MetaDataPageDto getPageData(@ApiParam(value="Page id",required = true) @RequestParam("page_id") String pageId,
			@ApiParam(value="Reference id") @RequestParam(value = "reference_id", required = false) Integer referenceId) throws ApplicationException {
		return entityMangeMentService.getPageInfo(pageId, referenceId);
	}

	/**
	 * Save page.
	 *
	 * @param pageId the page id
	 * @param referenceId the reference id
	 * @param isActive the is active
	 * @param fieldGroup the field group
	 * @return the integer
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Company changes",notes="Create or modify the companies",response=MetaDataPageDto.class)
	@PostMapping("/entitymanagement/saveOrUpdate")
	public Integer savePage(
			@ApiParam(value="Page id",required = true) @RequestParam("page_id") String pageId,
			@ApiParam(value="Reference id") @RequestParam(name = "reference_id", required = false) String referenceId,
			@ApiParam(value="Active or not",required = true) @RequestParam(name = "is_active") boolean isActive, 
			@ApiParam(value="FieldGroup data payload",required = true) @RequestBody FieldGroup fieldGroup)
			throws ApplicationException {
		LOGGER.info("Entity Management save call started ====>");
		Integer id = entityMangeMentService.savePage(referenceId, fieldGroup, pageId, isActive);
		return (id);
	}

	/**
	 * Save file.
	 *
	 * @param companyFileSaveDto the company file save dto
	 * @return the string
	 * @throws ApplicationException the application exception
	 * @throws TemplateNotFoundException the template not found exception
	 * @throws MalformedTemplateNameException the malformed template name exception
	 * @throws ParseException the parse exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws TemplateException the template exception
	 */
	@ApiOperation(value="Update company file",notes="Update the file url of company creation",response=String.class)
	@PostMapping("/entitymanagement/updateFileUrl")
	public String saveFile(@ApiParam(value="CompanyFileSaveDto data payload",required = true) @RequestBody CompanyFileSaveDto companyFileSaveDto)
			throws ApplicationException, TemplateNotFoundException, MalformedTemplateNameException, ParseException, IOException, TemplateException {
		String id = entityMangeMentService.saveFile(companyFileSaveDto);
		return (id);
	}

	/**
	 * Gets the insurance company data.
	 *
	 * @param min the min
	 * @param max the max
	 * @param searchValue the search value
	 * @param filterOrSortingVo the filter or sorting vo
	 * @return the insurance company data
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Company details",notes="Get the company details list",response=List.class)
	@PostMapping("/entitymanagement/getInsuranceData")
	public List<companyViewDto> getInsuranceCompanyData(
			@ApiParam(value="Skip data count",required = true) @RequestParam(name = "min") Integer min,
			@ApiParam(value="Limit data count",required = true)  @RequestParam(name = "max") int max, 
			@ApiParam(value="Search data",required = true)   @RequestParam(name = "searchValue") String searchValue, 
			@ApiParam(value="Filter vo payload data",required = true)   @RequestBody List<FilterOrSortingVo> filterOrSortingVo) throws ApplicationException {
		return entityMangeMentService.getInsuranceCompanyData(min, max,filterOrSortingVo, searchValue);
	}
	
	/**
	 * Entity managment download.
	 *
	 * @param min the min
	 * @param max the max
	 * @param searchValue the search value
	 * @param filterOrSortingVo the filter or sorting vo
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Company download",notes="Download the company details list",response=ResponseEntity.class)
	@PostMapping("/entitymanagement/entityManagement-download")
	public ResponseEntity<ByteArrayResource> entityManagmentDownload(
			@ApiParam(value="Skip data count",required = true) @RequestParam(name = "min") Integer min,
			@ApiParam(value="Limit data count",required = true) @RequestParam(name = "max") int max, 
			@ApiParam(value="Search data",required = true) @RequestParam(name = "searchValue") String searchValue ,
			@ApiParam(value="Filter vo payload data",required = true) @RequestBody List<FilterOrSortingVo> filterOrSortingVo) throws ApplicationException {
		
		List<companyViewDto> entityManagmentList = entityMangeMentService.getInsuranceCompanyData(min, max,filterOrSortingVo,searchValue);
		
		if (Boolean.FALSE.equals(ApplicationUtils.isValidateObject(entityManagmentList))) {
			return null;
		}
		
		return entityMangeMentService.managmentDownload(entityManagmentList);
		
	}
	
	/**
	 * GetGarageListExcel.
	 *
	 * @return the garage list excel
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Download Garage List as Excel", notes = "Fetches the garage list in Excel format", response = ResponseEntity.class)
	@GetMapping("/entitymanagement/garage/download-excel")
	public ResponseEntity<InputStreamResource> getGarageListExcel() throws ApplicationException {
		return entityMangeMentService.getGarageListIntoExcel();
	}

	/**
	 * Gets the insurance company count.
	 *
	 * @param searchValue the search value
	 * @param filterOrSortingVos the filter or sorting vos
	 * @return the insurance company count
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Get Insurance Company Count", notes = "Returns the count of insurance companies based on filters",response=Long.class)
	@PostMapping("/entitymanagement/getInsuranceDataCount")
	public Long getInsuranceCompanyCount(@ApiParam(value="Search data",required = true) @RequestParam(name = "searchValue") String searchValue,
			@ApiParam(value="Filter vo payload data",required = true) @RequestBody List<FilterOrSortingVo> filterOrSortingVos) throws ApplicationException {
		return entityMangeMentService.getInsuranceCompanyCount(filterOrSortingVos, searchValue);
	}

	/**
	 * Gets the garage list.
	 *
	 * @param min the min
	 * @param max the max
	 * @return the garage list
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Get Garage List", notes = "Fetches the list of garages with pagination",response = List.class)
	@GetMapping("/entitymanagement/getGarageData")
	public List<GarageDto> getGarageList(
			@ApiParam(value="Skip data count",required = true) @RequestParam(name = "min") int min, 
			@ApiParam(value="Limit data count",required = true) @RequestParam(name = "max") int max)
			throws ApplicationException {
		return entityMangeMentService.getGarageList(min, max);
	}

	/**
	 * Gets the garage count.
	 *
	 * @return the garage count
	 * @throws ApplicationException the application exception
	 */
	 @ApiOperation(value = "Get Garage Count", notes = "Fetches the total count of garages",response = Long.class)
	@GetMapping("/entitymanagement/getGarageCount")
	public Long getGarageCount() throws ApplicationException {
		return entityMangeMentService.getGarageCount();
	}

	/**
	 * Delete company.
	 *
	 * @param companyId the company id
	 * @return the string
	 * @throws ApplicationException the application exception
	 */
	 @ApiOperation(value = "Delete a Company", notes = "Deletes a company by Id",response = String.class)
	@GetMapping("/entitymanagement/DeleteCompanyIdentiy")
	public String deleteCompany(@ApiParam(value="Company id",required = true)  @RequestParam(value = "companyId") String companyId) throws ApplicationException {
		return entityMangeMentService.deleteCompany(companyId);
	}

	/**
	 * Delete garage.
	 *
	 * @param garageDisable the garage disable
	 * @return the string
	 * @throws ApplicationException the application exception
	 */

	@ApiOperation(value = "Delete a Garage", notes = "Disables or deletes a garage",response = String.class)
	@PostMapping("/entitymanagement/DeleteGarageIdentiy")
	public String deleteGarage(@ApiParam(value = "Garage disable payload", required = true)  @RequestBody GarageDisableDto garageDisable) throws ApplicationException {
		return entityMangeMentService.deleteGarage(garageDisable);
	}

	/**
	 * Gets the all company details.
	 *
	 * @return the all company details
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Get All Company Details", notes = "Fetches details of all companies",response=List.class) 
	@GetMapping("/entitymanagement/get-all-company")
	public List<CompanyDto> getAllCompanyDetails() throws ApplicationException {
		return entityMangeMentService.getAllCompanyDetails();
	}
	
	/**
	 * Gets the company name list.
	 *
	 * @param associationId the association id
	 * @return the company name list
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Get Company Name List", notes = "Fetches company names by association ID",response=List.class)
	@GetMapping("/entitymanagement/get-company-name-list")
	public List<String> getCompanyNameList(@ApiParam(value = "Association ID", required = true) @RequestParam(value="associationId") Integer associationId) throws ApplicationException {
		return entityMangeMentService.getCompanyNameListByAssociationId(associationId);
	}
	
	/**
	 * Gets the company id list.
	 *
	 * @param associationId the association id
	 * @return the company id list
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Get Company ID and Name List", notes = "Fetches company ID and names by association ID",response=List.class)
	@GetMapping("/entitymanagement/get-company-id-And-Name-list")
	public List<CompanyDetailsDto> getCompanyIdList(@ApiParam(value = "Association ID", required = true) @RequestParam(value="associationId") Integer associationId) throws ApplicationException {
		return entityMangeMentService.getCompanyIdAndNameListByAssociationId(associationId);
	}

	/**
	 * Gets the all company.
	 *
	 * @return the all company
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Get All Companies", notes = "Fetches a map of all company IDs and names",response=HashMap.class)
	@GetMapping("/get-allCompanyList")
	public HashMap<Integer, String> getAllCompany() throws ApplicationException {
		return entityMangeMentService.getAllCompanyMAp();
	}
	
	/**
	 * Gets the all other companies.
	 *
	 * @param companyId the company id
	 * @return the all other companies
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Get All Other Companies", notes = "Fetches all companies excluding the given company ID",response=List.class)
	@GetMapping("/get-all-other-companiesList")
	public List<CompanyDto> getAllOtherCompanies(@ApiParam(value = "Company ID to exclude", required = true) @RequestParam(value="companyId") Integer companyId) throws ApplicationException {
		return entityMangeMentService.getAllOtherCompanies(companyId);
	}
	
	/**
	 * Gets the company user mail.
	 *
	 * @param companyList the company list
	 * @return the company user mail
	 */
	 @ApiOperation(value = "Get Company User Emails", notes = "Fetches user emails for a list of companies",response = Map.class)
	@PostMapping("/get-company-user-mail")
	public Map<String, List<String>> getCompanyUserMail( @ApiParam(value = "List of company names", required = true) @RequestBody List<String> companyList) {
		return entityMangeMentService.getCompanyUserEmail(companyList); 
	}
	
	/**
	 * Gets the company from company name.
	 *
	 * @param companyName the company name
	 * @return the company from company name
	 */
	@ApiOperation(value = "Get Company by Name", notes = "Fetches company details using company name",response = CompanyDto.class)
	@GetMapping("/get-company-from-companyName")
	public CompanyDto getCompanyFromCompanyName(@ApiParam(value = "Company name", required = true) @RequestParam("name") String companyName) {
		return entityMangeMentService.getCompanyByCompanyName(companyName);
	}
	
	/**
	 * Gets the company from company id.
	 *
	 * @param companyId the company id
	 * @return the company from company id
	 */
	@ApiOperation(value = "Get Company by ID", notes = "Fetches company details using company ID",response=CompanyDto.class)
	@GetMapping("/get-company-from-companyId")
	public CompanyDto getCompanyFromCompanyId(@ApiParam(value = "Company ID", required = true) @RequestParam("id") Integer companyId) {
		return entityMangeMentService.getCompanyByCompanyId(companyId);
	}
	
	/**
	 * Gets the company file storage details.
	 *
	 * @param companyId the company id
	 * @param rpType the rp type
	 * @return the company file storage details
	 */
	@ApiOperation(value = "Get Company File Storage Details", notes = "Fetches file storage details by company ID and reference type",response=FileStorageDetailsDto.class)
	@GetMapping("/get-file-storage-from-companyId")
	public FileStorageDetailsDto getCompanyFileStorageDetails(@ApiParam(value = "Company ID", required = true) @RequestParam("companyId") Integer companyId, 
			 @ApiParam(value = "Reference type", required = true)  @RequestParam("rp_type") String rpType) {
		return entityMangeMentService.getFileStorageUsingCompanyIdandRpType(companyId,rpType);
	}
	
	/**
	 * Gets the companies from company ids.
	 *
	 * @param companyIdList the company id list
	 * @return the companies from company ids
	 */
	@ApiOperation(value = "Get Companies from IDs", notes = "Fetches a list of companies using a list of company IDs",response = List.class)
	@PostMapping("/get-companies-from-companyIdList")
	public List<CompanyDto> getCompaniesFromCompanyIds(@ApiParam(value="CompanyIdList payload data",required = true) @RequestBody List<Integer> companyIdList){
		return entityMangeMentService.getCompanyListUsingCompanyIds(companyIdList);
	}
	
	/**
	 * Gets the companies from company names.
	 *
	 * @param companyNameList the company name list
	 * @return the companies from company names
	 */
	@ApiOperation(value = "Get Company IDs from Names", notes = "Fetches company IDs from a list of company names",response = List.class)
	@PostMapping("/get-companyIds-from-companyNameList")
	public List<Integer> getCompaniesFromCompanyNames(@ApiParam(value = "List of company names payload", required = true)   @RequestBody List<String> companyNameList){
		return entityMangeMentService.getCompaniesFromCompanyNames(companyNameList);
	}
	
	/**
	 * Gets the all company dto map.
	 *
	 * @return the all company dto map
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Get All Company DTOs", notes = "Fetches a map of all company DTOs",response=HashMap.class)
	@GetMapping("/get-allCompanyDtos")
	public HashMap<Integer, CompanyDto> getAllCompanyDtoMap() throws ApplicationException {
		return entityMangeMentService.getCompanyDtoMaps();
	}
	
	 /**
 	 * Gets the contact.
 	 *
 	 * @param garageName the garage name
 	 * @return the contact
 	 */
	@ApiOperation(value = "Get Garage Contact Details", notes = "Fetches contact details for a given garage name",response = ApplicationResponse.class)
 	@GetMapping("/get-contact-detail")
 	public ApplicationResponse getContact(@ApiParam(value = "Garage name", required = true) @RequestParam(name = "garageName")String garageName) {
 	return getApplicationResponse(entityMangeMentService.getGarageByGarageName(garageName));
 		
 	}

	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {

	}

}
