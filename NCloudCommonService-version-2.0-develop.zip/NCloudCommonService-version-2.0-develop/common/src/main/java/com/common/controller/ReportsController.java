package com.common.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.common.exception.core.ApplicationException;
import com.common.service.IReportService;
import com.common.transfer.object.dto.MakeModelUsageDto;
import com.common.transfer.object.dto.ReportCardDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;


/**
 * The Class ReportsController.
 */
@RestController
@RequestMapping("/report")
@RequiredArgsConstructor
public class ReportsController {

	/** The report service. */
	private final IReportService reportService;

	/**
	 * Save report details.
	 *
	 * @param list the list
	 * @return the string
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Save report details",
            notes = "Saves the report details into the system",
            response = String.class)
	@PostMapping("/saveData")
	public String saveReportDetails(
			@ApiParam(value = "Report details to be saved", required = true)	 @RequestBody ReportCardDto list) throws ApplicationException{
		return  reportService.SaveReportDetails(list);
		
	}
	
	/**
	 * Gets the report fields.
	 *
	 * @return the report fields
	 */
	 @ApiOperation(value = "Get report fields",
             notes = "Retrieves the list of report fields",
             response = List.class)
	@GetMapping("/ReportFields")
	public List<String> getReportFields() {
		return reportService.getReportFields();	
		
	}

	/**
	 * Gets the report details.
	 *
	 * @return the report details
	 * @throws ApplicationException the application exception
	 */
	 @ApiOperation(value = "Get all report details",
             notes = "Retrieves all report data",
             response = List.class)
	@GetMapping("/getData")
	public List<ReportCardDto> getReportDetails()throws ApplicationException {
		return reportService.getAllData();
		
	}
	
	/**
	 * Report card update.
	 *
	 * @param list the list
	 * @return the string
	 * @throws ApplicationException the application exception
	 */
	 @ApiOperation(value = "Update report card details",
             notes = "Updates an existing report card entry",
             response = String.class)
	@PostMapping("/updateData")
	public String ReportCardUpdate(
			@ApiParam(value = "Updated report details", required = true) @RequestBody ReportCardDto list) throws ApplicationException {
		return  reportService.UpdateValues(list);
	}
	
	/**
	 * Gets the single data.
	 *
	 * @param Identity the identity
	 * @return the single data
	 * @throws ApplicationException the application exception
	 */
	 @ApiOperation(value = "Get a single report entry by identity",
             notes = "Retrieves a specific report card entry",
             response = ReportCardDto.class)
	@PostMapping("/getByIdentity")
	public ReportCardDto getSingleData(
			@ApiParam(value = "Identity of the report", required = true)   @RequestBody String Identity) throws ApplicationException {
		
		return reportService.getSingleValue(Identity);
	}

	/**
	 * Gets the option list.
	 *
	 * @param fieldIdentity the field identity
	 * @param fieldValue the field value
	 * @param fieldName the field name
	 * @return the option list
	 * @throws ApplicationException the application exception
	 */
	
	 @ApiOperation(value = "Get dropdown options",
             notes = "Retrieves dropdown data based on field identity, value, and name",
             response = List.class)
	@GetMapping("/getDropDownData")
	public List<String> getOptionList(@RequestParam("fieldIdentity") String fieldIdentity
											,@RequestParam("fieldValue") String fieldValue,@RequestParam("fieldName") String fieldName)throws ApplicationException {
		
		return reportService.getDropDownValue(fieldIdentity,fieldValue,fieldName);
		
	}
	

	/**
	 * Gets the drop down data.
	 *
	 * @param fieldIdentity the field identity
	 * @param fieldValue the field value
	 * @param fieldName the field name
	 * @return the drop down data
	 * @throws ApplicationException the application exception
	 */
	@GetMapping("/getDropDownData-digital-paper")
	public List<String> getDropDownData(
			@ApiParam(value = "Field Identity", required = true)	@RequestParam("fieldIdentity") String fieldIdentity,
			 @ApiParam(value = "Field Value", required = true)  @RequestParam("fieldValue") String fieldValue,
			 @ApiParam(value = "Field Name", required = true) @RequestParam("fieldName") String fieldName)throws ApplicationException {
		
		return reportService.getDropDownDataByDropDownList(fieldIdentity,fieldValue,fieldName);
		
	}
	
	/**
	 * Gets the make dropdown list.
	 *
	 * @return the make dropdown list
	 */
	 @ApiOperation(value = "Get make, model, and usage dropdown list",
             notes = "Retrieves the dropdown list for make, model, and usage",
             response = MakeModelUsageDto.class)
	@GetMapping("/get-make-model-usage-list")
	public MakeModelUsageDto getMakeDropdownList(){
		return reportService.getMakeModelUsageDropdown();
	}
	

}


