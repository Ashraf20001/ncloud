package com.common.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.common.config.base.controller.BaseController;
import com.common.exception.core.ApplicationException;
import com.common.service.ILogoService;
import com.common.transfer.object.core.ApplicationResponse;
import com.common.transfer.object.dto.CompanyDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

/**
 * The Class CompanyLogoController.
 */
@RestController
@RequestMapping
@RequiredArgsConstructor
public class CompanyLogoController extends BaseController{

	/** The logo service. */
	private final ILogoService logoService;
	
	 
    /**
     * Gets the company logo.
     *
     * @param companyId the company id
     * @return the company logo
     * @throws ApplicationException the application exception
     */
	@ApiOperation(value="Company logo",notes = "Get company logo details",response=ApplicationResponse.class)
    @GetMapping("/company/get-logo")
    public ApplicationResponse getCompanyLogo(@ApiParam(value = "Company id",required = true) @RequestParam(name="companyId") Integer companyId) throws ApplicationException {
    	String logoByCompanyId = logoService.getLogoByCompanyId(companyId);
    	return getApplicationResponse(logoByCompanyId);
    }
    
    /**
     * Gets the company logo.
     *
     * @param companyId the company id
     * @param rpType the rp type
     * @return the company logo
     * @throws ApplicationException the application exception
     */
	@ApiOperation(value="Company logo",notes = "Get company logo details using reference type",response=ApplicationResponse.class)
    @GetMapping("/company/get-logo-using-rptype")
    public ApplicationResponse getCompanyLogo(@ApiParam(value = "Company id",required = true) @RequestParam(name="companyId") Integer companyId,
    		@ApiParam(value = "Reference type",required = true) @RequestParam(name="rpType") String rpType) throws ApplicationException {
    	String logoByCompanyId = logoService.getLogoByCompanyId(companyId);
    	return getApplicationResponse(logoByCompanyId);
    }

    /**
     * Gets the class name.
     *
     * @return the class name
     */
    @Override
    protected Class<?> getClassName() {
        return this.getClass();
    }

    /**
     * Gets the vo.
     *
     * @param identity the identity
     * @return the vo
     * @throws ApplicationException the application exception
     */
    @Override
    public Object getVo(String identity) throws ApplicationException {
        return null;
    }

    /**
     * Register interceptor.
     */
    @Override
    protected void registerInterceptor() {

    }
    
    
    /**
     * Gets the platform values.
     *
     * @return the platform values
     */
    @ApiOperation(value="System properties",notes = "Get system property details for platforms",response=ApplicationResponse.class)
    @GetMapping("/get-system-propertyValue")
	public ApplicationResponse getPlatformValues() {
		
    	return getApplicationResponse( logoService.getpropertysValue());
	}

    /**
     * Gets the all company list.
     *
     * @return the all company list
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value="Company list",notes = "Get all companies list",response=ApplicationResponse.class)
    @GetMapping("/get-insuren-company")
	public ApplicationResponse getAllCompanyList() throws ApplicationException {
    	
    	List<CompanyDto> list = new ArrayList<CompanyDto>();
    	list = logoService.getAllCompanyList();
    	
    	return getApplicationResponse(list);
	}

}
