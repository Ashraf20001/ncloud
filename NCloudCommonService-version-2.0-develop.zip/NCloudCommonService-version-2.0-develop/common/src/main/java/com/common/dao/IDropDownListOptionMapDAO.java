package com.common.dao;

import java.util.List;

import com.common.transfer.object.entity.DropDownListOptionMapping;

/**
 * The Interface IDropDownListOptionMapDAO.
 */
public interface IDropDownListOptionMapDAO {

	/**
	 * Gets the drop down options list by drop down id.
	 *
	 * @param dropdownId the dropdown id
	 * @param parentOptionId the parent option id
	 * @return the drop down options list by drop down id
	 */
	List<DropDownListOptionMapping> getDropDownOptionsListByDropDownId(Integer dropdownId, Integer parentOptionId);
	
	/**
	 * Gets the drop down option name list by drop drown list id.
	 *
	 * @param dropdownlistId the dropdownlist id
	 * @return the drop down option name list by drop drown list id
	 */
	List<String> getDropDownOptionNameListByDropDrownListId(Integer dropdownlistId);
}
