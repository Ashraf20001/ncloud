package com.common.approvalLimit;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.common.constants.core.ApprovalLimitDropdown;
import com.common.constants.core.RecoveryStatusConstant;

public class ApprovalStatusMap {
	public static final Map<String, List<ApprovalLimitDropdown>> approvalMap=new LinkedHashMap();
	
	static {
		approvalMap.put(RecoveryStatusConstant.TOTALLOSS_ACCEPTED, 
		         new ArrayList<ApprovalLimitDropdown>(Arrays.asList(
		        		 							ApprovalLimitDropdown.TotalLossEstimatedAmount)));
		
		approvalMap.put(RecoveryStatusConstant.SURVEYOR_ASSIGNED, 
				new ArrayList<ApprovalLimitDropdown>(Arrays.asList(
													ApprovalLimitDropdown.TotalLossEstimatedAmount)));
		
		approvalMap.put(RecoveryStatusConstant.NOTIFICATION_ACCEPTED, 
				new ArrayList<ApprovalLimitDropdown>(Arrays.asList(
													ApprovalLimitDropdown.SumInsured,
						                            ApprovalLimitDropdown.ReserveAmount)));
	
		approvalMap.put(RecoveryStatusConstant.LIABLITY_REVIEW, 
				new ArrayList<ApprovalLimitDropdown>(Arrays.asList(
													ApprovalLimitDropdown.SurveyAmount,
						                            ApprovalLimitDropdown.ClaimAmount)));
		
		
		
	}

}
