package com.common.dao;

import java.util.List;

import com.common.transfer.object.entity.DropDownList;

/**
 * The Interface IDropDownListDAO.
 */
public interface IDropDownListDAO {

	/**
	 * Gets the drop down list by id.
	 *
	 * @param dropDownListId the drop down list id
	 * @return the drop down list by id
	 */
	DropDownList getDropDownListById(Integer dropDownListId);
	
	/**
	 * Gets the custom option list by drop down list id.
	 *
	 * @param referencedTableName the referenced table name
	 * @param referenceColumnId the reference column id
	 * @param displayColumnName the display column name
	 * @return the custom option list by drop down list id
	 */
	List<?> getCustomOptionListByDropDownListId(Class<?> referencedTableName, String referenceColumnId, String displayColumnName);
	
	/**
	 * Gets the drop down list by dropdown name.
	 *
	 * @param dropdownName the dropdown name
	 * @return the drop down list by dropdown name
	 */
	DropDownList getDropDownListByDropdownName(String dropdownName);
}
