package com.common.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.common.aop.annotation.Auditable;
import com.common.config.base.controller.BaseController;
import com.common.exception.core.ApplicationException;
import com.common.service.IApprovalLimitService;
import com.common.transfer.object.core.ApplicationResponse;
import com.common.transfer.object.dto.ApprovalLevelStateTransferDto;
import com.common.transfer.object.dto.ApprovalLimitDto;
import com.common.transfer.object.dto.ApprovalRoleLimitRequest;
import com.common.transfer.object.entity.Role;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class ApprovalLimitController.
 */
@RestController
@RequestMapping("/Approvallimit")
@Auditable
public class ApprovalLimitController extends BaseController {

	/** The approval service. */
	@Autowired
	IApprovalLimitService approvalService;
	
	/**
	 * Gets the field.
	 *
	 * @return the field
	 */
	@ApiOperation(value="Approval limit fields",notes="Get approval limit fields list",response = List.class)
	@GetMapping("/field-list")
	public List<String> getField(){
		return approvalService.getDropdownList();
	}
	
	/**
	 * Gets the role list.
	 *
	 * @return the role list
	 * @throws ApplicationException the application exception
	 * @throws ClassNotFoundException the class not found exception
	 */
	@ApiOperation(value="Approval limit roles",notes="Get approval limit roles list",response = List.class)
	@GetMapping("/role-list")
	public List<Role> getRoleList() throws ApplicationException, ClassNotFoundException{
		return approvalService.getUserRoleList();
	}
	
	/**
	 * Gets the company list.
	 *
	 * @param action the action
	 * @return the company list
	 * @throws ApplicationException the application exception
	 * @throws ClassNotFoundException the class not found exception
	 */
	@ApiOperation(value="Companies data",notes = "Get company map for approval limit",response = Map.class)
	@GetMapping("/company-list")
	public Map<Integer,String> getCompanyList(@ApiParam(value="Action") @RequestParam(name = "action") String action) throws ApplicationException, ClassNotFoundException{
		return approvalService.getCompanies(action);
	}
	
	

	/**
	 * Save or update.
	 *
	 * @param approvallimit the approvallimit
	 * @return the integer
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Approval limit changes",notes = "Create or update the approval limit",response = Integer.class)
	@PostMapping("/saveOrUpdate")
	public Integer saveOrUpdate(@ApiParam(value="Approval limit dto payload",required = true) @RequestBody ApprovalLimitDto approvallimit) throws ApplicationException{
		return approvalService.saveOrUpdateUserApproval(approvallimit);
	}
	
   
	/**
	 * Gets the approval list.
	 *
	 * @param min the min
	 * @param max the max
	 * @return the approval list
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Approval limit list",notes="Get approval limit details",response = List.class)
	@GetMapping("/get-approval-list")
	public List<ApprovalLimitDto> getApprovalList(@ApiParam(value = "Skip data count",required = true) @RequestParam(name = "min") Integer min,
			@ApiParam(value = "Limit data count",required = true) @RequestParam(name = "max")Integer max) throws ApplicationException{
		return approvalService.getApprovalLimitDtoList(min,max);
	}
	
	/**
	 * Gets the approval count.
	 *
	 * @return the approval count
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Approval limit count",notes="Get approval limit details count",response = Long.class)
	@GetMapping("/get-approval-count")
	public Long getApprovalCount() throws ApplicationException{
		return approvalService.getApprovalLimitCount();
	}
	
	/**
	 * Delete approval limit.
	 *
	 * @param approvalLimitIdentity the approval limit identity
	 * @return the integer
	 * @throws ApplicationException the application exception
	 * @throws ClassNotFoundException the class not found exception
	 */
	@ApiOperation(value = "Approval limit delete",notes="Delete approval limit based on approval limit identity",response = Integer.class)
	@GetMapping("/delete-list")
	public Integer deleteApprovalLimit(@ApiParam(value="Approval limit identity",required = true) @RequestParam(value="approvalLimitId")String approvalLimitIdentity ) throws ApplicationException, ClassNotFoundException {
		return approvalService.deleteUserApproval(approvalLimitIdentity);
	}
	
	/**
	 * Gets the approval list for edit.
	 *
	 * @param approvalLimitIdentity the approval limit identity
	 * @return the approval list for edit
	 * @throws ClassNotFoundException the class not found exception
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Approval limit edit data",notes="Get approval limit data for modification using approval limit identity",response = ApprovalLimitDto.class)
	@GetMapping("/edit-list")
	public ApprovalLimitDto getApprovalListForEdit( @ApiParam(value="Approval limit identity",required = true) @RequestParam(value="approvalLimitId")String approvalLimitIdentity ) throws ClassNotFoundException, ApplicationException{
		return approvalService.getApprovalLimitById( approvalLimitIdentity);

	}
	
	/**
	 * GetApprovalLimitListExcel.
	 *
	 * @return the approval limit list excel
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Download approval limit data",notes="Download the list of approval limit as excel",response = ResponseEntity.class)
	@GetMapping("/download-excel")
	public ResponseEntity<InputStreamResource> getApprovalLimitListExcel() throws ApplicationException {
		return approvalService.getApprovalLimitListExcel();
	}
	
	 /**
 	 * Gets the currency type list.
 	 *
 	 * @return the currency type list
 	 * @throws ApplicationException the application exception
 	 */
	@ApiOperation(value = "Currency types",notes="Get currency type list",response = ApplicationResponse.class)
 	@GetMapping("/currency-types")
	    public ApplicationResponse getCurrencyTypeList() throws ApplicationException {
	    	return getApplicationResponse(approvalService.getCurrencyTypeList());
	    }
	 
	 /**
 	 * Gets the approval level for knock check.
 	 *
 	 * @param fromCompany the from company
 	 * @param toCompany the to company
 	 * @param currencyValue the currency value
 	 * @return the approval level for knock check
 	 */
	@ApiOperation(value = "Approval level data",notes="Get approval level data for knockcheck",response = ApprovalLevelStateTransferDto.class)
 	@GetMapping("/get-approval-level-for-knockcheck")
	 public ApprovalLevelStateTransferDto getApprovalLevelForKnockCheck(
			@ApiParam(value="fromCompany",required = true) @RequestParam("fromCompany") Integer fromCompany, 
			@ApiParam(value="toCompany",required = true) @RequestParam("toCompany") Integer toCompany,
			@ApiParam(value="Currency value data",required = true) @RequestParam("currencyValue") String currencyValue) {
		 return approvalService.getApprovalLevelDtoForKnockCheck(fromCompany,toCompany,currencyValue);
	 }
	 
	 /**
 	 * Gets the approval level for role limit check.
 	 *
 	 * @param fieldId the field id
 	 * @param companyId the company id
 	 * @param currencyValue the currency value
 	 * @return the approval level for role limit check
 	 */
	@ApiOperation(value = "Approval level data",notes="Get approval level data for checking the limit of field to particular role id",response = List.class)
 	@GetMapping("/get-approval-level-for-roleLimitCheck")
	 public List<ApprovalLevelStateTransferDto> getApprovalLevelForRoleLimitCheck(@ApiParam(value="field id",required = true) @RequestParam("fieldId") Integer fieldId, 
			 @ApiParam(value="company id",required = true) @RequestParam("companyId") Integer companyId, 
			 @ApiParam(value="currency value",required = true) @RequestParam("currencyValue") Double currencyValue) {
		 return approvalService.getApprovalLevelFromRoleListLimitCheck(fieldId,companyId,currencyValue);
	 }
	 
	 /**
 	 * Gets the approval level for role limit.
 	 *
 	 * @param approvalRoleLimitRequest the approval role limit request
 	 * @return the approval level for role limit
 	 */
	@ApiOperation(value = "Approval level data",notes="Get approval level data for partcular role limit",response = List.class)
 	@PostMapping("/get-approval-level-for-roleLimit")
	 public List<ApprovalLevelStateTransferDto> getApprovalLevelForRoleLimit(
			 @ApiParam(value="ApprovalRoleLimitRequest data payload",required = true)   @RequestBody ApprovalRoleLimitRequest approvalRoleLimitRequest ){
		 return approvalService.getApprovalLevelForRoleLimit(approvalRoleLimitRequest);
	 }

	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {
	}
}
