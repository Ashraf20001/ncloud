package com.common.controller.dp.fieldconfiguration;


import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.common.dp.fieldconfiguration.service.IDpFieldConfigurationService;
import com.common.exception.core.ApplicationException;
import com.common.transfer.object.dto.DpFieldConfiguratorDto;
import com.common.transfer.object.dto.SectionDetailsDto;
import com.common.transfer.object.dto.SectionNameDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;


@RestController
@RequestMapping("/dp-page-config")
@RequiredArgsConstructor
public class DpFieldConfigurationController {

	/**
	 * IDpFieldConfigurationService
	 */
	private final IDpFieldConfigurationService iDpFieldConfigurationService;
	
	/**
	 * @param dpFieldConfiguratorDto
	 * @return
	 * @throws ApplicationException
	 */
	 @ApiOperation(value = "Add or update fields configuration", 
             notes = "Adds new fields or modifies existing field configurations",
             response = Boolean.class)
	@PostMapping("/save-update-fields")
	public Boolean addOrModifyFields(
			@ApiParam(value = "Field Configuration Data", required = true)  
			@RequestBody DpFieldConfiguratorDto dpFieldConfiguratorDto)
			throws ApplicationException {
		return iDpFieldConfigurationService.fieldsConfiguration(dpFieldConfiguratorDto);
	}
	
	/**
	 * @param identity
	 * @return
	 * @throws ApplicationException
	 */
	 @ApiOperation(value = "Delete dropdown option", 
             notes = "Deletes a dropdown option based on the provided identity",
             response = Boolean.class)
	@PostMapping("/delete-dropdown-option")
	public Boolean deleteDropDownOption(
			@ApiParam(value = "Dropdown Option Identity", required = true)  @RequestParam (name="identity") String identity) throws ApplicationException {
		return iDpFieldConfigurationService.deleteDropDownOption(identity);
		
	}
	
	/**
	 * @param pageIdentity
	 * @param parentSectionId
	 * @return
	 * @throws ApplicationException
	 */
	 @ApiOperation(value = "Get section names", 
             notes = "Retrieves section names based on page identity and parent section ID",
             response = List.class)
	@GetMapping("/get-section-names")
	public List<SectionNameDto> getSectionNames(
			@ApiParam(value = "Page Identity", required = true)  @RequestParam(name = "pageIdentity") String pageIdentity,
			@ApiParam(value = "Parent Section ID", required = true) @RequestParam(name = "parentSectionId") Integer parentSectionId) throws ApplicationException {
		return iDpFieldConfigurationService.getSectionNames(pageIdentity, parentSectionId);

	}
	
	/**
	 * @param sectionDetailsDto
	 * @return
	 * @throws ApplicationException
	 */
	 @ApiOperation(value = "Add section name", 
             notes = "Adds a new section name",
             response = Boolean.class)
	@PostMapping("/add-section-name")
	public Boolean addSectionName(
			@ApiParam(value = "Section Details", required = true) 
			@RequestBody SectionDetailsDto sectionDetailsDto) throws ApplicationException {
		return iDpFieldConfigurationService.addSectionName(sectionDetailsDto);

	}
	
	/**
	 * @param sectionDetailsDto
	 * @return
	 * @throws ApplicationException
	 */
	 @ApiOperation(value = "Update section names", 
             notes = "Updates existing section names",
             response = List.class)
	@PostMapping("/update-section-name")
	public List<SectionNameDto> updateSectionName(
			 @ApiParam(value = "Section Name Details", required = true) 
			@RequestBody List<SectionNameDto> sectionDetailsDto) throws ApplicationException {
		return iDpFieldConfigurationService.updateSectionName(sectionDetailsDto);
		
	}
	
	/**
	 * @param identity
	 * @return
	 * @throws ApplicationException
	 */
	 @ApiOperation(value = "Delete section name", 
             notes = "Deletes a section name based on the provided identity",
             response = Boolean.class)
	@PostMapping("/delete-section-name")
	public Boolean deleteSectionName(
			 @ApiParam(value = "Section Name Identity", required = true) 
			@RequestParam(name="identity") String identity) throws ApplicationException {
		return iDpFieldConfigurationService.deleteSectionName(identity);
		
	}
}

