package com.common.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.common.exception.core.ApplicationException;
import com.common.service.IUserCompanyMappingService;
import com.common.transfer.object.dto.UserCompanyMappingDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

/**
 * The Class UserCompanyMappingController.
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/company")
public class UserCompanyMappingController {
    
	/** UserCompanyMappingService. */
    private final IUserCompanyMappingService userCompanyMappingService;
    
    /**
     * Gets the company by user id.
     *
     * @param userId the user id
     * @return the company by user id
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Get company by user Identity", 
            notes = "Retrieves the company associated with the given user Identity",
            response = UserCompanyMappingDto.class)

    @GetMapping("/get-company")
    public UserCompanyMappingDto getCompanyByUserId(
    		 @ApiParam(value = "User Identity", required = true) @RequestParam("user_id") String userId) throws ApplicationException {
        return userCompanyMappingService.getCompanyByUserId(userId);
    }
    
    /**
     * Gets the user list by company id.
     *
     * @param companyId the company id
     * @return the user list by company id
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Get users by company Identity",
            notes = "Retrieves a list of users associated with the given company Identity",
            response = UserCompanyMappingDto.class)
    @GetMapping("/get-users")
    public List<UserCompanyMappingDto> getUserListByCompanyId(
    		@ApiParam(value = "Company Identity", required = true)  @RequestParam("company_id") String companyId) throws ApplicationException {
        return userCompanyMappingService.getUserListByCompany(companyId);
    }
    
    /**
     * Gets the user list by company id.
     *
     * @param companyId the company id
     * @return the user list by company id
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Get users by company ID",
            notes = "Retrieves a list of users associated with the given company ID",
            response = UserCompanyMappingDto.class, responseContainer = "List")
    @GetMapping("/get-users-by-companyId")
    public List<UserCompanyMappingDto> getUserListByCompanyId(
    		@ApiParam(value = "Company ID", required = true)  @RequestParam("company_id") Integer companyId) throws ApplicationException {
    	return userCompanyMappingService.getUserListByCompanyId(companyId);
    }
    
    /**
     * Gets the company by user.
     *
     * @param userId the user id
     * @return the company by user
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Get company by user ID",
            notes = "Retrieves the company associated with the given user ID",
            response = UserCompanyMappingDto.class)
    @GetMapping("/get-company-by-user")
    public UserCompanyMappingDto getCompanyByUser(@ApiParam(value = "User ID", required = true)  @RequestParam("user_id") Integer userId) throws ApplicationException {
        return userCompanyMappingService.getCompanyByUser(userId);
    }
    
    /**
     * Gets the users email id list for email.
     *
     * @param menuName the menu name
     * @param pageName the page name
     * @param sectionName the section name
     * @param companyName the company name
     * @return the users email id list for email
     */
    @ApiOperation(value = "Get user email IDs for notifications",
            notes = "Retrieves a list of email IDs for notifications based on menu, page, section, and company name",
            response = List.class)
    @GetMapping("/get-user-company-emailIds")
    public List<String> getUsersEmailIdListForEmail(
    		@ApiParam(value = "Menu Name", required = true) @RequestParam("menuName")String menuName,
    		@ApiParam(value = "Page Name", required = true) @RequestParam("pageName")String pageName,
    		@ApiParam(value = "Section Name", required = true) @RequestParam("sectionName")String sectionName,
    		@ApiParam(value = "Company Name", required = true) @RequestParam("companyName")String companyName){
    	return userCompanyMappingService.getUserEmailIdListForEmail(menuName, pageName, sectionName, companyName);
    }
    
    /**
     * Gets the user id list for notification.
     *
     * @param menuName the menu name
     * @param pageName the page name
     * @param sectionName the section name
     * @param companyName the company name
     * @return the user id list for notification
     */
    @ApiOperation(value = "Get user Identities for notifications",
            notes = "Retrieves a list of user Identities for notifications based on menu, page, section, and company name",
            response = List.class)
      @GetMapping("/get-user-company-userListForNotification")
    public List<String> getUserIdListForNotification(
    		@ApiParam(value = "Menu Name", required = true) @RequestParam("menuName")String menuName,
    		@ApiParam(value = "Page Name", required = true) @RequestParam("pageName")String pageName,
    		@ApiParam(value = "Section Name", required = true) @RequestParam("sectionName")String sectionName,
    		@ApiParam(value = "Company Name", required = true) @RequestParam("companyName")String companyName){
    	return userCompanyMappingService.getUserListForNotification(menuName,pageName,sectionName,companyName);
    }
    
}