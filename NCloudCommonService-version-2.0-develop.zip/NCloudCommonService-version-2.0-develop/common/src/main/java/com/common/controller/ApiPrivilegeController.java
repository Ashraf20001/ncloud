package com.common.controller;

import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.common.service.IApiPrivilegeService;

import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;


/**
 * The Class ApiPrivilegeController.
 */
@RestController
@RequiredArgsConstructor
public class ApiPrivilegeController {
	
	/** The api privilege service. */
	private final IApiPrivilegeService apiPrivilegeService;
	
	/**
	 * Gets the all privilages.
	 *
	 * @return the all privilages
	 */
	@ApiOperation(value = "Privilege details",notes = "Get all privilege data",response=Map.class)
	@GetMapping("/api-privilege")
	public Map<Integer,List<String>> getAllPrivilages() {
		Map<Integer,List<String>> allPrivilageMaps=null;
	     allPrivilageMaps=apiPrivilegeService.getAllPrivilages();
		return allPrivilageMaps;
	}
	
	/**
	 * All api privilege.
	 *
	 * @return the map
	 */
	@ApiOperation(value = "Privilege details",notes = "Get all api privilege data",response=Map.class)
	@GetMapping("/allApiPrivilege")
	public Map<Integer, String>  allApiPrivilege() {
		Map<Integer, String> allPrivilageMaps=null;
	     allPrivilageMaps=apiPrivilegeService.allApiPrivilege();
		return allPrivilageMaps;
		
	}
	

}
