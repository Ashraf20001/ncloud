package com.common.dao;


import java.util.List;


import com.common.transfer.object.entity.BulkImportHistory;
import com.common.transfer.object.entity.FileStorageDetails;
import com.common.transfer.object.entity.Platform;
import com.common.transfer.object.reportloss.entity.Company;

/**
 * The Interface IBulkUploadDao.
 */
public interface IBulkUploadDao {

	/**
	 * Gets the plate form data.
	 *
	 * @param platformId the platform id
	 * @return the plate form data
	 */
	Platform getPlateFormData(Integer platformId);

	/**
	 * Gets the bulk import histrory data.
	 *
	 * @param plateFormID the plate form ID
	 * @param companyId the company id
	 * @param uploadtypeId the uploadtype id
	 * @return the bulk import histrory data
	 */
	List<BulkImportHistory> getBulkImportHistroryData(Platform plateFormID, Integer companyId,Integer uploadtypeId);

	/**
	 * Gets the bulk import histrory based on company id.
	 *
	 * @param plateFordData the plate ford data
	 * @param companyId the company id
	 * @param uploadtypeId the uploadtype id
	 * @return the bulk import histrory based on company id
	 */
	List<BulkImportHistory> getBulkImportHistroryBasedOnCompanyId(Platform plateFordData, Integer companyId,Integer uploadtypeId);

	/**
	 * Gets the company details.
	 *
	 * @param companyId the company id
	 * @return the company details
	 */
	Company getCompanyDetails(Integer companyId);

	/**
	 * Gets the storage data based on id.
	 *
	 * @param uploadId the upload id
	 * @return the storage data based on id
	 */
	FileStorageDetails getstorageDataBasedOnId(Integer uploadId);

}
