package com.common.config;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.common.constants.core.ApplicationConstants;
import com.common.constants.core.SessionScopeClass;
import com.common.constants.enums.DataFilterEnum;
import com.common.exception.core.ApplicationException;
import com.common.exception.core.codes.ErrorCodes;
import com.common.security.jwt.JwtUtils;
import com.common.service.IApiPrivilegeService;
import com.common.transfer.object.dto.PlatformDetailsDto;
import com.common.transfer.object.dto.RoleListDto;
import com.common.transfer.object.dto.UserInfo;
import com.common.transfer.object.entity.UserType;
import com.common.utils.RestCallUtil;
import com.common.utils.core.ApplicationUtils;
import com.common.utils.core.LoggedInUserContextHolder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import io.jsonwebtoken.Claims;
import lombok.RequiredArgsConstructor;

/**
 * The Class HttpInterceptor.
 */
@Component
@RequiredArgsConstructor
public class HttpInterceptor implements HandlerInterceptor {

	/**
	 * JwtUtils
	 */
	private final JwtUtils jwtUtils;

	/** The logged in user context holder. */
	private final LoggedInUserContextHolder loggedInUserContextHolder;

	/** The resttemplte. */
	private final RestCallUtil resttemplte;
	
	/** The api privilege service. */
	private final IApiPrivilegeService apiPrivilegeService;
	
	/** The session scope class. */
	private final SessionScopeClass sessionScopeClass;
	
	/** The access previlage. */
	@Value("${access-previlage}")
	private String accessPrevilage;
	
	/** The Constant logger. */
	private static final Logger logger= LoggerFactory.getLogger(HttpInterceptor.class);

	/**
	 * @param request
	 * @param response
	 * @param handler
	 */
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

		try {
			String jwtToken = parseJwt(request);
			if (jwtToken != null && jwtUtils.validateJwtToken(jwtToken)) {
				Claims userDetailsMap = jwtUtils.getUserDetailsFromJwtToken(jwtToken);
				UserInfo userInfo = buildUserInfo(userDetailsMap);
				loggedInUserContextHolder.setLoggedInUser(userInfo);
				setBasePredicateVariableValue(userInfo);
			}
			
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		if (accessPrevilage.equalsIgnoreCase("true")) {
			checkIsRoleHasPrivilege(request);
		}
		return HandlerInterceptor.super.preHandle(request, response, handler);
	}

	/**
	 * @param userDetailsMap
	 * @return
	 */
	private UserInfo buildUserInfo(Claims userDetailsMap) {
		UserInfo userInfo = new UserInfo();
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.ID))) {
			userInfo.setId(Integer.parseInt(userDetailsMap.get(ApplicationConstants.ID).toString()));
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.USER_NAME))) {
			userInfo.setUsername(userDetailsMap.get(ApplicationConstants.USER_NAME).toString());
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.EMAIL))) {
			userInfo.setEmail(userDetailsMap.get(ApplicationConstants.EMAIL).toString());
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.PLATFORM_IDENTITY))) {
			userInfo.setPlatformIdentity(userDetailsMap.get(ApplicationConstants.PLATFORM_IDENTITY).toString());
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.USER_TYPE))) {
			ModelMapper modelMapper = new ModelMapper();
			UserType userType = modelMapper.map(userDetailsMap.get(ApplicationConstants.USER_TYPE), UserType.class);
			userInfo.setUserTypeId(userType);
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.IDENTITY))) {
			userInfo.setIdentity(userDetailsMap.get(ApplicationConstants.IDENTITY).toString());
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.ASSOCIATION_ID))) {
			userInfo.setAssociationId(
					Integer.parseInt(userDetailsMap.get(ApplicationConstants.ASSOCIATION_ID).toString()));
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.PLATFORM_DETAILS))) {
			ModelMapper modelMapper = new ModelMapper();
			PlatformDetailsDto platformDetails = modelMapper
					.map(userDetailsMap.get(ApplicationConstants.PLATFORM_DETAILS), PlatformDetailsDto.class);
			userInfo.setPlatformDetailsDto(platformDetails);
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.COMPANY_ID))) {
			userInfo.setCompanyId(Integer.parseInt(userDetailsMap.get(ApplicationConstants.COMPANY_ID).toString()));
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.ALLOCATION_USER_TYPE))) {
			userInfo.setAllocationUserType(
					Integer.parseInt(userDetailsMap.get(ApplicationConstants.ALLOCATION_USER_TYPE).toString()));
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.COMPANY_NAME))) {
			userInfo.setCompanyName(userDetailsMap.get(ApplicationConstants.COMPANY_NAME).toString());
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.ROLES))) {
			String object = (String) userDetailsMap.get(ApplicationConstants.ROLES);
			String string = "{" + '"' + "userRoleList" + '"' + ":" + object + "}";
			RoleListDto readValue = null;
			try {
				readValue = new com.fasterxml.jackson.databind.ObjectMapper().readValue(string, RoleListDto.class);
			} catch (JsonMappingException e) {
				logger.error(e.getMessage());
			} catch (JsonProcessingException e) {
				logger.error(e.getMessage());
			}
			if (ApplicationUtils.isValidObject(readValue)) {
				userInfo.setRoles(readValue.getUserRoleList());
			}
		}
		return userInfo;
	}

	/**
	 * @param request
	 * @return
	 */
	private String parseJwt(HttpServletRequest request) {
		String headerAuth = request.getHeader(ApplicationConstants.AUTHORIZATION);
		if (StringUtils.hasText(headerAuth) && headerAuth.startsWith(ApplicationConstants.BEARER)) {
			return headerAuth.substring(7, headerAuth.length());
		}
		return null;
	}

	/**
	 * Post handle.
	 *
	 * @param request the request
	 * @param response the response
	 * @param handler the handler
	 * @param modelAndView the model and view
	 * @throws Exception the exception
	 */
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			@Nullable ModelAndView modelAndView) throws Exception {
		apiToClearCahe(request);

	}

	/**
	 * Api to clear cahe.
	 *
	 * @param request the request
	 */
	private void apiToClearCahe(HttpServletRequest request) {
		if (ApplicationConstants.API_TO_CLEAR_CAHCE.contains(request.getRequestURL())) {
			resttemplte.clearCache();
		}

	}
	
	/**
	 * Check is role has privilege.
	 *
	 * @param request the request
	 * @throws ApplicationException the application exception
	 */
	private void checkIsRoleHasPrivilege(HttpServletRequest request) throws ApplicationException {
		boolean flag = false;
		Map<Integer, String> roleApiMap = RoleCache.getRoleApiMap();
		if (!ApplicationUtils.isValidateObject(roleApiMap)) {
			roleApiMap = apiPrivilegeService.allApiPrivilege();
			RoleCache.setRoleApiMap(roleApiMap);
		}
		
		if(!ApplicationUtils.isValidObject(loggedInUserContextHolder.getLoggedInUser())) {
			return;
		}

		if (ApplicationUtils.isValidList(loggedInUserContextHolder.getLoggedInUser().getRoles())) {
			List<Integer> roleIds = loggedInUserContextHolder.getLoggedInUser().getRoles().stream()
					.map(s -> s.getRoleId()).toList();
			for (Integer roleid : roleIds) {
				if (!flag) {
					flag = checkApiIsValid(request, roleid);
				}

			}
			if (!flag) {

				throw new ApplicationException(ErrorCodes.UN_AUTHORIZED);

			}
		}
		
	}
	
	/**
	 * Check api is valid.
	 *
	 * @param request the request
	 * @param roleid the roleid
	 * @return true, if successful
	 * @throws ApplicationException the application exception
	 */
	private boolean checkApiIsValid(HttpServletRequest request, Integer roleid) throws ApplicationException {
		boolean flag = true;
		String api = request.getRequestURI();
		String apiList = RoleCache.getRoleApiMap().get(roleid);

		if (ApplicationUtils.isValidString(apiList)) {
			if (!ApplicationConstants.CLEAR_CACHE_URLS.contains(api)) {
				flag = Arrays.asList(apiList.split(",")).stream().anyMatch(api::contains);
			}
		}
		return flag;

	}
	
	/**
	 * Sets the base predicate variable value.
	 *
	 * @param userInfo the new base predicate variable value
	 */
	private void setBasePredicateVariableValue(UserInfo userInfo) {
		String userType = DataFilterEnum.getUserType(userInfo.getUserTypeId().getUserTypeName());
		if(ApplicationUtils.isValidString(userType)   &&  userType.equalsIgnoreCase(ApplicationConstants.INSURANCE_COMPANY_CAP)) {
			sessionScopeClass.setPredicateMap(userType,userInfo.getCompanyId());
		}else {
			sessionScopeClass.removePredicate();
		}
	}
}
