package com.common.dao;

import java.util.List;

import com.common.transfer.object.entity.AllocationUserType;



/**
 * The Interface IAllocationPoolDao.
 */
public interface IAllocationPoolDao {
		
	/**
	 * Gets the allocation user type details.
	 *
	 * @return the allocation user type details
	 */
	public List<AllocationUserType> getAllocationUserTypeDetails();
}
