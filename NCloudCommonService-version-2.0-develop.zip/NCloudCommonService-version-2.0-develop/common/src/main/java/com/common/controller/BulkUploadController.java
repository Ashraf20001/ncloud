package com.common.controller;

import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.common.config.base.controller.BaseController;
import com.common.exception.core.ApplicationException;
import com.common.service.IBulkUploadService;
import com.common.transfer.object.core.ApplicationResponse;
import com.common.transfer.object.dto.BulkImportHistoryDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

/**
 * The Class BulkUploadController.
 */
@RestController
@RequiredArgsConstructor
public class BulkUploadController extends BaseController{

	/** The bulk service. */
	private final IBulkUploadService bulkService;
	
	/**
	 * Gets the bulk import data.
	 *
	 * @param isBulkUploadPage the is bulk upload page
	 * @return the bulk import data
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Bulk import",notes = "Get bulk import details",response=ApplicationResponse.class)
	@GetMapping("/get-bulkimport_histrory")
	public ApplicationResponse getBulkImportData(@ApiParam(value="is bulk upload or revoke",required = true)  @RequestParam(name = "isBulkUploadPage") boolean isBulkUploadPage)
			throws ApplicationException {

		List<BulkImportHistoryDto> data = bulkService.getBulkImportHistroryData(isBulkUploadPage);

		return getApplicationResponse(data);
	}
	
	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {
		
	}

}

