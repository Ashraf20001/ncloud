package com.common.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.common.exception.core.ApplicationException;
import com.common.service.IApplicationHeaderService;
import com.common.transfer.object.dto.AppHeaderDto;

import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;

/**
 * The Class ApplicationHeaderController.
 */
@RestController
@RequestMapping("/app-header")
@RequiredArgsConstructor
public class ApplicationHeaderController {

	/** ApplicationHeaderService. */
	private final IApplicationHeaderService applicationHeaderService;
	
	
	/**
	 * Gets the application header.
	 *
	 * @return the application header
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Menu details",notes="Get all the menu details for specific platform",response=AppHeaderDto.class)
	@GetMapping("/platform-menu-details")
	public AppHeaderDto getApplicationHeader() throws ApplicationException{
		 AppHeaderDto appHeaderDto =  applicationHeaderService.getApplicationHeaderDetails();
		 return appHeaderDto;
	}
	
}
