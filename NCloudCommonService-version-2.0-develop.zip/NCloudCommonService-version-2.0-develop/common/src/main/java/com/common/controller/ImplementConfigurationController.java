package com.common.controller;


import java.util.HashMap;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.common.config.base.controller.BaseController;
import com.common.exception.core.ApplicationException;
import com.common.service.IImplementConfigurationService;
import com.common.service.impl.UserCompanyMappingServiceImpl;
import com.common.transfer.object.core.ApplicationResponse;
import com.common.transfer.object.dto.CompanyDto;
import com.common.transfer.object.dto.ImplementConfigurationVo;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

/**
 * The Class ImplementConfigurationController.
 */
@RestController
@RequiredArgsConstructor
public class ImplementConfigurationController extends BaseController {

	/** The implementation service. */
	private final IImplementConfigurationService implementationService;
	
	/** The company service. */
	private final UserCompanyMappingServiceImpl companyService;

	/**
	 * Gets the insurance user type.
	 *
	 * @return the insurance user type
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Get insurance user types", notes = "Retrieves a list of insurance user types", response = ApplicationResponse.class)
	@GetMapping("/get-insurance-user-data")
	public ApplicationResponse getInsuranceUserType() throws ApplicationException {

		List<String> data = implementationService.getInsuranceUserTypeList();
		return getApplicationResponse(data);

	}

	/**
	 * Save insurance user type.
	 *
	 * @param value the value
	 * @return the application response
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Save insurance user type", notes = "Saves an insurance user type", response = ApplicationResponse.class)
	@PostMapping("/save-allocation-type")
	public ApplicationResponse saveInsuranceUserType(@ApiParam(value = "Insurance user type value", required = true) @RequestBody String value) throws ApplicationException {

		String responce = implementationService.saveInsuranceUserType(value);

		return getApplicationResponse(responce);
	}

	/**
	 * Save implement configuration.
	 *
	 * @param data the data
	 * @return the application response
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Save implementation configuration", notes = "Saves a list of implementation configurations", response = ApplicationResponse.class)
	@PostMapping("/save-implement-configuration")
	public ApplicationResponse saveImplementConfiguration(
			@ApiParam(value = "Implementation configuration data", required = true) @RequestBody List<ImplementConfigurationVo> data)
			throws ApplicationException {

		String responce = implementationService.saveImplementConfiguration(data);

		return getApplicationResponse(responce);
	}

	/**
	 * Gets the implementation configuration.
	 *
	 * @param data the data
	 * @return the implementation configuration
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Get implementation configuration data", notes = "Retrieves configuration data for implementation", response = ApplicationResponse.class)
	@PostMapping("/get-implement-configure-data")
	public ApplicationResponse getImplementationConfiguration(
			@ApiParam(value = "Implementation configuration request data", required = true) @RequestBody List<ImplementConfigurationVo> data)
			throws ApplicationException {

		List<ImplementConfigurationVo> responce = implementationService.getConfigurationData(data);
		return getApplicationResponse(responce);
	}
	
	
    /**
     * Gets the company id.
     *
     * @param companyId the company id
     * @return the company id
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Get company object", notes = "Retrieves company details based on company ID", response = CompanyDto.class)
	@GetMapping("/get-company-object")
	public CompanyDto getCompanyId(
			@ApiParam(value = "Company ID", required = true) @RequestParam(name = "companyId") Integer companyId) throws ApplicationException {
		return companyService.getCompanyDtoByCompanyId(companyId);
	}

	
    /**
     * Gets the system property value.
     *
     * @return the system property value
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Get system property values", notes = "Retrieves system property data", response = HashMap.class)
	@GetMapping("/get-systemproperty-value")
	public HashMap<String, String> getSystemPropertyValue() throws ApplicationException {

		return implementationService.getSystemPropertyData();
	}

	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {

	}

}

