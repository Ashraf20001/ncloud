package com.common.controller;

import java.util.List;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.common.service.IPageService;
import com.common.transfer.object.dto.RolePageMappingDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

/**
 * The Class PageController.
 */
@RestController
@RequiredArgsConstructor
public class PageController {
	
	/** The page service. */
	private final IPageService pageService;

	/**
	 * Gets the role page map by page id and role id list.
	 *
	 * @param roleIdList the role id list
	 * @param pageId the page id
	 * @return the role page map by page id and role id list
	 */
	@ApiOperation(value = "Get role-page mapping by page ID and role ID list", 
            notes = "Retrieves the role-page mapping details for the given page ID and list of role IDs", 
            response = RolePageMappingDto.class)
	@PostMapping("/getRolePageMapByPageIdAndRoleIdList")
	public RolePageMappingDto getRolePageMapByPageIdAndRoleIdList(
			@ApiParam(value = "List of role IDs", required = true) @RequestBody List<Integer> roleIdList,
			@ApiParam(value = "Page ID", required = true) @RequestParam String pageId) {
		RolePageMappingDto rolePageMappingDto = pageService.getRolePageMapByPageIdAndRoleIdList(roleIdList, pageId);
		return rolePageMappingDto;
	}

}
