package com.common.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.common.exception.core.ApplicationException;
import com.common.service.IMetaDataService;
import com.common.transfer.object.dto.MetaDataViewDto;
import com.common.transfer.object.dto.RlMetaDataConvertDto;
import com.common.transfer.object.entity.MetaData;
import com.common.transfer.object.reportloss.dto.ReportLossDto;
import com.common.transfer.object.vo.dto.FieldGroup;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

/**
 * The Class MetaDataController.
 */
@RestController
@RequiredArgsConstructor
public class MetaDataController {

	/** The meta data service. */
	private final IMetaDataService metaDataService;

	/**
	 * Gets the meta data list by page identity.
	 *
	 * @param pageIdentity the page identity
	 * @return the meta data list by page identity
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Get metadata list by page identity", 
            notes = "Retrieves a list of metadata associated with the given page identity", 
            response = List.class)
	@GetMapping("/getMetaDataListByPageIdentity")
	List<MetaData> getMetaDataListByPageIdentity(@ApiParam(value = "Page identity", required = true) @RequestParam String pageIdentity) throws ApplicationException{
		
		return metaDataService.getMetaDataListByPageIdentity(pageIdentity);
	}
	
	
	/**
	 * Convert meta data entity into DTO.
	 *
	 * @param meteDataViewDto the mete data view dto
	 * @return the meta data view dto
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Convert metadata entity into DTO", 
            notes = "Converts a metadata entity into a DTO", 
            response = MetaDataViewDto.class)
	@PostMapping("/convertMetaDataEntityIntoDTO")
	MetaDataViewDto convertMetaDataEntityIntoDTO(
			@ApiParam(value = "Metadata conversion request DTO", required = true)  
			@RequestBody RlMetaDataConvertDto meteDataViewDto) throws ApplicationException{
		
		return metaDataService.convertMetaDataEntityIntoDTO(meteDataViewDto);
	}
	
	/**
	 * Builds the field group.
	 *
	 * @param fieldGroup the field group
	 * @return the report loss dto
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Build field group", 
            notes = "Builds a field group and returns a Report Loss DTO", 
            response = ReportLossDto.class)
	@PostMapping("/buildFieldGroup")
	ReportLossDto buildFieldGroup( 
			@ApiParam(value = "Field group data", required = true) @RequestBody FieldGroup fieldGroup) throws ApplicationException{
		
		return (ReportLossDto)metaDataService.buildFieldGroup(fieldGroup);
	}

}
