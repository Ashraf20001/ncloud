package com.common.config;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * The Class RoleCache.
 */
@Component
public class RoleCache {
	
	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(RoleCache.class);
    
    /** The role api map. */
    private static Map<Integer,String> roleApiMap;
    
    /** The system property V alue. */
    private static HashMap<String,String> systemPropertyVAlue;
    
	/**
	 * Gets the role api map.
	 *
	 * @return the role api map
	 */
	public static Map<Integer, String> getRoleApiMap() {
		return roleApiMap;
	}
	
	/**
	 * Sets the role api map.
	 *
	 * @param roleApiMap the role api map
	 */
	public static void setRoleApiMap(Map<Integer, String> roleApiMap) {
		RoleCache.roleApiMap = roleApiMap;
	}
	
	/**
	 * Gets the system property V alue.
	 *
	 * @return the system property V alue
	 */
	public static HashMap<String, String> getSystemPropertyVAlue() {
		return systemPropertyVAlue;
	}
	
	/**
	 * Sets the system property V alue.
	 *
	 * @param systemPropertyVAlue the system property V alue
	 */
	public static void setSystemPropertyVAlue(HashMap<String, String> systemPropertyVAlue) {
		RoleCache.systemPropertyVAlue = systemPropertyVAlue;
	}
	
	/**
	 * The Enum RecoveryCacheItem.
	 */
	private enum RecoveryCacheItem {
		
		/** The role api maps. */
		roleApiMaps
	}

	/**
	 * Pork cache.
	 *
	 * @param cacheName the cache name
	 */
	public void porkCache(String cacheName) {
		logger.info("Pork Cache method invoked .....{}", cacheName);
		if (RecoveryCacheItem.roleApiMaps.name().equalsIgnoreCase(cacheName)) {
			setRoleApiMap(null);
			logger.info("Cache Cleared successfully .....{}", cacheName);
		}
	}

	/**
	 * Clear cache.
	 */
	public void clearCache() {
		RoleCache.roleApiMap = null;
	}
    
    

}
