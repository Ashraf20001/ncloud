package com.common.config;

import java.util.Optional;

import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;

import com.common.utils.core.LoggedInUserContextHolder;


import lombok.RequiredArgsConstructor;

/**
 * The Class CustomAuditAware.
 */
@Component
@RequiredArgsConstructor
public class CustomAuditAware implements AuditorAware<Integer> {

	/** The logged in user context holder. */
	private final LoggedInUserContextHolder loggedInUserContextHolder;
	
	/**
	 * Gets the current auditor.
	 *
	 * @return the current auditor
	 */
	@Override
	public Optional<Integer> getCurrentAuditor() {
		Integer id = loggedInUserContextHolder.getLoggedInUser()
		.getId();
		
		return Optional.ofNullable(id);
	}

}
