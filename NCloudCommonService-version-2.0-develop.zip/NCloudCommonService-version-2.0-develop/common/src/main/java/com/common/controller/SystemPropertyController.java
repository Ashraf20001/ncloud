package com.common.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.common.exception.core.ApplicationException;
import com.common.service.ISystemPropertyService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

/**
 * The Class SystemPropertyController.
 */
@RestController
@RequestMapping("/system-property")
@RequiredArgsConstructor
public class SystemPropertyController {

	/** SystemPropertyService. */
	private final ISystemPropertyService systemPropertyService;

	/**
	 * Gets the property value by property name.
	 *
	 * @param propertyName the property name
	 * @return the property value by property name
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Get property value by property name",
            notes = "Retrieves the value of a system property based on the given property name",
            response = String.class)
	@GetMapping("/get-property-value")
	public ResponseEntity<String> getPropertyValueByPropertyName(
			 @ApiParam(value = "Property name", required = true) 
			@RequestParam(value = "propertyName") String propertyName) throws ApplicationException {
		String propertyValue = systemPropertyService.getSystemPropertyValueByPropertyName(propertyName);
		return new ResponseEntity<>(propertyValue, HttpStatus.OK);
	}

}
