package com.common.dao;


import com.common.exception.core.ApplicationException;
import com.common.transfer.object.entity.BulkImportErrorData;
import com.common.transfer.object.entity.BulkImportHistory;

import java.util.List;

/**
 * The Interface IBulkImportHistoryDao.
 */
public interface IBulkImportHistoryDao {
	
    /**
     * Gets the all import history by company.
     *
     * @param companyId the company id
     * @return the all import history by company
     */
    List<BulkImportHistory> getAllImportHistoryByCompany(Integer companyId);

    /**
     * Gets the bulk import error data by upload id.
     *
     * @param uploadId the upload id
     * @return the bulk import error data by upload id
     */
    List<BulkImportErrorData> getBulkImportErrorDataByUploadId(String uploadId);

    /**
     * Save bulk upload history.
     *
     * @param bulkImportHistory the bulk import history
     * @return the bulk import history
     * @throws ApplicationException the application exception
     */
    BulkImportHistory saveBulkUploadHistory(BulkImportHistory bulkImportHistory) throws ApplicationException;

    /**
     * Updatebulk import history.
     *
     * @param bulkImportHistory the bulk import history
     * @return the bulk import history
     */
    BulkImportHistory updatebulkImportHistory(BulkImportHistory bulkImportHistory);

    /**
     * Gets the file path by bulk upload id.
     *
     * @param uploadId the upload id
     * @return the file path by bulk upload id
     */
    String getFilePathByBulkUploadId(Integer uploadId);

    /**
     * Gets the bulk import history by id.
     *
     * @param identity the identity
     * @return the bulk import history by id
     */
    BulkImportHistory getBulkImportHistoryById(String identity);
    
    /**
     * Gets the bulk import history by upload id.
     *
     * @param id the id
     * @return the bulk import history by upload id
     */
    BulkImportHistory getBulkImportHistoryByUploadId(Integer id);
}

