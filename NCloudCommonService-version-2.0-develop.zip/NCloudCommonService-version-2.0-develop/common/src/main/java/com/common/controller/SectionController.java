package com.common.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.common.service.ISectionService;
import com.common.transfer.object.dto.RoleSectionMappingDto;
import com.common.transfer.object.dto.UserSectionDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

/**
 * The Class SectionController.
 */
@RestController
@RequiredArgsConstructor
public class SectionController {
	
	/** The section service. */
	private final ISectionService sectionService;

	/**
	 * Gets the role section map list by role id list.
	 *
	 * @param roleIdList the role id list
	 * @return the role section map list by role id list
	 */
	@ApiOperation(value = "Get role-section mapping list by role ID list",
            notes = "Retrieves a list of role-section mappings for the provided role IDs",
            response = List.class)
	@PostMapping("/getRoleSectionMapListByRoleIdList")
	public List<RoleSectionMappingDto> getRoleSectionMapListByRoleIdList(
			@ApiParam(value = "List of Role IDs", required = true) @RequestBody List<Integer> roleIdList){
		List<RoleSectionMappingDto> roleSectionMapListByRoleIdList = sectionService.getRoleSectionMapListByRoleIdList(roleIdList);
		return roleSectionMapListByRoleIdList;
	}
	
	/**
	 * Gets the all user section mapping data.
	 *
	 * @param userId the user id
	 * @return the all user section mapping data
	 */
	 @ApiOperation(value = "Get all user section mapping data",
             notes = "Retrieves section mapping data for a given user ID",
             response = List.class)
	@GetMapping("/getAllUserSectionMappingData")
	public List<UserSectionDto> getAllUserSectionMappingData(
			@ApiParam(value = "User ID", required = true) @RequestParam String userId){
		List<UserSectionDto> userSectionDto = sectionService.getAllUserSectionMappingData(userId);
		return userSectionDto;
	}
}
