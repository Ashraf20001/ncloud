package com.common.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.common.exception.core.ApplicationException;
import com.common.service.IDigitalPaperMetaDataService;
import com.common.transfer.object.dto.DigitalPaperDto;
import com.common.transfer.object.vo.dto.FieldGroup;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

/**
 * The Class DigitalPaperMetaDataController.
 */
@RestController
@RequiredArgsConstructor
public class DigitalPaperMetaDataController {

	/** The digital paper meta data service. */
	private final IDigitalPaperMetaDataService digitalPaperMetaDataService;

	/**
	 * Convert dto to field group.
	 *
	 * @param dto the dto
	 * @return the field group
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Digital paper fieldgroup",notes="Convert Digital paper dto to FieldGroup",response=FieldGroup.class)
	@PostMapping("/didgitalPaper-dto-to-fieldGroup")
	public FieldGroup convertDtoToFieldGroup( @ApiParam(value = "DigitalPaperDto payload",required = true)  @RequestBody DigitalPaperDto dto) throws ApplicationException {
		return digitalPaperMetaDataService.convertDtoToFieldGroup(dto);

	}

}
