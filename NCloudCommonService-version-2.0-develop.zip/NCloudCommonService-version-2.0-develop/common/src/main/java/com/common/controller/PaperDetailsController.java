package com.common.controller;


import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.common.config.base.controller.BaseController;
import com.common.exception.core.ApplicationException;
import com.common.service.IPaperDetailsService;
import com.common.transfer.object.dto.MetaDataPageDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

/**
 * The Class PaperDetailsController.
 */
@RestController
@RequestMapping("/paper-details")
@RequiredArgsConstructor
public class PaperDetailsController extends BaseController {
	
	
	/** PaperDetailsService. */
	private final IPaperDetailsService paperDetailsService;
	
	/**
	 * Gets the meta data generate paper.
	 *
	 * @param pageId the page id
	 * @return the meta data generate paper
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Get metadata for paper generation",
            notes = "Retrieves metadata details for generating paper",
            response = MetaDataPageDto.class)
	@GetMapping("/get-metadata")
	public ResponseEntity<MetaDataPageDto> getMetaDataGeneratePaper(
			@ApiParam(value = "Page ID", required = true) @RequestParam(name="pageId") String pageId) throws ApplicationException {
		MetaDataPageDto  pageDto = paperDetailsService.getMetaDataGeneratePaper(pageId);
		return new ResponseEntity<MetaDataPageDto>(pageDto,HttpStatus.OK);
	}
	
	/**
	 * Gets the meta data generate paper for manual generation.
	 *
	 * @param pageId the page id
	 * @return the meta data generate paper for manual generation
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Get metadata for manual paper generation",
            notes = "Retrieves metadata details for manual paper generation",
            response = MetaDataPageDto.class)
	@GetMapping("/get-metadata-for-generate-paper")
	public ResponseEntity<MetaDataPageDto> getMetaDataGeneratePaperForManualGeneration(
			 @ApiParam(value = "Page ID", required = true) @RequestParam(name="pageId") String pageId) throws ApplicationException {
		MetaDataPageDto  pageDto = paperDetailsService.getMetaDataGeneratePaperForManualGeneration(pageId);
		return new ResponseEntity<MetaDataPageDto>(pageDto,HttpStatus.OK);
	}
	
	/**
	 * Gets the field data.
	 *
	 * @param pageIdentity the page identity
	 * @return the field data
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Get field data by page identity",
            notes = "Retrieves field data associated with a given page identity",
            response = List.class)
	@PostMapping("/get-field-data")
	public List<String> getFieldData(
			@ApiParam(value = "Page Identity", required = true) @RequestParam(name="pageIdentity") String pageIdentity) throws ApplicationException {
		return paperDetailsService.getFieldData(pageIdentity);
		
	}

	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return PaperDetailsController.class;
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {
		
	}

}

