package com.common.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.ldap.core.support.LdapContextSource;

/**
 * The Class LdapConfig.
 */
@Configuration
public class LdapConfig {
	
	/** The ldap url. */
	@Value("${ldap.url}")
	private String ldapUrl;
	
	/** The base DN. */
	@Value("${base.DN}")
	private String baseDN;
	
	/** The password. */
	@Value("${ldap.admin.password}")
	private String password;
	
	/**
	 * Context source.
	 *
	 * @return the ldap context source
	 */
	@Bean
	public LdapContextSource contextSource() {
		LdapContextSource ldapContextSource = new LdapContextSource();
		ldapContextSource.setUrl(ldapUrl);
		ldapContextSource.setUserDn(baseDN);
		ldapContextSource.setPassword(password);
		return ldapContextSource;
	}
}
