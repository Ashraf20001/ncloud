package com.common.controller;


import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.common.config.base.controller.BaseController;
import com.common.exception.core.ApplicationException;
import com.common.exception.core.codes.ErrorCodes;
import com.common.service.IBulkImportPaperDetailsService;
import com.common.transfer.object.core.ApplicationResponse;
import com.common.transfer.object.dto.BulkImportFieldList;
import com.common.transfer.object.dto.BulkImportFieldValidationDto;
import com.common.transfer.object.dto.BulkImportHistoryDto;
import com.common.transfer.object.dto.BulkImportMappingDto;
import com.common.transfer.object.dto.BulkImportTriggerConsumerDto;
import com.common.transfer.object.dto.FieldDto;
import com.common.transfer.object.entity.BulkImportHistory;
import com.common.utils.core.ApplicationUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

/**
 * The Class BulkImportPaperDetailsController.
 */
@RestController
@RequestMapping
@RequiredArgsConstructor
public class BulkImportPaperDetailsController extends BaseController{
	
	/** The bulk import paper details service. */
	private final IBulkImportPaperDetailsService bulkImportPaperDetailsService;
	
	/**
	 * Bulk import paper details from excel.
	 *
	 * @param file the file
	 * @param pageIdentity the page identity
	 * @param uploadType the upload type
	 * @param uploadAction the upload action
	 * @return the response entity
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Bulk Import",notes="Endpoint serves to generate digital paper using bulk import",response=ResponseEntity.class)
	@PostMapping("/paper-details/bulk-import/excel")
	public ResponseEntity<BulkImportTriggerConsumerDto> bulkImportPaperDetailsFromExcel(
			@ApiParam(value="Import file") @RequestParam(name="bulk_import_file", required = false) MultipartFile file,
			@ApiParam(value="Bulk import page identity",required = true) @RequestParam("page_id") String pageIdentity,
			@ApiParam(value="Upload type",required = true) @RequestParam("upload_type") String uploadType,
			@ApiParam(value="Upload action",required = true) @RequestParam("upload_action") String uploadAction) throws IOException, ApplicationException{
		if (Boolean.FALSE.equals(ApplicationUtils.isValidateObject(file))) {
            throw new ApplicationException(ErrorCodes.INVALID_FILE);
        }
		
		BulkImportTriggerConsumerDto bulkImportTriggerConsumer = bulkImportPaperDetailsService.bulkImportPaperDetailsFromExcel(file, pageIdentity,uploadType,uploadAction);
		
		bulkImportPaperDetailsService.triggerConsumer(bulkImportTriggerConsumer);
		
		return new ResponseEntity<BulkImportTriggerConsumerDto>(bulkImportTriggerConsumer,HttpStatus.OK);
		
	}
	
	
	 /**
 	 * Bulk import paper details history update.
 	 *
 	 * @param bulkImportHistoryDto the bulk import history dto
 	 * @throws IOException Signals that an I/O exception has occurred.
 	 * @throws ApplicationException the application exception
 	 */
	@ApiOperation(value = "Bulk Import history",notes="Endpoint serves to update bulk import history details for digital paper")
 	@PostMapping("/auth/paper-details/bulk-import/update-import-history")
	    public void bulkImportPaperDetailsHistoryUpdate(@ApiParam(value="BulkImportHistoryDto payload data",required = true) @RequestBody BulkImportHistoryDto bulkImportHistoryDto) throws IOException, ApplicationException{
		 bulkImportPaperDetailsService.bulkImportPaperDetailsHistoryUpdate(bulkImportHistoryDto);
	    }
	 
	 /**
 	 * Gets the file path by upload id.
 	 *
 	 * @param uploadId the upload id
 	 * @return the file path by upload id
 	 * @throws IOException Signals that an I/O exception has occurred.
 	 * @throws ApplicationException the application exception
 	 */
	@ApiOperation(value="Bulk import file path",notes="Endpoint serves to get file path of bulk import file of digital paper",response = ApplicationResponse.class)
 	@GetMapping("/auth/paper-details/bulk-import/get-file-path")
	    public ApplicationResponse getFilePathByUploadId( @ApiParam(value="BulkImport upload id",required = true) @RequestParam("upload_id") Integer uploadId) throws IOException, ApplicationException{
	        return getApplicationResponse(bulkImportPaperDetailsService.getFilePathByBulkUploadId(uploadId));
	    }
	 
	 /**
 	 * Gets the page data.
 	 *
 	 * @param pageId the page id
 	 * @param platformId the platform id
 	 * @return the page data
 	 * @throws ApplicationException the application exception
 	 */
	@ApiOperation(value="Bulk import field list",notes="Endpoint serves to get details about field list in bulk import",response = BulkImportFieldList.class)
 	@GetMapping("auth/paper-details/get-field-list")
	    public BulkImportFieldList getPageData(@ApiParam(value="Page id for field list",required = true) @RequestParam("page_id") String pageId, 
	    	  @ApiParam(value="Platform id details",required = true) @RequestParam("platform_id") Integer platformId ) throws ApplicationException {
	         List<FieldDto> fieldList = bulkImportPaperDetailsService.getFieldList(pageId);
	         List<BulkImportMappingDto> bulkImportMappingDto = bulkImportPaperDetailsService.getBulkImportMappingDto(platformId);
	         BulkImportFieldList bulkImportFieldList = new BulkImportFieldList();
	         bulkImportFieldList.setListOfField(fieldList);
	         bulkImportFieldList.setBulkImportMapping(bulkImportMappingDto);
	         return bulkImportFieldList;
	    }
	 
	 /**
 	 * Validate fields.
 	 *
 	 * @param validationDto the validation dto
 	 * @throws NoSuchMethodException the no such method exception
 	 * @throws InvocationTargetException the invocation target exception
 	 * @throws IllegalAccessException the illegal access exception
 	 * @throws ApplicationException the application exception
 	 */
	@ApiOperation(value="Bulk import validate",notes="Endpoint serves to validate data of digital paper in bulk import")
 	@PostMapping("/auth/paper-details/bulk-import/validate-fields")
	    public void validateFields(@ApiParam(value="BulkImportFieldValidationDto payload data") @RequestBody BulkImportFieldValidationDto validationDto) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, ApplicationException {
	         bulkImportPaperDetailsService.validateFields(validationDto);
	    }

	 
	 /**
 	 * Gets the bulk upload history by id.
 	 *
 	 * @param bulkId the bulk id
 	 * @return the bulk upload history by id
 	 */
	@ApiOperation(value="Bulk import history",notes="Get digital paper bulk import history details using bulk import id",response=ApplicationResponse.class)
 	@GetMapping("/auth/paper-details/bulk-import/get-history")
	 public ApplicationResponse getBulkUploadHistoryById(@ApiParam(value = "Bulk import id",required = true) @RequestParam("bulkId") Integer bulkId) {
		 BulkImportHistory bulkUploadHistoryById = bulkImportPaperDetailsService.getBulkUploadHistoryById(bulkId);
		return getApplicationResponse(bulkUploadHistoryById);
	 }
	 


	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return BulkImportPaperDetailsController.class;
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {
		
	}
	

}
