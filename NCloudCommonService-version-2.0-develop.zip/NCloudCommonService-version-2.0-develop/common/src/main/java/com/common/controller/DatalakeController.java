package com.common.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.common.config.base.controller.BaseController;
import com.common.exception.core.ApplicationException;
import com.common.service.IDataLakeService;
import com.common.service.IUserRoleManagementService;
import com.common.transfer.object.dto.AccessMappingPrivilegeDto;
import com.common.transfer.object.dto.RepositoryConfigurationDto;
import com.common.transfer.object.dto.UserDetailsDto;
import com.common.transfer.object.dto.UserPrivillageDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

/**
 * @author CBT
 *
 */
@RestController
@RequiredArgsConstructor
public class DatalakeController extends BaseController {
   
	/**
	 * IDataLakeService
	 */
	private final IDataLakeService iDataLakeService;
	
	/**
	 * userRoleManagementService
	 */
	private final IUserRoleManagementService userRoleManagementService;
	
	/**
	 * @param roleId
	 * @return
	 */
	@ApiOperation(value="Privilege details",notes="Get all role specific privileges in data lake",response=List.class)
	@PostMapping("/user-info")
	public List<UserPrivillageDto> getRoleAndPrivilegeDetails() throws ApplicationException {
		return iDataLakeService.getRoleAndPrivilegeDetails();
	}
	
	/**
	 * @param userIds
	 * @return
	 * @throws ApplicationException
	 */
	@ApiOperation(value="Privilege details",notes="Get all role specific privileges in data lake",response=List.class)
	@PostMapping("/user-details")
    public List<UserDetailsDto> getUserDetailsByIds(@ApiParam(value="UserId list payload",required = true) @RequestBody List<Integer> userIds) throws ApplicationException {
        return iDataLakeService.getUserDetailsByIds(userIds);
    }
	
	/**
	 * @param repositoryConfiguration
	 * @return
	 * @throws ApplicationException
	 */
	@ApiOperation(value="Data lake super admin",notes="Create super admin for the repositoryconfiguration in data lake",response=String.class)
	@PostMapping("/super-admin")
	public String saveSuperAdminDetails(@ApiParam(value="RepositoryConfigurationDto payload",required = true)  @RequestBody RepositoryConfigurationDto repositoryConfiguration) throws ApplicationException {
		return iDataLakeService.saveSuperAdminDetails(repositoryConfiguration);
	}
	
	/**
	 * @return
	 * @throws ApplicationException
	 */
	@ApiOperation(value="Data lake super admin",notes="Get super admin details of data lake",response=RepositoryConfigurationDto.class)
	@GetMapping("/get-super-admin-details")
	public RepositoryConfigurationDto getSuperAdminDetails() throws ApplicationException {
		return iDataLakeService.getSuperAdminDetails();
	}
	
	/**
	 * @param pageId
	 * @return
	 * @throws ApplicationException
	 */
	@ApiOperation(value="User privilege",notes="Get all user privilege for particular page",response=List.class)
	@GetMapping("/user-privilege")
    public List<AccessMappingPrivilegeDto> getUserprivilege(@ApiParam(value="Page id",required = true)  @RequestParam Integer pageId) throws ApplicationException {
        return userRoleManagementService.getAllPrivillegeByUserRole(pageId);
    }

    @Override
    protected Class<?> getClassName() {
        return this.getClass();
    }

    @Override
    public Object getVo(String identity) throws ApplicationException {
        return null;
    }

    @Override
    protected void registerInterceptor() {
    }

}

