package com.common.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.common.config.base.controller.BaseController;
import com.common.dao.impl.ExportImportDaoImpl;
import com.common.exception.core.ApplicationException;
import com.common.service.IManageDataService;
import com.common.transfer.object.core.ApplicationResponse;
import com.common.transfer.object.dto.AlterDto;
import com.common.transfer.object.dto.SearchDto;
import com.common.transfer.object.dto.UpdateDto;
import com.common.transfer.object.vo.dto.MasterDataMappingDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

/**
 * The Class ManageDataController.
 */
@RestController
@RequestMapping("/data")
@RequiredArgsConstructor
public class ManageDataController extends BaseController{
		
			/** The data service. */
			private final IManageDataService dataService;
	
			/**
			 * Creates the table.
			 *
			 * @param tableName the table name
			 * @param columnNames the column names
			 * @return the response entity
			 * @throws Exception the exception
			 */
			@ApiOperation(value="Create tables",notes="Endpoint servers for table creation",response=ResponseEntity.class)
			@PostMapping("/create")
			public ResponseEntity<?> createTable(@ApiParam(value = "Table name",required = true) @RequestParam String tableName , @ApiParam(value = "Column names payload data",required = true) @RequestBody Map<String,String> columnNames) throws Exception{
						dataService.createTable(tableName, columnNames);
						return ResponseEntity.ok().build();
			}
			
			/**
			 * Insert into table.
			 *
			 * @param tableName the table name
			 * @param columnsWithValues the columns with values
			 * @return the response entity
			 * @throws Exception the exception
			 */
			@ApiOperation(value="Insert tables",notes="Endpoint useful for inserting data to the table",response=ResponseEntity.class)
			@PostMapping("/insert")
			public ResponseEntity<?> insertIntoTable(
					@ApiParam(value = "Table name",required = true) @RequestParam String tableName,  
					@ApiParam(value = "Column names with values",required = true) @RequestBody Map<String,Object> columnsWithValues) throws Exception{
						dataService.insertValuesIntoTable(tableName, columnsWithValues);
						return ResponseEntity.ok().build();
			}
			
			/**
			 * Insert all into table.
			 *
			 * @param tableName the table name
			 * @param listofColumnsWithValues the listof columns with values
			 * @return the response entity
			 * @throws Exception the exception
			 */
			@ApiOperation(value="Insert tables",notes="Endpoint useful for inserting many data to the table",response=ResponseEntity.class)
			@PostMapping("/insertAll")
			public ResponseEntity<?> insertAllIntoTable(@ApiParam(value = "Table name",required = true) @RequestParam String tableName, 
					@ApiParam(value = "List of columns with values",required = true)	@RequestBody List<Map<String,Object>> listofColumnsWithValues) throws Exception{
						dataService.insertAllValuesIntoTable(tableName,listofColumnsWithValues);
						return ResponseEntity.ok("Records has been inserted successfully");
			}
			
			/**
			 * Update table.
			 *
			 * @param tableName the table name
			 * @param updateDto the update dto
			 * @return the response entity
			 * @throws Exception the exception
			 */
			@ApiOperation(value="Update tables",notes="Endpoint useful for updating data to the table",response=ResponseEntity.class)
			@PostMapping("/update")
			public ResponseEntity<String> updateTable(@ApiParam(value = "Table name",required = true)  @RequestParam String tableName, 
					@ApiParam(value = "Update dto payload",required = true)  @RequestBody UpdateDto updateDto) throws Exception{
					 dataService.updateTable(tableName, updateDto);
					 return ResponseEntity.ok("Updated Successfully");
			}
			
			/**
			 * Search table.
			 *
			 * @param tableName the table name
			 * @param searchDto the search dto
			 * @return the list
			 * @throws Exception the exception
			 */
			@ApiOperation(value="Search tables",notes="Endpoint useful for querying data from the table",response=ResponseEntity.class)
			@PostMapping("/search")
			public  List<Map<String, Object>> searchTable(@ApiParam(value = "Table name",required = true)  @RequestParam String tableName, 
					@ApiParam(value="Search dto payload",required=true) @RequestBody SearchDto searchDto) throws Exception{
					 List<Map<String, Object>> searchFromTables = dataService.searchFromTables(tableName, searchDto);
					 return searchFromTables;
			}
			
			/**
			 * Alter table.
			 *
			 * @param alterDto the alter dto
			 * @return the response entity
			 * @throws Exception the exception
			 */
			@ApiOperation(value="Alter tables",notes="Endpoint useful for altering table",response=ResponseEntity.class)
			@PostMapping("/alter")
			public ResponseEntity<String> alterTable(@ApiParam(value="AlterDto payload data",required=true) @RequestBody AlterDto alterDto) throws Exception{
					 dataService.alterTable(alterDto);
					 return ResponseEntity.ok("Table Altered Successfully");
			}
			
			/**
			 * Drop table.
			 *
			 * @param tableName the table name
			 * @return the response entity
			 * @throws Exception the exception
			 */
			@ApiOperation(value="Drop tables",notes="Endpoint useful for drop table",response=ResponseEntity.class)
			@DeleteMapping("/drop")
			public ResponseEntity<String> dropTable(@ApiParam(value = "Table name",required = true)  @RequestParam String tableName) throws Exception{
					dataService.dropTable(tableName);
					return ResponseEntity.ok("Table Dropped Successfully");
			}
			
			
			
			/**
			 * Gets the export master data details.
			 *
			 * @param platformId the platform id
			 * @return the export master data details
			 * @throws Exception the exception
			 */
			@ApiOperation(value="Master tables",notes="Endpoint useful for getting master tables",response=ApplicationResponse.class)
			@RequestMapping("/get-master-table-details")
			public ApplicationResponse getExportMasterDataDetails(@ApiParam(value = "Platform id",required = true)  @RequestParam("platformId") Integer platformId) throws Exception{
				return getApplicationResponse(dataService.getMasterDataDetails(platformId));
			}
			
			/**
			 * Export master datas.
			 *
			 * @param tableEntityMap the table entity map
			 * @param platformId the platform id
			 * @param request the request
			 * @return the byte[]
			 * @throws IOException Signals that an I/O exception has occurred.
			 */
			@ApiOperation(value="Export Master tables",notes="Endpoint useful for exporting master tables",response=Byte[].class)
			@RequestMapping("/export-master-datas")
			public byte[] exportMasterDatas( @ApiParam(value = "MasterDataMappingDto list payload",required = true) @RequestBody List<MasterDataMappingDto> tableEntityMap,
					@ApiParam(value = "Platform id",required = true)	@RequestParam(name = "platformId") Integer platformId, HttpServletRequest request) throws IOException {
				return dataService.exportMasterDatas(tableEntityMap, platformId, request);
			}
			
			/**
			 * Import master datas.
			 *
			 * @param file the file
			 * @param isOverride the is override
			 * @param platformId the platform id
			 * @return the application response
			 * @throws ApplicationException the application exception
			 * @throws IOException Signals that an I/O exception has occurred.
			 */
			@ApiOperation(value="Import Master tables",notes="Endpoint useful for importing master tables",response=ApplicationResponse.class)
			@RequestMapping("/import-master-datas")
			public ApplicationResponse importMasterDatas(@ApiParam(value = "Multipart file payload") @RequestBody(required = false) MultipartFile file,
					@ApiParam(value = "is override or not",required = true)	@RequestParam Boolean isOverride,@ApiParam(value = "Platform id",required = true) @RequestParam Integer platformId) throws ApplicationException, IOException {
				return getApplicationResponse(dataService.importMasterData(file, isOverride, platformId));
			}

			/** The export import dao impl. */
			@Autowired
			ExportImportDaoImpl exportImportDaoImpl;
			

			/**
			 * Gets the class name.
			 *
			 * @return the class name
			 */
			@Override
			protected Class<?> getClassName() {
				return this.getClass();
			}

			/**
			 * Gets the vo.
			 *
			 * @param identity the identity
			 * @return the vo
			 * @throws ApplicationException the application exception
			 */
			@Override
			public Object getVo(String identity) throws ApplicationException {
				return null;
			}

			/**
			 * Register interceptor.
			 */
			@Override
			protected void registerInterceptor() {
				
			}
			
			
}
