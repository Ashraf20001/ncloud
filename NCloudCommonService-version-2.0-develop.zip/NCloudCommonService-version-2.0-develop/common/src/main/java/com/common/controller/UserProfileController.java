package com.common.controller;


import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.common.config.base.controller.BaseController;
import com.common.exception.core.ApplicationException;
import com.common.service.IUserProfileService;
import com.common.transfer.object.core.ApplicationResponse;
import com.common.transfer.object.dto.ChangePasswordDto;
import com.common.transfer.object.dto.UserDto;
import com.common.transfer.object.dto.UserManagementListDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;


@RestController
@RequestMapping("/user-profile")
@RequiredArgsConstructor
public class UserProfileController extends BaseController{
	
	/**
	 * UserProfileService
	 */
	private final IUserProfileService userProfileService;
	
	/**
	 * Retrieves the user profile.
	 *
	 * @return UserManagementListDto containing the user profile.
	 * @throws ApplicationException if an error occurs while fetching the user profile.
	 */
	@ApiOperation(value = "Get User Profile", 
	              notes = "Fetches the user profile details.",
	              response = UserManagementListDto.class)
	@GetMapping("/get-user")
	public UserManagementListDto getUserProfile() throws ApplicationException {
			UserManagementListDto userProfile = userProfileService.getUserProfile();
			return userProfile;
	}
	
	/**
	 * Updates the user profile.
	 *
	 * @param userManagementListDto the user profile details to be updated.
	 * @return ApplicationResponse containing success or failure message.
	 * @throws ApplicationException if an error occurs while updating the profile.
	 */
	@ApiOperation(value = "Update User Profile", 
	              notes = "Updates the user profile information.",
	              response = ApplicationResponse.class)
	@PostMapping("/update-user")
	public ApplicationResponse updateUserProfile(@RequestBody(required = true) UserManagementListDto userManagementListDto) throws ApplicationException {
		return getApplicationResponse(userProfileService.updateUserProfile(userManagementListDto));
	}
	
	
	/**
	 * Changes the user's password based request provided in ChangePasswordDto.
	 *
	 * @param changePassword the request DTO containing old and new passwords.
	 * @return ApplicationResponse indicating success or failure.
	 * @throws ApplicationException if an error occurs during password change.
	 */
	@ApiOperation(value = "Change Password", 
	              notes = "Allows users to change their password.",
	              response = ApplicationResponse.class)
	@PostMapping("/change-password")
	public void changePassword(@RequestBody(required = true) ChangePasswordDto changePassword) throws ApplicationException {
		userProfileService.changePassword(changePassword);
	}
	
	/**
	 * Saves the user's profile URL.
	 *
	 * @param userId      the unique identifier of the user
	 * @param profileUrl  the profile URL to be saved
	 * @return ApplicationResponse indicating success or failure
	 * @throws ApplicationException if an error occurs while saving the profile URL
	 */
	@ApiOperation(value = "Save User Profile URL", notes = "Stores the provided profile URL for the given user ID.", response = Void.class)
	@GetMapping("/save-userProfileUrl")
	public void saveUserProfileUrl(
			@ApiParam(value = "User ID", required = true) @RequestParam(name = "userId") Integer userId,
			@ApiParam(value = "Profile URL", required = true) @RequestParam(name = "url") String profileUrl)
			throws ApplicationException {
		userProfileService.saveUserProfileUrl(userId, profileUrl);
	}
	
	/**
	 * Fetch the profile picture URL for the specified user identity.
	 *
	 * @param identity the unique identifier of the user
	 * @return ApplicationResponse containing the profile picture URL or an error message
	 * @throws ApplicationException if an error occurs while fetching the profile picture
	 */
	@ApiOperation(value = "Get User Profile Picture", 
	              notes = "Fetches the profile picture URL for the given user identity.",
	              response = ApplicationResponse.class)
	@GetMapping("/get-profilepic")
	public ApplicationResponse getProfilePicture(
			@ApiParam(value = "Unique Identifier for User", required = true) @RequestParam(name = "user_identity") String identity)
			throws ApplicationException {
		String userProfile= userProfileService.getProfilePicture(identity);
		return getApplicationResponse(userProfile);
	}
	
	/**
	 * Fetches profile pictures for multiple user IDs.
	 *
	 * @param userIds List of user IDs
	 * @return Map<Integer, String> containing a Map of user IDs to profile picture URLs
	 * @throws ApplicationException if an error occurs while fetching data
	 */
	@ApiOperation(value = "Get Multiple User Profile Pictures", 
	              notes = "Fetches profile picture URLs for the provided list of user IDs.",
	              response = Map.class)
	@PostMapping("/get-profile")
	public Map<Integer, String> getUserProfilePicture(
			@ApiParam(value = "List of Integer (User ID's)", required = true) @RequestBody List<Integer> user_id)
			throws ApplicationException {
		Map<Integer, String> userProfile= userProfileService.getUserProfilePicture(user_id);
		return userProfile;
	}

	/**
	 * Fetches user details using an association ID.
	 *
	 * @param userTypeId The user type ID
	 * @return ResponseEntity containing the UserDto
	 * @throws ApplicationException if an error occurs while fetching data
	 */
	@ApiOperation(value = "Get User Details by Association ID", 
	              notes = "Fetches the UserDto using the provided userTypeId.",
	              response = UserDto.class)
	@GetMapping("/get-association-profile")
	public UserDto getUserDtoUsingAssociationId(
			@ApiParam(value = "User Type ID", required = true) @RequestParam Integer userTypeId)
			throws ApplicationException {
		return userProfileService.getUserDtoUsingAssociation(userTypeId);
	}
	
	/**
	 * Fetches a list of user details using an association ID.
	 *
	 * @param userTypeId The user type ID.
	 * @return ResponseEntity containing a list of UserDto.
	 * @throws ApplicationException if an error occurs while fetching data.
	 */
	@ApiOperation(value = "Get User List by Association ID", 
	              notes = "Fetches a list of UserDto objects using the provided userTypeId.",
	              response = List.class)
	@GetMapping("/get-association-profile-list")
	public List<UserDto> getUserDtoListUsingAssociationId(
			@ApiParam(value = "User Type ID", required = true) @RequestParam Integer userTypeId)
			throws ApplicationException {
		return userProfileService.getUserDtoListUsingAssociation(userTypeId);
	}
	
	/**
	 * Fetches a UserDto using the provided user ID.
	 *
	 * @param userId The ID of the user.
	 * @return ResponseEntity containing UserDto.
	 */
	@ApiOperation(value = "Get User by User ID", notes = "Fetches a UserDto object using the provided userId.",
			response = UserDto.class)
	@GetMapping("/get-user-from-userId")
	public UserDto getUserDtousingUserId(@ApiParam(value = "User ID", required = true) @RequestParam("user_id") Integer userId) {
		return userProfileService.getUserDtousingUserId(userId);
	}
	
	/**
	 * Fetches a UserDto using the provided username.
	 *
	 * @param userName The username of the user.
	 * @return ResponseEntity containing UserDto.
	 */
	@ApiOperation(value = "Get User by Username", notes = "Fetches a UserDto object using the provided username.",
			response = UserDto.class)
	@GetMapping("/get-user-from-userName")
	public UserDto getUserDtousingUserId(@ApiParam(value = "UserName", required = true) @RequestParam("user_name") String userName) {
		return userProfileService.getUserDtousingUserName(userName);
	}
	
	/**
	 * Fetches a list of UserDto objects based on the provided role IDs.
	 *
	 * @param roleIds List of role IDs.
	 * @return ResponseEntity containing the list of UserDto objects.
	 */
	@ApiOperation(value = "Get Users by Role IDs", notes = "Fetches a list of UserDto objects based on the provided role IDs.",
			response = List.class)
	@PostMapping("/get-users-from-roleIds")
	public List<UserDto> getUserDtousingroleIds(
			@ApiParam(value = "List of Role Id's", required = true) @RequestBody List<Integer> roleIds) {
		return userProfileService.getUserDtousingRoleIds(roleIds);
	}
	
	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}

	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	@Override
	protected void registerInterceptor() {
		
	}

}

