package com.common.controller;


import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.common.config.base.controller.BaseController;
import com.common.constants.core.ApplicationConstants;
import com.common.enums.SequenceEnum;
import com.common.exception.core.ApplicationException;
import com.common.exception.core.codes.ErrorCodes;
import com.common.generator.SequenceGenerator;
import com.common.service.IFileUploadService;
import com.common.service.ILogoService;
import com.common.transfer.object.core.ApplicationResponse;
import com.common.utils.core.ApplicationUtils;
import com.common.utils.core.LoggedInUserContextHolder;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class FileUploadController extends BaseController {
	
	private final IFileUploadService  fileUploadService;
	
	private final SequenceGenerator sequenceGenerator;
	
	private final ILogoService logoService;
	
	private final LoggedInUserContextHolder loggedInUserContextHolder;
	
	@ApiOperation(value = "Upload file", notes = "Uploads a file with referenceId and referenceType", response = ApplicationResponse.class)
	@PostMapping("/upload-file/{referenceId}/{referenceType}")
	public ApplicationResponse uploadFile(@ApiParam(value = "Reference Type", required = true) @PathVariable String referenceType,
			@ApiParam(value = "Reference ID", required = true)	@PathVariable String referenceId,
			 @ApiParam(value = "List of files to upload")  @RequestParam(name="file", required=false) MultipartFile[] fileList, HttpServletRequest request) throws IOException, ApplicationException{
		if (Boolean.FALSE.equals(ApplicationUtils.isValidateObject(fileList)) ) {
			throw new ApplicationException(ErrorCodes.INVALID_FILE);
		}
		else if(fileList.length > 15) {
			throw new ApplicationException(ErrorCodes.MULTIPLE_FILE_ERROR);
		}
		for (MultipartFile file : fileList) {
			String fileType = file.getContentType();
			boolean extension = fileType.equals(ApplicationConstants.JPEG) || fileType.equals(ApplicationConstants.PNG)
					|| fileType.equals(ApplicationConstants.JPG) || fileType.equals(ApplicationConstants.SVG_XML) || 
					fileType.equals(ApplicationConstants.PDF);
			if (!extension) {
				throw new ApplicationException(ErrorCodes.INVALID_FILE);
			}
		}
		String companyId = referenceId;
		if((referenceType.equals(ApplicationConstants.GROUP_REFERENCE_TYPE) && referenceId.equals(ApplicationConstants.NULL)) || referenceType.equals(ApplicationConstants.STOCK)) {
			referenceId = sequenceGenerator.generateSequence(SequenceEnum.DOCUMENT_GROUP);
		}
		String username=loggedInUserContextHolder.getLoggedInUser().getUsername();
		
		String storageId = fileUploadService.uploadFile(referenceType,referenceId,username,fileList,request,companyId);
		//NOTE:: for police report, survey report and garage invoice - referenceId
		//NOTE:: for Insurance Company, Garage - storageId
		String returnId = referenceType.equals(ApplicationConstants.GROUP_REFERENCE_TYPE) ? referenceId : storageId;
		return getApplicationResponse(returnId);
	}
	
	@ApiOperation(value = "Download file", notes = "Downloads a file using its file code", response = ResponseEntity.class)
	@GetMapping("/downloadFile/{fileCode}")
	public ResponseEntity<Resource> downloadFile(
			@ApiParam(value = "File name", required = true)	@PathVariable("fileCode") String fileName) throws IOException{
		
    	Resource resource = null;
    	try {
    		resource = fileUploadService.downloadFile(fileName);
    	} catch (IOException e) {
    		return ResponseEntity.internalServerError().build();
    	}
       
    	if (resource == null) {
    		return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
    	}
       
    	String contentType = "application/octet-stream";
    	String headerValue = "attachment; filename=\"" + resource.getFilename() + "\"";
     
    	return ResponseEntity.ok()
            .contentType(MediaType.parseMediaType(contentType))
            .header(HttpHeaders.CONTENT_DISPOSITION, headerValue)
            .body(resource); 
		
	}
	
	@ApiOperation(value = "Get company logo", notes = "Retrieves the company logo by company ID", response = ApplicationResponse.class)
	@GetMapping("/getCompanyLog/{companyId}")
	public ApplicationResponse getFileList(@ApiParam(value = "Company ID", required = true) @PathVariable("companyId") Integer companyId) throws ApplicationException {
		return getApplicationResponse(logoService.getLogoByCompanyId(companyId));
	}
	
	@ApiOperation(value = "Get file list", notes = "Retrieves the list of files uploaded for a given reference ID", response = ApplicationResponse.class)
	@GetMapping("/getFileList/{referenceId}")
	public ApplicationResponse getUploadCompanyLogo( @ApiParam(value = "Reference ID", required = true) @PathVariable("referenceId") Integer referenceId) throws ApplicationException {
		return getApplicationResponse(fileUploadService.getFileListByGroupId(referenceId));
	}
	
	@ApiOperation(value = "Delete files", notes = "Deletes files by providing a list of file IDs", response = ApplicationResponse.class)
	@PostMapping("/deleteFileList")
	public ApplicationResponse deleteFileList(@ApiParam(value = "List of File IDs payload", required = true) @RequestBody List<Integer> fileIdList) throws ApplicationException {
		return getApplicationResponse(fileUploadService.deleteFilesByFileIdList(fileIdList));
	}
	
	@ApiOperation(value = "Get profile URL", notes = "Retrieves the file URL based on reference ID and upload file type", response = ApplicationResponse.class)
	@GetMapping("/getProfileUrl")
	public ApplicationResponse getProfileUrl(
			 @ApiParam(value = "Reference ID", required = true) @RequestParam(name="referenceId") Integer referenceId,
			 @ApiParam(value = "Upload file Type", required = true) @RequestParam(name="rpType") String rpType ) {
		
		return getApplicationResponse(fileUploadService.getFileUrlByReferenceAndRpType(referenceId, rpType));
	}

	@Override
	protected Class<?> getClassName() {
		return FileUploadController.class;
	}

	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	@Override
	protected void registerInterceptor() {
		
	}

}
