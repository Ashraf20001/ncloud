package com.common.dao;

import java.time.LocalDate;
import java.util.List;

import com.common.exception.core.ApplicationException;
import com.common.exception.core.ApplicationUnauthorizedException;
import com.common.transfer.object.core.RefreshToken;
import com.common.transfer.object.entity.ForgetPassword;
import com.common.transfer.object.entity.Userprofile;

/**
 * The Interface IAuthDao.
 */
public interface IAuthDao {

/**
 * Createuser.
 *
 * @param userprofile the userprofile
 * @return the userprofile
 * @throws ApplicationException the application exception
 */
public Userprofile createuser(Userprofile userprofile) throws ApplicationException;
	
	/**
	 * Gets the logon user email.
	 *
	 * @param EmailId the email id
	 * @return the logon user email
	 */
	public Userprofile getLogonUserEmail(String EmailId);

    /**
     * Verify email.
     *
     * @param email the email
     * @return true, if successful
     */
    boolean verifyEmail(String email);

	/**
	 * Save forget entry.
	 *
	 * @param forgetEntity the forget entity
	 */
	public void saveForgetEntry(ForgetPassword forgetEntity);

	/**
	 * Gets the date by email id.
	 *
	 * @param today the today
	 * @param emailId the email id
	 * @return the date by email id
	 */
	public List<ForgetPassword> getDateByEmailId(LocalDate today, String emailId);

	/**
	 * Gets the user profile by identity.
	 *
	 * @param id the id
	 * @return the user profile by identity
	 */
	public Userprofile getUserProfileByIdentity(String id);
	
	/**
	 * Update user profile.
	 *
	 * @param userprofile the userprofile
	 */
	public void updateUserProfile(Userprofile userprofile);
	
	/**
	 * Gets the user id from login table.
	 *
	 * @param identity the identity
	 * @return the user id from login table
	 */
	public ForgetPassword getUserIdFromLoginTable(String identity);
	
	/**
	 * Gets the user from username.
	 *
	 * @param name the name
	 * @return the user from username
	 */
	public Userprofile getUserFromUsername(String name);
	
	/**
	 * Verify username or email.
	 *
	 * @param userNameOrEmail the user name or email
	 * @param field the field
	 * @param userId the user id
	 * @return the list
	 */
	public List<Userprofile> verifyUsernameOrEmail(String userNameOrEmail,String field, Integer userId);

	/**
	 * Save refresh token.
	 *
	 * @param refreshToken the refresh token
	 * @throws ApplicationException the application exception
	 */
	public void saveRefreshToken(RefreshToken refreshToken) throws ApplicationException;

	/**
	 * Find by token.
	 *
	 * @param requestRefreshToken the request refresh token
	 * @return the refresh token
	 */
	public RefreshToken findByToken(String requestRefreshToken);

	/**
	 * Delete token.
	 *
	 * @param token the token
	 */
	public void deleteToken(RefreshToken token);

	/**
	 * Find by username.
	 *
	 * @param username the username
	 * @return the userprofile
	 * @throws ApplicationUnauthorizedException the application unauthorized exception
	 */
	public Userprofile findByUsername(String username) throws ApplicationUnauthorizedException;

	/**
	 * Delete by user id.
	 *
	 * @param userId the user id
	 */
	public void deleteByUserId(int userId);

	/**
	 * Verify user name.
	 *
	 * @param userName the user name
	 * @param FieldName the field name
	 * @return the list
	 */
	List<Userprofile> verifyUserName(String userName, String FieldName);

	/**
	 * GET IDENTITY BY ID
	 */
	Object getIdByIdIdentity(String identity, Class className) throws ClassNotFoundException;

}
