package com.common.controller;

import java.io.IOException;
import java.util.List;

import javax.mail.MessagingException;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.common.aop.annotation.Auditable;
import com.common.config.base.controller.BaseController;
import com.common.config.model.FilterOrSortingVo;
import com.common.exception.core.ApplicationException;
import com.common.service.IUserManagementService;
import com.common.transfer.object.core.ApplicationResponse;
import com.common.transfer.object.dto.ListOfRoles;
import com.common.transfer.object.dto.PagesInUserManagement;
import com.common.transfer.object.dto.UserDisableDto;
import com.common.transfer.object.dto.UserManagementListDto;
import com.common.transfer.object.dto.UserManagementSaveOrUpdateDto;
import com.common.utils.core.ApplicationUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@Auditable
public class UserManagementController extends BaseController {

    private final IUserManagementService userManagementService;

	/**
	 * Retrieves a paginated and optionally filtered list of user management
	 * details.
	 *
	 * @param min         The minimum index (skip) of the list.
	 * @param max         The maximum index (limit) of the list.
	 * @param searchValue Optional search value for filtering user management data.
	 * @param filterVo    Optional list of filter or sorting criteria to apply to
	 *                    the user management list.
	 * @return ApplicationResponse containing the user management list details.
	 * @throws ApplicationException If any error occurs during the retrieval
	 *                              process.
	 */
	@ApiOperation(value = "Get User Management List", notes = "Fetches a paginated and optionally filtered list of user management details.",
			response = ApplicationResponse.class)
	@PostMapping("/get-user-management-list")
	public ApplicationResponse getAllUserManagementListDetails(
			@ApiParam(value = "Minimum value to skip", required = true) @RequestParam(name = "min") Integer min,
			@ApiParam(value = "Maximum value to return", required = true) @RequestParam(name = "max") Integer max,
			@ApiParam(value = "Search value") @RequestParam(name = "searchValue", required = false) String searchValue,
			@ApiParam(value = "Filter or sorting options (Optional)", required = false) @RequestBody(required = false) List<FilterOrSortingVo> filterVo)
			throws ApplicationException {
		return getApplicationResponse(userManagementService.getAllUserManagementListDetails(null, min, max, searchValue,filterVo));
	}
	
	/**
	 * Downloads the user management data as an Excel file.
	 * 
	 * @param min         The minimum index (skip) of the list for pagination.
	 * @param max         The maximum index (limit) of the list for pagination.
	 * @param searchValue The search value to filter the user management data.
	 * @param filterVo    Optional list of filter or sorting criteria.
	 * @return ResponseEntity containing the Excel file as a ByteArrayResource.
	 * @throws ApplicationException If an error occurs while fetching or generating
	 *                              the Excel file.
	 */
	@ApiOperation(value = "Download User Management Data as Excel", notes = "Fetches user management data with pagination and search, then downloads it as an Excel file.",
			response = ResponseEntity.class)
	@PostMapping("/download-user-management-list")
	public ResponseEntity<ByteArrayResource> downloadUserManagment(
			@ApiParam(value = "Minimum value", required = true) @RequestParam(name = "min") Integer min,
			@ApiParam(value = "Maximum value", required = true) @RequestParam(name = "max") Integer max,
			@ApiParam(value = "Search value", required = false) @RequestParam(name = "searchValue") String searchValue,
			@ApiParam(value = "Filter or sorting options") @RequestBody(required = false) List<FilterOrSortingVo> filterVo)
			throws ApplicationException {
		
		List<UserManagementListDto> data = userManagementService.getAllUserManagementListDetails(null, min, max,searchValue,filterVo);
		
		if (Boolean.FALSE.equals(ApplicationUtils.isValidateObject(data))) {
			return null;
		}
		return userManagementService.downloadExcelInUser(data);
		
	}
    
	/**
	 * Retrieves a total count of users based on paginated and optionally filtered.
	 *
	 * @param min         The minimum index (skip) of the list.
	 * @param max         The maximum index (limit) of the list.
	 * @param searchValue Optional search value for filtering user management data.
	 * @param filterVo    Optional list of filter or sorting criteria to apply to
	 *                    the user management list.
	 * @return ApplicationResponse containing the user management list details.
	 * @throws ApplicationException If any error occurs during the retrieval
	 *                              process.
	 */
	@ApiOperation(value = "Get User Management List", notes = "Fetches a total count of user management based on paginated and optionally filtered.",
			response = ApplicationResponse.class)
    @PostMapping("/get-user-management-count")
	public ApplicationResponse getAllUserManagementCount(
			@ApiParam(value = "Search Value") @RequestParam(name = "searchValue", required = false) String searchValue,
			@RequestBody(required = false) List<FilterOrSortingVo> filterVo) throws ApplicationException {
        Long Response = userManagementService.getAllUserManagementCount(searchValue,null,filterVo);
    	return getApplicationResponse(Response);
    }

	/**
	 * Retrieves user management page information based on the provided page and
	 * user IDs.
	 *
	 * @param pageId The unique identifier for the page.
	 * @param userId The unique identifier for the user (optional).
	 * @return ApplicationResponse containing user management page information.
	 * @throws ApplicationException If any error occurs during the retrieval
	 *                              process.
	 */
    @ApiOperation(value = "Get User Management Page Information", 
                  notes = "Fetches user management page details based on page ID and user ID.",
                  response = ApplicationResponse.class)
    @GetMapping("/get-user-management-page-info")
	public ApplicationResponse getUserManagementPageInfo(
			@ApiParam(value = "Page ID", required = true) @RequestParam(name = "page_id") String pageId,
			@ApiParam(value = "User ID", required = true) @RequestParam(name = "user_id", required = false) String userId)
			throws ApplicationException {
        return getApplicationResponse(userManagementService.getUserManagementPageInfo(pageId,userId));
    }
    
    /**
     * Saves or updates user management details based on the provided data.
     * 
     * @param userManagementSaveOrUpdateDto DTO containing user management data to be saved or updated.
     * @param platformId The platform identifier associated with the user management data.
     * @return ApplicationResponse containing the result of the save or update operation.
     * @throws Exception If any error occurs during the save or update process.
     */
    @ApiOperation(value = "Save or Update User Management", 
                  notes = "Saves or updates the user management details based on the provided user data and platform ID.",
                  response = ApplicationResponse.class)
    @PostMapping("/user-management/saveOrUpdate")
	public ApplicationResponse saveOrUpdateUsers(
			@ApiParam(value = "UserManagementSaveOrUpdateDto Request Payload", required = true) @RequestBody UserManagementSaveOrUpdateDto userManagementSaveOrUpdateDto,
			@ApiParam(value = "Paltform ID", required = true) @RequestParam(name = "platform_id") String platformId)
			throws Exception {
        return getApplicationResponse(userManagementService.saveUsers(null,userManagementSaveOrUpdateDto, platformId));
    }
    
	/**
	 * Deletes a user based on the provided user disable details.
	 * 
	 * @param userDisableDto DTO containing user information for deletion.
	 * @return ApplicationResponse indicating success or failure of the deletion
	 *         operation.
	 * @throws ApplicationException If an error occurs during the deletion process.
	 * @throws MessagingException   If an error occurs while sending related
	 *                              notifications.
	 * @throws IOException          If an error occurs in file handling during the
	 *                              process.
	 */
    @ApiOperation(value = "Delete a User", 
                  notes = "Deletes a user based on the provided details and may trigger related notifications.",
                  response = ApplicationResponse.class)
    @PostMapping("/user-management/deleteUser")
	public ApplicationResponse deleteUserData(
			@ApiParam(value = "UserDisableDto Payload request", required = true) @RequestBody UserDisableDto userDisableDto)
			throws ApplicationException, MessagingException, IOException {
        return getApplicationResponse(userManagementService.deleteUserData(userDisableDto));
    }
    
	/**
	 * Determines the pages a user can access based on their roles(Payable or Receivable User).
	 * 
	 * @param listOfRole A DTO containing the list of roles associated with the
	 *                   user.
	 * @return ApplicationResponse containing the pages accessible to the user.
	 */
   @ApiOperation(value = "Check Accessible Pages for User", 
                 notes = "Return PagesInUserManagement will determine the user is receivable or payable based on their roles.",
                 response = ApplicationResponse.class)
    @PostMapping("/user-management/showPages")
	public ApplicationResponse checkPageToShow(
			@ApiParam(value = "ListOfRoles Request payload", required = true) @RequestBody ListOfRoles listOfRole) {
    	PagesInUserManagement pagesInUserManagement = userManagementService.getPagesInUserManagement(listOfRole);
    	return getApplicationResponse(pagesInUserManagement);
    	
    }
    
   /**
    * Generates and downloads an Excel file containing the list of users.
    * 
    * @return ResponseEntity containing the Excel file as an InputStreamResource.
    * @throws ApplicationException If an error occurs while generating the Excel file.
    */
   @ApiOperation(value = "Download User List as Excel", 
                 notes = "Generates an Excel file containing user details and returns it as a downloadable response.",
                 response = ResponseEntity.class)
    @GetMapping("/user-management/download-excel")
    public ResponseEntity<InputStreamResource> getUserListExcel() throws ApplicationException {
        return userManagementService.getUserListExcel();
    }
    
    @Override
    protected Class<?> getClassName() {
        return this.getClass();
    }

    @Override
    public Object getVo(String identity) throws ApplicationException {return null;}

    @Override
    protected void registerInterceptor() {}
}
