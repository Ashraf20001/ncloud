package com.common.constants.enums;

/**
 * The Enum RecoveryDetailsEnum.
 */
public enum RecoveryDetailsEnum {
	
	/** The police report fee. */
	POLICE_REPORT_FEE("policeReportFee","Police Report Fee"),
	
	/** The towing charge. */
	TOWING_CHARGE("towingCharge","Towing Charge"),
	
	/** The inspection fee. */
	INSPECTION_FEE("inspectionFee","Inspection Fee"),
	
	/** The other expenses. */
	OTHER_EXPENSES("otherExpenses","Other Expenses"),
	
	/** The cash settlement. */
	CASH_SETTLEMENT("cashSettlement","Cash Settlement"),
	
	/** The labour cost. */
	LABOUR_COST("labourCost","Labour Cost"),
	
	/** The spare parts. */
	SPARE_PARTS("spareParts","Spare Amount");
	
	/** The column name. */
	String columnName;
	
	/** The Alias name. */
	String AliasName;
	
	/**
	 * Instantiates a new recovery details enum.
	 *
	 * @param columnName the column name
	 * @param aliasName the alias name
	 */
	private RecoveryDetailsEnum(String columnName, String aliasName) {
		this.columnName = columnName;
		AliasName = aliasName;
	}
	
	/**
	 * Gets the alias name by column name.
	 *
	 * @param columnName the column name
	 * @return the alias name by column name
	 */
	public static String getAliasNameByColumnName(String columnName) {
		String aliasName = null;
		for(RecoveryDetailsEnum enums : RecoveryDetailsEnum.values()) {
			if(enums.columnName.equals(columnName)) {
				aliasName = enums.AliasName;
			}
		}
		return aliasName;
	}
	
			
}
