package com.common.constants.externalApi.core;

import java.util.ArrayList;
import java.util.List;

/**
 * The Class ExternalApiFieldList.
 */
public class ExternalApiFieldList {

/** The Constant entityFieldNameList. */
public static final List<String> entityFieldNameList=new ArrayList<>();
static {
	entityFieldNameList.add("insuredInfo");
	entityFieldNameList.add("thirdPartyInfo");
	entityFieldNameList.add("userComment");
	entityFieldNameList.add("company");
	entityFieldNameList.add("vehicleDetails");
	entityFieldNameList.add("documents");
	entityFieldNameList.add("garageInfo");
	entityFieldNameList.add("totalLossDetails");


}
}
