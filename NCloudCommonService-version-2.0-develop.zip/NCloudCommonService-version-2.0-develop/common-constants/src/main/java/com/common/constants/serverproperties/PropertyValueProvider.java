package com.common.constants.serverproperties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

 /**
  * The Class PropertyValueProvider.
  */
 @Component
 @ConfigurationProperties(prefix = "common")
 @Data
public class PropertyValueProvider {
	
	/** The mysql data source url. */
	private String mysqlDataSourceUrl;

	/** The mysql ip. */
	private String mysqlIp;

	/** The mysql port. */
	private String mysqlPort;

	/** The mysql username. */
	private String mysqlUsername;

	/** The mysql password. */
	private String mysqlPassword;

	/** The mysql data base. */
	private String mysqlDataBase;

	/** The mysql driver. */
	private String mysqlDriver;
	
	/** The mysql max idle timeout. */
	private String mysqlMaxIdleTimeout;
	
	/** The mysql max idle excess connections. */
	private String mysqlMaxIdleExcessConnections;
	
	/** The mysql connection checkout. */
	private String mysqlConnectionCheckout;
	
	/** The mysql min poolsize. */
	private String mysqlMinPoolsize;
	
	/** The mysql max pool size. */
	private String mysqlMaxPoolSize;
	
	/** The mysql idle connection testperiod. */
	private String mysqlIdleConnectionTestperiod;
	
	/** The data lake login url. */
	private String dataLakeLoginUrl;
		
	/** The digital paper login url. */
	private String digitalPaperLoginUrl;

	/** The is digital paper integrated. */
	private String isDigitalPaperIntegrated;
	
	/** The date format. */
	private String dateFormat;
	
	/** The time format. */
	private String timeFormat;
	
	/** The currency format. */
	private String currencyFormat;
	
	/** The country code. */
	private String countryCode;
	
	/** The time zone. */
	private String timeZone;
	
	/** The send email name. */
	private String sendEmailName;
	
	/** The bulk upload reportloss path. */
	private String bulkUploadReportlossPath;
	
	/** The bulk upload consumer path. */
	private String bulkUploadConsumerPath;
	
	/** The file download url. */
	private String fileDownloadUrl;
	
	/** The common digital url. */
	private String commonDigitalUrl;
	
	/** The reset call digital paper. */
	private String resetCallDigitalPaper;
	
	/** The bulk upload save file path. */
	private String bulkUploadSaveFilePath;
	
	/** The login url. */
	private String loginUrl;
	
	/** The file upload storage type. */
	private String fileUploadStorageType;
	
	/** The file upload path. */
	private String fileUploadPath;
	
	/** The spring mail username. */
	private String springMailUsername;
	
	/** The spring mail password. */
	private String springMailPassword;
	
	/** The algorithm. */
	private String algorithm;
	
	/** The secret key. */
	private String secretKey;
	
	/** The approval limit notification url. */
	private String approvalLimitNotificationUrl;
	
	/** The recovery url. */
	private String recoveryUrl;
	
	/** The is recovery integrated. */
	private String isRecoveryIntegrated;
	
	/**
	 * This is data Lake URL.
	 */
	private String dataLakeUrl;
}
