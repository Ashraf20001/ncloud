package com.common.constants.enums;

/**
 * The Enum ResultCodeEnum.
 */
public enum ResultCodeEnum {
	
	/** The ok. */
	OK("200", "OK"), 
 
 /** The bad request. */
 BAD_REQUEST("400", "bad request"), 
 
 /** The internal server error. */
 INTERNAL_SERVER_ERROR("500", "internal server error"),

	/** The faild. */
	FAILD("4400", "Operation failed"),

	/** The params miss. */
	PARAMS_MISS("4300", "PARAMS MISS"), 
 /** The param error. */
 PARAM_ERROR("4301", "PARAM ERROR"), 
 /** The more request. */
 MORE_REQUEST("4302", "MORE REQUEST"),;

	/** The code. */
	private String code;
	
	/** The msg. */
	private String msg;

	/**
	 * Instantiates a new result code enum.
	 *
	 * @param code the code
	 * @param msg the msg
	 */
	ResultCodeEnum(String code, String msg) {
		this.code = code;
		this.msg = msg;
	}

	/**
	 * Gets the code.
	 *
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Sets the code.
	 *
	 * @param code the new code
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * Gets the msg.
	 *
	 * @return the msg
	 */
	public String getMsg() {
		return msg;
	}

	/**
	 * Sets the msg.
	 *
	 * @param msg the new msg
	 */
	public void setMsg(String msg) {
		this.msg = msg;
	}

}
