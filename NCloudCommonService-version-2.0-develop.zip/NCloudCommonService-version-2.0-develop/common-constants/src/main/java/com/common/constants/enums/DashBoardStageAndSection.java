package com.common.constants.enums;

import java.util.Arrays;
import java.util.List;

import com.common.constants.core.RecoveryStatusConstant;

/**
 * The Enum DashBoardStageAndSection.
 */
public enum DashBoardStageAndSection {

	/** The notification stage. */
	NOTIFICATION_STAGE(RecoveryStatusConstant.DRAFT + "," + RecoveryStatusConstant.NOTIFICATION_OPEN + ","
			+ RecoveryStatusConstant.NOTIFICATION_RECEIVED + "," + RecoveryStatusConstant.NOTIFICATION_ACCEPTED),
	
	/** The claim inspection stage. */
	CLAIM_INSPECTION_STAGE(RecoveryStatusConstant.MOVED_INSPECTION + "," + RecoveryStatusConstant.UNDER_INSPECTION + ","
			+ RecoveryStatusConstant.GS_DETAILS_UPDATED + "," + RecoveryStatusConstant.EXPENSES_AND_DOCUMENT_UPDATED
			+ "," + RecoveryStatusConstant.TOTALLOSS_INITITED + "," + RecoveryStatusConstant.TOTALLOSS_ACCEPTED + ","
			+ RecoveryStatusConstant.SURVEYOR_ASSIGNED),
	
	/** The liability confirmation stage. */
	LIABILITY_CONFIRMATION_STAGE(RecoveryStatusConstant.RECEIVED_LIABILITY + ","
			+ RecoveryStatusConstant.LIABLITY_REVIEW + "," + RecoveryStatusConstant.LIABLITY_ACCEPTED),
	
	/** The settlement stage. */
	SETTLEMENT_STAGE(RecoveryStatusConstant.CONFIRM_LIABLITY + "," + RecoveryStatusConstant.DEBIT_NOTE_GENERATED + ","
			+ RecoveryStatusConstant.CLAIM_SETTLED);

	/** The status list. */
	public List<String> statusList;
	
	/**
	 * Instantiates a new dash board stage and section.
	 *
	 * @param statusArr the status arr
	 */
	private DashBoardStageAndSection(String statusArr) {
		this.statusList= Arrays.asList(statusArr.split(","));

	}
}
