package com.common.constants.externalApi.core;


/**
 * The Class ReportLossDtoField.
 */
public class ReportLossDtoField {
	
	/** The Constant STATE. */
	//claimDetails
	public static final String STATE="state";
	
	/** The Constant CLAIM_ID. */
	public static final String CLAIM_ID="claimId";
	
	/** The Constant CLAIM_SEQUENCE_ID. */
	public static final String CLAIM_SEQUENCE_ID= "claimSequenceId";


    /** The Constant IN_INSURED_NAME. */
    //InsurerInfo
     public static final String IN_INSURED_NAME= "inInsuredName";
     
     /** The Constant IN_INSURER_NAME. */
     public static final String IN_INSURER_NAME= "inInsurerName";
     
     /** The Constant IN_REGISRATION_NO. */
     public static final String IN_REGISRATION_NO= "inRegistrationNo";
     
     /** The Constant IN_MAKE. */
     public static final String IN_MAKE= "inMake";
     
     /** The Constant IN_MODEL. */
     public static final String IN_MODEL= "inModel";
     
     /** The Constant IN_PURCHASE_DATE. */
     public static final String IN_PURCHASE_DATE= "inPurchaseDate";
     
     /** The Constant IN_SUM_INSURED. */
     public static final String IN_SUM_INSURED= "inSumInsured";

    /** The Constant TP_NAME. */
    //ThirdPartyInfo
     public static final String TP_NAME= "tpName";
     
     /** The Constant TP_POLICY_NUMBER. */
     public static final String TP_POLICY_NUMBER= "tpPolicyNumber";
     
     /** The Constant TP_CLAIM_NO. */
     public static final String TP_CLAIM_NO= "tpClaimNo";
     
     /** The Constant TP_REGISTRATION_NO. */
     public static final String TP_REGISTRATION_NO= "tpRegistrationNo";
     
     /** The Constant TP_REGISTRATION_TYPE. */
     public static final String TP_REGISTRATION_TYPE= "tpRegistrationType";
     
     /** The Constant TP_MAKE. */
     public static final String TP_MAKE= "tpMake";
     
     /** The Constant TP_MODEL. */
     public static final String TP_MODEL= "tpModel";

    /** The Constant LD_DATE_OF_LOSS. */
    //loss details
     public static final String LD_DATE_OF_LOSS= "ldDateOfLoss";
     
     /** The Constant LD_CLAIM_NUMBER. */
     public static final String LD_CLAIM_NUMBER= "ldClaimNumber";
     
     /** The Constant LD_REPORTED_DATE. */
     public static final String LD_REPORTED_DATE= "ldReportedDate";
     
     /** The Constant LD_POLICY_NUMBER. */
     public static final String LD_POLICY_NUMBER= "ldPolicyNumber";
     
     /** The Constant LD_RESERVE_AMOUNT. */
     public static final String LD_RESERVE_AMOUNT= "ldReserveAmount";
     
     /** The Constant LD_POLICE_REPORT_NUMBER. */
     public static final String LD_POLICE_REPORT_NUMBER= "ldPoliceReportNumber";
     
     /** The Constant LD_IS_TOTALLOSS. */
     public static final String LD_IS_TOTALLOSS= "ldIsTotalLoss";

    /** The Constant PR_DOCUMENT_UPLOAD. */
    //police report
     public static final String PR_DOCUMENT_UPLOAD= "prDocumentUpload";
     
     /** The Constant PR_POLICE_REPORTID. */
     public static final String PR_POLICE_REPORTID= "policeReportId";

    /** The Constant GARAGE_NAME. */
    //garageInfo
     public static final String GARAGE_NAME= "garageName";
     
     /** The Constant GARAGE_LOCATION. */
     public static final String GARAGE_LOCATION= "garageLocation";
     
     /** The Constant GARAGE_CONTACT_DETAILS. */
     public static final String GARAGE_CONTACT_DETAILS= "garageContactDetails";
     
     /** The Constant GARAGE_TYPE. */
     public static final String GARAGE_TYPE= "garageType";
     
     /** The Constant GARAGE_INVOICE_NAME. */
     public static final String GARAGE_INVOICE_NAME= "garageInvoiceName";

    /** The Constant SD_SURVEYNAME. */
    //survey Details
     public static final String SD_SURVEYNAME= "sdSurveyName";
     
     /** The Constant SD_SURVEY_ALLOCATION_DATE. */
     public static final String SD_SURVEY_ALLOCATION_DATE= "sdSurveyAllocationDate";
     
     /** The Constant SD_SURVEY_DUE_DATE. */
     public static final String SD_SURVEY_DUE_DATE= "sdSurveyDueDate";
     
     /** The Constant SD_SURVEY_REPORT_NAME. */
     public static final String SD_SURVEY_REPORT_NAME= "sdSurveyReportName";

    /** The Constant SR_TOTALLOSS. */
    //survey report
     public static final String SR_TOTALLOSS= "srTotalLoss";
     
     /** The Constant SR_SPARE_PARTS. */
     public static final String SR_SPARE_PARTS= "srSpareParts";
     
     /** The Constant SR_LABOUR_COSR. */
     public static final String SR_LABOUR_COSR= "srLabourCost";
     
     /** The Constant SR_SURVEY_AMOUNT. */
     public static final String SR_SURVEY_AMOUNT = "srSurveyAmount";
     
     /** The Constant SR_SURVEY_REPORT_UPLOAD. */
     public static final String SR_SURVEY_REPORT_UPLOAD= "srSurveyReportUpload";

    /** The Constant RD_POLICE_REPORT_FREE. */
    //recovery details
     public static final String RD_POLICE_REPORT_FREE= "rdPoliceReportFee";
     
     /** The Constant RD_TOWING_CHARGE. */
     public static final String RD_TOWING_CHARGE= "rdTowingCharge";
     
     /** The Constant RD_INSPECTION_FREE. */
     public static final String RD_INSPECTION_FREE= "rdInspectionFee";
     
     /** The Constant RD_OTHER_EXPENSES. */
     public static final String RD_OTHER_EXPENSES="rdOtherExpenses";
     
     /** The Constant RD_CASH_SETTLEMENT. */
     public static final String RD_CASH_SETTLEMENT= "rdCashSettlement";
     
     /** The Constant RD_SPARE_PARTS. */
     public static final String RD_SPARE_PARTS= "rdSpareParts";
     
     /** The Constant RD_LABOUR_COST. */
     public static final String RD_LABOUR_COST= "rdLabourCost";
     
     /** The Constant RD_TP_SURVEYAMOUNT. */
     public static final String RD_TP_SURVEYAMOUNT= "rdTPSurveyAmount";
     
     /** The Constant RD_CLAIM_AMOUNT. */
     public static final String RD_CLAIM_AMOUNT= "rdClaimAmount";

    /** The Constant RR_RESERVE_AMOUNT. */
    //reserve review
     public static final String RR_RESERVE_AMOUNT= "rrReserveAmount";
     
     /** The Constant RR_TP_SURVEY_AMOUNT. */
     public static final String RR_TP_SURVEY_AMOUNT= "rrTPSurveyAmount";
     
     /** The Constant RR_TOTAL_CLAIM_AMOUNT. */
     public static final String RR_TOTAL_CLAIM_AMOUNT= "rrTotalClaimAmount";

    /** The Constant GI_DOCUMENT. */
    //garage invoice
     public static final String GI_DOCUMENT= "giDocument";
     
     /** The Constant GI_GARAGE_INVOICE_NO. */
     public static final String GI_GARAGE_INVOICE_NO= "giGarageInvoiceNo";
     
     /** The Constant GI_GARAGE_INVOICE_ID. */
     public static final String GI_GARAGE_INVOICE_ID= "garageInvoiceId";

    /** The Constant DN_DEBITNOTE_NUMBER. */
    //debit note number
     public static final String DN_DEBITNOTE_NUMBER = "dnDebitNoteNumber";
     
     /** The Constant DN_DEBITNOTE_ID. */
     public static final String DN_DEBITNOTE_ID = "debitNoteId";
     
     /** The Constant DN_DEBITNOTE_DOCUMENT. */
     public static final String DN_DEBITNOTE_DOCUMENT= "dnDebitNoteDocument";

    /** The Constant CN_CREDITNOTE_NUMBER. */
    //credit note number
     public static final String CN_CREDITNOTE_NUMBER= "cnCreditNoteNumber";
     
     /** The Constant CN_CREDITNOTE_ID. */
     public static final String CN_CREDITNOTE_ID= "creditNoteId";
     
     /** The Constant CN_CREDITNOTE_DOCUMENT. */
     public static final String CN_CREDITNOTE_DOCUMENT= "cnCreditNoteDocument";
     
     
     /** The Constant ADJUSTORNAME1. */
     //totalLossFields
     public static final String ADJUSTORNAME1= "adjustorName1";
     
     /** The Constant ADJUSTORNAME2. */
     public static final String ADJUSTORNAME2= "adjustorName2";
     
     /** The Constant SURVEYDATE1. */
     public static final String SURVEYDATE1= "surveyDate1";
     
     /** The Constant SURVEYDATE2. */
     public static final String SURVEYDATE2= "surveyDate2";
     
     /** The Constant TOTALLOSSAMOUNT1. */
     public static final String TOTALLOSSAMOUNT1= "totalLossAmount1";
     
     /** The Constant TOTALLOSSAMOUNT2. */
     public static final String TOTALLOSSAMOUNT2= "totalLossAmount2";
     
     /** The Constant ESTIMATEDTOTALLOSSAMOUNT. */
     public static final String ESTIMATEDTOTALLOSSAMOUNT= "estimatedTotalLossAmount";
     
     /** The Constant SALVAGESELLERNAME. */
     public static final String SALVAGESELLERNAME= "salvageSellerName";
     
     /** The Constant SALVAGEAMOUNT. */
     public static final String SALVAGEAMOUNT= "salvageAmount";
     
     /** The Constant SALVAGEBUYERNAME. */
     public static final String SALVAGEBUYERNAME= "salvageBuyerName";
    
}
