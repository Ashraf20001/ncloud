package com.common.constants.core;


/**
 * The Class TableConstants.
 */
public class TableConstants {
	
	/** The Constant LOGIN_USER. */
	public static final String LOGIN_USER = "rp_login_user";
	
	/** The Constant ROLE. */
	public static final String ROLE = "user_role";
	
	/** The Constant CURRENCY. */
	public static final String CURRENCY = "rp_currency";
	
	/** The Constant SYSTEMCONFIGURATION. */
	public static final String SYSTEMCONFIGURATION = "system_configuration";
	
	/** The Constant IDENTITY. */
	public static final String IDENTITY = "identity";
	
	/** The Constant CLAIM_ID. */
	public static final String CLAIM_ID = "claimId";
	
	/** The Constant STORAGE_DATA. */
	public static final String STORAGE_DATA = "storage_data";
	
	/** The Constant REF_ID. */
	public static final String REF_ID="referenceId";
	
	/** The Constant RP_TYPE. */
	public static final String RP_TYPE="reportType";
	
	/** The Constant STORAGE_TYPE. */
	public static final String STORAGE_TYPE="storageType";
	
	/** The Constant USER_ROLE_DETAILS. */
	public static final String USER_ROLE_DETAILS = "userRoleDetails";
	
	/** The Constant PLATEFORM_ID. */
	public static final String PLATEFORM_ID = "platformId";
	
	/** The Constant PLATFORM. */
	public static final String PLATFORM = "platform";
	
	/** The Constant ALLOCATION_USERTYPE. */
	public static final String ALLOCATION_USERTYPE = "allocation_user_type";
	
	/** The Constant ASSOCIATION. */
	public static final String ASSOCIATION = "association";
	
	/** The Constant BULK_UPLOAD. */
	public static final String BULK_UPLOAD = "BULK_UPLOAD";
	
	/** The Constant BULK_REVOKE. */
	public static final String BULK_REVOKE = "BULK_REVOKE";

	/** The Constant META_DATA_PAGE_DETAILS. */
	public static final String META_DATA_PAGE_DETAILS = "pageDetails";
	
	/** The Constant META_DATA_PAGE_ID. */
	public static final String META_DATA_PAGE_ID = "pageId";
	
	/** The Constant ISDELETED. */
	public static final String ISDELETED = "isDeleted";
	
	/** The Constant USER_TYPE_NAME. */
	public static final String USER_TYPE_NAME = "userTypeName";
	
	/** The Constant IS_MAPPED. */
	public static final String IS_MAPPED = "isMapped";
    
    /** The Constant COMPANY_ID. */
    public static final String COMPANY_ID = "companyId";
	
	/** The Constant USER_ID. */
	public static final String USER_ID = "userId";
	
	/** The Constant USER_SEQ_ID. */
	public static final String USER_SEQ_ID = "userSequenceId";
	
	/** The Constant MODIFIED_DATE. */
	public static final String MODIFIED_DATE = "modifiedDate";
	
	/** The Constant COMPANY_NAME. */
	public static final String COMPANY_NAME = "name";
	
	/** The Constant GARAGE_USER_ID. */
	public static final String GARAGE_USER_ID = "userId";
	
	/** The Constant GARAGE_SHORT_ID. */
	public static final String GARAGE_SHORT_ID = "shortId";

    /** The Constant FIELD. */
    public static final String FIELD = "field";
    
    /** The Constant NAME. */
    public static final String NAME = "name";

    /** The Constant REPORT_CARD. */
    public static final String REPORT_CARD = "report_card";

	/** The Constant PAGE_NAME. */
	public static final String PAGE_NAME = "pageName";

	/** The Constant REFERENCE_ID. */
	public static final String REFERENCE_ID = "referenceId";
	
	/** The Constant UPLOAD_TYPE. */
	public static final String UPLOAD_TYPE = "uploadType";
	
	/** The Constant ACTION_TYPE. */
	public static final String ACTION_TYPE = "uploadActionType";

	/** The Constant TOTAL_LOSS. */
	public static final String TOTAL_LOSS = "total_loss";
	
	/** The Constant TOTAL_LOSS_REPORT_LOSS. */
	public static final String TOTAL_LOSS_REPORT_LOSS = "reportLoss";
	
	/** The Constant ID. */
	public static final String ID = "id";


	/** The Constant GARAGE_ID. */
	public static final String GARAGE_ID = "garageId";
	
	/** The Constant GARAGE_NAME. */
	public static final String GARAGE_NAME = "garageName";

	/** The Constant RECOVERY_DETAILS_ID. */
	public static final String RECOVERY_DETAILS_ID = "recoveryDetailsId";

    /** The Constant MODIFIED_BY. */
    public static final String MODIFIED_BY = "modifiedBy";

	/** The Constant USER_NAME. */
	public static final String USER_NAME = "username";
	
	/** The Constant IS_DLT_STS. */
	public static final String IS_DLT_STS = "isDeleted";
	
	/** The Constant EFFECTIVE_DATE. */
	public static final String EFFECTIVE_DATE = "effectiveDate";
	
	/** The Constant EFFECTIVE_TO. */
	public static final String EFFECTIVE_TO = "effectiveTo";
	
	/** The Constant STATUS. */
	public static final String STATUS = "status";
	
	/** The Constant STORAGE_ID. */
	public static final String STORAGE_ID = "storageId";

	/** The Constant FIELD_ID. */
	public static final String FIELD_ID = "fieldId";
	
	/** The Constant SECTION_ID. */
	public static final String SECTION_ID = "sectionId";
	
	/** The Constant PAGE_ID. */
	public static final String PAGE_ID = "pageId";
	
	/** The Constant META_DATA. */
	public static final String META_DATA = "meta_data";
	
	/** The Constant FIELD_OPTION_MAPPING. */
	public static final String FIELD_OPTION_MAPPING = "field_option_mapping";
	
	/** The Constant DROP_DOWN_OPTIONS. */
	public static final String DROP_DOWN_OPTIONS = "dropdown_options";


	/** The Constant PAGE_DETAILS. */
	public static final String PAGE_DETAILS = "pageDetails";
	
	/** The Constant RLCOMPANY. */
	public static final String RLCOMPANY = "rl_company";
	
	/** The Constant THRESHOLDLIMIT. */
	public static final String THRESHOLDLIMIT = "threshold_limit";

    /** The Constant ROLES. */
    public static final String ROLES = "roles";
	
	/** The Constant ROLE_ID. */
	public static final String ROLE_ID = "roleId";
    
    /** The Constant USER_ROLE_ENTITY. */
    public static final String USER_ROLE_ENTITY = "user_role";
    
    /** The Constant MENU_ID. */
    public static final String MENU_ID = "menuId";
    
    /** The Constant ROLE_MENU_MAPPING. */
    public static final String ROLE_MENU_MAPPING = "um_role_menu_mapping";
	
	/** The Constant ROLE_PRIVILEGE_MAPPING. */
	public static final String ROLE_PRIVILEGE_MAPPING = "um_role_privilege_mapping";
	
	/** The Constant PRIVILEGE_ID. */
	public static final String PRIVILEGE_ID = "privilegeId";
    
    /** The Constant ROLE_PAGE_MAPPING. */
    public static final String ROLE_PAGE_MAPPING = "um_role_page_mapping";
	
	/** The Constant ROLE_SECTION_MAPPING. */
	public static final String ROLE_SECTION_MAPPING ="um_role_section_mapping";

	/** The Constant PAGE. */
	public static final String PAGE = "pageDetails";
	
	/** The Constant SECTION. */
	public static final String SECTION = "sectionDetails";
	
	/** The Constant FIELD_DETAILS. */
	public static final String FIELD_DETAILS = "fieldDetails";
	
	/** The Constant SECTION_NAME. */
	public static final String SECTION_NAME = "sectionName";



	/** The Constant GARAGE. */
	public static final String GARAGE = "garage";



	/** The Constant ROLE_MENU_MAP_MENU_DETAILS. */
	public static final String ROLE_MENU_MAP_MENU_DETAILS = "menuDetails";
	
	/** The Constant ROLE_MENU_MAP_ROLE_NAME. */
	public static final String ROLE_MENU_MAP_ROLE_NAME = "name";
	
	/** The Constant USER_ROLE_ROLE_ID. */
	public static final String USER_ROLE_ROLE_ID = "roleId";
	
	/** The Constant ORDER_BY. */
	public static final String ORDER_BY = "orderBy";
	
	/** The Constant PRIVILLEGE_DETAILS. */
	public static final String PRIVILLEGE_DETAILS = "privilegeDetails";
	
	/** The Constant PRIVILLEGE_PAGE_ID. */
	public static final String PRIVILLEGE_PAGE_ID = "pageId";
	
	/** The Constant APPROVAL_LIMIT_ID. */
	public static final String APPROVAL_LIMIT_ID = "approvalLimitId";
	
	/** The Constant APL_FIELD_ID. */
	public static final String APL_FIELD_ID = "fieldId";
	
	/** The Constant USER_COMPANY_MAPPING_TABLE_NAME. */
	public static final String USER_COMPANY_MAPPING_TABLE_NAME = "user_company_mapping";
    
    /** The Constant UM_USER_SECTION_MAPPING. */
    public static final String UM_USER_SECTION_MAPPING = "um_user_section_mapping";
    
    /** The Constant RECEIVABLE_ID. */
    public static final String RECEIVABLE_ID = "3";
	
	/** The Constant PAYABLE_ID. */
	public static final String PAYABLE_ID = "4";
    
    /** The Constant REPORT_LOSS_ID. */
    public static final String REPORT_LOSS_ID = "1";
    
    /** The Constant USER_DELETED_SUCCESSFULLY. */
    public static final String USER_DELETED_SUCCESSFULLY = "User Deleted Successfully";
    
    /** The Constant ROLE_DELETED_SUCCESSFULLY. */
    public static final String ROLE_DELETED_SUCCESSFULLY = "Role Deleted Successfully";
    
    /** The Constant UPLOAD_ID. */
    public static final String UPLOAD_ID = "uploadId";
    
    /** The Constant USER. */
    public static final String USER = "USER";
    
    /** The Constant LOCAL. */
    public static final String LOCAL = "LOCAL";
	
	/** The Constant BULK_IMPORT_HISTORY. */
	public static final String BULK_IMPORT_HISTORY = "bulk_import_history";
    
    /** The Constant NEW. */
    public static final String NEW = "New";
    
    /** The Constant URL. */
    public static final String URL = "url";
    
    /** The Constant MENU_NAME. */
    public static final String MENU_NAME = "menuName";



    /*
     * Approval Limit
     */

	/** The Constant UM_APPROVAL_LIMIT. */
    public static final String UM_APPROVAL_LIMIT = "um_approval_limit";
	
	/** The Constant UM_APPROVAL_LEVEL. */
	public static final String UM_APPROVAL_LEVEL="um_approval_level";


    //bulk-upload-consumer-path

    /** The Constant BULK_UPLOAD_PROCESS. */
    public static final String BULK_UPLOAD_PROCESS = "/api/auth/process-upload/bulk-upload";
	
	/** The Constant DROPDOWN_ID. */
	public static final String DROPDOWN_ID = "dropdownListId";
	
	/** The Constant AP_IS_DELETED. */
	public static final String AP_IS_DELETED="isDeleted";
	
	/** The Constant IS_ENABLED. */
	public static final String IS_ENABLED = "isEnabled";

	/** The Constant DROPDOWNLIST. */
	public static final String DROPDOWNLIST = "dropDownList";
	
	/** The Constant DROPDOWNLIST_ID. */
	public static final String DROPDOWNLIST_ID = "dropdownListId";
	
	/** The Constant DROPDOWNLISTID. */
	public static final String DROPDOWNLISTID = "dropDownListId";
	
	/** The Constant DROPDOWN_OPTIONS. */
	public static final String DROPDOWN_OPTIONS = "dropDownOptionsId";
	
	/** The Constant DROPDOWN_OPTIONS_PARENT_ID. */
	public static final String DROPDOWN_OPTIONS_PARENT_ID = "parant_option";
	
	/** The Constant DROPDOWN_OPTIONS_NAME. */
	public static final String DROPDOWN_OPTIONS_NAME = "dropdownOption";

	/** The Constant FIELD_DROPDOWN_LIST_MAP. */
	public static final String FIELD_DROPDOWN_LIST_MAP = "field_dropdown_map";

	/** The Constant RECEIVALE. */
	public static final String RECEIVALE = "Receivable";
	
	/** The Constant PAYABLE. */
	public static final String PAYABLE = "Payable";

	/** The Constant USERNAME. */
	public static final String USERNAME = "username";
    
    /** The Constant PAYABLE_REPORT_LOSS_ID. */
    public static final String PAYABLE_REPORT_LOSS_ID = "31";
    
    /** The Constant EMAIL. */
    public static final String EMAIL = "email"; 
	
	/** The Constant USER_TYPE. */
	public static final String USER_TYPE = "userTypeId";
	
	/** The Constant MOBILE_NO. */
	public static final String MOBILE_NO = "mobileno";

	/** The Constant REFRESH_TOKEN. */
	public static final String REFRESH_TOKEN = "refreshtoken";
	
	/** The Constant TOKEN. */
	public static final String TOKEN = "token";
	
	/** The Constant USER_TOKEN. */
	public static final String USER_TOKEN = "user";
	
	/** The Constant BEARER. */
	public static final String BEARER = "Bearer";
	
	/** The Constant PLATFORM_ID. */
	public static final String PLATFORM_ID = "platformId";
	
	/** The Constant PROPERTY_ID. */
	public static final String PROPERTY_ID = "propertyId";
	
	/** The Constant PLATFORM_IDENTITY. */
	public static final String PLATFORM_IDENTITY = "platformIdentity";
	
	/** The Constant BELONGS_TO_COMPANY. */
	public static final String BELONGS_TO_COMPANY = "belongsToCompany";
	
	
	/** The Constant BULK_UPLOAD_PAPER_DETAILS. */
	public static final String BULK_UPLOAD_PAPER_DETAILS = "BULK_UPLOAD_PAPER_DETAILS";
	
	/** The Constant DP_BULK_UPLOAD_PROCESS. */
	public static final String DP_BULK_UPLOAD_PROCESS = "/paper-details/bulk-upload";
	
	/** The Constant DIGITAL_PAPER_ID. */
	public static final String DIGITAL_PAPER_ID = "pdDigitalPaperId"; 
	
	/** The Constant PROPERTY_NAME. */
	public static final String PROPERTY_NAME = "propertyName";
	
	/** The Constant PROPERTY_VALUE. */
	public static final String PROPERTY_VALUE = "propertyValue";
	
	/** The Constant ASSOCIATION_ID. */
	public static final String ASSOCIATION_ID = "associationId";
	
	/** The Constant FILE_STORAGE. */
	public static final String FILE_STORAGE = "storageDetails";
	
	/** The Constant DIGITAL_PAPAER_PLATFORM_ID. */
	public static final String DIGITAL_PAPAER_PLATFORM_ID = "2";
	
	/** The Constant DIGITAL_PAPAER_PAGE_IDENTITY. */
	public static final String DIGITAL_PAPAER_PAGE_IDENTITY = "c741ae6b5c3a49b888d2592a51c6bu8u";
	
	/** The Constant API_DETAILS. */
	public static final String API_DETAILS = "apiDetails";
	
	/** The Constant API_URL. */
	public static final String API_URL = "apiURL";
	
	/** The Constant DEFAULT_PRIVILEGE_ID. */
	public static final String DEFAULT_PRIVILEGE_ID = "59";

	/** The Constant PRIVILEGE_NAME. */
	public static final String PRIVILEGE_NAME = "privilegeName";
	
	/** The Constant DEFAULT_PRIVILEGE_NAME. */
	public static final String DEFAULT_PRIVILEGE_NAME = "Default API Access";
    
    /** The Constant EXTERNAL_API_ACCESS. */
    public static final String EXTERNAL_API_ACCESS = "External API Access";
    
    /** The Constant PLATFORM_ACTIVE. */
    public static final String PLATFORM_ACTIVE = "platformActive";
    
    /** The Constant USER_PROFILE. */
    public static final String USER_PROFILE = "userProfile"; 
    
    /** The Constant ASSOCIATION_ID_. */
    public static final String ASSOCIATION_ID_ = "associationId"; 
    
    /** The Constant ROLE_. */
    public static final String ROLE_ = "role"; 
    
	/** The Constant ATTEMPT. */
	public static final String ATTEMPT = "attempt";
	
	/** The Constant PHONE. */
	public static final String PHONE = "phone";
	
	/** The Constant COMPANY_ADDRESS. */
	public static final String COMPANY_ADDRESS = "address";
	
	/** The Constant TIME. */
	public static final String TIME = "time";
	
	/** The Constant IP. */
	public static final String IP = "ip";
	
	/** The Constant LOGIN_CAPTCHA_CHECK. */
	public static final String LOGIN_CAPTCHA_CHECK = "login_captcha_check";
	
	/** The Constant UM_PHONE_NUMBER. */
	public static final String UM_PHONE_NUMBER = "umPhoneNumber";
    
	// user managment download column

	/** The Constant DOW_USER_ID. */
	public static final String DOW_USER_ID = "User Id";
	
	/** The Constant DOW_USER_NAME. */
	public static final String DOW_USER_NAME = "User Name";
	
	/** The Constant DOW_EMAIL_ID. */
	public static final String DOW_EMAIL_ID = "Email Id";
	
	/** The Constant DOW_PHONE_NUMBER. */
	public static final String DOW_PHONE_NUMBER = "Phone Number";
	
	/** The Constant DOW_USER_ROLE. */
	public static final String DOW_USER_ROLE = "User Role";
	
	/** The Constant DOW_ADDED_DATE. */
	public static final String DOW_ADDED_DATE = "Added Date";
	
	/** The Constant DOW_STATUS. */
	public static final String DOW_STATUS = "Status";
	
	/** The Constant DISCRIPTION. */
	public static final String DISCRIPTION = "description";
	
	// User Role download column

		/** The Constant DOW_USER_ROLE_NAME. */
	public static final String DOW_USER_ROLE_NAME = "Role Name";
		
		/** The Constant DOW_USER_ROLE_DIS. */
		public static final String DOW_USER_ROLE_DIS = "Description";
		
		/** The Constant DOW_USER_ROLE_DATE. */
		public static final String DOW_USER_ROLE_DATE = "Added Date";
		
		/** The Constant DOW_USER_ROLE_MAPPED. */
		public static final String DOW_USER_ROLE_MAPPED = "Mapped/UnMapped";
		
		
		// entity managment download column
		
		/** The Constant DOW_COMPANY_NAME. */
		public static final String DOW_COMPANY_NAME = "Company Name";
		
		/** The Constant EMAIL_ID. */
		public static final String EMAIL_ID = "Email Address";
		
		/** The Constant PHONE_NUMBER. */
		public static final String PHONE_NUMBER = "Phone Number";
		
		/** The Constant ADDRESS. */
		public static final String ADDRESS = "Address";
		
		/** The Constant BULK_IMPORT_MAPPING. */
		public static final String BULK_IMPORT_MAPPING = "bulk_import_mapping";
		
		
		/** The Constant BULK_IMPORT_FIELD_NAME. */
		public static final String BULK_IMPORT_FIELD_NAME="bulkImportFieldName";
		
		/** The Constant DROPDOWN_OPTIONS_ID. */
		public static final String DROPDOWN_OPTIONS_ID = "dropdownOptionsId";
		
		/** The Constant DROP_DOWN_LIST_OPTION_MAP. */
		public static final String DROP_DOWN_LIST_OPTION_MAP="dropdownlist_option_map";
		
		/** The Constant ROLE_PRIVIVLEGE_ID. */
		public static final String ROLE_PRIVIVLEGE_ID = "rolePrivilegeId";
		
		/** The Constant DROPDOWN_NAME. */
		public static final String DROPDOWN_NAME="dropDownName";
		
		/** The Constant ENTITY_PHONE_NUMBER_FIELD_NAME. */
		public static final String ENTITY_PHONE_NUMBER_FIELD_NAME="emInsPhone";
		
	    /** The Constant FROM_COMPANY. */
    	public static final String FROM_COMPANY="fromCompany";
	    
    	/** The Constant TO_COMPANY. */
    	public static final String TO_COMPANY= "toCompany";
	    
    	/** The Constant APPROVAL_LEVEL_CURRENCY. */
    	public static final String APPROVAL_LEVEL_CURRENCY = "currency";
	    
    	/** The Constant DROPDOWN_TYPE. */
    	public static final String DROPDOWN_TYPE = "dropDownType";
	    
    	/** The Constant MAX_VALUE. */
    	public static final String MAX_VALUE = "maxValue";
	    
    	/** The Constant IS_EMAIL. */
    	public static final String IS_EMAIL	= "isEmail";
		
		/** The Constant IS_NOTIFICATION. */
		public static final String IS_NOTIFICATION = "isNotification";
		
		/** The Constant RP_USER_ROLE. */
		public static final String RP_USER_ROLE = "rp_user_role";
    
    /**
     * Instantiates a new table constants.
     */
    private TableConstants() {

		}

}
