package com.common.constants.core;

/**
 * The Class RecoveryStatusConstant.
 */
public class RecoveryStatusConstant {

	/** The Constant NOTIFICATION_OPEN. */
	public static final String NOTIFICATION_OPEN = "Notification Open";
	
	/** The Constant REOPEN. */
	public static final String REOPEN = "Reopen";
	
	/** The Constant DRAFT. */
	public static final String DRAFT = "Draft";
	
	/** The Constant NOTIFICATION_RECEIVED. */
	public static final String NOTIFICATION_RECEIVED = "Notification Received";
	
	/** The Constant NOTIFICATION_ACCEPTED. */
	public static final String NOTIFICATION_ACCEPTED = "Notification Accepted";
	
	/** The Constant NOTIFICATION_REJECTED. */
	public static final String NOTIFICATION_REJECTED = "Notification Rejected";
	
	/** The Constant GS_DETAILS_UPDATED. */
	public static final String GS_DETAILS_UPDATED = "Garage And Survey Details Updated";
	
	/** The Constant MOVED_INSPECTION. */
	public static final String MOVED_INSPECTION = "Moved To Inspection";
	
	/** The Constant UNDER_INSPECTION. */
	public static final String UNDER_INSPECTION = "Under Inspection";
	
	/** The Constant RECEIVED_LIABILITY. */
	public static final String RECEIVED_LIABILITY = "Received Liability";
    
    /** The Constant LIABLITY_ACCEPTED. */
    public static final String LIABLITY_ACCEPTED = "Liability Accepted";
	
	/** The Constant LIABLITY_REVIEW. */
	public static final String LIABLITY_REVIEW="Liability Review";
	
	/** The Constant CLAIM_SETTLED. */
	public static final String CLAIM_SETTLED = "Claim Settled";
	
	/** The Constant CONFIRM_LIABLITY. */
	public static final String CONFIRM_LIABLITY = "Confirmed Liability";
	
	/** The Constant DEBIT_NOTE_GENERATED. */
	public static final String DEBIT_NOTE_GENERATED = "Debit Note Generated";
	
	/** The Constant EXPENSES_AND_DOCUMENT_UPDATED. */
	public static final String EXPENSES_AND_DOCUMENT_UPDATED = "Expenses And Document Updated";
	
	/** The Constant NEEDMOREDETAIL. */
	public static final String NEEDMOREDETAIL = "Need More Details";
	
	/** The Constant DETAILS_PROVIDED. */
	public static final String DETAILS_PROVIDED = "Details Provided";
	
	/** The Constant RECEIVED_REJECTED_NOTIFICATION. */
	public static final String RECEIVED_REJECTED_NOTIFICATION = "Received Rejected Notification";
	
	/** The Constant DISPUTE. */
	public static final String DISPUTE = "Dispute";
	
	/** The Constant DISPUTE_REOPEN. */
	public static final String DISPUTE_REOPEN = "Dispute Reopen";

	/** The Constant TOTALLOSS_INITITED. */
	public static final String TOTALLOSS_INITITED = "TotalLoss Initiated";
	
	/** The Constant TOTALLOSS_ACCEPTED. */
	public static final String TOTALLOSS_ACCEPTED = "TotalLoss Accepted";
	
	/** The Constant SURVEYOR_ASSIGNED. */
	public static final String SURVEYOR_ASSIGNED = "Surveyor Assigned";
}
