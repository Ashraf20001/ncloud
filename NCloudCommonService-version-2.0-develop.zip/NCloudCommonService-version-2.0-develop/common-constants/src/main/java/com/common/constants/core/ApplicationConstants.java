/*
\ * @author codeboard
 */
package com.common.constants.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * The Class ApplicationConstants.
 */
public class ApplicationConstants {

	/** The Constant ALL. */
	public static final String ALL = "ALL";
	
	 /** The Constant STOCK. */
 	public static final String STOCK="stock";

	/** The Constant AUTHORIZATION. */
	public static final String AUTHORIZATION = "Authorization";  
	
	/** The Constant loginUrl. */
	public static final String loginUrl = "LoginUrl";

	/** The Constant BEARER. */
	public static final String BEARER = "Bearer ";

	/** The Constant BETWEEN. */
	public static final String BETWEEN = "BW";

	/** The Constant COMMA. */
	public static final String COMMA = ",";

	/** The Constant DOT_REGEX. */
	public static final String DOT_REGEX = "\\.";

	/** The Constant EMPTY_STRING. */
	public static final String EMPTY_STRING = " ";

	/** The Constant EQUAL. */
	public static final String EQUAL = "Equal";

	/** The Constant FILTER. */
	public static final String FILTER = "FILTER";

	/** The Constant FILTER_TYPE_BOOLEAN. */
	public static final String FILTER_TYPE_BOOLEAN = "Boolean";

	/** The Constant FILTER_TYPE_DATE. */
	public static final String FILTER_TYPE_DATE = "Date";

	/** The Constant FILTER_TYPE_DOUBLE. */
	public static final String FILTER_TYPE_DOUBLE = "Double";

	/** The Constant FILTER_TYPE_INTEGER. */
	public static final String FILTER_TYPE_INTEGER = "Integer";

	/** The Constant FILTER_TYPE_TEXT. */
	public static final String FILTER_TYPE_TEXT = "String";

	/** The Constant GT. */
	public static final String GT = "Gt";

	/** The Constant GTE. */
	public static final String GTE = "Ge";

	/** The Constant IDENTITY. */
	public static final String IDENTITY = "Identity";

	/** The Constant LIKE. */
	public static final String LIKE = "Like";

	/** The Constant LT. */
	public static final String LT = "Lt";

	/** The Constant LTE. */
	public static final String LTE = "Le";

	/** The Constant MINUS_ONE. */
	public static final String MINUS_ONE = "-1";

	/** The Constant ONE. */
	public static final int ONE = 1;

	/** The Constant ORDERBY. */
	public static final String ORDERBY = "orderBy";

	/** The Constant ROLE_SAVED_SUCCESS. */
	public static final String ROLE_SAVED_SUCCESS = "Role Saved Successfully.";
	
	/** The Constant SAVED_SUCCESS. */
	public static final String SAVED_SUCCESS = "Saved Successfully.";

	/** The Constant ROUNDOFF. */
	public static final String ROUNDOFF = "ROUNDOFF";

	/** The Constant SET_IDENTITY. */
	public static final String SET_IDENTITY = "setIdentity";


	/** The Constant SLASH. */
	public static final String SLASH = "/";

	/** The Constant SORTING. */
	public static final String SORTING = "SORTING";

	/** The Constant TOO_MANY_REQUEST_FOUND. */
	public static final String TOO_MANY_REQUEST_FOUND = "Too Many Request found for the input URL : ";

	/** The Constant USER_SAVED_SUCCESS. */
	public static final String USER_SAVED_SUCCESS = "User Saved Successfully.";
	
	/** The Constant WITHOUT_SPACE. */
	public static final String WITHOUT_SPACE = "";

	/** The Constant ZERO. */
	public static final int ZERO = 0;

	/** The Constant valid. */
	public static final String valid = "valid Email Id";

	/** The Constant UPDATE_SUCCESS. */
	public static final String UPDATE_SUCCESS = "Update password successfull";

	/** The Constant AUTHORITY. */
	public static final String AUTHORITY = "AUTHORITY";

	/** The Constant NULL. */
	public static final String NULL = "null";

	/** The Constant LOCAL. */
	public static final String LOCAL = "LOCAL";

	/** The Constant _USER. */
	public static final String _USER = "USER";

	/** The Constant CLAIM. */
	public static final String CLAIM = "CLAIM";


	/** The Constant CREDIT_NOTE. */
	public static final String CREDIT_NOTE="Credit_Note";
	
	/** The Constant DEBIT_NOTE. */
	public static final String DEBIT_NOTE="Debit_Note";
	
	/** The Constant DEFAULT_DATE_FORMAT. */
	/*
	 * Date formate contant.
	 */
	public static final String DEFAULT_DATE_FORMAT = "MM/dd/yyyy";
	
	/** The Constant COMPANY_NAME. */
	public static final String COMPANY_NAME = "COMPANY_NAME";

	/** The Constant INSURANCE_ADMIN. */
	public static final String INSURANCE_ADMIN = "ADMIN";

	/** The Constant INSURANCE_COMPANY_CAP. */
	public static final String INSURANCE_COMPANY_CAP = "INSURANCE_COMPANY";

	/** The Constant INSURANCE_ADMIN_DESCRIPTION. */
	public static final String INSURANCE_ADMIN_DESCRIPTION = "INSURANCE COMPANY ADMIN";

	/** The Constant INSURANCE_ADMIN_CONCAT. */
	public static final String INSURANCE_ADMIN_CONCAT = "_ADMIN";
	
	 /** The Constant COMPANY_GARAGE_GREETING. */
 	public static final String COMPANY_GARAGE_GREETING="Welcome to ";
    
    /** The Constant INSURANCE_PAGE_ID. */
    public static final String INSURANCE_PAGE_ID="29";
    
    /** The Constant INSURANCE_RP_TYPE. */
    public static final String INSURANCE_RP_TYPE="emInsLogo";
    
    /** The Constant COMPANY_LOGO_URL. */
    public static final String COMPANY_LOGO_URL="company_logo_url";
    
    /** The Constant USERNAME. */
    public static final String USERNAME="userName";
    
    /** The Constant LOGINDTO_USER. */
    public static final String LOGINDTO_USER="username";
    
    /** The Constant COMPANYNAME. */
    public static final String COMPANYNAME="companyName";
    
    /** The Constant MAIL_TEMPLATE. */
    public static final String MAIL_TEMPLATE="/mail-template/";
    
    /** The Constant TEMPLATE_FILE_NAME. */
    public static final String TEMPLATE_FILE_NAME="disableUser.ftl";
    
    /** The Constant TITLE. */
    public static final String TITLE="title";
    
    /** The Constant USER_DISABLED. */
    public static final String USER_DISABLED="User Disabled";
    
    /** The Constant PALTFORM_NAME. */
    public static final String PALTFORM_NAME="paltFormName";
    
    /** The Constant EFFECTIVETODATE. */
    public static final String EFFECTIVETODATE="effectiveToDate";
    
    /** The Constant SUBJECT. */
    public static final String SUBJECT="Important: Changes to Your Account Access";
    
    /** The Constant ADD_USER. */
    public static final String ADD_USER="User";
    
    /** The Constant CONTACT. */
    public static final String CONTACT="contact";
    
    /** The Constant DEFAULT_COMPANY_LOGO. */
    public static final String DEFAULT_COMPANY_LOGO="/no_company_logo.jpg";
    
    /** The Constant ASSOCIATION_RP_TYPE. */
    public static final String ASSOCIATION_RP_TYPE="association";
    
    /** The Constant GARAGE_PAGE_ID. */
    public static final String GARAGE_PAGE_ID="30";
	
	/** The Constant MENU_PAGE_CONFIGURATOR. */
	public static final String MENU_PAGE_CONFIGURATOR = "Page Configurator";
	
	/** The Constant MENU_ENTITY_MANAGEMENT. */
	public static final String MENU_ENTITY_MANAGEMENT = "Entity Management";

	/** The Constant CREDIT_NOTE_GENERATED. */
	public static final String CREDIT_NOTE_GENERATED = "CREDIT NOTE GENERATED";
	
	/** The Constant GROUP_REFERENCE_TYPE. */
	public static final String GROUP_REFERENCE_TYPE = "group";
	
	/** The Constant MAX_AMOUNT. */
	public static final Double MAX_AMOUNT = 1000000.0;
	
	/** The Constant SAVE. */
	public static final String SAVE = "SAVE";
	
	/** The Constant JPEG. */
	public static final String JPEG = "image/jpeg";
	
	/** The Constant PNG. */
	public static final String PNG = "image/png";
	
	/** The Constant JPG. */
	public static final String JPG = "image/jpg";
	
	/** The Constant PDF. */
	public static final String PDF="application/pdf";
	
	/** The Constant SVG_XML. */
	public static final String SVG_XML = "image/svg+xml";
	
	/** The Constant DATALAKE. */
	public static final String DATALAKE = "Data Lake";
	
	/** The Constant DIGITAL_CERTIFICATE. */
	public static final String DIGITAL_CERTIFICATE = "Digital Certificate";
	
	/** The Constant UNDER_SCORE. */
	public static final String UNDER_SCORE = "_";

	/** The Constant ID. */
	public static final String ID = "id";

	/** The Constant USER_NAME. */
	public static final String USER_NAME = "user_name";
	
	/** The Constant USER_MANAGEMENT. */
	public static final String USER_MANAGEMENT = "User Management";
	
	/** The Constant EMAIL. */
	public static final String EMAIL = "email";
	
	/** The Constant USER_TYPE. */
	public static final String USER_TYPE = "user_type"; 
	
	/** The Constant ROLES. */
	public static final String ROLES = "roles"; 
	
	/** The Constant PLATFORM_IDENTITY. */
	public static final String PLATFORM_IDENTITY = "platform_identity"; 
	
	/** The Constant PLATFORM_DETAILS. */
	public static final String PLATFORM_DETAILS = "platform_details";
	
	/** The Constant DIGITAL_PLATFORM_ID. */
	public static final Integer DIGITAL_PLATFORM_ID = 2;
	
	/** The Constant DATALAKE_PLATFORM_ID. */
	public static final Integer DATALAKE_PLATFORM_ID = 3;
	
	/** The Constant RECOVERY_PLATFORM_ID. */
	public static final Integer RECOVERY_PLATFORM_ID = 1;
		
	/** The Constant STOCK_POOL_ENTRY. */
	public static final String STOCK_POOL_ENTRY="/saveAllocationUserId";
	
	/** The Constant COMPANY_ID. */
	public static final String COMPANY_ID="company_id";
	
	/** The Constant PARAM_COMPANY_ID. */
	public static final String PARAM_COMPANY_ID="companyId";
	
	/** The Constant USER_ID. */
	public static final String USER_ID="userId";
	
	/** The Constant BULK_IMPORT_PAPER_DETAILS. */
	public static final String BULK_IMPORT_PAPER_DETAILS="paper-details";
	
	/** The Constant ALLOCATION_USER_TYPE. */
	public static final String ALLOCATION_USER_TYPE="allocationUserType";
	
	/** The Constant ALLOCATION_TYPE. */
	public static final String ALLOCATION_TYPE = "allocation_type";
	
	/** The Constant ALLOCATION_POOL. */
	public static final String ALLOCATION_POOL = "User Type";

	/** The Constant ASSOCIATION_ID. */
	public static final String ASSOCIATION_ID = "associationId";
	
	/** The Constant POOL_BASED_ALLOCATION. */
	public static final String POOL_BASED_ALLOCATION = "isPoolBasedAllocation";

	/** The Constant USER_PROFILE. */
	public static final String USER_PROFILE = "USER_PROFILE";

	/** The Constant PROFILE_PICTURE. */
	public static final String PROFILE_PICTURE = "PROFILE_PICTURE";
	
	/** The Constant INSURED_USER_TYPE. */
	public static final String INSURED_USER_TYPE = "Insurance User Type";

	/** The Constant CUSTOMER_PROFILE. */
	public static final String CUSTOMER_PROFILE = "CUSTOMER_PROFILE";
	
	/** The Constant CLEAR_CACHE. */
	public static final String CLEAR_CACHE = "/clear-cache";
	
	/** The Constant CLEAR_CACHE_SYSTEMPROPERTY. */
	public static final String CLEAR_CACHE_SYSTEMPROPERTY = "/clear-cache-system-property";
	
	/** The Constant CLEAR_CACHE_COMPANY_LIST. */
	public static final String CLEAR_CACHE_COMPANY_LIST = "/clear-cache-companyList";
	
	/** The Constant CLEAR_RP_CACHE_COMPANY_LIST. */
	public static final String CLEAR_RP_CACHE_COMPANY_LIST ="/clear-recovery-cache-companyList";
	
	
	/** The Constant API_TO_CLEAR_CAHCE. */
	public static final List<String> API_TO_CLEAR_CAHCE = new ArrayList<>(Arrays.asList(
			"api/user-role/association/saveOrUpdate","api/user-role/saveOrUpdate"

			));
	
	/** The Constant ASSOCIATION. */
	public static final String ASSOCIATION = "ASSOCIATION";
	
	/** The Constant DIGITAL_DASHBOARD_SECTIONS. */
	public static final List<String> DIGITAL_DASHBOARD_SECTIONS= new ArrayList<>(Arrays.asList("Digital paper status","Recent Digital papers"));
	
	/** The Constant REPOSITORY_COST. */
	public static final String REPOSITORY_COST = "repositoryCost";
	
	/** The Constant SHARE_PERCENTAGE. */
	public static final String SHARE_PERCENTAGE = "sharePercentage";

	/** The Constant CUSTOMER. */
	public static final String CUSTOMER = "CUSTOMER";
	
	/** The Constant TRAFFIC_AUTHORITY_. */
	public static final String TRAFFIC_AUTHORITY_ = "TRAFFIC_AUTHORITY";

	/** The Constant RESET_SUCCESS. */
	public static final String RESET_SUCCESS = "Password Resetted Success";
	
	/** The Constant MAPPED_UNMAPPED. */
	public static final String MAPPED_UNMAPPED = "Mapped/UnMapped";
	
	/** The Constant EMPLOYEE. */
	public static final String EMPLOYEE = "Employee";
	
	/** The Constant PASSWORD_PATTERN_REGX. */
	public static final String PASSWORD_PATTERN_REGX = "^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,20}$";
	
	/** The Constant CLEAR_CACHE_URLS. */
	public static final List<String> CLEAR_CACHE_URLS = Arrays.asList("/digital-paper/clear-cache","/digital-paper/clear-cache-system-property"
			,"/digital-paper/clear-cache-companyList");

	/** The Constant STOCK_COUNT_AVAILABILITY. */
	public static final String STOCK_COUNT_AVAILABILITY ="/get-stock-available-count";
	
	/** The Constant REVOKE. */
	public static final String REVOKE ="REVOKE";
	
	/** The Constant DIGITAL_PAPER. */
	public static final String DIGITAL_PAPER ="Digital Paper";
	
	/** The Constant POLICY_NUMBER. */
	public static final String POLICY_NUMBER="Policy Number";
	
	/** The Constant ERROR_MESSAGE. */
	public static final String ERROR_MESSAGE="Error Message";
	
	/** The Constant PAPER_DETAILS_SECTION. */
	public static final String PAPER_DETAILS_SECTION="Paper Details";

	/** The Constant MAKE. */
	public static final String MAKE = "Make";

	/** The Constant MODEL. */
	public static final String MODEL = "Model";
	
	/** The Constant DP_MAKE_FIELD_ID. */
	public static final Integer DP_MAKE_FIELD_ID =133 ;
	
	/** The Constant DP_MODEL_FIELD_ID. */
	public static final Integer DP_MODEL_FIELD_ID =134 ;
	
	/** The Constant DP_USAGE. */
	public static final Integer DP_USAGE=135;

	/** The Constant MAKE_MODEL_USAGE_DROPDOWN_CLEAR. */
	public static final String MAKE_MODEL_USAGE_DROPDOWN_CLEAR = "/clear-make-model-usage-cache";
	
	/** The Constant DISABLED_BY. */
	public static final String DISABLED_BY = "disabledBy";

	/** The Constant IN. */
	public static final String IN = "IN";

	/** The Constant COMPANY_DETAILS_GROUP. */
	public static final String COMPANY_DETAILS_GROUP = "Company Details";
	
	/** The Constant LDAP_INSURANCE_USER_DN. */
	public static final String LDAP_INSURANCE_USER_DN="insurance";
	
	/** The Constant LDAP_AUTHORITY_USER_DN. */
	public static final String LDAP_AUTHORITY_USER_DN="authority";
	
	/** The Constant ORGANISATIONAL_UNIT. */
	public static final String ORGANISATIONAL_UNIT="ou";
	
	/** The Constant SYSTEM_UNIT. */
	public static final String SYSTEM_UNIT="system";
	
	/** The Constant USER_UNIT. */
	public static final String USER_UNIT="users";
	
	/** The Constant LDAP_COMMON_NAME. */
	public static final String LDAP_COMMON_NAME ="cn";
	
	/** The Constant LDAP_SUR_NAME. */
	public static final String LDAP_SUR_NAME ="sn";
	
	/** The Constant OBJECT_CLASS. */
	public static final String OBJECT_CLASS="objectclass";
	
	/** The Constant OBJECT_CLASSES_ARRAY. */
	public static final String[] OBJECT_CLASSES_ARRAY = new String[] { "top", "person", "organizationalPerson",
			"inetOrgPerson" };
	
	/** The Constant EMPLOYEE_TYPE. */
	public static final String EMPLOYEE_TYPE="employeeType";
	
	/** The Constant USER_PASSWORD. */
	public static final String USER_PASSWORD="userPassword";
	
	/** The Constant SSHA_ALGORITHM. */
	public static final String SSHA_ALGORITHM="{SSHA}";
	
	/** The Constant TRUE. */
	public static final String TRUE="true";
	
	/** The Constant KAFKA_TOPIC. */
	public static final String KAFKA_TOPIC="common_audit";

	/** The Constant AUTH_KAFKA_TOPIC. */
	public static final String AUTH_KAFKA_TOPIC="auth_audit";

	/** The Constant ACTIVE_STATUS. */
	public static final String ACTIVE_STATUS = "Active";

	/** The Constant IN_ACTIVE_STATUS. */
	public static final String IN_ACTIVE_STATUS = "InActive";
	
	/** The Constant USER_ROLE_MAPPING. */
	public static final String USER_ROLE_MAPPING  = "UserRoleMapping";

	/** The Constant DISABLED_STATUS. */
	public static final String DISABLED_STATUS = "Disabled";
	
	/** The Constant NO_COMPANY_LOGO. */
	public static final String NO_COMPANY_LOGO = "no_company_logo.jpg";
	
	/** The Constant EIGHT. */
	public static final Integer EIGHT = 8;
	
	/** The Constant KNOCKFORKNOCK. */
	public static final String KNOCKFORKNOCK="KnockForKnock";
	
	/** The Constant ADD_APPROVAL_LIMIT. */
	public static final String ADD_APPROVAL_LIMIT="Add Approval Limit";
	
	/** The Constant EDIT_APPROVAL_LIMIT. */
	public static final String EDIT_APPROVAL_LIMIT="Edit Approval Limit";
	
	/** The Constant CURRENCY_TYPE. */
	public static final String CURRENCY_TYPE = "CURRENCY_TYPE";
	
	/** The Constant ROLE_NAME_APPROVAL_LIMIT. */
	public static final String ROLE_NAME_APPROVAL_LIMIT = "ROLE_NAME";
	
	/** The Constant SELECTED_FIELD. */
	public static final CharSequence SELECTED_FIELD = "[SelectedField]";
	
	/** The Constant CLAIM_RESERVE_AMOUNT. */
	public static final String CLAIM_RESERVE_AMOUNT = "ClaimReserveAmount";
    
    /**
     * Instantiates a new application constants.
     */
    private ApplicationConstants() {
		}

}