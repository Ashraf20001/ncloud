package com.common.constants.core;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

/**
 * The Class SessionScopeClass.
 */
@Component
public class SessionScopeClass {
	
	/** The Constant predicateMap. */
	private static final ThreadLocal<Map<String,Object>> predicateMap= new ThreadLocal<>(); 

	/**
	 * Gets the predicate map.
	 *
	 * @return the predicate map
	 */
	public Map<String,Object> getPredicateMap() {
		return predicateMap.get();
	}

	/**
	 * Sets the predicate map.
	 *
	 * @param userType the user type
	 * @param value the value
	 */
	public  void setPredicateMap(String userType,Object value) {
		Map<String, Object> map = getPredicateMap();
		if(map == null) {
			map = new HashMap<String,Object>();
		}
		map.put(userType, value);
		predicateMap.set(map);
	}
	
	/**
	 * Removes the predicate.
	 */
	public void removePredicate() {
		SessionScopeClass.predicateMap.remove();
	}
}
