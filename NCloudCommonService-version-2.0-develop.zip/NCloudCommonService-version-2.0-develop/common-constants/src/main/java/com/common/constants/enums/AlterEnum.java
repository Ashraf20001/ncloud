package com.common.constants.enums;

/**
 * The Enum AlterEnum.
 */
public enum AlterEnum {
	
	/** The add. */
	ADD,
	
	/** The modify. */
	MODIFY,
	
	/** The drop. */
	DROP,
	
	/** The rename. */
	RENAME;
	
	/**
	 * Find enum.
	 *
	 * @param value the value
	 * @return the string
	 */
	public static String findEnum(String value) {
		for (AlterEnum data : AlterEnum.values()) {
			   if(data.toString().equals(value)) {
				   return data.toString();
			   }
		}
		return null;
	}
}
