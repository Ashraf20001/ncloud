package com.common.constants;


import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * The Class CommonConstantsApplication.
 */
@SpringBootApplication
@ComponentScan("com.common.*")
public class CommonConstantsApplication {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {

	}

}
