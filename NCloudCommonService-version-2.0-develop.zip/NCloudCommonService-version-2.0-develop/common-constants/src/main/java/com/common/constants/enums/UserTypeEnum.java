package com.common.constants.enums;


/**
 * The Enum UserTypeEnum.
 */
public enum UserTypeEnum {
	
	/** The association. */
	ASSOCIATION(1,"ASSOCIATION"),
	
	/** The insurance company. */
	INSURANCE_COMPANY(2,"INSURANCE_COMPANY"),
	
	/** The traffic authority. */
	TRAFFIC_AUTHORITY(3,"TRAFFIC_AUTHORITY"),
	
	/** The customer. */
	CUSTOMER(4,"CUSTOMER");
	
	/** The user type id. */
	public Integer userTypeId;
	
	/** The user type name. */
	public String userTypeName;
	
	/**
	 * Instantiates a new user type enum.
	 *
	 * @param userTypeId the user type id
	 * @param userTypeName the user type name
	 */
	private UserTypeEnum(Integer userTypeId, String userTypeName) {
		this.userTypeId = userTypeId;
		this.userTypeName = userTypeName;
	}
	
}

