package com.common.constants.enums;

/**
 * The Enum DropDownTypeEnum.
 */
public enum DropDownTypeEnum {
	
	/** The common. */
	COMMON(1, "common"),
	
	/** The currency. */
	CURRENCY(3, "currency");
	
	/** The type id. */
	public int typeId;
	
	/** The type name. */
	public String typeName;
	
	/**
	 * Instantiates a new drop down type enum.
	 *
	 * @param typeId the type id
	 * @param typeName the type name
	 */
	DropDownTypeEnum(int typeId, String typeName) {
		this.typeId = typeId;
		this.typeName = typeName;
	}

}
