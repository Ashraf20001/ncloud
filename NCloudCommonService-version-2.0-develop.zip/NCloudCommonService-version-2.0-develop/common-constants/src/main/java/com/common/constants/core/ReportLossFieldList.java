package com.common.constants.core;

/**
 * The Class ReportLossFieldList.
 */
public class ReportLossFieldList {

	/** The Constant IS_MAKE_EMPTY. */
	public static final String IS_MAKE_EMPTY = "isMakeEmpty";
	
	/** The Constant IS_MODEL_EMPTY. */
	public static final String IS_MODEL_EMPTY = "isModelEmpty";
	
	/** The Constant IS_POLICYNO_EMPTY. */
	public static final String IS_POLICYNO_EMPTY = "isPolicyNoEmpty";
	
	/** The Constant IS_POLICE_REPORT_NUMBER_EMPTY. */
	public static final String IS_POLICE_REPORT_NUMBER_EMPTY = "isPoliceReportNoEmpty";
	
	/** The Constant IS_REGISTRATION_NO_EMPTY. */
	public static final String IS_REGISTRATION_NO_EMPTY = "isRegistrationNoEmpty";
	
	/** The Constant IS_THIRDPARTY_CLAIMNO_EMPTY. */
	public static final String IS_THIRDPARTY_CLAIMNO_EMPTY = "isThirdPartyClaimNoEmpty";
	
	/** The Constant IS_CLAIMOPENED. */
	public static final String IS_CLAIMOPENED = "isClaimOpened";
	
	/** The Constant IS_SURVEYDUEDATE_EMPTY. */
	public static final String IS_SURVEYDUEDATE_EMPTY = "isSurveyDueDateEmpty";
	
	/** The Constant IS_SURVEYALLOCATIONDATE_EMPTY. */
	public static final String IS_SURVEYALLOCATIONDATE_EMPTY = "isSurveyAllocationDateEmpty";
	
	/** The Constant IS_GARAGELOCATION_EMPTY. */
	public static final String IS_GARAGELOCATION_EMPTY = "isGarageLocationEmpty";
	
	/** The Constant IS_GARAGENAME_EMPTY. */
	public static final String IS_GARAGENAME_EMPTY = "isGarageNameEmpty";

	/** The Constant IS_NOTIFICATION_REJECTED. */
	public static final String IS_NOTIFICATION_REJECTED = "isnotificationRejected";
	
	/** The Constant IS_NOTIFICATION_REOPEN. */
	public static final String IS_NOTIFICATION_REOPEN = "isnotificationRepoen";
	
	/** The Constant IS_NOTFICATIONNEEDMOREDETAIL_EMPTY. */
	public static final String IS_NOTFICATIONNEEDMOREDETAIL_EMPTY = "notficationNeedMoreDetail";
	
	/** The Constant IS_RECEIVEDREJECTEDNOTIFICATION_VIEWED. */
	public static final String IS_RECEIVEDREJECTEDNOTIFICATION_VIEWED = "receivedRejectedNotification";
	
	/** The Constant IS_DISPUTE. */
	public static final String IS_DISPUTE = "dispute";
	
	/** The Constant IS_DISPUTE_REOPEN. */
	public static final String IS_DISPUTE_REOPEN = "disputeReopen";
	 
 	/** The Constant IS_TPCOMPANY_EMPTY. */
 	public static final String IS_TPCOMPANY_EMPTY="isTpCompanyEmpty";
	 
 	/** The Constant IS_DEBITNOTE_VIEWED. */
 	//REPORT METHODS
	 public static final String IS_DEBITNOTE_VIEWED = "isDebitNoteViewed";
	 
 	/** The Constant IS_CREDITNOTE_GENERATED. */
 	public static final String IS_CREDITNOTE_GENERATED = "isCreditNoteGenerated";
	 
 	/** The Constant IS_SURVEYREPORT_EXIST. */
 	public static final String IS_SURVEYREPORT_EXIST = "isSurveyReportExist";
	 
 	/** The Constant IS_POLICEREPORT_EXIST. */
 	public static final String IS_POLICEREPORT_EXIST = "isPoliceReportExist";
	 
 	/** The Constant IS_GARAGEREPORT_EXIST. */
 	public static final String IS_GARAGEREPORT_EXIST = "isGarageReportExist";
	 
	 /** The Constant IS_GSDTLS_OPENED. */
 	public static final String IS_GSDTLS_OPENED="isGsDtlsOpened";
	 
 	/** The Constant IS_GSDETAILVIEWEDBY_SURVEYOR. */
 	public static final String IS_GSDETAILVIEWEDBY_SURVEYOR="isGsDetailViewedBySurveyor";
	 
 	/** The Constant IS_EXPENSES_AND_DOCUMENT_VIEWED. */
 	public static final String IS_EXPENSES_AND_DOCUMENT_VIEWED="isExpensesAndDocumentViewed";
	 
 	/** The Constant IS_LIABLITYACCEPTED. */
 	public static final String IS_LIABLITYACCEPTED="isLiablityAccepted";
	 
 	/** The Constant IS_LIABLITYVIEWED. */
 	public static final String IS_LIABLITYVIEWED="isLiablityViewed";
	 
 	/** The Constant IS_DEBITNOTEGENERATED. */
 	public static final String IS_DEBITNOTEGENERATED="isDebitNoteGenerated";
	
	 /** The Constant IS_NATURE_OF_LOSS_EMPTY. */
 	public static final String IS_NATURE_OF_LOSS_EMPTY="isNatureOfLossEmpty";
	 
 	/** The Constant IS_ESTIMATED_TOTALLOSS_EMPTY. */
 	public static final String IS_ESTIMATED_TOTALLOSS_EMPTY="isEstimatedTotalLossEmpty";
	 
	 /** The Constant IS_TOTAL_LOSS_EMPTY. */
 	public static final String IS_TOTAL_LOSS_EMPTY="isTotalLossEmpty";
	 
 	/** The Constant IS_TOTAL_LOSS_ACCEPTED_EMPTY. */
 	public static final String IS_TOTAL_LOSS_ACCEPTED_EMPTY="isTotalLossAcceptedEmpty";
	 
 	/** The Constant IS_SURVEYOR_ASSIGNED. */
 	public static final String IS_SURVEYOR_ASSIGNED="isSurveyorAssigned";
	 
	 /** The Constant IS_RESERVE_AMOUNT_EMPTY. */
 	//expense and document reserve review
	 public static final String IS_RESERVE_AMOUNT_EMPTY="isReserveAmountEmpty";
	 
 	/** The Constant IS_TP_SURVEYAMOUNT_EMPTY. */
 	public static final String IS_TP_SURVEYAMOUNT_EMPTY="isTPSurveyAmountEmpty";
	 
 	/** The Constant IS_TOTALCLAIMAMOUNT_EMPTY. */
 	public static final String IS_TOTALCLAIMAMOUNT_EMPTY="isTotalClaimAmountEmpty";
	 
 	/** The Constant IS_SPARPART_ENTERED. */
 	public static final String IS_SPARPART_ENTERED="isSparPartEntered";
	 
 	/** The Constant IS_SURVEY_AMOUNT_ENTERED. */
 	public static final String IS_SURVEY_AMOUNT_ENTERED="isSurveyAmountEntered";
	 
 	/** The Constant IS_LABOUR_CHARGE_ENTERED. */
 	public static final String IS_LABOUR_CHARGE_ENTERED="isLabourChargeEntered";
	 
 	/** The Constant IS_CONFIRM_LIABLITY_ACCEPTED. */
 	public static final String IS_CONFIRM_LIABLITY_ACCEPTED="isConfirmLiablityAccepted";
	 
	 
	 /** The Constant IS_DETAILPROVIDED. */
 	//DETAIL PROVIDED
	 public static final String IS_DETAILPROVIDED="isDetailProvided";
	 
	 /** The Constant IS_DATE_OF_LOSS_EPMTY. */
 	public static final String IS_DATE_OF_LOSS_EPMTY="isDateOfLossEmpty";
	 
 	/** The Constant IS_LS_CLAIM_NO_EMPTY. */
 	public static final String IS_LS_CLAIM_NO_EMPTY="isLsClaimNoEmpty";

	 //Total Loss Inited method
	 
	 /** The Constant IS_ADJUSTER_NAME1_ENTERED. */
 	public static final String IS_ADJUSTER_NAME1_ENTERED="isAdjusterName1Entered";
	 
 	/** The Constant IS_TOTAL_LOSS_AMOUNT_1_ENTERD. */
 	public static final String IS_TOTAL_LOSS_AMOUNT_1_ENTERD="isTotalLossAmount1Entered";
	 
 	/** The Constant IS_SURVEY_DATE_1_ENTERED. */
 	public static final String IS_SURVEY_DATE_1_ENTERED="isSurveyDate1Entered";
	 
	 
	 
}
