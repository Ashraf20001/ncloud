package com.common.constants.enums;

/**
 * The Enum SectionEnum.
 */
public enum SectionEnum {
	
	/** The Insured details. */
	Insured_Details,
	
	/** The T P details. */
	TP_Details,
	
	/** The Loss details. */
	Loss_Details,
	
	/** The Police report. */
	Police_Report,
	
	/** The Garage details. */
	Garage_Details,
	
	/** The Survey details. */
	Survey_Details,
	
	/** The Survey report. */
	Survey_Report,
	
	/** The Recovery details. */
	Recovery_Details,
	
	/** The Reserve review. */
	Reserve_Review,
	
	/** The Garage invoice. */
	Garage_Invoice,
	
	/** The Debit note. */
	Debit_Note,
	
	/** The Credit note. */
	Credit_Note
	
}
