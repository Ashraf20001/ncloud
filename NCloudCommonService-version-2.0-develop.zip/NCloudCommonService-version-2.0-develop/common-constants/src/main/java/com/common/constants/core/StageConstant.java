package com.common.constants.core;

/**
 * The Class StageConstant.
 */
public class StageConstant {

/** The Constant NOTIFICATION_STAGE. */
public static final String NOTIFICATION_STAGE="Notification Stage";

/** The Constant CLAIM_INSPECTION_STAGE. */
public static final String CLAIM_INSPECTION_STAGE="Claim Inspection Stage";

/** The Constant LIABILITY_CONFIRMATION_STAGE. */
public static final String LIABILITY_CONFIRMATION_STAGE="Liability Confirmation Stage";

/** The Constant SETTLEMENT_STAGE. */
public static final String SETTLEMENT_STAGE="Settlement Stage";
}
