package com.common.constants.core;

/**
 * The Class SectionConstant.
 */
public class SectionConstant {

/** The Constant Insured_Details. */
public static final String Insured_Details="Insured Details";

/** The Constant TP_Details. */
public static final String TP_Details="TP Details";

/** The Constant Loss_Details. */
public static final String Loss_Details="Loss Details";

/** The Constant Police_Report. */
public static final String Police_Report="Police Report";

/** The Constant Garage_Details. */
public static final String Garage_Details="Garage Details";

/** The Constant Survey_Details. */
public static final String Survey_Details="Survey Details";

/** The Constant Survey_Report. */
public static final String Survey_Report="Survey Report";

/** The Constant Recovery_Details. */
public static final String Recovery_Details="Recovery Details";

/** The Constant Reserve_Review. */
public static final String Reserve_Review="Reserve Review";

/** The Constant Garage_Invoice. */
public static final String Garage_Invoice="Garage Invoice";

/** The Constant Debit_Note. */
public static final String Debit_Note="Debit Note";

/** The Constant Credit_Note. */
public static final String Credit_Note="Credit Note";
}
