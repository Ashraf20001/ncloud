package com.common.constants.enums;

import com.common.constants.core.SectionConstant;
import com.common.constants.core.StageConstant;

/**
 * The Enum StageAndSectionEnum.
 */
public enum StageAndSectionEnum {
	
	/** The insureddetails. */
	INSUREDDETAILS(SectionConstant.Insured_Details,StageConstant.NOTIFICATION_STAGE),
	
	/** The thirdpartydetails. */
	THIRDPARTYDETAILS(SectionConstant.TP_Details,StageConstant.NOTIFICATION_STAGE),
	
	/** The lossdetails. */
	LOSSDETAILS(SectionConstant.Loss_Details,StageConstant.NOTIFICATION_STAGE),
	
	/** The policereport. */
	POLICEREPORT(SectionConstant.Police_Report,StageConstant.NOTIFICATION_STAGE),
	
	/** The garageinfo. */
	GARAGEINFO(SectionConstant.Garage_Details,StageConstant.CLAIM_INSPECTION_STAGE),
	
	/** The surveydetails. */
	SURVEYDETAILS(SectionConstant.Survey_Details,StageConstant.CLAIM_INSPECTION_STAGE),
	
	/** The surveyreport. */
	SURVEYREPORT(SectionConstant.Survey_Report,StageConstant.CLAIM_INSPECTION_STAGE),
	
	/** The recoverydetails. */
	RECOVERYDETAILS(SectionConstant.Recovery_Details,StageConstant.LIABILITY_CONFIRMATION_STAGE),
	
	/** The reservereview. */
	RESERVEREVIEW(SectionConstant.Reserve_Review,StageConstant.LIABILITY_CONFIRMATION_STAGE),
	
	/** The garageinvoice. */
	GARAGEINVOICE(SectionConstant.Garage_Invoice,StageConstant.SETTLEMENT_STAGE),
	
	/** The debitnote. */
	DEBITNOTE(SectionConstant.Debit_Note,StageConstant.SETTLEMENT_STAGE),
	
	/** The creditnote. */
	CREDITNOTE(SectionConstant.Credit_Note,StageConstant.SETTLEMENT_STAGE);
	
	/** The section. */
	public String section;
	
	/** The stage. */
	public String stage;

	/**
	 * Instantiates a new stage and section enum.
	 *
	 * @param section the section
	 * @param stage the stage
	 */
	private StageAndSectionEnum(String section, String stage) {
		this.stage = stage;
		this.section=section;
	}

}
