package com.common.constants.enums;

import java.util.LinkedHashMap;
import java.util.Map;

import com.common.constants.core.ApplicationConstants;
import com.common.constants.core.RecoveryStatusConstant;

/**
 * The Class StageAndSectionMap.
 */
public class StageAndSectionMap {

/** The Constant stageAndSection. */
public static final Map<String,StageAndSectionEnum> stageAndSection=new LinkedHashMap<>();

/** The Constant COLON. */
public static final String COLON=":";
static {
	stageAndSection.put(RecoveryStatusConstant.DEBIT_NOTE_GENERATED, StageAndSectionEnum.DEBITNOTE);
	stageAndSection.put(RecoveryStatusConstant.CONFIRM_LIABLITY, StageAndSectionEnum.DEBITNOTE);
	stageAndSection.put(RecoveryStatusConstant.CLAIM_SETTLED, StageAndSectionEnum.CREDITNOTE);
	stageAndSection.put(ApplicationConstants.CREDIT_NOTE_GENERATED, StageAndSectionEnum.CREDITNOTE);
	stageAndSection.put(RecoveryStatusConstant.NEEDMOREDETAIL+COLON+RecoveryStatusConstant.MOVED_INSPECTION, StageAndSectionEnum.SURVEYREPORT);
	stageAndSection.put(RecoveryStatusConstant.NEEDMOREDETAIL+COLON+RecoveryStatusConstant.RECEIVED_LIABILITY,StageAndSectionEnum.RECOVERYDETAILS);
	stageAndSection.put(RecoveryStatusConstant.NEEDMOREDETAIL+COLON+RecoveryStatusConstant.LIABLITY_REVIEW,StageAndSectionEnum.RESERVEREVIEW);
	stageAndSection.put(RecoveryStatusConstant.NEEDMOREDETAIL+COLON+RecoveryStatusConstant.CONFIRM_LIABLITY,StageAndSectionEnum.DEBITNOTE);
	stageAndSection.put(RecoveryStatusConstant.DISPUTE+COLON+RecoveryStatusConstant.RECEIVED_LIABILITY,StageAndSectionEnum.RECOVERYDETAILS);
	stageAndSection.put(RecoveryStatusConstant.DISPUTE+COLON+RecoveryStatusConstant.LIABLITY_REVIEW,StageAndSectionEnum.RESERVEREVIEW);
	stageAndSection.put(RecoveryStatusConstant.DISPUTE+COLON+RecoveryStatusConstant.CONFIRM_LIABLITY,StageAndSectionEnum.DEBITNOTE);


}
}
