package com.common.constants.enums;

/**
 * The Enum ConditionEnum.
 */
public enum ConditionEnum {
		
		/** The equals. */
		EQUALS("="),
		
		/** The in. */
		IN("IN"),
		
		/** The notequal. */
		NOTEQUAL("IS NOT"),
		
		/** The notin. */
		NOTIN("NOT IN"),
		
		/** The between. */
		BETWEEN("BETWEEN"),
		
		/** The gte. */
		GTE(">="),
		
		/** The lte. */
		LTE("<="),
		
		/** The gt. */
		GT(">"),
		
		/** The lt. */
		LT("<"),
		
		/** The like. */
		LIKE("like");
		
		/** The condition. */
		private String condition;
		
		/**
		 * Instantiates a new condition enum.
		 *
		 * @param condition the condition
		 */
		private ConditionEnum(String condition) {
			this.condition=condition;
		}
			
		/**
		 * Gets the condition value.
		 *
		 * @return the condition value
		 */
		public String getConditionValue() {
			return condition;
		}
		
		/**
		 * Gets the condition for enum value.
		 *
		 * @param conditionValue the condition value
		 * @return the condition for enum value
		 */
		public static String getConditionForEnumValue(String conditionValue) {
			for (ConditionEnum enumData: ConditionEnum.values()) {
					if(enumData.toString().equalsIgnoreCase(conditionValue)) {
						return enumData.getConditionValue();
					}
			}
			return null;
		}
}