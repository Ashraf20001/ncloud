/*
 * @author codeboard
 */
package com.common.config.base.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * The Class BaseService.
 */
@Service
@Transactional(value = "transactionManager")
public class BaseService {

	/**
	 * The Constant logger.
	 */
	private static final Logger logger = LoggerFactory.getLogger(BaseService.class);

}
