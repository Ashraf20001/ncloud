/*
 * @author codeboard
 */
package com.common.config.property;

/**
 * The Enum DbType.
 */
public enum DbType {
	/**
	 * The master & TEST .
	 */
	MASTER, TEST
}