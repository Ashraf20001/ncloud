/*
 * @author codeboard
 */
package com.common.config.common.base.dao;

/**
 * The Class UserGroupSupport.
 */
public abstract interface IUserGroupSupport {

}
