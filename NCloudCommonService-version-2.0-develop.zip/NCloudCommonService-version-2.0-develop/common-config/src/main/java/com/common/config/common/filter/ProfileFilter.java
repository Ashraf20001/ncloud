/*
 * @author codeboard
 */
package com.common.config.common.filter;

import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;



/**
 * The Class ProfileFilter.
 */
@Component
@Qualifier("profileFilter")
public class ProfileFilter implements IDataFilter {

	Logger logger = LoggerFactory.getLogger(ProfileFilter.class);

	@Override
	public Predicate getFilter(Root<?> root, Object key) {
		return null;
	}

}
