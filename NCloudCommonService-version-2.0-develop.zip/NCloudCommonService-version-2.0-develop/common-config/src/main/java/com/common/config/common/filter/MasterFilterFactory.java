/*
 * @author codeboard
 */
package com.common.config.common.filter;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.common.constants.core.ApplicationConstants;

import lombok.RequiredArgsConstructor;


/**
 * A factory for creating MasterFilter objects.
 */
@Component
public class MasterFilterFactory {

	/**
	 * The bw filter.
	 */
	private final IMasterFilter bwFilter;

	/**
	 * The equals filter.
	 */
	private final IMasterFilter equalsFilter;

	/**
	 * The gte filter.
	 */
	private final IMasterFilter gteFilter;

	/**
	 * The gt filter.
	 */
	private final IMasterFilter gtFilter;

	/**
	 * The like filter.
	 */
	private final IMasterFilter likeFilter;

	/**
	 * The lte filter.
	 */
	private final IMasterFilter lteFilter;

	/**
	 * The lt filter.
	 */
	private final IMasterFilter ltFilter;

	/**
	 * The master filter factory map.
	 */
	private Map<String, IMasterFilter> masterFilterFactoryMap = null;

	/**
	 * The round off filter.
	 */
	private final IMasterFilter roundOffFilter;

	/**
	 * The sorting filters.
	 */
	private final IMasterFilter sortingFilters;
	

	private final IMasterFilter inFilter;
	
	public MasterFilterFactory(@Qualifier("BWFilter") IMasterFilter bwFilter, @Qualifier("EqualFilter") IMasterFilter equalsFilter , 
			@Qualifier("GTEFilter") IMasterFilter gteFilter,@Qualifier("GTFilter") IMasterFilter gtFilter,@Qualifier("LikeFilter") IMasterFilter likeFilter,
			@Qualifier("LTEFilter") IMasterFilter lteFilter ,@Qualifier("LTFilter") IMasterFilter ltFilter, 
			@Qualifier("RoundOffFilter") IMasterFilter roundOffFilter,@Qualifier("SortingFilters") IMasterFilter sortingFilters,@Qualifier("INFilter") IMasterFilter inFilter) {
		
		this.bwFilter = bwFilter;
		this.equalsFilter = equalsFilter;
		this.gteFilter = gteFilter;
		this.gtFilter = gtFilter;
		this.likeFilter = likeFilter;
		this.lteFilter = lteFilter;
		this.ltFilter = ltFilter;
		this.roundOffFilter = roundOffFilter;
		this.sortingFilters = sortingFilters;
		this.inFilter = inFilter;
	}

	/**
	 * Bulid map.
	 */
	@PostConstruct
	public void bulidMap() {
		masterFilterFactoryMap = new HashMap<>();
		masterFilterFactoryMap.put(ApplicationConstants.EQUAL, equalsFilter);
		masterFilterFactoryMap.put(ApplicationConstants.LIKE, likeFilter);
		masterFilterFactoryMap.put(ApplicationConstants.GTE, gteFilter);
		masterFilterFactoryMap.put(ApplicationConstants.GT, gtFilter);
		masterFilterFactoryMap.put(ApplicationConstants.LTE, lteFilter);
		masterFilterFactoryMap.put(ApplicationConstants.LT, ltFilter);
		masterFilterFactoryMap.put(ApplicationConstants.BETWEEN, bwFilter);
		masterFilterFactoryMap.put(ApplicationConstants.ORDERBY, sortingFilters);
		masterFilterFactoryMap.put(ApplicationConstants.ROUNDOFF, roundOffFilter);
		masterFilterFactoryMap.put(ApplicationConstants.IN, inFilter);
	}

	/**
	 * Gets the filter by name.
	 *
	 * @param filterName the filter name
	 * @return the filter by name
	 */
	public IMasterFilter getFilterByName(String filterName) {
		return masterFilterFactoryMap.get(filterName);
	}

}
