package com.common.config.property;

import org.springframework.context.annotation.Configuration;

import com.common.constants.core.PropertyConstants;
import com.common.constants.serverproperties.PropertyValueProvider;
import com.common.crypto.core.TwoWayEncryption;

import lombok.RequiredArgsConstructor;

@Configuration
@RequiredArgsConstructor
public class EnvironmentProperties {
			
	private final TwoWayEncryption enc;
	
	private final PropertyValueProvider configurationProperties;
	
	
	private String dataBaseName = "";

	public String getDataSourceUrl() {
		return configurationProperties.getMysqlDataSourceUrl();
	}
	
	public String getDriverName() {
		return configurationProperties.getMysqlDriver();
	}

	public String getJdbcPassword() {
		return enc.doDecryption(configurationProperties.getMysqlPassword());
	}
	
	public String getJdbcUrl() {
		String url = replaceDateBaseName(configurationProperties.getMysqlDataSourceUrl());
		System.out.println(url);
		url = url.replace(PropertyConstants.MAIN_APP_MYSQL_IP,
				configurationProperties.getMysqlIp());
		url = url.replace(PropertyConstants.MAIN_APP_MYSQL_PORT,
				configurationProperties.getMysqlPort());
		return url;
	}
	
	public String getJdbcUser() {
		return enc.doDecryption(configurationProperties.getMysqlUsername());
	}
	
	public String getMySqlDateBase() {
		if (dataBaseName.isEmpty()) {
			dataBaseName = configurationProperties.getMysqlDataBase();
		}
		return dataBaseName;
	}
	
	public String getSqlIp() {
		return enc.doDecryption(configurationProperties.getMysqlIp());
	}

	public String getSqlPort() {
		return  enc.doDecryption(configurationProperties.getMysqlPort());
	}

	public String replaceDateBaseName(String data) {
		data = data.replace(PropertyConstants.DB_NAME, getMySqlDateBase());
		return data;
	}
	
	public String getJdbcDriver() {
		return configurationProperties.getMysqlDriver();
	}
	
	public String getTimeZone() {
		return configurationProperties.getTimeZone();
	}
	
	public String getDateFormat() {
		return configurationProperties.getDateFormat();
	}
	
	public String getTimeFormat() {
		return configurationProperties.getTimeFormat();
	}
	
	public String getCurrencyFormat() {
		return configurationProperties.getCurrencyFormat();
	}
	
	public String getCountryCode() {
		return configurationProperties.getCountryCode();
	}
	
	public String getFileDownloadUrl() {
		return configurationProperties.getFileDownloadUrl();
	}
	
	public String getResetCallUrl() {
		return configurationProperties.getResetCallDigitalPaper();
	}

    public String getFromEMail() {
		return configurationProperties.getSpringMailUsername();
    }

    public String getFileUploadPath() {
		return configurationProperties.getFileUploadPath();
    }
    
    public String getDigitalUrlPath() {
    	return configurationProperties.getCommonDigitalUrl();
    }
    
    public String getBulkUploadConsumerPath() {
		return configurationProperties.getBulkUploadConsumerPath();
	}
    
    public String getBulkUploadFilePath() {
    	return configurationProperties.getBulkUploadSaveFilePath();
    }
    
    public String getLoginUrl() {
        return configurationProperties.getLoginUrl();
    }
    public String getMysqlMaxIdleTimeout() {
		return configurationProperties.getMysqlMaxIdleTimeout();
	}

	public String getMysqlMaxIdleTimeExcessConnections() {
		return configurationProperties.getMysqlMaxIdleExcessConnections();
	}

	public Boolean getMaterConnectionOnCheckout() {
		return Boolean.valueOf(configurationProperties.getMysqlConnectionCheckout());
	}

	public String getMysqlMinPoolSize() {
		return configurationProperties.getMysqlMinPoolsize();
	}

	public String getMysqlMaxPoolSize() {
		return configurationProperties.getMysqlMaxPoolSize();
	}
	public String getMysqlIdleConnectionTestPeriod() {
		return configurationProperties.getMysqlIdleConnectionTestperiod();
	}

	public String getDataLakeLoginUrl() {
		return configurationProperties.getDataLakeLoginUrl();
	}
	public String getDigitalPaperLoginUrl() {
		return configurationProperties.getDigitalPaperLoginUrl();
	}

	public String getIsDigitalPaperIntegrated() {
		return configurationProperties.getIsDigitalPaperIntegrated();
	}
	
	public String getIsRecoveryIntegrated() {
		return configurationProperties.getIsRecoveryIntegrated();
	}
	
	public String getRecoveryUrl() {
		return configurationProperties.getRecoveryUrl();
	}
	
	public String getDataLakeUrl() {
		return configurationProperties.getDataLakeUrl();
	}
}