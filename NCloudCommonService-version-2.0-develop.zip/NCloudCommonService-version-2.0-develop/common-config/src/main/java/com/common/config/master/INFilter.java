package com.common.config.master;

import java.util.ArrayList;
import java.util.Arrays;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.common.config.common.filter.IMasterFilter;
import com.common.config.model.FilterOrSortingVo;
import com.common.constants.core.ApplicationConstants;
import com.common.exception.core.ApplicationException;
import com.common.utils.core.ApplicationUtils;


@Service
@Qualifier("INFilter")
public class INFilter implements IMasterFilter {
	


	@Override
	public Predicate getFilterPredicate(From<?, ?> root, CriteriaBuilder builder, FilterOrSortingVo filterVo,
			CriteriaQuery<?> criteria) throws ApplicationException {
		String[] columnNames = getColumnNames(filterVo.getColumnName());
		Predicate predicate = null;
		Expression<String> path = getPath(root, columnNames);
		if (ApplicationUtils.isValidList(filterVo.getIntgerValueList())) {
			predicate = builder.and(path.in(filterVo.getIntgerValueList()));
		} else if (Boolean.FALSE.equals(ApplicationUtils.isValidList(filterVo.getIntgerValueList()))
				&& filterVo.getValue() != null
				&& filterVo.getValue().trim().equalsIgnoreCase(ApplicationConstants.ALL)) {
			predicate = builder.and(builder.isNull(path));
		} else if (ApplicationUtils.isValidList(filterVo.getValueList())) {
			predicate = builder.and(path.in(filterVo.getValueList()));
		} else if (Boolean.FALSE.equals(ApplicationUtils.isValidList(filterVo.getValueList()))
				&& filterVo.getValue().trim().equalsIgnoreCase(ApplicationConstants.ALL)) {
			predicate = builder.and(builder.isNull(path));
		} else {
			predicate = builder.and(path.in(new ArrayList<>(Arrays.asList(-1))));
		}
		return predicate;
	}

}
