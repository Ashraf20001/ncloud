/*
 * @author codeboard
 */
package com.common.config.model;

/**
 * The Interface CommonVo.
 */
public interface ICommonVo {

}
