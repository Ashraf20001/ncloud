package com.common.config;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * The Class CommonConfigApplication.
 */
@SpringBootApplication
@ComponentScan("com.common.*")
public class CommonConfigApplication {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {

	}

}
