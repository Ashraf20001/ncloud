package com.common.aop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;


@SpringBootApplication
@ComponentScan("com.common.*")
public class CommonAopApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommonAopApplication.class, args);	
	}
	

}
