package com.common.aop.dao;

import org.springframework.stereotype.Repository;

import com.common.transfer.object.entity.CommonAuditEntity;


@Repository
public interface IAuditMongoRepository extends org.springframework.data.mongodb.repository.MongoRepository<CommonAuditEntity,String>{
}
