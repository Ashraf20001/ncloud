package com.common.aop.interceptor;

import org.aspectj.lang.annotation.Pointcut;

public class CommonAopAspects {
	@Pointcut("(execution(* com.common.*.*.*(..)) && !(within(com.common..*dao*..*) || within(com.common..*daoImpl*..*)))")
	public void serviceLog() {}
	
	
	@Pointcut("@within(com.common.aop.annotation.Auditable)")
	public void auditAnnotation() {}
}
