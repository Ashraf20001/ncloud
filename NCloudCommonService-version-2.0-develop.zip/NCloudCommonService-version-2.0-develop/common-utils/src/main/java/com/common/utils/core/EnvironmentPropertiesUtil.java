package com.common.utils.core;

import org.springframework.context.annotation.Configuration;

import com.common.constants.serverproperties.PropertyValueProvider;

import lombok.RequiredArgsConstructor;

/**
 * The Class EnvironmentPropertiesUtil.
 */
@Configuration
@RequiredArgsConstructor
public class EnvironmentPropertiesUtil {
		
	/** The configuration properties. */
	private final PropertyValueProvider configurationProperties;
	
		
	/**
	 * Gets the time zone.
	 *
	 * @return the time zone
	 */
	public String getTimeZone() {
		return configurationProperties.getTimeZone();
	}
	
	/**
	 * Gets the date format.
	 *
	 * @return the date format
	 */
	public String getDateFormat() {
		return configurationProperties.getDateFormat();
	}
	
	/**
	 * Gets the currency format.
	 *
	 * @return the currency format
	 */
	public String getCurrencyFormat() {
		return configurationProperties.getCurrencyFormat();
	}
	
	/**
	 * Gets the country code.
	 *
	 * @return the country code
	 */
	public String getCountryCode() {
		return configurationProperties.getCountryCode();
	}

	/**
	 * Gets the bulk upload report loss path.
	 *
	 * @return the bulk upload report loss path
	 */
	public String getBulkUploadReportLossPath() {
		return configurationProperties.getBulkUploadReportlossPath();
	}

	/**
	 * Gets the approval limit notification url.
	 *
	 * @return the approval limit notification url
	 */
	public String getApprovalLimitNotificationUrl() {
		return configurationProperties.getApprovalLimitNotificationUrl();
	}
}