package com.common.utils;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.common.*")
public class CommonUtilsApplication {

	public static void main(String[] args) {

	}

}
