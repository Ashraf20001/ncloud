package com.common.utils.core;

import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import com.common.constants.core.ApplicationConstants;


/**
 * The Class RestTemplateUtils.
 */
@Component
public class RestTemplateUtils {
    
    /**
     * Gets the POST headers.
     *
     * @return the POST headers
     */
    public HttpHeaders getPOSTHeaders(){
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        return headers;
    }
    
    /**
     * Gets the gets the headers.
     *
     * @return the gets the headers
     */
    public HttpHeaders getGETHeaders(){
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        return headers;
    }
    
    /**
     * Configure rest template.
     *
     * @param request the request
     * @return the http headers
     */
	public HttpHeaders configureRestTemplate(HttpServletRequest request) {
		HttpHeaders httpHeaders = null;
		String authorizationHeader = request.getHeader(ApplicationConstants.AUTHORIZATION);
		String authToken = authorizationHeader.replace(ApplicationConstants.BEARER, ApplicationConstants.EMPTY_STRING)
				.trim();
		if(HttpMethod.GET.toString().equals(request.getMethod())) {
			httpHeaders = getGETHeaders();
		}else {
			httpHeaders = getPOSTHeaders();
		}
		httpHeaders.setBearerAuth(authToken);
		return httpHeaders;
	}
}
