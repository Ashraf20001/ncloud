package com.common.fileupload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuperAdminFileuploadApplicationTests {

	@Test
	void contextLoads() {
	}

}
