package com.common.fileupload.service.local;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.common.constants.core.ApplicationConstants;
import com.common.exception.core.ApplicationException;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;


@Service
public class FileUploadServiceLocal {

	@Value("${common.file-upload-path}")
	private String filePath;
	
	public  String saveFile(MultipartFile multipartFile,String claimId)
            throws IOException, ApplicationException {
        Path uploadPath = Paths.get(filePath);
          
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }
        String fileCode=null;
        if (claimId.equals(ApplicationConstants.NULL)) {
        	 fileCode = System.currentTimeMillis() + "_" + multipartFile.getOriginalFilename();
		}else {
			fileCode = claimId +"_"+ System.currentTimeMillis() + "_" + multipartFile.getOriginalFilename();
		}
        try (InputStream inputStream = multipartFile.getInputStream()) {
            Path filePath = uploadPath.resolve(fileCode);
            Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ioe) {       
            throw new IOException("Could not save file: " , ioe);
        }
         
        return fileCode;
    }
	
	
	private Path foundFile;
    
    public synchronized Resource getFileAsResource(String fileCode) throws IOException {
    	foundFile = null;
	
        Path dirPath = Paths.get(filePath);
         
        Files.list(dirPath).forEach(file -> {
            if (file.getFileName().toString().startsWith(fileCode)) {
                foundFile = file;
                return;
            }
        });
 
        if (foundFile != null) {
            return new UrlResource(foundFile.toUri());
        }
         
        return null;
    }
}
