package com.common.fileupload.handler;

import java.io.IOException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.common.constants.core.ApplicationConstants;
import com.common.exception.core.ApplicationException;
import com.common.fileupload.service.local.FileUploadServiceLocal;

import lombok.RequiredArgsConstructor;


@Component
@RequiredArgsConstructor
public class FileUploadHandler {
	
	@Value("${common.file-upload-storage-type}")
	private String storageType;
	
	private final FileUploadServiceLocal fileUploadService;
	
	
	public String uploadDocument(MultipartFile file,String claimId) throws IOException, ApplicationException {
		String fileName = null;
		if (storageType.equals(ApplicationConstants.LOCAL)) {
			 fileName = fileUploadService.saveFile(file,claimId);
		}
		
		return fileName;
		
	}
	
	public Resource downloadFile(String fileName) throws IOException {
		Resource fileAsResource = null;
		if (storageType.equals(ApplicationConstants.LOCAL)) {
			 fileAsResource = fileUploadService.getFileAsResource(fileName);
		}
		return fileAsResource;
		
	}

}
