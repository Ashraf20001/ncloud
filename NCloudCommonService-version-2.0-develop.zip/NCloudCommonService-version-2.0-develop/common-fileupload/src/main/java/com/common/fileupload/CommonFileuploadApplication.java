package com.common.fileupload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommonFileuploadApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommonFileuploadApplication.class, args);
	}

}
