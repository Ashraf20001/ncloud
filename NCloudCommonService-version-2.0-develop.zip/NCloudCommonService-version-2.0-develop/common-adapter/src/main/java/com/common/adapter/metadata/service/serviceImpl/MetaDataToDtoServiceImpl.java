package com.common.adapter.metadata.service.serviceImpl;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.common.adapter.service.metadata.MetaDataToDtoService;
import com.common.exception.core.ApplicationException;
import com.common.exception.core.codes.ErrorCodes;
import com.common.transfer.object.dto.DigitalPaperDto;
import com.common.transfer.object.entity.Field;
import com.common.transfer.object.entity.MetaData;
import com.common.transfer.object.entity.Section;
import com.common.transfer.object.vo.dto.DataTypeConstantsDto;
import com.common.transfer.object.vo.dto.FieldGroup;
import com.common.transfer.object.vo.dto.FieldValue;
import com.common.utils.core.ApplicationUtils;

/**
 * The Class MetaDataToDtoServiceImpl.
 */
@Service
public class MetaDataToDtoServiceImpl implements MetaDataToDtoService{
	
	/**
	 * Dto to field group.
	 *
	 * @param metaList the meta list
	 * @param digitalPaperDto the digital paper dto
	 * @return the field group
	 * @throws ApplicationException the application exception
	 */
	@Override
	 public FieldGroup dtoToFieldGroup(List<MetaData> metaList,DigitalPaperDto digitalPaperDto) throws ApplicationException {

	        if(metaList.isEmpty()){
	            throw new ApplicationException(ErrorCodes.INVALID_META_DATA);
	        }
	        FieldGroup fieldGroup = null;

	        FieldGroup actualfieldGroup = null;
	        for (MetaData mt : metaList) {
	            
	        	FieldValue fieldDto = getFieldData(mt,digitalPaperDto);
	        	actualfieldGroup = getInnerFieldGroup(mt.getSectionDetails(), fieldDto, null/*child*/);
	            fieldGroup = addChildFieldGroupIntoParentFieldGroup(actualfieldGroup, fieldGroup);
	        }


	        return fieldGroup;
	    }
	 
	 
	 /**
 	 * Gets the field data.
 	 *
 	 * @param metaData the meta data
 	 * @param digitalPaperDto the digital paper dto
 	 * @return the field data
 	 * @throws ApplicationException the application exception
 	 */
 	private FieldValue getFieldData(MetaData metaData, DigitalPaperDto digitalPaperDto) throws ApplicationException {
	        Field field = metaData.getFieldDetails();
	        FieldValue fieldValue=new FieldValue();
	        com.common.transfer.object.vo.dto.Field fieldDto = new com.common.transfer.object.vo.dto.Field();
	        if(ApplicationUtils.isValidateObject(field)){
	            fieldDto.setFieldId(field.getIdentity());
	            fieldDto.setFieldName(field.getFieldName());
	            fieldDto.setFieldType(field.getFieldType());
	            fieldDto.setAliasName(field.getAliasName());
	            fieldDto.setIsCoreData(field.getIsCoreData());
	            fieldDto.setMandatory(field.isMandatory());
	            fieldDto.setMinlength(field.getMinLength());
	            fieldDto.setMaxlength(field.getMaxLength());
	            fieldDto.setRegex(field.getRegex());
	            fieldDto.setReferenceId(field.getReferenceId());
	            fieldDto.setIsSystemGenerated(field.getIsSystemGenerated());
	            if (ApplicationUtils.isValidateObject(digitalPaperDto)){
	                try{
	                    java.lang.reflect.Field fields1 = digitalPaperDto.getClass().getDeclaredField(field.getFieldName());
	                    fields1.setAccessible(true);
	                    String str = fields1.get(digitalPaperDto).toString();
	                    if(field.getFieldType().equals(DataTypeConstantsDto.FDATE)|| field.getFieldType().equals(DataTypeConstantsDto.PDATE)){
	                        LocalDateTime ldt = LocalDateTime.parse(str);
	                        ZonedDateTime zdt = ldt.atZone(ZoneOffset.UTC);
	                        str = zdt.toString().replace('Z',' ').trim().concat(".000Z");
	                    }
	                    fieldDto.setValue(str);
	    	            fieldValue.setValue(str);

	                } catch (Exception e){}
	            }
	            fieldValue.setField(fieldDto);

	        }else {
	            throw new ApplicationException(ErrorCodes.INVALID_FIELD_DATA);
	        }
	        return fieldValue;
	    }
	 
	 
	 /**
 	 * Gets the inner field group.
 	 *
 	 * @param sectionDetails the section details
 	 * @param fieldDto the field dto
 	 * @param childFieldGroup the child field group
 	 * @return the inner field group
 	 * @throws ApplicationException the application exception
 	 */
 	private FieldGroup getInnerFieldGroup(Section sectionDetails, FieldValue fieldDto, FieldGroup childFieldGroup) throws ApplicationException {
	        if(sectionDetails == null) {
	            return childFieldGroup;
	        }
	        FieldGroup parentFieldGroup = new FieldGroup();
	        // required field for section
	        parentFieldGroup = getFieldGroupData(sectionDetails);
	        if(fieldDto != null) {
	            List<FieldValue> fieldDtoList = new ArrayList<>();
	            fieldDtoList.add(fieldDto);
	            parentFieldGroup.setFieldValues(fieldDtoList);
	        }
	        if (ApplicationUtils.isValidateObject(childFieldGroup)) {
	        	List<FieldGroup> fieldGroupList = new ArrayList<>();
	        	fieldGroupList.add(childFieldGroup);
	        	parentFieldGroup.setFieldGroups(fieldGroupList);
			}
	        return getInnerFieldGroup(sectionDetails.getSectionDetails(), null, parentFieldGroup);
	    }

	 
	 /**
 	 * Gets the field group data.
 	 *
 	 * @param section the section
 	 * @return the field group data
 	 * @throws ApplicationException the application exception
 	 */
 	private FieldGroup getFieldGroupData(Section section) throws ApplicationException {

		 FieldGroup fieldGroup = new FieldGroup();

	        if(ApplicationUtils.isValidateObject(section)){
	        	fieldGroup.setGroupName(section.getSectionName());
	        }else {
	            throw new ApplicationException(ErrorCodes.INVALID_SECTION_DATA);
	        }
	        return fieldGroup;
	    }
	 
	 
		/**
		 * Adds the child field group into parent field group.
		 *
		 * @param actualfieldGroup the actualfield group
		 * @param fieldGroup the field group
		 * @return the field group
		 */
		private FieldGroup addChildFieldGroupIntoParentFieldGroup(FieldGroup actualfieldGroup,
				FieldGroup fieldGroup) {

			if (fieldGroup == null) {
				FieldGroup list = new FieldGroup();
				list=(actualfieldGroup);
				return list;
			}

			boolean x = false;
			for (FieldGroup sec1 : fieldGroup.getFieldGroups()) {
				if (actualfieldGroup.getFieldGroups().get(0).getGroupName().equals(sec1.getGroupName())) {
					x = true;

						sec1.getFieldValues().add(actualfieldGroup.getFieldGroups().get(0).getFieldValues().get(0));
				}
			}
			if (!x) {
				fieldGroup.getFieldGroups().add(actualfieldGroup.getFieldGroups().get(0));
			}
			return fieldGroup;
		}
	  
}
