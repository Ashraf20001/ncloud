package com.common.adapter.service;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.poi.ss.formula.functions.T;
import org.springframework.stereotype.Component;

import com.common.transfer.object.entity.APIDetails;
import com.common.transfer.object.entity.APIPageMapping;
import com.common.transfer.object.entity.AllocationUserType;
import com.common.transfer.object.entity.Association;
import com.common.transfer.object.entity.BulkImportMapping;
import com.common.transfer.object.entity.DropDownList;
import com.common.transfer.object.entity.DropDownListOptionMapping;
import com.common.transfer.object.entity.Field;
import com.common.transfer.object.entity.FieldDropDownListMap;
import com.common.transfer.object.entity.Menu;
import com.common.transfer.object.entity.MetaData;
import com.common.transfer.object.entity.Page;
import com.common.transfer.object.entity.Platform;
import com.common.transfer.object.entity.Privilege;
import com.common.transfer.object.entity.PrivilegeApiMapping;
import com.common.transfer.object.entity.Role;
import com.common.transfer.object.entity.RoleMenuMapping;
import com.common.transfer.object.entity.RolePageMapping;
import com.common.transfer.object.entity.RolePrivilegeMapping;
import com.common.transfer.object.entity.RoleSectionMapping;
import com.common.transfer.object.entity.Section;
import com.common.transfer.object.entity.SystemProperty;
import com.common.transfer.object.entity.SystemPropertyValue;
import com.common.transfer.object.entity.UserCompanyMapping;
import com.common.transfer.object.entity.UserRoleMapping;
import com.common.transfer.object.entity.UserType;
import com.common.transfer.object.entity.Userprofile;
import com.common.transfer.object.reportloss.entity.Company;
import com.common.transfer.object.reportloss.entity.DropdownOptions;
import com.common.transfer.object.reportloss.entity.FieldOptionMapping;


/**
 * A factory for creating EntityTableMapping objects.
 */
@Component
public class EntityTableMappingFactory {
	
	/** The table entit map. */
	Map<String, Object> tableEntitMap = new HashMap<>();
	
	/**
	 * Entity table map.
	 */
	@PostConstruct
	void entityTableMap() {
		tableEntitMap.put("user_type", UserType.class);
		tableEntitMap.put("um_menu", Menu.class);
		tableEntitMap.put("um_api_details", APIDetails.class);
		tableEntitMap.put("system_property", SystemProperty.class);
		tableEntitMap.put("allocation_user_type", AllocationUserType.class);
		tableEntitMap.put("association", Association.class);
		tableEntitMap.put("bulk_import_mapping", BulkImportMapping.class);
		tableEntitMap.put("dropdownlist", DropDownList.class);
		tableEntitMap.put("dropdown_options", DropdownOptions.class);
		tableEntitMap.put("dropdownlist_option_map", DropDownListOptionMapping.class);
		
		tableEntitMap.put("section", Section.class);
		tableEntitMap.put("platform", Platform.class);
		tableEntitMap.put("user_role", Role.class);
		tableEntitMap.put("rl_company", Company.class);
		tableEntitMap.put("page", Page.class);
		tableEntitMap.put("rp_user_role", UserRoleMapping.class);
		tableEntitMap.put("um_page_api_mapping", APIPageMapping.class);
		tableEntitMap.put("um_role_page_mapping", RolePageMapping.class);
		tableEntitMap.put("user_company_mapping", UserCompanyMapping.class);
		tableEntitMap.put("um_role_section_mapping", RoleSectionMapping.class);
		tableEntitMap.put("field", Field.class);
		tableEntitMap.put("field_dropdown_map", FieldDropDownListMap.class);
		tableEntitMap.put("field_option_mapping", FieldOptionMapping.class);
		tableEntitMap.put("um_privilege", Privilege.class);
		tableEntitMap.put("um_role_privilege_mapping", RolePrivilegeMapping.class);
		tableEntitMap.put("um_role_menu_mapping", RoleMenuMapping.class);
		tableEntitMap.put("system_property", SystemProperty.class);
		tableEntitMap.put("rp_login_user", Userprofile.class);
		tableEntitMap.put("um_role_menu_mapping", RoleMenuMapping.class);
		tableEntitMap.put("system_property_value", SystemPropertyValue.class);
		tableEntitMap.put("privilege_api_mapping", PrivilegeApiMapping.class);
		tableEntitMap.put("meta_data", MetaData.class);
	}
	
	/**
	 * Gets the entity class by table name.
	 *
	 * @param tableName the table name
	 * @return the entity class by table name
	 */
	@SuppressWarnings("unchecked")
	public Class<T> getEntityClassByTableName(String tableName) {
		return (Class<T>)tableEntitMap.get(tableName);
	}

}
