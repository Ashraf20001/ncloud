package com.common.adapter.service.metadata;

import java.util.List;

import com.common.exception.core.ApplicationException;
import com.common.transfer.object.dto.DigitalPaperDto;
import com.common.transfer.object.entity.MetaData;
import com.common.transfer.object.vo.dto.FieldGroup;

/**
 * The Interface MetaDataToDtoService.
 */
public interface MetaDataToDtoService {
	
	/**
	 * Dto to field group.
	 *
	 * @param metaList the meta list
	 * @param reportLossViewDto the report loss view dto
	 * @return the field group
	 * @throws ApplicationException the application exception
	 */
	public FieldGroup dtoToFieldGroup(List<MetaData> metaList,DigitalPaperDto reportLossViewDto) throws ApplicationException;
}
