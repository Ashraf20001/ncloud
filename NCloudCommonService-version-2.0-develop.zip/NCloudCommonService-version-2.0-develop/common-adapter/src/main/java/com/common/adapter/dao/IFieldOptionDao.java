package com.common.adapter.dao;

import java.util.List;

import com.common.exception.core.ApplicationException;
import com.common.transfer.object.reportloss.entity.FieldOptionMapping;

/**
 * The Interface IFieldOptionDao.
 */
public interface IFieldOptionDao {

	/**
	 * Gets the field options.
	 *
	 * @param fieldId the field id
	 * @return the field options
	 */
	List<FieldOptionMapping> getFieldOptions(String fieldId);

	/**
	 * Save field option mapping.
	 *
	 * @param fieldOptionMapping the field option mapping
	 * @return the field option mapping
	 * @throws ApplicationException the application exception
	 */
	public FieldOptionMapping saveFieldOptionMapping(FieldOptionMapping fieldOptionMapping) throws ApplicationException;

	/**
	 * Update field option mapping.
	 *
	 * @param option the option
	 * @return the field option mapping
	 * @throws ApplicationException the application exception
	 */
	public FieldOptionMapping updateFieldOptionMapping(FieldOptionMapping option) throws ApplicationException;

	/**
	 * Gets the field option mapping.
	 *
	 * @param fieldId the field id
	 * @return the field option mapping
	 * @throws ApplicationException the application exception
	 */
	List<FieldOptionMapping> getFieldOptionMapping(Integer fieldId) throws ApplicationException;

}
