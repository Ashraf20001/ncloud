package com.common.adapter.service.metadata;

import java.util.List;

import com.common.exception.core.ApplicationException;
import com.common.transfer.object.dto.GarageDto;
import com.common.transfer.object.dto.MetaDataViewDto;
import com.common.transfer.object.dto.companyViewDto;
import com.common.transfer.object.entity.MetaData;
import com.common.transfer.object.reportloss.dto.ReportLossViewDto;

/**
 * The Interface IMetaDataViewService.
 */
public interface IMetaDataViewService {
    
    /**
     * Convert meta data entity into DTO.
     *
     * @param metaList the meta list
     * @param reportLossViewDto the report loss view dto
     * @return the meta data view dto
     * @throws ApplicationException the application exception
     */
    public MetaDataViewDto convertMetaDataEntityIntoDTO(List<MetaData> metaList, ReportLossViewDto reportLossViewDto) throws ApplicationException;

	/**
	 * Convert meta data entity into DTO insurance company.
	 *
	 * @param metaList the meta list
	 * @param companyDto the company dto
	 * @return the meta data view dto
	 * @throws ApplicationException the application exception
	 */
	MetaDataViewDto convertMetaDataEntityIntoDTOInsuranceCompany(List<MetaData> metaList, companyViewDto companyDto)
			throws ApplicationException;

	/**
	 * Convert meta data entity into DTO garage.
	 *
	 * @param metaList the meta list
	 * @param garagedto the garagedto
	 * @return the meta data view dto
	 * @throws ApplicationException the application exception
	 */
	MetaDataViewDto convertMetaDataEntityIntoDTOGarage(List<MetaData> metaList, GarageDto garagedto)
			throws ApplicationException;

    /**
     * Convert meta data entity into user mgmt DTO.
     *
     * @param metaList the meta list
     * @param viewDto the view dto
     * @return the meta data view dto
     * @throws ApplicationException the application exception
     */
    MetaDataViewDto convertMetaDataEntityIntoUserMgmtDTO(List<MetaData> metaList, Object viewDto) throws ApplicationException;

}
