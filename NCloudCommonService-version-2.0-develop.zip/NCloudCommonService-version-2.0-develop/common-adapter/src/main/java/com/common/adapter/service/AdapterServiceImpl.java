package com.common.adapter.service;

import java.lang.reflect.Method;
import java.util.List;
import org.springframework.stereotype.Service;

import com.common.exception.core.ApplicationException;
import com.common.exception.core.codes.ErrorCodes;
import com.common.transfer.object.vo.dto.DataTypeConstantsDto;
import com.common.transfer.object.vo.dto.FieldGroup;
import com.common.transfer.object.vo.dto.FieldValue;
import com.common.transfer.object.vo.dto.IConfigurable;
import com.common.utils.core.ApplicationUtils;

import lombok.RequiredArgsConstructor;

/**
 * The Class AdapterServiceImpl.
 */
@Service
@RequiredArgsConstructor
public class AdapterServiceImpl implements IAdapterService {
	
/** The Constant SET. */
private static final String SET = "set";
	
	/** The config. */
	private final FieldMapperInstanceConfig config;
	
	/** The class mapper. */
	private final FieldClassMapper classMapper;
	
	/** The converter factory. */
	private final DataConverterFactory converterFactory;
	
	/**
	 * Builds the field group.
	 *
	 * @param data the data
	 * @return the i configurable
	 * @throws ApplicationException the application exception
	 */
	@Override
	public IConfigurable buildFieldGroup(FieldGroup data) throws ApplicationException {
		String baseClassName = data.getGroupName();
		
		Class<?> baseClass = config.getClass(baseClassName);
		IConfigurable baseObject = config.getObject(baseClass);
		
		buildFieldValues(data, baseClass, baseObject);

		List<FieldGroup> fieldGroups = data.getFieldGroups();
		if(fieldGroups != null) {
			for (FieldGroup subGroup : fieldGroups) {
				buildSubFieldValue(subGroup,baseClass, baseObject);
			}
		}
		
		System.out.println(baseObject);
		return baseObject;
	}
	
	/**
	 * Builds the field values.
	 *
	 * @param data the data
	 * @param clss the clss
	 * @param object the object
	 * @throws ApplicationException the application exception
	 */
	public void buildFieldValues(FieldGroup data, Class<?> clss, IConfigurable object) throws ApplicationException {
		for (FieldValue fieldValue : data.getFieldValues()) {
			String fieldName = fieldValue.getField().getFieldName();
			String value = fieldValue.getValue();
			String fieldType = fieldValue.getField().getFieldType();
			setSubGroupValue(fieldName, fieldType, value, null, clss, object);
		}
	}
	
	/**
	 * Builds the sub field value.
	 *
	 * @param subGroup the sub group
	 * @param parentCls the parent cls
	 * @param parentObject the parent object
	 * @throws ApplicationException the application exception
	 */
	public void buildSubFieldValue(FieldGroup subGroup, Class<?> parentCls, IConfigurable parentObject) throws ApplicationException {
		String subGroupName = subGroup.getGroupName();
		for(FieldValue fieldValue: subGroup.getFieldValues()) {
			String fieldName = fieldValue.getField().getFieldName();
			String value = fieldValue.getValue();
			String fieldType = fieldValue.getField().getFieldType();
			setSubGroupValue(fieldName, fieldType, value, subGroupName, parentCls, parentObject);
		}
		List<FieldGroup> innerFieldGroups = subGroup.getFieldGroups();
		if(innerFieldGroups != null) {
			for(FieldGroup innerGroup: innerFieldGroups) {
				buildSubFieldValue(innerGroup, parentCls, parentObject,innerGroup.getGroupName());
			}
		}
	}
	
	/**
	 * Builds the sub field value.
	 *
	 * @param subGroup the sub group
	 * @param parentCls the parent cls
	 * @param parentObject the parent object
	 * @param subGroupName the sub group name
	 * @throws ApplicationException the application exception
	 */
	public void buildSubFieldValue(FieldGroup subGroup, Class<?> parentCls, IConfigurable parentObject,String subGroupName) throws ApplicationException {
		for(FieldValue fieldValue: subGroup.getFieldValues()) {
			String fieldName = fieldValue.getField().getFieldName();
			String value = fieldValue.getValue();
			String fieldType = fieldValue.getField().getFieldType();
			setSubGroupValue(fieldName, fieldType, value, subGroupName, parentCls, parentObject);
		}
		List<FieldGroup> innerFieldGroups = subGroup.getFieldGroups();
		if(innerFieldGroups != null) {
			for(FieldGroup innerGroup: innerFieldGroups) {
				buildSubFieldValue(innerGroup, parentCls, parentObject,innerGroup.getGroupName());
			}
		}
	}

	/**
	 * Sets the sub group value.
	 *
	 * @param fieldName the field name
	 * @param fieldType the field type
	 * @param value the value
	 * @param groupName the group name
	 * @param parentClass the parent class
	 * @param parentObject the parent object
	 * @throws ApplicationException the application exception
	 */
	private void setSubGroupValue(String fieldName, String fieldType, String value, String groupName, Class<?> parentClass, IConfigurable parentObject) throws ApplicationException {
		String setMethodName = getSetMethodName(fieldName, groupName);
		String temp=fieldType;
		try {
			if (!ApplicationUtils.isValidString(value)){
				return;
			}
			if(fieldType.equals(DataTypeConstantsDto.DROPDOWN)
					|| fieldType.equals(DataTypeConstantsDto.TEXT)
					|| fieldType.equals(DataTypeConstantsDto.MULTI_SELECT)
					|| fieldType.equals(DataTypeConstantsDto.DOWNLOAD)
					|| fieldType.equals(DataTypeConstantsDto.FILE)
							|| fieldType.equals(DataTypeConstantsDto.PASSWORD)){
				temp=DataTypeConstantsDto.STRING;
			}
			if(fieldType.equals(DataTypeConstantsDto.FDATE)||fieldType.equals(DataTypeConstantsDto.PDATE)){
				temp=DataTypeConstantsDto.LOCAL_DATE_TIME;
			}
			if(fieldType.equals(DataTypeConstantsDto.CHECKBOX)|| fieldType.equals(DataTypeConstantsDto.TOGGLE)){
				temp=DataTypeConstantsDto.BOOLEAN;
			}
			if(fieldType.equals(DataTypeConstantsDto.LONG)){
				temp=DataTypeConstantsDto.LONG;
			}
			
			
			Class<?> fieldTypeClass = classMapper.getClass(temp);
			Method setMethod = parentClass.getMethod(setMethodName, fieldTypeClass);
			Object convertedValue = converterFactory.dataConverter(fieldType, value);
			setMethod.invoke(parentObject, convertedValue);
		} catch (Exception e) {
			System.out.println("Error in setter method: " + e);
			throw new ApplicationException(ErrorCodes.INVALID_DATA);
		}
	}
	
	/**
	 * Gets the sets the method name.
	 *
	 * @param fieldName the field name
	 * @param groupName the group name
	 * @return the sets the method name
	 */
	private String getSetMethodName(String fieldName, String groupName) {
		String fieldName1 = fieldName.substring(0, 1).toUpperCase();
		String fieldName2 = fieldName.substring(1, fieldName.length());
		String setMethodName = "";
		if(groupName != null) {
			String prefix = config.getPrefix(groupName);
			if(prefix != null) {
				setMethodName = SET  + fieldName1 + fieldName2;
			} else {
				setMethodName = SET + fieldName1 + fieldName2;
			}
		} else {
			setMethodName = SET + fieldName1 + fieldName2;
		}
		return setMethodName;
	}
	

}
