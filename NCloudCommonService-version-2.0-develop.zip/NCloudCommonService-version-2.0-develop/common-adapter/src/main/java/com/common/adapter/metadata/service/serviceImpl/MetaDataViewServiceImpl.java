package com.common.adapter.metadata.service.serviceImpl;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.stereotype.Service;

import com.common.adapter.dao.IFieldOptionDao;
import com.common.adapter.service.metadata.IMetaDataViewService;
import com.common.constants.enums.SectionEnum;
import com.common.exception.core.ApplicationException;
import com.common.exception.core.codes.ErrorCodes;
import com.common.transfer.object.dto.FieldDto;
import com.common.transfer.object.dto.GarageDto;
import com.common.transfer.object.dto.MetaDataViewDto;
import com.common.transfer.object.dto.SectionDto;
import com.common.transfer.object.dto.companyViewDto;
import com.common.transfer.object.entity.Field;
import com.common.transfer.object.entity.MetaData;
import com.common.transfer.object.entity.Section;
import com.common.transfer.object.reportloss.dto.ReportLossViewDto;
import com.common.transfer.object.reportloss.entity.FieldOptionMapping;
import com.common.transfer.object.vo.dto.DataTypeConstantsDto;
import com.common.utils.core.ApplicationUtils;

import lombok.RequiredArgsConstructor;

/**
 * The Class MetaDataViewServiceImpl.
 */
@Service
@RequiredArgsConstructor
public class MetaDataViewServiceImpl implements IMetaDataViewService {
    
	/** The field option dao. */
	private final IFieldOptionDao fieldOptionDao;

    /**
     * Convert meta data entity into DTO.
     *
     * @param metaList the meta list
     * @param reportLossViewDto the report loss view dto
     * @return the meta data view dto
     * @throws ApplicationException the application exception
     */
    @Override
    public MetaDataViewDto convertMetaDataEntityIntoDTO(List<MetaData> metaList,ReportLossViewDto reportLossViewDto) throws ApplicationException {

        if(metaList.isEmpty()){
            throw new ApplicationException(ErrorCodes.INVALID_META_DATA);
        }
        MetaDataViewDto output = new MetaDataViewDto();
        List<SectionDto> sectionDtoList = null;

        SectionDto actualSectionData = null;
        for (MetaData mt : metaList) {
            
            FieldDto fieldDto = getFieldData(mt,reportLossViewDto);
            actualSectionData = getInnerSection(mt.getSectionDetails(), fieldDto, null/*child*/);
            sectionDtoList = AddSectionIntoMetaDataViewDto(actualSectionData, sectionDtoList);
        }
        output.setPageId(metaList.get(0).getPageDetails().getIdentity());
        output.setPageName(metaList.get(0).getPageDetails().getPageName());
      
        setSectionFilledStatus(sectionDtoList, reportLossViewDto.getSectionName());
        output.setSectionList(sectionDtoList);

        return output;
    }
    
    /**
     * Convert meta data entity into DTO insurance company.
     *
     * @param metaList the meta list
     * @param companyDto the company dto
     * @return the meta data view dto
     * @throws ApplicationException the application exception
     */
    @Override
    public MetaDataViewDto convertMetaDataEntityIntoDTOInsuranceCompany(List<MetaData> metaList,companyViewDto companyDto) throws ApplicationException {

        if(metaList.isEmpty()){
            throw new ApplicationException(ErrorCodes.INVALID_META_DATA);
        }
        MetaDataViewDto output = new MetaDataViewDto();
        List<SectionDto> sectionDtoList = null;

        SectionDto actualSectionData = null;
        for (MetaData mt : metaList) {
            
            FieldDto fieldDto = getFieldDataInsuranceCompany(mt,companyDto);
            actualSectionData = getInnerSection(mt.getSectionDetails(), fieldDto, null/*child*/);
            sectionDtoList = CommonAddSectionIntoMetaDataViewDto(actualSectionData, sectionDtoList);
        }
        output.setPageId(metaList.get(0).getPageDetails().getIdentity());
        output.setPageName(metaList.get(0).getPageDetails().getPageName());
        output.setSectionList(sectionDtoList);

        return output;
    }
    
    /**
     * Convert meta data entity into DTO garage.
     *
     * @param metaList the meta list
     * @param garagedto the garagedto
     * @return the meta data view dto
     * @throws ApplicationException the application exception
     */
    @Override
    public MetaDataViewDto convertMetaDataEntityIntoDTOGarage(List<MetaData> metaList,GarageDto garagedto) throws ApplicationException {

        if(metaList.isEmpty()){
            throw new ApplicationException(ErrorCodes.INVALID_META_DATA);
        }
        MetaDataViewDto output = new MetaDataViewDto();
        List<SectionDto> sectionDtoList = null;

        SectionDto actualSectionData = null;
        for (MetaData mt : metaList) {
            
            FieldDto fieldDto = getFieldDataGarage(mt,garagedto);
            actualSectionData = getInnerSection(mt.getSectionDetails(), fieldDto, null/*child*/);
            sectionDtoList = CommonAddSectionIntoMetaDataViewDto(actualSectionData, sectionDtoList);
        }
        output.setPageId(metaList.get(0).getPageDetails().getIdentity());
        output.setPageName(metaList.get(0).getPageDetails().getPageName());
        output.setSectionList(sectionDtoList);

        return output;
    }

    
	/**
	 * Common add section into meta data view dto.
	 *
	 * @param actualSectionData the actual section data
	 * @param sectionDtoList the section dto list
	 * @return the list
	 */
	private List<SectionDto> CommonAddSectionIntoMetaDataViewDto(SectionDto actualSectionData,
			List<SectionDto> sectionDtoList) {

		if (sectionDtoList == null) {
			List<SectionDto> list = new ArrayList<>();
			list.add(actualSectionData);
			return list;
		}
		
		boolean x = false, y = false, z = false;
		for (SectionDto sec1 : sectionDtoList) {
			if (actualSectionData.getSectionName().equals(sec1.getSectionName())) {
				x = true;
				for (SectionDto sec2 : sec1.getSectionList()) {
					if (sec2!=null && actualSectionData.getSectionList().get(0).getSectionName()
							.equals(sec2.getSectionName())) {
						y = true;
						if (actualSectionData.getSectionList().get(0).getSectionList().get(0) == null
								&& sec2.getSectionList().get(0) == null) {
							sec2.getFieldList().add(actualSectionData.getSectionList().get(0).getFieldList().get(0));
						}
						else if (actualSectionData.getSectionList().get(0).getSectionList().get(0) != null
								&& sec2.getSectionList().get(0) != null) {
							for (SectionDto sec3 : sec2.getSectionList()) {
								if (Objects.equals(actualSectionData.getSectionList().get(0).getSectionList().get(0)
										.getSectionName(), sec3.getSectionName())) {
									sec3.getFieldList().add(actualSectionData.getSectionList().get(0).getSectionList()
											.get(0).getFieldList().get(0));
								}
							}
						}
					}
				}
				if (!y) {
					if(actualSectionData.getFieldList()!=null) {
				sec1.getFieldList().add(actualSectionData.getFieldList().get(0));
					}
					if (actualSectionData.getSectionList().get(0) != null)
						sec1.getSectionList().add(actualSectionData.getSectionList().get(0));
				}
				
			}
		}
		if (!x) {
			sectionDtoList.add(actualSectionData);
			
		}
		return sectionDtoList;
	}
	
	
    /**
     * Sets the section filled status.
     *
     * @param sectionList the section list
     * @param savedSectionName the saved section name
     */
    private void setSectionFilledStatus(List<SectionDto> sectionList, String savedSectionName) {
    	for(SectionDto section: sectionList) {
    		if(section != null) {
	    		boolean isFilled = true;
	    		if(section.getSectionList() != null && section.getSectionList().size() > 0) {
	    			setSectionFilledStatus(section.getSectionList(), savedSectionName);
	    		}
	    		boolean isBefore = isSectionBeforeSaved(savedSectionName, section.getSectionName());
	    		if(isBefore && section.getFieldList() != null && section.getFieldList().size() > 0) {
	    			List<FieldDto> mandatoryFieldList = section.getFieldList().stream().filter(field -> field.isMandatory()).toList();
	    			if(mandatoryFieldList == null || mandatoryFieldList.isEmpty()) {
	    				boolean isAllFilled = false;
	    				for(FieldDto field: section.getFieldList()) {
	    					isAllFilled = isAllFilled | (field.getValue() != null && !field.getValue().endsWith("/"));
	    				}
	    				isFilled = isAllFilled;
	    			} else {
		    			for(FieldDto field: mandatoryFieldList) {
		    				if(field.isMandatory() && field.getValue() == null) {
		    					isFilled = false;
		    					break;
		    				}
		    			}
	    			}
	    		}
	    		section.setIsAllFilled(isBefore && isFilled);
    		}
    	}
    }
    
    /**
     * Checks if is section before saved.
     *
     * @param savedSectionName the saved section name
     * @param currentSectionName the current section name
     * @return true, if is section before saved
     */
    private boolean isSectionBeforeSaved(String savedSectionName, String currentSectionName) {
    	boolean result = false;
    	if(ApplicationUtils.isValidString(savedSectionName) && ApplicationUtils.isValidString(currentSectionName)) {
	    	savedSectionName = savedSectionName.replace(' ', '_');
	    	currentSectionName = currentSectionName.replace(' ', '_');
	    	List<String> sectionList = Stream.of(SectionEnum.values()).map(Enum::toString).collect(Collectors.toList());
	    	int savedIndex = sectionList.indexOf(savedSectionName);
	    	int currentIndex = sectionList.indexOf(currentSectionName);
	    	result = currentIndex <= savedIndex;
    	}
    	return result;
    }
    
/**
 * Gets the field option mapping.
 *
 * @param fieldId the field id
 * @return the field option mapping
 */
//  get the dropdown data
    private String getFieldOptionMapping(String fieldId) {
        List<FieldOptionMapping> fieldOptionMapping = fieldOptionDao.getFieldOptions(fieldId);
        if (!fieldOptionMapping.isEmpty()){
            List<String> optionsList = new ArrayList<>();
            for (FieldOptionMapping f : fieldOptionMapping){
            	if(f.getDropdownOptions() != null) {
                    optionsList.add(f.getDropdownOptions().getDropdownOption());
            	}
            }
            String str = optionsList.toString().replace(", ", ",");
            return str.substring(1,str.length()-1);
        }
        return fieldOptionMapping.toString();
    }

    /**
     * Adds the section into meta data view dto.
     *
     * @param actualSectionData the actual section data
     * @param sectionDtoList the section dto list
     * @return the list
     */
    private List<SectionDto> AddSectionIntoMetaDataViewDto(SectionDto actualSectionData,
                                                           List<SectionDto> sectionDtoList) {

        if(sectionDtoList==null){
            List<SectionDto> list = new ArrayList<>();
            list.add(actualSectionData);
            return list;
        }

        boolean x=false, y=false, z=false;
        for (SectionDto sec1:sectionDtoList){
            if(actualSectionData.getSectionName().equals(sec1.getSectionName())){
                x=true;
                for (SectionDto sec2: sec1.getSectionList()){
                    if (actualSectionData.getSectionList().get(0).getSectionName().equals(sec2.getSectionName())){
                        y=true;
//                        check both having 1 sub sections
                        if (actualSectionData.getSectionList().get(0).getSectionList().get(0)==null
                                && sec2.getSectionList().get(0)==null){
                            sec2.getFieldList().add(actualSectionData.getSectionList().get(0).getFieldList().get(0));
                        }
                        //check 2nd sub section
                        else if(actualSectionData.getSectionList().get(0).getSectionList().get(0)!=null
                                && sec2.getSectionList().get(0)!=null){
                            for(SectionDto sec3: sec2.getSectionList()){
                                if(Objects.equals(actualSectionData.getSectionList().get(0).getSectionList().get(0).getSectionName(), sec3.getSectionName())){
                                    sec3.getFieldList().add(actualSectionData.getSectionList().get(0).getSectionList().get(0).getFieldList().get(0));
                                }
                            }
                        }
                    }
                }
                if(!y){
                    sec1.getSectionList().add(actualSectionData.getSectionList().get(0));
                }
            }
        }
        if (!x){
            sectionDtoList.add(actualSectionData);
        }
        return sectionDtoList;
    }

    /**
     * Gets the inner section.
     *
     * @param sectionDetails the section details
     * @param fieldDto the field dto
     * @param childSection the child section
     * @return the inner section
     * @throws ApplicationException the application exception
     */
    private SectionDto getInnerSection(Section sectionDetails, FieldDto fieldDto, SectionDto childSection) throws ApplicationException {
        if(sectionDetails == null) {
            return childSection;
        }
        SectionDto parentSectionDto = new SectionDto();
        // required field for section
        parentSectionDto = getSectionData(sectionDetails);
        if(fieldDto != null) {
            List<FieldDto> fieldDtoList = new ArrayList<>();
            fieldDtoList.add(fieldDto);
            parentSectionDto.setFieldList(fieldDtoList);
        }
        List<SectionDto> sectionDtoList = new ArrayList<>();
        sectionDtoList.add(childSection);
        parentSectionDto.setSectionList(sectionDtoList);
        return getInnerSection(sectionDetails.getSectionDetails(), null, parentSectionDto);
    }

    /**
     * Gets the field data.
     *
     * @param metaData the meta data
     * @param reportLossViewDto the report loss view dto
     * @return the field data
     * @throws ApplicationException the application exception
     */
    private FieldDto getFieldData(MetaData metaData, ReportLossViewDto reportLossViewDto) throws ApplicationException {
        Field field = metaData.getFieldDetails();
        FieldDto fieldDto = new FieldDto();
        if(ApplicationUtils.isValidateObject(field)){
            fieldDto.setFieldId(field.getIdentity());
            fieldDto.setFieldName(field.getFieldName());
            fieldDto.setFieldType(field.getFieldType());
            fieldDto.setAliasName(field.getAliasName());
            fieldDto.setIsCoreData(field.getIsCoreData());
            fieldDto.setMandatory(field.isMandatory());
            fieldDto.setEntityName(metaData.getEntity());
            fieldDto.setColumnName(metaData.getColumn());
            fieldDto.setMinLength(field.getMinLength());
            fieldDto.setMaxLength(field.getMaxLength());
            fieldDto.setRegex(field.getRegex());
            fieldDto.setReferenceId(field.getReferenceId());
            fieldDto.setIsSystemGenerated(field.getIsSystemGenerated());
            if (ApplicationUtils.isValidateObject(reportLossViewDto)){
                try{
                    java.lang.reflect.Field fields1 = reportLossViewDto.getClass().getDeclaredField(field.getFieldName());
                    fields1.setAccessible(true);
                    String str = fields1.get(reportLossViewDto).toString();
                    if(field.getFieldType().equals(DataTypeConstantsDto.FDATE)|| field.getFieldType().equals(DataTypeConstantsDto.PDATE)){
                        LocalDateTime ldt = LocalDateTime.parse(str);
                        ZonedDateTime zdt = ldt.atZone(ZoneOffset.UTC);
                        str = zdt.toString().replace('Z',':').concat("00.000Z");
                    }
                    fieldDto.setValue(str);

                } catch (Exception e){}
            }
        }else {
            throw new ApplicationException(ErrorCodes.INVALID_FIELD_DATA);
        }
        return fieldDto;
    }
    
    /**
     * Gets the field data insurance company.
     *
     * @param metaData the meta data
     * @param companyDto the company dto
     * @return the field data insurance company
     * @throws ApplicationException the application exception
     */
    private FieldDto getFieldDataInsuranceCompany(MetaData metaData, companyViewDto companyDto) throws ApplicationException {
        Field field = metaData.getFieldDetails();
        FieldDto fieldDto = new FieldDto();
        if(ApplicationUtils.isValidateObject(field)){
        	fieldDto=getField(field,metaData);

            if (ApplicationUtils.isValidateObject(companyDto)){
                try{
                    java.lang.reflect.Field fields1 = companyDto.getClass().getDeclaredField(field.getFieldName());
                    fields1.setAccessible(true);
                    String str = fields1.get(companyDto).toString();
                    if(field.getFieldType().equals(DataTypeConstantsDto.FDATE)|| field.getFieldType().equals(DataTypeConstantsDto.PDATE)){
                        LocalDateTime ldt = LocalDateTime.parse(str);
                        ZonedDateTime zdt = ldt.atZone(ZoneOffset.UTC);
                        str = zdt.toString().replace('Z',':').concat("00.000Z");
                    }
                    fieldDto.setValue(str);

                } catch (Exception e){}
            }

        }else {
            throw new ApplicationException(ErrorCodes.INVALID_FIELD_DATA);
        }
        return fieldDto;
    }
    
    /**
     * Gets the field data garage.
     *
     * @param metaData the meta data
     * @param garagedto the garagedto
     * @return the field data garage
     * @throws ApplicationException the application exception
     */
    private FieldDto getFieldDataGarage(MetaData metaData, GarageDto garagedto) throws ApplicationException {
        Field field = metaData.getFieldDetails();
        FieldDto fieldDto = new FieldDto();
        if(ApplicationUtils.isValidateObject(field)){
        	fieldDto=getField(field,metaData);
         if (ApplicationUtils.isValidateObject(garagedto)){
                try{
                    java.lang.reflect.Field fields1 = garagedto.getClass().getDeclaredField(field.getFieldName());
                    fields1.setAccessible(true);
                    String str = fields1.get(garagedto).toString();
                    if(field.getFieldType().equals(DataTypeConstantsDto.FDATE)|| field.getFieldType().equals(DataTypeConstantsDto.PDATE)){
                        LocalDateTime ldt = LocalDateTime.parse(str);
                        ZonedDateTime zdt = ldt.atZone(ZoneOffset.UTC);
                        str = zdt.toString().replace('Z',':').concat("00.000Z");
                    }
                    fieldDto.setValue(str);

                } catch (Exception e){}
            }

        }else {
            throw new ApplicationException(ErrorCodes.INVALID_FIELD_DATA);
        }
        return fieldDto;
    }
    
    /**
     * Gets the field.
     *
     * @param field the field
     * @param metaData the meta data
     * @return the field
     */
    private FieldDto getField(Field field,MetaData metaData) {
    	FieldDto fieldDto = new FieldDto();
    	  fieldDto.setFieldId(field.getIdentity());
          fieldDto.setFieldName(field.getFieldName());
          fieldDto.setFieldType(field.getFieldType());
          fieldDto.setAliasName(field.getAliasName());
          fieldDto.setIsCoreData(field.getIsCoreData());
          fieldDto.setMandatory(field.isMandatory());
          fieldDto.setEntityName(metaData.getEntity());
          fieldDto.setColumnName(metaData.getColumn());
          fieldDto.setMinLength(field.getMinLength());
          fieldDto.setMaxLength(field.getMaxLength());
          fieldDto.setRegex(field.getRegex());
		return fieldDto;
    }
    
    /**
     * Gets the section data.
     *
     * @param section the section
     * @return the section data
     * @throws ApplicationException the application exception
     */
    private SectionDto getSectionData(Section section) throws ApplicationException {

        SectionDto sectionDto = new SectionDto();

        if(ApplicationUtils.isValidateObject(section)){
            sectionDto.setSectionId(section.getIdentity());
            sectionDto.setSectionName(section.getSectionName());
            sectionDto.setIsEnabled(section.getIsEnabled());
        }else {
            throw new ApplicationException(ErrorCodes.INVALID_SECTION_DATA);
        }
        return sectionDto;
    }

    /**
     * Convert meta data entity into user mgmt DTO.
     *
     * @param metaList the meta list
     * @param userRoleMgmtViewDto the user role mgmt view dto
     * @return the meta data view dto
     * @throws ApplicationException the application exception
     */
    @Override
    public MetaDataViewDto convertMetaDataEntityIntoUserMgmtDTO(List<MetaData> metaList, Object userRoleMgmtViewDto) throws ApplicationException {

        if(metaList.isEmpty()){
            throw new ApplicationException(ErrorCodes.INVALID_META_DATA);
        }
        MetaDataViewDto output = new MetaDataViewDto();
        List<SectionDto> sectionDtoList = null;

        //get parent section list
        SectionDto actualSectionData = null;
        for (MetaData mt : metaList) {
            //get field dto from each metadata
            FieldDto fieldDto = getFieldDataFromRoleMgmt(mt,userRoleMgmtViewDto);
            actualSectionData = getInnerSection(mt.getSectionDetails(), fieldDto, null/*child*/);
            sectionDtoList = AddSectionIntoMetaDataViewDtoForUserMgmt(actualSectionData, sectionDtoList);
        }
        output.setPageId(metaList.get(0).getPageDetails().getIdentity());
        output.setPageName(metaList.get(0).getPageDetails().getPageName());
        output.setSectionList(sectionDtoList);

        return output;
    }
    
    /**
     * Gets the field data from role mgmt.
     *
     * @param mt the mt
     * @param userRoleMgmtViewDto the user role mgmt view dto
     * @return the field data from role mgmt
     * @throws ApplicationException the application exception
     */
    private FieldDto getFieldDataFromRoleMgmt(MetaData mt, Object userRoleMgmtViewDto) throws ApplicationException {
        Field field = mt.getFieldDetails();
        FieldDto fieldDto = new FieldDto();
        if(ApplicationUtils.isValidateObject(field)){
            fieldDto.setFieldId(field.getIdentity());
            fieldDto.setFieldName(field.getFieldName());
            fieldDto.setFieldType(field.getFieldType());
            fieldDto.setAliasName(field.getAliasName());
            fieldDto.setIsCoreData(field.getIsCoreData());
            fieldDto.setMandatory(field.isMandatory());
            fieldDto.setEntityName(mt.getEntity());
            fieldDto.setColumnName(mt.getColumn());
            fieldDto.setMinLength(field.getMinLength());
            fieldDto.setMaxLength(field.getMaxLength());
            fieldDto.setRegex(field.getRegex());
            fieldDto.setReferenceId(field.getReferenceId());
            if (ApplicationUtils.isValidateObject(userRoleMgmtViewDto)){
                java.lang.reflect.Field fields1 = null;
                try {
                    fields1 = userRoleMgmtViewDto.getClass().getDeclaredField(field.getFieldName());
                    fields1.setAccessible(true);
                    Object str = fields1.get(userRoleMgmtViewDto);
                    if (str != null)
                        fieldDto.setValue(str.toString());
                } catch (NoSuchFieldException e) {
                    throw new RuntimeException(e);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                }
            }
        }else {
            throw new ApplicationException(ErrorCodes.INVALID_FIELD_DATA);
        }
        return fieldDto;
    }


    /**
     * Adds the section into meta data view dto for user mgmt.
     *
     * @param actualSectionData the actual section data
     * @param sectionDtoList the section dto list
     * @return the list
     */
    private List<SectionDto> AddSectionIntoMetaDataViewDtoForUserMgmt(SectionDto actualSectionData,
                                                           List<SectionDto> sectionDtoList) {

        if(sectionDtoList==null){
            List<SectionDto> list = new ArrayList<>();
            list.add(actualSectionData);
            return list;
        }

        boolean x=false, y=false, z=false;
        for (SectionDto sec1:sectionDtoList){
            if(actualSectionData.getSectionName().equals(sec1.getSectionName())){
                x=true;
                for (SectionDto sec2: sec1.getSectionList()){
                    if (sec2!=null && actualSectionData.getSectionList().get(0).getSectionName().equals(sec2.getSectionName())){
                        y=true;
//                        check both having 1 sub sections
                        if (actualSectionData.getSectionList().get(0).getSectionList().get(0)==null
                                && sec2.getSectionList().get(0)==null){
                            sec2.getFieldList().add(actualSectionData.getSectionList().get(0).getFieldList().get(0));
                        }
                        //check 2nd sub section
                        else if(actualSectionData.getSectionList().get(0).getSectionList().get(0)!=null
                                && sec2.getSectionList().get(0)!=null){
                            for(SectionDto sec3: sec2.getSectionList()){
                                if(Objects.equals(actualSectionData.getSectionList().get(0).getSectionList().get(0).getSectionName(), sec3.getSectionName())){
                                    sec3.getFieldList().add(actualSectionData.getSectionList().get(0).getSectionList().get(0).getFieldList().get(0));
                                }
                            }
                        }
                    }
                }
                if(!y){
                    sec1.getFieldList().add(actualSectionData.getFieldList().get(0));
                    if (actualSectionData.getSectionList().get(0)!=null)
                        sec1.getSectionList().add(actualSectionData.getSectionList().get(0));
                }
            }
        }
        if (!x){
            sectionDtoList.get(0).getFieldList().add(actualSectionData.getSectionList().get(0).getFieldList().get(0));
            sectionDtoList.add(actualSectionData);
        }
        return sectionDtoList;
    }

}
