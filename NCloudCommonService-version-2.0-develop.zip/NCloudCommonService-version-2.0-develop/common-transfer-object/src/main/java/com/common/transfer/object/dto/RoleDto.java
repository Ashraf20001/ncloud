package com.common.transfer.object.dto;

import java.time.LocalDateTime;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class RoleDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RoleDto {

	/** The role id. */
	private int roleId;

	/** The name. */
	private String name;

	/** The description. */
	private String description;

	/** The is active. */
	private Boolean isActive;

	/** The in active date. */
	private LocalDateTime inActiveDate;

	/** The company id. */
	private CompanyDto companyId;

	/** The is deleted. */
	private boolean isDeleted;

	/** The created date. */
	private Date createdDate;

	/** The created by. */
	private int createdBy;

	/** The modified date. */
	private Date modifiedDate;

	/** The modified by. */
	private int modifiedBy;

}
