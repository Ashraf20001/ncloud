package com.common.transfer.object.reportloss.dto;

import com.common.transfer.object.dto.MetaDataViewDto;

import lombok.*;


/**
 * The Class ReportLossPageDto.
 */
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ReportLossPageDto {

    /** The claim id. */
    private Integer claimId;
    
    /** The insured name. */
    private String insuredName;
    
    /** The claim sequence id. */
    private String claimSequenceId;
    
    /** The at fault company name. */
    private String atFaultCompanyName;
    
    /** The is receivable. */
    private boolean isReceivable;
    
    /** The receivable amount. */
    private String receivableAmount;
    
    /** The status. */
    private String status;
    
    /** The meta data. */
    private MetaDataViewDto metaData;
    
    /** The insurer name. */
    private String insurerName;
    
    /** The last status. */
    private String lastStatus;
    
    /** The total loss type. */
    private String totalLossType;
    
    /** The survey due hours. */
    private Integer surveyDueHours;
    
    /** The claim identity. */
    private String claimIdentity;
}
