package com.common.transfer.object.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * The Class UserRoleId.
 */
@Embeddable
@Data
public class UserRoleId implements Serializable {
    
    /** The role id. */
    @Column(name = "role_id")
    Long roleId;
    
    /** The user id. */
    @Column(name = "user_id")
    Long userId;
}
