package com.common.transfer.object.dto;

import lombok.Data;

/**
 * The Class CurrencyDto.
 */
@Data
public class CurrencyDto {

	/** The currency id. */
	private int currencyId;
	
	/** The region. */
	private String region;
	
	/** The currency. */
	private String currency;
	
	/** The createdby. */
	private String createdby;
	
	/** The modifiedby. */
	private String modifiedby;
	
	/** The isdeleted. */
	private boolean isdeleted;
	
	/** The identity. */
	private String identity;
	



}
