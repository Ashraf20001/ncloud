package com.common.transfer.object.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FileStorageDetails.
 */
@Data
@NoArgsConstructor
@Entity
@Table(name="storage_data")
@Audited
public class FileStorageDetails {
	
	/** The storage id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Integer storageId;
	
	/** The identity. */
	@Column(name = "storage_identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;
	
	/** The storage type. */
	@Column(name="stg_type")
	private String storageType;
	
	/** The url. */
	@Column(name="url")
	private String url;
	
	/** The upload type. */
	@Column(name="up_type")
	private String uploadType;
	
	/** The report type. */
	@Column(name="rp_type")
	private String reportType;
	
	/** The reference id. */
	@Column(name="ref_id")
	private long referenceId;
	
	/** The is deleted. */
	@Column(name="is_deleted")
	private boolean isDeleted = false;
	
	/** The created date. */
	@Column(name="created_date")
	private String createdDate;
	
	/** The file size. */
	@Column(name = "file_size")
	private Long fileSize;
}
