package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BulkImportMappingDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BulkImportMappingDto {

	/** The bulk import field name. */
	private String bulkImportFieldName;
	
	/** The bulk import alias name. */
	private String bulkImportAliasName;
}
