package com.common.transfer.object.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SectionNameDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SectionNameDto {

	/** The section id. */
	private Integer sectionId;
	
	/** The section name. */
	private String sectionName;
	
	/** The identity. */
	private String identity;
	
	/** The field position. */
	private Integer fieldPosition;
}