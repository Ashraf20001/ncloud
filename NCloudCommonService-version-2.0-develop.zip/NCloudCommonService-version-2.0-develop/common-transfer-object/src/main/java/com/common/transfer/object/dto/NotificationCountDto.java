package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class NotificationCountDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class NotificationCountDto {

	/** The company name. */
	private String companyName;
	
	/** The un read count. */
	private Long unReadCount;
	
	/** The read count. */
	private Long readCount;
	
	/** The total count. */
	private Long totalCount;
}
