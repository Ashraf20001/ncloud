package com.common.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CommentsDto.
 */
@Data
@NoArgsConstructor
public class CommentsDto {
	
	/** The message. */
	private String message;
	
	/** The status. */
	private String status;
	
	/** The is receivable. */
	private Boolean isReceivable;
	
	/** The created date. */
	private String createdDate;
	
	/** The created time. */
	private String createdTime;
	
	/** The user name. */
	private String userName;
	
	/** The company name. */
	private String companyName;

}
