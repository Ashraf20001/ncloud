package com.common.transfer.object.reportloss.dto;

import lombok.*;

import java.time.LocalDateTime;

import com.common.transfer.object.vo.dto.IConfigurable;


/**
 * The Class ReportLossDto.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ReportLossDto implements IConfigurable{

    /** The state. */
    //claimDetails
    private String state;
    
    /** The in insured name. */
    //InsurerInfo
    private String inInsuredName;
    
    /** The in insurer name. */
    private String inInsurerName;
    
    /** The in registration no. */
    private String inRegistrationNo;
    
    /** The in make. */
    private String inMake;
    
    /** The in model. */
    private String inModel;
    
    /** The in purchase date. */
    private LocalDateTime inPurchaseDate;
    
    /** The in sum insured. */
    private Double inSumInsured;

    /** The tp name. */
    //ThirdPartyInfo
    private String tpName;
    
    /** The tp policy number. */
    private String tpPolicyNumber;
    
    /** The tp claim no. */
    private String tpClaimNo;
    
    /** The tp registration no. */
    private String tpRegistrationNo;
    
    /** The tp registration type. */
    private String tpRegistrationType;
    
    /** The tp make. */
    private String tpMake;
    
    /** The tp model. */
    private String tpModel;

    /** The ld date of loss. */
    //loss details
    private LocalDateTime ldDateOfLoss;
    
    /** The ld claim number. */
    private String ldClaimNumber;
    
    /** The ld reported date. */
    private LocalDateTime ldReportedDate;
    
    /** The ld policy number. */
    private String ldPolicyNumber;
    
    /** The ld reserve amount. */
    private Double ldReserveAmount;
    
    /** The ld police report number. */
    private String ldPoliceReportNumber;
    
    /** The ld is total loss. */
    private Boolean ldIsTotalLoss;

    /** The pr document upload. */
    //police report
    private String prDocumentUpload	;

    /** The garage name. */
    //garageInfo
    private String garageName;
    
    /** The garage location. */
    private String garageLocation;
    
    /** The garage contact details. */
    private String garageContactDetails;
    
    /** The garage type. */
    private String garageType;
    
    /** The garage invoice name. */
    private String garageInvoiceName;

    //survey Details
   /** The sd survey allocation date. */
    private LocalDateTime sdSurveyAllocationDate;
    
    /** The sd survey due date. */
    private LocalDateTime sdSurveyDueDate;
    
    /** The sd survey report name. */
    private String sdSurveyReportName;

    /** The sr total loss. */
    //  survey report
    private Boolean srTotalLoss;
    
    /** The sr spare parts. */
    private Double srSpareParts;
    
    /** The sr labour cost. */
    private Double srLabourCost	;
    
    /** The sr survey amount. */
    private Double srSurveyAmount;
    
    /** The sr survey report upload. */
    private String srSurveyReportUpload	;
    
    /** The sr survey name. */
    private String srSurveyName;
    
    /** The rd police report fee. */
    //    recovery details
    private Double rdPoliceReportFee;
    
    /** The rd towing charge. */
    private Double rdTowingCharge;
    
    /** The rd inspection fee. */
    private Double rdInspectionFee;
    
    /** The rd other expenses. */
    private Double rdOtherExpenses;
    
    /** The rd cash settlement. */
    private Double rdCashSettlement;
    
    /** The rd spare parts. */
    private Double rdSpareParts;
    
    /** The rd labour cost. */
    private Double rdLabourCost;
    
    /** The rd TP survey amount. */
    private Double rdTPSurveyAmount;
    
    /** The rd claim amount. */
    private Double rdClaimAmount;

    /** The rr reserve amount. */
    //    reserve review
    private Double rrReserveAmount;
    
    /** The rr TP survey amount. */
    private Double rrTPSurveyAmount;
    
    /** The rr total claim amount. */
    private Double rrTotalClaimAmount;

    /** The gi document. */
    //    garage invoice
    private String giDocument;
    
    /** The gi garage invoice no. */
    private String giGarageInvoiceNo;

    /** The dn debit note number. */
    //    debit note number
    private String dnDebitNoteNumber;
    
    /** The dn debit note document. */
    private String dnDebitNoteDocument;

    /** The cn credit note number. */
    //    credit note number
    private String cnCreditNoteNumber;
    
    /** The cn credit note document. */
    private String cnCreditNoteDocument;
}
