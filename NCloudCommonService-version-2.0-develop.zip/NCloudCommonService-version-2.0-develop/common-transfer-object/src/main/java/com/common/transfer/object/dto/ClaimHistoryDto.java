package com.common.transfer.object.dto;

import java.util.List;

import lombok.Data;

/**
 * The Class ClaimHistoryDto.
 */
@Data
public class ClaimHistoryDto {

	/** The claim id. */
	private Integer claimId;
	
	/** The template. */
	private String template;
	
	/** The comments. */
	private List<String> comments;
	
	/** The doc url. */
	private List<String> docUrl;
	
	/** The is recievable. */
	private Boolean isRecievable;
	
	/** The stage name. */
	private String stageName;
	
	/** The section name. */
	private String sectionName;
	
	/** The date. */
	private String date;
	
	/** The time. */
	private String time;
	
	/** The insurance company id. */
	private Integer insuranceCompanyId;
	
	/** The tp company id. */
	private Integer tpCompanyId;
	
	/** The insurance company identity. */
	private String insuranceCompanyIdentity;
	
	/** The tp company identity. */
	private String tpCompanyIdentity;
	
}
