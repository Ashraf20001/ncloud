package com.common.transfer.object.dto;

import java.time.LocalDateTime;

import lombok.Data;

/**
 * The Class RoleSectionMappingDto.
 */
@Data
public class RoleSectionMappingDto {

    /** The api function mapping id. */
    private Integer apiFunctionMappingId;

    /** The role id. */
    private RoleDto roleId;

    /** The section id. */
    private SectionDto sectionId;
    
    /** The is view. */
    private Boolean isView;
    
    /** The is edit. */
    private Boolean isEdit;
    
    /** The is download. */
    private Boolean isDownload;
    
    /** The is notification. */
    private Boolean isNotification;
    
    /** The created date. */
    private LocalDateTime createdDate;
    
    /** The created by. */
    private Integer createdBy;
    
    /** The modified date. */
    private LocalDateTime modifiedDate;
    
    /** The modified by. */
    private Integer modifiedBy;

    /** The identity. */
    private String identity;
    
    /** The is deleted. */
    private Boolean isDeleted = false;
}
