package com.common.transfer.object.entity;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class SchedulerNotification.
 */
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity(name="scheduler_notification")
public class SchedulerNotification {
	 
 	/** The schedular id. */
 	@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "SchedularId")
	    private Integer schedularId;
	    
    	/** The notification name. */
    	@Column(name = "Notification_Name")
	    private String notificationName;
	    
    	/** The triggered status. */
    	@Column(name = "Triggered_Status")
	    private String triggeredStatus;
	    
    	/** The message. */
    	@Column(name = "Message")
	    private String message;
	    
    	/** The remainder. */
    	@Column(name = "Reminder")
	    private Integer remainder;
	    
    	/** The is deleted. */
    	@Column(name = "is_deleted")
	    private Boolean isDeleted;
	    
    	/** The status map id. */
    	@OneToMany(mappedBy="statusMapId",cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	    private List<TriggerStatusMap> statusMapId;


}
