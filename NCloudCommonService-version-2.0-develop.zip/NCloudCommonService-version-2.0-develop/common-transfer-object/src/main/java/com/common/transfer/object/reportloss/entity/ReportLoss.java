package com.common.transfer.object.reportloss.entity;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * The Class ReportLoss.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "report_loss")
public class ReportLoss {
	  
  	/** The claim id. */
  	@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "claim_id")
	    private Integer claimId;
	   
	    /** The comments. */
    	@OneToMany(mappedBy="claimId",cascade=CascadeType.ALL, fetch = FetchType.LAZY)
	    private List<Comments> comments;
	    
    	/** The insured info. */
    	@OneToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "insured_info")
	    private InsuredInfo insuredInfo;
	    
    	/** The third party info. */
    	@OneToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "third_party_info")
	    private ThirdPartyInfo thirdPartyInfo;
	    
    	/** The loss details. */
    	@OneToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "loss_details")
	    private LossDetails lossDetails;
	    
    	/** The police report. */
    	@OneToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "police_report")
	    private PoliceReport policeReport;
	    
    	/** The garage info. */
    	@OneToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "garage_info")
	    private GarageInfo garageInfo;
	    
    	/** The survey details. */
    	@OneToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "survey_details")
	    private SurveyDetails surveyDetails;
	    
    	/** The survey report. */
    	@OneToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "survey_report")
	    private SurveyReport surveyReport;
	    
    	/** The recovery details. */
    	@OneToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "recovery_details")
	    private RecoveryDetails recoveryDetails;
	    
    	/** The reserve review. */
    	@OneToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "reserve_review")
	    private ReserveReview reserveReview;
	    
    	/** The garage invoice. */
    	@OneToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "garage_invoice")
	    private GarageInvoice garageInvoice;
	    
    	/** The debit note. */
    	@OneToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "debit_note")
	    private DebitNote debitNote;
	    
    	/** The credit note. */
    	@OneToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "credit_note")
	    private CreditNote creditNote;
	    
    	/** The state. */
    	@Column(name = "state")
	    private String state;
	    
    	/** The created date. */
    	@Column(name="created_date")
	    private LocalDateTime createdDate;
	    
    	/** The created by. */
    	@Column(name="created_by")
	    private Integer createdBy;
	    
    	/** The modified date. */
    	@Column(name="modified_date")
	    private LocalDateTime modifiedDate;
	    
    	/** The modified by. */
    	@Column(name="modified_by")
	    private Integer modifiedBy;
	    
    	/** The identity. */
    	@Column(name = "identity")
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private String identity;
	    
    	/** The is deleted. */
    	@Column(name = "is_deleted")
	    private Boolean isDeleted = false;

	     /** The last status. */
     	@Column(name = "lastStatus")
	    private String lastStatus;
	     
	     /** The claim sequence id. */
     	@Column(name="claim_sequence_id")
	     private String claimSequenceId;
	     
	     /** The stage name. */
     	@Column(name="stage_name")
	     private String stageName;
	     
	     /** The section name. */
     	@Column(name="section_name")
	     private String sectionName;
	}