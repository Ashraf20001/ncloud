package com.common.transfer.object.core;

import lombok.Data;

/**
 * The Class TokenRefreshRequest.
 */
@Data
public class TokenRefreshRequest {
	
	/** The refresh token. */
	private String refreshToken;
}
