package com.common.transfer.object.chart;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class HorizontalBarChartFilterDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class HorizontalBarChartFilterDto {
    
    /** The label. */
    private String label;
    
    /** The count. */
    private Object count;
}
