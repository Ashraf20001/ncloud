package com.common.transfer.object.dto;

import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AssociationDto.
 */
@Data
@NoArgsConstructor
public class AssociationDto {


		/** The association id. */
		private int associationId;
		
		/** The association name. */
		private String associationName;
		
		/** The is deleted. */
		private boolean isDeleted;

		/** The identity. */
		private String identity;

		/** The created date. */
		private Date createdDate;

		/** The created by. */
		private int createdBy;
		
		/** The modified date. */
		private Date modifiedDate;

		/** The modified by. */
		private int modifiedBy;

}
