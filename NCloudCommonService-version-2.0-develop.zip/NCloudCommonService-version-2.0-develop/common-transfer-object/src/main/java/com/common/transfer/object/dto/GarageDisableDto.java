package com.common.transfer.object.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class GarageDisableDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class GarageDisableDto {
	

	 /** The expired date. */
 	private LocalDateTime expiredDate;
	 
 	/** The identity. */
 	private String identity;
	 
 	/** The garage id. */
 	private Integer garageId;

}
