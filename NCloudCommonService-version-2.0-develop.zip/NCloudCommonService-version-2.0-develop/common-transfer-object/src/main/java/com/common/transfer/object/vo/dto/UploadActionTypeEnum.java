package com.common.transfer.object.vo.dto;

/**
 * The Enum UploadActionTypeEnum.
 */
public enum UploadActionTypeEnum {
	
	/** The upload. */
	UPLOAD(1, "UPLOAD"), /** The revoke. */
 REVOKE(2, "REVOKE");

	/** The id. */
	Integer id;
	
	/** The action type. */
	String actionType;

	/**
	 * Instantiates a new upload action type enum.
	 *
	 * @param id the id
	 * @param actionType the action type
	 */
	private UploadActionTypeEnum(Integer id, String actionType) {
		this.id = id;
		this.actionType = actionType;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * Gets the action type.
	 *
	 * @return the action type
	 */
	public String getActionType() {
		return actionType;
	}

	/**
	 * Sets the action type.
	 *
	 * @param actionType the new action type
	 */
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	/**
	 * Gets the action type by name.
	 *
	 * @param actionType the action type
	 * @return the action type by name
	 */
	public static UploadActionTypeEnum getActionTypeByName(String actionType) {
		for (UploadActionTypeEnum onePaymentStatusEnum : UploadActionTypeEnum.values()) {
			if (onePaymentStatusEnum.name().equalsIgnoreCase(actionType)) {
				return onePaymentStatusEnum;
			}
		}
		return null;
	}
	
	/**
	 * Gets the action type by id.
	 *
	 * @param actionTypeId the action type id
	 * @return the action type by id
	 */
	public static UploadActionTypeEnum getActionTypeById(Integer actionTypeId) {
		for (UploadActionTypeEnum onePaymentStatusEnum : UploadActionTypeEnum.values()) {
			if (onePaymentStatusEnum.getId().equals(actionTypeId)) {
				return onePaymentStatusEnum;
			}
		}
		return null;
	}

}
