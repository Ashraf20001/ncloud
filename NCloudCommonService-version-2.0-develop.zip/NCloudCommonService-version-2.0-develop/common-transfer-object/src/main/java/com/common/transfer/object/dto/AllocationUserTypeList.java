package com.common.transfer.object.dto;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AllocationUserTypeList.
 */
@Data
@NoArgsConstructor
public class AllocationUserTypeList {

	/** The allocation user type list. */
	private List<AllocationUserTypeDto> allocationUserTypeList;
}

