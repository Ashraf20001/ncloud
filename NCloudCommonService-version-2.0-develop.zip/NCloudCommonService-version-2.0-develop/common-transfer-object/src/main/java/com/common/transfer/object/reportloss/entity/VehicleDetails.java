package com.common.transfer.object.reportloss.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * The Class VehicleDetails.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rl_vehicle_details")
public class VehicleDetails {
    
    /** The vehicle id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "vehicle_id")
    private int vehicleId;
    
    /** The registration no. */
    @Column(name = "registration_no")
    private String registrationNo;
    
    /** The model. */
    @Column(name = "model")
    private String model;
    
    /** The make. */
    @Column(name = "make")
    private String make;
    
    /** The created date. */
    @Column(name="created_date")
    private LocalDateTime createdDate;

    /** The created by. */
    @Column(name="created_by")
    private int createdBy;

    /** The modified date. */
    @Column(name="modified_date")
    private LocalDateTime modifiedDate;

    /** The modified by. */
    @Column(name="modified_by")
    private int modifiedBy;

    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;

    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;


}
