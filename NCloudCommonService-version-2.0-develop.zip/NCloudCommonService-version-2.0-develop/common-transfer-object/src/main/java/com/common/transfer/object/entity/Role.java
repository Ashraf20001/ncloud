package com.common.transfer.object.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import com.common.transfer.object.reportloss.entity.Company;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;

/**
 * The Class Role.
 */
@Entity
@Table(name = "user_role")
@Data
@AllArgsConstructor
@Getter
@Setter
@NoArgsConstructor
@Audited
public class Role extends Auditable implements Serializable {
	

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1115130974011519488L;

	/** The role id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="role_id")
	private Integer roleId;
	
	/** The name. */
	@Column(name="role_name")
	private String name;
	
	/** The description. */
	@Column(name="description")
	private String description;
	
	/** The allocation user type. */
	@OneToOne
	@JoinColumn(name="allocation_user_type")
	@NotAudited
	private AllocationUserType allocationUserType;

	/** The company id. */
	@OneToOne
	@JoinColumn(name = "company_id")
	@NotAudited
	private Company companyId;

	/** The is active. */
	@Column(name="is_active")
	private Boolean isActive = true;

	/** The in active date. */
	@Column(name="in_active_date")
	private LocalDateTime inActiveDate;

	/** The is deleted. */
	@Column(name="is_deleted")
	private boolean isDeleted;

	/** The identity. */
	@NonNull
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="identity")
	private String identity;


	/** The effective date. */
	@Column(name="effective_date")
	private LocalDateTime effectiveDate;
	
	
	/** The user type id. */
	@OneToOne
	@JoinColumn(name="user_type_id")
	@NotAudited
	private UserType userTypeId;
	
	/** The platform id. */
	@OneToOne
	@JoinColumn(name="role_platform_id")
	@NotAudited
	private Platform platformId;
	
	/**
	 * Instantiates a new role.
	 *
	 * @param roleId the role id
	 */
	public Role(int roleId){
		this.roleId = roleId;
	}

}
