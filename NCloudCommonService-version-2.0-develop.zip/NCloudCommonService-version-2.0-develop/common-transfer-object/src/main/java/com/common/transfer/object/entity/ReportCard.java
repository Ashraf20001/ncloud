package com.common.transfer.object.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ReportCard.
 */
@Entity
@Table(name = "report_card")
@Data
@NoArgsConstructor
public class ReportCard {

	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	/** The company name. */
	@Column(name="companyName")
	private String companyName;
	
	/** The third party company. */
	@Column(name="thirdPartyCompany")
	private String thirdPartyCompany;
	
	/** The from. */
	@Column(name="fromDate")
	private String from;

	/** The identity. */
	@Column(name="identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;

	/** The to. */
	@Column(name="toDate")
	private String to;

	/** The claim type. */
	@Column(name="claimType")
	private String claimType;
	
	/** The selected column. */
	@Column(name="selectedColumn")
	private String selectedColumn;
	
	/** The status. */
	@Column(name="status")
	private String status;

	/** The file type. */
	@Column(name="fileType")
	private String fileType;
	
	/** The report type. */
	@Column(name="reportType")
	private String reportType;
	
	/** The is deleted. */
	@Column(name = "isDetele")
    private Boolean isDeleted = false;

    /** The period. */
    @Column(name="period")
	private String period;
    
    /** The created by. */
    @Column(name="created_by")
	private int created_by;
    
    /** The created date. */
    @Column(name="created_date")
	private String created_date;
    
    /** The modified by. */
    @Column(name="modified_by")
	private int modified_by;
    
    /** The modified date. */
    @Column(name="modified_date")
	private String modified_date;
}
