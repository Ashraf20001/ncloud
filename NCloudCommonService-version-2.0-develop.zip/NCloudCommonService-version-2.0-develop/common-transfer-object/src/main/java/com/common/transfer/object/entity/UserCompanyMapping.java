package com.common.transfer.object.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

import com.common.transfer.object.reportloss.entity.Company;

import java.util.Date;

/**
 * The Class UserCompanyMapping.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "user_company_mapping")
public class UserCompanyMapping {
    
    /** The user company mapping id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_company_mapping_id")
    private int userCompanyMappingId;

    /** The user id. */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id")
    private Userprofile userId;

    /** The company id. */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "company_id")
    private Company companyId;

    /** The is deleted. */
    @Column(name="is_deleted")
    private boolean isDeleted;

    /** The identity. */
    @Column(name="identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;

    /** The created date. */
    @Column(name="created_date")
    private Date createdDate;

    /** The created by. */
    @Column(name="created_by")
    private int createdBy;

    /** The modified date. */
    @Column(name="modified_date")
    private Date modifiedDate;

    /** The modified by. */
    @Column(name="modified_by")
    private int modifiedBy;
    
    
    

}
