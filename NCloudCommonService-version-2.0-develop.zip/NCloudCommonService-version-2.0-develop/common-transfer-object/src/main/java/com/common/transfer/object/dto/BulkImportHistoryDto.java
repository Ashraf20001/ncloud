package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BulkImportHistoryDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BulkImportHistoryDto {

    /** The upload image name. */
    private String uploadImageName;
    
    /** The success count. */
    private Integer successCount;
    
    /** The failure count. */
    private Integer failureCount;
    
    /** The total count. */
    private Integer totalCount;
    
    /** The status. */
    private String status;
    
    /** The page id. */
    private Integer pageId;
    
    /** The created by. */
    private String createdBy;
    
    /** The created date. */
    private String createdDate;
    
    /** The identity. */
    private String identity;
    
    /** The pool id. */
    private Integer poolId;
    
    /** The platform id. */
    private Integer platformId;
    
    /** The upload type. */
    private Integer uploadType;
    
    /** The upload id. */
    private Integer uploadId;
    
    /** The url. */
    private String url;
    
    /** The action type. */
    private Integer actionType;
}
