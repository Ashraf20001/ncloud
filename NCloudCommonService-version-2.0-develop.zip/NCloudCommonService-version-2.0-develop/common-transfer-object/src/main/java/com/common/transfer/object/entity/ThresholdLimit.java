package com.common.transfer.object.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

import javax.persistence.*;

import com.common.transfer.object.reportloss.entity.Company;



/**
 * The Class ThresholdLimit.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "threshold_limit")
public class ThresholdLimit {
   
    /** The threshold id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "threshold_id")
    private Integer thresholdId;
    
    /** The company id. */
    @OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name ="company_id")
	private Company companyId;
    
    /** The maximum payable amount. */
    @Column(name="maximum_payable_amount")
    private Double maximumPayableAmount;
    
    /** The maximum time. */
    @Column(name="maximum_time")
    private Double maximumTime;
    
    /** The created date. */
    @Column(name="created_date")
    private Date createdDate;

    /** The created by. */
    @Column(name="created_by")
    private Integer createdBy;

    /** The modified date. */
    @Column(name="modified_date")
    private Date modifiedDate;

    /** The modified by. */
    @Column(name="modified_by")
    private Integer modifiedBy;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;

    /** The is deleted. */
    @Column(name = "is_deleted")
    private Boolean isDeleted = false;

}


