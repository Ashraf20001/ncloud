package com.common.transfer.object.dto;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ListOfRoles.
 */
@Data
@NoArgsConstructor
public class ListOfRoles {
	
	/** The list of roles. */
	private List<Integer> listOfRoles;

}
