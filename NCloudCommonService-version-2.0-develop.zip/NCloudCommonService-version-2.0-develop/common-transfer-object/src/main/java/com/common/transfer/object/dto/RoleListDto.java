package com.common.transfer.object.dto;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class RoleListDto.
 */
@Data
@NoArgsConstructor
public class RoleListDto {
	
	/** The user role list. */
	public List<UserRoleDto> userRoleList;
}
