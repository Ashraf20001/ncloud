package com.common.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class PageDto.
 */
@Data
@NoArgsConstructor
public class PageDto {

	/** The page id. */
	private int pageId;

	/** The page name. */
	private String pageName;

}
