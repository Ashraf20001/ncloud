package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserTypeDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserTypeDto {

    /** The user type id. */
    private Integer userTypeId;
    
    /** The user type name. */
    private String userTypeName;
}
