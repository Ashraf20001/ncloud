package com.common.transfer.object.dto;


import java.util.ArrayList;
import java.util.List;

/**
 * The Class SectionAccessDto.
 */
public class SectionAccessDto {

	/** The Constant sectionAcessList. */
	public static final List<String> sectionAcessList=new ArrayList<>();
	
	static {
		sectionAcessList.add("isView");
		sectionAcessList.add("isEdit");
		sectionAcessList.add("isDownload");
		sectionAcessList.add("isClone");
		sectionAcessList.add("isDisable");
		
		
	}
}
