package com.common.transfer.object.reportloss.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * The Class SurveyReport.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rl_survey_report")
public class SurveyReport {
    
    /** The survey report id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "survey_report_id")
    private int surveyReportId;

    /** The is total loss. */
    @Column(name = "is_total_loss")
    private boolean isTotalLoss;
    
    /** The spare parts. */
    @Column(name = "spare_parts")
    private Double spareParts;
    
    /** The labour cost. */
    @Column(name = "labour_cost")
    private Double labourCost;
    
    /** The survey amount. */
    @Column(name = "survey_amount")
    private Double surveyAmount;
    
    /** The survey report upload. */
    @Column(name = "survey_report_upload")
    private String surveyReportUpload;

    /** The created date. */
    @Column(name="created_date")
    private LocalDateTime createdDate;
    
    /** The created by. */
    @Column(name="created_by")
    private int createdBy;
    
    /** The modified date. */
    @Column(name="modified_date")
    private LocalDateTime modifiedDate;
    
    /** The modified by. */
    @Column(name="modified_by")
    private int modifiedBy;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;
    
    /** The survey name. */
    @Column(name = "survey_name")
    private String surveyName;
}
