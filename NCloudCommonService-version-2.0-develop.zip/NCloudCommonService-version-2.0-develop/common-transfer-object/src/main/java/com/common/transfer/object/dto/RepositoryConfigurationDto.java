package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class RepositoryConfigurationDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RepositoryConfigurationDto {

	/** The repository cost. */
	private String repositoryCost;
	
	/** The share percentage. */
	private String sharePercentage;

}
