package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class NotificationDto.
 */
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class NotificationDto {
	
	/** The claim id. */
	private Integer claimId;
	
	/** The status. */
	private String status;
	
	/** The company name. */
	private String companyName;
	
	/** The is receivable. */
	private String isReceivable;
	
	/** The logo url. */
	private String logoUrl;
	
	/** The last acted. */
	private String lastActed;

}
