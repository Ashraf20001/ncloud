package com.common.transfer.object.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * The Class Privilege.
 */
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "um_privilege")
public class Privilege {
	   
   	/** The privilege id. */
   	@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name="privilege_id")
	    private Integer privilegeId;
	    
    	/** The privilege name. */
    	@Column(name="privilege_name")
	    private String privilegeName;
	    
    	/** The page id. */
    	@Column(name="page_id")
	    private Integer pageId;
	    
    	/** The created date. */
    	@Column(name="created_date")
	    private LocalDateTime createdDate;
	    
    	/** The created by. */
    	@Column(name="created_by")
	    private Integer createdBy;
	    
    	/** The modified date. */
    	@Column(name="modified_date")
	    private LocalDateTime modifiedDate;
	    
    	/** The modified by. */
    	@Column(name="modified_by")
	    private Integer modifiedBy;
	    
    	/** The identity. */
    	@Column(name = "identity")
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private String identity;
	    
    	/** The is deleted. */
    	@Column(name = "is_deleted")
	    private Boolean isDeleted = false;
	    
    	/** The order by. */
    	@Column(name = "order_by")
	    private Integer orderBy;

	    /**
    	 * Instantiates a new privilege.
    	 *
    	 * @param privilegeId the privilege id
    	 */
    	public Privilege(Integer privilegeId){
	        this.privilegeId = privilegeId;
	    }
	} 	