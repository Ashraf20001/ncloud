package com.common.transfer.object.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class APIDetails.
 */
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Table(name = "um_api_details")
public class APIDetails {
    
    /** The api id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="api_id")
    private Integer apiId;
    
    /** The api URL. */
    @Column(name="api_url")
    private String apiURL;
    
    /** The created date. */
    @Column(name="created_date")
    private Date createdDate;
    
    /** The created by. */
    @Column(name="created_by")
    private Integer createdBy;
    
    /** The modified date. */
    @Column(name="modified_date")
    private Date modifiedDate;
    
    /** The modified by. */
    @Column(name="modified_by")
    private Integer modifiedBy;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private Boolean isDeleted = false;
}
