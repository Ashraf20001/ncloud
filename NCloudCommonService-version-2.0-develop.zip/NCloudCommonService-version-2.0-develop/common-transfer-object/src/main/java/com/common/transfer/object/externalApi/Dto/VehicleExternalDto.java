package com.common.transfer.object.externalApi.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class VehicleExternalDto.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class VehicleExternalDto {
	
	/** The registration no. */
	private String registrationNo;
	
	/** The model. */
	private String model;
	
	/** The make. */
	private String make;
	
	/** The registration type. */
	private String registrationType;//DOUBT FOR INSURED INFO//NO NEED
	
	/** The purchase date. */
	private String purchaseDate;//ONLY INSURED WE HAVE
	
	/** The sum insured. */
	private Double sumInsured;

}
