package com.common.transfer.object.vo.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class DocumentsDto.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DocumentsDto implements IConfigurable {
	
	/** The doc id. */
	private long docId;
	
	/** The document id. */
	private String documentId;
	
	/** The name. */
	private String name;
	
	/** The category. */
	private String category;
	
	/** The content type. */
	private String contentType;
	
	/** The document. */
	private String document;
	
	/** The doc ref no. */
	private String docRefNo;
	
	/** The document url. */
	private String documentUrl;
	
	/** The uploaded date time. */
	private Date uploadedDateTime;
	
	/** The claim status. */
	private ClaimDetailsDto claimStatus;

}
