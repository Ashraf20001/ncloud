package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CompanyDetailsDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CompanyDetailsDto {

	/** The company id. */
	Integer companyId;
	
	/** The company name. */
	String companyName;
}
