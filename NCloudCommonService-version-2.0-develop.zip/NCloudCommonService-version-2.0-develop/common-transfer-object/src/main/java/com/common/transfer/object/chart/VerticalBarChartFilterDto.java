package com.common.transfer.object.chart;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class VerticalBarChartFilterDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class VerticalBarChartFilterDto {
    
    /** The amount. */
    private Object amount;
    
    /** The days. */
    private Object days;
}
