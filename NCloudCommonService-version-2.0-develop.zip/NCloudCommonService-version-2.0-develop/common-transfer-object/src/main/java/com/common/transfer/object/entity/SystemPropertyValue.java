package com.common.transfer.object.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SystemPropertyValue.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "system_property_value")
public class SystemPropertyValue {

	/** The property value id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "property_value_id")
    private Integer propertyValueId;

	/** The property value. */
	@Column(name = "property_value")
	private String propertyValue;

	/** The property id. */
	@OneToOne
	@JoinColumn(name = "property_id")
    private SystemProperty propertyId;

	/** The association id. */
	@Column(name = "association_id")
    private Integer associationId;
}

