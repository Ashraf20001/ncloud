package com.common.transfer.object.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;

import org.hibernate.envers.Audited;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Data;

/**
 * The Class Auditable.
 */
@Data
@Audited
@EntityListeners(AuditingEntityListener.class)
@MappedSuperclass
public abstract class Auditable {

	/** The created by. */
	@CreatedBy
	@Column (name = "created_by")
	private Integer createdBy;

	/** The modified by. */
	@LastModifiedBy
	@Column (name = "modified_by")
	private Integer modifiedBy;

	/** The modified date. */
	@LastModifiedDate
	@Column (name = "modified_date")
	private LocalDateTime modifiedDate;

	/** The created date. */
	@CreatedDate
	@Column (name = "created_date")
	private LocalDateTime createdDate;
	
}
