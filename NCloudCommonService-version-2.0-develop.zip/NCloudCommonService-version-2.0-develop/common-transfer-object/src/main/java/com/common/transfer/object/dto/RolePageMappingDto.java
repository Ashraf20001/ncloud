package com.common.transfer.object.dto;

import java.time.LocalDateTime; 

import lombok.Data;

/**
 * The Class RolePageMappingDto.
 */
@Data
public class RolePageMappingDto {

    /** The role page mapping id. */
    private Integer rolePageMappingId;

    /** The role id. */
    private RoleDto roleId;

    /** The page id. */
    private PageMappingDto pageId;
    
    /** The is enabled. */
    private Boolean isEnabled;

    /** The created date. */
    private LocalDateTime createdDate;
    
    /** The created by. */
    private Integer createdBy;
    
    /** The modified date. */
    private LocalDateTime modifiedDate;
    
    /** The modified by. */
    private Integer modifiedBy;

    /** The identity. */
    private String identity;
    
   /** The is deleted. */
   private Boolean isDeleted = false;
}
