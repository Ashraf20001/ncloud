package com.common.transfer.object.dto;


import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ApprovalLevelDto.
 */
@Data
@NoArgsConstructor
public class ApprovalLevelDto {

	/** The role id. */
	List<Integer> roleId;
	
	/** The min value. */
	Double minValue;
	
	/** The max value. */
	Double maxValue;
	
	/** The currency. */
	String currency;
}
