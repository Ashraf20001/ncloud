package com.common.transfer.object.dto;

import lombok.Data;

/**
 * The Class PoolCountDetails.
 */
@Data
public class PoolCountDetails {
	
	/** The reserved paper count. */
	private Integer reservedPaperCount;
	
	/** The success paper generate count. */
	private Integer successPaperGenerateCount;
	
	/** The failed paper generate count. */
	private Integer failedPaperGenerateCount;

}
