package com.common.transfer.object.entity;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * The Class RoleSectionMapping.
 */
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Table(name = "um_role_section_mapping")
public class RoleSectionMapping {
    
    /** The api function mapping id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="role_section_mapping_id")
    private Integer apiFunctionMappingId;
    
    /** The role id. */
    @OneToOne
    @JoinColumn(name = "role_id")
    private Role roleId;
    
    /** The section id. */
    @OneToOne
    @JoinColumn(name = "section_id")
    private Section sectionId;
    
    /** The is view. */
    @Column(name="is_view")
    private Boolean isView;
    
    /** The is edit. */
    @Column(name="is_edit")
    private Boolean isEdit;
    
    /** The is download. */
    @Column(name="is_download")
    private Boolean isDownload;
    
    /** The is notification. */
    @Column(name="is_notification")
    private Boolean isNotification;
    
    /** The is clone. */
    @Column(name="is_clone")
    private Boolean isClone;
    
    /** The is disable. */
    @Column(name="is_disable")
    private Boolean isDisable;
    
    /** The created date. */
    @Column(name="created_date")
    private LocalDateTime createdDate;
    
    /** The created by. */
    @Column(name="created_by")
    private Integer createdBy;
    
    /** The modified date. */
    @Column(name="modified_date")
    private LocalDateTime modifiedDate;
    
    /** The modified by. */
    @Column(name="modified_by")
    private Integer modifiedBy;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private Boolean isDeleted = false;
}
