package com.common.transfer.object.dto;

import java.util.List;

import com.common.transfer.object.entity.MetaData;
import com.common.transfer.object.reportloss.dto.ReportLossViewDto;

import lombok.Data;

/**
 * The Class RlMetaDataConvertDto.
 */
@Data
public class RlMetaDataConvertDto {
	
	/** The meta list. */
	private List<MetaData> metaList;
	
	/** The report loss view dto. */
	private ReportLossViewDto reportLossViewDto;
}
