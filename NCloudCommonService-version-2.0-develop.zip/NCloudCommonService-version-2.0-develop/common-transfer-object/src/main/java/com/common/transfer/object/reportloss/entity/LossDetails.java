package com.common.transfer.object.reportloss.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * The Class LossDetails.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rl_loss_details")
public class LossDetails {

    /** The loss details id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "loss_details_id")
    private int lossDetailsId;

    /** The date of loss. */
    @Column(name = "date_of_loss")
    private LocalDateTime dateOfLoss;

    /** The claim number. */
    @Column(name = "claim_number")
    private String claimNumber;
    
    /** The reported date. */
    @Column(name = "reported_date")
    private LocalDateTime reportedDate;
    
    /** The policy number. */
    @Column(name = "policy_number")
    private String policyNumber;
    
    /** The reserve amount. */
    @Column(name = "reserve_amount")
    private Double reserveAmount;
    
    /** The police report number. */
    @Column(name = "police_report_number")
    private String policeReportNumber;
    
    /** The is total loss. */
    @Column(name = "is_total_loss")
    private boolean isTotalLoss;

    /** The created date. */
    @Column(name="created_date")
    private LocalDateTime createdDate;
    
    /** The created by. */
    @Column(name="created_by")
    private int createdBy;
    
    /** The modified date. */
    @Column(name="modified_date")
    private LocalDateTime modifiedDate;
    
    /** The modified by. */
    @Column(name="modified_by")
    private int modifiedBy;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;
}
