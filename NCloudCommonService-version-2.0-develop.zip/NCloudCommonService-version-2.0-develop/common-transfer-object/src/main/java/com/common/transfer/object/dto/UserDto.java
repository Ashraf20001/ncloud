package com.common.transfer.object.dto;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import com.common.transfer.object.entity.UserType;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserDto.
 */
@Data
@NoArgsConstructor
public class UserDto {

	/** The id. */
	private Integer id;

	/** The username. */
	private String username;

	/** The email. */
	private String email;

	/** The password. */
	private String password;
	
	/** The roles. */
	@JsonIgnore
	private Set<RoleDto> roles = new HashSet<>();

	/** The is deleted. */
	private int isDeleted;
	
	/** The identity. */
	private String identity;

	/** The created by. */
	private String createdBy;

	/** The modified by. */
	private String modifiedBy;
	
	/** The first time login. */
	private boolean firstTimeLogin = true;

	/** The created date. */
	private Date createdDate;

	/** The modified date. */
	private Date modifiedDate;

	/** The mobileno. */
	private String mobileno;
	
	/** The Address. */
	private String Address;
	
	/** The user type id. */
	private UserType userTypeId;

	/** The status. */
	private Boolean status;

	/** The effective date. */
	private LocalDateTime effectiveDate;
	

}
