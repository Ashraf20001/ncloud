package com.common.transfer.object.entity;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.envers.Audited;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class Garage.
 */
@Data
@NoArgsConstructor
@Setter
@Getter
@Entity(name = "rl_garage")
@Audited
public class Garage implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7360872943128448072L;

	/** The garage id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "garage_id")
	private Integer garageId;

	/** The short id. */
	@Column(name = "short_id")
	private String shortId;

	/** The garage name. */
	@Column(name = "garage_name")
	private String garageName;

	/** The email. */
	@Column(name = "email")
	private String email;

	/** The phone. */
	@Column(name = "phone")
	private String phone;

	/** The location. */
	@Column(name = "location")
	private String location;

	/** The password. */
	@Column(name = "password")
	private String password;

	/** The address. */
	@Column(name = "address")
	private String address;

	/** The user id. */
	@Column(name = "garage_user_id")
	private String userId;

	/** The logo. */
	@Column(name = "logo")
	private String logo;

	/** The created date. */
	@Column(name = "created_date")
	private Date createdDate;

	/** The created by. */
	@Column(name = "created_by")
	private Integer createdBy;

	/** The modified date. */
	@Column(name = "modified_date")
	private Date modifiedDate;

	/** The modified by. */
	@Column(name = "modified_by")
	private Integer modifiedBy;

	/** The identity. */
	@Column(name = "identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;

	/** The is deleted. */
	@Column(name = "is_deleted")
	private Boolean isDeleted = false;

	/** The is active. */
	@Column(name = "is_Active")
	private Boolean isActive=true;
	
	/** The effective to. */
	@Column(name = "effective_to")
	private LocalDateTime effectiveTo;

}
