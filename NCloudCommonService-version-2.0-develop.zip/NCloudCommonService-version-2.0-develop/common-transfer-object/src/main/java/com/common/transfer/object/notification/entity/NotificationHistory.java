package com.common.transfer.object.notification.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.common.transfer.object.reportloss.entity.Company;
import com.common.transfer.object.reportloss.entity.ReportLoss;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class NotificationHistory.
 */
@Entity
@Data
@Table(name="notification_history")
@NoArgsConstructor
public class NotificationHistory {
	
	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "notification_history_id")
	private int id;	
	  
	/** The template. */
	@Column(name = "notification_template")
	private String template;
	
	/** The is read. */
	@Column(name = "is_read")
	private boolean isRead;
	
	/** The claim details. */
	@OneToOne(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	@JoinColumn(name = "claim_id")
	private ReportLoss claimDetails;
	
	/** The status. */
	@Column(name = "status")
	private String status;
	
	/** The last acted. */
	@OneToOne
	@JoinColumn(name = "last_acted")
	private Company lastActed;
	
	/** The to notify. */
	@OneToOne
	@JoinColumn(name = "to_notify")
	private Company toNotify;
	
	/** The is deleted. */
	@Column(name="is_deleted")
	private boolean isDeleted;

	/** The identity. */
	@Column(name="identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;

	/** The created date. */
	@Column(name="created_date")
	private Date createdDate;

	/** The created by. */
	@Column(name="created_by")
	private int createdBy;
	
	/** The modified date. */
	@Column(name="modified_date")
	private Date modifiedDate;

	/** The modified by. */
	@Column(name="modified_by")
	private int modifiedBy;

}
