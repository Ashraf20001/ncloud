package com.common.transfer.object.reportloss.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * The Class DebitNote.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rl_debit_note")
public class DebitNote {

    /** The debit note id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "debit_note_id")
    private int debitNoteId;

    /** The debit note number. */
    @Column(name = "debit_note_number")
    private String debitNoteNumber;
    
    /** The debit note document. */
    @Column(name = "debit_note_document")
    private String debitNoteDocument;

    /** The created date. */
    @Column(name="created_date")
    private LocalDateTime createdDate;
    
    /** The created by. */
    @Column(name="created_by")
    private int createdBy;
    
    /** The modified date. */
    @Column(name="modified_date")
    private LocalDateTime modifiedDate;
    
    /** The modified by. */
    @Column(name="modified_by")
    private int modifiedBy;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;
    
    /** The debit note sequence id. */
    @Column(name="debit_note_sequenceId")
    private String debitNoteSequenceId;
    
}
