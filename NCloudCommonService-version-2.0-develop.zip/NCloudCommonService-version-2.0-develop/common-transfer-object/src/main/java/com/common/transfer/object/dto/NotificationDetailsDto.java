package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class NotificationDetailsDto.
 */
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class NotificationDetailsDto {
	
	/** The report loss dto. */
	private ReportLossForNotificationDto reportLossDto;
	
	/** The user id. */
	private Integer userId;;
	
	/** The login user company name. */
	private String loginUserCompanyName;
	
	/** The insurer name. */
	private String insurerName;
	
	/** The third party tpname. */
	private String thirdPartyTpname;
	
	/** The logo by company id. */
	private String logoByCompanyId;
	
	/** The state. */
	private String state;
	
	/** The min amount. */
	private Double minAmount;
	
	/** The max amount. */
	private Double maxAmount;
	
	/** The role name. */
	private String roleName;
	

}
