package com.common.transfer.object.dto;


import java.util.List;

import lombok.Data;

/**
 * The Class DpFieldConfiguratorDto.
 */
@Data
public class DpFieldConfiguratorDto {

	/** The platform id. */
	private Integer platformId;

	/** The updated fields. */
	private List<UpdateFieldDto> updatedFields;

	/** The deleted fields. */
	private List<DeleteFieldDto> deletedFields;
	
}
