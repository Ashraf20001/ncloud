package com.common.transfer.object.dto;

import java.util.List;

import com.common.transfer.object.entity.SystemProperty;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ImplementConfigurationVo.
 */
@Data
@NoArgsConstructor
public class ImplementConfigurationVo {

	/** The column name. */
	private String columnName ;
	
	/** The value. */
	private String value;
	
	/** The id. */
	private SystemProperty id;
	
	/** The insurance user value. */
	private List<String> insuranceUserValue;
}
