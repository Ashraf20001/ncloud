package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * The Class DropDownFieldDto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class DropDownFieldDto {
	
	/** The field option name. */
	private String fieldOptionName;
	
	/** The field option identity. */
	private String fieldOptionIdentity;
	
	/** The field option id. */
	private Integer fieldOptionId;
}
