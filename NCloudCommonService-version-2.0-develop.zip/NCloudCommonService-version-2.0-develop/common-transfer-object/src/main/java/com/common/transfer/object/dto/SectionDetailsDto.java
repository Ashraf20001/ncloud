package com.common.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SectionDetailsDto.
 */
@Data
@NoArgsConstructor
public class SectionDetailsDto {

	/** The platform id. */
	private Integer platformId;
	
	/** The section name. */
	private String sectionName;
	
	/** The page identity. */
	private String pageIdentity;
	
	/** The sub section identity. */
	private String subSectionIdentity;
}

