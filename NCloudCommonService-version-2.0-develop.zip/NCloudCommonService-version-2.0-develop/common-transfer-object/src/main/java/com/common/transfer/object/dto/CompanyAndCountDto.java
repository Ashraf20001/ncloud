package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CompanyAndCountDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CompanyAndCountDto {
	
	/** The company. */
	private String company;
	
	/** The count. */
	private Long count;

}
