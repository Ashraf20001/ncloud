package com.common.transfer.object.reportloss.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * The Class ReserveReview.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rl_reserve_review")
public class ReserveReview {

    /** The reserve review id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "reserve_review_id")
    private int reserveReviewId;

    /** The reserve amount. */
    @Column(name = "reserve_amount")
    private Double reserveAmount;
    
    /** The tp survey amount. */
    @Column(name = "tp_survey_amount")
    private Double tpSurveyAmount;
    
    /** The tp claim amount. */
    @Column(name = "tp_claim_amount")
    private Double tpClaimAmount;

    /** The created date. */
    @Column(name="created_date")
    private LocalDateTime createdDate;
    
    /** The created by. */
    @Column(name="created_by")
    private int createdBy;
    
    /** The modified date. */
    @Column(name="modified_date")
    private LocalDateTime modifiedDate;
    
    /** The modified by. */
    @Column(name="modified_by")
    private int modifiedBy;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;
}
