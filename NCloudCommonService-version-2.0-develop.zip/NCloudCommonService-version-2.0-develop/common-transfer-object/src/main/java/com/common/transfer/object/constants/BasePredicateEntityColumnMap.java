package com.common.transfer.object.constants;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.common.constants.core.ApplicationConstants;
import com.common.constants.core.TableConstants;
import com.common.transfer.object.entity.BulkImportHistory;
import com.common.transfer.object.entity.Role;
import com.common.transfer.object.entity.ThresholdLimit;
import com.common.transfer.object.entity.UserCompanyMapping;
import com.common.transfer.object.entity.UserRoleMapping;

/**
 * The Class BasePredicateEntityColumnMap.
 */
@Component
public class BasePredicateEntityColumnMap {
	
	/** The Constant basePredicateEntityColumnMap. */
	public static final Map<Class<?>,String> basePredicateEntityColumnMap = new HashMap<>();
	
	/**
	 * Sets the base predicate map.
	 */
	@PostConstruct
	public void setBasePredicateMap() {
		basePredicateEntityColumnMap.put(Role.class, TableConstants.COMPANY_ID);
		basePredicateEntityColumnMap.put(UserCompanyMapping.class,TableConstants.COMPANY_ID);
		basePredicateEntityColumnMap.put(BulkImportHistory.class,TableConstants.COMPANY_ID);
		basePredicateEntityColumnMap.put(UserRoleMapping.class, TableConstants.ROLE_+ApplicationConstants.COMMA+TableConstants.COMPANY_ID);
		basePredicateEntityColumnMap.put(ThresholdLimit.class, TableConstants.COMPANY_ID);
	}
}
