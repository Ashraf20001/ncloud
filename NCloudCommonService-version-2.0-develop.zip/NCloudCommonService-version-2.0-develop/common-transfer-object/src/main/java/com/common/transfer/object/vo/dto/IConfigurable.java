package com.common.transfer.object.vo.dto;

/**
 * The Interface IConfigurable.
 */
public interface IConfigurable {

}
