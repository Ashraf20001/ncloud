package com.common.transfer.object.dto;

import lombok.Data;

/**
 * The Class CustomerDto.
 */
@Data
public class CustomerDto {
	
	/** The customer id. */
	private Integer customerId;
	
	/** The username. */
	private String username;
	
	/** The email. */
	private String email;
	
	/** The phone number. */
	private String phoneNumber;
	
	/** The added date. */
	private String addedDate;
	
	/** The status. */
	private boolean status;
	
	/** The password. */
	private String password;
	
	/** The is first time login. */
	private boolean isFirstTimeLogin;
	
	/** The identity. */
	private String identity;
	
	/** The company id. */
	private Integer companyId;
}
