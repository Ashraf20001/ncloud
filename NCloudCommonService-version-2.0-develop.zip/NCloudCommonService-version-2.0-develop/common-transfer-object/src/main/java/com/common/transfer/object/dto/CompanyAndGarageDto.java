package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class CompanyAndGarageDto.
 */
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CompanyAndGarageDto {
	
	/** The company id. */
	public Integer companyId;
	
	/** The garage id. */
	public Integer garageId;
	
	/** The company identity. */
	public String companyIdentity;
	
	/** The garage identity. */
	public String garageIdentity;
}
