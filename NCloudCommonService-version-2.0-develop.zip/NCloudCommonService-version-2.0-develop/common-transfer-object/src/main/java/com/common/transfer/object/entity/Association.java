package com.common.transfer.object.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class Association.
 */
@Entity
@Table(name = "association")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Association {

	/** The association id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="association_id")
	private int associationId;
	
	/** The association name. */
	@Column (name="association_name")
	private String associationName;
	
	/** The is deleted. */
	@Column(name="is_deleted")
	private boolean isDeleted;

	/** The identity. */
	@Column(name="identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;

	/** The created date. */
	@Column(name="created_date")
	private Date createdDate;

	/** The created by. */
	@Column(name="created_by")
	private int createdBy;
	
	/** The modified date. */
	@Column(name="modified_date")
	private Date modifiedDate;

	/** The modified by. */
	@Column(name="modified_by")
	private int modifiedBy;



}
