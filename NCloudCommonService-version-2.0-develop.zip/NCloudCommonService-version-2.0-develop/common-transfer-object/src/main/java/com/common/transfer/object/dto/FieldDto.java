package com.common.transfer.object.dto;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FieldDto.
 */
@Data
@NoArgsConstructor
public class FieldDto {

	/** The field id. */
	private String fieldId;
	
	/** The field name. */
	private String fieldName;
	
	/** The field type. */
	private String fieldType;
	
	/** The alias name. */
	private String aliasName;
	
	/** The is mandatory. */
	private boolean isMandatory;
	
	/** The is core data. */
	private Boolean isCoreData;
	
	/** The default values. */
	private String defaultValues;
	
	/** The entity name. */
	private String entityName;
	
	/** The column name. */
	private String columnName;
	
	/** The value. */
	private String value;
	
	/** The min length. */
	private Integer minLength;
	
	/** The max length. */
	private Integer maxLength;
	
	/** The regex. */
	private String regex;
	
	/** The reference id. */
	private Integer referenceId;
	
	/** The is system generated. */
	private Boolean isSystemGenerated;
	
	/** The has error. */
	private Boolean hasError = false;
	
	/** The identity. */
	private String identity;
	
	/** The error message. */
	private String errorMessage;
	
	/** The drop down list. */
	private List<DropDownFieldDto> dropDownList;
	
	/** The field position. */
	private Integer fieldPosition;

}
