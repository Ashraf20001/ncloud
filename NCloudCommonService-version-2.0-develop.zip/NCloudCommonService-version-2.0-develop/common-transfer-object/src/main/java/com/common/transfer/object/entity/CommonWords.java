package com.common.transfer.object.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

/**
 * The Class CommonWords.
 */
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Table(name = "pwd_common_words")
public class CommonWords {
    
    /** The common word id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="pwd_common_words_id")
    private Integer commonWordId;
    
    /** The common word. */
    @Column(name="common_word")
    private String commonWord;
    
    /** The is deleted. */
    @Column(name="is_deleted")
    private Boolean isDeleted = false;
}
