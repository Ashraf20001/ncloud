package com.common.transfer.object.vo.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class InsuredInfoDto.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class InsuredInfoDto implements IConfigurable {

	
	/** The in policy number. */
	private String inPolicyNumber;
	
	/** The in company. */
	private Company inCompany;
	
	/** The in vehicle details. */
	private VehicleDetailsDto inVehicleDetails;
}
