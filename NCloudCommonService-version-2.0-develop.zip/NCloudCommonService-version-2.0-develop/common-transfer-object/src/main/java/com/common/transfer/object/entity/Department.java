package com.common.transfer.object.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The Class Department.
 */
@Entity
@Data
@Table(name="department")
@NoArgsConstructor
public class Department {
	
	/**
	 * Instantiates a new department.
	 *
	 * @param id the id
	 * @param dept_code the dept code
	 * @param dept_name the dept name
	 */
	public Department(int id, int dept_code, String dept_name) {
		super();
		this.id = id;
		this.dept_code = dept_code;
		this.dept_name = dept_name;
	}
	
	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	/** The dept code. */
	private int dept_code;
	
	/** The dept name. */
	private String dept_name;
	
	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "Department [id=" + id + ", dept_code=" + dept_code + ", dept_name=" + dept_name + "]";
	}

}
