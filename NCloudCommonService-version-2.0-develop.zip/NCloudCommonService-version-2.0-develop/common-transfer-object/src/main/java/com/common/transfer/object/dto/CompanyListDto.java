package com.common.transfer.object.dto;

import java.util.List;

import lombok.Data;

/**
 * The Class CompanyListDto.
 */
@Data
public class CompanyListDto {

/** The company list. */
private List<CompanyDto> companyList;
}
