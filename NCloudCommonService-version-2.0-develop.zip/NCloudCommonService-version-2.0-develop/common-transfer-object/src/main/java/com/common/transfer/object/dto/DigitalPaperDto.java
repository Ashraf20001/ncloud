package com.common.transfer.object.dto;

import java.time.LocalDateTime;

import com.common.transfer.object.vo.dto.IConfigurable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class DigitalPaperDto.
 */
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DigitalPaperDto implements IConfigurable {
	
	/** The pd digital paper id. */
	private String pdDigitalPaperId;
	
	/** The pd policy number. */
	private String pdPolicyNumber;
	
	/** The pd insured name. */
	private String pdInsuredName;
	
	/** The pd phone number. */
	private String pdPhoneNumber;
	
	/** The pd email id. */
	private String pdEmailId;
	
	/** The pd effective from. */
	private LocalDateTime pdEffectiveFrom;
	
	/** The pd expire date. */
	private LocalDateTime pdExpireDate;
	
	/** The vd registration number. */
	private String vdRegistrationNumber;
	
	/** The vd chassis. */
	private String vdChassis;
	
	/** The vd licensed to carry. */
	private String vdLicensedToCarry;
	
	/** The vd make. */
	private String vdMake;
	
	/** The vd model. */
	private String vdModel;
	
	/** The vd usage. */
	private String vdUsage;
	
	/** The status. */
	private Integer status;
	
	/** The file url. */
	private String fileUrl;
	
	/** The identity. */
	private String identity;
	

}
