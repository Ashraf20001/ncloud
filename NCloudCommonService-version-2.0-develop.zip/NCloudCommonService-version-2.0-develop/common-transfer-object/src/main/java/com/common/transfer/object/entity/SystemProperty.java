package com.common.transfer.object.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SystemProperty.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "system_property")
public class SystemProperty {
	
	/** The property id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "property_id")
    private Integer propertyId;

	/** The property name. */
	@Column(name = "propertyName")
	private String propertyName;


	/** The platform id. */
	@OneToOne
	@JoinColumn(name = "platform_id")
    private Platform platformId;

}

