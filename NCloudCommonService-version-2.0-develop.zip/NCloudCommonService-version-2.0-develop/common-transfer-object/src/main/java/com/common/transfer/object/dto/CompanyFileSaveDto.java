package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CompanyFileSaveDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CompanyFileSaveDto {

	/** The reference id. */
	private String referenceId;
	
	/** The file url. */
	private String fileUrl;
	
	/** The page id. */
	private String pageId;
	
	/** The is edit. */
	private Boolean isEdit;
	
	/** The password. */
	private String password;
	
}
