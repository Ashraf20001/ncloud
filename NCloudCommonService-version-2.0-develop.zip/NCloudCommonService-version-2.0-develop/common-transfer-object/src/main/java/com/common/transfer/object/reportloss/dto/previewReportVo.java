package com.common.transfer.object.reportloss.dto;

import java.util.ArrayList;
import java.util.HashMap;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class previewReportVo.
 */
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class previewReportVo {
	
	/** The receivable amount. */
	private double receivableAmount;
	
	/** The payable amount. */
	private double payableAmount;
	
	/** The Data list. */
	private ArrayList<HashMap<String, Object>> DataList;

}
