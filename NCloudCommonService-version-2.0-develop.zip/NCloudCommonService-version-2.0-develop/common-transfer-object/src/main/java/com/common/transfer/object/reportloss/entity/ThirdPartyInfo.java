package com.common.transfer.object.reportloss.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

import java.time.LocalDateTime;

/**
 * The Class ThirdPartyInfo.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rl_third_party_info")
public class ThirdPartyInfo {
    
    /** The third party info id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "third_party_info_id")
    private int thirdPartyInfoId;
    
    /** The tp company. */
    @OneToOne
    @JoinColumn(name = "tp_company_id")
    private Company tpCompany;
    
    /** The policy number. */
    @Column(name = "policy_number")
    private String policyNumber;
    
    /** The claim no. */
    @Column(name = "claim_no")
    private String claimNo;
    
    /** The vehicle details. */
    @OneToOne(cascade = {CascadeType.ALL})
    @JoinColumn(name = "vehicle_details")
    private VehicleDetails vehicleDetails;
    
    /** The registration type. */
    @Column(name = "registration_type")
    private String registrationType;

    /** The created date. */
    @Column(name="created_date")
    private LocalDateTime createdDate;

    /** The created by. */
    @Column(name="created_by")
    private int createdBy;

    /** The modified date. */
    @Column(name="modified_date")
    private LocalDateTime modifiedDate;

    /** The modified by. */
    @Column(name="modified_by")
    private int modifiedBy;

    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;

    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;
}
