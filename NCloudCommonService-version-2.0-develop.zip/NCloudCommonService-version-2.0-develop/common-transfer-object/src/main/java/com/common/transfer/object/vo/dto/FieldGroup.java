package com.common.transfer.object.vo.dto;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FieldGroup.
 */
@Data
@NoArgsConstructor
public class FieldGroup {
	
	/** The group name. */
	private String groupName;
	
	/** The field values. */
	private List<FieldValue> fieldValues;
	
	/** The field groups. */
	private List<FieldGroup> fieldGroups;

}
