package com.common.transfer.object.dto;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UpdateDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UpdateDto {
		
		/** The column values. */
		private Map<String, Object> columnValues;
		
		/** The queries. */
		private List<QueryDto> queries;
}
