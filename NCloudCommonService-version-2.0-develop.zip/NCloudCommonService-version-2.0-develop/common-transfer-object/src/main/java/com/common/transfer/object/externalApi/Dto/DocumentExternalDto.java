package com.common.transfer.object.externalApi.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class DocumentExternalDto.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DocumentExternalDto {
	
	/** The name. */
	private String name;
	
	/** The document id. */
	private String documentId;
	
	/** The category. */
	private String category;
	
	/** The content type. */
	private String contentType;
	
	/** The document. */
	private String document;
	
	/** The doc ref no. */
	private String docRefNo;
	
	/** The document url. */
	private String documentUrl;
	
	/** The uploaded date time. */
	private String uploadedDateTime;

}
