package com.common.transfer.object.entity;

import lombok.*;

import javax.persistence.*;



import java.time.LocalDateTime;

/**
 * The Class UserSectionMapping.
 */
@Entity
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "um_user_section_mapping")
public class UserSectionMapping {
    
    /** The user section mapping id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "um_user_section_mapping_id")
    private Integer userSectionMappingId;
    
    /** The user id. */
    @OneToOne
    @JoinColumn(name = "user_id")
    private Userprofile userId;
    
    /** The section id. */
    @OneToOne
    @JoinColumn(name = "section_id")
    private Section sectionId;
    
    /** The menu id. */
    @OneToOne
    @JoinColumn(name = "menu_id")
    private Menu menuId;
    
    /** The page id. */
    @OneToOne
    @JoinColumn(name = "page_id")
    private Page pageId;
    
    /** The is notification. */
    @Column(name = "is_notification")
    private Boolean isNotification;  
    
    /** The is email. */
    @Column(name = "is_email")
    private Boolean isEmail;
    
    /** The created date. */
    @Column(name="created_date")
    private LocalDateTime createdDate;
    
    /** The created by. */
    @Column(name="created_by")
    private Integer createdBy;
    
    /** The modified date. */
    @Column(name="modified_date")
    private LocalDateTime modifiedDate;
    
    /** The modified by. */
    @Column(name="modified_by")
    private Integer modifiedBy;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private Boolean isDeleted = false;

}
