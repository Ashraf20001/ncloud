package com.common.transfer.object.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class Platform.
 */
@Entity
@Table(name="platform")
@Data
@NoArgsConstructor
public class Platform {

	/** The platform id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="platform_id")
	private Integer platformId;

	/** The platform identity. */
	@Column(name="platform_identity")
	private String platformIdentity;

	/** The platform name. */
	@Column(name="platform_name")
	private String platformName;
	
	/** The platform url. */
	@Column(name="platform_url")
    private String platformUrl;

    /** The platform active. */
    @Column(name="platform_active")
    private Boolean platformActive;
    
    /** The platform logo. */
    @Column(name="platform_logo")
	private String platformLogo;
	

}

