package com.common.transfer.object.dto;


/**
 * The Class PrivielgeNames.
 */
public class PrivielgeNames {

/** The Constant DIGITAL_PAPER_TAKE. */
public static final String DIGITAL_PAPER_TAKE="Digital Paper Take";

/** The Constant DIGITAL_PAPER_STATUS. */
public static final String DIGITAL_PAPER_STATUS="Digital Paper Status";

/** The Constant PREDICTION. */
public static final String PREDICTION="Prediction";

/** The Constant RECENT_DIGITAL_PAPER. */
public static final String RECENT_DIGITAL_PAPER="Recent Digital Papers";

/** The Constant UPCOMMING_EXPIRY_DIGITAL_PAPERS. */
public static final String UPCOMMING_EXPIRY_DIGITAL_PAPERS="Upcoming Expiry Digital Papers";

/** The Constant PURCHASE_LIST_VIEW. */
public static final String PURCHASE_LIST_VIEW = "Purchase List View";

/** The Constant PURCHASE_STOCK_DOWNLOAD. */
public static final String PURCHASE_STOCK_DOWNLOAD = "Purchase Stock Download";

/** The Constant PAPER_LIST_COUNT_VIEW. */
public static final String PAPER_LIST_COUNT_VIEW = "Paper List Count View";

/** The Constant PAPER_LIST_VIEW. */
public static final String PAPER_LIST_VIEW ="Paper List View";

/** The Constant PAPER_LIST_DOWNLOAD. */
public static final String PAPER_LIST_DOWNLOAD ="Paper List Download";

/** The Constant GENERATE_PAPER_MANUAL_SAVE. */
public static final String GENERATE_PAPER_MANUAL_SAVE ="Generate Paper Manual Save";

/** The Constant GENERATE_PAPER_BULK_EXCEL_DOWNLOAD. */
public static final String GENERATE_PAPER_BULK_EXCEL_DOWNLOAD ="Generate Paper Bulk Excel Download";

/** The Constant GENERATE_PAPER_RECORDS_EXCEL_DOWNLOAD. */
public static final String GENERATE_PAPER_RECORDS_EXCEL_DOWNLOAD ="Generate Paper Records Excel Download";

/** The Constant GENERATE_PAPER_TOTAL_RECORDS_VIEW. */
public static final String GENERATE_PAPER_TOTAL_RECORDS_VIEW ="Generate Paper Total Records View";

/** The Constant GENERATE_PAPER_ERROR_RECORDS_COUNT_VIEW. */
public static final String GENERATE_PAPER_ERROR_RECORDS_COUNT_VIEW ="Generate Paper Error Records Count View";

/** The Constant GENERATE_PAPER_SUCCESS_DATA_VIEW. */
public static final String GENERATE_PAPER_SUCCESS_DATA_VIEW ="Generate Paper Success Data View";

/** The Constant GENERATE_PAPER_SUCCESS_DATA_COUNT_VIEW. */
public static final String GENERATE_PAPER_SUCCESS_DATA_COUNT_VIEW ="Generate Paper Success Data Count View";

/** The Constant GENERATE_PAPER_ERROR_RECORDS_VIEW. */
public static final String GENERATE_PAPER_ERROR_RECORDS_VIEW ="Generate Paper Error Records View";

/** The Constant REVOKE_UPDATE_VIEW. */
public static final String REVOKE_UPDATE_VIEW ="Revoke Update View";

/** The Constant REVOKE_BULK_SAMPLE_FILE_VIEW. */
public static final String REVOKE_BULK_SAMPLE_FILE_VIEW ="Revoke Bulk Sample File View";

/** The Constant REVOKE_BULK_ERROR_RECORDS_VIEW. */
public static final String REVOKE_BULK_ERROR_RECORDS_VIEW ="Revoke Bulk Error Records View";

/** The Constant REVOKE_BULK_SUCCESS_DATA_VIEW. */
public static final String REVOKE_BULK_SUCCESS_DATA_VIEW ="Revoke Bulk Success Data View";

/** The Constant REVOKE_BULK_TOTAL_REVOKE_COUNT_VIEW. */
public static final String REVOKE_BULK_TOTAL_REVOKE_COUNT_VIEW ="Revoke Bulk Total Revoke Count View";

/** The Constant REVOKE_BULK_ERROR_RECORDS_COUNT_VIEW. */
public static final String REVOKE_BULK_ERROR_RECORDS_COUNT_VIEW ="Revoke Bulk Error Records Count View";

/** The Constant REVOKE_BULK_SUCCESS_DATA_COUNT_VIEW. */
public static final String REVOKE_BULK_SUCCESS_DATA_COUNT_VIEW ="Revoke Bulk Success Data Count View";

/** The Constant REPORTS_ALL_CARDS_VIEW. */
public static final String REPORTS_ALL_CARDS_VIEW ="Reports All Cards View";

/** The Constant REPORTS_CARDS_EDIT. */
public static final String REPORTS_CARDS_EDIT ="Reports Cards Edit";

/** The Constant REPORT_CARDS_DOWNLOAD. */
public static final String REPORT_CARDS_DOWNLOAD ="Report Cards Download";

/** The Constant GENERATE_REPORTS_PURCHASE_ORDER_VIEW. */
public static final String GENERATE_REPORTS_PURCHASE_ORDER_VIEW ="Generate Reports Purchase Order View";

/** The Constant GENERATE_REPORTS_DIGITAL_PAPER_VIEW. */
public static final String GENERATE_REPORTS_DIGITAL_PAPER_VIEW ="Generate Reports Digital Paper View";

/** The Constant GENERATE_REPORTS_PREVIEW_VIEW. */
public static final String GENERATE_REPORTS_PREVIEW_VIEW ="Generate Reports Preview View";

/** The Constant GENERATE_REPORTS_PREVIEW_VIEW_COUNT. */
public static final String GENERATE_REPORTS_PREVIEW_VIEW_COUNT ="Generate Reports Preview View Count";

/** The Constant GENERATE_REPORTS_SAVE_VIEW. */
public static final String GENERATE_REPORTS_SAVE_VIEW ="Generate Reports Save View";

/** The Constant DIGITAL_PAPER_ALLOCATED_BARCHART_VIEW. */
public static final String DIGITAL_PAPER_ALLOCATED_BARCHART_VIEW ="Digital Paper Allocated Barchart View";

/** The Constant DIGITAL_PAPER_STATUS_DOUGHNUT_VIEW. */
public static final String DIGITAL_PAPER_STATUS_DOUGHNUT_VIEW ="Digital Paper Status Doughnut View";

/** The Constant TOP_PURCHASES_VIEW. */
public static final String TOP_PURCHASES_VIEW ="Top Purchases View";

/** The Constant RECENT_TRANSACTION_VIEW. */
public static final String RECENT_TRANSACTION_VIEW ="Recent Transaction View";

/** The Constant RECENT_DIGITAL_PAPERS_VIEW. */
public static final String RECENT_DIGITAL_PAPERS_VIEW ="Recent Digital Papers View";

/** The Constant PAPER_DETAILS_STOCK_LIST_VIEW. */
public static final String PAPER_DETAILS_STOCK_LIST_VIEW ="Paper Details Stock List View";

/** The Constant PAPER_DETAILS_STOCK_COUNT_VIEW. */
public static final String PAPER_DETAILS_STOCK_COUNT_VIEW ="Paper Details Stock Count View";

/** The Constant PAPER_DETAILS_STOCK_DOWNLOAD. */
public static final String PAPER_DETAILS_STOCK_DOWNLOAD ="Paper Details Stock Download";

/** The Constant VIEW_PAPER_COUNT_VIEW. */
public static final String VIEW_PAPER_COUNT_VIEW ="View Paper Count View";

/** The Constant VIEW_PAPER_LIST_VIEW. */
public static final String VIEW_PAPER_LIST_VIEW ="View Paper List View";

/** The Constant VIEW_PAPER_DOWNLOAD. */
public static final String VIEW_PAPER_DOWNLOAD ="View Paper Download";

/** The Constant PURCHASE_HISTORY_COUNT_VIEW. */
public static final String PURCHASE_HISTORY_COUNT_VIEW ="Purchase History Count View";

/** The Constant PURCHASE_HISTORY_LIST_VIEW. */
public static final String PURCHASE_HISTORY_LIST_VIEW ="Purchase History List View";

/** The Constant PURCHASE_HISTORY_STOCK_COUNT_VIEW. */
public static final String PURCHASE_HISTORY_STOCK_COUNT_VIEW ="Purchase History Stock Count View";

/** The Constant PURCHASE_HISTORY_ALLOCATION_SAVE_VIEW. */
public static final String PURCHASE_HISTORY_ALLOCATION_SAVE_VIEW="Purchase History Allocation Save View";

/** The Constant VIEW_HISTORY_COUNT_VIEW. */
public static final String VIEW_HISTORY_COUNT_VIEW="View History Count View";

/** The Constant VIEW_HISTORY_LIST_VIEW. */
public static final String VIEW_HISTORY_LIST_VIEW="View History List View";

/** The Constant VIEW_HISTORY_LIST_DOWNLOAD. */
public static final String VIEW_HISTORY_LIST_DOWNLOAD="View History List Download";

/** The Constant APPROVE_VIEW. */
public static final String APPROVE_VIEW="Approve View";

/** The Constant REJECT_VIEW. */
public static final String REJECT_VIEW="Reject View";

/** The Constant POOL_LIST_COUNT_VIEW. */
public static final String POOL_LIST_COUNT_VIEW="Pool List Count View";

/** The Constant POOL_LIST_VIEW. */
public static final String POOL_LIST_VIEW="Pool List View";

/** The Constant ALLOCATE_STOCK_POPUP_VIEW. */
public static final String ALLOCATE_STOCK_POPUP_VIEW="Allocate Stock Popup View";

/** The Constant ALLOCATE_STOCK_POPUP_DROPDOWN_VIEW. */
public static final String ALLOCATE_STOCK_POPUP_DROPDOWN_VIEW="Allocate Stock Popup Dropdown View";

/** The Constant ALLOCATE_STOCK_SAVE_VIEW. */
public static final String ALLOCATE_STOCK_SAVE_VIEW="Allocate Stock Save View";

/** The Constant REALLOCATE_STOCK_SAVE_VIEW. */
public static final String REALLOCATE_STOCK_SAVE_VIEW="Reallocate Stock Save View";

/** The Constant DEALLOCATE_STOCK_SAVE_VIEW. */
public static final String DEALLOCATE_STOCK_SAVE_VIEW="Deallocate Stock Save View";

/** The Constant CUSTOMER_COUNT_VIEW. */
public static final String CUSTOMER_COUNT_VIEW="Customer Count View";

/** The Constant CUSTOMER_LIST_VIEW. */
public static final String CUSTOMER_LIST_VIEW="Customer List View";

/** The Constant CUSTOMER_LIST_DOWNLOAD. */
public static final String CUSTOMER_LIST_DOWNLOAD="Customer List Download";

/** The Constant CUSTOMER_LIST_EDIT. */
public static final String CUSTOMER_LIST_EDIT="Customer List Edit";

/** The Constant PURCHASE_HISTORY_DOWNLOAD. */
public static final String PURCHASE_HISTORY_DOWNLOAD = "Purchase History List Download";

/** The Constant USER_ROLE_LIST_VIEW. */
public static final String USER_ROLE_LIST_VIEW = "User Role List View";

/** The Constant USER_ROLE_LIST_EDIT. */
public static final String USER_ROLE_LIST_EDIT = "User Role List Edit";

/** The Constant USER_ROLE_LIST_DOWNLOAD. */
public static final String USER_ROLE_LIST_DOWNLOAD = "User Role List Download";

/** The Constant USER_ROLE_LIST_CLONE. */
public static final String USER_ROLE_LIST_CLONE = "User Role List Clone";

/** The Constant USER_ROLE_LIST_DISABLE. */
public static final String USER_ROLE_LIST_DISABLE = "User Role List Disable";

/** The Constant ADD_NEW_ROLE_VIEW. */
public static final String ADD_NEW_ROLE_VIEW = "Add New Role View";

/** The Constant ADD_NEW_ROLE_EDIT. */
public static final String ADD_NEW_ROLE_EDIT = "Add New Role Edit";

/** The Constant USER_LIST_VIEW. */
public static final String USER_LIST_VIEW = "User List View";

/** The Constant USER_LIST_EDIT. */
public static final String USER_LIST_EDIT = "User List Edit";

/** The Constant USER_LIST_DOWNLOAD. */
public static final String USER_LIST_DOWNLOAD = "User List Download";

/** The Constant ADD_NEW_USER_VIEW. */
public static final String ADD_NEW_USER_VIEW = "Add New User View";

/** The Constant ADD_NEW_USER_EDIT. */
public static final String ADD_NEW_USER_EDIT = "Add New User Edit";


}

