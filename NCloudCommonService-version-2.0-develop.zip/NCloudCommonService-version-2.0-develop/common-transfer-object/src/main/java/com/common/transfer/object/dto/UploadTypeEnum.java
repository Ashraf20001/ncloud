package com.common.transfer.object.dto;


/**
 * The Enum UploadTypeEnum.
 */
public enum UploadTypeEnum {

	/** The bulk upload. */
	BULK_UPLOAD(1,"BULK_UPLOAD"),
	
	/** The bulk revoke. */
	BULK_REVOKE(2,"BULK_REVOKE");
	
	/** The upload type id. */
	Integer uploadTypeId;
	
	/** The upload type name. */
	String uploadTypeName;
	
	/**
	 * Gets the upload type id.
	 *
	 * @return the upload type id
	 */
	public Integer getUploadTypeId() {
		return uploadTypeId;
	}

	/**
	 * Sets the upload type id.
	 *
	 * @param uploadTypeId the new upload type id
	 */
	public void setUploadTypeId(Integer uploadTypeId) {
		this.uploadTypeId = uploadTypeId;
	}

	/**
	 * Gets the upload type name.
	 *
	 * @return the upload type name
	 */
	public String getUploadTypeName() {
		return uploadTypeName;
	}

	/**
	 * Sets the upload type name.
	 *
	 * @param uploadTypeName the new upload type name
	 */
	public void setUploadTypeName(String uploadTypeName) {
		this.uploadTypeName = uploadTypeName;
	}

	/**
	 * Instantiates a new upload type enum.
	 *
	 * @param uploadTypeId the upload type id
	 * @param uploadTypeName the upload type name
	 */
	private UploadTypeEnum(Integer uploadTypeId, String uploadTypeName) {
		this.uploadTypeId = uploadTypeId;
		this.uploadTypeName = uploadTypeName;
	}
	
	/**
	 * Gets the upload type id by name.
	 *
	 * @param uploadTypeName the upload type name
	 * @return the upload type id by name
	 */
	public static Integer getUploadTypeIdByName(String uploadTypeName) {
		for (UploadTypeEnum oneUploadTypeEnum : UploadTypeEnum.values()) {
			if (oneUploadTypeEnum.name().equalsIgnoreCase(uploadTypeName)) {
				return oneUploadTypeEnum.getUploadTypeId();
			}
		}
		return null;
	}
	
	/**
	 * Gets the upload type by id.
	 *
	 * @param uploadTypeId the upload type id
	 * @return the upload type by id
	 */
	public static String getUploadTypeById(Integer uploadTypeId) {
		for (UploadTypeEnum oneUploadTypeEnum : UploadTypeEnum.values()) {
			if (oneUploadTypeEnum.getUploadTypeId().equals(uploadTypeId)) {
				return oneUploadTypeEnum.getUploadTypeName();
			}
		}
		return null;
	}

}

