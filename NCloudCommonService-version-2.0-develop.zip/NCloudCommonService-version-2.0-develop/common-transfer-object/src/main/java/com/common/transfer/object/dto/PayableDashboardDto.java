package com.common.transfer.object.dto;


import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class PayableDashboardDto.
 */
@Data
@NoArgsConstructor
public class PayableDashboardDto {

    /** The title. */
    private String title;
    
    /** The amount title. */
    private String amountTitle;
    
    /** The total payable amount. */
    private String totalPayableAmount;
    
    /** The payable count. */
    private String payableCount;
    
    /** The notification count. */
    private String notificationCount;
    
    /** The claim inspection count. */
    private String claimInspectionCount;
    
    /** The liability count. */
    private String liabilityCount;
    
    /** The settlement count. */
    private String settlementCount;
}
