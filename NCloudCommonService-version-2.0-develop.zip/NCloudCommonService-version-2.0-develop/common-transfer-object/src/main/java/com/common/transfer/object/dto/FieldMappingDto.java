package com.common.transfer.object.dto;

import java.util.Date;

/**
 * The Class FieldMappingDto.
 */
public class FieldMappingDto {

	
		/** The field id. */
		private int fieldId;
		
		/** The field name. */
		private String fieldName;
		
		/** The field type. */
		private String fieldType;
		
		/** The alias name. */
		private String aliasName;
		
		/** The is mandatory. */
		private boolean isMandatory;
		
		/** The is core data. */
		private Boolean isCoreData;
		
		/** The reference id. */
		private Integer referenceId;
		
		/** The is deleted. */
		private boolean isDeleted;
		

		/** The identity. */
		private String identity;

		/** The created date. */
		private Date createdDate;

		/** The created by. */
		private int createdBy;
		
		/** The modified date. */
		private Date modifiedDate;

		/** The modified by. */
		private int modifiedBy;

		/** The min length. */
		private Integer minLength;

		/** The max length. */
		private Integer maxLength;

		/** The regex. */
		private String regex;
		
		/** The is system generated. */
		private Boolean isSystemGenerated;
		
	

}
