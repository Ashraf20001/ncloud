package com.common.transfer.object.dto;

import lombok.*;

import java.util.List;

/**
 * The Class ListOfString.
 */
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ListOfString {
    
    /** The list. */
    private List<String> list;
    
    /** The limit. */
    private int limit;
    
    /** The skip. */
    private int skip;
    
    /** The stage name. */
    private String stageName;
    
    /** The search value. */
    private String searchValue;

}
