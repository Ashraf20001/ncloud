package com.common.transfer.object.vo.dto;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

/**
 * The Class DataConstructMap.
 */
@Component
public class DataConstructMap {
			
			/** The data defintion map. */
			public static Map<String,String> dataDefintionMap= new HashMap<>();
			
			/**
			 * Define data types.
			 */
			@PostConstruct
			public void defineDataTypes() {
				dataDefintionMap.put(DataTypeConstantsDto.INTEGER,SqlQueryConstants.INT);
				dataDefintionMap.put(DataTypeConstantsDto.BOOLEAN,SqlQueryConstants.TINYINT);
				dataDefintionMap.put(DataTypeConstantsDto.STRING, SqlQueryConstants.VARCHAR);
				dataDefintionMap.put(DataTypeConstantsDto.LONG, SqlQueryConstants.BIGINT);
				dataDefintionMap.put(DataTypeConstantsDto.LOCAL_DATE_TIME, SqlQueryConstants.TIMESTAMP);
				dataDefintionMap.put(DataTypeConstantsDto.DOUBLE, SqlQueryConstants.DOUBLE);
			}
}
