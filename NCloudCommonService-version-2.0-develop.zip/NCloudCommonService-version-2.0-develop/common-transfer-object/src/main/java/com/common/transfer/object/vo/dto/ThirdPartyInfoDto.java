package com.common.transfer.object.vo.dto;



import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class ThirdPartyInfoDto.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ThirdPartyInfoDto implements IConfigurable  {
	
	
	/** The tp policy number. */
	private String tpPolicyNumber;
	
	/** The tp company. */
	private Company tpCompany;
	
	/** The tp vehicle details. */
	private VehicleDetailsDto tpVehicleDetails;

}
