package com.common.transfer.object.dto;


import java.util.ArrayList;
import java.util.List;

/**
 * The Class SectionPrivelageMapDto.
 */
public class SectionPrivelageMapDto {
	
	/** The Constant digitalPaperTakenList. */
	public static final List<String> digitalPaperTakenList = new ArrayList<>();
	
	/** The Constant digitalPaperstatusList. */
	public static final List<String> digitalPaperstatusList = new ArrayList<>();
	
	/** The Constant predictionlist. */
	public static final List<String> predictionlist = new ArrayList<>();
	
	/** The Constant recentDigitalPaper. */
	public static final List<String> recentDigitalPaper = new ArrayList<>();
	
	/** The Constant upcomingExpiryDigitalPapers. */
	public static final List<String> upcomingExpiryDigitalPapers = new ArrayList<>();
	
	/** The Constant purchaseListView. */
	public static final List<String> purchaseListView = new ArrayList<>();
	
	/** The Constant purchaseListDownload. */
	public static final List<String> purchaseListDownload = new ArrayList<>();
	
	/** The Constant newPaperListView. */
	public static final List<String> newPaperListView = new ArrayList<>();
	
	/** The Constant newPaperListDownload. */
	public static final List<String> newPaperListDownload=new ArrayList<>();
	
	/** The Constant generatePaperManualSave. */
	public static final List<String> generatePaperManualSave=new ArrayList<>();
	
	/** The Constant generatePaperBulkSaveDownload. */
	public static final List<String> generatePaperBulkSaveDownload = new ArrayList<>();
	
	/** The Constant generatePaperBulkView. */
	public static final List<String> generatePaperBulkView = new ArrayList<>();
	
	/** The Constant revokeManualView. */
	public static final List<String> revokeManualView = new ArrayList<>();
	
	/** The Constant revokeBulkView. */
	public static final List<String> revokeBulkView = new ArrayList<>();
	
	/** The Constant reportsView. */
	public static final List<String> reportsView = new ArrayList<>();
	
	/** The Constant reportsEdit. */
	public static final List<String> reportsEdit = new ArrayList<>();
	
	/** The Constant reportsDownload. */
	public static final List<String> reportsDownload = new ArrayList<>();
	
	/** The Constant generateReportsView. */
	public static final List<String> generateReportsView = new ArrayList<>();
	
	/** The Constant digitalPaperAllocatedView. */
	public static final List<String> digitalPaperAllocatedView = new ArrayList<>();
	
	/** The Constant digitalPaperStatusView. */
	public static final List<String> digitalPaperStatusView = new ArrayList<>();
	
	/** The Constant topPurchasesView. */
	public static final List<String> topPurchasesView = new ArrayList<>();
	
	/** The Constant recentTransactionView. */
	public static final List<String> recentTransactionView = new ArrayList<>();
	
	/** The Constant recentDigitalPaperView. */
	public static final List<String> recentDigitalPaperView = new ArrayList<>();
	
	/** The Constant paperDetailsView. */
	public static final List<String> paperDetailsView = new ArrayList<>();
	
	/** The Constant paperDetailsDownload. */
	public static final List<String> paperDetailsDownload = new ArrayList<>();
	
	/** The Constant viewPaperView. */
	public static final List<String> viewPaperView = new ArrayList<>();
	
	/** The Constant viewPaperDownload. */
	public static final List<String> viewPaperDownload = new ArrayList<>();
	
	/** The Constant purchaseHistoryView. */
	public static final List<String> purchaseHistoryView = new ArrayList<>();
	
	/** The Constant viewHistoryView. */
	public static final List<String> viewHistoryView = new ArrayList<>();
	
	/** The Constant purchaseHistoryDownload. */
	public static final List<String> purchaseHistoryDownload=new ArrayList<>();
	
	/** The Constant viewHistoryDownload. */
	public static final List<String> viewHistoryDownload = new ArrayList<>();
	
	/** The Constant approveView. */
	public static final List<String> approveView = new ArrayList<>();
	
	/** The Constant rejectView. */
	public static final List<String> rejectView = new ArrayList<>();
	
	/** The Constant poolListView. */
	public static final List<String> poolListView = new ArrayList<>();
	
	/** The Constant allocateStockView. */
	public static final List<String> allocateStockView = new ArrayList<>();
	
	/** The Constant reallocateView. */
	public static final List<String> reallocateView = new ArrayList<>();
	
	/** The Constant deallocateView. */
	public static final List<String> deallocateView = new ArrayList<>();
	
	/** The Constant customerView. */
	public static final List<String> customerView = new ArrayList<>();
	
	/** The Constant customerDownload. */
	public static final List<String> customerDownload = new ArrayList<>();
	
	/** The Constant customerEdit. */
	public static final List<String> customerEdit = new ArrayList<>();
	
	/** The Constant userRoleListView. */
	public static final List<String> userRoleListView = new ArrayList<>();
	
	/** The Constant userRoleListEdit. */
	public static final List<String> userRoleListEdit = new ArrayList<>();
	
	/** The Constant userRoleListDownload. */
	public static final List<String> userRoleListDownload = new ArrayList<>();
	
	/** The Constant userRoleListClone. */
	public static final List<String> userRoleListClone = new ArrayList<>();
	
	/** The Constant userRoleListDisable. */
	public static final List<String> userRoleListDisable = new ArrayList<>();
	
	/** The Constant addNewRoleView. */
	public static final List<String> addNewRoleView = new ArrayList<>();
	
	/** The Constant addNewRoleEdit. */
	public static final List<String> addNewRoleEdit = new ArrayList<>();
	
	/** The Constant userListEdit. */
	public static final List<String> userListEdit = new ArrayList<>();
	
	/** The Constant userListView. */
	public static final List<String> userListView = new ArrayList<>();
	
	/** The Constant userListDownload. */
	public static final List<String> userListDownload = new ArrayList<>();
	
	/** The Constant addNewUserView. */
	public static final List<String> addNewUserView = new ArrayList<>();
	
	/** The Constant addNewUserEdit. */
	public static final List<String> addNewUserEdit = new ArrayList<>();
	
	

	static {
		// section =Digital Paper Taken
		digitalPaperTakenList.add(PrivielgeNames.DIGITAL_PAPER_TAKE);

		// section =Digital Paper Status
		digitalPaperstatusList.add(PrivielgeNames.DIGITAL_PAPER_STATUS);

		// section =Prediction
		predictionlist.add(PrivielgeNames.PREDICTION);

		// section =Recent Digital Paper
		recentDigitalPaper.add(PrivielgeNames.RECENT_DIGITAL_PAPER);

		// section =Digital Paper Taken
		upcomingExpiryDigitalPapers.add(PrivielgeNames.UPCOMMING_EXPIRY_DIGITAL_PAPERS);
		
		//section= Purchase List
		purchaseListView.add(PrivielgeNames.PURCHASE_LIST_VIEW);
		purchaseListDownload.add(PrivielgeNames.PURCHASE_STOCK_DOWNLOAD);
		
		//section=Paper List
		newPaperListView.add(PrivielgeNames.PAPER_LIST_COUNT_VIEW);
		newPaperListView.add(PrivielgeNames.PAPER_LIST_VIEW);
		newPaperListDownload.add(PrivielgeNames.PAPER_LIST_DOWNLOAD);
		
		//section=Generate Paper Manual
		generatePaperManualSave.add(PrivielgeNames.GENERATE_PAPER_MANUAL_SAVE);
		
		//section=Generate Paper Bulk
		generatePaperBulkSaveDownload.add(PrivielgeNames.GENERATE_PAPER_BULK_EXCEL_DOWNLOAD);
		generatePaperBulkSaveDownload.add(PrivielgeNames.GENERATE_PAPER_RECORDS_EXCEL_DOWNLOAD);
		generatePaperBulkView.add(PrivielgeNames.GENERATE_PAPER_TOTAL_RECORDS_VIEW);
		generatePaperBulkView.add(PrivielgeNames.GENERATE_PAPER_ERROR_RECORDS_COUNT_VIEW);
		generatePaperBulkView.add(PrivielgeNames.GENERATE_PAPER_SUCCESS_DATA_VIEW);
		generatePaperBulkView.add(PrivielgeNames.GENERATE_PAPER_SUCCESS_DATA_COUNT_VIEW);
		generatePaperBulkView.add(PrivielgeNames.GENERATE_PAPER_ERROR_RECORDS_VIEW);
		
		//section=Revoke Manual
		revokeManualView.add(PrivielgeNames.REVOKE_UPDATE_VIEW);
		
		//section=Revoke Bulk
		revokeBulkView.add(PrivielgeNames.REVOKE_BULK_SAMPLE_FILE_VIEW);
		revokeBulkView.add(PrivielgeNames.REVOKE_BULK_ERROR_RECORDS_VIEW);
		revokeBulkView.add(PrivielgeNames.REVOKE_BULK_SUCCESS_DATA_VIEW);
		revokeBulkView.add(PrivielgeNames.REVOKE_BULK_TOTAL_REVOKE_COUNT_VIEW);
		revokeBulkView.add(PrivielgeNames.REVOKE_BULK_ERROR_RECORDS_COUNT_VIEW);
		revokeBulkView.add(PrivielgeNames.REVOKE_BULK_SUCCESS_DATA_COUNT_VIEW);
		
		//section= Reports
		reportsView.add(PrivielgeNames.REPORTS_ALL_CARDS_VIEW);
		reportsEdit.add(PrivielgeNames.REPORTS_CARDS_EDIT);
		reportsDownload.add(PrivielgeNames.REPORT_CARDS_DOWNLOAD);
		
		//section=Generate Reports
		generateReportsView.add(PrivielgeNames.GENERATE_REPORTS_PURCHASE_ORDER_VIEW);
		generateReportsView.add(PrivielgeNames.GENERATE_REPORTS_DIGITAL_PAPER_VIEW);
		generateReportsView.add(PrivielgeNames.GENERATE_REPORTS_PREVIEW_VIEW);
		generateReportsView.add(PrivielgeNames.GENERATE_REPORTS_SAVE_VIEW);
		generateReportsView.add(PrivielgeNames.GENERATE_REPORTS_PREVIEW_VIEW_COUNT);
		
		//section=Digital paper Allocated
		digitalPaperAllocatedView.add(PrivielgeNames.DIGITAL_PAPER_ALLOCATED_BARCHART_VIEW);
		
		//section=Digital paper status
		digitalPaperStatusView.add(PrivielgeNames.DIGITAL_PAPER_STATUS_DOUGHNUT_VIEW);
		
		//section=Top purchases
		topPurchasesView.add(PrivielgeNames.TOP_PURCHASES_VIEW);
		
		//section=Recent Transaction
		recentTransactionView.add(PrivielgeNames.RECENT_TRANSACTION_VIEW);
		
		//section=Recent Digital papers
		recentDigitalPaperView.add(PrivielgeNames.RECENT_DIGITAL_PAPERS_VIEW);
		
		//section=Paper Details
		paperDetailsView.add(PrivielgeNames.PAPER_DETAILS_STOCK_LIST_VIEW);
		paperDetailsView.add(PrivielgeNames.PAPER_DETAILS_STOCK_COUNT_VIEW);
		
		paperDetailsDownload.add(PrivielgeNames.PAPER_DETAILS_STOCK_DOWNLOAD);
		
		//section=View Paper
		viewPaperView.add(PrivielgeNames.VIEW_PAPER_COUNT_VIEW);
		viewPaperView.add(PrivielgeNames.VIEW_PAPER_LIST_VIEW);
		viewPaperDownload.add(PrivielgeNames.VIEW_PAPER_DOWNLOAD);
		
		//section=Purchase History
		purchaseHistoryView.add(PrivielgeNames.PURCHASE_HISTORY_COUNT_VIEW);
		purchaseHistoryView.add(PrivielgeNames.PURCHASE_HISTORY_LIST_VIEW);
		purchaseHistoryView.add(PrivielgeNames.PURCHASE_HISTORY_STOCK_COUNT_VIEW);
		purchaseHistoryView.add(PrivielgeNames.PURCHASE_HISTORY_ALLOCATION_SAVE_VIEW);
		purchaseHistoryDownload.add(PrivielgeNames.PURCHASE_HISTORY_DOWNLOAD);
		
		//section=View History
		viewHistoryView.add(PrivielgeNames.VIEW_HISTORY_COUNT_VIEW);
		viewHistoryView.add(PrivielgeNames.VIEW_HISTORY_LIST_VIEW);
		viewHistoryDownload.add(PrivielgeNames.VIEW_HISTORY_LIST_DOWNLOAD);
		
		//section=Approve
		approveView.add(PrivielgeNames.APPROVE_VIEW);
		
		//section=Reject
		rejectView.add(PrivielgeNames.REJECT_VIEW);
		
		//section=Pool List
		poolListView.add(PrivielgeNames.POOL_LIST_COUNT_VIEW);
		poolListView.add(PrivielgeNames.POOL_LIST_VIEW);
		
		//section=Allocate Stock
		allocateStockView.add(PrivielgeNames.ALLOCATE_STOCK_POPUP_VIEW);
		allocateStockView.add(PrivielgeNames.ALLOCATE_STOCK_POPUP_DROPDOWN_VIEW);
		allocateStockView.add(PrivielgeNames.ALLOCATE_STOCK_SAVE_VIEW);
		
		//section=Reallocate
		reallocateView.add(PrivielgeNames.REALLOCATE_STOCK_SAVE_VIEW);
		
		//section=Deallocate
		deallocateView.add(PrivielgeNames.DEALLOCATE_STOCK_SAVE_VIEW);
		
		//section=Customer
		customerView.add(PrivielgeNames.CUSTOMER_COUNT_VIEW);
		customerView.add(PrivielgeNames.CUSTOMER_LIST_VIEW);
		customerDownload.add(PrivielgeNames.CUSTOMER_LIST_DOWNLOAD);
		customerEdit.add(PrivielgeNames.CUSTOMER_LIST_EDIT);
		
		//section = User Role
		userRoleListView.add(PrivielgeNames.USER_ROLE_LIST_VIEW);
		userRoleListEdit.add(PrivielgeNames.USER_ROLE_LIST_EDIT);
		userRoleListDownload.add(PrivielgeNames.USER_ROLE_LIST_DOWNLOAD);
		userRoleListClone.add(PrivielgeNames.USER_ROLE_LIST_CLONE);
		userRoleListDisable.add(PrivielgeNames.USER_ROLE_LIST_DISABLE);
		addNewRoleView.add(PrivielgeNames.ADD_NEW_ROLE_VIEW);
		addNewRoleEdit.add(PrivielgeNames.ADD_NEW_ROLE_EDIT);
		userListEdit.add(PrivielgeNames.USER_LIST_EDIT);
		userListView.add(PrivielgeNames.USER_LIST_VIEW);
		userListDownload.add(PrivielgeNames.USER_LIST_DOWNLOAD);
		addNewUserView.add(PrivielgeNames.ADD_NEW_USER_VIEW);
		addNewUserEdit.add(PrivielgeNames.ADD_NEW_USER_EDIT);
	}
}

