package com.common.transfer.object.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import com.common.transfer.object.reportloss.entity.ReportLoss;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ClaimHistory.
 */
@Entity
@Table(name = "claim_history")
@Data
@NoArgsConstructor
public class ClaimHistory {
	
	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="history_id")
	private Integer id;
	
    /** The claim id. */
    @OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	@JoinColumn (name="report_loss_id")
	private ReportLoss claimId;
    
   	/** The comment id. */
	   @Column(name="comment_id")
   	private Integer commentId;
    
   	/** The storage id. */
	   @Column(name="storage_id")
   	private Integer storageId;
    
    /** The content. */
    @Column(name = "content")
    private String content;
    
    /** The is recievable. */
    @Column(name = "is_recievable")
    private Boolean isRecievable;
    
    /** The section name. */
    @Column(name = "section_name")
    private String sectionName;
    
    /** The stage name. */
    @Column(name = "stage_name")
    private String stageName;
    
    /** The state. */
    @Column(name = "state")
    private String state;

	/** The identity. */
	@Column(name="identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;

	/** The created date. */
	@Column(name="created_date")
	private Date createdDate;

	/** The created by. */
	@Column(name="created_by")
	private int createdBy;
	
	/** The modified date. */
	@Column(name="modified_date")
	private Date modifiedDate;
	
	/** The modified by. */
	@Column(name="modified_by")
	private int modifiedBy;
	
	/** The is deleted. */
	@Column(name="is_deleted")
	private boolean isDeleted;

    /** The pdf path. */
    @Column(name = "pdf_path")
    private String pdfPath;

}
