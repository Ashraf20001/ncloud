package com.common.transfer.object.reportloss.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

import org.hibernate.annotations.GenericGenerator;

import java.util.Date;

/**
 * The Class DropdownOptions.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "dropdown_options")
public class DropdownOptions {
    
    /** The dropdown options id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "dropdown_options_id")
    private int dropdownOptionsId;
    
    /** The dropdown option. */
    @Column(name = "dropdown_option")
    private String dropdownOption;

    /** The created date. */
    @Column(name="created_date")
    private Date createdDate;

    /** The created by. */
    @Column(name="created_by")
    private int createdBy;

    /** The modified date. */
    @Column(name="modified_date")
    private Date modifiedDate;

    /** The modified by. */
    @Column(name="modified_by")
    private int modifiedBy;

    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @GenericGenerator(name = "uuid", strategy = "uuid4")
    private String identity;

    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;
    
    /** The parant option. */
    @Column(name = "parant_option")
    private Integer parant_option;
}
