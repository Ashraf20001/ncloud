package com.common.transfer.object.externalApi.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class ContactExternalDto.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ContactExternalDto {
	
/** The contact name. */
private String contactName;

/** The contact phone. */
private String contactPhone;//GARAGE CONTACT DETAILS

/** The email address. */
private String emailAddress;

}
