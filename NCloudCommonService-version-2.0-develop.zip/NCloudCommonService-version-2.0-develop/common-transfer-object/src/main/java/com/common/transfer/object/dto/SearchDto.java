package com.common.transfer.object.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SearchDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SearchDto {
	
	/** The column names. */
	private List<String> columnNames;
	
	/** The queries. */
	private List<QueryDto> queries;
}
