package com.common.transfer.object.entity;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ForgetPassword.
 */
@Entity
@Data
@Table(name="forget_email")
@NoArgsConstructor
@AllArgsConstructor
public class ForgetPassword {

	
	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	/** The identity. */
	@Column(name = "identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;
	
	/** The user profile identity. */
	@Column(name = "user_identity")
	private String userProfileIdentity;
	
	/** The email id. */
	@Column(name = "email_id")
	private String emailId;
	
	/** The created at. */
	@Column(name = "created_at")
	private LocalDate createdAt;
	
	/** The expiri time. */
	@Column(name = "expire_at")
	private Date expiriTime;
	
	/** The user profile. */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="user_id")
	@JsonIgnore
	private Userprofile userProfile;
}
