package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class ReportLossForNotificationDto.
 */
@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ReportLossForNotificationDto {
	
	/** The claim id. */
	private Integer claimId;
	
	/** The State. */
	private String State;
	
	/** The claim sequence id. */
	private String claimSequenceId;
	

}
