package com.common.transfer.object.entity;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * The Class Menu.
 */
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Table(name = "um_menu")
public class Menu {
	  
  	/** The menu id. */
  	@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name="menu_id")
	    private Integer menuId;
	    
    	/** The menu name. */
    	@Column(name="menu_name")
	    private String menuName;
	    
    	/** The created date. */
    	@Column(name="created_date")
	    private LocalDateTime createdDate;
	    
    	/** The created by. */
    	@Column(name="created_by")
	    private Integer createdBy;
	    
    	/** The modified date. */
    	@Column(name="modified_date")
	    private LocalDateTime modifiedDate;
	    
    	/** The modified by. */
    	@Column(name="modified_by")
	    private Integer modifiedBy;
	    
    	/** The identity. */
    	@Column(name = "identity")
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private String identity;
	    
    	/** The is deleted. */
    	@Column(name = "is_deleted")
	    private Boolean isDeleted = false;
	    
    	/** The order by. */
    	@Column(name = "order_by")
	    private Integer orderBy;
	    
    	/** The platform id. */
    	@OneToOne
		@JoinColumn(name="platform_id")
		private Platform platformId;
	    
    	/** The route url. */
    	@Column(name = "route_url")
	    private String routeUrl;
	    
    	/** The logo path. */
    	@Column(name="logo_path")
	    private String logoPath;
	    
	    

	   	/** The belongs to company. */
	   	@Column(name="belongs_to_company")
	   	private Integer belongsToCompany;

	    /**
    	 * Instantiates a new menu.
    	 *
    	 * @param menuId the menu id
    	 */
    	public Menu(Integer menuId){
	        this.menuId = menuId;
	    }
	}


