package com.common.transfer.object.dto;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class InsuredAndTpArray.
 */
@Data
@NoArgsConstructor
public class InsuredAndTpArray {

	/** The insurence company names. */
	private List<String> insurenceCompanyNames;
	
	/** The tp company names. */
	private List<String> tpCompanyNames;
}
