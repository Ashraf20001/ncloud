package com.common.transfer.object.entity;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.common.transfer.object.reportloss.entity.DropdownOptions;
import com.common.transfer.object.reportloss.entity.ReportLoss;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class TotalLoss.
 */
@Entity
@Table(name = "total_loss")
@Data
@NoArgsConstructor
public class TotalLoss {

	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	/** The report loss. */
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="claim_id")
	private ReportLoss reportLoss;
	
	/** The adjustor name 1. */
	@Column(name="adjustor_name1")
	private String adjustorName1;
	
	/** The adjustor name 2. */
	@Column(name="adjustor_name2")
	private String adjustorName2;
	
	/** The survey date 1. */
	@Column(name="survey_date1")
	private Date surveyDate1;
	
	/** The survey date 2. */
	@Column(name="survey_date2")
	private Date surveyDate2;
	
	/** The total loss amount 1. */
	@Column(name="total_loss_amount1")
	private Double totalLossAmount1;
	
	/** The total loss amount 2. */
	@Column(name="total_loss_amount2")
	private Double totalLossAmount2;
	
	/** The reason for total loss. */
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name="reason_for_total_loss")
	private DropdownOptions reasonForTotalLoss;
	
	/** The estimated total loss amount. */
	@Column(name="estimated_total_loss_amount")
	private Double estimatedTotalLossAmount;
	
	/** The salvage seller name. */
	@Column(name="salvage_seller_name")
	private String salvageSellerName;
	
	/** The salvage amount. */
	@Column(name="salvage_amount")
	private Double salvageAmount;
	
	/** The salvage buyer name. */
	@Column(name="salvage_buyer_name")
	private String salvageBuyerName;
	
	/** The is deleted. */
	@Column(name="is_deleted")
	private boolean isDeleted;
	
	/** The identity. */
	@Column(name="identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;

	/** The created date. */
	@Column(name="created_date")
	private LocalDate createdDate;

	/** The created by. */
	@Column(name="created_by")
	private int createdBy;
	
	/** The modified date. */
	@Column(name="modified_date")
	private LocalDate modifiedDate;

	/** The modified by. */
	@Column(name="modified_by")
	private int modifiedBy;
	
}
