package com.common.transfer.object.dto;

import java.util.List;
import java.util.Map;

import com.common.transfer.object.entity.BulkImportMapping;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BulkImportFieldValidationDto.
 */
@Data
@NoArgsConstructor
public class BulkImportFieldValidationDto {
	  
  	/** The user id. */
  	private String userId;
	    
    	/** The insurer name. */
    	private String insurerName;
	    
    	/** The initial row number. */
    	private Integer initialRowNumber;
	    
    	/** The bulk import history dto. */
    	private BulkImportHistoryDto bulkImportHistoryDto;
	    
    	/** The map list. */
    	private List<Map<String,String>> mapList;
	    
    	/** The field list. */
    	private List<FieldDto> fieldList;
	    
    	/** The user info. */
    	private UserInfo userInfo;
	    
    	/** The upload type. */
    	private String uploadType;
	    
    	/** The total row in excel. */
    	private Integer totalRowInExcel;
	    
    	/** The pool count details. */
    	private PoolCountDetails poolCountDetails;
	    
    	/** The is last process. */
    	private Boolean isLastProcess;
	    
    	/** The upload action. */
    	private String uploadAction;
	    
    	/** The bulk import mapping data. */
    	private List<BulkImportMapping> bulkImportMappingData;
	}
