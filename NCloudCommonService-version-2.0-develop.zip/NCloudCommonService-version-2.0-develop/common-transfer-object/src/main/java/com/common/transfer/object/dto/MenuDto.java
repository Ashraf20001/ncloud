package com.common.transfer.object.dto;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class MenuDto.
 */
@Data
@NoArgsConstructor
public class MenuDto {
 
/** The menu id. */
private Integer menuId;
	
	/** The menu name. */
	private String menuName;
	
	/** The route url. */
	private String routeUrl;
	
	/** The logo path. */
	private String logoPath;
}
