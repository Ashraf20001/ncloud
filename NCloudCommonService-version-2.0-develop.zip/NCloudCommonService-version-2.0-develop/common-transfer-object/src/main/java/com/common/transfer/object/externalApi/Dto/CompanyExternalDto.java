package com.common.transfer.object.externalApi.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class CompanyExternalDto.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CompanyExternalDto {
	
/** The company id. */
private String companyId;

/** The name. */
private String name;

/** The short name. */
private String shortName;


}
