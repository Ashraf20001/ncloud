package com.common.transfer.object.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class SubSectionDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class SubSectionDto {
    
    /** The section id. */
    private String sectionId;
    
    /** The section name. */
    private String sectionName;
    
    /** The field list. */
    private List<FieldDto> fieldList;
}
