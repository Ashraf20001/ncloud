package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class EntityMgntEmailDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EntityMgntEmailDto {
    
    /** The id. */
    private Integer id;
    
    /** The Name. */
    private String Name;
    
    /** The email. */
    private String email;
    
    /** The pasword. */
    private String pasword;
    
    /** The user name. */
    private String userName;
    
}
