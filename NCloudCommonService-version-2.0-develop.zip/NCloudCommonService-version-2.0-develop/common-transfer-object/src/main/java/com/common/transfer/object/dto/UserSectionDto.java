package com.common.transfer.object.dto;

import java.time.LocalDateTime;

import lombok.Data;

/**
 * The Class UserSectionDto.
 */
@Data
public class UserSectionDto {

	    /** The user section mapping id. */
    	private Integer userSectionMappingId;
	  
	    /** The user id. */
    	private UserDto userId;

	    /** The section id. */
    	private SectionDto sectionId;
	
	    /** The menu id. */
    	private MenuDto menuId;

	    /** The page id. */
    	private PageMappingDto pageId;
	    
    	/** The is notification. */
    	private Boolean isNotification;
	    
    	/** The created date. */
    	private LocalDateTime createdDate;
	    
    	/** The created by. */
    	private Integer createdBy;
	    
    	/** The modified date. */
    	private LocalDateTime modifiedDate;
	    
    	/** The modified by. */
    	private Integer modifiedBy;
	    
    	/** The identity. */
    	private String identity;
	    
    	/** The is deleted. */
    	private Boolean isDeleted = false;
}
