package com.common.transfer.object.dto;

import java.util.List;

/**
 * The Enum SectionPrivilegeEnum.
 */
public enum SectionPrivilegeEnum {
	
	/** The digital paper taken isview. */
	DIGITAL_PAPER_TAKEN_ISVIEW(SectionPrivelageMapDto.digitalPaperTakenList),
	
	/** The digital paper status isview. */
	DIGITAL_PAPER_STATUS_ISVIEW(SectionPrivelageMapDto.digitalPaperstatusList),
	
	/** The recent digital papers isview. */
	RECENT_DIGITAL_PAPERS_ISVIEW(SectionPrivelageMapDto.recentDigitalPaper),
	
	/** The prediction isview. */
	PREDICTION_ISVIEW(SectionPrivelageMapDto.predictionlist),
	
	/** The upcoming expiry digital papers isview. */
	UPCOMING_EXPIRY_DIGITAL_PAPERS_ISVIEW(SectionPrivelageMapDto.upcomingExpiryDigitalPapers),
	
	/** The purchase list isview. */
	PURCHASE_LIST_ISVIEW(SectionPrivelageMapDto.purchaseListView),
	
	/** The purchase list isdownload. */
	PURCHASE_LIST_ISDOWNLOAD(SectionPrivelageMapDto.purchaseListDownload),
	
	/** The paper list isview. */
	PAPER_LIST_ISVIEW(SectionPrivelageMapDto.newPaperListView),
	
	/** The paper list isdownload. */
	PAPER_LIST_ISDOWNLOAD(SectionPrivelageMapDto.newPaperListDownload),
	
	/** The generate paper manual isview. */
	GENERATE_PAPER_MANUAL_ISVIEW(SectionPrivelageMapDto.generatePaperManualSave),
	
	/** The generate paper bulk isdownload. */
	GENERATE_PAPER_BULK_ISDOWNLOAD(SectionPrivelageMapDto.generatePaperBulkSaveDownload),
	
	/** The generate paper bulk isview. */
	GENERATE_PAPER_BULK_ISVIEW(SectionPrivelageMapDto.generatePaperBulkView),
	
	/** The revoke manual isview. */
	REVOKE_MANUAL_ISVIEW(SectionPrivelageMapDto.revokeManualView),
	
	/** The revoke bulk isview. */
	REVOKE_BULK_ISVIEW(SectionPrivelageMapDto.revokeBulkView),
	
	/** The reports isview. */
	REPORTS_ISVIEW(SectionPrivelageMapDto.reportsView),
	
	/** The reports isedit. */
	REPORTS_ISEDIT(SectionPrivelageMapDto.reportsEdit),
	
	/** The reports isdownload. */
	REPORTS_ISDOWNLOAD(SectionPrivelageMapDto.reportsDownload),
	
	/** The generate reports isview. */
	GENERATE_REPORTS_ISVIEW(SectionPrivelageMapDto.generateReportsView),
	
	/** The no of digital paper purchased vs no of digital paper allocated isview. */
	NO_OF_DIGITAL_PAPER_PURCHASED_VS_NO_OF_DIGITAL_PAPER_ALLOCATED_ISVIEW(SectionPrivelageMapDto.digitalPaperAllocatedView),
	
	/** The digital paper status authority isview. */
	DIGITAL_PAPER_STATUS_AUTHORITY_ISVIEW(SectionPrivelageMapDto.digitalPaperStatusView),
	
	/** The top purchases isview. */
	TOP_PURCHASES_ISVIEW(SectionPrivelageMapDto.topPurchasesView),
	
	/** The recent transaction isview. */
	RECENT_TRANSACTION_ISVIEW(SectionPrivelageMapDto.recentTransactionView),
	
	/** The recent digital papers authority isview. */
	RECENT_DIGITAL_PAPERS_AUTHORITY_ISVIEW(SectionPrivelageMapDto.recentDigitalPaperView),
	
	/** The paper details list isview. */
	PAPER_DETAILS_LIST_ISVIEW(SectionPrivelageMapDto.paperDetailsView),
	
	/** The paper details list isdownload. */
	PAPER_DETAILS_LIST_ISDOWNLOAD(SectionPrivelageMapDto.paperDetailsDownload),
	
	/** The view paper isview. */
	VIEW_PAPER_ISVIEW(SectionPrivelageMapDto.viewPaperView),
	
	/** The view paper isdownload. */
	VIEW_PAPER_ISDOWNLOAD(SectionPrivelageMapDto.viewPaperDownload),
	
	/** The purchase history list isview. */
	PURCHASE_HISTORY_LIST_ISVIEW(SectionPrivelageMapDto.purchaseHistoryView),
	
	/** The view history isview. */
	VIEW_HISTORY_ISVIEW(SectionPrivelageMapDto.viewHistoryView),
	
	/** The view history isdownload. */
	VIEW_HISTORY_ISDOWNLOAD(SectionPrivelageMapDto.viewHistoryDownload),
	
	/** The approve isview. */
	APPROVE_ISVIEW(SectionPrivelageMapDto.approveView),
	
	/** The reject isview. */
	REJECT_ISVIEW(SectionPrivelageMapDto.rejectView),
	
	/** The pool list isview. */
	POOL_LIST_ISVIEW(SectionPrivelageMapDto.poolListView),
	
	/** The allocate stock isview. */
	ALLOCATE_STOCK_ISVIEW(SectionPrivelageMapDto.allocateStockView),
	
	/** The reallocate isview. */
	REALLOCATE_ISVIEW(SectionPrivelageMapDto.reallocateView),
	
	/** The deallocate isview. */
	DEALLOCATE_ISVIEW(SectionPrivelageMapDto.deallocateView),
	
	/** The customer isview. */
	CUSTOMER_ISVIEW(SectionPrivelageMapDto.customerView),
	
	/** The customer isdownload. */
	CUSTOMER_ISDOWNLOAD(SectionPrivelageMapDto.customerDownload),
	
	/** The customer isedit. */
	CUSTOMER_ISEDIT(SectionPrivelageMapDto.customerEdit),
	
	/** The purchase history list isdownload. */
	PURCHASE_HISTORY_LIST_ISDOWNLOAD(SectionPrivelageMapDto.purchaseHistoryDownload),
	
	/** The user role list isview. */
	USER_ROLE_LIST_ISVIEW(SectionPrivelageMapDto.userRoleListView),
	
	/** The user role list isedit. */
	USER_ROLE_LIST_ISEDIT(SectionPrivelageMapDto.userRoleListEdit),
	
	/** The user role list isdownload. */
	USER_ROLE_LIST_ISDOWNLOAD(SectionPrivelageMapDto.userRoleListDownload),
	
	/** The user role list isclone. */
	USER_ROLE_LIST_ISCLONE(SectionPrivelageMapDto.userRoleListClone),
	
	/** The user role list isdisable. */
	USER_ROLE_LIST_ISDISABLE(SectionPrivelageMapDto.userRoleListDisable),
	
	/** The add new role isview. */
	ADD_NEW_ROLE_ISVIEW(SectionPrivelageMapDto.addNewRoleView),
	
	/** The add new role isedit. */
	ADD_NEW_ROLE_ISEDIT(SectionPrivelageMapDto.addNewRoleEdit),
	
	/** The user list isview. */
	USER_LIST_ISVIEW(SectionPrivelageMapDto.userListView),
	
	/** The user list isedit. */
	USER_LIST_ISEDIT(SectionPrivelageMapDto.userListEdit),
	
	/** The user list isdownload. */
	USER_LIST_ISDOWNLOAD(SectionPrivelageMapDto.userListDownload),
	
	/** The add new user isview. */
	ADD_NEW_USER_ISVIEW(SectionPrivelageMapDto.addNewUserView),
	
	/** The add new user isedit. */
	ADD_NEW_USER_ISEDIT(SectionPrivelageMapDto.addNewUserEdit);
	
	/** The privilege list. */
	public List<String> privilegeList;

	/**
	 * Instantiates a new section privilege enum.
	 *
	 * @param privilegeList the privilege list
	 */
	SectionPrivilegeEnum(List<String> privilegeList) {
		this.privilegeList = privilegeList;
	}
}
