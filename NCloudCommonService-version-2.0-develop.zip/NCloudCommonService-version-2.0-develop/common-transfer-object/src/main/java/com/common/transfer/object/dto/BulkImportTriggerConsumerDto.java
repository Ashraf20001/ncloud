package com.common.transfer.object.dto;

import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BulkImportTriggerConsumerDto.
 */
@Data
@NoArgsConstructor
public class BulkImportTriggerConsumerDto implements Serializable {
	 
 	/** The bulk import history dto. */
 	private BulkImportHistoryDto bulkImportHistoryDto;
	    
    	/** The page identity. */
    	private String pageIdentity;
	    
    	/** The insurer. */
    	private String insurer;
	    
    	/** The user id. */
    	private Integer userId;
	    
    	/** The bulk import identity. */
    	private String bulkImportIdentity;
	    
    	/** The user info. */
    	private UserInfo userInfo;
	    
    	/** The upload type. */
    	private String uploadType;
	    
    	/** The pool count details. */
    	private PoolCountDetails poolCountDetails;
	    
    	/** The upload action. */
    	private String uploadAction;
	    
	}
