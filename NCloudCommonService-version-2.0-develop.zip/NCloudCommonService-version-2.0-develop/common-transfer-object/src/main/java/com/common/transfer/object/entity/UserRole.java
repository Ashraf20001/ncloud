package com.common.transfer.object.entity;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserRole.
 */
@Entity
@Table(name = "user_role")
@Data
@NoArgsConstructor
public class UserRole {

	/** The role id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="role_id")
	private int roleId;

	/** The role name. */
	@Column(name="role_name")
	private String role_name;

	/** The description. */
	@Column(name="description")
	private String description;

	/** The is active. */
	@Column(name="is_active")
	private Boolean isActive;

	/** The in active date. */
	@Column(name="in_active_date")
	private LocalDateTime inActiveDate;

	/** The is deleted. */
	@Column(name="is_deleted")
	private boolean isDeleted;

	/** The identity. */
	@Column(name="identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;

	/** The created date. */
	@Column(name="created_date")
	private Date createdDate;

	/** The created by. */
	@Column(name="created_by")
	private int createdBy;

	/** The modified date. */
	@Column(name="modified_date")
	private Date modifiedDate;

	/** The modified by. */
	@Column(name="modified_by")
	private int modifiedBy;
	
	/** The is system role. */
	@Column(name="is_system_role")
	private boolean isSystemRole;
	
	/** The effective date. */
	@Column(name="effective_date")
	private LocalDateTime effectiveDate;


}
