package com.common.transfer.object.vo.dto;

import java.util.List;

import com.common.transfer.object.dto.DropDownFieldDto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class Field.
 */
@Data
@NoArgsConstructor
public class Field {
	
	/** The field id. */
	private String fieldId;
	
	/** The field name. */
	private String fieldName;
	
	/** The field type. */
	private String fieldType;	
	
	/** The field default. */
	private String fieldDefault;
    
    /** The alias name. */
    private String aliasName;
    
    /** The mandatory. */
    private Boolean mandatory;
    
    /** The is core data. */
    private Boolean isCoreData;
    
    /** The reference id. */
    private Integer referenceId;
    
    /** The is system generated. */
    private Boolean isSystemGenerated;
	
	/** The value. */
	private String value;
	
	/** The minlength. */
	private Integer minlength;
	
	/** The maxlength. */
	private Integer maxlength;
	
	/** The regex. */
	private String regex;
    
    /** The field position. */
    private Integer fieldPosition;
    
    /** The identity. */
    private String identity;
    
    /** The error message. */
    private String errorMessage;
    
    /** The drop down list. */
    private List<DropDownFieldDto> dropDownList;
	
}
