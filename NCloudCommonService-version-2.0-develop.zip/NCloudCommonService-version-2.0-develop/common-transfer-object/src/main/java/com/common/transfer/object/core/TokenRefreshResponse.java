package com.common.transfer.object.core;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class TokenRefreshResponse.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TokenRefreshResponse {
	  
  	/** The access token. */
  	private String accessToken;
	  
  	/** The refresh token. */
  	private String refreshToken;
	  
  	/** The token type. */
  	private String tokenType = "Bearer";
}
