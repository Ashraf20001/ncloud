package com.common.transfer.object.chart;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The Class StackedBarChartDaysDiffDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class StackedBarChartDaysDiffDto {
    
    /** The label. */
    private List<String> label;
    
    /** The company. */
    private Object company;
    
    /** The count. */
    private List<Long> count;
}
