package com.common.transfer.object.dto;

import java.time.LocalDateTime;
import java.util.Date;

import lombok.Data;

/**
 * The Class GarageMappingDto.
 */
@Data
public class GarageMappingDto {
	
	/** The garage id. */
	private Integer garageId;

	/** The short id. */
	private String shortId;

	/** The garage name. */
	private String garageName;

	/** The email. */
	private String email;

	/** The phone. */
	private String phone;

	/** The location. */
	private String location;

	/** The password. */
	private String password;

	/** The address. */
	private String address;

	/** The user id. */
	private String userId;

	/** The logo. */
	private String logo;

	/** The created date. */
	private Date createdDate;

	/** The created by. */
	private Integer createdBy;

	/** The modified date. */
	private Date modifiedDate;

	/** The modified by. */
	private Integer modifiedBy;


	/** The identity. */
	private String identity;

	/** The is deleted. */
	private Boolean isDeleted = false;

	/** The is active. */
	private Boolean isActive=true;
	
	/** The effective to. */
	private LocalDateTime effectiveTo;

}
