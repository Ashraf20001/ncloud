package com.common.transfer.object.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserDisableDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDisableDto {

	/** The expired date. */
	private LocalDateTime expiredDate;
	 
 	/** The identity. */
 	private String identity;
	 
 	/** The user id. */
 	private Integer userId;
	 
 	/** The is mapped. */
 	private Boolean isMapped;
}
