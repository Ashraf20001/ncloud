package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserRoleManagementViewDTO.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserRoleManagementViewDTO {
    
    /** The is active. */
    private Boolean isActive;
    
    /** The role details. */
    private MetaDataViewDto roleDetails;
    
    /** The access mapping. */
    private AccessMappingDto accessMapping;
}
