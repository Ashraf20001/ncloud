package com.common.transfer.object.core;

import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.common.transfer.object.entity.Userprofile;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class RefreshToken.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity(name = "refreshtoken")
public class RefreshToken {
  
  /** The id. */
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  /** The user. */
  @OneToOne
  @JoinColumn(name = "login_user_id")
  private Userprofile user;

  /** The token. */
  @Column(nullable = false, unique = true)
  private String token;

  /** The expiry date. */
  @Column(name="expiry_date",nullable = false)
  private Instant expiryDate;
  
  /** The identity. */
  @Column(name = "identity")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private String identity;
  
  /** The is deleted. */
  @Column(name = "is_deleted")
  private Boolean isDeleted = false;
}
