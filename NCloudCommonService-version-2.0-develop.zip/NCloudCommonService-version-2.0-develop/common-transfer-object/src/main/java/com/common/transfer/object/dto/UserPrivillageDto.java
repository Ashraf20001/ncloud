package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserPrivillageDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserPrivillageDto {

	/** The Privillage id. */
	private Integer PrivillageId;

	/** The Privillage name. */
	private String PrivillageName;
}
