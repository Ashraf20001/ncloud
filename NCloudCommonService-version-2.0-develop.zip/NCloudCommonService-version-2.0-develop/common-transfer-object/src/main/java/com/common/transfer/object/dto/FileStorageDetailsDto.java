package com.common.transfer.object.dto;



import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The Class FileStorageDetailsDto.
 */
@Data
@NoArgsConstructor
public class FileStorageDetailsDto {
	
	
	
	/** The url. */
	private String url;
	
	/** The upload type. */
	private String uploadType;
	
	/** The report type. */
	private String reportType;
	
	/** The storage type. */
	private String storageType;
	
	/** The reference id. */
	private long referenceId;
	
	/** The file size. */
	private Long fileSize;

}
