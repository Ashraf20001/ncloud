package com.common.transfer.object.dto;


import java.time.LocalDateTime;

import com.common.transfer.object.vo.dto.IConfigurable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * The Class companyViewDto.
 */
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class companyViewDto implements IConfigurable {
	
	/** The em ins company id. */
	private String emInsCompanyId;
	
	/** The em ins name. */
	private String emInsName;
	
	/** The em ins phone. */
	private String emInsPhone;
	
	/** The em ins email. */
	private String emInsEmail;
	
	/** The em ins password. */
	private String emInsPassword;
	
	/** The em ins location. */
	private String emInsLocation;
	
	/** The em ins address. */
	private String emInsAddress;
	
	/** The em ins max time. */
	private Double emInsMaxTime;
	
	/** The em ins max payable amount. */
	private Double emInsMaxPayableAmount;
	
	/** The em ins logo. */
	private String emInsLogo;
	
	/** The em ins user name. */
	private String emInsUserName;
	
	/** The em ins is active. */
	private Boolean emInsIsActive=true;
    
    /** The em ins short name. */
    private String emInsShortName;
    
    /** The em ins exceed date. */
    private LocalDateTime emInsExceedDate;

}
