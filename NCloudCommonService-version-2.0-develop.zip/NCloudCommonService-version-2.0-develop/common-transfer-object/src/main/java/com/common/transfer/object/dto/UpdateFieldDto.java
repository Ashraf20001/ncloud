package com.common.transfer.object.dto;

import java.util.List;

import lombok.Data;

/**
 * The Class UpdateFieldDto.
 */
@Data
public class UpdateFieldDto {

	/** The stage. */
	private String stage;
	
	/** The section. */
	private String section;
	
	/** The field list. */
	private List<FieldDto> fieldList;
}
