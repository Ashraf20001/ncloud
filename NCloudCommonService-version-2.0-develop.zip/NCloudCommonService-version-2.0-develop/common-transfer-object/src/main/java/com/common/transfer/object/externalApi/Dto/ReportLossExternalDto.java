package com.common.transfer.object.externalApi.Dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class ReportLossExternalDto.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ReportLossExternalDto {
	
  /** The id. */
  private Integer id;
  
  /** The fnol no. */
  private String fnolNo;//CLAIMNO SEQUENCE
  
  /** The claim ref no. */
  private String claimRefNo;//NEED TO FIND
  
  /** The recovery letter. */
  private boolean recoveryLetter;//NO NEED
  
  /** The date ofloss. */
  private String dateOfloss;
  
  /** The date of reported. */
  private String dateOfReported;
  
  /** The police report no. */
  private String policeReportNo;
  
  /** The insured claim no. */
  private String insuredClaimNo;
  
  /** The third party claim no. */
  private String thirdPartyClaimNo;
  
  /** The insured info. */
  private InsuredInfoExternalDto insuredInfo;
  
  /** The third party info. */
  private ThirdPartyInfoExternalDto thirdPartyInfo;
  
  /** The garage info. */
  private GarageExternalDto garageInfo;
  
  /** The documents. */
  private List<DocumentExternalDto> documents;
  
  /** The status. */
  private String status;
  
  /** The user comment. */
  private UserCommentExternalDto userComment;
  
  /** The nature of loss. */
  private String natureOfLoss;//TL
  
  /** The reserve amount. */
  private Double reserveAmount;//LD RESERVE
  
  /** The total reserve amount. */
  private Double totalReserveAmount;//RR RESEREVE
  
  /** The third party reserve amount. */
  private Double thirdPartyReserveAmount;
  
  /** The estimated total loss amount. */
  private Double estimatedTotalLossAmount;//TL
  
  /** The survey estimated amount. */
  private Double surveyEstimatedAmount;
  
  /** The claim amount. */
  private Double claimAmount;//RD CLAIM
  
  /** The settle amount. */
  private Double settleAmount;
  
  /** The third party settle amount. */
  private Double thirdPartySettleAmount;//RR CLAIM
  
  /** The is total loss. */
  private Boolean isTotalLoss;
  
  /** The total loss details. */
  private TotalLossExternalDto totalLossDetails;
  
  /** The spare part cost. */
  private Double sparePartCost;
  
  /** The labour cost. */
  private Double labourCost;
  
}
