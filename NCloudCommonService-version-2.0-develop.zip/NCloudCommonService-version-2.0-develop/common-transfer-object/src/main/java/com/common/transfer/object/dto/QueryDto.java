package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class QueryDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QueryDto {
		
		/** The column name. */
		private String columnName;
		
		/** The value 1. */
		private Object value1;
		
		/** The value 2. */
		private Object value2;
		
		/** The condition. */
		private String condition;
}
