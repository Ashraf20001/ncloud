package com.common.transfer.object.entity;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AllocationUserType.
 */
@Entity
@Table(name="allocation_user_type")
@Data
@NoArgsConstructor
public class AllocationUserType{
	
	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="type_id")
	private Integer id;
	
	/** The user type name. */
	@Column(name="user_type_name")
	private String userTypeName;
	
	/** The identity. */
	@Column(name="identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;

	/** The created date. */
	@Column(name="created_date")
	private Date createdDate;

	/** The created by. */
	@Column(name="created_by")
	private int createdBy;
	
	/** The modified date. */
	@Column(name="modified_date")
	private Date modifiedDate;
	
	/** The modified by. */
	@Column(name="modified_by")
	private int modifiedBy;
	
	/** The is deleted. */
	@Column(name="is_deleted")
	private boolean isDeleted;	
	
	/** The is mapped. */
	@Column(name="is_mapped")
	private boolean isMapped;	
	
	/** The association id. */
	@Column(name="association_id")
	private Integer associationId;	

}

