package com.common.transfer.object.entity;

import lombok.*;

import javax.persistence.*;


import java.time.LocalDateTime;

/**
 * The Class RolePageMapping.
 */
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Table(name = "um_role_page_mapping")
public class RolePageMapping {
    
    /** The role page mapping id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="role_page_mapping_id")
    private Integer rolePageMappingId;
    
    /** The role id. */
    @OneToOne
    @JoinColumn(name = "role_id")
    private Role roleId;
    
    /** The page id. */
    @OneToOne
    @JoinColumn(name = "page_id")
    private Page pageId;
    
    /** The is enabled. */
    @Column(name="is_enabled")
    private Boolean isEnabled;

    /** The created date. */
    @Column(name="created_date")
    private LocalDateTime createdDate;
    
    /** The created by. */
    @Column(name="created_by")
    private Integer createdBy;
    
    /** The modified date. */
    @Column(name="modified_date")
    private LocalDateTime modifiedDate;
    
    /** The modified by. */
    @Column(name="modified_by")
    private Integer modifiedBy;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private Boolean isDeleted = false;
}
