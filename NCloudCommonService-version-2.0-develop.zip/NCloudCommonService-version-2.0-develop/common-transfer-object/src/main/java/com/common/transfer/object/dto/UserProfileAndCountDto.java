package com.common.transfer.object.dto;

import com.common.transfer.object.entity.UserRoleMapping;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserProfileAndCountDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserProfileAndCountDto {
    
    /** The user. */
    private UserRoleMapping user;
    
    /** The count. */
    private Long count;
}
