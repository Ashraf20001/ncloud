package com.common.transfer.object.vo.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class MasterDataMappingDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MasterDataMappingDto {
	
	/** The table name. */
	private String tableName;
	
	/** The dis play name. */
	private String disPlayName;
	
	/** The plat form id. */
	private Integer platFormId;
	
	/** The is selected. */
	private Boolean isSelected;
	
	/** The relation mapping tables. */
	private List<MasterDataMappingDto> relationMappingTables;

}
