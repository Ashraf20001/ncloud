package com.common.transfer.object.dto;

import java.util.Date;

import lombok.Data;

/**
 * The Class PageMappingDto.
 */
@Data
public class PageMappingDto {

	/** The page id. */
	private int pageId;
	
	/** The page name. */
	private String pageName;
	
	/** The display name. */
	private String displayName;

	/** The menu id. */
	private int menuId;
	
	/** The is deleted. */
	private boolean isDeleted;
	

	/** The identity. */
	private String identity;

	/** The created date. */
	private Date createdDate;

	/** The created by. */
	private int createdBy;
	
	/** The modified date. */
	private Date modifiedDate;

	/** The modified by. */
	private int modifiedBy;

	/** The order by. */
	private Integer orderBy;
}