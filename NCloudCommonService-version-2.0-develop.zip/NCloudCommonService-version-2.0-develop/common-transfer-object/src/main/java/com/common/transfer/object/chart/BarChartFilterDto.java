package com.common.transfer.object.chart;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BarChartFilterDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BarChartFilterDto {
    
    /** The label. */
    private String label;
    
    /** The receivable. */
    private Object receivable;
    
    /** The payable. */
    private Object payable;
}
