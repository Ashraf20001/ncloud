package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class RecentClaimDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RecentClaimDto {

	/** The claim id. */
	private Integer claimId;
	
	/** The history message. */
	private String historyMessage;
	
	/** The stage. */
	private String stage;
	
	/** The section. */
	private String section;
	
	/** The claim identity. */
	private String claimIdentity;
}
