package com.common.transfer.object.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class EnableNotificationDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EnableNotificationDto {
    
    /** The menu data. */
    private List<AccessMappingMenuDto> menuData;

}
