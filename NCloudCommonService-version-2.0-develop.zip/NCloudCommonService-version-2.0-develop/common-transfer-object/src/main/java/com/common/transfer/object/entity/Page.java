package com.common.transfer.object.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class Page.
 */
@Entity
@Table(name = "page")
@Data
@NoArgsConstructor
public class Page {
	
	/** The page id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="page_id")
	private int pageId;
	
	/** The page name. */
	@Column(name="page_name")
	private String pageName;
	
	/** The display name. */
	@Column(name="display_name")
	private String displayName;

	/** The menu id. */
	@Column(name = "menu_id")
	private int menuId;
	
	/** The platform. */
	@OneToOne
	@JoinColumn(name="platform_id")
	private Platform platform;
	
	/** The is deleted. */
	@Column(name="is_deleted")
	private boolean isDeleted;
	
	/** The identity. */
	@Column(name="identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;

	/** The created date. */
	@Column(name="created_date")
	private Date createdDate;

	/** The created by. */
	@Column(name="created_by")
	private int createdBy;
	
	/** The modified date. */
	@Column(name="modified_date")
	private Date modifiedDate;

	/** The modified by. */
	@Column(name="modified_by")
	private int modifiedBy;

	/** The order by. */
	@Column(name = "order_by")
	private Integer orderBy;

	/**
	 * Instantiates a new page.
	 *
	 * @param pageId the page id
	 */
	public Page(Integer pageId){
		this.pageId = pageId;
	}

}
