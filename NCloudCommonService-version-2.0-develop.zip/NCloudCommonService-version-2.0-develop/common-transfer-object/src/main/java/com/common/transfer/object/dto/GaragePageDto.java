package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class GaragePageDto.
 */
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class GaragePageDto {

		 /** The garage id. */
 		private String garageId;
		  
  		/** The meta data. */
  		private MetaDataViewDto metaData;
}
