package com.common.transfer.object.externalApi.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class UserCommentExternalDto.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserCommentExternalDto {
	
/** The reason. */
private String reason;

/** The last comment. */
private String lastComment;

}
