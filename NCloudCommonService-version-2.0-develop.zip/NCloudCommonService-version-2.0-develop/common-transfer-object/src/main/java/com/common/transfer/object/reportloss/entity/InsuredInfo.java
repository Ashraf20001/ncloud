package com.common.transfer.object.reportloss.entity;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class InsuredInfo.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rl_insured_info")
public class InsuredInfo {
	
	/** The insured info id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "insured_info_id")
    private int insuredInfoId;
    
    /** The insured name. */
    @Column(name = "insured_name")
    private String insuredName;
    
    /** The insurer name. */
    @Column(name = "insurer_name")
    private String insurerName;
    
    /** The vehicle details. */
    @ManyToOne(cascade = {CascadeType.ALL})
    @JoinColumn(name = "vehicle_details")
    private VehicleDetails vehicleDetails;

    /** The purchase date. */
    @Column(name = "purchase_date")
    private LocalDateTime purchaseDate;
    
    /** The sum insured. */
    @Column(name = "sum_insured")
    private Double sumInsured;
    
    /** The created date. */
    @Column(name="created_date")
    private LocalDateTime createdDate;

    /** The created by. */
    @Column(name="created_by")
    private int createdBy;

    /** The modified date. */
    @Column(name="modified_date")
    private LocalDateTime modifiedDate;

    /** The modified by. */
    @Column(name="modified_by")
    private int modifiedBy;

    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;

    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;

}
