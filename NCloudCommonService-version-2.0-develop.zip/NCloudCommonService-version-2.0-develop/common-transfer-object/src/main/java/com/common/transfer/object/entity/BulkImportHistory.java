package com.common.transfer.object.entity;

import lombok.*;

import javax.persistence.*;

import com.common.transfer.object.reportloss.entity.Company;

import java.time.LocalDateTime;

/**
 * The Class BulkImportHistory.
 */
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Table(name = "bulk_import_history")
public class BulkImportHistory {
	 
 	/** The upload id. */
 	@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name="upload_id")
	    private Integer uploadId;
	    
    	/** The success count. */
    	@Column(name="success_count")
	    private Integer successCount;
	    
    	/** The failure count. */
    	@Column(name="failure_count")
	    private Integer failureCount;
	    
    	/** The total count. */
    	@Column(name="total_count")
	    private Integer totalCount;
	    
    	/** The status. */
    	@Column(name="status")
	    private String status;
	    
    	/** The storage id. */
    	@OneToOne
	    @JoinColumn(name="storage_id")
	    private FileStorageDetails storageId;
	    
    	/** The company id. */
    	@OneToOne
	    @JoinColumn(name="company_id")
	    private Company companyId;
	    
    	/** The page id. */
    	@OneToOne
	    @JoinColumn(name="page_id")
	    private Page pageId;
	    
    	/** The created date. */
    	@Column(name="created_date")
	    private LocalDateTime createdDate;
	    
    	/** The created by. */
    	@Column(name="created_by")
	    private Integer createdBy;
	    
    	/** The modified date. */
    	@Column(name="modified_date")
	    private LocalDateTime modifiedDate;
	    
    	/** The modified by. */
    	@Column(name="modified_by")
	    private Integer modifiedBy;
	    
    	/** The identity. */
    	@Column(name = "identity")
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private String identity;
	    
    	/** The is deleted. */
    	@Column(name = "is_deleted")
	    private Boolean isDeleted = false;
	    
    	/** The pool id. */
    	@Column(name="pool_id")
	    private Integer poolId;
	    
    	/** The platform id. */
    	@OneToOne
	    @JoinColumn(name = "platform_id")
	    private Platform platformId;
	    
    	/** The upload type. */
    	@Column(name="upload_type")
	    private Integer uploadType;
	    
    	/** The upload action type. */
    	@Column(name="action_type")
	    private Integer uploadActionType;
	}
