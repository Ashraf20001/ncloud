package com.common.transfer.object.dto;

import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * The Class UserManagementListDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class UserManagementListDto {

    /** The user id. */
    private Integer userId;
    
    /** The email id. */
    private String emailId;
    
    /** The user name. */
    private String userName;
    
    /** The user role list. */
    private List<UserRoleDto> userRoleList;
    
    /** The added date. */
    private Date addedDate;
    
    /** The status. */
    private Boolean status;
    
    /** The user identity. */
    private String userIdentity;
    
    /** The phone number. */
    private String phoneNumber;
    
    /** The password. */
    private String password;
    
    /** The profile url. */
    private String profileUrl;
    
    /** The user seq id. */
    private String userSeqId;
    
    /** The is disable. */
    private Boolean isDisable;
}
