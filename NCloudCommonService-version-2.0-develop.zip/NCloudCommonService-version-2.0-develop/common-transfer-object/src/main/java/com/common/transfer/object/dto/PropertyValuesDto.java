package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class PropertyValuesDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class PropertyValuesDto {
	
	/** The property value. */
	private String propertyValue;
	
	/** The property name. */
	private String propertyName;
}
