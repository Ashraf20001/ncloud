package com.common.transfer.object.externalApi.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class ThirdPartyInfoExternalDto.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ThirdPartyInfoExternalDto {
	
	/** The policy number. */
	private String policyNumber;
	
	/** The company. */
	private CompanyExternalDto company;
	
	/** The vehicle details. */
	private VehicleExternalDto vehicleDetails;
	
}
