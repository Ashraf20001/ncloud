package com.common.transfer.object.dto;

import java.util.List;

import com.common.transfer.object.entity.Menu;
import com.common.transfer.object.entity.Page;
import com.common.transfer.object.entity.Privilege;
import com.common.transfer.object.entity.RoleMenuMapping;
import com.common.transfer.object.entity.RolePageMapping;
import com.common.transfer.object.entity.RolePrivilegeMapping;
import com.common.transfer.object.entity.RoleSectionMapping;
import com.common.transfer.object.entity.Section;
import com.common.transfer.object.entity.UserSectionMapping;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class RoleAccessDto.
 */
@Data
@NoArgsConstructor
public class RoleAccessDto {

    /** The menu dto list. */
    List<Menu> menuDtoList;
    
    /** The page dto list. */
    List<Page> pageDtoList;
    
    /** The section dto list. */
    List<Section> sectionDtoList;
    
    /** The privilege dto list. */
    List<Privilege> privilegeDtoList;
    
    /** The role menu mapping list. */
    List<RoleMenuMapping> roleMenuMappingList;
    
    /** The role page mapping list. */
    List<RolePageMapping> rolePageMappingList;
    
    /** The role section mapping list. */
    List<RoleSectionMapping> roleSectionMappingList;
    
    /** The role privilege mapping list. */
    List<RolePrivilegeMapping> rolePrivilegeMappingList;
    
    /** The user section mapping list. */
    List<UserSectionMapping> userSectionMappingList;
}
