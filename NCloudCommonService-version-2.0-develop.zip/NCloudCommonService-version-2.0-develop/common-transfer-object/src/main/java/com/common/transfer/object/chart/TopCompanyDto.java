package com.common.transfer.object.chart;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class TopCompanyDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TopCompanyDto {
    
    /** The company name. */
    private String companyName;
    
    /** The total claim amount. */
    private Double totalClaimAmount;
    
    /** The total claim count. */
    private Long totalClaimCount;
}
