package com.common.transfer.object.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AccessMappingMenuDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccessMappingMenuDto {
    
    /** The menu id. */
    private Integer menuId;
    
    /** The menu name. */
    private String menuName;
    
    /** The is enabled. */
    private Boolean isEnabled = true;
    
    /** The page data. */
    private List<AccessMappingPageDto> pageData;
}
