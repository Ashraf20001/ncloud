package com.common.transfer.object.vo.dto;


/**
 * The Enum UploadTypeEnum.
 */
public enum UploadTypeEnum {
	
	
	/** The normal. */
	NORMAL(1, "NORMAL"), /** The fleet. */
 FLEET(2, "FLEET");

	/** The id. */
	Integer id;
	
	/** The upload type. */
	String uploadType;

	/**
	 * Instantiates a new upload type enum.
	 *
	 * @param id the id
	 * @param uploadType the upload type
	 */
	private UploadTypeEnum(Integer id, String uploadType) {
		this.id = id;
		this.uploadType = uploadType;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * Gets the upload type.
	 *
	 * @return the upload type
	 */
	public String getUploadType() {
		return uploadType;
	}

	/**
	 * Sets the upload type.
	 *
	 * @param uploadType the new upload type
	 */
	public void setUploadType(String uploadType) {
		this.uploadType = uploadType;
	}

	/**
	 * Gets the paper type by name.
	 *
	 * @param uploadType the upload type
	 * @return the paper type by name
	 */
	public static UploadTypeEnum getPaperTypeByName(String uploadType) {
		for (UploadTypeEnum onePaymentStatusEnum : UploadTypeEnum.values()) {
			if (onePaymentStatusEnum.name().equalsIgnoreCase(uploadType)) {
				return onePaymentStatusEnum;
			}
		}
		return null;
	}
	
	/**
	 * Gets the paper type by id.
	 *
	 * @param uploadTypeId the upload type id
	 * @return the paper type by id
	 */
	public static UploadTypeEnum getPaperTypeById(Integer uploadTypeId) {
		for (UploadTypeEnum onePaymentStatusEnum : UploadTypeEnum.values()) {
			if (onePaymentStatusEnum.getId().equals(uploadTypeId)) {
				return onePaymentStatusEnum;
			}
		}
		return null;
	}


}
