package com.common.transfer.object.dto;

import com.common.transfer.object.vo.dto.IConfigurable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserDetailsViewDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDetailsViewDto implements IConfigurable {
	   
   	/** The um user id. */
   	private Integer umUserId;
	    
    	/** The um user name. */
    	private String umUserName;
	    
    	/** The um email id. */
    	private String umEmailId;
	    
    	/** The um phone number. */
    	private String umPhoneNumber;
	    
    	/** The um address. */
    	private String umAddress;
	    
    	/** The um user role. */
    	private String umUserRole;
	    
    	/** The um password. */
    	private String umPassword;
	    
    	/** The um user type. */
    	private String umUserType;
	    
    	/** The um auth user type. */
    	private String umAuthUserType;
	    
    	/** The um association user type. */
    	private String umAssociationUserType;

	}
