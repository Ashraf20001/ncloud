package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class MenuDetailsDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MenuDetailsDto {

/** The menu name. */
private String menuName;

/** The role name. */
private String roleName;

/** The is enabled. */
private Boolean isEnabled;
}
