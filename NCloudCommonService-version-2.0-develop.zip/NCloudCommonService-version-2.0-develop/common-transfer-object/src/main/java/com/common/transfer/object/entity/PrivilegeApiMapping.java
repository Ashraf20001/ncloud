package com.common.transfer.object.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

import javax.persistence.*;


/**
 * The Class PrivilegeApiMapping.
 */
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "privilege_api_mapping")
public class PrivilegeApiMapping {
	
	/** The privilege api id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "privilege_api_id")
    private Integer privilegeApiId;
    
    /** The privilege details. */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "privilege_id")
    private Privilege privilegeDetails;
    
    /** The page details. */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "page_id")
    private Page pageDetails;

    /** The api details. */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "api_details_id")
    private APIDetails apiDetails;
    
    /** The created date. */
    @Column(name="created_date")
    private LocalDateTime createdDate;
    
    /** The created by. */
    @Column(name="created_by")
    private Integer createdBy;
    
    /** The modified date. */
    @Column(name="modified_date")
    private LocalDateTime modifiedDate;
    
    /** The modified by. */
    @Column(name="modified_by")
    private Integer modifiedBy;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
     private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private Boolean isDeleted = false;
	

}
