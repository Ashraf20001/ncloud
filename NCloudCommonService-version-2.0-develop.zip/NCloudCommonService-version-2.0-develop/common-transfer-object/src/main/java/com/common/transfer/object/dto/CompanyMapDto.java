package com.common.transfer.object.dto;

import lombok.Data;

/**
 * The Class CompanyMapDto.
 */
@Data
public class CompanyMapDto {
	
	/** The company id. */
	private Integer companyId;
	
	/** The identity. */
	private String identity;
	
	/** The company name. */
	private String companyName;

}
