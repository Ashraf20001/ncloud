package com.common.transfer.object.dto;

import java.util.List;

import lombok.Data;

/**
 * The Class FieldConfiguratorDto.
 */
@Data
public class FieldConfiguratorDto {

	/** The page id. */
	private String pageId;
	
	/** The updated fields. */
	private List<UpdateFieldDto> updatedFields;
	
	/** The deleted fields. */
	private List<DeleteFieldDto> deletedFields;
	
}
