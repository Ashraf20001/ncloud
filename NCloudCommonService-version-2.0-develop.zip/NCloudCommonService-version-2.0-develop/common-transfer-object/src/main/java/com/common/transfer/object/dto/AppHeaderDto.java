package com.common.transfer.object.dto;
import java.util.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AppHeaderDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AppHeaderDto {

    /** The menu details. */
    private List<MenuDto> menuDetails;
	
	/** The platform details. */
	private PlatformDetailsDto platformDetails;
	
	/** The company logo path. */
	private String companyLogoPath;
}
