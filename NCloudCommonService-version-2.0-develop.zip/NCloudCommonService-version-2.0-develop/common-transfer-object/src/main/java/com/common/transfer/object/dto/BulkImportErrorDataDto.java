package com.common.transfer.object.dto;

import com.common.transfer.object.entity.BulkImportHistory;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The Class BulkImportErrorDataDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BulkImportErrorDataDto {
    
    /** The bulk import error data id. */
    private Integer bulkImportErrorDataId;
    
    /** The upload id. */
    private Integer uploadId;
    
    /** The row id. */
    private Integer rowId;
    
    /** The error detail. */
    private String errorDetail;
    
    /** The identity. */
    private String identity;
}
