package com.common.transfer.object.dto;

import java.util.List;

import lombok.Data;

/**
 * The Class ApprovalRoleLimitRequest.
 */
@Data
public class ApprovalRoleLimitRequest {
	
	/** The role ids. */
	private List<Integer> roleIds;
	
	/** The field ids. */
	private List<Integer> fieldIds;
}
