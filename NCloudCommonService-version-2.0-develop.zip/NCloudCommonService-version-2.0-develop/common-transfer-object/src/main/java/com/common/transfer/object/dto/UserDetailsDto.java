package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserDetailsDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDetailsDto {

	/** The id. */
	private Integer id;
	
	/** The username. */
	private String username;
}
