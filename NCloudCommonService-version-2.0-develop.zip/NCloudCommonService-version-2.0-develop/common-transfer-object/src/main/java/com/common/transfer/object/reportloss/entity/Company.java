package com.common.transfer.object.reportloss.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import com.common.transfer.object.entity.Association;

import java.io.Serializable;
import java.util.Date;

/**
 * The Class Company.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rl_company")
@Audited
public class Company implements Serializable {
    
    /** The Constant serialVersionUID. */
	private static final long serialVersionUID = -7837930115416918151L;
	
	/** The company id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "company_id")
    private Integer companyId;
    
    /** The name. */
    @Column(name = "name")
    private String name;
    
    /** The short name. */
    @Column(name = "short_name")
    private String shortName;

    /** The created date. */
    @Column(name="created_date")
    private Date createdDate;

    /** The created by. */
    @Column(name="created_by")
    private Integer createdBy;

    /** The modified date. */
    @Column(name="modified_date")
    private Date modifiedDate;

    /** The modified by. */
    @Column(name="modified_by")
    private Integer modifiedBy;
    
    /** The email. */
    @Column(name="email")
    private String email;
    
    /** The phone. */
    @Column(name="phone")
    private String phone;
    
    /** The location. */
    @Column(name="location")
    private String location;
    
    /** The password. */
    @Column(name="password")
    private String password;
    
    /** The address. */
    @Column(name="address")
    private String address;

    /** The logo. */
    @Column(name="logo")
    private String logo;
    
    /** The association. */
    @ManyToOne
    @JoinColumn(name = "association_id")
    @NotAudited
    private Association association;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;

    /** The is deleted. */
    @Column(name = "is_deleted")
    private Boolean isDeleted = false;
    
    /** The is active. */
    @Column(name = "is_Active")
    private Boolean isActive = true;

    /**
     * Instantiates a new company.
     *
     * @param companyId the company id
     */
    public Company(Integer companyId){
        this.companyId = companyId;
        
        
    }
}
