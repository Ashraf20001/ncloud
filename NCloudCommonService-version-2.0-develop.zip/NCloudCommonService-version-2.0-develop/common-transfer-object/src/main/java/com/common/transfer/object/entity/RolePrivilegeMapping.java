package com.common.transfer.object.entity;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * The Class RolePrivilegeMapping.
 */
@Entity
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "um_role_privilege_mapping")
public class RolePrivilegeMapping {

    /** The role privilege id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "role_privilege_id")
    private Integer rolePrivilegeId;
    
    /** The user role details. */
    @OneToOne
    @JoinColumn(name = "user_role_details")
    private Role userRoleDetails;
    
    /** The privilege details. */
    @OneToOne
    @JoinColumn(name = "privilege_details")
    private Privilege privilegeDetails;
    
    /** The is enabled. */
    @Column(name="is_enabled")
    private Boolean isEnabled;

    /** The created date. */
    @Column(name="created_date")
    private LocalDateTime createdDate;
    
    /** The created by. */
    @Column(name="created_by")
    private Integer createdBy;
    
    /** The modified date. */
    @Column(name="modified_date")
    private LocalDateTime modifiedDate;
    
    /** The modified by. */
    @Column(name="modified_by")
    private Integer modifiedBy;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private Boolean isDeleted = false;
}
