package com.common.transfer.object.reportloss.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * The Class GarageInvoice.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rl_garage_invoice")
public class GarageInvoice {

    /** The garage invoice id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "garage_invoice_id")
    private int garageInvoiceId;

    /** The garage invoice no. */
    @Column(name = "garage_invoice_no")
    private String garageInvoiceNo;
    
    /** The attachment. */
    @Column(name = "attachment")
    private String attachment;

    /** The created date. */
    @Column(name="created_date")
    private LocalDateTime createdDate;
    
    /** The created by. */
    @Column(name="created_by")
    private int createdBy;
    
    /** The modified date. */
    @Column(name="modified_date")
    private LocalDateTime modifiedDate;
    
    /** The modified by. */
    @Column(name="modified_by")
    private int modifiedBy;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;
}
