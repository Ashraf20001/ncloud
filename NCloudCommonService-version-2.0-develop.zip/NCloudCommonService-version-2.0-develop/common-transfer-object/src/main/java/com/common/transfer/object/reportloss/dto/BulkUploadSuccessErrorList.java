package com.common.transfer.object.reportloss.dto;

import java.util.List;

import com.common.transfer.object.entity.BulkImportTempData;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BulkUploadSuccessErrorList.
 */
@Data
@NoArgsConstructor
public class BulkUploadSuccessErrorList {
    
    /** The report loss list. */
    private List<ReportLossDto> reportLossList;
    
    /** The error list. */
    private List<BulkImportErrorDataDto> errorList;
    
    /** The bulk import data. */
    private List<BulkImportTempData> bulkImportData;
}
