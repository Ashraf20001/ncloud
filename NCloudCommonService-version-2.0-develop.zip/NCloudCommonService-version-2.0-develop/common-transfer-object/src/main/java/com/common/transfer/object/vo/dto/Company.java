package com.common.transfer.object.vo.dto;



import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class Company.
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Company implements IConfigurable {

	/** The company id. */
	private long companyId;
	
	/** The name. */
	private String name;
	
	/** The short name. */
	private String shortName;
	
	
}
