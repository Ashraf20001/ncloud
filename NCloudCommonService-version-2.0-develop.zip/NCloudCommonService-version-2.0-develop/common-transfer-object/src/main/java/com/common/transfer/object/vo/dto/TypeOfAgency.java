package com.common.transfer.object.vo.dto;

/**
 * The Enum TypeOfAgency.
 */
public enum TypeOfAgency {
	
	/** The Agency. */
	Agency,/** The Non agency. */
NonAgency

}
