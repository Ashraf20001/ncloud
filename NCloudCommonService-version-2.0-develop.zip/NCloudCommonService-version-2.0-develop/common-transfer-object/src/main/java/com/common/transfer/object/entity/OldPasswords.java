package com.common.transfer.object.entity;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * The Class OldPasswords.
 */
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Table(name = "pwd_old_password")
public class OldPasswords {
    
    /** The old password id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="pwd_old_password_id")
    private Integer oldPasswordId;
    
    /** The old password. */
    @Column(name="old_password")
    private String oldPassword;
    
    /** The user id. */
    @OneToOne
    @JoinColumn(name="user_id")
    private Userprofile userId;
    
    /** The created date. */
    @Column(name="created_date")
    private LocalDateTime createdDate;
    
    /** The created by. */
    @Column(name="created_by")
    private Integer createdBy;
    
    /** The modified date. */
    @Column(name="modified_date")
    private LocalDateTime modifiedDate;
    
    /** The modified by. */
    @Column(name="modified_by")
    private Integer modifiedBy;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private Boolean isDeleted = false;

}

