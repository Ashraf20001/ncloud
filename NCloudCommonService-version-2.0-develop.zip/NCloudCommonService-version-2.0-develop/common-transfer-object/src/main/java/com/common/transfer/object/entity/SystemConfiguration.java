package com.common.transfer.object.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;


import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

/**
 * The Class SystemConfiguration.
 */
@Entity
@Table(name = "system_configuration")
@Data
@NoArgsConstructor
public class SystemConfiguration {
		
	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="system_configuration_id")
	private int id;
	
	/** The region. */
	@Column(name="region")
	private String region;
	
	/** The timezone. */
	@Column(name="timezone")
	private String timezone;
	
	/** The currency. */
	@Column(name="currency")
	private String currency;
	
	
	/** The role. */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_role")
	private Role role;
	
	/** The identity. */
	@NonNull
	@Column(name="identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;
	
	/** The currency details. */
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="currency_id",referencedColumnName ="currency_id" )
	private CurrencyDetails  currencyDetails;
	
}
