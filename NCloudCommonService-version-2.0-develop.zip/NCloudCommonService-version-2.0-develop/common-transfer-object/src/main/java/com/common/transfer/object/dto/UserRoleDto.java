package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserRoleDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserRoleDto {
	
	/** The role id. */
	private Integer roleId;
	
	/** The role name. */
	private String roleName;
	
	/** The allocation user type. */
	private Integer allocationUserType;
}

