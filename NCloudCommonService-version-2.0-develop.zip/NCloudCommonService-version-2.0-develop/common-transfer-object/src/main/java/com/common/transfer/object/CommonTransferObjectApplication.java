package com.common.transfer.object;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.common.*")
public class CommonTransferObjectApplication {

	public static void main(String[] args) {
		
	}

}
