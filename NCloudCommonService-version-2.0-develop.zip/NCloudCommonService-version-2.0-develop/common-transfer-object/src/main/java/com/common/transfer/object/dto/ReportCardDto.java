package com.common.transfer.object.dto;

import java.util.ArrayList;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ReportCardDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReportCardDto {
	
	/** The company name. */
	private String companyName;
	
	/** The third party company name. */
	private ArrayList<String> thirdPartyCompanyName;
	
	/** The from date. */
	private String fromDate;
	
	/** The to date. */
	private String toDate;
	
	/** The claim type. */
	private ArrayList<String> claimType;
	
	/** The select column. */
	private ArrayList<String> selectColumn;
	
	/** The file type. */
	private String fileType;
	
	/** The report type. */
	private String reportType;
	
	/** The total column count. */
	private Number totalColumnCount;
	
	/** The identity. */
	private String identity;
	
	/** The period. */
	private String period;
	
	/** The status. */
	private ArrayList<String> status;
	
	
}
