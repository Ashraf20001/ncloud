package com.common.transfer.object.reportloss.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * The Class RecoveryDetails.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rl_recovery_details")
public class RecoveryDetails {
    
    /** The recovery details id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "recovery_details_id")
    private int recoveryDetailsId;

    /** The police report fee. */
    @Column(name = "police_report_fee")
    private Double policeReportFee;
    
    /** The towing charge. */
    @Column(name = "towing_charge")
    private Double towingCharge;
    
    /** The inspection fee. */
    @Column(name = "inspection_fee")
    private Double inspectionFee;
    
    /** The other expenses. */
    @Column(name = "other_expenses")
    private Double otherExpenses;
    
    /** The cash settlement. */
    @Column(name = "cash_settlement")
    private Double cashSettlement;
    
    /** The spare parts. */
    @Column(name = "spare_parts")
    private Double spareParts;
    
    /** The labour cost. */
    @Column(name = "labour_cost")
    private Double labourCost;
    
    /** The tp survey amount. */
    @Column(name = "tp_survey_amount")
    private Double tpSurveyAmount;
    
    /** The claim amount. */
    @Column(name = "claim_amount")
    private Double claimAmount;

    /** The created date. */
    @Column(name="created_date")
    private LocalDateTime createdDate;
    
    /** The created by. */
    @Column(name="created_by")
    private int createdBy;
    
    /** The modified date. */
    @Column(name="modified_date")
    private LocalDateTime modifiedDate;
    
    /** The modified by. */
    @Column(name="modified_by")
    private int modifiedBy;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;
}
