package com.common.transfer.object.dto;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ApprovalLimitDto.
 */
@Data
@NoArgsConstructor
public class ApprovalLimitDto {
    
    /** The approval limit id. */
    private Integer approvalLimitId;
	
	/** The field name. */
	private	String fieldName;
	
	/** The stage name. */
	private	String stageName;
	
	/** The section name. */
	private String sectionName;
	
	/** The approval level. */
	private	List<ApprovalLevelDto> approvalLevel;
	
	/** The role. */
	private List<String> role;
	
	/** The is active. */
	private Boolean isActive;
	
	/** The approval limit identity. */
	private String approvalLimitIdentity;
		
	
}
