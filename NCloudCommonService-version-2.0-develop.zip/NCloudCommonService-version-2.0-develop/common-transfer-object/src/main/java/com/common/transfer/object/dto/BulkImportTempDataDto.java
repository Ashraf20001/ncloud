package com.common.transfer.object.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class BulkImportTempDataDto.
 */
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BulkImportTempDataDto {

	/** The upload data id. */
	private Integer uploadDataId;

	/** The upload id. */
	private Integer uploadId;

	/** The status. */
	private Boolean status;

	/** The error description. */
	private String errorDescription;

	/** The in registration no. */
	private String inRegistrationNo;

	/** The in make. */
	private String inMake;

	/** The in model. */
	private String inModel;

	/** The in purchase date. */
	private String inPurchaseDate;

	/** The in sum insured. */
	private String inSumInsured;

	// ThirdPartyInfo

	/** The tp name. */
	private String tpName;

	/** The tp policy number. */
	private String tpPolicyNumber;

	/** The tp claim no. */
	private String tpClaimNo;

	/** The tp registration no. */
	private String tpRegistrationNo;

	/** The tp registration type. */
	private String tpRegistrationType;

	/** The tp make. */
	private String tpMake;

	/** The tp model. */
	private String tpModel;

	// loss details

	/** The ld date of loss. */
	private String ldDateOfLoss;

	/** The ld claim number. */
	private String ldClaimNumber;

	/** The ld reported date. */
	private String ldReportedDate;

	/** The ld policy number. */
	private String ldPolicyNumber;

	/** The ld reserve amount. */
	private String ldReserveAmount;

	/** The ld police report number. */
	private String ldPoliceReportNumber;

	/** The ld is total loss. */
	private String ldIsTotalLoss;

	// garageInfo

	/** The garage name. */
	private String garageName;

	/** The garage location. */
	private String garageLocation;

	/** The garage contact details. */
	private String garageContactDetails;

	/** The garage type. */
	private String garageType;

	/** The garage invoice name. */
	private String garageInvoiceName;

	/** The sd survey allocation date. */
	private String sdSurveyAllocationDate;

	/** The sd survey due date. */
	private String sdSurveyDueDate;

	/** The sd survey report name. */
	private String sdSurveyReportName;

	// survey report

	/** The sr total loss. */
	private String srTotalLoss;

	/** The sr spare parts. */
	private String srSpareParts;

	/** The sr labour cost. */
	private String srLabourCost;

	/** The sr survey amount. */
	private String srSurveyAmount;

	/** The identity. */
	private String identity;

	/** The created date. */
	private LocalDateTime createdDate;

	/** The created by. */
	private Integer createdBy;

	/** The modified date. */
	private LocalDateTime modifiedDate;

	/** The modified by. */
	private Integer modifiedBy;

	/** The is deleted. */
	private Boolean isDeleted;

}
