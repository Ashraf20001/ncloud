package com.common.transfer.object.chart;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CompanyCountByDateDiffDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CompanyCountByDateDiffDto {
    
    /** The company. */
    private Object company;
    
    /** The count. */
    private Long count;
}
