package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class SchedulerRequestDto.
 */
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SchedulerRequestDto {
	
	/** The claim id. */
	private Integer claimId;

	/** The status. */
	private String status;

	/** The time interval. */
	private Integer timeInterval;
	
	/** The is receivable. */
	private boolean isReceivable;


}
