package com.common.transfer.object.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ApprovalLevelStateTransferDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApprovalLevelStateTransferDto {
	
	/** The min value. */
	Double minValue;
	
	/** The max value. */
	Double maxValue;
	
	/** The currency. */
	String currency;
	
	/** The role name. */
	String roleName;
	
	/** The is approval limit active. */
	Boolean isApprovalLimitActive;
	
	/** The approval limit field id. */
	Integer approvalLimitFieldId;
	
	/** The approval limit role id. */
	Integer approvalLimitRoleId;
}
