package com.common.transfer.object.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class BulkImportErrorData.
 */
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Table(name = "bulk_import_error_data")
public class BulkImportErrorData {
    
    /** The bulk import error data id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="bulk_import_error_data_id")
    private Integer bulkImportErrorDataId;
    
    /** The upload id. */
    @OneToOne
    @JoinColumn(name="upload_id")
    private BulkImportHistory uploadId;
    
    /** The row id. */
    @Column(name="row_id")
    private Integer rowId;
    
    /** The error detail. */
    @Column(name="error_detail")
    private String errorDetail;
    
    /** The created date. */
    @Column(name="created_date")
    private LocalDateTime createdDate;
    
    /** The created by. */
    @Column(name="created_by")
    private Integer createdBy;
    
    /** The modified date. */
    @Column(name="modified_date")
    private LocalDateTime modifiedDate;
    
    /** The modified by. */
    @Column(name="modified_by")
    private Integer modifiedBy;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private Boolean isDeleted = false;
}
