package com.common.transfer.object.reportloss.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BulkImportErrorDataDto.
 */
@Data
@NoArgsConstructor
public class BulkImportErrorDataDto {
    
    /** The row id. */
    private Integer rowId;
    
    /** The field name. */
    private String fieldName;
    
    /** The error id. */
    private String errorId;

}
