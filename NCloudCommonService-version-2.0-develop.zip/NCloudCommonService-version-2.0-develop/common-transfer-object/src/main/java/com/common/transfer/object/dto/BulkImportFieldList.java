package com.common.transfer.object.dto;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BulkImportFieldList.
 */
@Data
@NoArgsConstructor
public class BulkImportFieldList {
	
	/** The list of field. */
	List<FieldDto> listOfField;
	
	/** The bulk import mapping. */
	List<BulkImportMappingDto> bulkImportMapping;

}
