package com.common.transfer.object.externalApi.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class GarageExternalDto.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class GarageExternalDto {
	
/** The fnol no. */
private String fnolNo;

/** The claim no. */
private String claimNo;

/** The name. */
private String name;

/** The type. */
private String type;

/** The contact. */
private ContactExternalDto contact;

/** The address location. */
private String addressLocation;

/** The survey allocation date. */
private String surveyAllocationDate;

/** The survey due date. */
private String surveyDueDate;
}
