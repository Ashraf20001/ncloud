package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AlterDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AlterDto {
		
		/** The table name. */
		private String tableName;
		
		/** The new table name. */
		private String newTableName;
		
		/** The condition. */
		private String condition;
		
		/** The column name. */
		private String columnName;
		
		/** The data type. */
		private String dataType;
}
