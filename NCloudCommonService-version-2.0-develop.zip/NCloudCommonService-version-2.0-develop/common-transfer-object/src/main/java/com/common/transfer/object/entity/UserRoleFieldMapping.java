package com.common.transfer.object.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserRoleFieldMapping.
 */
@Entity
@Table(name = "user_role_field_mapping")
@Data
@NoArgsConstructor
public class UserRoleFieldMapping {
	
	/** The user role field mapping id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="user_role_field_mapping_id")
	private int userRoleFieldMappingId;
	
	/** The user role details. */
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="user_role_id")
	private UserRole userRoleDetails;
	
	/** The meta data details. */
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name ="meta_data_id")
	private MetaData metaDataDetails;
	
	/** The is deleted. */
	@Column(name="is_deleted")
	private boolean isDeleted;

	/** The identity. */
	@Column(name="identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;

	/** The created date. */
	@Column(name="created_date")
	private Date createdDate;

	/** The created by. */
	@Column(name="created_by")
	private int createdBy;
	
	/** The modified date. */
	@Column(name="modified_date")
	private Date modifiedDate;

	/** The modified by. */
	@Column(name="modified_by")
	private int modifiedBy;

}
