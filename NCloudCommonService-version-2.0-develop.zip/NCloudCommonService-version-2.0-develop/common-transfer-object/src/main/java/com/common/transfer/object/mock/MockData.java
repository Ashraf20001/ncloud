package com.common.transfer.object.mock;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.common.transfer.object.models.BarChartModelTemp;

/**
 * The Class MockData.
 */
public class MockData {
    
    /**
     * Gets the filter bar chart data.
     *
     * @return the filter bar chart data
     */
    public static List<BarChartModelTemp> getFilterBarChartData(){
        List<BarChartModelTemp> list = new ArrayList<>();
        list.add(new BarChartModelTemp(500,200,new Date("12/1/2022"),10000,87643));
        list.add(new BarChartModelTemp(200,100,new Date("12/2/2022"),87643,34535));
        list.add(new BarChartModelTemp(150,250,new Date("12/3/2022"),67555,87643));
        list.add(new BarChartModelTemp(300,100,new Date("12/4/2022"),10000,56765));
        list.add(new BarChartModelTemp(800,400,new Date("12/5/2022"),45444,35346));
        list.add(new BarChartModelTemp(500,700,new Date("12/6/2022"),23242,76866));
        list.add(new BarChartModelTemp(600,400,new Date("12/6/2022"),30393,34343));
        list.add(new BarChartModelTemp(10,200,new Date("12/7/2022"),12344,67688));
        list.add(new BarChartModelTemp(100,20,new Date("12/8/2022"),10000,79788));
        list.add(new BarChartModelTemp(111,22,new Date("12/9/2023"),61000,95463));
        list.add(new BarChartModelTemp(1000,762,new Date("12/1/2023"),40000,3535));
        list.add(new BarChartModelTemp(333,44,new Date("12/1/2021"),10000,5765));
        return list;
    }
}
