package com.common.transfer.object.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * The Class ApprovalLevel.
 */
@Entity(name = "um_approval_level")
@Data
@NoArgsConstructor
@Setter
@Getter
public class ApprovalLevel {
	
	/** The approval level id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="um_approval_level_id")
	private Integer approvalLevelId;
	
	/** The approval limit id. */
	@OneToOne
	@JoinColumn(name="approval_limit_id")
	private ApprovalLimit approvalLimitId;
	
	/** The role id. */
	@OneToOne
	@JoinColumn(name="role_id")
	private Role roleId;
	
	/** The min value. */
	@Column(name="min_value")
	private Double minValue;
	
	/** The max value. */
	@Column(name="max_value")
	private Double maxValue;
	
	/** The identity. */
	@Column(name="identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;

	/** The created date. */
	@Column(name="created_date")
	private Date createdDate;

	/** The created by. */
	@Column(name="created_by")
	private int createdBy;
	
	/** The modified date. */
	@Column(name="modified_date")
	private Date modifiedDate;
	
	/** The modified by. */
	@Column(name="modified_by")
	private int modifiedBy;
	
	/** The is deleted. */
	@Column(name="is_deleted")
	private boolean isDeleted;
	
	/** The from company. */
	@Column(name="from_company")
	private Integer fromCompany;
	
	/** The to company. */
	@Column(name="to_company")
	private Integer toCompany;
	
	/** The currency. */
	@Column(name="currency_type")
	private String currency;
	
}
