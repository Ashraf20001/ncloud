package com.common.transfer.object.dto;

import lombok.Data;

/**
 * The Class LdapUser.
 */
@Data
public class LdapUser {
		
		/** The user name. */
		private String userName;
		
		/** The password. */
		private String password;
		
		/** The user type. */
		private String userType;
}
