package com.common.transfer.object.dto;

import lombok.Data;

/**
 * The Class LoginDto.
 */
@Data
public class LoginDto {
	
	/** The username. */
	private String username;

	/** The password. */
	private String password;
	
	/** The platform details dto. */
	private PlatformDetailsDto platformDetailsDto;

	/** The user type dto. */
	private UserTypeDto userTypeDto;
}
