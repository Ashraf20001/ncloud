package com.common.transfer.object.dto;

import lombok.Data;

/**
 * The Class ForgetPasswordDto.
 */
@Data
public class ForgetPasswordDto {
	
	/** The email id. */
	private String emailId;
	
	/** The user type. */
	private String userType;

}
