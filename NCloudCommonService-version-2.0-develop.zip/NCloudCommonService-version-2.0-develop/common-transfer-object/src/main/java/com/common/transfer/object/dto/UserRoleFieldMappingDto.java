package com.common.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserRoleFieldMappingDto.
 */
@Data
@NoArgsConstructor
public class UserRoleFieldMappingDto {

	/** The user role field mapping id. */
	private int userRoleFieldMappingId;
	
	/** The user role id. */
	private int userRoleId;

	/** The meta data id. */
	private int metaDataId;

}