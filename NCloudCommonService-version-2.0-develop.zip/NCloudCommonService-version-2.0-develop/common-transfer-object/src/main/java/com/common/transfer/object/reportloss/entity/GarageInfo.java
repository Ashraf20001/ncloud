package com.common.transfer.object.reportloss.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * The Class GarageInfo.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rl_garage_info")
public class GarageInfo {
    
    /** The garage id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "garage_id")
    private int garageId;
    
    /** The name. */
    @Column(name = "name")
    private String name;
    
    /** The location. */
    @Column(name = "location")
    private String location;
    
    /** The contact details. */
    @Column(name = "contact_details")
    private String contactDetails;
    
    /** The type. */
    @Column(name = "type")
    private String type;
    
    /** The invoice name. */
    @Column(name="invoice_name")
    private String invoiceName;

    /** The created date. */
    @Column(name="created_date")
    private LocalDateTime createdDate;

    /** The created by. */
    @Column(name="created_by")
    private int createdBy;

    /** The modified date. */
    @Column(name="modified_date")
    private LocalDateTime modifiedDate;

    /** The modified by. */
    @Column(name="modified_by")
    private int modifiedBy;

    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;

    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;
}
