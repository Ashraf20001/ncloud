package com.common.transfer.object.vo.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class GarageInfoDto.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class GarageInfoDto implements IConfigurable  {
	
	/** The garage info id. */
	private String garageInfoId;

	/** The garage fnol no. */
	private String garageFnolNo;
	
	/** The garage claim no. */
	private String garageClaimNo;
	
	/** The garage name. */
	private String garageName;
	
	/** The garage type. */
	private TypeOfAgency garageType;
	
	/** The garage contact. */
	private ContactDto garageContact;
	
	/** The garage adress location. */
	private String garageAdressLocation;
	
	/** The garage survey allocation date. */
	private Date garageSurveyAllocationDate;
	
	/** The garage survey due date. */
	private Date garageSurveyDueDate;
}
