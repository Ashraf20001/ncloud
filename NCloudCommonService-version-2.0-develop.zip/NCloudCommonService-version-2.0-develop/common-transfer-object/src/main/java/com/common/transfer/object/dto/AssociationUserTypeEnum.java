package com.common.transfer.object.dto;

/**
 * The Enum AssociationUserTypeEnum.
 */
public enum AssociationUserTypeEnum {
	
	/** The employee. */
	EMPLOYEE("1","Employee"),
	
	/** The traffic. */
	TRAFFIC("2","Traffic Authority");
	
	 /** The id. */
 	String id;
	 
 	/** The user type. */
 	String userType;
	 
	/**
	 * Instantiates a new association user type enum.
	 *
	 * @param id the id
	 * @param userType the user type
	 */
	AssociationUserTypeEnum(String id, String userType) {
		this.id = id;
		this.userType = userType;
	}
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(String id) {
		this.id = id;
	}
	
	/**
	 * Gets the user type.
	 *
	 * @return the user type
	 */
	public String getUserType() {
		return userType;
	}
	
	/**
	 * Sets the user type.
	 *
	 * @param userType the new user type
	 */
	public void setUserType(String userType) {
		this.userType = userType;
	}
	 
	/**
	 * Gets the association user type id by name.
	 *
	 * @param userType the user type
	 * @return the association user type id by name
	 */
	public static String getAssociationUserTypeIdByName(String userType) {
		for (AssociationUserTypeEnum oneUploadTypeEnum : AssociationUserTypeEnum.values()) {
			if (oneUploadTypeEnum.name().equalsIgnoreCase(userType)) {
				return oneUploadTypeEnum.getId();
			}
		}
		return null;
	}
	
	/**
	 * Gets the association user type by id.
	 *
	 * @param id the id
	 * @return the association user type by id
	 */
	public static String getAssociationUserTypeById(String id) {
		for (AssociationUserTypeEnum oneUploadTypeEnum : AssociationUserTypeEnum.values()) {
			if (oneUploadTypeEnum.getId().equals(id)) {
				return oneUploadTypeEnum.getUserType();
			}
		}
		return null;
	}
	 

}
