package com.common.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CaptchaDataDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CaptchaDataDto {
    
    /** The captcha. */
    private String captcha;
    
    /** The captcha value. */
    private String captchaValue;
    
    /** The compare captcha data value. */
    private String compareCaptchaDataValue;
}
