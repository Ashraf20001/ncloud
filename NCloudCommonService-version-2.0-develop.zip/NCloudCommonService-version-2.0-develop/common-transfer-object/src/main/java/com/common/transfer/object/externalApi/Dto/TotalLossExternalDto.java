package com.common.transfer.object.externalApi.Dto;

import java.util.Date; 

import lombok.Data;

/**
 * The Class TotalLossExternalDto.
 */
@Data
public class TotalLossExternalDto {

	/** The id. */
	private long id;

	/** The claim id. */
	private long claimId;

	/** The sequence no. */
	private long sequenceNo;

	/** The adjustor name one. */
	private String adjustorNameOne;

	/** The adjustor name two. */
	private String adjustorNameTwo;

	/** The survey date one. */
	private Date surveyDateOne;

	/** The survey date two. */
	private Date surveyDateTwo;

	/** The total loss amount one. */
	private double totalLossAmountOne;

	/** The total loss amount two. */
	private double totalLossAmountTwo;

	/** The reason for total loss. */
	private String reasonForTotalLoss;

	/** The reason for total loss others. */
	private String reasonForTotalLossOthers;

	/** The estimated total loss amount. */
	private double estimatedTotalLossAmount;

	/** The salvage seller name. */
	private String salvageSellerName;

	/** The salvage amount. */
	private double salvageAmount;

	/** The salvage buyer name. */
	private String salvageBuyerName;

	/** The created by. */
	private String createdBy;

	/** The updated by. */
	private String updatedBy;

}
