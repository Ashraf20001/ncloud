package com.common.transfer.object.entity;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

/**
 * The Class Userprofile.
 */
@Data
@Entity
@Table(name = "rp_login_user")
@Audited
public class Userprofile  extends Auditable implements Serializable{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1793353443073665419L;

	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "USER_ID")
	private Integer id;

	/** The user sequence id. */
	@Column(name = "user_seq_id")
	private String userSequenceId;
	
	/** The identity. */
	@Column(name = "user_identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;

	/** The username. */
	@Column(name = "USER_NAME")
	private String username;

	/** The email. */
	@Column(name = "EMAIL_ID",unique=true,nullable=false)
	private String email;

	/** The password. */
	@Column(name = "PASSWORD")
	private String password;

	/** The roles. */
	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "rp_user_role", joinColumns = @JoinColumn(name = "user_id"), inverseJoinColumns = @JoinColumn(name = "role_id"))
	private Set<Role> roles = new HashSet<>();

	/** The is deleted. */
	@Column(name = "IS_DELETE")
	private int isDeleted;
	
	/** The first time login. */
	@Column(name = "first_time_login")
	private boolean firstTimeLogin;

	/** The mobileno. */
	@Column(name = "PHONE_NUMBER",unique=true,nullable=false)
	private String mobileno;

	/** The address. */
	@Column(name = "address")
	private String address;
	
	/** The effective date. */
	@Column(name="effective_date")
	private LocalDateTime effectiveDate;

	/** The status. */
	@Column(name = "status")
	private Boolean status;
	
	
	/** The forget password. */
	@OneToMany(mappedBy = "userProfile",fetch = FetchType.LAZY)
	@JsonIgnore
	@NotAudited
	private Set<ForgetPassword> forgetPassword;
	
	
	/** The user type id. */
	@OneToOne
	@JoinColumn(name="user_type_id")
	@NotAudited
	private UserType userTypeId;
	
	/** The user type. */
	@Column(name="um_user_type")
	private String userType;
	
	/** The association id. */
	@Column(name="association_id")
	private Integer associationId;
	
	/** The association user type. */
	@Column(name="association_user_type")
	private String associationUserType;
	
	/** The storage details. */
	@OneToOne
	@JoinColumn(name="user_profile_url")
	private FileStorageDetails storageDetails;
	
	/**
	 * Instantiates a new userprofile.
	 */
	public Userprofile() {
	}

	/**
	 * Instantiates a new userprofile.
	 *
	 * @param username the username
	 * @param email the email
	 * @param password the password
	 */
	public Userprofile(String username, String email, String password) {
		this.username = username;
		this.email = email;
		this.password = password;
	}
	
	

}
