package com.common.transfer.object.dto;

import com.common.transfer.object.vo.dto.FieldGroup;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserRoleSaveOrUpdateDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserRoleSaveOrUpdateDto {
    
    /** The is active. */
    private Boolean isActive = true;
    
    /** The role details. */
    private FieldGroup roleDetails;
    
    /** The access mapping. */
    private AccessMappingDto accessMapping;
}
