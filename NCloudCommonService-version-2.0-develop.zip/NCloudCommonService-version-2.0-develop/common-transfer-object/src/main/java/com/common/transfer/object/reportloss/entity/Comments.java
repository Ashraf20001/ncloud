package com.common.transfer.object.reportloss.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The Class Comments.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="comments")
public class Comments {
	
	/** The comment id. */
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="comment_id")
	private Integer commentId;
	
	/** The message. */
	@Column(name="message")
	private String message;
	
	/** The status. */
	@Column(name="status")
	private String status;
	
	/** The claim id. */
	@ManyToOne( cascade= CascadeType.ALL)
    @JoinColumn(name = "claim_id")
	private ReportLoss claimId;	
	
	/** The is receivable. */
	@Column(name="is_receivable")
	private Boolean isReceivable;
	
	/** The created by. */
	@Column(name="created_by")
	private String createdBy;
	
	/** The created date. */
	@Column(name="created_date")
	private Date createdDate;
	
	/** The is viewed. */
	@Column(name = "isViewed")
	private boolean isViewed;
	
	/** The identity. */
	@Column(name="identity")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private String identity;
	
    
}
