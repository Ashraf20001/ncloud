package com.common.transfer.object.entity;


import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ApprovalLimit.
 */
@Entity
@Table(name = "um_approval_limit")
@Data
@NoArgsConstructor
public class ApprovalLimit {
	
	/** The approval limit id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="um_approval_limit_id")
	private Integer approvalLimitId;
	
	/** The field id. */
	@Column(name="field_id")
	private Integer fieldId;
		
	/** The is active. */
	@Column(name="isActive")
	private Boolean isActive;
	
	/** The identity. */
	@Column(name="identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;

	/** The created date. */
	@Column(name="created_date")
	private Date createdDate;

	/** The created by. */
	@Column(name="created_by")
	private int createdBy;
	
	/** The modified date. */
	@Column(name="modified_date")
	private Date modifiedDate;
	
	/** The modified by. */
	@Column(name="modified_by")
	private int modifiedBy;
	
	/** The is deleted. */
	@Column(name="is_deleted")
	private boolean isDeleted;
	
	/** The company id. */
	@Column(name="company_id")
	private int companyId;
	

}
