package com.common.transfer.object.entity;

import lombok.*;

import javax.persistence.*;


import java.time.LocalDateTime;

/**
 * The Class RoleMenuMapping.
 */
@Entity
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "um_role_menu_mapping")
public class RoleMenuMapping {
    
    /** The role menu mapping id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "role_menu_mapping_id")
    private Integer roleMenuMappingId;
    
    /** The menu details. */
    @OneToOne
    @JoinColumn(name = "menu_details")
    private Menu menuDetails;
    
    /** The user role details. */
    @OneToOne
    @JoinColumn(name = "user_role_details")
    private Role userRoleDetails;
    
    /** The is enabled. */
    @Column(name="is_enabled")
    private Boolean isEnabled;
    
    /** The created date. */
    @Column(name="created_date")
    private LocalDateTime createdDate;
    
    /** The created by. */
    @Column(name="created_by")
    private Integer createdBy;
    
    /** The modified date. */
    @Column(name="modified_date")
    private LocalDateTime modifiedDate;
    
    /** The modified by. */
    @Column(name="modified_by")
    private Integer modifiedBy;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private Boolean isDeleted = false;

}
