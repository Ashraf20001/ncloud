package com.common.transfer.object.dto;

import lombok.Data;

/**
 * The Class AdditionalReserveDto.
 */
@Data
public class AdditionalReserveDto {
		
		/** The loss dec. */
		private String lossDec;
		
		/** The amount. */
		private String amount;
}
