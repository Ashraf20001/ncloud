package com.common.transfer.object.vo.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class UserCommentDto.
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class UserCommentDto implements IConfigurable  {
	
	/** The uc user comment id. */
	private long ucUserCommentId;
	
	/** The uc reason. */
	private String ucReason;
	
	/** The uc last comment. */
	private String ucLastComment;

}
