package com.common.transfer.object.vo.dto;

/**
 * The Class SqlQueryConstants.
 */
public class SqlQueryConstants {
		
		/** The Constant INT. */
		public static final String INT="INT";
		
		/** The Constant TINYINT. */
		public static final String TINYINT="tinyint(1)";
		
		/** The Constant VARCHAR. */
		public static final String VARCHAR="VARCHAR(255)";
		
		/** The Constant BIGINT. */
		public static final String BIGINT="BIGINT";
		
		/** The Constant TIMESTAMP. */
		public static final String TIMESTAMP="timestamp";
		
		/** The Constant DOUBLE. */
		public static final String DOUBLE="DOUBLE";
		
}
