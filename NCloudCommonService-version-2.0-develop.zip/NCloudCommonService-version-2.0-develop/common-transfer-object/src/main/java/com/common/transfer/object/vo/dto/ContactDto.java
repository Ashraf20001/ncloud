package com.common.transfer.object.vo.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class ContactDto.
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ContactDto implements IConfigurable {

	/** The contact id. */
	private long contactId;
	
	/** The contact name. */
	private String contactName;
	
	/** The contact phone. */
	private String contactPhone;
	
	/** The email adress. */
	private String emailAdress;
	
}
