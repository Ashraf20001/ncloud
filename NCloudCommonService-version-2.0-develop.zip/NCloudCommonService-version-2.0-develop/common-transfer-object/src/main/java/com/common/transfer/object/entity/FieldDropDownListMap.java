package com.common.transfer.object.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FieldDropDownListMap.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "field_dropdown_map")
public class FieldDropDownListMap {

	/** The field drop down list map id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer fieldDropDownListMapId;
	
	/** The field. */
	@OneToOne
    @JoinColumn(name = "field_id")
	private Field field;
	
	/** The drop down list. */
	@OneToOne
    @JoinColumn(name = "dropdownlist_id")
	private DropDownList dropDownList;
	
	/** The is deleted. */
	@Column(name="is_deleted")
	private boolean isDeleted = false;
	
	/** The identity. */
	@Column(name="identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private String identity;

	/** The created date. */
	@Column(name="created_date")
	private Date createdDate;

	/** The created by. */
	@Column(name="created_by")
	private int createdBy;
	
	/** The modified date. */
	@Column(name="modified_date")
	private Date modifiedDate;

	/** The modified by. */
	@Column(name="modified_by")
	private int modifiedBy;
}
