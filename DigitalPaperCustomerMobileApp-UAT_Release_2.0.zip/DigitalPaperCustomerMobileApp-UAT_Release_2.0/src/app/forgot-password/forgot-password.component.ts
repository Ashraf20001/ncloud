import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../services/auth-service/auth.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss'],
})
export class ForgotPasswordComponent  implements OnInit {

  forgetPassword:FormGroup
  constructor(private fb: FormBuilder,private service:AuthService,private route:Router,private toaster:ToastrService) { 
    
  }

  ngOnInit() {
    this.forgetPassword=this.fb.group({
      mailId:new FormControl("",Validators.required)
    });
  }
 
  onSumbitting(){
    if(this.forgetPassword.valid){
        const mailId=this.forgetPassword.value.mailId;
        this.service.sendMailForForgetPassword(mailId).subscribe((response)=>{
            if(response){
              this.route.navigateByUrl('/login');
              this.toaster.success("Mail Send Successfully");
            }
        })
    }
  }

}
