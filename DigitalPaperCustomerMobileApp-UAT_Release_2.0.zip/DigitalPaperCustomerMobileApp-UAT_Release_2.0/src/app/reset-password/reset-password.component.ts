import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import Validation from '../services/Validation';
import { ResetPasswordRequest } from '../models/reset-password-dto';
import { AuthService } from '../services/auth-service/auth.service';
import { Router } from '@angular/router';
import { ComplaintsService } from '../services/complaints.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss'],
})
export class ResetPasswordComponent  implements OnInit {
  resetPassword:FormGroup;

  passwordRegex = /^(?=[^A-Z]*[A-Z])(?=[^a-z]*[a-z])(?=\D*\d)[A-Za-z\d!$%@#£€*?&]{8,}$/;
  constructor(private fb:FormBuilder,private service:AuthService,private route:Router,private subjectService: ComplaintsService) { }

  ngOnInit() {
      this.resetPassword=this.fb.group({
          newPassword:new FormControl("",[Validators.required,this.noSpaceAllowed,Validators.pattern(this.passwordRegex)]),
          confrmPwd:new FormControl("",[Validators.required])
      },
      {
        validators: [Validation.match('newPassword', 'confrmPwd')]
      }
      );
  }
  showPassword=false;
  togglePasswordVisibility()
   {
     this.showPassword = !this.showPassword;
   }
   confirmPassword=false;
   toggleConfirmPasswordVisibility()
   {
this.confirmPassword=!this.confirmPassword;
   }

   noSpaceAllowed(control:FormControl){
    if (control.value!= null && control.value.indexOf(' ')!= -1) {
      return {noSpaceAllowed:true}
    }
    return null;
  }

  get f(): { [key: string]: AbstractControl } {
    return this.resetPassword.controls;
  }

   onReset(){
      if(this.resetPassword.valid){
          const resetPwd= new ResetPasswordRequest();
          resetPwd.identity=sessionStorage.getItem("customerIdentity");
          resetPwd.newPassword=this.resetPassword.value.newPassword;
          resetPwd.confirmPassword=this.resetPassword.value.confrmPwd;

          this.service.resetFirstTimePassword(resetPwd).subscribe((response)=>{
            if(response){
              console.log('Password has been resetted successfully');
              this.subjectService.setValue(true);
              this.route.navigateByUrl('/login');
            }
          })
      }
   }
}
