import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";

@Injectable({
    providedIn:'root'
})
export class NotficationService{
    
    constructor(private request:HttpClient){}
    private baseUrl = environment.API_BASE_URL+"/digital-paper";
    allNotification(){
      return  this.request.get(this.baseUrl+"/get-customer-notification-details");
    }
    updateNotificationById(identity:any){
      return this.request.get(this.baseUrl+"/update-notification?identity="+identity);
    }

    getPerticulerpaper(paperId:string) {
      return  this.request.get(this.baseUrl+"/getCustomer-paperDetails?paperId="+paperId);
    }
}