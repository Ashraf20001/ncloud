import { Injectable } from '@angular/core';
import { LoginDetals, RegisterComplaints } from '../models/register-complaints';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { ChangePasswordDto } from '../models/change-password-dto';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ComplaintsService {
   
   
   private baseUrl = environment.API_BASE_URL+ "/digital-paper";

   private getProfilePicture = new BehaviorSubject<boolean>(false);

  constructor(private http: HttpClient
    ) { }


  saveComplaints(complaintsRegisterVo: RegisterComplaints) {
    return this.http.post(this.baseUrl+"/complaints/save",complaintsRegisterVo);
  }

  updateEditProfile(loginDetails:LoginDetals) {
    return this.http.post<string>(this.baseUrl+"/Update-login-customer",loginDetails);
 }

  getComplaints() {
    return this.http.get(this.baseUrl+"/complaints/get-all-details");
  }

  getLoginDetails() {
    return this.http.get(this.baseUrl+"/get-login-customer");
 }

 changeCustomerPassword(changePassword:ChangePasswordDto) {
    return this.http.post(this.baseUrl+"/change-password",changePassword);
 }

 saveProfileUrl(customerId:number,url:string){
    return this.http.get(this.baseUrl+"/save-customerProfileUrl?customerId="+customerId+"&url="+url);
 }

 getUserProfilePicture(userIdentity:string){
  return this.http.get(this.baseUrl+"/get-profilepic?user_identity="+userIdentity);
}

setValue(value: boolean) {
  this.getProfilePicture.next(value);
}

getValue() {
  return this.getProfilePicture.asObservable();
}

}
