import { HttpClient } from "@angular/common/http";
import { EventEmitter, Injectable, Output } from "@angular/core";
import { BehaviorSubject, Observable } from "rxjs";
import { environment } from "src/environments/environment";
import { PaperDetailsDto } from "../home/home-dashboard/home-dashboard.component";

@Injectable({
    providedIn:'root'
})
export class DashboardService{

    constructor(private request:HttpClient){}
    private ClickAddnew = new BehaviorSubject<PaperDetailsDto>(null);
    public ClickAdd$ = this.ClickAddnew.asObservable();

    @Output() viewPaper = new EventEmitter<boolean>();

    private baseUrl = environment.API_BASE_URL+"/digital-paper";

    getDashboardDetails(){
      return this.request.get(this.baseUrl+"/get-login-digital-paperDetals");
    }

    sendMail(paperIdentity:string,policyNumber:string){
      return this.request.get(this.baseUrl+"/send-email?paperIdentity="+paperIdentity+"&policyNo="+policyNumber);
    }

    getImageFromUrl(url:string){
      return this.request.get(url, { responseType: 'blob' });
     }

    getAddNew(): Observable<PaperDetailsDto> {
      return this.ClickAddnew;
    }

     setAddNew(value: PaperDetailsDto) {
        return this.ClickAddnew.next(value);
    }

    onViewPaper(value:boolean){
      this.viewPaper.emit(value);
    }
}