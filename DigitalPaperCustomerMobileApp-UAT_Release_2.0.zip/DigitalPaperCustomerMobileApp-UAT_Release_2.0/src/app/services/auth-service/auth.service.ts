import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { UserType } from "src/app/enum/enum";
import { LoginDto } from "src/app/models/login-dto";
import { ResetPasswordRequest } from "src/app/models/reset-password-dto";
import { environment } from "src/environments/environment";

@Injectable({
    providedIn:"root",
})
export class AuthService{

    constructor(private httpRequest: HttpClient, private router: Router) {}

    apiurl = environment.API_BASE_URL + '/auth-service/auth/signin';

    resetFirstTimeUrl = environment.API_BASE_URL + '/digital-paper/resetpassword';

    sendMailIdToResetPasswordUrl =environment.API_BASE_URL + '/digital-paper/forgetPassword';

    commonResetPasswordUrl =environment.API_BASE_URL + '/digital-paper/updatePassword';

    platformUrl = environment.API_BASE_URL + '/api';

    ProceedLogin(username: string, password: string) {
        // const platformDetails= JSON.parse(localStorage.getItem("platformDetails"));
        const platformDetails = {
          platformId: 2,
          platformName: 'DIGITAL_PAPER',
          platformIdentity: 'e31c7ccb51d047e7930b5cf5908ae9de',
        };
    
        const userType = {
          userTypeId:UserType.User_Type_Id,
          userTypeName:UserType.User_Type_Name
        }
        const loginDto: LoginDto = {
          username: username,
          password: password,
          platformDetailsDto: platformDetails,
          userTypeDto:userType
        };
        return this.httpRequest.post(this.apiurl, loginDto);
      }

      autoLogout(expirationTime: number) {
        setTimeout(() => {
          this.logout();
        }, expirationTime);
      }
      logout() {
        this.router.navigate(['/login']);
        sessionStorage.clear();
      }

        //checking user is still loggedin or not
      IsLoggedIn() {
        let myCurrentToken = sessionStorage.getItem('token') != null;
        return myCurrentToken;
      }

        //checking jwt oken is still in session storage
        GetToken() {
          return sessionStorage.getItem('token');
        }   

      resetFirstTimePassword(request: ResetPasswordRequest) {
        return this.httpRequest.put(this.resetFirstTimeUrl, request);
      }

      sendMailForForgetPassword(mailId:string){
        return this.httpRequest.post(this.sendMailIdToResetPasswordUrl+"?emailId="+mailId,{});
      }

      updatePassword(request:ResetPasswordRequest){
        return this.httpRequest.post(this.commonResetPasswordUrl,request);
      }

}