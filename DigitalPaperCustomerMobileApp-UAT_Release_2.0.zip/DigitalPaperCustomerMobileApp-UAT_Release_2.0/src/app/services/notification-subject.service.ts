import { Injectable} from "@angular/core";
import { BehaviorSubject, Observable } from "rxjs";

@Injectable({
    providedIn: 'root'
  })
export class NotificationSubjectService{
    private ClickAddnew = new BehaviorSubject<any>(null);
    public ClickAdd$ = this.ClickAddnew.asObservable();

    private addNotification = new BehaviorSubject<any>(null);
    public addNotification$ = this.addNotification.asObservable();
    
    getAddNew():Observable<any> {
        return this.ClickAddnew;
    
      }

      setAddNew(value:any){
        return this.ClickAddnew.next(value);
    
      }

      getAddNotification():Observable<any> {
        return this.addNotification;
    
      }

      setAddNotification(value:any){
        return this.addNotification.next(value);
    
      }

}