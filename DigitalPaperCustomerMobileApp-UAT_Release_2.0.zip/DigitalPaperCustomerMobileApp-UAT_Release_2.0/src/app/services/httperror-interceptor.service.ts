import {  HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { throwError, Observable, of, EMPTY } from 'rxjs';
import { catchError, concatMap, delay, finalize, map, retryWhen, take, tap } from 'rxjs/operators';
import { AlertController, LoadingController, ToastController } from '@ionic/angular';
import { ConstantService, ErrorCode, ErrorCodeToIgnore, UnAuthorisedErrorCode } from '../enum/enum';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class HttperrorInterceptorService implements HttpInterceptor {

  constructor(private toaster:ToastrService,){}

  //checking if there is error for every http request
  intercept(request: HttpRequest<any>, next: HttpHandler) {
    return next.handle(request)
        .pipe(
            retryWhen(error => this.retryRequest(error,1)),
            catchError((error: HttpErrorResponse) => {
                const errorMessage = this.setError(error);
                console.log(error);
                return throwError(errorMessage);
            })
        );
}



  // Retry the request in case of errror
  retryRequest(error: Observable<unknown>, retryCount: number): Observable<unknown>
  {
      return error.pipe(
          concatMap((checkErr: HttpErrorResponse, count: number) => {

              if(count <= retryCount)
              {
                  switch(checkErr.status)
                  {
                  case ErrorCode.serverDown :
                      return of(checkErr);

                  // case ErrorCode.unauthenticated :
                  //     return of(checkErr);

                  }
              }
              return throwError(checkErr);
          })
      );
  }


  //setting error
  setError(error: HttpErrorResponse): string {
      let errorMessage = ConstantService.unknownError;
      if(error.error instanceof ErrorEvent) {
          // Client side error
          errorMessage = error.error.message;
      } else {
          // server side error
          if(error.status=== ErrorCode.unauthorised)
          {
            const errorIdList = JSON.parse(error.error.message);
            const errorMessage = errorIdList.errorIds[0].errorMessage;
            this.toaster.error("couldn't connect to server");
              return error.statusText
          }
          if(error.status=== 400)
          {
            const errorIdList = JSON.parse(error.error.message);
            const errorMessage = errorIdList.errorIds[0].errorMessage;
            const unAuthorisedError='Authentication Failed Please Check Your Email / Password';
            if(errorIdList.errorIds[0].errorCode !== (ErrorCodeToIgnore.companyLogoError)  
               && errorIdList.errorIds[0].errorCode !== (UnAuthorisedErrorCode.errorCode) ){
              this.toaster.error(errorMessage);
            }
            if(errorIdList.errorIds[0].errorCode===(UnAuthorisedErrorCode.errorCode)){
              this.toaster.error(unAuthorisedError);
            }
              return error.statusText;
          }

          if (error.error.message && error.status!==ErrorCode.serverDown) {
              {const errorIdList = JSON.parse(error.error.message);
                errorMessage = errorIdList.errorIds[0].errorMessage;}
                this.toaster.error(errorMessage);
                return error.statusText
          }

          if (!error.error.message && error.error && error.status!==ErrorCode.serverDown) {
              const errorIdList = JSON.parse(error.error.message)
              errorMessage = errorIdList.errorIds[0].errorMessage;}
          }

      this.toaster.error(errorMessage);
      return errorMessage;
  }
}
