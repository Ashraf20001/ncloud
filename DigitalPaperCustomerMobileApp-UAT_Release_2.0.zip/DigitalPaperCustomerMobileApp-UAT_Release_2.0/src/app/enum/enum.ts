export enum UserType{
    User_Type_Id=4,
    User_Type_Name="CUSTOMER"
}
export enum ExpireTime {
    expirationTime = 12 * 60 * 60 * 1000
  }

  export enum ErrorCode {
    serverDown = 0,
    unauthorised = 403,
    unauthenticated = 401
  }


export enum ErrorCodeToIgnore {
  companyLogoError = 'E7112',
}

  export enum UnAuthorisedErrorCode{
    errorCode='E0011'
  }

  export class ConstantService{

    public static readonly unknownError = 'Unknown error occured'

    public static readonly dashboard = 'Dashboard'

    public static readonly  reportList='/get-report-for-list'

    }

    export enum FileTypeEnum {

      EXCEL = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      CSV = 'text/csv',
      PDF = 'application/pdf',
      PNG = 'image/png'
    }

    export enum ProfileUploadRPType{
      rpType="CUSTOMER_PROFILE"
    }

  