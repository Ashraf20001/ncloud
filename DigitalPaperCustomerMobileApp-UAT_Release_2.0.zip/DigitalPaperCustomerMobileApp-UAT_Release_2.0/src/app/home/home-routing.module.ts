import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomePage } from './home.page';
import { HomeDashboardComponent } from './home-dashboard/home-dashboard.component';
import { ProfileComponent } from './profile/profile.component';
import { VehicleDetailsComponent } from './vehicle-details/vehicle-details.component';
import { NotificationsComponent } from './notifications/notifications.component';


const routes: Routes = [
  {
    path: '',
    component: HomePage,
    children: [
      {
        path: 'home_dashboard',
        component: HomeDashboardComponent,
      },
      {
        path: 'notifications',
        component: NotificationsComponent,
      },
    
      {
        path: 'vehicale_details',
        component: VehicleDetailsComponent,
      },
     
    
      {
        path: 'profile',
        component: ProfileComponent,
      },
      {
        path: '',
        redirectTo: 'home_dashboard',
        pathMatch: 'full'
      },
    ]
  }






];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomePageRoutingModule { }
