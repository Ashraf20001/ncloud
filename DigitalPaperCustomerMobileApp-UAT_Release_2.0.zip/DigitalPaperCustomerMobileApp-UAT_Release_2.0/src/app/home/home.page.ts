import { NotficationService } from 'src/app/services/notification.service';
import { AfterViewInit, Component, OnInit, SimpleChanges } from '@angular/core';
import { PhotoService } from '../services/photo.service';
import { NotificationSubjectService } from '../services/notification-subject.service';
import { ComplaintsService } from '../services/complaints.service';
import { FileUploadService } from '../services/file-upload.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage  implements OnInit,AfterViewInit{
notificationlst:any;
message:string;
preview='';
public count: number = 0;
  constructor(public photoService: PhotoService,public notificationService: NotficationService,public notificationSubjectService: NotificationSubjectService
    ,public profileService:ComplaintsService, public fileService:FileUploadService,private route:Router) { 
  
      this.profileService.getValue().subscribe(value=>{
        if(value){
          this.getProfilePic();
        }
      })
  }
  ngAfterViewInit(): void {
    
  }
  ngOnInit(): void {
    this.getProfilePic();
    this.notificationSplice();
    this.getAllNotification();
    
  }
      notificationSplice(){
        this.notificationSubjectService.getAddNotification().subscribe(res=>{
         console.log("notificationSplice",res)
          if(res){
            this.notificationlst=res;
            this.count=this.count-1;
          }
        })
      }

  menubar = 'Home';
  private getAllNotification() {

    this.notificationService.allNotification().subscribe((res) => {
      this.notificationlst = res;
      this.count = this.notificationlst?.length;
      if (this.notificationlst) {
        this.notificationSubjectService.setAddNew(this.notificationlst);
      }
    });
  }

  setHeaderMenu(event: any) {
    const menu = event.target.innerText.trim();
    if (menu === 'Home') {
      this.menubar = 'Home';
    }
   
    else if (menu === 'Profile') {
      this.menubar = 'Profile';
    }

  }

  getProfilePic(){
    let userIdentity=sessionStorage.getItem("customerIdentity");
    this.profileService.getUserProfilePicture(userIdentity).subscribe((data)=>{
      if(data){
        const profilePicture=data['content'];
        if(profilePicture===null || profilePicture===""){
          this.preview='/assets/ProfilePic.png'
        }
        else{
            this.profilePreview(profilePicture); // fileReader call
        }
      }
    });
  }
  
  profilePreview(profilePicture:string) {
    this.fileService.downloadImageByImageName(profilePicture).subscribe((response:Blob)=>{
     const reader = new FileReader();
     reader.onload = (e: any) => {
       this.preview = e.target.result;
     };
    reader.readAsDataURL(response);
    })
  }


  onLogout(){
    this.route.navigateByUrl('/login');
    sessionStorage.clear()
  }
 

addPhotoToGallery() {
  this.photoService.addNewToGallery();
}
}
