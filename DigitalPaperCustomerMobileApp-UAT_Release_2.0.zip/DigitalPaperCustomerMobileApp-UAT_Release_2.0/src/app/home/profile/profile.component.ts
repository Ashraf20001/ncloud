import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { ProfileUploadRPType } from 'src/app/enum/enum';
import { ChangePasswordDto } from 'src/app/models/change-password-dto';
import { LoginDetals } from 'src/app/models/register-complaints';
import Validation from 'src/app/services/Validation';
import { ComplaintsService } from 'src/app/services/complaints.service';
import { FileUploadService } from 'src/app/services/file-upload.service';

@Component({
   selector: 'app-profile',
   templateUrl: './profile.component.html',
   styleUrls: ['./profile.component.scss'],
})
export class ProfileComponent implements OnInit {

   loginDetaild= new LoginDetals();
   isPasswordReadonly: boolean = true;
   isShowEditProfile:boolean=true;
   changePassword:FormGroup;
   passwordRegex = /^(?=[^A-Z]*[A-Z])(?=[^a-z]*[a-z])(?=\D*\d)[A-Za-z\d!$%@#£€*?&]{8,}$/;
   isDisabled=false;
   role="Customer";
   userName: any;
   phoneNumber: any;

   // For Files
   selectedFiles?: FileList;
   currentFile?: File;
    preview = '';
   fileUrl: any;

   constructor(
      private service:ComplaintsService,
      public formBuilder: FormBuilder,private fileUploadService:FileUploadService,private toster:ToastrService
   ) { }


   editSave=true;

   editSaveChanges()
   {
     this.editSave=!this.editSave;
   }

   userNameValueChange(username:any){
      this.userName=username;
    }

    phoneNumberValueChange(phoneNumber:any){
      this.phoneNumber=phoneNumber;
    }

   ngOnInit() {

       this.changePassword = this.formBuilder.group({
         oldPassword:new FormControl("",[Validators.required]),
         newPassword:new FormControl("",[Validators.required,this.noSpaceAllowed,Validators.pattern(this.passwordRegex)]),
         confirmPassword: new FormControl("", [Validators.required]),
       },

         {
           validators: [Validation.match('newPassword', 'confirmPassword')],
         },

       );
      this.getLoginDetals();
   }

   get f(): { [key: string]: AbstractControl } {
      return this.changePassword.controls;
    }

    noSpaceAllowed(control:FormControl){
      if (control.value!= null && control.value.indexOf(' ')!= -1) {
        return {noSpaceAllowed:true}
      }
      return null;
  }

  selectFile(event: any): void {

   this.preview = '';

   this.selectedFiles = event.target.files;

   if (this.selectedFiles) {
     const file: File= this.selectedFiles.item(0);

     if (file) {
       this.preview = '';
       this.currentFile = file;
       const reader = new FileReader();

       reader.onload = (e: any) => {
         this.preview = e.target.result;
       };

       reader.readAsDataURL(this.currentFile);
     }
   }
 }


  changePwd(){
   if(this.changePassword.valid){
     const passwordDto=new ChangePasswordDto();
     passwordDto.oldPassword = this.changePassword.value.oldPassword;
     passwordDto.newPassword = this.changePassword.value.newPassword;
     passwordDto.confirmPassword=this.changePassword.value.confirmPassword;

       this.service.changeCustomerPassword(passwordDto).subscribe(data=>{
           alert("Password Successfully changed");
           this.showedit=true;
           this.passwordChanged();
       });

   }
}

   editProfile(){
      this.isShowEditProfile=false;
      this.isPasswordReadonly= !this.isPasswordReadonly;
      this.editSave=!this.editSave;
   }

   updateProfile(){
        let loginData=new LoginDetals();
      if(this.userName!=null || this.phoneNumber!=null){
         loginData.username=this.userName;
         loginData.phoneNumber=this.phoneNumber;
       // Assigning null value to the used variables inorder to avoid duplicate entries in further operations
         this.userName=null;
         this.phoneNumber=null
        }
      
        this.editSave=!this.editSave;
      if (this.currentFile != null && this.currentFile != undefined && (loginData.username != null || loginData.phoneNumber)) {
         this.updatingUserDataAndLogo(loginData); // This method will be called when both profile picture and data are modified by user
      }
      else if (this.currentFile != null && this.currentFile != undefined) {
         this.updateProfilePicture();  // This method will be called when profile picture alone is modified by user
      }
      else {
         this.updateProfileData(loginData); // This method will be called when profile data alone is modified by user
      }
   }


   updatingUserDataAndLogo(loginData:LoginDetals){
      this.service.updateEditProfile(loginData).subscribe((value)=>{
        if(value['content']){
          const customerId:number=this.loginDetaild.customerId;
          this.fileUploadService.upload(
            [this.currentFile],
            customerId.toString(),
            ProfileUploadRPType.rpType).subscribe((response)=>{
              if(response) {
                const downloadUrl = response.content;
                this.fileUrl=downloadUrl
              }
              this.service.saveProfileUrl(customerId,this.fileUrl).subscribe((data)=>{
               this.isShowEditProfile = !this.isShowEditProfile;
               this.isPasswordReadonly = !this.isPasswordReadonly;
               this.toster.success("Profile Updated Successfully", "");
               this.service.setValue(true);
              });
            });
        }
      })
    }



    updateProfilePicture(){
      const customerId:number=this.loginDetaild.customerId;
          this.fileUploadService.upload(
            [this.currentFile],
            customerId.toString(),
            ProfileUploadRPType.rpType).subscribe((response)=>{
              if(response) {
                const downloadUrl = response.content;
                this.fileUrl=downloadUrl
              }
              this.service.saveProfileUrl(customerId,this.fileUrl).subscribe((data)=>{
               this.isShowEditProfile = !this.isShowEditProfile;
               this.isPasswordReadonly = !this.isPasswordReadonly;
               this.service.setValue(true);
               this.toster.success("Profile Updated Successfully", "");
              });
         });

    }


   updateProfileData(loginData: LoginDetals) {
      this.service.updateEditProfile(loginData).subscribe((data: any) => {
         if (data['content']) {
            this.isShowEditProfile = !this.isShowEditProfile;
            this.isPasswordReadonly = !this.isPasswordReadonly;
            this.toster.success("Profile Updated Successfully", "");
         }
      });
   }

   getLoginDetals() {
      this.service.getLoginDetails().subscribe((data:any)=>{

         this.loginDetaild = data['content'];
         this.getImage(this.loginDetaild.customerUrl);

         this.isDisabled=true;

      })
   }

   showPasswordOld = false;
   togglePasswordVisibilityOld() {
      this.showPasswordOld = !this.showPasswordOld;
   }
   showPasswordNew = false;
   togglePasswordVisibilityNew() {
      this.showPasswordNew = !this.showPasswordNew;
   }
   showPasswordConfirm = false;
   togglePasswordVisibilityConfirm() {
      this.showPasswordConfirm = !this.showPasswordConfirm;
   }
   showedit = true;
   showEditProfile() {
      this.showedit = !this.showedit;
     this.isDisabled = true;
     this.isPasswordReadonly = true;
   // this.ngOnInit();
   }

   showChangePassword(){
      this.showedit = !this.showedit;
      this.isDisabled = true;
      this.isPasswordReadonly = true;
   }
   passwordchange = false;
   hiddenPassword = false;
   passwordChanged() {
      this.passwordchange = true;
      this.hiddenPassword = true;
   }
   oldPasswordValidation():boolean{
      return this.changePassword.value.newPassword===this.changePassword.value.oldPassword;
   }



   fileName: string;
   file: File;

   // trigger() {
   // //   let element = document.getElementById('upload_file') as HTMLInputElement;
   //   element.click();
   // }

   getImage(profileUrl: string): void {
      this.preview=''
      if(profileUrl===null){
        this.preview='/assets/ProfilePic.png';
      }
      this.fileUploadService.downloadImageByImageName(profileUrl).subscribe((response:Blob)=>{
        const reader = new FileReader();
          reader.onload = (e: any) => {
            this.preview = e.target.result;
          };
         reader.readAsDataURL(response);
      });
    }
}
