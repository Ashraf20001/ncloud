import { Component, OnInit, Output } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DashboardService } from 'src/app/services/dashboard.service';
import { PaperDetailsDto } from '../home-dashboard/home-dashboard.component';
import { ModalController } from '@ionic/angular';
import { ViewPaperComponent } from '../view-paper-component/view-paper-component.component';

@Component({
  selector: 'app-vehicle-details',
  templateUrl: './vehicle-details.component.html',
  styleUrls: ['./vehicle-details.component.scss'],
})
export class VehicleDetailsComponent  implements OnInit {

  vehicleDetails:PaperDetailsDto;

  

  constructor(private dashboardService:DashboardService,public modalControl : ModalController) { 
    // this.route.queryParams.subscribe((value)=>{
    //   if(value){
    //     this.vehicleDetails=value['paperData'];
    //   }
    // })
    this.dashboardService.ClickAdd$.subscribe((value:any)=>{
      if(value){
        this.vehicleDetails=value;
      }
    });
    
  }

  ngOnInit() {}
  
  onViewPaper(){

    this.modalControl.create({
      component:ViewPaperComponent,
      cssClass:'my-modal',
      componentProps:this.vehicleDetails
    }).then(modalResponse =>{
      modalResponse.present();
    });


  }

}
