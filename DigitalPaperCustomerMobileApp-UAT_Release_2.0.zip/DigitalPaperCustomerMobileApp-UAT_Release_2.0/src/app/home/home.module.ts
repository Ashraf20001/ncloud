import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HomePage } from './home.page';

import { HomePageRoutingModule } from './home-routing.module';
import { ProfileComponent } from './profile/profile.component';
import { HomeDashboardComponent } from './home-dashboard/home-dashboard.component';

import { VehicleDetailsComponent } from './vehicle-details/vehicle-details.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { ViewPaperComponent } from './view-paper-component/view-paper-component.component';



@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    IonicModule,
    HomePageRoutingModule,
  ],
  declarations: [HomePage,
    ProfileComponent,
    HomeDashboardComponent,
    NotificationsComponent,
    VehicleDetailsComponent,
    ViewPaperComponent
 
    ]
})
export class HomePageModule {}
