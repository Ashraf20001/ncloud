import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { map } from 'rxjs';
import { FileTypeEnum } from 'src/app/enum/enum';
import { DashboardService } from 'src/app/services/dashboard.service';


@Component({
  selector: 'app-home-dashboard',
  templateUrl: './home-dashboard.component.html',
  styleUrls: ['./home-dashboard.component.scss'],
})
export class HomeDashboardComponent  implements OnInit {
  paperDetails: PaperDetailsDto[];
  propertyArray : string[];
  activeDataMap:any[]=[];
  activeDetailsArray:PaperDetailsDto[]=[];
  expireDetailsArray:PaperDetailsDto[]=[];
  activeCount:number;
  inActiveCount:number;
  noDataFound: boolean;
  expireNoDataFound: boolean;


      constructor(private dashboardService:DashboardService,private route:Router,private toaster:ToastrService){}

  ngOnInit() {
    this.dashboardService.getDashboardDetails().subscribe((data)=>{
      if(data){
        this.paperDetails=data['content'];

        this.activeCount=0;
        this.inActiveCount=0;
        this.paperDetails.forEach(element => {
          if (element.status==="1") {
            this.activeDetailsArray.push(element);
            this.activeCount++;
          }
          else if(element.status==="2"){
            this.expireDetailsArray.push(element);
            this.inActiveCount++;
          }
        });

        if(this.activeCount===0){
          this.noDataFound=true
        }
        if(this.inActiveCount===0){
          this.expireNoDataFound=true
        }
      }
    })
  }
active:string='blue'
expired:string='white'
  Active()
  {
    this.active='blue'
    this.expired='white'
  }
  Expired()
  {
   
    this.active='white'
    this.expired='blue'
  }
  // cardetails:any[]=[
  //   {
  //     name:'Insurance Name',model:'chandru'
  //   },
  //   {
  //     name:'Registation Number',model:'RN43359392A'
  //   },
  // {
  //     name:'Effective From',model:'10/01/2023'
  //   },  {
  //     name:'Effective to',model:'10/01/2026'
  //   }, ]


    show=true
    show1=false
    shouhidden()
    {
      this.show=true;
      this.show1=false;
    }
    shouhidden1(){
   

      this.show=false;
this.show1=true;
    }

    sendMail(paperIdentity:string,policyNo:string){
        this.dashboardService.sendMail(paperIdentity,policyNo).subscribe((data)=>{
            if(data['content']){
              this.toaster.success("Mail Send Successfully");
            }
          
        });
    }

    onGettingDetails(data:PaperDetailsDto){
      this.dashboardService.setAddNew(data);
      this.route.navigate(["/home/vehicale_details"]);
    }

    printImage(fileUrl:string){
        let ImageUrl:string;
        this.dashboardService.getImageFromUrl(fileUrl).subscribe(data=>{
          if(data){
            const blob = new Blob([data], { type: 'image/jpeg' });
          const imagePath = URL.createObjectURL(blob);
          console.log(imagePath);
          ImageUrl=imagePath;
          this.doPrint(ImageUrl);
          }
        },(
          (error)=>{
            this.toaster.error('Digital Paper Image Is Not Found');
          }
        ));

    }

    doPrint(imageUrl:string): void {
      const printWindow = window.open('', '_blank');
      const printDocument = printWindow.document;


      printDocument.open();
      printDocument.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>Print Images</title>
            <style>
              img {
                width: 100%;
                height: auto;
              }
            </style>
          </head>
          <body>
          <img src="${imageUrl}" alt="paperImage">
          </body>
        </html>
      `);


      // Trigger print dialog
      setTimeout(()=> {
        printDocument.close();
        printWindow.print();
        printWindow.close();
      }, 50);
    }


    onDownload(fileUrl:string){
      this.dashboardService.getImageFromUrl(fileUrl).subscribe(data=>{
        const blob = new Blob([data], { type: FileTypeEnum.PNG });
        const downloadLink = document.createElement('a');
        downloadLink.style.display = 'none';
        document.body.appendChild(downloadLink);
        downloadLink.setAttribute('href', window.URL.createObjectURL(blob));
        downloadLink.setAttribute('download', "PaperImage");
        downloadLink.click();
        document.body.removeChild(downloadLink);
    },(error)=>{
      this.toaster.error('Digital Paper Image Is Not Found');
    });

}

}


export class PaperDetailsDto{
  pdDigiltaPaperId:string;
  pdPolicyNumber:string;
  pdInsuredName:string;
  pdPhoneNumber:string;
  pdEmailId:string;
  pdEffectiveFrom:string;
  pdExpireDate:string;
  vdRegistrationNumber:string;
  vdChassis:string;
  vdLicensedToCarry:string;
  vdMake:string;
  vdModel:string;
  vdUsage:string;
  identity:string;
  status:string;
  fileURL:string;
}

