import { Component, OnInit } from '@angular/core';
import { ModalController, NavParams } from '@ionic/angular';

@Component({
  selector: 'app-view-paper-component',
  templateUrl: './view-paper-component.component.html',
  styleUrls: ['./view-paper-component.component.scss'],
})
export class ViewPaperComponent  implements OnInit {

  constructor(private navParams: NavParams, private modalContrl:ModalController) { }
  paperImageUrl:string;
  
  ngOnInit() {
     this.paperImageUrl=this.navParams.data['fileURL'];
     console.log('paper',this.paperImageUrl);
    }

    getUrl(){
      return this.paperImageUrl;
    }

    close() {
      this.modalContrl.dismiss();
    }

}
