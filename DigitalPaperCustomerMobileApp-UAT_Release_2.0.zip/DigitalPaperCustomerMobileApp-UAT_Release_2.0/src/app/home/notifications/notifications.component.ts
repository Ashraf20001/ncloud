import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DashboardService } from 'src/app/services/dashboard.service';
import { NotificationSubjectService } from 'src/app/services/notification-subject.service';
import { NotficationService } from 'src/app/services/notification.service';
import { PaperDetailsDto } from '../home-dashboard/home-dashboard.component';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.scss'],
})
export class NotificationsComponent  implements OnInit {
notificationData:any[];
splicedNotification:any;
  paperId: string;
  noDataFound=false;

  constructor(private notificationService:NotficationService,
    public notificationSubjectService: NotificationSubjectService,
    private route:Router,
    private dashboardService:DashboardService) { }

  ngOnInit() {
    this.notificationSubjectService.getAddNew().subscribe((res)=>{
      this.notificationData=res;
      if(!this.notificationData){
        this.noDataFound=true;
      }
      else if(this.notificationData.length===0){
        this.noDataFound=true;
      }
      else{
        this.noDataFound=false;
      }
    })
  }
  updateNotification(data:any,index:any){
    this.notificationService.updateNotificationById(data.identity).subscribe((res)=>{
      if(res){
       this.extractValue(data.notificationMsg);
        this.splicedNotification=this.notificationData.splice(index,1);

      }
    });
  }
  extractValue(message:string) {
    const parts = message.split('<b>');
    if (parts.length >= 3) {
      this.paperId =  parts[1].split('</b>')[0];
      this.notificationService.getPerticulerpaper(this.paperId).subscribe((data:PaperDetailsDto) =>{
        if(data !== null && data !== undefined){
          this.notificationSubjectService.setAddNotification(data);
          this.dashboardService.setAddNew(data);
          this.route.navigate(["/home/vehicale_details"]);
        }
      })
  }
}

list:any[]=[1,2,3,4,]
}
