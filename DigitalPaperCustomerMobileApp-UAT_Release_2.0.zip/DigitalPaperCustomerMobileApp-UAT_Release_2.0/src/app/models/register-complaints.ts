export class RegisterComplaints {
    name!: string;
    emailId!: string;
    dateOfIncident:any;
    compliantsType!: string;
    remarks!: string;
    companyId!: number;
    digitalPaperId!:string;
     complaintsId!:string;
}

export class LoginDetals{
    customerId!: number;
    username!: string;
    email!: number;
    phoneNumber!: string;
    addedDate!: string;
    status!: boolean;
    password!: string;
    customerUrl:string;
}
