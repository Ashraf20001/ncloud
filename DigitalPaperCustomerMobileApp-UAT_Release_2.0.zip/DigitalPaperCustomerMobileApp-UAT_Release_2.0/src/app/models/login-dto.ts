import { PlatformDetailsDto } from "./platform-details-dto";
import { UserTypeDto } from "./user-type-dto";

export interface LoginDto{
    username:string;
    password:string;
    platformDetailsDto:PlatformDetailsDto
    userTypeDto:UserTypeDto;
}