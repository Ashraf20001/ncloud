import { UserType } from "../enum/enum";

export interface UserTypeDto{
    userTypeId:UserType;
    userTypeName:UserType;
  }