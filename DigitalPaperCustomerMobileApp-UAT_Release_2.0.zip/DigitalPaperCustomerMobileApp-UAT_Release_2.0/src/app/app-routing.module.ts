import { Component, NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { CommonResetPasswordComponent } from './common/components/common-reset-password/common-reset-password.component';
import { AuthGuard } from './services/auth-guard/auth.guard';

const routes: Routes = [
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginModule)
  },
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule),
    canActivate:[AuthGuard]
  },
  {
    path: 'forgot_password',
    loadChildren: () => import('./forgot-password/forgot-password.module').then( m => m.ForgotPasswordModule)
  },
  {
    path: 'reset_password',
    loadChildren: () => import('./reset-password/reset-password.module').then( m => m.ResetPasswordModule)
  },
  {
    path:'reset_password/:forgetPasswordIdentity/:email',
    loadChildren: () => import('./common/components/common-reset-password/common-reset-password.module').then( m => m.CommonResetPasswordModule)
  },
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
