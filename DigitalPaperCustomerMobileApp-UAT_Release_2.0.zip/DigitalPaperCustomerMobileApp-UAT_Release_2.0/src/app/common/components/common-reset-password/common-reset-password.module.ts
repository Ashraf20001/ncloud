import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { CommonResetPasswordComponent } from "./common-reset-password.component";
import { IonicModule } from "@ionic/angular";
import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { CommonResetPasswordRoutingModule } from "./common-reset-password-routing.module";

@NgModule({
    imports: [
      CommonModule,
      FormsModule,
      IonicModule,
      ReactiveFormsModule,
      CommonResetPasswordRoutingModule

    ],
    declarations: [CommonResetPasswordComponent]
  })

  export class CommonResetPasswordModule{}