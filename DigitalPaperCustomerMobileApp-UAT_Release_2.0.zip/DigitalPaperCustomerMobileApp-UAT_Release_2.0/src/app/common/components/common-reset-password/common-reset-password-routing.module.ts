import { RouterModule, Routes } from "@angular/router";
import { CommonResetPasswordComponent } from "./common-reset-password.component";
import { NgModule } from "@angular/core";

const routes: Routes = [
    {
      path: '',
      component:CommonResetPasswordComponent ,
    }
  ];

  @NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })
  export class CommonResetPasswordRoutingModule {}