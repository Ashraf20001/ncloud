import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ResetPasswordRequest } from 'src/app/models/reset-password-dto';
import Validation from 'src/app/services/Validation';
import { AuthService } from 'src/app/services/auth-service/auth.service';

@Component({
  selector: 'app-common-reset-password',
  templateUrl: './common-reset-password.component.html',
  styleUrls: ['./common-reset-password.component.scss'],
})
export class CommonResetPasswordComponent  implements OnInit {

  resetPassword:FormGroup;
  userName:string;
  forgetIdentity:string;
  decryptedUserName:string;

  passwordRegex = /^(?=[^A-Z]*[A-Z])(?=[^a-z]*[a-z])(?=\D*\d)[A-Za-z\d!$%@#£€*?&]{8,}$/;
  constructor(private fb:FormBuilder,private service:AuthService,private route:Router,private router: ActivatedRoute) { 

  }

  ngOnInit() {
      this.resetPassword=this.fb.group({
          userName:new FormControl("",[Validators.required]),
          newPassword:new FormControl("",[Validators.required,this.noSpaceAllowed,Validators.pattern(this.passwordRegex)]),
          confrmPwd:new FormControl("",[Validators.required])
      },
      {
        validators: [Validation.match('newPassword', 'confrmPwd')]
      }
      );
      this.userName=this.router.snapshot.paramMap.get('email');
      this.forgetIdentity=this.router.snapshot.paramMap.get('forgetPasswordIdentity');
      this.decryptedUserName=atob(this.userName);

  }
  showPassword=false;
  togglePasswordVisibility()
   {
     this.showPassword = !this.showPassword;
   }
   confirmPassword=false;
   toggleConfirmPasswordVisibility()
   {
this.confirmPassword=!this.confirmPassword;
   }

   noSpaceAllowed(control:FormControl){
    if (control.value!= null && control.value.indexOf(' ')!= -1) {
      return {noSpaceAllowed:true}
    }
    return null;
  }

  get f(): { [key: string]: AbstractControl } {
    return this.resetPassword.controls;
  }

   onReset(){
      if(this.resetPassword.valid){
          const resetPwd= new ResetPasswordRequest();
          resetPwd.identity=this.forgetIdentity;
          resetPwd.newPassword=this.resetPassword.value.newPassword;
          resetPwd.confirmPassword=this.resetPassword.value.confrmPwd;

          this.service.updatePassword(resetPwd).subscribe((response)=>{
            if(response){
              console.log('Password has been resetted successfully');
              this.route.navigateByUrl('/login');
            }
          })
      }
   }

}
