import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth-service/auth.service';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ExpireTime } from '../enum/enum';
import { Router } from '@angular/router';
import { ComplaintsService } from '../services/complaints.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent  implements OnInit {

  constructor(private fb: FormBuilder,private authService:AuthService,private route:Router, private complaints:ComplaintsService,private tosterservice: ToastrService,) { }
  login:FormGroup;
  ngOnInit() {
    this.login=this.fb.group({
      userName:new FormControl("",[Validators.required]),
      password:new FormControl("",[Validators.required,this.noSpaceAllowed]),
    })
    this.complaints.getValue().subscribe((data)=>{
      if(data){
        this.login.controls['userName'].setValue('');
        this.login.controls['password'].setValue('');

      }
    })

  }
  showPassword=false;
  togglePasswordVisibility()
   {
     this.showPassword = !this.showPassword;
   }

   noSpaceAllowed(control:FormControl){
    if (control.value!= null && control.value.indexOf(' ')!= -1) {
      return {noSpaceAllowed:true}
    }
    return null;
}

    ProceedLogin(){
        if(this.login.invalid){
          return
        }

        this.authService.ProceedLogin(this.login.value.userName,this.login.value.password).subscribe((data:any)=>{
            if(data){
              sessionStorage.setItem("customerIdentity",data.identity);
              sessionStorage.setItem("token",data.accessToken);
              sessionStorage.setItem("email",data.email);
              this.authService.autoLogout(ExpireTime.expirationTime);

              if(data.firstTimeLogin===true){
                    this.route.navigateByUrl('/reset_password');
              }
              else{
                this.route.navigateByUrl("/home/home_dashboard");

                this.tosterservice.success("Login Successfully");
              }

            }
        })
    }

}
