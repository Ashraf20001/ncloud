export const environment = {
  production: true,
  API_BASE_URL : 'http://216.48.177.53:6063',
  AUTH_URL : 'http://216.48.177.53:6063'
};
