package com.ncloud.batch.config;

import java.util.List;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ncloud.batch.dao.DataRepositoryDao;
import com.ncloud.batch.listner.JobCompletionListener;
import com.ncloud.batch.step.Processor;
import com.ncloud.batch.step.Reader;
import com.ncloud.batch.step.Writer;
import com.ncloud.dl.transfer.object.entity.DataRepository;

/**
 * The Class BatchConfig.
 */
@Configuration
public class BatchConfig {

	/**
	 * jobBuilderFactory
	 */
	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	/**
	 * stepBuilderFactory
	 */
	@Autowired
	public StepBuilderFactory stepBuilderFactory;


	/**
	 * Process job.
	 *
	 * @return the job
	 */
	@Bean
	public Job processJob() {
		return jobBuilderFactory.get("processJob").incrementer(new RunIdIncrementer()).listener(listener())
				.flow(orderStep()).end().build();
	}


	/**
	 * Order step.
	 *
	 * @return the step
	 */
	@Bean
	public Step orderStep() {
		return stepBuilderFactory.get("orderStep").<List<DataRepository>, List<DataRepository>>chunk(1)
				.reader(getReader()).processor(getProcessor()).writer(getWriter()).build();
	}


	/**
	 * Listener.
	 *
	 * @return the job execution listener
	 */
	@Bean
	public JobExecutionListener listener() {
		return new JobCompletionListener();
	}

	/**
	 * Gets the paper details dao.
	 *
	 * @return the paper details dao
	 */
	@Autowired
	@Bean(name = "dataRepositoryDao")
	public DataRepositoryDao getPaperDetailsDao() {
		return new DataRepositoryDao();
	}

	/**
	 * Gets the reader.
	 *
	 * @return the reader
	 */
	@Bean
	public ItemReader<List<DataRepository>> getReader() {
		return new Reader();
	}

	/**
	 * Gets the processor.
	 *
	 * @return the processor
	 */
	@Bean
	public ItemProcessor<List<DataRepository>, List<DataRepository>> getProcessor() {
		return new Processor();
	}

	/**
	 * Gets the writer.
	 *
	 * @return the writer
	 */
	@Bean
	public ItemWriter<List<DataRepository>> getWriter() {
		return new Writer();
	}

}
