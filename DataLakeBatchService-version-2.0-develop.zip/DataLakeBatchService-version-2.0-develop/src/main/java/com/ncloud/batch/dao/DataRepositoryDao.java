package com.ncloud.batch.dao;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ncloud.dl.transfer.object.entity.DataRepository;


/**
 * The Class DataRepositoryDao.
 */
@Repository
public class DataRepositoryDao {

	/** The entity manager. */
	@PersistenceContext
	@Autowired
	private EntityManager entityManager;

	/**
	 * @return Repositories
	 */
	public List<DataRepository> getToDisableRepositories() {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<DataRepository> query = builder.createQuery(DataRepository.class);
		Root<DataRepository> root = query.from(DataRepository.class);
		query.select(root);
		Predicate isDeleted = builder.and(builder.equal(root.get("isDltSts"), Boolean.FALSE));
		Predicate status = builder.and(builder.notEqual(root.get("repoStatus"), 5));
		Predicate effectiveTo = builder.and(builder.lessThan(root.get("effectiveTo"), LocalDate.now()));
			Predicate finalPredicate = builder.and(isDeleted, status, effectiveTo);
			query.where(finalPredicate);
			return entityManager.createQuery(query).getResultList();
		
	}

	/**
	 * @param repository
	 */
	public void updateData(DataRepository repository) {
		entityManager.merge(repository);
	}

}
