package com.ncloud.batch.step;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.ncloud.batch.dao.DataRepositoryDao;
import com.ncloud.dl.transfer.object.entity.DataRepository;

/**
 * The Class Writer.
 */
public class Writer implements ItemWriter<List<DataRepository>> {

	/** The data repository dao. */
	@Autowired
	private DataRepositoryDao dataRepositoryDao;

	/**
	 * Update the Data repository in Writer Step.
	 *
	 * @param repositoryList the repository list
	 * @throws Exception the exception
	 */
	@Override
	public void write(List<? extends List<DataRepository>> repositoryList) throws Exception {

		for (DataRepository notification : repositoryList.get(0)) {
			dataRepositoryDao.updateData(notification);
		}
		System.out.println("the end");
	}

}
