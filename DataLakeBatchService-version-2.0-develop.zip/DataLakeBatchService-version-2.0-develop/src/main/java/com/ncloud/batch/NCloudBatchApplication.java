package com.ncloud.batch;


import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

/**
 * The Class NCloudBatchApplication.
 */
@SpringBootApplication
@EnableBatchProcessing
@EntityScan("com.*")
public class NCloudBatchApplication {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		SpringApplication.run(NCloudBatchApplication.class, args);
	}
	
	

}
