package com.ncloud.batch.step;

import java.util.List;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Autowired;

import com.ncloud.batch.dao.DataRepositoryDao;
import com.ncloud.dl.transfer.object.entity.DataRepository;

/**
 * The Class Reader.
 */
public class Reader implements ItemReader<List<DataRepository>> {

	/** The data repository dao. */
	@Autowired
	DataRepositoryDao dataRepositoryDao;

	/** The count. */
	private int count = 0;

	/**
	 * Fetch the {@link DataRepository} list
	 *
	 * @return the list
	 * @throws Exception the exception
	 * @throws UnexpectedInputException the unexpected input exception
	 * @throws ParseException the parse exception
	 * @throws NonTransientResourceException the non transient resource exception
	 */
	@Override
	public List<DataRepository> read()
			throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {

		List<DataRepository> repositories = null;
		if (count == 0) {
			repositories = dataRepositoryDao.getToDisableRepositories();
			count++;
		} else {
			count = 0;
			return null;
		}
		return repositories;
	}

}
