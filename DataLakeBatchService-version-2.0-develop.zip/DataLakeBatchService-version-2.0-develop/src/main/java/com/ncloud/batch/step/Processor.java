package com.ncloud.batch.step;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.batch.item.ItemProcessor;

import com.ncloud.dl.transfer.object.entity.DataRepository;
import com.ncloud.dl.transfer.object.enums.RepositoryStatusEnum;


/**
 * The Class Processor.
 */
public class Processor implements ItemProcessor<List<DataRepository>, List<DataRepository>> {

	/**
	 * Process the data to update repository disable.
	 *
	 * @param repositoryList the repository list
	 * @return the list
	 * @throws Exception the exception
	 */
	@Override
	public List<DataRepository> process(List<DataRepository> repositoryList) throws Exception {
		for (DataRepository dataRepository : repositoryList) {
			dataRepository.setRepoStatus(RepositoryStatusEnum.DISABLED.getStatusId());
			dataRepository.setMdyUsrId(1);
			dataRepository.setMdyDteTme(LocalDateTime.now());
		}
		return repositoryList;
	}

}
