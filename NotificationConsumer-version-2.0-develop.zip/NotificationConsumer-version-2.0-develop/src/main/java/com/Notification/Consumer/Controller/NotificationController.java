package com.Notification.Consumer.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Notification.Consumer.Dto.NotificationDto;
import com.Notification.Consumer.Service.NotificationService;

/**
 * The Class NotificationController.
 */
@RestController
public class NotificationController {
	
	/** The notification service. */
	@Autowired
	private NotificationService notificationService;
	
    /**
     * Trigger notification by rest template call to send Notification.
     *
     * @param notificationDto the notification dto
     */
    @PostMapping(value = "/triggerSchedular")
	public void triggerScheduler(@RequestBody NotificationDto notificationDto) {
    	notificationService.callNotification(notificationDto);
	}
    
    /**
     * Post RestTemplate call to generate monthly report.
     *
     * @param notificationDto the notification dto
     */
    @PostMapping(value="/generate-monthly-report")
    public void generateMonthlyReport(@RequestBody NotificationDto notificationDto) {
    	notificationService.generateMonthlyReport(notificationDto);
    	notificationService.triggerPaymentReminderSetup();
    }

    /**
     * Post RestTemplate call to stop scheduler.
     *
     * @param notificationDto the notification dto
     */
    @PostMapping(value="/stopSchedular")
    public void stopSchedular(@RequestBody NotificationDto notificationDto) {
    	notificationService.callSchedular(notificationDto);
	}

    /**
     * Trigger notification for data-lake platform through rest template call.
     *
     * @param notificationDto the notification dto
     */
    @PostMapping(value="/triggerSchedularForDataLake")
    public void triggerNotificationForDataLake(@RequestBody NotificationDto notificationDto) {
    	boolean uploadFlow =notificationDto.getFromDate() == null ? true : false; 
    	notificationService.callNotificationForDataLake(notificationDto,uploadFlow);
    }
    
    /**
     * Post RestTemplate call to generate payment reminder.
     *
     * @param notificationDto the notification dto
     */
    @PostMapping(value="/generate-payment-reminder")
    public void generatePaymentReminder(@RequestBody NotificationDto notificationDto) {
    	notificationService.generatePaymentReminder(notificationDto);
    }
}
