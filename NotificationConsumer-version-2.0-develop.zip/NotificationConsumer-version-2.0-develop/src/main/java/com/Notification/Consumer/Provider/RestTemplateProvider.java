package com.Notification.Consumer.Provider;

import java.util.Arrays;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

/**
 * The Class RestTemplateProvider.
 */
@Component
public class RestTemplateProvider {

	/**
	 * Gets the http headers.
	 *
	 * @return the http headers
	 */
	public HttpHeaders getHttpHeaders() {

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		return headers;
	}

	/**
	 * Gets the rest template.
	 *
	 * @return the rest template
	 */
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}

}
