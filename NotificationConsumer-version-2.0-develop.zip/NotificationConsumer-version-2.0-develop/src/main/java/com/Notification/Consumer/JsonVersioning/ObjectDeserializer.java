package com.Notification.Consumer.JsonVersioning;

import java.util.Map;

import org.apache.kafka.common.serialization.Deserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.Notification.Consumer.Dto.NotificationDto;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * The Class ObjectDeserializer.
 */
public class ObjectDeserializer implements Deserializer<NotificationDto>{
	
	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ObjectDeserializer.class);
	
	/**
	 * Configure.
	 *
	 * @param configs the configs
	 * @param isKey the is key
	 */
	@Override
	public void configure(Map<String, ?> configs, boolean isKey) {		
	}

	/**
	 * Deserialize.
	 *
	 * @param topic the topic
	 * @param data the data
	 * @return the notification dto
	 */
	@Override
	public NotificationDto deserialize(String topic, byte[] data) {
		ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		NotificationDto version = null;
	    try {
	    	version = mapper.readValue(data, NotificationDto.class);
	    } catch (Exception e) {
	    	logger.info("Exception while deserializing Notification data ===> " + e);
	    }
	    return version;
	}
	
	/**
	 * Close.
	 */
	@Override
	public void close() {
	}

}
