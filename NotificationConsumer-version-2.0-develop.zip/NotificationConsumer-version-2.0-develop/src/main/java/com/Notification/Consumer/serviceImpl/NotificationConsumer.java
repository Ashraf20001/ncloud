package com.Notification.Consumer.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;
import com.Notification.Consumer.Controller.NotificationController;
import com.Notification.Consumer.Dto.NotificationDto;

/**
 * The Class NotificationConsumer.
 */
@Service
public class NotificationConsumer {

	/** The notification controller. */
	@Autowired
	NotificationController notificationController;

	/**
	 * Kafka listener that listens to the "NotificationConsumer" topic. This method
	 * is triggered whenever a new message is received from the Kafka topic.
	 *
	 * @param notificationDto the notification dto
	 */
	@KafkaListener(topics = "NotificationConsumer")
	public void triggerScheduler(NotificationDto notificationDto) {
		notificationController.triggerScheduler(notificationDto);
	}

	/**
	 * Kafka listener that listens to the "NotificationConsumer" topic.This method
	 * is stop scheduler In-progress status.
	 *
	 * @param notificationDto the notification dto
	 */
	@KafkaListener(topics = "StopSchedular")
	public void stopScheduling(NotificationDto notificationDto) {
		notificationController.stopSchedular(notificationDto);
	}
	
	/**
	 * This kafka listener is look up for object drop on this topic. Once dropped
	 * notification data-lake method will triggered.
	 *
	 * @param notificationDto the notification dto
	 */
	@KafkaListener(topics = "datalake.repository.notify")
	public void triggerSchedulerForDataLake(NotificationDto notificationDto,Acknowledgment acknowledgment) {
		acknowledgment.acknowledge();
		notificationController.triggerNotificationForDataLake(notificationDto);
	}

	/**
	 * Listens to the "WalletReportGeneration" topic and triggers the monthly report
	 * generation.
	 *
	 * @param notificationDto the notification dto
	 */
	@KafkaListener(topics = "WalletReportGeneration")
	public void callWalletReportGeneration(NotificationDto notificationDto) {
		notificationController.generateMonthlyReport(notificationDto);
	}
	
	/**
	 * Listens to the "WalletPaymentReminder" topic and triggers a payment reminder
	 * generation.
	 *
	 * @param notificationDto the notification dto
	 */
	@KafkaListener(topics = "WalletPaymentReminder")
	public void callWalletPaymentReminder(NotificationDto notificationDto) {
		notificationController.generatePaymentReminder(notificationDto);
	}
}
