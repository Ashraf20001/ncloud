package com.Notification.Consumer.Service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.Notification.Consumer.Config.EnvironmentProperties;
import com.Notification.Consumer.Dto.NotificationDto;
import com.Notification.Consumer.Provider.RestTemplateProvider;

/**
 * The Class NotificationService.
 */
@Service
public class NotificationService {
	
	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(NotificationService.class);
	
	/** The environment properties. */
	@Autowired
	private EnvironmentProperties environmentProperties;

	/** The rest template provider. */
	@Autowired
	private RestTemplateProvider restTemplateProvider;

	/**
	 * Call notification.
	 *
	 * @param notificationDto the notification dto
	 */
	public void callNotification(NotificationDto notificationDto) {

		RestTemplate restTemplate = restTemplateProvider.getRestTemplate();
		HttpHeaders httpHeaders = restTemplateProvider.getHttpHeaders();
		HttpEntity<NotificationDto> httpEntity = new HttpEntity<NotificationDto>(notificationDto, httpHeaders);
		String url = environmentProperties.getNotificationUrl();
		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, httpEntity, String.class);
		logger.info("Notification Response ===> " + response);
	}

	/**
	 * Call scheduler.
	 *
	 * @param notificationDto the notification dto
	 */
	public void callSchedular(NotificationDto notificationDto) {
		RestTemplate restTemplate = restTemplateProvider.getRestTemplate();
		HttpHeaders httpHeaders = restTemplateProvider.getHttpHeaders();
		HttpEntity<NotificationDto> httpEntity = new HttpEntity<NotificationDto>(notificationDto, httpHeaders);
		String url = environmentProperties.getSchedularUrl();
		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, httpEntity, String.class);
		logger.info("Schedular Response ===> " + response);
	}
		
	/**
	 * Call notification for data lake.
	 *
	 * @param notificationDto the notification dto
	 * @param uploadFlow the upload flow
	 */
	public void callNotificationForDataLake(NotificationDto notificationDto , boolean uploadFlow) {
		RestTemplate restTemplate = restTemplateProvider.getRestTemplate();
	    HttpHeaders httpHeaders = restTemplateProvider.getHttpHeaders();
	    // Create a UriComponentsBuilder to build the URL with query parameters
	    UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(environmentProperties.getDataLakeNotificationUrl())
	            .queryParam("uploadFlow", uploadFlow); // Append the boolean parameter as a query parameter
	    // Build the final URL with query parameter
	    String urlWithParams = builder.toUriString();
	    HttpEntity<NotificationDto> httpEntity = new HttpEntity<>(notificationDto, httpHeaders);
	    restTemplate.exchange(urlWithParams, HttpMethod.POST, httpEntity, String.class);
	}
	
	/**
	 * Generate monthly report.
	 *
	 * @param notificationDto the notification dto
	 */
	public void generateMonthlyReport(NotificationDto notificationDto) {
		RestTemplate restTemplate = restTemplateProvider.getRestTemplate();
		HttpHeaders httpHeaders = restTemplateProvider.getHttpHeaders();
		HttpEntity<NotificationDto> httpEntity = new HttpEntity<NotificationDto>(notificationDto, httpHeaders);
		String url = environmentProperties.getWalletMonthlyReportGenerationUrl();
		restTemplate.exchange(url, HttpMethod.POST, httpEntity, Void.class);
	}

	/**
	 * Trigger payment reminder setup.
	 */
	public void triggerPaymentReminderSetup() {
		RestTemplate restTemplate = restTemplateProvider.getRestTemplate();
		String url = environmentProperties.getWalletPaymentReminderSetupUrl();
		restTemplate.exchange(url, HttpMethod.POST, null, Void.class);
	}
	
	/**
	 * Generate payment reminder.
	 *
	 * @param notificationDto the notification dto
	 */
	public void generatePaymentReminder(NotificationDto notificationDto) {
		RestTemplate restTemplate = restTemplateProvider.getRestTemplate();
		HttpHeaders httpHeaders = restTemplateProvider.getHttpHeaders();
		HttpEntity<NotificationDto> httpEntity = new HttpEntity<NotificationDto>(notificationDto, httpHeaders);
		String url = environmentProperties.getWalletPaymentReminderNotifyUrl();
		restTemplate.exchange(url, HttpMethod.POST, httpEntity, Void.class);
	}

}
