package com.Notification.Consumer.Config;

import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * The Class EnvironmentProperties.
 */
@Configuration
@RequiredArgsConstructor
public class EnvironmentProperties {

	/** The property value provider. */
	private final PropertyValueProvider propertyValueProvider;
	
	/**
	 * Gets the notification url.
	 *
	 * @return the notification url
	 */
	public String getNotificationUrl() {
		return this.propertyValueProvider.getNotificationUrl();
	}
	
	/**
	 * Gets the schedular url.
	 *
	 * @return the schedular url
	 */
	public String getSchedularUrl() {
		return this.propertyValueProvider.getSchedularUrl();
	}
	
	/**
	 * Gets the data lake notification url.
	 *
	 * @return the data lake notification url
	 */
	public String getDataLakeNotificationUrl() {
		return this.propertyValueProvider.getDatalakeNotificationUrl();
	}
	
	
	/**
	 * Gets the wallet monthly report generation url.
	 *
	 * @return the wallet monthly report generation url
	 */
	public String getWalletMonthlyReportGenerationUrl() {
		return this.propertyValueProvider.getWalletMonthlyReportGenerationUrl();
	}
	
	/**
	 * Gets the wallet payment reminder setup url.
	 *
	 * @return the wallet payment reminder setup url
	 */
	public String getWalletPaymentReminderSetupUrl() {
		return this.propertyValueProvider.getWalletPaymentReminderSetupUrl();
	}
	
	/**
	 * Gets the wallet payment reminder notify url.
	 *
	 * @return the wallet payment reminder notify url
	 */
	public String getWalletPaymentReminderNotifyUrl() {
		return this.propertyValueProvider.getWalletPaymentReminderNotifyUrl();
	}
}
