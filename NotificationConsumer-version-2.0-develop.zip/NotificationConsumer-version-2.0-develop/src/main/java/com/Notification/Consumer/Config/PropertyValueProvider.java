package com.Notification.Consumer.Config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import lombok.Getter;
import lombok.Setter;

/**
 * The Class PropertyValueProvider.
 */
@ConfigurationProperties(prefix = "ntconsumer")
@Getter
@Setter
@Component
public class PropertyValueProvider {
	
		/** The notification url. */
		private String notificationUrl;
		
		/** The schedular url. */
		private String schedularUrl;
		
		/** The datalake notification url. */
		private String datalakeNotificationUrl;
		
		/** The wallet report generation url. */
		private String walletReportGenerationUrl;
		
		/** The wallet monthly report generation url. */
		private String walletMonthlyReportGenerationUrl;
		
		/** The wallet payment reminder setup url. */
		private String walletPaymentReminderSetupUrl;
		
		/** The wallet payment reminder notify url. */
		private String walletPaymentReminderNotifyUrl;
		
		 @PostConstruct
		    public void printProperties() {
		        System.out.println("notificationUrl: " + notificationUrl);
		        System.out.println("schedularUrl: " + schedularUrl);
		        System.out.println("datalakeNotificationUrl: " + datalakeNotificationUrl);
		        System.out.println("walletReportGenerationUrl: " + walletReportGenerationUrl);
		        System.out.println("walletMonthlyReportGenerationUrl: " + walletMonthlyReportGenerationUrl);
		        System.out.println("walletPaymentReminderSetupUrl: " + walletPaymentReminderSetupUrl);
		        System.out.println("walletPaymentReminderNotifyUrl: " + walletPaymentReminderNotifyUrl);
		    }

}
