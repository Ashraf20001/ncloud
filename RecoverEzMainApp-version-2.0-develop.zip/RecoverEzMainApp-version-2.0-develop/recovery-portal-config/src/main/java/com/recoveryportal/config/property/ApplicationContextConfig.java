/*
 * @author codeboard
 */
package com.recoveryportal.config.property;

import org.hibernate.SessionFactory; 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBuilder;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;


/**
 * The Class ApplicationContextConfig.
 */
@Configuration
@ComponentScan("com.recoveryportal.*")
@EnableTransactionManagement
@EnableAsync
@EnableAutoConfiguration(exclude = HibernateJpaAutoConfiguration.class)
public class ApplicationContextConfig implements WebMvcConfigurer {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ApplicationContextConfig.class);

	/**
	 * Property config in dev.
	 *
	 * @return the property sources placeholder configurer
	 */
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	/**
	 * Gets the hibernate session factory.
	 *
	 * @param dataSource the data source
	 * @param hibernateProperties the hibernate properties
	 * @return the hibernate session factory
	 */
	@Autowired
	@Bean(name = "sessionFactory")
	public SessionFactory getHibernateSessionFactory(RoutingDataSource dataSource,
			HibernateProperties hibernateProperties) {
		LocalSessionFactoryBuilder sessionBuilder = new LocalSessionFactoryBuilder(dataSource);
		sessionBuilder.addProperties(hibernateProperties.getHibernateProperties());
		sessionBuilder.scanPackages("com.recoveryportal");
		logger.info("SessionFactory Created...");
		return sessionBuilder.buildSessionFactory();
	}

	/**
	 * Gets the hibernate template.
	 *
	 * @param sessionFactory the session factory
	 * @return the hibernate template
	 */
	@Autowired
	@Bean(name = "hibernateTemplate")
	public HibernateTemplate getHibernateTemplate(SessionFactory sessionFactory) {
		HibernateTemplate hibernateTemplate = new HibernateTemplate(sessionFactory);
		logger.info("HibernateTemplate Created...");
		return hibernateTemplate;
	}

	/**
	 * Gets the hibernate transaction manager.
	 *
	 * @param sessionFactory the session factory
	 * @return the hibernate transaction manager
	 */
	@Autowired
	@Bean(name = "transactionManager")
	public HibernateTransactionManager getHibernateTransactionManager(SessionFactory sessionFactory) {
		HibernateTransactionManager hibernateTransactionManager = new HibernateTransactionManager(sessionFactory);
		logger.info("Transaction Manager Created...");
		return hibernateTransactionManager;
	}

	/**
	 * Rest template.
	 *
	 * @return the rest template
	 */
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

}
