/*
 * @author codeboard
 */
package com.recoveryportal.config.model;

/**
 * The Interface CommonVo.
 */
public interface CommonVo {

}
