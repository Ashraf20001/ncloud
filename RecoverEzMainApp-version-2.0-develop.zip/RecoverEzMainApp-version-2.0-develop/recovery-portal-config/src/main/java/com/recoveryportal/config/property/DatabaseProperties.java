/*
 * @author codeboard
 */
package com.recoveryportal.config.property;

import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.context.annotation.Configuration;

import com.recoveryportal.constants.core.PropertyConstants;




/**
 * The Class DatabaseProperties.
 */
@Configuration
public class DatabaseProperties {

	/** The data base name. */
	private String dataBaseName = "";

	/** The environment properties. */
	@Autowired
	private EnvironmentProperties environmentProperties;

	/**
	 * Gets the jdbc driver.
	 *
	 * @return the jdbc driver
	 */
	public String getJdbcDriver() {
		return environmentProperties.getJdbcDriver();
	}

	/**
	 * Gets the jdbc password.
	 *
	 * @return the jdbc password
	 */
	public String getJdbcPassword() {
		return environmentProperties.getJdbcPassword().trim();
	}

	/**
	 * Gets the jdbc url.
	 *
	 * @return the jdbc url
	 */
	public String getJdbcUrl() {
		String url = replaceDateBaseName(environmentProperties.getDataSourceUrl());
		url = url.replace(PropertyConstants.MAIN_APP_MYSQL_IP, environmentProperties.getSqlIp().trim());
		url = url.replace(PropertyConstants.MAIN_APP_MYSQL_PORT, environmentProperties.getSqlPort().trim());
		return url;
	}

	/**
	 * Gets the jdbc user.
	 *
	 * @return the jdbc user
	 */
	public String getJdbcUser() {
		return environmentProperties.getJdbcUser();
	}

	/**
	 * Gets the my sql date base.
	 *
	 * @return the my sql date base
	 */
	public String getMySqlDateBase() {
		if (dataBaseName.isEmpty()) {
			dataBaseName = environmentProperties.getMySqlDateBase();
		}
		return dataBaseName;
	}

	/**
	 * Replace date base name.
	 *
	 * @param data the data
	 * @return the string
	 */
	public String replaceDateBaseName(String data) {
		data = data.replace(PropertyConstants.DB_NAME, getMySqlDateBase());
		return data;
	}
	
	/**
	 * Gets the mater connection on checkout.
	 *
	 * @return the mater connection on checkout
	 */
	public Boolean getMaterConnectionOnCheckout() {
        return environmentProperties.getMaterConnectionOnCheckout();
    }
    
    /**
     * Gets the mysql min pool size.
     *
     * @return the mysql min pool size
     */
    public String getMysqlMinPoolSize() {
        return environmentProperties.getMysqlMinPoolSize();
    }
    
    /**
     * Gets the mysql max pool size.
     *
     * @return the mysql max pool size
     */
    public String getMysqlMaxPoolSize() {
        return environmentProperties.getMysqlMaxPoolSize();
    }   
   /**
    * Gets the mysql max idle time out.
    *
    * @return the mysql max idle time out
    */
   public String getMysqlMaxIdleTimeOut() {
        return environmentProperties.getMysqlMaxIdleTimeout();
    }
    
    /**
     * Gets the mysql max idle time excess connections.
     *
     * @return the mysql max idle time excess connections
     */
    public String getMysqlMaxIdleTimeExcessConnections() {
        return environmentProperties.getMysqlMaxIdleTimeExcessConnections();
    }
    
    /**
     * Gets the mysql idle connection test period.
     *
     * @return the mysql idle connection test period
     */
    public String getMysqlIdleConnectionTestPeriod() {
		return environmentProperties.getMysqlIdleConnectionTestPeriod();
	}
}
