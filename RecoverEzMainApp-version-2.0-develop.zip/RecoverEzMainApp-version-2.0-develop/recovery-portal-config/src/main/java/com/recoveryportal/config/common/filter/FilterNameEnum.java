/*
 * @author codeboard
 */
package com.recoveryportal.config.common.filter;

/**
 * The Enum FilterNameEnum.
 */
public enum FilterNameEnum {

	/**
	 * The profile filter.
	 */
	PROFILE_FILTER

}
