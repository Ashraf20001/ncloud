package com.recoveryportal.config.property;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.recoveryportal.constants.core.PropertyConstants;
import com.recoveryportal.constants.serverproperties.PropertyValueProvider;
import com.recoveryportal.crypto.core.TwoWayEncryption;


/**
 * The Class EnvironmentProperties.
 */
@Configuration
public class EnvironmentProperties {
	
	
	/** The configuration properties. */
	@Autowired
	private PropertyValueProvider configurationProperties; 	
	
	/** The enc. */
	@Autowired
	private TwoWayEncryption enc;
	
	
	/** The data base name. */
	private String dataBaseName = "";

	/**
	 * Gets the data source url.
	 *
	 * @return the data source url
	 */
	public String getDataSourceUrl() {
		return configurationProperties.getMysqlDataSourceUrl();
	}
	
	/**
	 * Gets the driver name.
	 *
	 * @return the driver name
	 */
	public String getDriverName() {
		return configurationProperties.getMysqlDriver();
	}

	/**
	 * Gets the jdbc password.
	 *
	 * @return the jdbc password
	 */
	public String getJdbcPassword() {
		return enc.doDecryption(configurationProperties.getMysqlPassword());
	}
	
	/**
	 * Gets the jdbc url.
	 *
	 * @return the jdbc url
	 */
	public String getJdbcUrl() {
		String url = replaceDateBaseName(configurationProperties.getMysqlDataSourceUrl());
		System.out.println(url);
		url = url.replace(PropertyConstants.MAIN_APP_MYSQL_IP,
				configurationProperties.getMysqlIp());
		url = url.replace(PropertyConstants.MAIN_APP_MYSQL_PORT,
				configurationProperties.getMysqlPort());
		return url;
	}
	
	/**
	 * Gets the jdbc user.
	 *
	 * @return the jdbc user
	 */
	public String getJdbcUser() {
		return enc.doDecryption(configurationProperties.getMysqlUsername());
	}
	
	/**
	 * Gets the my sql date base.
	 *
	 * @return the my sql date base
	 */
	public String getMySqlDateBase() {
		if (dataBaseName.isEmpty()) {
			dataBaseName = configurationProperties.getMysqlDataBase();
		}
		return dataBaseName;
	}
	
	/**
	 * Gets the sql ip.
	 *
	 * @return the sql ip
	 */
	public String getSqlIp() {
		return enc.doDecryption(configurationProperties.getMysqlIp());
	}

	/**
	 * Gets the sql port.
	 *
	 * @return the sql port
	 */
	public String getSqlPort() {
		return  enc.doDecryption(configurationProperties.getMysqlPort());
	}

	/**
	 * Replace date base name.
	 *
	 * @param data the data
	 * @return the string
	 */
	public String replaceDateBaseName(String data) {
		data = data.replace(PropertyConstants.DB_NAME, getMySqlDateBase());
		return data;
	}
	
	/**
	 * Gets the jdbc driver.
	 *
	 * @return the jdbc driver
	 */
	public String getJdbcDriver() {
		return configurationProperties.getMysqlDriver();
	}
	
	/**
	 * Gets the time zone.
	 *
	 * @return the time zone
	 */
	public String getTimeZone() {
		return configurationProperties.getTimeZone();
	}
	
	/**
	 * Gets the date format.
	 *
	 * @return the date format
	 */
	public String getDateFormat() {
		return configurationProperties.getDateFormat();
	}
	
	/**
	 * Gets the time format.
	 *
	 * @return the time format
	 */
	public String getTimeFormat() {
		return configurationProperties.getTimeFormat();
	}
	
	/**
	 * Gets the currency format.
	 *
	 * @return the currency format
	 */
	public String getCurrencyFormat() {
		return configurationProperties.getCurrencyFormat();
	}
	
	/**
	 * Gets the country code.
	 *
	 * @return the country code
	 */
	public String getCountryCode() {
		return configurationProperties.getCountryCode();
	}
	
	/**
	 * Gets the file download url.
	 *
	 * @return the file download url
	 */
	public String getFileDownloadUrl() {
		return configurationProperties.getFileDownloadUrl();
	}

    /**
     * Gets the from E mail.
     *
     * @return the from E mail
     */
    public String getFromEMail() {
    	return configurationProperties.getSpringMailUsername();
    }

    /**
     * Gets the file upload path.
     *
     * @return the file upload path
     */
    public String getFileUploadPath() {
    	return configurationProperties.getFileUploadPath();
    }

	/**
	 * Gets the antivirus API key.
	 *
	 * @return the antivirus API key
	 */
	public String getAntivirusAPIKey() {
		return configurationProperties.getAntivirusApiKey();
	}
	
	/**
	 * Gets the antivirus API endpoint.
	 *
	 * @return the antivirus API endpoint
	 */
	public String getAntivirusAPIEndpoint() {
		return configurationProperties.getAntivirusApiEndpoint();
	}

    /**
     * Gets the logo upload path.
     *
     * @return the logo upload path
     */
    public String getLogoUploadPath() {
    	return configurationProperties.getLogoUploadPath();
	}
    
    /**
     * Gets the login url.
     *
     * @return the login url
     */
    public String getLoginUrl() {
    	return configurationProperties.getLoginUrl();
  	}

	/**
	 * Gets the mysql max idle timeout.
	 *
	 * @return the mysql max idle timeout
	 */
	public String getMysqlMaxIdleTimeout() {
		return configurationProperties.getMysqlMaxIdleTimeout();
	}

	/**
	 * Gets the mysql max idle time excess connections.
	 *
	 * @return the mysql max idle time excess connections
	 */
	public String getMysqlMaxIdleTimeExcessConnections() {
		return configurationProperties.getMysqlMaxIdleExcessConnections();
	}

	/**
	 * Gets the mater connection on checkout.
	 *
	 * @return the mater connection on checkout
	 */
	public Boolean getMaterConnectionOnCheckout() {
		return Boolean.valueOf(configurationProperties.getMysqlConnectionCheckout());
	}

	/**
	 * Gets the mysql min pool size.
	 *
	 * @return the mysql min pool size
	 */
	public String getMysqlMinPoolSize() {
		return configurationProperties.getMysqlMinPoolsize();
	}

	/**
	 * Gets the mysql max pool size.
	 *
	 * @return the mysql max pool size
	 */
	public String getMysqlMaxPoolSize() {
		return configurationProperties.getMysqlMaxPoolSize();
	}
	
	/**
	 * Gets the mysql idle connection test period.
	 *
	 * @return the mysql idle connection test period
	 */
	public String getMysqlIdleConnectionTestPeriod() {
		return configurationProperties.getMysqlIdleConnectionTestperiod();
	}
	
	/**
	 * Gets the time end.
	 *
	 * @return the time end
	 */
	public String getTimeEnd() {
		return configurationProperties.getTimeEnd();
	}
	
	/**
	 * Gets the common service url.
	 *
	 * @return the common service url
	 */
	public String getCommonServiceUrl() {
		return configurationProperties.getCommonServiceUrl();
	}
}