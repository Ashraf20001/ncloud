/*
 * @author codeboard
 */
package com.recoveryportal.config.property;

/**
 * The Enum DbType.
 */
public enum DbType {
	
	/** The master. */
	MASTER, 
 /** The test. */
 TEST
}