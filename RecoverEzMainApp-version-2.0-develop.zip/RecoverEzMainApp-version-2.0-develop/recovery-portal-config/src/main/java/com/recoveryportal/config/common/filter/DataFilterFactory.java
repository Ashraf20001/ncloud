/*
 * @author codeboard
 */
package com.recoveryportal.config.common.filter;

import java.util.EnumMap; 
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/**
 * A factory for creating DataFilter objects.
 */
@Component
public class DataFilterFactory {

	/**
	 * The filter map.
	 */
	private Map<FilterNameEnum, DataFilter> filterMap = null;

	/**
	 * The profile filiter.
	 */
	@Autowired
	@Qualifier("profileFilter")
	private DataFilter profileFiliter;

	/**
	 * Builds the map.
	 */
	@PostConstruct
	private void buildMap() {
		filterMap = new EnumMap<>(FilterNameEnum.class);
		filterMap.put(FilterNameEnum.PROFILE_FILTER, profileFiliter);
	}

	/**
	 * Gets the filter by name.
	 *
	 * @param filterName the filter name
	 * @return the filter by name
	 */
	public DataFilter getFilterByName(FilterNameEnum filterName) {
		return filterMap.get(filterName);
	}
}