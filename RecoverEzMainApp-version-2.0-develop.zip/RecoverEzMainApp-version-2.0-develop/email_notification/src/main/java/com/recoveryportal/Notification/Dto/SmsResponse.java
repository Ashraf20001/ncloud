package com.recoveryportal.Notification.Dto;

public class SmsResponse {
	private String Message;

}
