package com.recoveryportal.Notification.Service;


import java.nio.charset.StandardCharsets;

import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;


import com.recoveryportal.Notification.Dto.MailRequest;
import com.recoveryportal.Notification.Dto.MailResponse;
import com.recoveryportal.Notification.Dto.ResetPasswordRequest;

import freemarker.template.Configuration;




@Service
public class EmailSenderService {

	@Autowired
	private JavaMailSender sender;
	
	@Autowired
	private Configuration config;
	
	@Value("${spring.mail.username}")
    private String from;
    
	public MailResponse sendEmail(MailRequest request) {
		MailResponse response = new MailResponse();
		MimeMessage message = sender.createMimeMessage();
		try {
			// set mediaType
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			// add attachment
						
			
			String htmls = request.getTemplate();

			StringBuffer stringBuffer = new StringBuffer();
			for (String userId : request.getTo()) {
				stringBuffer.append(userId);
				stringBuffer.append(", ");
			}
			helper.setFrom(from);
			helper.setTo(InternetAddress.parse(stringBuffer.toString()));
			helper.setText(htmls,true);
			helper.setSubject(request.getSubject());
			sender.send(message);

			response.setMessage("mail send successfully");
			response.setStatus(Boolean.TRUE);
			

		} catch (	Exception e) {
			response.setMessage("Mail Sending failure : "+ e.getMessage());
			response.setStatus(Boolean.FALSE);
		}

		return response;
	}
	
	public MailResponse sendResetEmail(ResetPasswordRequest request) {
		MailResponse response = new MailResponse();
		MimeMessage message = sender.createMimeMessage();
		try {
			// set mediaType
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			
				helper.setFrom(from);
				helper.setTo(request.getTo());
				helper.setText(request.getTemplate());
				helper.setSubject(request.getSubject());
				sender.send(message);
		
			response.setMessage("mail send successfully");
			response.setStatus(Boolean.TRUE);
			

		} catch (	Exception e) {
			response.setMessage("Mail Sending failure : "+ e.getMessage());
			response.setStatus(Boolean.FALSE);
		}

		return response;
	}

    

}

