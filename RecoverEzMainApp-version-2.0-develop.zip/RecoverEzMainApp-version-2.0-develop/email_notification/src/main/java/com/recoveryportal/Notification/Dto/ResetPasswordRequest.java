package com.recoveryportal.Notification.Dto;

import java.util.List;

import lombok.Data;

@Data
public class ResetPasswordRequest {

	private String to;
	private String subject;
	private String template;
}
