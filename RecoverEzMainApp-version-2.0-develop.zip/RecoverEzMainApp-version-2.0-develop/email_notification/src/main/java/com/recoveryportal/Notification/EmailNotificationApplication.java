package com.recoveryportal.Notification;

import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * The Class EmailNotificationApplication.
 */
@SpringBootApplication
public class EmailNotificationApplication {
	
	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {

	}

}
