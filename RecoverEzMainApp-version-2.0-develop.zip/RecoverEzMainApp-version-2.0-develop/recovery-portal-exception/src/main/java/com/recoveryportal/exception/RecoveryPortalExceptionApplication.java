package com.recoveryportal.exception;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.recoveryportal.*")
public class RecoveryPortalExceptionApplication {

	public static void main(String[] args) {

	}

}
