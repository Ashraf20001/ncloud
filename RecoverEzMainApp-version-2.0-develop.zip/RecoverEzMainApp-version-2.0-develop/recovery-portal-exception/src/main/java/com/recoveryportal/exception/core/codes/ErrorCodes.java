/*
 * @author codeboard
 */
package com.recoveryportal.exception.core.codes;

/**
 * The Class ErrorCodes.
 */
public class ErrorCodes {

	/** The Constant BAD_REQUEST. */
	public static final ErrorId BAD_REQUEST = new ErrorId("E0029", "Bad Request");

	/** The Constant INVALID_COLUMN_NAME. */
	public static final ErrorId INVALID_COLUMN_NAME = new ErrorId("E0003", "Invalid column name to filter..!");

	/** The Constant INVALID_DATA. */
	public static final ErrorId INVALID_DATA = new ErrorId("E0002",
			"Data type not valid. Please provide data with valid data type..!");
	
	/** The Constant INVALID_METHOD_NAME. */
	public static final ErrorId INVALID_METHOD_NAME = new ErrorId("E0004", "Invalid Method name..!");
	
	/** The Constant UN_AUthorized. */
	public static final ErrorId UN_AUthorized = new ErrorId("E0005", "Invalid user name..!");
	
	/** The Constant FORGETPWDLIMIT. */
	public static final ErrorId FORGETPWDLIMIT=new ErrorId("E0006","Cannot send more than 3 emails per day." );
	
	/** The Constant INVALIDEMAIL. */
	public static final ErrorId INVALIDEMAIL=new ErrorId("E0007","Email is not registered") ;
	 
 	/** The Constant INVALIDATA. */
 	public static final ErrorId INVALIDATA=new ErrorId("E8050","Invalid Data") ;
	
	/** The Constant PWDFAILED. */
	public static final ErrorId PWDFAILED=new ErrorId("E0008","ResetPassword is failed ") ;
	
	/** The Constant USERNAME_EXIST. */
	public static final ErrorId USERNAME_EXIST=new ErrorId("E0009","Username already  exist ") ;
	
	/** The Constant SHORTNAME_EXIST. */
	public static final ErrorId SHORTNAME_EXIST=new ErrorId("E0014","ShortName already  exist ") ;	
	
	/** The Constant EMAIL_EXIST. */
	public static final ErrorId EMAIL_EXIST=new ErrorId("E0010","Email is already  exist ") ;
	
	/** The Constant BAD_CREDINTIAL. */
	public static final ErrorId BAD_CREDINTIAL=new ErrorId("E0011","Invalid Username & Password") ;
	
	/** The Constant PWD_MISSMATCH. */
	public static final ErrorId PWD_MISSMATCH=new ErrorId("E0012","new password is not matched with confirm password ") ;
	
	/** The Constant LINK_EXPIRED. */
	public static final ErrorId LINK_EXPIRED=new ErrorId("E0013","Link is expired ") ;
	
	/** The Constant COMPANY_NAME_EXIST. */
	public static final ErrorId COMPANY_NAME_EXIST=new ErrorId("E0015","CompanyName Already Exist ") ;

	/** The Constant INTERNAL_ERROR. */
	public static final ErrorId INTERNAL_ERROR = new ErrorId("E0000", "Something went wrong. Please try again...");

	/** The Constant INVALID_REPORT_LOSS_DTO. */
	/*
	  *REPORT LOSS ERROR CODES
	 */
	public static final ErrorId INVALID_REPORT_LOSS_DTO = new ErrorId("E5006","Invalid data in report loss dto");
	
	/** The Constant INVALID_REPORT_LOSS_INSURED_INFO. */
	public static final ErrorId INVALID_REPORT_LOSS_INSURED_INFO = new ErrorId("E5007","Invalid data in report loss insured info");
	
	/** The Constant INVALID_REPORT_LOSS_INSURED_INFO_COMPANY. */
	public static final ErrorId INVALID_REPORT_LOSS_INSURED_INFO_COMPANY = new ErrorId("E5008","Invalid data in report loss -insured info -company");
	
	/** The Constant INVALID_REPORT_LOSS_INSURED_INFO_VEHICLE_DETAILS. */
	public static final ErrorId INVALID_REPORT_LOSS_INSURED_INFO_VEHICLE_DETAILS = new ErrorId("E5009","Invalid data in report loss -insured info -vehicle details");
	
	/** The Constant INVALID_REPORT_LOSS_THIRD_PARTY_INFO. */
	public static final ErrorId INVALID_REPORT_LOSS_THIRD_PARTY_INFO = new ErrorId("E5010","Invalid data in report loss -third party info");
	
	/** The Constant INVALID_REPORT_LOSS_THIRD_PARTY_INFO_COMPANY. */
	public static final ErrorId INVALID_REPORT_LOSS_THIRD_PARTY_INFO_COMPANY = new ErrorId("E5011","Invalid data in report loss -third party info -company");
	
	/** The Constant INVALID_REPORT_LOSS_THIRD_PARTY_INFO_VEHICLE_DETAILS. */
	public static final ErrorId INVALID_REPORT_LOSS_THIRD_PARTY_INFO_VEHICLE_DETAILS = new ErrorId("E5012","Invalid data in report loss -third party info -vehicle details");
	
	/** The Constant INVALID_REPORT_LOSS_GARAGE_INFO. */
	public static final ErrorId INVALID_REPORT_LOSS_GARAGE_INFO = new ErrorId("E5013","Invalid data in report loss -garage info");
	
	/** The Constant INVALID_REPORT_LOSS_GARAGE_INFO_CONTACT. */
	public static final ErrorId INVALID_REPORT_LOSS_GARAGE_INFO_CONTACT = new ErrorId("E5014","Invalid data in report loss -garage info -contact");
	
	/** The Constant INVALID_REPORT_LOSS_USER_COMMENT_INFO. */
	public static final ErrorId INVALID_REPORT_LOSS_USER_COMMENT_INFO = new ErrorId("E5015","Invalid page id or role id");
	
	/** The Constant INVALID_REPORT_LOSS_TOTAL_LOSS. */
	public static final ErrorId INVALID_REPORT_LOSS_TOTAL_LOSS = new ErrorId("E8051","Invalid data in total loss dto");

	/** The Constant INVALID_REPORT_LOSS_MANDATORY_FIELDS_GARAGE. */
	/*
	*Mandatory fields in report loss
	*/
	public static final ErrorId INVALID_REPORT_LOSS_MANDATORY_FIELDS_GARAGE = new ErrorId("E5016","Invalid garage name, GarageSurveyAllocationDate, GarageSurveyDueDate and GarageAddressLocation in insured info");
	
	/** The Constant INVALID_REPORT_LOSS_MANDATORY_FIELDS_THIRD_PARTY. */
	public static final ErrorId INVALID_REPORT_LOSS_MANDATORY_FIELDS_THIRD_PARTY = new ErrorId("E5017","Please Enter The Mandatory  Field Third Party Company Name");
	
	/** The Constant INVALID_REPORT_LOSS_MANDATORY_FIELDS_INSURED_INFO. */
	public static final ErrorId INVALID_REPORT_LOSS_MANDATORY_FIELDS_INSURED_INFO = new ErrorId("E5018","Invalid model, make or registraion no in insured info");
	
	/** The Constant INVALID_IDENTITY. */
	public static final ErrorId INVALID_IDENTITY = new ErrorId("E5019","Invalid identity");
	
	/** The Constant INVALID_CLAIM_ID. */
	public static final ErrorId INVALID_CLAIM_ID = new ErrorId("E5020","Invalid claim id");
	
	/** The Constant NUMBER_FORMAT_EXCEPTION. */
	public static final ErrorId NUMBER_FORMAT_EXCEPTION= new ErrorId("E5021","Invalid number");
	
	/** The Constant INVALID_PAGE_OR_ROLE_ID. */
	public static final ErrorId INVALID_PAGE_OR_ROLE_ID= new ErrorId("E5022","Invalid page or role id");
	
	/** The Constant INVALID_FIELD_DATA. */
	public static final ErrorId INVALID_FIELD_DATA= new ErrorId("E5023","Invalid field data");
	
	/** The Constant INVALID_SECTION_DATA. */
	public static final ErrorId INVALID_SECTION_DATA= new ErrorId("E5024","Invalid section data");
	
	/** The Constant INVALID_META_DATA. */
	public static final ErrorId INVALID_META_DATA= new ErrorId("E5025","Invalid meta data");
	
	/** The Constant INVALID_CLAIM_SUMMARY_DETAILS. */
	public static final ErrorId INVALID_CLAIM_SUMMARY_DETAILS= new ErrorId("E5026","Invalid claim summary details");
    
    /** The Constant UN_AUTHORIZED. */
    public static final ErrorId UN_AUTHORIZED = new ErrorId("E5027","Unauthorized");
    
    /** The Constant INVALID_REPORT_LOSS_LOSS_DETAILS. */
    public static final ErrorId INVALID_REPORT_LOSS_LOSS_DETAILS = new ErrorId("E5028","Invalid data in report loss -loss details");
    
    /** The Constant INVALID_REPORT_LOSS_POLICE_REPORT. */
    public static final ErrorId INVALID_REPORT_LOSS_POLICE_REPORT = new ErrorId("E5029","Invalid data in report loss -police report");
    
    /** The Constant INVALID_REPORT_LOSS_SURVEY_DETAILS. */
    public static final ErrorId INVALID_REPORT_LOSS_SURVEY_DETAILS = new ErrorId("E5030","Invalid data in report loss -survey details");
    
    /** The Constant INVALID_REPORT_LOSS_SURVEY_REPORT. */
    public static final ErrorId INVALID_REPORT_LOSS_SURVEY_REPORT= new ErrorId("E5031","Invalid data in report loss -survey report");
    
    /** The Constant INVALID_REPORT_LOSS_RESERVE_REVIEW. */
    public static final ErrorId INVALID_REPORT_LOSS_RESERVE_REVIEW = new ErrorId("E5032","Invalid data in report loss -reserve review");
    
    /** The Constant INVALID_REPORT_LOSS_GARAGE_INVOICE. */
    public static final ErrorId INVALID_REPORT_LOSS_GARAGE_INVOICE = new ErrorId("E5033","Invalid data in report loss -garage invoice");
    
    /** The Constant INVALID_REPORT_LOSS_DEBIT_NOTE. */
    public static final ErrorId INVALID_REPORT_LOSS_DEBIT_NOTE = new ErrorId("E5034","Invalid data in report loss -debit note");
    
    /** The Constant INVALID_REPORT_LOSS_CREDIT_NOTE. */
    public static final ErrorId INVALID_REPORT_LOSS_CREDIT_NOTE = new ErrorId("E5035","Invalid data in report loss -credit note");
    
    /** The Constant INVALID_REPORT_LOSS_RECOVERY_DETAILS. */
    public static final ErrorId INVALID_REPORT_LOSS_RECOVERY_DETAILS = new ErrorId("E5036","Invalid data in report loss -recovery details");
    
    /** The Constant INVALID_FILE. */
    public static final ErrorId INVALID_FILE = new ErrorId("E5037","Invalid file");
    
    /** The Constant INVALID_COMPANY. */
    public static final ErrorId INVALID_COMPANY = new ErrorId("E8052","Invalid Company");

   
/** The Constant SF_LOSS_DETAILS. */
// status flow error code
    public static final ErrorId SF_LOSS_DETAILS = new ErrorId("E8107","Mandatory Details Yet to be Filled Under Loss Details");
    
    /** The Constant SF_CLAIM_NUMBER. */
    public static final ErrorId SF_CLAIM_NUMBER = new ErrorId("E5040","Mandatory Details Yet to Filled Under Survey Details");
    
    /** The Constant SF_REGISTRATION_NUMBER. */
    public static final ErrorId SF_REGISTRATION_NUMBER = new ErrorId("E5041","Mandatory Details Yet to Filled Under Insured Details");
    
    /** The Constant SF_TP_COMPANYNAME. */
    public static final ErrorId SF_TP_COMPANYNAME = new ErrorId("E5042","Mandatory Details Yet to Filled Under TP Details");
    
    /** The Constant SF_MODEL. */
    public static final ErrorId SF_MODEL = new ErrorId("E5043","Mandatory Details Yet to Filled Under Insured Details");
    
    /** The Constant SF_MAKE. */
    public static final ErrorId SF_MAKE = new ErrorId("E5044","Mandatory Details Yet to Filled Under Insured Details");
    
    /** The Constant SF_POLICY_ID. */
    public static final ErrorId SF_POLICY_ID = new ErrorId("E5045","Mandatory Details Yet to Filled Under TP Details");
    
    /** The Constant SF_TP_INSURANCE_CLAIM_NO. */
    public static final ErrorId SF_TP_INSURANCE_CLAIM_NO = new ErrorId("E5046","TP Claim Number Yet to be Filled");
    
    /** The Constant SF_POLICY_REPORT. */
    public static final ErrorId SF_POLICY_REPORT = new ErrorId("E5047","Police Report Yet to be Uploaded");
    
    /** The Constant SF_GARAGE_NAME. */
    public static final ErrorId SF_GARAGE_NAME = new ErrorId("E5048","Mandatory Details Yet to Filled Under Garage Details");
    
    /** The Constant SF_GARAGE_LOCATION. */
    public static final ErrorId SF_GARAGE_LOCATION = new ErrorId("E5049","Mandatory Details Yet to Filled Under Garage Details");
    
    /** The Constant SF_SURVEY_DUE_DATE. */
    public static final ErrorId SF_SURVEY_DUE_DATE = new ErrorId("E5050","Mandatory Details Yet to Filled Under Survey Details");
    
    /** The Constant SF_SURVEY_ALLOCATION_DATE. */
    public static final ErrorId SF_SURVEY_ALLOCATION_DATE = new ErrorId("E5051","Mandatory Details Yet to Filled Under Survey Details");
    
    /** The Constant SF_SURVEY_REPORT. */
    public static final ErrorId SF_SURVEY_REPORT = new ErrorId("E5052","Survey Report Yet to be Uploaded");
    
    /** The Constant SF_SURVEY_AMOUNT. */
    public static final ErrorId SF_SURVEY_AMOUNT = new ErrorId("E5053","Expenses Yet to be Filled");
    
    /** The Constant SF_LABOUR_COST. */
    public static final ErrorId SF_LABOUR_COST = new ErrorId("E5054","Mandatory Details Yet to Filled Under Survey Report");
    
    /** The Constant SF_SPARE_PARTS. */
    public static final ErrorId SF_SPARE_PARTS = new ErrorId("E5055","Mandatory Details Yet to Filled Under Survey Report");
    
    /** The Constant SF_CREDIT_NOTE. */
    public static final ErrorId SF_CREDIT_NOTE = new ErrorId("E5056","Mandatory Details Yet to Filled Under Credit Note");
    
    /** The Constant SF_DEBIT_NOTE. */
    public static final ErrorId SF_DEBIT_NOTE = new ErrorId("E5057","Mandatory Details Yet to Filled Under Debit Note");
    
    /** The Constant SF_GARAGE_REPORT. */
    public static final ErrorId SF_GARAGE_REPORT = new ErrorId("E5058"," Garage Invoice Yet to be Uploaded");
    
    /** The Constant SF_INSURANCE_COMPANY_NAME. */
    public static final ErrorId SF_INSURANCE_COMPANY_NAME = new ErrorId("E5059","Mandatory Details Yet to Filled Under TP Details");
    
    /** The Constant SF_POLICE_REPORT. */
    public static final ErrorId SF_POLICE_REPORT = new ErrorId("E5060","Police Report Yet to be Uploaded");
    
    /** The Constant SF_GARAGE_SURVEY_DTLS. */
    public static final ErrorId SF_GARAGE_SURVEY_DTLS = new ErrorId("E8054","Garage Details and Survey Details are Yet to be Filled");

    

    /** The Constant REPORT_GENERATION. */
    /*
     * Notification
     */
    public static final ErrorId REPORT_GENERATION = new ErrorId("E5061","Error occured during generation of report");
    
    /** The Constant ALREADY_WORKING. */
    public static final ErrorId ALREADY_WORKING = new ErrorId("E5062","Someone is already working on this claim");
    
    /** The Constant INVALID_ROLE. */
    public static final ErrorId INVALID_ROLE = new ErrorId("E50363","Invalid Role type to Proceed the Transaction");
    
    /** The Constant INVALID_TEMPLATE. */
    public static final ErrorId INVALID_TEMPLATE = new ErrorId("E5064","Template is not available for the given Notification Event");
    
    /** The Constant INVALID_EVENT. */
    public static final ErrorId INVALID_EVENT = new ErrorId("E5065","Notification Event is not available for the given Status");
    
    /** The Constant UNMAPPED_USER. */
    public static final ErrorId UNMAPPED_USER = new ErrorId("E5066","User not yet mapped to an Insurance Company");
    
    /** The Constant INVALID_USER. */
    public static final ErrorId INVALID_USER = new ErrorId("E5067","User not found!!");
    
    /** The Constant INVALID_LOGGED_IN_USER. */
    public static final ErrorId INVALID_LOGGED_IN_USER = new ErrorId("E5068","User is not related to the Claim");

    /** The Constant SF_TOTALLOSS_AMT_1. */
    public static final ErrorId SF_TOTALLOSS_AMT_1 = new ErrorId("E5069","Please Enter the Mandatory Field-Total Loss Amount 1");
    
    /** The Constant SF_ADJUSTERNAME_1. */
    public static final ErrorId SF_ADJUSTERNAME_1 = new ErrorId("E5070","Please Enter the Mandatory Field-Adjuster Name 1");
    
    /** The Constant SF_SURVEY_DATE_1. */
    public static final ErrorId SF_SURVEY_DATE_1 = new ErrorId("E5071","Please Enter the Mandatory Field-Survey Date 1");
    
    /** The Constant COMPANY_IS_NOT_MAPPED_THE_USER. */
    public static final ErrorId COMPANY_IS_NOT_MAPPED_THE_USER = new ErrorId("E8055","No Company is mapped to User");
    
    /** The Constant SF_COMMENTS. */
    public static final ErrorId SF_COMMENTS = new ErrorId("E8056","Comments Required for Action.");
    
    /** The Constant SF_COMMENTS_DETAILS. */
    public static final ErrorId SF_COMMENTS_DETAILS = new ErrorId("E8057","Enter Comments for the Details Provided");
    
    /** The Constant SF_COMMENTS_NEED_INFO. */
    public static final ErrorId SF_COMMENTS_NEED_INFO = new ErrorId("E8058","Enter Comments for Need Info");
    
    /** The Constant SF_COMMENTS_DISPUTE. */
    public static final ErrorId SF_COMMENTS_DISPUTE = new ErrorId("E8059","Enter Comments for Disputing");
    
    /** The Constant SF_COMMENTS_DISPUTE_REOPEN. */
    public static final ErrorId SF_COMMENTS_DISPUTE_REOPEN = new ErrorId("E8060","Enter Comments for Dispute Reopening");
    
    /** The Constant SF_COMMENTS_REJECTION. */
    public static final ErrorId SF_COMMENTS_REJECTION = new ErrorId("E8061","Enter Comments for Rejection");
    
    /** The Constant INVALID_USER_ROLE_DATA. */
    public static final ErrorId INVALID_USER_ROLE_DATA =new ErrorId("E7230","User role field is yet to be filled");

    /** The Constant INVALID_FIELD_IDENTITY. */
    public static final ErrorId INVALID_FIELD_IDENTITY = new ErrorId("E5073", "Invalid Field Identity");

	/** The Constant INVALID_STAGE_DETAILS. */
	public static final ErrorId INVALID_STAGE_DETAILS = new ErrorId("E5074", "Invalid Stage Details");

	/** The Constant INVALID_FIELD_CONFIG_DATA. */
	public static final ErrorId INVALID_FIELD_CONFIG_DATA = new ErrorId("E5075", "Invalid Field Configuration Data");

	/** The Constant INVALID_ACTION_FOR_CORE_DATA. */
	public static final ErrorId INVALID_ACTION_FOR_CORE_DATA = new ErrorId("E5076", "Cannot Delete Field Marked as CoreData");

	/** The Constant INVALID_DROP_DOWN. */
	public static final ErrorId INVALID_DROP_DOWN = new ErrorId("E5077", "Invalid DropdownList Identity");

	/** The Constant INVALID_PAGE. */
	public static final ErrorId INVALID_PAGE = new ErrorId("E5078", "Invalid Page Identity");

	/** The Constant INVALID_COMPANY_DTO. */
	public static final ErrorId INVALID_COMPANY_DTO = new ErrorId("E5079","Invalid data in company dto");
	
	/** The Constant INVALID_GARAGE. */
	public static final ErrorId INVALID_GARAGE = new ErrorId("E8062","Invalid Garage");

	/** The Constant INVALID_PAGE_ID. */
	public static final ErrorId INVALID_PAGE_ID = new ErrorId("E5081", "Invalid Page Id");
	
	/** The Constant INVALID_ACTION. */
	public static final ErrorId INVALID_ACTION= new ErrorId("E5082", "Invalid Action");


    /** The Constant INVALID_USER_DATA. */
    public static final ErrorId INVALID_USER_DATA =new ErrorId("E8063","Invalid User data");
    
    /** The Constant INVALID_PAGE_ID_OR_USER_ID. */
    public static final ErrorId INVALID_PAGE_ID_OR_USER_ID =new ErrorId("E8064","Invalid User Id or Page Id");

/** The Constant INVALID_FILE_PATH. */
//entity management
    public static final ErrorId INVALID_FILE_PATH = new ErrorId("E8065", "Invalid File Path");
    
    /** The Constant INVALID_UPLOAD_ID. */
    public static final ErrorId INVALID_UPLOAD_ID = new ErrorId("E8066", "Invalid Upload ID");


	/** The Constant ERR_TOTALCALIMAMOUNT_MIN. */
	//approval limit error
	public static final ErrorId ERR_TOTALCALIMAMOUNT_MIN = new ErrorId("E8067", "Minimum Total Claim  Amount should be at (Min Amount)");
	
	/** The Constant ERR_TOTALCALIMAMOUNT_MAX. */
	public static final ErrorId ERR_TOTALCALIMAMOUNT_MAX = new ErrorId("E8068", "Total Claim  Amount exceeds your approval limit. Requires approval from (role name)");
	
	/** The Constant ERR_CLAIMANOUNT_MIN. */
	public static final ErrorId ERR_CLAIMANOUNT_MIN = new ErrorId("E8069", "Minimum Claim Amount should be at (Min Amount)");
	
	/** The Constant ERR_CLAIMANOUNT_MAX. */
	public static final ErrorId ERR_CLAIMANOUNT_MAX = new ErrorId("E8070", " Claim Amount exceeds your approval limit. Requires approval from (role name)");
	
	/** The Constant ERR_SUMINSURED_MIN. */
	public static final ErrorId ERR_SUMINSURED_MIN = new ErrorId("E8071", "Minimum Sum Insured amount should be at (Min Amount)");
	
	/** The Constant ERR_SUMINSURED_MAX. */
	public static final ErrorId ERR_SUMINSURED_MAX = new ErrorId("E8072", "Sum Insured Amount exceeds your approval limit. Requires approval from (role name)");
	
	/** The Constant ERR_RESERVEAMOUNT_MIN. */
	public static final ErrorId ERR_RESERVEAMOUNT_MIN = new ErrorId("E8073", "Minimum Reserve Amount should be at (Min Amount)");
	
	/** The Constant ERR_RESERVEAMOUNT_MAX. */
	public static final ErrorId ERR_RESERVEAMOUNT_MAX = new ErrorId("E8074", "Reserve Amount exceeds your approval limit. Requires approval from (role name)");
	
	/** The Constant ERR_TOTALLOSSESTIMATED_MIN. */
	public static final ErrorId ERR_TOTALLOSSESTIMATED_MIN = new ErrorId("E8075", "Minimum TotalLoss Estimated Amount should be at (Min Amount)");
	
	/** The Constant ERR_TOTALLOSSESTIMATED_MAX. */
	public static final ErrorId ERR_TOTALLOSSESTIMATED_MAX = new ErrorId("E8076", "Total Loss Estimated amount exceeds your approval limit. Requires approval from (role name)");
	
	/** The Constant ERR_SURVEYAMOUNT_MIN. */
	public static final ErrorId ERR_SURVEYAMOUNT_MIN = new ErrorId("E8077", "Minimum Survey Amount should be at (Min Amount)");
	
	/** The Constant ERR_SURVEYAMOUNT_MAX. */
	public static final ErrorId ERR_SURVEYAMOUNT_MAX = new ErrorId("E8078", "Survey amount exceeds your approval limit. Requires approval from (role name)");
	
	/** The Constant ERR_TPSURVEYAMOUNT_MIN. */
	public static final ErrorId ERR_TPSURVEYAMOUNT_MIN = new ErrorId("E8079", "Minimum TP Survey Amount should be at (Min Amount)");
	
	/** The Constant ERR_TPSURVEYAMOUNT_MAX. */
	public static final ErrorId ERR_TPSURVEYAMOUNT_MAX = new ErrorId("E8080", "TP Survey amount exceeds your approval limit. Requires approval from (role name)");

	
	/** The Constant AMOUNT_EXCEDED. */
	public static final ErrorId AMOUNT_EXCEDED = new ErrorId("E8081", "Entered Amount Exceeded The Limit(1000000)");

	/** The Constant INVALID_STORAGE_REFERENCE_ID. */
	public static final ErrorId INVALID_STORAGE_REFERENCE_ID = new ErrorId("E6101", "Invalid Reference Id");

    /** The Constant SF_POLICE_REPORT_NUMBER. */
    public static final ErrorId SF_POLICE_REPORT_NUMBER = new ErrorId("E6102","Please Enter the  Mandatory Field  \"Police Report Number\"");

	/** The Constant INVALID_DROPDOWNLIST_ID. */
	public static final ErrorId INVALID_DROPDOWNLIST_ID = new ErrorId("E7101", "Invalid DropdownList Id!");

	/** The Constant INVALID_REPORT_DATA. */
	public static final ErrorId INVALID_REPORT_DATA = new ErrorId("E7102", "Invalid Data to Generate Report");
    
    /** The Constant INVALID_USER_NAME. */
    public static final ErrorId INVALID_USER_NAME = new ErrorId("E7103", "Invalid User Name");
    
    /** The Constant INVALID_PASSWORD. */
    public static final ErrorId INVALID_PASSWORD = new ErrorId("E7104", "Please Enter The Password");
    
    /** The Constant REASON_FOR_REPORT_LOSS. */
    public static final ErrorId REASON_FOR_REPORT_LOSS = new ErrorId("E7105", "Please Enter the Mandatory Field-Reason for Total loss ");
    
    /** The Constant INVALID_ROLE_NAME. */
    public static final ErrorId INVALID_ROLE_NAME = new ErrorId("E7106", "Role Name Already Exist!");
	
	/** The Constant INVALID_USER_TYPE. */
	public static final ErrorId INVALID_USER_TYPE = new ErrorId("E7107", "Invalid User Type");
	
	/** The Constant INVALID_USER_ID. */
	public static final ErrorId INVALID_USER_ID = new ErrorId("E8083", "Invalid User Id");
    
    /** The Constant INVALID_USER_ROLE_NAME. */
    public static final ErrorId INVALID_USER_ROLE_NAME = new ErrorId("E8084", "Invalid Role Name");
    
    /** The Constant INVALID_EMAIL_ID. */
    public static final ErrorId INVALID_EMAIL_ID = new ErrorId("E8085", "Invalid Email Id");
    
    /** The Constant INVALID_EMAIL_FIELD. */
    public static final ErrorId INVALID_EMAIL_FIELD = new ErrorId("E8086", "The email id field is yet to be filled");
    
    /** The Constant INVALID_PASSWORD_ID. */
    public static final ErrorId INVALID_PASSWORD_ID = new ErrorId("E8087", "Password must contains 1-UpperCase, 1-LowerCase, 1-digit, 1-Special Character and minimum 8 characters");
   
   /** The Constant INVALID_COMPANY_ID. */
   public static final ErrorId INVALID_COMPANY_ID = new ErrorId("E8053", "Invalid Company Id");
   
   /** The Constant SHORTID_EXISTS. */
   public static final ErrorId SHORTID_EXISTS = new ErrorId("E8088","Short Id Already Exist");
   
   /** The Constant USERID_EXISTS. */
   public static final ErrorId USERID_EXISTS = new ErrorId("E8089","User Id Already Exist");
   
   /** The Constant SHORTID_USERID_EXISTS. */
   public static final ErrorId SHORTID_USERID_EXISTS = new ErrorId("E8090","Short Id & User Id Already Exist");
   
   /** The Constant NO_LOGO_FOUND. */
   public static final ErrorId NO_LOGO_FOUND = new ErrorId("E8091", "No Logo Available");
   
   /** The Constant INVALID_MAX_VALUE. */
   public static final ErrorId INVALID_MAX_VALUE = new ErrorId("E8092", "Please Enter the Maximum Amount Greater than the Minimum Amount");
   
   /** The Constant MAPPING_TABLE_NOT_FOUND. */
   public static final ErrorId MAPPING_TABLE_NOT_FOUND = new ErrorId("E8093", "Bulk Import Mapping table not found");
   
   /** The Constant CLAIM_ALREADY_EXIST. */
   public static final ErrorId CLAIM_ALREADY_EXIST = new ErrorId("E8094", "Claim already exist");
   
   /** The Constant CLAIM_NOT_EXIST. */
   public static final ErrorId CLAIM_NOT_EXIST = new ErrorId("E8082", "Claim Not exist");
   
   /** The Constant INSURANCE_COMPANY_NOT_EXIST. */
   public static final ErrorId INSURANCE_COMPANY_NOT_EXIST = new ErrorId("E8095", "Insurance company Not exist");
   
   /** The Constant TP_COMPANY_NOT_EXIST. */
   public static final ErrorId TP_COMPANY_NOT_EXIST = new ErrorId("E8096", "Third party company Not exist");
   
   /** The Constant TOO_MANY_ATTEMTS. */
   public static final ErrorId TOO_MANY_ATTEMTS = new ErrorId("E8099", "Too Many Attempts");
	
	/** The Constant MALICIOUS_FILE. */
	public static final ErrorId MALICIOUS_FILE = new ErrorId("E8100", "Uploaded file is invalid");
	
	/** The Constant INVALID_CHARACTERS. */
	public static final ErrorId INVALID_CHARACTERS = new ErrorId("E8101", "Invalid Characters in File Name");
	
	/** The Constant MAXIMUM_CHARACTERS_EXCEED. */
	public static final ErrorId MAXIMUM_CHARACTERS_EXCEED = new ErrorId("E8102", "Maximum Characters 255 exceeded in File Name");
	
	/** The Constant MULTIPLE_EXTENSION. */
	public static final ErrorId MULTIPLE_EXTENSION = new ErrorId("E8103", "File name contains invalid characters. Avoid special characters or symbols");
	
	/** The Constant UNAUTHROIZE_IDENTITY. */
	public static final ErrorId UNAUTHROIZE_IDENTITY = new ErrorId("E8104", "Unauthorized to access this data");


	/** The Constant INVALID_ROLE_ID. */
	public static final ErrorId INVALID_ROLE_ID= new ErrorId("E7132", "Invalid Role Id");
	 
 	/** The Constant INVALID_REGISTRATION_NO. */
 	public static final ErrorId INVALID_REGISTRATION_NO = new ErrorId("E7133", "Duplicate value in field Registration Number in Insured Details.");
	 
 	/** The Constant INVALID_POLICY_ID. */
 	public static final ErrorId INVALID_POLICY_ID = new ErrorId("E7134", "Duplicate value in field TP Policy Id");
	 
 	/** The Constant INVALID_TP_NUMBER. */
 	public static final ErrorId INVALID_TP_NUMBER = new ErrorId("E7135", "Duplicate value in field TP Insurance Claim Number.");
	 
 	/** The Constant INVALID_CLAIM_NO. */
 	public static final ErrorId INVALID_CLAIM_NO = new ErrorId("E7136", "Duplicate value in field  Loss Details Claim Number.");
	 
 	/** The Constant INVALID_POLICE_REPORT_NO. */
 	public static final ErrorId INVALID_POLICE_REPORT_NO = new ErrorId("E8105", "Duplicate value in field Police Report Number.");
	 
 	/** The Constant INVALID_POLICY_NO. */
 	public static final ErrorId INVALID_POLICY_NO = new ErrorId("E7138", "Duplicate value in field Policy Number.");
    
    /** The Constant INVALID_GARAGE_DETAILS. */
    public static final ErrorId INVALID_GARAGE_DETAILS = new ErrorId("E7139", "Invalid Garage details");

	/** The Constant DELETED_GARAGE_DETAILS. */
	public static final ErrorId DELETED_GARAGE_DETAILS = new ErrorId("E7140", "Garage you are trying to delete is already deleted");
	
	/** The Constant INVALID_REGISTRATION_NO_TP. */
	public static final ErrorId INVALID_REGISTRATION_NO_TP = new ErrorId("E7141", "Duplicate value in field Registration Number in TP Details.");
	
	/** The Constant INVALID_DATA_LOSS_DETAILS. */
	public static final ErrorId INVALID_DATA_LOSS_DETAILS = new ErrorId("E7142", "Duplicate values in Section : Loss Details ");

	/** The Constant INVALID_PHONE_NUMBER. */
	public static final ErrorId INVALID_PHONE_NUMBER = new ErrorId("E8106", "Invalid Phone Number");
	
	/** The Constant INVALID_EMAIL. */
	public static final ErrorId INVALID_EMAIL = new ErrorId("E7144", "New Password and Existing Password are Same");
	
	/** The Constant INVALID_DATA_INSURED. */
	public static final ErrorId INVALID_DATA_INSURED = new ErrorId("E7145", "Duplicate value in section, Insured Details");
	
	/** The Constant INVALID_DATA_TP. */
	public static final ErrorId INVALID_DATA_TP = new ErrorId("E7146", "Duplicate value in section, TP Details");
    
    /** The Constant PAYMENT_NOT_YET_APPROVED. */
    public static final ErrorId PAYMENT_NOT_YET_APPROVED = new ErrorId("E8001", "Payment not yet approved");
    
    /** The Constant INVALID_REPORT. */
    public static final ErrorId INVALID_REPORT = new ErrorId("E8002", "Invalid Report");
	
	/** The Constant PAYMENT_ALREADY_DONE. */
	public static final ErrorId PAYMENT_ALREADY_DONE = new ErrorId("E8003", "Payment Done Already");
	
	/** The Constant INVALID_REPORT_TYPE. */
	public static final ErrorId INVALID_REPORT_TYPE = new ErrorId("E8004", "Invalid Report Type");
	
	/** The Constant INVALID_USER_FOR_PAYMENT. */
	public static final ErrorId INVALID_USER_FOR_PAYMENT = new ErrorId("E8005", "Invalid User");
    
    /** The Constant INVALID_PAYMENT. */
    public static final ErrorId INVALID_PAYMENT = new ErrorId("E8006", "Recipient not assigned for this report");
	
	/** The Constant PENDING_INSURANCE_APPROVAL_FOR_PAYMENT. */
	public static final ErrorId PENDING_INSURANCE_APPROVAL_FOR_PAYMENT =  new ErrorId("E8007", "Pending Insurance Payment Approval to Pay Association");
	
	/** The Constant ERR_EXCEED_TOTALCALIMAMOUNT_MAX. */
	//Exceed Approved Limit Error Codes 
	public static final ErrorId ERR_EXCEED_TOTALCALIMAMOUNT_MAX = new ErrorId("E8008", "Total loss Estimated Amount exceeds your approval limit and no other limits are available. Contact your admin");
	
	/** The Constant ERR_EXCEED_CLAIMANOUNT_MAX. */
	public static final ErrorId ERR_EXCEED_CLAIMANOUNT_MAX = new ErrorId("E8009", "Claim Amount exceeds your Approval limit and no other limits are available. Contact your admin");
	
	/** The Constant ERR_EXCEED_SUMINSURED_MAX. */
	public static final ErrorId ERR_EXCEED_SUMINSURED_MAX = new ErrorId("E8010", "Sum Insured Amount exceeds your Approval limit and no other limits are available. Contact your admin");
	
	/** The Constant ERR_EXCEED_RESERVEAMOUNT_MAX. */
	public static final ErrorId ERR_EXCEED_RESERVEAMOUNT_MAX = new ErrorId("E8011", "Reserve amount exceeds your Approval limit and no other limits are available. Contact your admin.");
	
	/** The Constant ERR_EXCEED_TOTALLOSSESTIMATED_MAX. */
	public static final ErrorId ERR_EXCEED_TOTALLOSSESTIMATED_MAX = new ErrorId("E8012", "Total loss Estimated amount exceeds your Approval limit and no other limits are available. Contact your admin");
	
	/** The Constant ERR_EXCEED_SUEVEYAMOUNT_MAX. */
	public static final ErrorId ERR_EXCEED_SUEVEYAMOUNT_MAX = new ErrorId("E8013", "Survey amount exceeds your Approval limit and no other limits are available. Contact your admin");
	
	/** The Constant ERR_EXCEED_TPSUEVEYAMOUNT_MAX. */
	public static final ErrorId ERR_EXCEED_TPSUEVEYAMOUNT_MAX = new ErrorId("E8014", "TP Survey amount exceeds your Approval limit and no other limits are available. Contact your admin");
	
	
	/** The Constant ERR_REASSIGN_USER_ROLE. */
	public static final ErrorId ERR_REASSIGN_USER_ROLE = new ErrorId("E8015", "Reassign existing users to another role before disabling this user role.");
	
	/** The Constant INVALID_EFF_DATE. */
	public static final ErrorId INVALID_EFF_DATE = new ErrorId("E8016","The effective To Date should be a present or future date.");
	
	/** The Constant EFF_DATE_ALREADY_PASSED. */
	public static final ErrorId EFF_DATE_ALREADY_PASSED = new ErrorId("E8017","The effective To Date has already passed. User role has been disabled.");
	
	/** The Constant EFF_DATE_ALREADY_PASSED_USER. */
	public static final ErrorId EFF_DATE_ALREADY_PASSED_USER = new ErrorId("E8018","The effective To Date has already passed. User has been disabled.");
	
	/** The Constant ERR_REASSIGN_USER. */
	public static final ErrorId ERR_REASSIGN_USER = new ErrorId("E8019", "At least one administrator account must remain active.");
	
	/** The Constant EMPTY_EFFECTIVE_DATE. */
	public static final ErrorId EMPTY_EFFECTIVE_DATE = new ErrorId("E8020", "Please enter a valid effective To Date for disabling the user role.");
	
	/** The Constant EFF_DATE_ALREADY_PASSED_GARAGE. */
	public static final ErrorId EFF_DATE_ALREADY_PASSED_GARAGE = new ErrorId("E8021","The effective To Date has already passed. Garage has been disabled.");
    
    /** The Constant DUPLICATE_DROPDOWN. */
    public static final ErrorId DUPLICATE_DROPDOWN = new ErrorId("E8022","Field Name Already Exists");
    
    /** The Constant SF_DUAL_CURRENCY. */
    public static final ErrorId SF_DUAL_CURRENCY = new ErrorId("E8023","Mandatory Details Yet to Filled Under Insured Details");
    
    /** The Constant CURRENCY_FIELD_IN_USE. */
    public static final ErrorId CURRENCY_FIELD_IN_USE = new ErrorId("E8024", "Cannot delete Currency Field. Claims exists with currency values!");
    
    /** The Constant CURRENCY_VALUE_IN_USE. */
    public static final ErrorId CURRENCY_VALUE_IN_USE = new ErrorId("E8025", "Claims exists with the given currency value!");

    /** The Constant BULK_IMPORT_EMPTY_FILE. */
    public static final ErrorId BULK_IMPORT_EMPTY_FILE = new ErrorId("E8026", "File should not be empty");
    
    /** The Constant BULK_IMPORT_INVALID_TEMPLATE. */
    public static final ErrorId BULK_IMPORT_INVALID_TEMPLATE = new ErrorId("E8027", "File Template is incorrect");
    
    /** The Constant DUPLICATE_DROPDOWN_OPTION_NAME. */
    public static final ErrorId DUPLICATE_DROPDOWN_OPTION_NAME = new ErrorId("E8028", "Dropdown Option Name already exists");

	/** The Constant SAME_TO_OLD_PASSWORD. */
	public static final ErrorId SAME_TO_OLD_PASSWORD = new ErrorId("E8029", "Choose passwords that are significantly different from previously used passwords.");
    
    /** The Constant INVALID_PASSWORD_ID_inside. */
    public static final ErrorId INVALID_PASSWORD_ID_inside = new ErrorId("E8031", "Password Must Contain 1- Uppercase 1-Lowercase 1-Special character and minimum (8-20) characters");
    
    /** The Constant DICTIONARY_WORDS. */
    public static final ErrorId DICTIONARY_WORDS = new ErrorId("E8032","Your passwords should not contain dictionary words from English or any other language");
    
    /** The Constant PASSWORD_STRENGTH. */
    public static final ErrorId PASSWORD_STRENGTH = new ErrorId("E8034", "For added security, avoid using passwords associated with personal details.");
    
    /** The Constant COMMOM_PASSWORD. */
    public static final ErrorId COMMOM_PASSWORD = new ErrorId("E8035", " Avoid choosing familiar acronyms or common slang expressions.");


    /**
     * Instantiates a new error codes.
     */
    private ErrorCodes() {
	}
}
