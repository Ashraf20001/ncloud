package com.recoveryportal.fileupload.handler;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.recoveryportal.constants.core.ApplicationConstants;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.fileupload.service.local.FileUploadServiceLocal;

/**
 * The Class FileUploadHandler.
 */
@Component
public class FileUploadHandler {
	
	/** The storage type. */
	@Value("${recovery.file-upload-storage-type}")
	private String storageType;
	
	/** The file upload service. */
	@Autowired
	private FileUploadServiceLocal fileUploadService;
	
	
	/**
	 * Upload document.
	 *
	 * @param file the file
	 * @param claimId the claim id
	 * @param reportType the report type
	 * @return the string
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws ApplicationException the application exception
	 */
	public String uploadDocument(MultipartFile file, String claimId, String reportType) throws IOException, ApplicationException {
		String fileName = null;
		if (storageType.equals(ApplicationConstants.LOCAL)) {
			 fileName = fileUploadService.saveFile(file,claimId,reportType);
		}
		
		return fileName;
		
	}
	
	/**
	 * Download file.
	 *
	 * @param fileName the file name
	 * @return the resource
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public Resource downloadFile(String fileName) throws IOException {
		Resource fileAsResource = null;
		if (storageType.equals(ApplicationConstants.LOCAL)) {
			 fileAsResource = fileUploadService.getFileAsResource(fileName);
		}
		return fileAsResource;
		
	}

}
