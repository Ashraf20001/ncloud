package com.recoveryportal.fileupload.service.local;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.recoveryportal.constants.core.ApplicationConstants;
import com.recoveryportal.exception.core.ApplicationException;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;


/**
 * The Class FileUploadServiceLocal.
 */
@Service
public class FileUploadServiceLocal {

	/** The file path. */
	@Value("${recovery.file-upload-path}")
	private String filePath;
	
	/**
	 * Save file.
	 *
	 * @param multipartFile the multipart file
	 * @param claimId the claim id
	 * @param reportType the report type
	 * @return the string
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws ApplicationException the application exception
	 */
	public  String saveFile(MultipartFile multipartFile, String claimId, String reportType)
            throws IOException, ApplicationException {
        Path uploadPath = Paths.get(filePath);
          
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }
        String fileCode=null;
        if (claimId.equals(ApplicationConstants.NULL)) {
        	 fileCode = System.currentTimeMillis() + "_" + multipartFile.getOriginalFilename();
		}else {
			fileCode = claimId +"_"+ System.currentTimeMillis() + "_" + multipartFile.getOriginalFilename();
		}
        if(reportType.equals(ApplicationConstants.CREDIT_NOTE)) {
            fileCode = System.currentTimeMillis() + "_" + ApplicationConstants.CREDIT_NOTE + ApplicationConstants.DOT_PDF;
        }
        if(reportType.equals(ApplicationConstants.DEBIT_NOTE)) {
            fileCode = System.currentTimeMillis() + "_" + ApplicationConstants.DEBIT_NOTE + ApplicationConstants.DOT_PDF;
        }
        try (InputStream inputStream = multipartFile.getInputStream()) {
            Path filePath = uploadPath.resolve(fileCode);
            Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ioe) {       
            throw new IOException("Could not save file: " , ioe);
        }
         
        return fileCode;
    }
	
	
	/** The found file. */
	private Path foundFile;

    /**
     * Gets the file as resource.
     *
     * @param fileCode the file code
     * @return the file as resource
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public synchronized Resource getFileAsResource(String fileCode) throws IOException {
    	foundFile = null;
	
        Path dirPath = Paths.get(filePath);
         
        Files.list(dirPath).forEach(file -> {
            if (file.getFileName().toString().startsWith(fileCode)) {
                foundFile = file;
                return;
            }
        });
 
        if (foundFile != null) {
            return new UrlResource(foundFile.toUri());
        }
         
        return null;
    }
}
