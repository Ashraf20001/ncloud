package com.recovery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecoveryEZBuilderApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecoveryEZBuilderApplication.class, args);
	}

}
