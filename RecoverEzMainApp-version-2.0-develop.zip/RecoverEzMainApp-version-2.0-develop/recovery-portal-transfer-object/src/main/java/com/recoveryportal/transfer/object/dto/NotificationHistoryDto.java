package com.recoveryportal.transfer.object.dto;

import java.util.Date;

import lombok.Data;

/**
 * The Class NotificationHistoryDto.
 */
@Data
public class NotificationHistoryDto {
	  
	/** The claim id. */
	private Integer claimId;
	
	/** The template. */
	private String template;
	
	/** The is read. */
	private boolean isRead;
	
	/** The last acted company. */
	private String lastActedCompany;
	
	/** The to notify company. */
	private String toNotifyCompany;
	
	/** The status. */
	private String status;
	
	/** The is receivable. */
	private boolean isReceivable;

	/** The created date. */
	private Date createdDate;
	
	/** The image url. */
	private String imageUrl;
	
	/** The claim identity. */
	private String claimIdentity;
	
	/** The approval id. */
	private Integer approvalId;
	
	/** The re placable template data. */
	private String rePlacableTemplateData;
}
