package com.recoveryportal.transfer.object.models;

/**
 * The Class StackedBarChartModelTemp.
 */
public class StackedBarChartModelTemp {
    
    /** The company. */
    private String company;
    
    /** The values. */
    private int[] values;

    /**
     * Instantiates a new stacked bar chart model temp.
     */
    public StackedBarChartModelTemp() {
    }

    /**
     * Instantiates a new stacked bar chart model temp.
     *
     * @param company the company
     * @param values the values
     */
    public StackedBarChartModelTemp(String company, int[] values) {
        this.company = company;
        this.values = values;
    }

    /**
     * Gets the company.
     *
     * @return the company
     */
    public String getCompany() {
        return company;
    }

    /**
     * Sets the company.
     *
     * @param company the new company
     */
    public void setCompany(String company) {
        this.company = company;
    }

    /**
     * Gets the values.
     *
     * @return the values
     */
    public int[] getValues() {
        return values;
    }

    /**
     * Sets the values.
     *
     * @param values the new values
     */
    public void setValues(int[] values) {
        this.values = values;
    }

}
