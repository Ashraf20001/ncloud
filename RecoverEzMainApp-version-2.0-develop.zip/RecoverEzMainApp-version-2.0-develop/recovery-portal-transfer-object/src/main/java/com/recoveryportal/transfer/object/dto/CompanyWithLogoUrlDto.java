package com.recoveryportal.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CompanyWithLogoUrlDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CompanyWithLogoUrlDto {
    
    /** The company. */
    private Integer company;
    
    /** The logo url. */
    private String logoUrl;
}
