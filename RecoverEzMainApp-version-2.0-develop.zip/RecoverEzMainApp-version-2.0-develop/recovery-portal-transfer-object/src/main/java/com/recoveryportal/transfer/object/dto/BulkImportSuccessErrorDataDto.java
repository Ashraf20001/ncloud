package com.recoveryportal.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The Class BulkImportSuccessErrorDataDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BulkImportSuccessErrorDataDto {
    
    /** The bulk import temp data dto list. */
    private List<BulkImportTempDataDto> bulkImportTempDataDtoList;
    
    /** The bulk import history dto. */
    private BulkImportHistoryDto bulkImportHistoryDto;
}
