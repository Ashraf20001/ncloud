package com.recoveryportal.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The Class UserSectionMappingDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserSectionMappingDto {
    
    /** The section id. */
    private Integer sectionId;
    
    /** The section identity. */
    private String sectionIdentity;
    
    /** The section name. */
    private String sectionName;
    
    /** The parent section. */
    private Integer parentSection;
    
    /** The page id. */
    private Integer pageId;
    
    /** The is notification. */
    private Boolean isNotification = false;
    
    /** The section data. */
    private List<UserSectionMappingDto> sectionData;
}
