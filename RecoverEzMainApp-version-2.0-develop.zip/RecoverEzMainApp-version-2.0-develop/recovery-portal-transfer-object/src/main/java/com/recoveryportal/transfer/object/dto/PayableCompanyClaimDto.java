package com.recoveryportal.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class PayableCompanyClaimDto.
 */
@Data
@NoArgsConstructor

public class PayableCompanyClaimDto {
	
	/** The company name. */
	private String companyName;
	
	/** The claims count. */
	private Long claimsCount = 0l;
	
	/** The notification stage. */
	private Long notificationStage = 0l;
	
	/** The claim inspection stage. */
	private Long claimInspectionStage= 0l;
	
	/** The liability conformation stage. */
	private Long liabilityConformationStage= 0l;
	
	/** The settlement stage. */
	private Long settlementStage= 0l;

	/** The total claims count. */
	private Long totalClaimsCount = 0l;
	
	/** The total notification stage. */
	private Long totalNotificationStage = 0l;
	
	/** The total claim inspection stage. */
	private Long totalClaimInspectionStage= 0l;
	
	/** The totalliability conformation stage. */
	private Long totalliabilityConformationStage= 0l;
	
	/** The total settlement stage. */
	private Long totalSettlementStage= 0l;
}
