package com.recoveryportal.transfer.object.dto;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SectionDto.
 */
@Data
@NoArgsConstructor
public class SectionDto {
	
	/** The section id. */
	private String sectionId;
	
	/** The section name. */
	private String sectionName;

	/** The section list. */
	private List<SectionDto> sectionList;

	/** The field list. */
	private List<FieldDto> fieldList;
	
	/** The is all filled. */
	private Boolean isAllFilled;
	
	/** The is viewable. */
	private Boolean isViewable;
	
	/** The is editable. */
	private Boolean isEditable;
	
	/** The is downloadable. */
	private Boolean isDownloadable;
	
	/** The is enabled. */
	private Boolean isEnabled;

	/** The is notification. */
	private Boolean isNotification;

}
