package com.recoveryportal.transfer.object.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;

/**
 * The Class BulkImportMapping.
 */
@Data
@Entity
@Table(name="bulk_import_mapping")
public class BulkImportMapping {

	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Integer id;
	
	/** The bulk import field name. */
	@Column(name="bulk_import_fieldName")
	private String bulkImportFieldName;
	
	/** The bulk import alias name. */
	@Column(name="bulk_import_aliasName")
	private String bulkImportAliasName;
	
	/** The is mandatory. */
	@Column(name="IsMandatrory")
	private Boolean isMandatory;
	
	/** The is drop down. */
	@Column(name="IsDropDown")
	private Boolean isDropDown;
	
	/** The section details. */
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="section_id")
	private Section sectionDetails;
	
	/** The order by. */
	@Column(name="order_by")
	private Integer orderBy;

	/** The is deleted. */
	@Column(name="is_deleted")
	private boolean isDeleted;
	
	/** The identity. */
	@Column(name="identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;
	
}
