package com.recoveryportal.transfer.object.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.recoveryportal.transfer.object.notification.entity.NotificationEvent;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class ClaimHistoryTemplate.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "claim_history_template")
public class ClaimHistoryTemplate {

	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "claim_history_template_id")
	private Integer id;

	/** The notification event. */
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "event_id")
	private NotificationEvent notificationEvent;

	/** The template. */
	@Column(name = "template")
	private String template;

	/** The section. */
	@Column(name = "section")
	private String section;

	/** The stage. */
	@Column(name = "stage")
	private String stage;

	/** The state. */
	@Column(name = "state")
	private String state;

	/** The identity. */
	@Column(name = "identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;

	/** The created date. */
	@Column(name = "created_date")
	private Date createdDate;

	/** The created by. */
	@Column(name = "created_by")
	private int createdBy;

	/** The modified date. */
	@Column(name = "modified_date")
	private Date modifiedDate;

	/** The modified by. */
	@Column(name = "modified_by")
	private int modifiedBy;

	/** The is deleted. */
	@Column(name = "is_deleted")
	private boolean isDeleted;
	
	/** The claim history unique code. */
	@Column(name = "clm_hstry_unique_code")
	private String claimHistoryUniqueCode;
}
