package com.recoveryportal.transfer.object.reportloss.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.envers.Audited;

import com.recoveryportal.transfer.object.entity.Auditable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class PoliceReport.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rl_police_report")
@Audited
public class PoliceReport extends Auditable implements Serializable {
	
	

    /** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4576243180455913552L;

	/** The police report id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "police_report_id")
    private int policeReportId;

    /** The document upload. */
    @Column(name = "document_upload")
    private String documentUpload;
  
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;
}
