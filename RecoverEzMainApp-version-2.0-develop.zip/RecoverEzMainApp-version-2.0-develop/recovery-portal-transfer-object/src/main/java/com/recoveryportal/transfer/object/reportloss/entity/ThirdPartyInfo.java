package com.recoveryportal.transfer.object.reportloss.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import com.recoveryportal.transfer.object.entity.Auditable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ThirdPartyInfo.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rl_third_party_info")
@Audited
public class ThirdPartyInfo extends Auditable implements Serializable {
    
    /** The Constant serialVersionUID. */
	private static final long serialVersionUID = -9007782629065633000L;
	
	/** The third party info id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "third_party_info_id")
    private int thirdPartyInfoId;
    
    /** The tp company. */
    @Column(name = "tp_company_id")
    private Integer tpCompany;
    
    /** The policy number. */
    @Column(name = "policy_number")
    private String policyNumber;
    
    /** The claim no. */
    @Column(name = "claim_no")
    private String claimNo;
    
    /** The vehicle details. */
    @OneToOne(cascade = {CascadeType.ALL})
    @JoinColumn(name = "vehicle_details")
    @NotAudited
    private VehicleDetails vehicleDetails;
    
    /** The registration type. */
    @Column(name = "registration_type")
    private String registrationType;

    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;

    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;
}
