package com.recoveryportal.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The Class AccessMappingSectionDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccessMappingSectionDto {

    /** The section id. */
    private Integer sectionId;
    
    /** The section identity. */
    private String sectionIdentity;
    
    /** The section name. */
    private String sectionName;
    
    /** The parent section. */
    private Integer parentSection;
    
    /** The page id. */
    private Integer pageId;
    
    /** The is view. */
    private Boolean isView = true;
    
    /** The is edit. */
    private Boolean isEdit = true;
    
    /** The is download. */
    private Boolean isDownload = true;
    
    /** The is notification. */
    private Boolean isNotification = true;
    
    /** The is email. */
    private Boolean isEmail = true;
    
    /** The section data. */
    private List<AccessMappingSectionDto> sectionData;
}
