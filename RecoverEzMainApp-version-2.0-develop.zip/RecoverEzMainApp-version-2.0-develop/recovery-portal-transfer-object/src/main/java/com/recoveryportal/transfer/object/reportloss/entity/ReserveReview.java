package com.recoveryportal.transfer.object.reportloss.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.envers.Audited;

import com.recoveryportal.transfer.object.entity.Auditable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ReserveReview.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rl_reserve_review")
@Audited
public class ReserveReview extends Auditable implements Serializable{

    /** The Constant serialVersionUID. */
	private static final long serialVersionUID = 2735750262382310105L;

	/** The reserve review id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "reserve_review_id")
    private int reserveReviewId;

    /** The reserve amount. */
    @Column(name = "reserve_amount")
    private Double reserveAmount;
    
    /** The tp survey amount. */
    @Column(name = "tp_survey_amount")
    private Double tpSurveyAmount;
    
    /** The tp claim amount. */
    @Column(name = "tp_claim_amount")
    private Double tpClaimAmount;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;
}
