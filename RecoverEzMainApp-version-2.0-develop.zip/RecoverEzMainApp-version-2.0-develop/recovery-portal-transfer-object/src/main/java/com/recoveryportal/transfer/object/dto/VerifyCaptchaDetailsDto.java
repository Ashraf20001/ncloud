package com.recoveryportal.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class VerifyCaptchaDetailsDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class VerifyCaptchaDetailsDto {
	
	/** The clear. */
	private Boolean clear = true;
	
	/** The captcha value. */
	private String captchaValue;
	
	/** The compare captcha data value. */
	private String compareCaptchaDataValue;
	

}
