package com.recoveryportal.transfer.object.dto;

import lombok.*;

import java.util.List;

/**
 * The Class MetaDataViewDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class MetaDataViewDto {
    
    /** The page id. */
    private String pageId;
    
    /** The page name. */
    private String pageName;
    
    /** The is enabled. */
    private boolean isEnabled;
    
    /** The section list. */
    private List<SectionDto> sectionList;
}
