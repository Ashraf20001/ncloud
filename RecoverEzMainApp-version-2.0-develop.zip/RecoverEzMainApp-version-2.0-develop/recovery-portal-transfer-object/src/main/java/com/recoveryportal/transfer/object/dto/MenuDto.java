package com.recoveryportal.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.time.LocalDateTime;
import java.util.List;

/**
 * The Class MenuDto.
 */
@Data
@NoArgsConstructor
public class MenuDto {
    
    /** The menu id. */
    private Integer menuId;
    
    /** The menu name. */
    private String menuName;
}
