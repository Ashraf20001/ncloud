package com.recoveryportal.transfer.object.chart;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class StackedBarChartFilterDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class StackedBarChartFilterDto {
    
    /** The company. */
    private Object company;
    
    /** The ranges. */
    private Object ranges;
    
    /** The count. */
    private Object count;
}