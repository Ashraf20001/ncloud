package com.recoveryportal.transfer.object.dto;

/**
 * The Enum RepeatFormatEnum.
 */
public enum RepeatFormatEnum {
	
	/** The day. */
	DAY, 
 /** The week. */
 WEEK, 
 /** The month. */
 MONTH, 
 /** The year. */
 YEAR
}
