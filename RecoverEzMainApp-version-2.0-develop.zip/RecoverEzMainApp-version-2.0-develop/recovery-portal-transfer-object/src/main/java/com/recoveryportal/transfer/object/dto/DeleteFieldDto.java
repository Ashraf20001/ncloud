package com.recoveryportal.transfer.object.dto;

import java.util.List;

import lombok.Data;

/**
 * The Class DeleteFieldDto.
 */
@Data
public class DeleteFieldDto {

	/** The section name. */
	private String sectionName;
	
	/** The field id. */
	private List<String> fieldId;

	/** The option id list. */
	private List<Integer> optionIdList;
}
