package com.recoveryportal.transfer.object.reportloss.dto;

import lombok.*;

import java.time.LocalDateTime;

import com.recoveryportal.transfer.object.vo.dto.IConfigurable;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ReportLossDto implements IConfigurable{

    //claimDetails
    private String state;
    //InsurerInfo
    private String inInsuredName;
    private String inInsurerName;
    private String inRegistrationNo;
    private String inMake;
    private String inModel;
    private LocalDateTime inPurchaseDate;
    private Double inSumInsured;
    private String dualCurrency;

    //ThirdPartyInfo
    private String tpName;
    private String tpPolicyNumber;
    private String tpClaimNo;
    private String tpRegistrationNo;
    private String tpRegistrationType;
    private String tpMake;
    private String tpModel;

    //loss details
    private LocalDateTime ldDateOfLoss;
    private String ldClaimNumber;
    private LocalDateTime ldReportedDate;
    private String ldPolicyNumber;
    private Double ldReserveAmount;
    private String ldPoliceReportNumber;
    private Boolean ldIsTotalLoss;

    //police report
    private String prDocumentUpload	;

    //garageInfo
    private String garageName;
    private String garageLocation;
    private String garageContactDetails;
    private String garageType;
    private String garageInvoiceName;

    //survey Details
   // private String sdSurveyName;
    private LocalDateTime sdSurveyAllocationDate;
    private LocalDateTime sdSurveyDueDate;
    private String sdSurveyReportName;

    //  survey report
    private Boolean srTotalLoss;
    private Double srSpareParts;
    private Double srLabourCost	;
    private Double srSurveyAmount;
    private String srSurveyReportUpload	;
    private String srSurveyName;
    //    recovery details
    private Double rdPoliceReportFee;
    private Double rdTowingCharge;
    private Double rdInspectionFee;
    private Double rdOtherExpenses;
    private Double rdCashSettlement;
    private Double rdSpareParts;
    private Double rdLabourCost;
    private Double rdTPSurveyAmount;
    private Double rdClaimAmount;

    //    reserve review
    private Double rrReserveAmount;
    private Double rrTPSurveyAmount;
    private Double rrTotalClaimAmount;

    //    garage invoice
    private String giDocument;
    private String giGarageInvoiceNo;

    //    debit note number
    private String dnDebitNoteNumber;
    private String dnDebitNoteDocument;

    //    credit note number
    private String cnCreditNoteNumber;
    private String cnCreditNoteDocument;
}
