package com.recoveryportal.transfer.object.claimSummaryDetails.entity;

import lombok.*;

import javax.persistence.*;
import java.util.Date;

/**
 * The Class ClaimSummaryDetails.
 */
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "claim_summary_details")
public class ClaimSummaryDetails {

    /** The claim summary details id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "claim_summary_details_id")
    private int claimSummaryDetailsId;
    
    /** The notification stage. */
    @Column(name = "notification_stage")
    private int notificationStage;
    
    /** The inspection stage. */
    @Column(name = "inspection_stage")
    private int inspectionStage;
    
    /** The liability confirmation stage. */
    @Column(name = "liability_confirmation_stage")
    private int liabilityConfirmationStage;
    
    /** The settlement stage. */
    @Column(name = "settlement_stage")
    private int settlementStage;
    
    /** The total payable amount. */
    @Column(name = "total_payable_amount")
    private double totalPayableAmount;
    
    /** The total receivable amount. */
    @Column(name = "total_receivable_amount")
    private double totalReceivableAmount;
    
    /** The created date. */
    @Column(name="created_date")
    private Date createdDate;
    
    /** The created by. */
    @Column(name="created_by")
    private int createdBy;
    
    /** The modified date. */
    @Column(name="modified_date")
    private Date modifiedDate;
    
    /** The modified by. */
    @Column(name="modified_by")
    private int modifiedBy;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted;

}
