package com.recoveryportal.transfer.object.models;


import java.util.Date;

/**
 * The Class BarChartModelTemp.
 */
public class BarChartModelTemp {
    
    /** The receivable. */
    private double receivable;
    
    /** The payable. */
    private double payable;
    
    /** The label. */
    private Date label;
    
    /** The receivable amount. */
    private double receivableAmount;
    
    /** The payable amount. */
    private double payableAmount;

    /**
     * Instantiates a new bar chart model temp.
     */
    public BarChartModelTemp() {
    }

    /**
     * Instantiates a new bar chart model temp.
     *
     * @param receivable the receivable
     * @param payable the payable
     * @param label the label
     * @param receivableAmount the receivable amount
     * @param payableAmount the payable amount
     */
    public BarChartModelTemp(double receivable, double payable, Date label, double receivableAmount, double payableAmount) {
        this.receivable = receivable;
        this.payable = payable;
        this.label = label;
        this.receivableAmount = receivableAmount;
        this.payableAmount = payableAmount;
    }

    /**
     * Gets the receivable.
     *
     * @return the receivable
     */
    public double getReceivable() {
        return receivable;
    }

    /**
     * Sets the receivable.
     *
     * @param receivable the new receivable
     */
    public void setReceivable(double receivable) {
        this.receivable = receivable;
    }

    /**
     * Gets the payable.
     *
     * @return the payable
     */
    public double getPayable() {
        return payable;
    }

    /**
     * Sets the payable.
     *
     * @param payable the new payable
     */
    public void setPayable(double payable) {
        this.payable = payable;
    }

    /**
     * Gets the label.
     *
     * @return the label
     */
    public Date getLabel() {
        return label;
    }

    /**
     * Sets the label.
     *
     * @param label the new label
     */
    public void setLabel(Date label) {
        this.label = label;
    }

    /**
     * Gets the receivable amount.
     *
     * @return the receivable amount
     */
    public double getReceivableAmount() {
        return receivableAmount;
    }

    /**
     * Sets the receivable amount.
     *
     * @param receivableAmount the new receivable amount
     */
    public void setReceivableAmount(double receivableAmount) {
        this.receivableAmount = receivableAmount;
    }

    /**
     * Gets the payable amount.
     *
     * @return the payable amount
     */
    public double getPayableAmount() {
        return payableAmount;
    }

    /**
     * Sets the payable amount.
     *
     * @param payableAmount the new payable amount
     */
    public void setPayableAmount(double payableAmount) {
        this.payableAmount = payableAmount;
    }
}
