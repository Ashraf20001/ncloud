package com.recoveryportal.transfer.object.dto;

import java.util.HashMap;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class PayReportDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PayReportDto {
	
	/** The total claim amount. */
	private Double totalClaimAmount;
	
	/** The company amount map. */
	private HashMap<String,Double> companyAmountMap;
	
	/** The currency type. */
	private String currencyType;

}
