package com.recoveryportal.transfer.object.vo.dto;

import com.recoveryportal.transfer.object.dto.DropDownListDto;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The Class Field.
 */
@Data
@NoArgsConstructor
public class Field {
	
	/** The field id. */
	private String fieldId;
	
	/** The field name. */
	private String fieldName;
	
	/** The field type. */
	private String fieldType;	
	
	/** The field default. */
	private String fieldDefault;
    
    /** The alias name. */
    private String aliasName;
    
    /** The mandatory. */
    private Boolean mandatory;
    
    /** The is core data. */
    private Boolean isCoreData;
    
    /** The reference id. */
    private Integer referenceId;
    
    /** The is system generated. */
    private Boolean isSystemGenerated;
    
    /** The drop down list. */
    private List<DropDownListDto> dropDownList;
    
    /** The order by. */
    private Integer orderBy;
	
}
