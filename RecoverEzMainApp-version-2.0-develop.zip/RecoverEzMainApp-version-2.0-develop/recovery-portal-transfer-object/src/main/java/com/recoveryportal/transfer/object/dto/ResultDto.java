package com.recoveryportal.transfer.object.dto;

import java.io.Serializable;
import java.util.HashMap;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.recoveryportal.constants.enums.ResultCodeEnum;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ResultDto.
 *
 * @param <T> the generic type
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResultDto<T> implements Serializable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The success. */
	private boolean success;

	/** The code. */
	private String code;

	/** The msg. */
	private String msg;

	/** The error msg. */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String errorMsg;

	/** The data. */
	private T data;

	/**
	 * Success.
	 *
	 * @return the result dto
	 */
	public static ResultDto success() {
		return ResultDto.success(null);
	}

	/**
	 * Failure.
	 *
	 * @param resultCodeEnum the result code enum
	 * @return the result dto
	 */
	public static ResultDto failure(ResultCodeEnum resultCodeEnum) {
		return ResultDto.failure(resultCodeEnum.getCode(), resultCodeEnum.getMsg());
	}

	/**
	 * Failure.
	 *
	 * @param resultCodeEnum the result code enum
	 * @param errorMsg the error msg
	 * @return the result dto
	 */
	public static ResultDto failure(ResultCodeEnum resultCodeEnum, String errorMsg) {
		return ResultDto.failure(resultCodeEnum.getCode(), resultCodeEnum.getMsg(), errorMsg);
	}

	/**
	 * Failure.
	 *
	 * @param code the code
	 * @param msg the msg
	 * @return the result dto
	 */
	public static ResultDto failure(String code, String msg) {
		return ResultDto.failure(code, msg, null);
	}

	/**
	 * Failure.
	 *
	 * @param e the e
	 * @param resultCodeEnum the result code enum
	 * @return the result dto
	 */
	public static ResultDto failure(Throwable e, ResultCodeEnum resultCodeEnum) {
		return failure(e, resultCodeEnum.getCode(), resultCodeEnum.getMsg(), e.getMessage());
	}

	/**
	 * Failure.
	 *
	 * @param code the code
	 * @param msg the msg
	 * @param errorMsg the error msg
	 * @return the result dto
	 */
	public static ResultDto failure(String code, String msg, String errorMsg) {
		return failure(null, code, msg, errorMsg);
	}

	/**
	 * Failure.
	 *
	 * @param <T> the generic type
	 * @param obj the obj
	 * @param code the code
	 * @param msg the msg
	 * @return the result dto
	 */
	public static <T> ResultDto failure(T obj, String code, String msg) {
		return failure(obj, code, msg, null);
	}

	/**
	 * Success.
	 *
	 * @param <T> the generic type
	 * @param obj the obj
	 * @return the result dto
	 */
	public static <T> ResultDto success(T obj) {
		ResultDto result = new ResultDto();
		result.setSuccess(true);
		result.setCode(ResultCodeEnum.OK.getCode());
		result.setMsg(ResultCodeEnum.OK.getMsg());
		if (obj == null) {
			result.setData(new HashMap<>(1));
		} else {
			result.setData(obj);
		}
		return result;
	}

	/**
	 * Failure.
	 *
	 * @param <T> the generic type
	 * @param obj the obj
	 * @param code the code
	 * @param msg the msg
	 * @param errorMsg the error msg
	 * @return the result dto
	 */
	public static <T> ResultDto failure(T obj, String code, String msg, String errorMsg) {
		ResultDto result = new ResultDto();
		result.setData(obj);
		result.setCode(code);
		result.setSuccess(false);
		result.setMsg(msg);
		result.setErrorMsg(errorMsg);
		return result;
	}

}
