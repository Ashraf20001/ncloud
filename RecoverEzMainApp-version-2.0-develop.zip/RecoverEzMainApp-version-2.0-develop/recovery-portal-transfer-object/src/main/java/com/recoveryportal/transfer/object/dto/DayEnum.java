package com.recoveryportal.transfer.object.dto;

/**
 * The Enum DayEnum.
 */
public enum DayEnum {
	
	/** The sun. */
	SUN, 
 /** The mon. */
 MON, 
 /** The tue. */
 TUE, 
 /** The wed. */
 WED, 
 /** The thu. */
 THU, 
 /** The fri. */
 FRI, 
 /** The sat. */
 SAT
}
