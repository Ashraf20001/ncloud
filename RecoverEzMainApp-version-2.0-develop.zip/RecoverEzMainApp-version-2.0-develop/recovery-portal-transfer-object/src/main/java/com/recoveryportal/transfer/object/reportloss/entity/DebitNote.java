package com.recoveryportal.transfer.object.reportloss.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.envers.Audited;

import com.recoveryportal.transfer.object.entity.Auditable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class DebitNote.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rl_debit_note")
@Audited
public class DebitNote extends Auditable implements Serializable{

    /** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1093463482434856134L;

	/** The debit note id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "debit_note_id")
    private int debitNoteId;

    /** The debit note number. */
    @Column(name = "debit_note_number")
    private String debitNoteNumber;
    
    /** The debit note document. */
    @Column(name = "debit_note_document")
    private String debitNoteDocument;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;
    
    /** The debit note sequence id. */
    @Column(name="debit_note_sequenceId")
    private String debitNoteSequenceId;
    
}
