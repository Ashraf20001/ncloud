package com.recoveryportal.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserRoleManagementViewDTO.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserRoleManagementViewDTO {
	
	/** The is insurence company admin. */
	private Boolean isInsurenceCompanyAdmin;
    
    /** The is active. */
    private Boolean isActive =true;
    
    /** The role details. */
    private MetaDataViewDto roleDetails;
    
    /** The access mapping. */
    private AccessMappingDto accessMapping;
}
