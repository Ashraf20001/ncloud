package com.recoveryportal.transfer.object.dto;

import com.recoveryportal.transfer.object.vo.dto.IConfigurable;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class GarageDto.
 */
@Data
@NoArgsConstructor
public class GarageDto implements IConfigurable{
	
	/** The em garage id. */
	private String emGarageId;
	
	/** The em garage short id. */
	private String emGarageShortId;
	
	/** The em garage name. */
	private String emGarageName;
	
	/** The em garage email. */
	private String emGarageEmail;
	
	/** The em garage location. */
	private String emGarageLocation;
	
	/** The em garage address. */
	private String emGarageAddress;
	
	/** The em garage password. */
	private String emGaragePassword;
	
	/** The em garage user id. */
	private String emGarageUserId;
	
	/** The em garage logo. */
	private String emGarageLogo;
	
	/** The em garage phone. */
	private String emGaragePhone;
	
	/** The em garage is active. */
	private Boolean emGarageIsActive=true;
	
	/** The em garage identity. */
	private String emGarageIdentity;
	
	/** The is disable garage. */
	private Boolean  isDisableGarage;
}
