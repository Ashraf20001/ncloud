package com.recoveryportal.transfer.object.dto;

import lombok.Data;

/**
 * The Class StageDetailsDto.
 */
@Data
public class StageDetailsDto {
	
	/** The section id. */
	private String sectionId;
	
	/** The section name. */
	private String sectionName;	
	
	/** The is enabled. */
	private Boolean isEnabled;
}
