package com.recoveryportal.transfer.object.reportloss.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.envers.Audited;

import com.recoveryportal.transfer.object.entity.Auditable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class LossDetails.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rl_loss_details")
@Audited
public class LossDetails extends Auditable implements Serializable{

    /** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7877741063576519440L;

	/** The loss details id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "loss_details_id")
    private int lossDetailsId;

    /** The date of loss. */
    @Column(name = "date_of_loss")
    private LocalDateTime dateOfLoss;

    /** The claim number. */
    @Column(name = "claim_number")
    private String claimNumber;
    
    /** The reported date. */
    @Column(name = "reported_date")
    private LocalDateTime reportedDate;
    
    /** The policy number. */
    @Column(name = "policy_number")
    private String policyNumber;
    
    /** The reserve amount. */
    @Column(name = "reserve_amount")
    private Double reserveAmount;
    
    /** The police report number. */
    @Column(name = "police_report_number")
    private String policeReportNumber;
    
    /** The is total loss. */
    @Column(name = "is_total_loss")
    private boolean isTotalLoss;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;
}
