package com.recoveryportal.transfer.object.claimSummaryDetails.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class ClaimSummaryDetailsDto.
 */
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ClaimSummaryDetailsDto {
    
    /** The claim summary details id. */
    private int claimSummaryDetailsId;
    
    /** The notification stage. */
    private int notificationStage;
    
    /** The inspection stage. */
    private int inspectionStage;
    
    /** The liability confirmation stage. */
    private int liabilityConfirmationStage;
    
    /** The settlement stage. */
    private int settlementStage;
    
    /** The total payable amount. */
    private double totalPayableAmount;
    
    /** The total receivable amount. */
    private double totalReceivableAmount;
}
