package com.recoveryportal.transfer.object.dto;

import com.recoveryportal.transfer.object.vo.dto.IConfigurable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserRoleMgmtViewDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserRoleMgmtViewDto implements IConfigurable {
    
    /** The um role id. */
    //roleDetails
    private Integer umRoleId;
    
    /** The um role name. */
    private String umRoleName;
    
    /** The um description. */
    private String umDescription;
}
