package com.recoveryportal.transfer.object.vo.dto;

import java.util.Date;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class VehicleDetailsDto.
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class VehicleDetailsDto implements IConfigurable {
	
	/** The vehicle detail id. */
	private long vehicleDetailId;
	
	/** The registration no. */
	private String registrationNo;
	
	/** The model. */
	private String model;
	
	/** The make. */
	private String make;
	
	/** The registration type. */
	private String registrationType;
	
	/** The purchase date. */
	private Date purchaseDate;
	
	/** The sum insured. */
	private long sumInsured;

}
