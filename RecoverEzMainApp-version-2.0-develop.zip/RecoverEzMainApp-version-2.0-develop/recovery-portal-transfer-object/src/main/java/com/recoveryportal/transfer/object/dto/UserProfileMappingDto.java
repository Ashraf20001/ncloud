package com.recoveryportal.transfer.object.dto;

import lombok.Data;

/**
 * The Class UserProfileMappingDto.
 */
@Data
public class UserProfileMappingDto {
    
    /** The user profile. */
    private UserDto userProfile;
    
    /** The role. */
    private RoleDto role;
}
