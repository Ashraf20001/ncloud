package com.recoveryportal.transfer.object.dto;

import java.util.List;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class EmailForPaymentDetailsDto.
 */
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EmailForPaymentDetailsDto {
	
	/** The at fault company. */
	private String atFaultCompany;
	
	/** The not at fault company. */
	private String notAtFaultCompany;
	
	/** The report id. */
	private Integer reportId;
	
	/** The to date. */
	private String toDate;
	
	/** The from date. */
	private String fromDate;
	
	/** The amount. */
	private String amount;
	
	/** The email. */
	private String email;
	
	/** The association name. */
	private String associationName;
	
	/** The reference id. */
	private Integer referenceId;
	
	/** The not at falt company list. */
	private List<CompanyDto> notAtFaltCompanyList;
	
	/** The auto generate pdf. */
	private Integer autoGeneratePdf;
}
