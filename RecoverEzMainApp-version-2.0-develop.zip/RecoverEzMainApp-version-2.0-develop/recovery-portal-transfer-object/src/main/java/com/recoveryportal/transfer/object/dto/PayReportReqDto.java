package com.recoveryportal.transfer.object.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class PayReportReqDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PayReportReqDto {
	
	/** The from company. */
	private String fromCompany;
	
	/** The from date. */
	private String fromDate;
	
	/** The to date. */
	private String toDate;
	
	/** The insured companies. */
	private List<String> insuredCompanies;
	
	/** The payment id. */
	private Integer paymentId;
	
	/** The report id. */
	private Integer reportId;
	
	/** The currency type. */
	private String currencyType;

}
