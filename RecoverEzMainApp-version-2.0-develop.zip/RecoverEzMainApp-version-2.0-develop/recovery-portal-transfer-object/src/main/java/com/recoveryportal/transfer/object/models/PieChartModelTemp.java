package com.recoveryportal.transfer.object.models;

/**
 * The Class PieChartModelTemp.
 */
public class PieChartModelTemp {
    
    /** The notification. */
    private int notification;
    
    /** The accidents. */
    private int accidents;
    
    /** The settlement. */
    private int settlement;
    
    /** The pending. */
    private int pending;

    /**
     * Instantiates a new pie chart model temp.
     */
    public PieChartModelTemp() {
    }

    /**
     * Instantiates a new pie chart model temp.
     *
     * @param notification the notification
     * @param accidents the accidents
     * @param settlement the settlement
     * @param pending the pending
     */
    public PieChartModelTemp(int notification, int accidents, int settlement, int pending) {
        this.notification = notification;
        this.accidents = accidents;
        this.settlement = settlement;
        this.pending = pending;
    }

    /**
     * Gets the notification.
     *
     * @return the notification
     */
    public int getNotification() {
        return notification;
    }

    /**
     * Sets the notification.
     *
     * @param notification the new notification
     */
    public void setNotification(int notification) {
        this.notification = notification;
    }

    /**
     * Gets the accidents.
     *
     * @return the accidents
     */
    public int getAccidents() {
        return accidents;
    }

    /**
     * Sets the accidents.
     *
     * @param accidents the new accidents
     */
    public void setAccidents(int accidents) {
        this.accidents = accidents;
    }

    /**
     * Gets the settlement.
     *
     * @return the settlement
     */
    public int getSettlement() {
        return settlement;
    }

    /**
     * Sets the settlement.
     *
     * @param settlement the new settlement
     */
    public void setSettlement(int settlement) {
        this.settlement = settlement;
    }

    /**
     * Gets the pending.
     *
     * @return the pending
     */
    public int getPending() {
        return pending;
    }

    /**
     * Sets the pending.
     *
     * @param pending the new pending
     */
    public void setPending(int pending) {
        this.pending = pending;
    }
}
