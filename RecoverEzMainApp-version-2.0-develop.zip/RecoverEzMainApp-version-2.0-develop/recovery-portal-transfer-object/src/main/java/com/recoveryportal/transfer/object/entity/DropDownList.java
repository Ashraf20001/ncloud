package com.recoveryportal.transfer.object.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class DropDownList.
 */
@Entity
@Table(name = "dropdownlist")
@Data
@NoArgsConstructor
public class DropDownList {
	
	/** The dropdown list id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="dropdownListId")
	private Integer dropdownListId;
	
	/** The drop down name. */
	@Column(name="name")
	private String dropDownName;
	
	/** The drop down type. */
	@Column(name="type")
	private Integer dropDownType;
	
	/** The reference table. */
	@Column(name="referenceTable")
	private String referenceTable;
	
	/** The reference column id. */
	@Column(name="referenceColumnId")
	private String referenceColumnId;
	
	/** The display column name. */
	@Column(name="displayColumnName")
	private String displayColumnName;
	
	/** The is deleted. */
	@Column(name="is_deleted")
	private Boolean isDeleted;
	
	/** The identity. */
	@Column(name="identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private String identity;

	/** The created date. */
	@Column(name="created_date")
	private Date createdDate;

	/** The created by. */
	@Column(name="created_by")
	private int createdBy;
	
	/** The modified date. */
	@Column(name="modified_date")
	private Date modifiedDate;

	/** The modified by. */
	@Column(name="modified_by")
	private int modifiedBy;
	
}
