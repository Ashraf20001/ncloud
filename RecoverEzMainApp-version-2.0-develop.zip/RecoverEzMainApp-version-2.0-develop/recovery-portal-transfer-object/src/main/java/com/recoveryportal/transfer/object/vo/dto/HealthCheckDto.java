package com.recoveryportal.transfer.object.vo.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class HealthCheckDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class HealthCheckDto {

	/** The service name. */
	private String serviceName;
	
	/** The host. */
	private String host;
	
	/** The port. */
	private Integer port;
	
	/** The status. */
	private String status;
	
}
