package com.recoveryportal.transfer.object.reportloss.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.envers.Audited;

import com.recoveryportal.transfer.object.entity.Auditable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SurveyReport.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rl_survey_report")
@Audited
public class SurveyReport extends Auditable implements Serializable{
    
    /** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4852752624634928826L;

	/** The survey report id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "survey_report_id")
    private int surveyReportId;

    /** The is total loss. */
    @Column(name = "is_total_loss")
    private boolean isTotalLoss;
    
    /** The spare parts. */
    @Column(name = "spare_parts")
    private Double spareParts;
    
    /** The labour cost. */
    @Column(name = "labour_cost")
    private Double labourCost;
    
    /** The survey amount. */
    @Column(name = "survey_amount")
    private Double surveyAmount;
    
    /** The survey report upload. */
    @Column(name = "survey_report_upload")
    private String surveyReportUpload;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;
    
    /** The survey name. */
    @Column(name = "survey_name")
    private String surveyName;
}
