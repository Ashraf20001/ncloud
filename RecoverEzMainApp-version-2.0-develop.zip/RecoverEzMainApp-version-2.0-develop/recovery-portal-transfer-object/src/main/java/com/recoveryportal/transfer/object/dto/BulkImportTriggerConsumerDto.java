package com.recoveryportal.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BulkImportTriggerConsumerDto.
 */
@Data
@NoArgsConstructor
public class BulkImportTriggerConsumerDto {
    
    /** The bulk import history dto. */
    private BulkImportHistoryDto bulkImportHistoryDto;
    
    /** The page identity. */
    private String pageIdentity;
    
    /** The insurer. */
    private String insurer;
    
    /** The user id. */
    private Integer userId;
}
