package com.recoveryportal.transfer.object.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class Section.
 */
@Entity
@Table(name = "section")
@Data
@NoArgsConstructor
public class Section {
	
	/** The section id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="section_id")
	private int sectionId;
	
	/** The section name. */
	@Column(name="section_name")
	private String sectionName;
	
	/** The section details. */
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn (name="parent_section")
	private Section sectionDetails;

	/** The association details. */
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="association")
	private Association associationDetails;

	/** The page id. */
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="page_id")
	private Page pageId;

	/** The is deleted. */
	@Column(name="is_deleted")
	private boolean isDeleted;
	
	/** The is enabled. */
	@Column(name="is_enb_sts")
	private Boolean isEnabled;
	
	/** The identity. */
	@Column(name="identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;

	/** The created date. */
	@Column(name="created_date")
	private Date createdDate;

	/** The created by. */
	@Column(name="created_by")
	private int createdBy;
	
	/** The modified date. */
	@Column(name="modified_date")
	private Date modifiedDate;

	/** The modified by. */
	@Column(name="modified_by")
	private int modifiedBy;
	
	/** The order by. */
	@Column(name="order_by")
	private Integer orderBy;

	/**
	 * Instantiates a new section.
	 *
	 * @param sectionId the section id
	 */
	public Section(Integer sectionId){
		this.sectionId=sectionId;
	}

}
