package com.recoveryportal.transfer.object.reportloss.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class NextStatusEntity.
 */
@Entity
@Table(name="rp_next_status")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class NextStatusEntity {

    /** The rp next status id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "rp_next_status_id")
    private Long rpNextStatusId;

    /** The current status. */
    @Column(name = "current_status")
    private String currentStatus;

    /** The action. */
    @Column(name = "action")
    private String action;

    /** The is receivable. */
    @Column(name = "is_receivable")
    private Boolean isReceivable;

    /** The last status. */
    @Column(name = "last_status")
    private String lastStatus;

    /** The total loss type. */
    @Column(name = "total_loss_type")
    private String totalLossType;
    
    /** The garage survery status. */
    @Column(name = "garage_survery_status")
    private String garageSurveryStatus;
    
    /** The next status. */
    @Column(name = "next_status")
    private String nextStatus;

    /** The is deleted. */
    @Column(name = "is_deleted")
    private Boolean isDeleted;

    /** The identity. */
    @Column(name = "identity")
    private String identity;
    
}
