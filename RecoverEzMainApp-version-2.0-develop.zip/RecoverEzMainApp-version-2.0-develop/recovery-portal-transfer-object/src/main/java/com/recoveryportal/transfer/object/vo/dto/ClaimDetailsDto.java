package com.recoveryportal.transfer.object.vo.dto;

import java.util.Date;
import java.util.Set;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class ClaimDetailsDto.
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ClaimDetailsDto implements IConfigurable{
	
	/** The fnol no. */
	private String fnolNo;
	
	/** The claim ref no. */
	private String claimRefNo;
	
	/** The recovery letter. */
	private Boolean recoveryLetter;
	
	/** The date ofloss. */
	private Date dateOfloss;
	
	/** The date of reported. */
	private Date dateOfReported;
	
	/** The police report no. */
	private String policeReportNo;
	
	/** The insured claim no. */
	private String insuredClaimNo;
	
	/** The third party claim no. */
	private String thirdPartyClaimNo;
	
	/** The insured info. */
	private InsuredInfoDto insuredInfo;
	
	/** The party info. */
	private ThirdPartyInfoDto partyInfo;
	
	/** The garage info. */
	private GarageInfoDto garageInfo;
	
	/** The documents. */
	private Set<DocumentsDto> documents;
	
	/** The status. */
	private String status;
	
	/** The user comment. */
	private UserCommentDto userComment;
	
	/** The nature of loss. */
	private String natureOfLoss;
	
	/** The reserve amount. */
	private long reserveAmount;
	
	/** The total reserve amount. */
	private long totalReserveAmount;
	
	/** The third party reserve amount. */
	private long thirdPartyReserveAmount;
	
	/** The estimated total loss amount. */
	private long estimatedTotalLossAmount;
	
	/** The survey estimated amount. */
	private long surveyEstimatedAmount;
	
	/** The claim amount. */
	private long claimAmount;
	
	/** The settle amount. */
	private long settleAmount;
	
	/** The third party settle amount. */
	private long thirdPartySettleAmount;

}
