package com.recoveryportal.transfer.object.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class MetaData.
 */
@Entity
@Table(name = "meta_data")
@Data
@NoArgsConstructor
public class MetaData {
	
	/** The meta data id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="meta_data_id")
	private int metaDataId;
	
	/** The page details. */
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="page_id")
	private Page pageDetails;
	
	/** The section details. */
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="section_id")
	private Section sectionDetails;
	
	/** The field details. */
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="field_id")
	private Field fieldDetails;
	
	/** The entity. */
	@Column(name="entity")
	private String entity;

	/** The column. */
	@Column (name="column_name")
	private String column;

	/** The is deleted. */
	@Column(name="is_deleted")
	private boolean isDeleted;

	/** The identity. */
	@Column(name="identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;

	/** The created date. */
	@Column(name="created_date")
	private Date createdDate;

	/** The created by. */
	@Column(name="created_by")
	private int createdBy;
	
	/** The modified date. */
	@Column(name="modified_date")
	private Date modifiedDate;

	/** The modified by. */
	@Column(name="modified_by")
	private int modifiedBy;
	
	/** The order by. */
	@Column(name="order_by")
	private Integer orderBy;

}
