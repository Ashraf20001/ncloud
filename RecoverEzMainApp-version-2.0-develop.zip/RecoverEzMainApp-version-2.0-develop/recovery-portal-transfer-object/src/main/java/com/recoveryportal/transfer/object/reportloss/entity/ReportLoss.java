package com.recoveryportal.transfer.object.reportloss.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import com.recoveryportal.transfer.object.entity.Auditable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * The Class ReportLoss.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "report_loss")
@Audited
public class ReportLoss extends Auditable implements Serializable {
   

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -6952030142217673890L;

	/** The claim id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "claim_id")
    private Integer claimId;
   
    /** The comments. */
    @OneToMany(mappedBy="claimId",cascade=CascadeType.ALL, fetch = FetchType.LAZY)
    @NotAudited
    private List<Comments> comments;
    
    /** The insured info. */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "insured_info")
    @NotAudited
    private InsuredInfo insuredInfo;
    
    /** The third party info. */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "third_party_info")
    @NotAudited
    private ThirdPartyInfo thirdPartyInfo;
    
    /** The loss details. */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "loss_details")
    @NotAudited
    private LossDetails lossDetails;
    
    /** The police report. */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "police_report")
    @NotAudited
    private PoliceReport policeReport;
    
    /** The garage info. */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "garage_info")
    @NotAudited
    private GarageInfo garageInfo;
    
    /** The survey details. */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "survey_details")
    @NotAudited
    private SurveyDetails surveyDetails;
    
    /** The survey report. */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "survey_report")
    @NotAudited
    private SurveyReport surveyReport;
    
    /** The recovery details. */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "recovery_details")
    @NotAudited
    private RecoveryDetails recoveryDetails;
    
    /** The reserve review. */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "reserve_review")
    @NotAudited
    private ReserveReview reserveReview;
    
    /** The garage invoice. */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "garage_invoice")
    @NotAudited
    private GarageInvoice garageInvoice;
    
    /** The debit note. */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "debit_note")
    @NotAudited
    private DebitNote debitNote;
    
    /** The credit note. */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "credit_note")
    @NotAudited
    private CreditNote creditNote;
    
    /** The state. */
    @Column(name = "state")
    private String state;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private Boolean isDeleted = false;

     /** The last status. */
     @Column(name = "lastStatus")
    private String lastStatus;
     
     /** The claim sequence id. */
     @Column(name="claim_sequence_id")
     private String claimSequenceId;
     
     /** The stage name. */
     @Column(name="stage_name")
     private String stageName;
     
     /** The section name. */
     @Column(name="section_name")
     private String sectionName;
}