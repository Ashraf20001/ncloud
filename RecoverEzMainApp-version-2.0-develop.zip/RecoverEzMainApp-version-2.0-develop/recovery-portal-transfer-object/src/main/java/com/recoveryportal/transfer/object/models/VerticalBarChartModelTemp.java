package com.recoveryportal.transfer.object.models;

/**
 * The Class VerticalBarChartModelTemp.
 */
public class VerticalBarChartModelTemp {

    /** The receivable claim. */
    private long receivableClaim;
    
    /** The days. */
    private int days;

    /**
     * Instantiates a new vertical bar chart model temp.
     */
    public VerticalBarChartModelTemp() {
    }

    /**
     * Instantiates a new vertical bar chart model temp.
     *
     * @param receivableClaim the receivable claim
     * @param days the days
     */
    public VerticalBarChartModelTemp(long receivableClaim, int days) {
        this.receivableClaim = receivableClaim;
        this.days = days;
    }

    /**
     * Gets the receivable claim.
     *
     * @return the receivable claim
     */
    public long getReceivableClaim() {
        return receivableClaim;
    }

    /**
     * Sets the receivable claim.
     *
     * @param receivableClaim the new receivable claim
     */
    public void setReceivableClaim(long receivableClaim) {
        this.receivableClaim = receivableClaim;
    }

    /**
     * Gets the days.
     *
     * @return the days
     */
    public int getDays() {
        return days;
    }

    /**
     * Sets the days.
     *
     * @param days the new days
     */
    public void setDays(int days) {
        this.days = days;
    }
}
