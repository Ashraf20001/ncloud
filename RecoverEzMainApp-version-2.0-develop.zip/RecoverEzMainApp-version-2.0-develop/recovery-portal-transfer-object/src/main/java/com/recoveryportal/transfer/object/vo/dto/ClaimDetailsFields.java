package com.recoveryportal.transfer.object.vo.dto;

import java.util.Date;


import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ClaimDetailsFields.
 */
@Data
@NoArgsConstructor
public class ClaimDetailsFields implements IConfigurable{
	
	/** The fnol no. */
	//claimDetails
	private String fnolNo;
	
	/** The claim ref no. */
	private String claimRefNo;
	
	/** The recovery letter. */
	private Boolean recoveryLetter;
	
	/** The date ofloss. */
	private Date dateOfloss;
	
	/** The date of reported. */
	private Date dateOfReported;
	
	/** The police report no. */
	private String policeReportNo;
	
	/** The insured claim no. */
	private String insuredClaimNo;
	
	/** The third party claim no. */
	private String thirdPartyClaimNo;
	
	/** The status. */
	private String status;
	
	/** The nature of loss. */
	private String natureOfLoss;
	
	/** The reserve amount. */
	private long reserveAmount;
	
	/** The total reserve amount. */
	private long totalReserveAmount;
	
	/** The third party reserve amount. */
	private long thirdPartyReserveAmount;
	
	/** The estimated total loss amount. */
	private long estimatedTotalLossAmount;
	
	/** The survey estimated amount. */
	private long surveyEstimatedAmount;
	
	/** The claim amount. */
	private long claimAmount;
	
	/** The settle amount. */
	private long settleAmount;
	
	/** The third party settle amount. */
	private long thirdPartySettleAmount;
	
	/** The in policy number. */
	//InsurerInfo
	private String inPolicyNumber;
	
	/** The in name. */
	private String inName;
	
	/** The in short name. */
	private String inShortName;
	
	/** The in registration no. */
	private String inRegistrationNo;
	
	/** The in model. */
	private String inModel;
	
	/** The in make. */
	private String inMake;
	
	/** The in registration type. */
	private String inRegistrationType;
	
	/** The in purchase date. */
	private Date inPurchaseDate;
	
	/** The in sum insured. */
	private long inSumInsured;
	
	/** The tp policy number. */
	//ThirdPartyInfo
	private String tpPolicyNumber;
	
	/** The tp registration no. */
	private String tpRegistrationNo;
	
	/** The tp model. */
	private String tpModel;
	
	/** The tp make. */
	private String tpMake;
	
	/** The tp registration type. */
	private String tpRegistrationType;
	
	/** The tp purchase date. */
	private Date tpPurchaseDate;
	
	/** The tp sum insured. */
	private long tpSumInsured;
	
	/** The tp name. */
	private String tpName;
	
	/** The tp short name. */
	private String tpShortName;
	
	/** The garage fnol no. */
	//garageInfo
	private String garageFnolNo;
	
	/** The garage claim no. */
	private String garageClaimNo;
	
	/** The garage name. */
	private String garageName;
	
	/** The garage type. */
	private TypeOfAgency garageType;
	
	/** The garage adress location. */
	private String garageAdressLocation;
	
	/** The garage survey allocation date. */
	private Date garageSurveyAllocationDate;
	
	/** The garage survey due date. */
	private Date garageSurveyDueDate;
	
	/** The garage contact name. */
	private String garageContactName;
	
	/** The garage contact phone. */
	private String garageContactPhone;
	
	/** The garage email adress. */
	private String garageEmailAdress;
	
	/** The uc reason. */
	//userComment
	private String ucReason;
	
	/** The uc last comment. */
	private String ucLastComment;
	
}
