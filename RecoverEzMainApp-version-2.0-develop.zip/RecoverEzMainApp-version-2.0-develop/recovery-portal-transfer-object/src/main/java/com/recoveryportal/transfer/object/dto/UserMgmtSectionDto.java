package com.recoveryportal.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserMgmtSectionDto.
 */
@Data
@NoArgsConstructor
public class UserMgmtSectionDto {
    
    /** The section id. */
    private Integer sectionId;
    
    /** The section name. */
    private String sectionName;
    
    /** The section details. */
    private Integer sectionDetails;
    
    /** The page id. */
    private Integer pageId;

}
