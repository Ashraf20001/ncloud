package com.recoveryportal.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The Class AccessMappingPageDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccessMappingPageDto {
    
    /** The page id. */
    private Integer pageId;
    
    /** The page name. */
    private String pageName;
    
    /** The display name. */
    private String displayName;
    
    /** The menu id. */
    private Integer menuId;
    
    /** The is enabled. */
    private Boolean isEnabled = true;
    
    /** The section data. */
    private List<AccessMappingSectionDto> sectionData;
    
    /** The privilege data. */
    private List<AccessMappingPrivilegeDto> privilegeData;
}
