package com.recoveryportal.transfer.object.chart;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BarChartFilterDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BarChartFilterDto {
    
    /** The month. */
    private String month;
    
    /** The receivable. */
    private Object receivable;
    
    /** The payable. */
    private Object payable;
}
