package com.recoveryportal.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserRoleDetailsDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserRoleDetailsDto {
    
    /** The role id. */
    private String roleId;
    
    /** The role name. */
    private String roleName;
    
    /** The description. */
    private String description;
}
