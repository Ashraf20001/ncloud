package com.recoveryportal.transfer.object.reportloss.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.recoveryportal.transfer.object.entity.Field;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FieldOptionMapping.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "field_option_mapping")
public class FieldOptionMapping {

    /** The field option mapping id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "field_option_mapping_id")
    private int fieldOptionMappingId;
    
    /** The field. */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "field")
    private Field field;
    
    /** The dropdown options. */
    @OneToOne( cascade= CascadeType.ALL)
    @JoinColumn(name = "dropdown_options")
    private DropdownOptions dropdownOptions;

    /** The created date. */
    @Column(name="created_date")
    private Date createdDate;

    /** The created by. */
    @Column(name="created_by")
    private int createdBy;

    /** The modified date. */
    @Column(name="modified_date")
    private Date modifiedDate;

    /** The modified by. */
    @Column(name="modified_by")
    private int modifiedBy;

    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;

    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;
}
