package com.recoveryportal.transfer.object.dto;

import com.recoveryportal.transfer.object.entity.FileStorageDetails;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * The Class BulkImportHistoryDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BulkImportHistoryDto {

    /** The upload id. */
    private Integer uploadId;
    
    /** The success count. */
    private Integer successCount=0;
    
    /** The failure count. */
    private Integer failureCount=0;
    
    /** The total count. */
    private Integer totalCount=0;
    
    /** The status. */
    private String status;
    
    /** The page id. */
    private Integer pageId;
    
    /** The file name. */
    private String fileName;
    
    /** The created by. */
    private String createdBy;
    
    /** The created date. */
    private String createdDate;
    
    /** The identity. */
    private String identity;
}
