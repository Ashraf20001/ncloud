package com.recoveryportal.transfer.object.dto;

import java.util.List;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 * The Class PushNotificationDto.
 */
@Data
@Getter
@Setter
public class PushNotificationDto {

	/** The company id. */
	private Integer companyId;
	
	/** The report loss details. */
	private List<Integer> reportLossDetails;
}
