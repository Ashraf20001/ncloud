package com.recoveryportal.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class EntityManagementViewDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EntityManagementViewDto {
	
	/** The meta data page dto. */
	private MetaDataPageDto metaDataPageDto;
	
	/** The enable notification dto. */
	private EnableNotificationDto enableNotificationDto;
}
