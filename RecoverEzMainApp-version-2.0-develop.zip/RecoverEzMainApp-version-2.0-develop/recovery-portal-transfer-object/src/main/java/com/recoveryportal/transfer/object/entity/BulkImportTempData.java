package com.recoveryportal.transfer.object.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class BulkImportTempData.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="report_loss_upload_data")
@Audited
public class BulkImportTempData extends Auditable implements Serializable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1987810859149360036L;

	/** The upload data id. */
	//claimDetails
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "upload_data_id")
    private Integer uploadDataId;

	/** The upload id. */
	@Column(name = "upload_id")
    private Integer uploadId;

	/** The status. */
	@Column(name = "status")
    private Boolean status;

	/** The error description. */
	@Column(name = "errordescription")
    private String errorDescription;


    /** The in registration no. */
    //InsurerInfo
	@Column(name = "in_registration_no")
    private String inRegistrationNo;

	/** The in make. */
	@Column(name = "in_make")
    private String inMake;

	/** The in model. */
	@Column(name = "in_model")
    private String inModel;

	/** The in purchase date. */
	@Column(name = "in_purchase_date")
    private String inPurchaseDate;

	/** The in sum insured. */
	@Column(name = "in_sum_insured")
    private String inSumInsured;

    //ThirdPartyInfo

	/** The tp name. */
    @Column(name = "tp_name")
    private String tpName;

	/** The tp policy number. */
	@Column(name = "tp_policy_number")
    private String tpPolicyNumber;

	/** The tp claim no. */
	@Column(name = "tp_claim_no")
    private String tpClaimNo;

	/** The tp registration no. */
	@Column(name = "tp_registration_no")
    private String tpRegistrationNo;

	/** The tp registration type. */
	@Column(name = "tp_registration_type")
    private String tpRegistrationType;

	/** The tp make. */
	@Column(name = "tp_make")
    private String tpMake;

	/** The tp model. */
	@Column(name = "tp_model")
    private String tpModel;


    //loss details

	/** The ld date of loss. */
    @Column(name = "ld_date_of_loss")
    private String ldDateOfLoss;

	/** The ld claim number. */
	@Column(name = "ld_claim_number")
    private String ldClaimNumber;

	/** The ld reported date. */
	@Column(name = "ld_reported_date")
    private String ldReportedDate;

	/** The ld policy number. */
	@Column(name = "ld_policy_number")
    private String ldPolicyNumber;

	/** The ld reserve amount. */
	@Column(name = "ld_reserve_amount")
    private String ldReserveAmount;

	/** The ld police report number. */
	@Column(name = "ld_police_report_number")
    private String ldPoliceReportNumber;

	/** The ld is total loss. */
	@Column(name = "ld_is_totalloss")
    private String ldIsTotalLoss;

    //garageInfo

	/** The garage name. */
    @Column(name = "garage_name")
    private String garageName;

	/** The garage location. */
	@Column(name = "garage_location")
    private String garageLocation;

	/** The garage contact details. */
	@Column(name = "garage_contact_details")
    private String garageContactDetails;

	/** The garage type. */
	@Column(name = "garage_type")
    private String garageType;

	/** The garage invoice name. */
	@Column(name = "garage_invoice_name")
    private String garageInvoiceName;

    /** The sd survey allocation date. */
    //survey Details
	@Column(name = "sd_survey_allocation_date")
    private String sdSurveyAllocationDate;

	/** The sd survey due date. */
	@Column(name = "sd_survey_due_date")
    private String sdSurveyDueDate;

	/** The sd survey report name. */
	@Column(name = "sd_survey_report_name")
    private String sdSurveyReportName;

    //survey report

	/** The sr total loss. */
    @Column(name = "sr_totalloss")
    private String srTotalLoss;

	/** The sr spare parts. */
	@Column(name = "sr_spare_parts")
    private String srSpareParts;

	/** The sr labour cost. */
	@Column(name = "sr_labour_cost")
    private String srLabourCost	;

	/** The sr survey amount. */
	@Column(name = "sr_survey_amount")
    private String srSurveyAmount;

    /** The insurer name. */
    @Column(name="insurer_name")
    private String insurerName;
    
    /** The sr survey name. */
    @Column(name = "sr_survey_name")
    private String srSurveyName;

    /** The identity. */
    @Column(name="identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;

    /** The is deleted. */
    @Column(name = "is_deleted")
    private Boolean isDeleted = false;

    /** The in insured name. */
    @Column(name = "in_insured_name")
    private String inInsuredName;
    
    /** The dual currency. */
    @Column(name = "dual_currency")
    private String dualCurrency;

}
