package com.recoveryportal.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserCompanyMappingDto.
 */
@Data
@NoArgsConstructor
public class UserCompanyMappingDto {
    
    /** The user company mapping id. */
    private int userCompanyMappingId;
    
    /** The user id. */
    private UserDto userId;
    
    /** The company id. */
    private CompanyDto companyId;
    
    /** The identity. */
    private String identity;
}
