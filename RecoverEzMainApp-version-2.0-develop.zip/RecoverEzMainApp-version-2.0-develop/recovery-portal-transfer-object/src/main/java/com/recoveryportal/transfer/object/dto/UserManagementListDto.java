package com.recoveryportal.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 * The Class UserManagementListDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserManagementListDto {

    /** The user id. */
    private Integer userId;
    
    /** The email id. */
    private String emailId;
    
    /** The user name. */
    private String userName;
    
    /** The user role list. */
    private List<UserRoleDto> userRoleList;
    
    /** The added date. */
    private Date addedDate;
    
    /** The status. */
    private Boolean status;
    
    /** The user identity. */
    private String userIdentity;
    
    /** The is disable user. */
    private Boolean isDisableUser;
}
