package com.recoveryportal.transfer.object.dto;

import com.recoveryportal.transfer.object.entity.CurrencyDetails;

import lombok.Data;

/**
 * The Class SystemConfigurationDto.
 */
@Data
public class SystemConfigurationDto {


	/** The region. */
	private String region;

	/** The timezone. */
	private String timezone;

	/** The currency. */
	private String currency;
	
	/** The role. */
	private RoleDto role;
	
	/** The currency details. */
	private CurrencyDetails currencyDetails;

}
