package com.recoveryportal.transfer.object.reportloss.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

import org.hibernate.envers.Audited;

import com.recoveryportal.transfer.object.entity.Auditable;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * The Class SurveyDetails.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rl_survey_details")
@Audited
public class SurveyDetails extends Auditable implements Serializable{
    
    /** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5594986381810071214L;

	/** The survey details id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "survey_details_id")
    private int surveyDetailsId;

    /** The survey allocation date. */
    @Column(name = "survey_allocation_date")
    private LocalDateTime surveyAllocationDate;
    
    /** The survey due date. */
    @Column(name = "survey_due_date")
    private LocalDateTime surveyDueDate;
    
    /** The survey report name. */
    @Column(name = "survey_report_name")
    private String surveyReportName;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;
}
