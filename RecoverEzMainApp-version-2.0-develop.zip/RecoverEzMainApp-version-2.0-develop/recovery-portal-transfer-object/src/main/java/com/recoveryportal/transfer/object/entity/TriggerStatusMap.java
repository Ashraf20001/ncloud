package com.recoveryportal.transfer.object.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class TriggerStatusMap.
 */
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity(name = "scheduler_satus_map")
public class TriggerStatusMap {
	
	/** The trigger id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "status_id")
	private Integer triggerId;
    
    /** The status map id. */
    @Column(name = "trigger_status_map_id")
	private Integer statusMapId;
	
	/** The trigger status. */
	@Column(name = "notification_name")
	private String triggerStatus;

}
