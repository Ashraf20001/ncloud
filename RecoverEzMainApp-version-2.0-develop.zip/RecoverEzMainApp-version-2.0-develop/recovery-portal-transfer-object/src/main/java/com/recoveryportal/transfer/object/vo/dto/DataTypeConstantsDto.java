package com.recoveryportal.transfer.object.vo.dto;


/**
 * The Class DataTypeConstantsDto.
 */
public class DataTypeConstantsDto {
	
	/** The Constant STRING. */
	public static final String STRING = "String";
	
	/** The Constant TEXT. */
	public static final String TEXT = "text";
	
	/** The Constant INTEGER. */
	public static final String INTEGER = "Integer";
	
	/** The Constant BOOLEAN. */
	public static final String BOOLEAN = "Boolean";
	
	/** The Constant LONG. */
	public static final String LONG = "Long";
	
	/** The Constant DOUBLE. */
	public static final String DOUBLE = "Double";
	
	/** The Constant PDATE. */
	public static final String PDATE = "pDate";
	
	/** The Constant FDATE. */
	public static final String FDATE = "fDate";
    
    /** The Constant DROPDOWN. */
    public static final String DROPDOWN = "Dropdown";
    
    /** The Constant DOWNLOAD. */
    public static final String DOWNLOAD = "download";
    
    /** The Constant LOCAL_DATE_TIME. */
    public static final String LOCAL_DATE_TIME = "LocalDateTime";
    
    /** The Constant CHECKBOX. */
    public static final String CHECKBOX = "checkbox";
	
	/** The Constant FILE. */
	public static final String FILE = "file";
	
	/** The Constant RADIO_BUTTON. */
	public static final String RADIO_BUTTON = "RadioButton";
	
	/** The Constant MULTI_SELECT. */
	public static final String MULTI_SELECT = "MultiSelect";
	
	/** The Constant TOGGLE. */
	public static final String TOGGLE = "toggle";
}
