package com.recoveryportal.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class DropDownListDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DropDownListDto {

	/** The drop down id. */
	private Integer dropDownId;
	
	/** The drop down name. */
	private String dropDownName;
	
	/** The drop down type. */
	private Integer dropDownType;
	
	/** The identity. */
	private String identity;
	
}
