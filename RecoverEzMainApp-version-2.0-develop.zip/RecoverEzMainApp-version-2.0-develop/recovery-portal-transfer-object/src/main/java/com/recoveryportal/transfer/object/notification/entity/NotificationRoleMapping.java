package com.recoveryportal.transfer.object.notification.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.recoveryportal.transfer.object.entity.UserRole;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class NotificationRoleMapping.
 */
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "notification_role_mapping")
public class NotificationRoleMapping {

	/** The id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "notification_role_mapping_id")
    private Integer id;
	
	/** The user role id. */
	@OneToOne( cascade= CascadeType.ALL,fetch = FetchType.LAZY)
	@JoinColumn(name = "role_id")
    private UserRole userRoleId;
	
	/** The notification event. */
	@OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	@JoinColumn(name = "event_id")
    private NotificationEvent notificationEvent;
	
	/** The identity. */
	@Column(name = "identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;

	/** The is deleted. */
	@Column(name = "is_deleted")
	private Boolean isDeleted = false;
	
}
