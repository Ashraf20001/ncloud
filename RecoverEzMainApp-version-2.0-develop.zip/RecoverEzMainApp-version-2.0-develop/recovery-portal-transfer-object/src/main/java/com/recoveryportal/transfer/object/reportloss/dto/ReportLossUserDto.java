package com.recoveryportal.transfer.object.reportloss.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ReportLossUserDto {

    private Integer reportLossUserId;
    private String reportLossId;
    private Integer receivableUserId;
    private Integer payableUserId;
    private String identity;

}
