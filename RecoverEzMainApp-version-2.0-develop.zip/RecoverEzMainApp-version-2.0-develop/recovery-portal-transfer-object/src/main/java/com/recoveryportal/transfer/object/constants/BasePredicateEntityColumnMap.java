package com.recoveryportal.transfer.object.constants;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.recoveryportal.constants.core.ApplicationConstants;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.transfer.object.entity.PaymentDetails;

/**
 * The Class BasePredicateEntityColumnMap.
 */
@Component
public class BasePredicateEntityColumnMap {
	
	/** The Constant basePredicateEntityColumnMap. */
	public static final Map<String, String> basePredicateEntityColumnMap = new HashMap<>();

	/**
	 * Sets the base predicate map.
	 */
	@PostConstruct
	public void setBasePredicateMap() {
		basePredicateEntityColumnMap.put(ApplicationConstants.PAYABLE,TableConstants.THIRD_PARTY_INFO+ApplicationConstants.COMMA+TableConstants.RL_TPI_TP_COMPANY);
		basePredicateEntityColumnMap.put(ApplicationConstants.RECEIVABLE, TableConstants.INSURED_INFO+ApplicationConstants.COMMA+TableConstants.RL_II_INSURER_COMPANY);
		basePredicateEntityColumnMap.put(ApplicationConstants.RECEIVABLE_CLAIM,TableConstants.CLAIM_ID+ApplicationConstants.COMMA+TableConstants.INSURED_INFO+ApplicationConstants.COMMA+
				TableConstants.RL_II_INSURER_COMPANY);
		basePredicateEntityColumnMap.put(ApplicationConstants.PAYABLE_CLAIM,TableConstants.CLAIM_ID+ApplicationConstants.COMMA+TableConstants.THIRD_PARTY_INFO+ApplicationConstants.COMMA+
				TableConstants.RL_TPI_TP_COMPANY);
		basePredicateEntityColumnMap.put(PaymentDetails.class.toString(), TableConstants.TO_COMPANY);
	}

}
