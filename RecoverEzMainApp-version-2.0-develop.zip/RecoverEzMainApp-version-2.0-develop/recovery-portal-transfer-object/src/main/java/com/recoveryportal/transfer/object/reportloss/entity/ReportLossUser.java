package com.recoveryportal.transfer.object.reportloss.entity;


import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import com.recoveryportal.transfer.object.entity.Auditable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class ReportLossUser.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "report_loss_working_user")
@Audited
public class ReportLossUser extends Auditable implements Serializable{

    /** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8360330323250045734L;
	
	/** The report loss user id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "report_loss_user_id")
    private Integer reportLossUserId;
    
    /** The report loss id. */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "report_loss_id")
    @NotAudited
    private ReportLoss reportLossId;
    
    /** The receivable user id. */
    @Column(name = "receivable_user")
    private Integer receivableUserId;
    
    /** The payable user id. */
    @Column(name = "payable_user")
    private Integer payableUserId;

    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
}
