package com.recoveryportal.transfer.object.reportloss.dto;

import lombok.*;

import java.time.LocalDateTime;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ReportLossViewDto {

    //claimDetails
    private Integer claimId;
    private String state;
    private String claimSequenceId;
    private String createdDate;
    private String claimIdentity;
    private String currencyType;

    //InsurerInfo
    private Integer inInsuredInfoId;
    private Integer inVehicleId;
    private String inInsuredName;
    private String inInsurerName;
    private String inRegistrationNo;
    private String inMake;
    private String inModel;
    private LocalDateTime inPurchaseDate;
    private Double inSumInsured;
    private String dualCurrency;

    //ThirdPartyInfo
    private Integer thirdPartyInfoId;
    private Integer tpVehicleId;
    private String tpName;
    private String tpPolicyNumber;
    private String tpClaimNo;
    private String tpRegistrationNo;
    private String tpRegistrationType;
    private String tpMake;
    private String tpModel;

    //loss details
    private Integer lossDetailsId;
    private LocalDateTime ldDateOfLoss;
    private String ldClaimNumber;
    private LocalDateTime ldReportedDate;
    private String ldPolicyNumber;
    private Double ldReserveAmount;
    private String ldPoliceReportNumber;
    private boolean ldIsTotalLoss;

  //total loss
    private String estimatedTotalLossAmount;
    
    //police report
    private Integer policeReportId;
    private String prDocumentUpload	;

    //garageInfo
    private Integer garageId;
    private String garageName;
    private String garageLocation;
    private String garageContactDetails;
    private String garageType;
    private String garageInvoiceName;

    //survey Details
    private Integer surveyDetailsId;
    private LocalDateTime sdSurveyAllocationDate;
    private LocalDateTime sdSurveyDueDate;
    private String sdSurveyReportName;

//  survey report
    private Integer surveyReportId;
    private boolean srTotalLoss;
    private Double srSpareParts;
    private Double srLabourCost	;
    private String srSurveyName;
    private Double srSurveyAmount;
    private String srSurveyReportUpload	;

//    recovery details
    private Integer recoveryDetailsId;
    private Double rdPoliceReportFee;
    private Double rdTowingCharge;
    private Double rdInspectionFee;
    private Double rdOtherExpenses;
    private Double rdCashSettlement;
    private Double rdSpareParts;
    private Double rdLabourCost;
    private Double rdTPSurveyAmount;
    private Double rdClaimAmount;

//    reserve review
    private Integer reserveReviewId;
    private Double rrReserveAmount;
    private Double rrTPSurveyAmount;
    private Double rrTotalClaimAmount;

//    garage invoice
    private Integer garageInvoiceId;
    private String giDocument;
    private String giGarageInvoiceNo;

//    debit note number
    private Integer debitNoteId;
    private String dnDebitNoteNumber;
    private String dnDebitNoteDocument;

    //    credit note number
    private Integer creditNoteId;
    private String cnCreditNoteNumber;
    private String cnCreditNoteDocument;
    
    //stage and section
    private String stageName;
    private String sectionName;
    
    
    
    
}
