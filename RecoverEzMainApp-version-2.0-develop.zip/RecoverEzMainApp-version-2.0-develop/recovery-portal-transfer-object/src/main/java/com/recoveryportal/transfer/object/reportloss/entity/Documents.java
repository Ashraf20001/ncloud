package com.recoveryportal.transfer.object.reportloss.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

/**
 * The Class Documents.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rl_documents")
public class Documents {
    
    /** The id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;
    
    /** The document id. */
    @Column(name = "document_id")
    private String documentId;
    
    /** The name. */
    @Column(name = "name")
    private String name;
    
    /** The category. */
    @Column(name = "category")
    private String category;
    
    /** The content type. */
    @Column(name = "content_type")
    private String contentType;
    
    /** The document. */
    @Column(name = "document")
    private String document;
    
    /** The doc ref no. */
    @Column(name = "doc_ref_no")
    private String docRefNo;
    
    /** The document url. */
    @Column(name = "document_url")
    private String documentUrl;
    
    /** The uploaded date time. */
    @Column(name = "uploaded_date_time")
    private String uploadedDateTime;

    /** The created date. */
    @Column(name="created_date")
    private Date createdDate;

    /** The created by. */
    @Column(name="created_by")
    private int createdBy;

    /** The modified date. */
    @Column(name="modified_date")
    private Date modifiedDate;

    /** The modified by. */
    @Column(name="modified_by")
    private int modifiedBy;

    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;

    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;
}
