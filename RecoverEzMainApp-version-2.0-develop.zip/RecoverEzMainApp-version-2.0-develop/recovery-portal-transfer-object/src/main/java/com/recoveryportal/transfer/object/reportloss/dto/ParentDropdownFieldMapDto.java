package com.recoveryportal.transfer.object.reportloss.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ParentDropdownFieldMapDto {
    private String parentFieldName;
    private String childFieldName;
}
