package com.recoveryportal.transfer.object.dto;

/**
 * The Enum RepeatOnEnum.
 */
public enum RepeatOnEnum {
	
	/** The first. */
	FIRST, 
 /** The second. */
 SECOND, 
 /** The third. */
 THIRD, 
 /** The fourth. */
 FOURTH, 
 /** The fifth. */
 FIFTH
}
