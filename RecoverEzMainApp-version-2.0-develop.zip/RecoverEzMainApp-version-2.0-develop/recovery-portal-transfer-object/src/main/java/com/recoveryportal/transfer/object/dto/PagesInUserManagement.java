package com.recoveryportal.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class PagesInUserManagement.
 */
@Data
@NoArgsConstructor
public class PagesInUserManagement {

	/** The is receivable. */
	private boolean isReceivable;
	
	/** The is payable. */
	private boolean isPayable;

}
