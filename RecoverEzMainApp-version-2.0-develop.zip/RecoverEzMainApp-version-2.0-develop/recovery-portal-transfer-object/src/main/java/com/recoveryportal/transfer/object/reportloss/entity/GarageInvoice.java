package com.recoveryportal.transfer.object.reportloss.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.envers.Audited;

import com.recoveryportal.transfer.object.entity.Auditable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class GarageInvoice.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rl_garage_invoice")
@Audited
public class GarageInvoice extends Auditable implements Serializable {

    /** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8033955234773922639L;

	/** The garage invoice id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "garage_invoice_id")
    private int garageInvoiceId;

    /** The garage invoice no. */
    @Column(name = "garage_invoice_no")
    private String garageInvoiceNo;
    
    /** The attachment. */
    @Column(name = "attachment")
    private String attachment;

    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;
}
