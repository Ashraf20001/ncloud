package com.recoveryportal.transfer.object.dto;

import java.util.List;

import com.recoveryportal.transfer.object.vo.dto.FieldGroup;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FieldGroupAndPageAccessMenuDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FieldGroupAndPageAccessMenuDto {

	/** The field group. */
	private FieldGroup fieldGroup;

	/** The menu data. */
	private List<AccessMappingMenuDto> menuData;
}
