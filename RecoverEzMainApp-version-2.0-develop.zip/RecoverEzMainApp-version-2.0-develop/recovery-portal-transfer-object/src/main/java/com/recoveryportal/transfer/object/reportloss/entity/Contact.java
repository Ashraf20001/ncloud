package com.recoveryportal.transfer.object.reportloss.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

/**
 * The Class Contact.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rl_contact")
public class Contact {
    
    /** The contact id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "contact_id")
    private int contactId;
    
    /** The contact name. */
    @Column(name = "contact_name")
    private String contactName;
    
    /** The contact phone. */
    @Column(name = "contact_phone")
    private String contactPhone;
    
    /** The email address. */
    @Column(name = "email_address")
    private String emailAddress;

    /** The created date. */
    @Column(name="created_date")
    private Date createdDate;

    /** The created by. */
    @Column(name="created_by")
    private int createdBy;

    /** The modified date. */
    @Column(name="modified_date")
    private Date modifiedDate;

    /** The modified by. */
    @Column(name="modified_by")
    private int modifiedBy;

    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;

    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;
}
