package com.recoveryportal.transfer.object.dto;

import java.time.LocalDateTime;

import lombok.Data;

/**
 * The Class DisableDto.
 */
@Data
public class DisableDto {

/** The effective date. */
private LocalDateTime effectiveDate;

/** The identity. */
private String identity;

/** The is mapped. */
private Boolean isMapped;
}
