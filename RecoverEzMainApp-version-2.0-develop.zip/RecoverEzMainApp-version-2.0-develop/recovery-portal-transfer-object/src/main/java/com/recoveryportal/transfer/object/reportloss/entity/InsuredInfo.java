package com.recoveryportal.transfer.object.reportloss.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.envers.Audited;

import com.recoveryportal.transfer.object.entity.Auditable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class InsuredInfo.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rl_insured_info")
@Audited
public class InsuredInfo extends Auditable implements Serializable {
    
    /** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6363274340260810569L;
	
	/** The insured info id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "insured_info_id")
    private int insuredInfoId;
    
    /** The insured name. */
    @Column(name = "insured_name")
    private String insuredName;
    
    /** The insurer company. */
    @Column(name = "insurer_company_id")
    private Integer insurerCompany;
    
    /** The vehicle details. */
    @ManyToOne(cascade = {CascadeType.ALL})
    @JoinColumn(name = "vehicle_details")
    private VehicleDetails vehicleDetails;

    /** The purchase date. */
    @Column(name = "purchase_date")
    private LocalDateTime purchaseDate;
    
    /** The sum insured. */
    @Column(name = "sum_insured")
    private Double sumInsured;
 
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;

    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;
    
    /** The dual currency. */
    @Column(name = "currency_value")
    private String dualCurrency;

}
