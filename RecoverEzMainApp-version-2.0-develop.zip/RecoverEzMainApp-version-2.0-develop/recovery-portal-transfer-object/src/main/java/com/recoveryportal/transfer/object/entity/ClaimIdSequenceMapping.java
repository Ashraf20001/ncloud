package com.recoveryportal.transfer.object.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class ClaimIdSequenceMapping.
 */
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Table(name = "claimid_sequence_generator")
public class ClaimIdSequenceMapping {
    
    /** The claim sequence id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="claim_sequence_id")
    private int claimSequenceId;

}
