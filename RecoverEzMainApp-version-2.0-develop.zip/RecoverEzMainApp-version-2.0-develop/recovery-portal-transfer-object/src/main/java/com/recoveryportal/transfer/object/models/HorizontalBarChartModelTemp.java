package com.recoveryportal.transfer.object.models;

/**
 * The Class HorizontalBarChartModelTemp.
 */
public class HorizontalBarChartModelTemp {
    
    /** The Company. */
    private String Company;
    
    /** The recovery count. */
    private int recoveryCount;

    /**
     * Instantiates a new horizontal bar chart model temp.
     */
    public HorizontalBarChartModelTemp() {
    }

    /**
     * Instantiates a new horizontal bar chart model temp.
     *
     * @param company the company
     * @param recoveryCount the recovery count
     */
    public HorizontalBarChartModelTemp(String company, int recoveryCount) {
        Company = company;
        this.recoveryCount = recoveryCount;
    }

    /**
     * Gets the company.
     *
     * @return the company
     */
    public String getCompany() {
        return Company;
    }

    /**
     * Sets the company.
     *
     * @param company the new company
     */
    public void setCompany(String company) {
        Company = company;
    }

    /**
     * Gets the recovery count.
     *
     * @return the recovery count
     */
    public int getRecoveryCount() {
        return recoveryCount;
    }

    /**
     * Sets the recovery count.
     *
     * @param recoveryCount the new recovery count
     */
    public void setRecoveryCount(int recoveryCount) {
        this.recoveryCount = recoveryCount;
    }
}
