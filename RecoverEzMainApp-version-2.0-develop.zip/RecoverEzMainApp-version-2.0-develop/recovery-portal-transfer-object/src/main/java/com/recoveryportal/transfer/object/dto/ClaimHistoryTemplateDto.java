package com.recoveryportal.transfer.object.dto;

import com.recoveryportal.transfer.object.notification.entity.NotificationEvent;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class ClaimHistoryTemplateDto.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ClaimHistoryTemplateDto {

	/** The id. */
	private Integer id;

	/** The notification event. */
	private NotificationEvent notificationEvent;
	
	/** The template. */
	private String template;

	/** The section name. */
	private String sectionName;

	/** The stage name. */
	private String stageName;
	
	/** The state. */
	private String state;

	/** The is deleted. */
	private boolean isDeleted;
	
	
	
}
