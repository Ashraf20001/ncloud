package com.recoveryportal.transfer.object.reportloss.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor
public class BulkImportErrorDataDto {
    private Integer rowId;
    private String fieldName;
    private String errorId;

}
