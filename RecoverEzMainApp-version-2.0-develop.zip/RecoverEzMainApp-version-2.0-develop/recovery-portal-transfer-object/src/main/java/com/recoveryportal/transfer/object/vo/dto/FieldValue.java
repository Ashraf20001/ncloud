package com.recoveryportal.transfer.object.vo.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FieldValue.
 */
@Data
@NoArgsConstructor
public class FieldValue {
	
	/** The field. */
	private Field field;
	
	/** The value. */
	private String value;
	
}
