package com.recoveryportal.transfer.object.entity;

import java.time.LocalDateTime;

import javax.persistence.Id;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

/**
 * The Class RecoveryAuditEntity.
 */
@Document(collection = "audit")
@Getter
@Setter
@ToString
@Accessors(chain = true)
public class RecoveryAuditEntity {
	
	/** The id. */
	@Id
	private String id;

	/** The request url. */
	private String requestUrl;

	/** The user id. */
	private String userId;

	/** The audit date. */
	private LocalDateTime auditDate;

	/** The response. */
	private String response;
}
