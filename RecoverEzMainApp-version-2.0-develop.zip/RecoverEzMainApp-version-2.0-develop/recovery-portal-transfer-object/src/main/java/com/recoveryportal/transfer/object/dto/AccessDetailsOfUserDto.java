package com.recoveryportal.transfer.object.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AccessDetailsOfUserDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccessDetailsOfUserDto {
	
	
	/** The access mapping page dto. */
	private AccessMappingPageDto accessMappingPageDto;
	
	/** The user section mapping dto. */
	private List<UserSectionMappingDto> userSectionMappingDto;
}
