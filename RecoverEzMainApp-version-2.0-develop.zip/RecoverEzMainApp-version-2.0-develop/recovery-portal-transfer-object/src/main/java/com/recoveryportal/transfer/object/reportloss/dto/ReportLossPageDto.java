package com.recoveryportal.transfer.object.reportloss.dto;

import com.recoveryportal.transfer.object.dto.MetaDataViewDto;
import lombok.*;


@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ReportLossPageDto {

    private Integer claimId;
    private String insuredName;
    private String claimSequenceId;
    private String atFaultCompanyName;
    private boolean isReceivable;
    private String receivableAmount;
    private String status;
    private MetaDataViewDto metaData;
    private String insurerName;
    private String lastStatus;
    private String totalLossType;
    private Integer surveyDueHours;
    private String claimIdentity;
    private String currencyType;
}
