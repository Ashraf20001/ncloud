package com.recoveryportal.transfer.object.dto;

import lombok.Data;

/**
 * The Class SortingDto.
 */
@Data
public class SortingDto {

	/** The skip. */
	private Integer skip;

	/** The limit. */
	private Integer limit;

	/** The column name. */
	private String columnName;

	/** The is ascending. */
	private Boolean isAscending;
}
