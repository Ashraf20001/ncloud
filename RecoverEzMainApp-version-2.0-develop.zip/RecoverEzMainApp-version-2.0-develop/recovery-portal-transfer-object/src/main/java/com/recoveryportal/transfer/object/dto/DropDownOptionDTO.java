package com.recoveryportal.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class DropDownOptionDTO.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DropDownOptionDTO {

	/** The option id. */
	private int optionId;
	
	/** The option name. */
	private String optionName;
	
	/** The identity. */
	private String identity;
}
