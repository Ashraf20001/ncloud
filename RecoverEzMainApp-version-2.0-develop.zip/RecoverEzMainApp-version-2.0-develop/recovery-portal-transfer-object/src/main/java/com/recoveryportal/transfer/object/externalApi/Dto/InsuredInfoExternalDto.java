package com.recoveryportal.transfer.object.externalApi.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class InsuredInfoExternalDto.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class InsuredInfoExternalDto {
	
	/** The dual currency. */
	private String dualCurrency;
	
	/** The policy number. */
	private String policyNumber;

	/** The company. */
	private CompanyExternalDto company;

	/** The vehicle details. */
	private VehicleExternalDto vehicleDetails;

}
