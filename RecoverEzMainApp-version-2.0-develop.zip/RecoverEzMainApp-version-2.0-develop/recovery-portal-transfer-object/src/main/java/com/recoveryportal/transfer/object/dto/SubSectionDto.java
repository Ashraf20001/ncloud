package com.recoveryportal.transfer.object.dto;

import lombok.*;

import java.util.List;

/**
 * The Class SubSectionDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class SubSectionDto {
    
    /** The section id. */
    private String sectionId;
    
    /** The section name. */
    private String sectionName;
    
    /** The field list. */
    private List<FieldDto> fieldList;
}
