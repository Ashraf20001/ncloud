package com.recoveryportal.transfer.object.dto;

import java.util.List;

import com.recoveryportal.transfer.object.entity.UserType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserInfo.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserInfo {
	
	/** The userid. */
	public static Integer userid;

	/** The name. */
	public static String name;

	/** The id. */
	private Integer id;

	/** The username. */
	private String username;

	/** The email. */
	private String email;

	/** The first time login. */
	private boolean firstTimeLogin;

	/** The identity. */
	private String identity;
	
	/** The user type id. */
	private UserType userTypeId;
	
	/** The platform details dto. */
	private  PlatformDetailsDto platformDetailsDto;
	
	/** The platform identity. */
	private String platformIdentity;
	
	/** The roles. */
	private List<UserRoleDto> roles;
	
	/** The company id. */
	private Integer companyId;
	
	/** The allocation user type. */
	private Integer allocationUserType;
	
	/** The association id. */
	private Integer associationId;
	
	/** The company name. */
	private String companyName;

}
