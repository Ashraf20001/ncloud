package com.recoveryportal.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ApprovalLevelNotificationDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApprovalLevelNotificationDto {
	
	/** The role name. */
	private String roleName;
	
	/** The min. */
	private Double min;
	
	/** The max. */
	private Double max;
	
	/** The role id. */
	private Integer roleId;
	
	/** The currency. */
	private String currency;

	

}
