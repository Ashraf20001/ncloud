package com.recoveryportal.transfer.object.dto;

import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class TotalLossDTO.
 */
@Data
@NoArgsConstructor
public class TotalLossDTO {

	/** The id. */
	private int id;
	
	/** The claim id. */
	private String claimId;
	
	/** The adjustor name 1. */
	private String adjustorName1;
	
	/** The adjustor name 2. */
	private String adjustorName2;
	
	/** The survey date 1. */
	private Date surveyDate1;
	
	/** The survey date 2. */
	private Date surveyDate2;
	
	/** The total loss amount 1. */
	private Double totalLossAmount1;
	
	/** The total loss amount 2. */
	private Double totalLossAmount2;
	
	/** The reason for total loss. */
	private String reasonForTotalLoss;
	
	/** The estimated total loss amount. */
	private Double estimatedTotalLossAmount;
	
	/** The salvage seller name. */
	private String salvageSellerName;
	
	/** The salvage amount. */
	private Double salvageAmount;
	
	/** The salvage buyer name. */
	private String salvageBuyerName;
	
}
