package com.recoveryportal.transfer.object.reportloss.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

import com.recoveryportal.transfer.object.entity.BulkImportTempData;

@Data
@NoArgsConstructor
public class BulkUploadSuccessErrorList {
    private List<ReportLossDto> reportLossList;
    private List<BulkImportErrorDataDto> errorList;
    private List<BulkImportTempData> bulkImportData;
}
