package com.recoveryportal.transfer.object.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.recoveryportal.transfer.object.reportloss.entity.DropdownOptions;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class DropDownListOptionMapping.
 */
@Entity
@Table(name = "dropdownlist_option_map")
@Data
@NoArgsConstructor
public class DropDownListOptionMapping {
	
	/** The dropdown list option mapping id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Integer dropdownListOptionMappingId;
	
	/** The drop down list id. */
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "dropdownlist_id")
	private DropDownList dropDownListId;
	
	/** The drop down options id. */
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "dropdown_options_id")
	private DropdownOptions dropDownOptionsId;
	
	/** The is deleted. */
	@Column(name="is_deleted")
	private Boolean isDeleted;
	
	/** The identity. */
	@Column(name="identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private String identity;

	/** The created date. */
	@Column(name="created_date")
	private Date createdDate;

	/** The created by. */
	@Column(name="created_by")
	private int createdBy;
	
	/** The modified date. */
	@Column(name="modified_date")
	private Date modifiedDate;

	/** The modified by. */
	@Column(name="modified_by")
	private int modifiedBy;
	
}
