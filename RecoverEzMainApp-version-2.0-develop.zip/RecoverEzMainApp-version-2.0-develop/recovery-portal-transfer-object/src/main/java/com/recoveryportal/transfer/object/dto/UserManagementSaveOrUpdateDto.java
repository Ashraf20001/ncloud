package com.recoveryportal.transfer.object.dto;

import com.recoveryportal.transfer.object.vo.dto.FieldGroup;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserManagementSaveOrUpdateDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserManagementSaveOrUpdateDto {
    
    /** The is active. */
    private Boolean isActive;
    
    /** The user details. */
    private FieldGroup userDetails;
    
    /** The enable notification. */
    private EnableNotificationDto enableNotification;
}
