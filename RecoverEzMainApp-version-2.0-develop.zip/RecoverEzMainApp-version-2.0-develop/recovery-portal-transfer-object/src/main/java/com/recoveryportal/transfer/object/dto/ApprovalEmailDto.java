package com.recoveryportal.transfer.object.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ApprovalEmailDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApprovalEmailDto {

	/** The user name. */
	private String userName;
	
	/** The email. */
	private List<String> email;
	
	/** The filed name. */
	private String filedName;
	
	/** The transaction date. */
	private String transactionDate;
	
	/** The approval max amount. */
	private Double approvalMaxAmount;
	
	/** The claim number. */
	private String claimNumber;
	
	/** The role name. */
	private String roleName;
	
	/** The company id. */
	private Integer companyId;
	
	/** The company name. */
	private String companyName;
}
