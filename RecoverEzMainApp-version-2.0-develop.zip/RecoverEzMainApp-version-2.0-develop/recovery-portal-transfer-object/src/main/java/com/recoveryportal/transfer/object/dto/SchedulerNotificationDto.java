package com.recoveryportal.transfer.object.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class SchedulerNotificationDto.
 */
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SchedulerNotificationDto {
	 
 	/** The schedular id. */
 	private Integer schedularId;
	    
    	/** The notification name. */
    	private String notificationName;
	    
    	/** The triggered status. */
    	private String triggeredStatus;
	    
    	/** The message. */
    	private String message;
	    
    	/** The remainder. */
    	private Integer remainder;
	    
    	/** The is active. */
    	private Boolean isActive;
	    
    	/** The action. */
    	private String action;
	    
    	/** The remainder status. */
    	private List<String> remainderStatus;


}
