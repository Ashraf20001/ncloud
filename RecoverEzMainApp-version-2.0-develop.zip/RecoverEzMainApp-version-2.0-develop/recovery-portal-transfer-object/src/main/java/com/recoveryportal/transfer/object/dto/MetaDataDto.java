package com.recoveryportal.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class MetaDataDto.
 */
@Data
@NoArgsConstructor
public class MetaDataDto {
	
	/** The meta data id. */
	private int metaDataId;
	
	/** The page id. */
	private int pageId;
	
	/** The section id. */
	private int sectionId;
	
	/** The field id. */
	private int fieldId;
	
	/** The entity. */
	private String entity;

	/** The column. */
	private String column;
	
	/** The order by. */
	private Integer orderBy;

}
