package com.recoveryportal.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CommentExternalDto.
 */
@Data
@NoArgsConstructor
public class CommentExternalDto {
	
	/** The reason. */
	public String reason;
	
	/** The last comment. */
	public String lastComment;

}
