package com.recoveryportal.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class MetaDataPageDto.
 */
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class MetaDataPageDto {
	 
 	/** The is active. */
 	private Boolean isActive=true;
	  
  	/** The meta data. */
  	private MetaDataViewDto metaData;
}
