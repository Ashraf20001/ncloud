package com.recoveryportal.transfer.object.dto;

import java.util.List;

import com.recoveryportal.transfer.object.vo.dto.Field;

import lombok.Data;

/**
 * The Class UpdateFieldDto.
 */
@Data
public class UpdateFieldDto {

	/** The stage. */
	private String stage;
	
	/** The section. */
	private String section;
	
	/** The field list. */
	private List<Field> fieldList;
}
