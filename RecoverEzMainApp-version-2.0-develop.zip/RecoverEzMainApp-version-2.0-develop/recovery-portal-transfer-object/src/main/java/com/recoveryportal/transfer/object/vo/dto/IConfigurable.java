package com.recoveryportal.transfer.object.vo.dto;

/**
 * The Interface IConfigurable.
 */
public interface IConfigurable {

}
