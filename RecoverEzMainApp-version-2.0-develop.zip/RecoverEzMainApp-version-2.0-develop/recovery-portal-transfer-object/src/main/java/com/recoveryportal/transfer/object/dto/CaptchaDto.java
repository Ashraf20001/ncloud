package com.recoveryportal.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CaptchaDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CaptchaDto {
	
	/** The captcha. */
	private String captcha;
	
	/** The captcha value. */
	private String captchaValue;
	
	/** The compare captcha data value. */
	private String compareCaptchaDataValue;

}
