package com.recoveryportal.transfer.object.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserType.
 */
@Entity
@Table(name="user_type")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserType {
	
	/** The user type id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="user_type_id")
	private Integer userTypeId;
	
	/** The user type name. */
	@Column(name="user_type_name")
	private String userTypeName;

}
