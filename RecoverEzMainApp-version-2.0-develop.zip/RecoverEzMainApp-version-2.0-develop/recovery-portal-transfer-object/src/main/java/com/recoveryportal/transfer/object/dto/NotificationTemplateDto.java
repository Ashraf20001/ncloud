package com.recoveryportal.transfer.object.dto;

import lombok.Data;

/**
 * The Class NotificationTemplateDto.
 */
@Data
public class NotificationTemplateDto {

	/** The start message. */
	private String startMessage;
	
	/** The claim no. */
	private String claimNo;
	
	/** The middle message. */
	private String middleMessage;
	
	/** The company name. */
	private String companyName;
	
}
