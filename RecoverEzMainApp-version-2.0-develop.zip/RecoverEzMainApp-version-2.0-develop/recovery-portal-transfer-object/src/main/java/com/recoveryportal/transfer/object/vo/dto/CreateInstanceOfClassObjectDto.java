package com.recoveryportal.transfer.object.vo.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CreateInstanceOfClassObjectDto.
 */
@Data
@NoArgsConstructor
public class CreateInstanceOfClassObjectDto  {
	
	/** The clss. */
	public Class<?> clss ;
	
	/** The instant 0. */
	public Object instant0 ;
	

}
