package com.recoveryportal.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FileViewDto.
 */
@Data
@NoArgsConstructor
public class FileViewDto {

	/** The id. */
	private int id;
	
	/** The url. */
	private String url;
}
