package com.recoveryportal.transfer.object.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CurrencyDetails.
 */
@Entity
@Data
@Table(name = "rp_currency")
@NoArgsConstructor
public class CurrencyDetails {
	
	/** The currency id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "currency_id")
	private int currencyId;

	/** The region. */
	@Column(name = "region")
	private String region;

	/** The currency. */
	@Column(name = "currency")
	private String currency;

	/** The createdby. */
	@Column(name = "created_by")
	private String createdby;

	/** The modifiedby. */
	@Column(name = "modified_by")
	private String modifiedby;

	/** The isdeleted. */
	@Column(name = "is_deleted")
	private boolean isdeleted;

	
	/** The identity. */
	@Column(name = "identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;

	/** The createdat. */
	@CreationTimestamp
	@Column(name = "created_at")
	private Date createdat;

	/** The modifiedat. */
	@UpdateTimestamp
	@Column(name = "modified_at")
	private Date modifiedat;

}
