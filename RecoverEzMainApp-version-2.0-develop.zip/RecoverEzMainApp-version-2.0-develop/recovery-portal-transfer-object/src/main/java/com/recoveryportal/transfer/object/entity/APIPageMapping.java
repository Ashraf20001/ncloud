package com.recoveryportal.transfer.object.entity;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class APIPageMapping.
 */
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Table(name = "um_page_api_mapping")
public class APIPageMapping {
    
    /** The api function mapping id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="page_api_mapping_id")
    private Integer apiFunctionMappingId;
    
    /** The page id. */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "page_id")
    private Page pageId;
    
    /** The api details id. */
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "api_details_id")
    private APIDetails apiDetailsId;
    
    /** The created date. */
    @Column(name="created_date")
    private LocalDateTime createdDate;
    
    /** The created by. */
    @Column(name="created_by")
    private Integer createdBy;
    
    /** The modified date. */
    @Column(name="modified_date")
    private LocalDateTime modifiedDate;
    
    /** The modified by. */
    @Column(name="modified_by")
    private Integer modifiedBy;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private Boolean isDeleted = false;
}
