package com.recoveryportal.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The Class AccessMappingDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccessMappingDto {
    
    /** The role id. */
    private Integer roleId;
    
    /** The menu data. */
    private List<AccessMappingMenuDto> menuData;

}
