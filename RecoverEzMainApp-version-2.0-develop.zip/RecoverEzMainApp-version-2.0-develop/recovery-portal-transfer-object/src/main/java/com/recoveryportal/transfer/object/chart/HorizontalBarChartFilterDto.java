package com.recoveryportal.transfer.object.chart;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class HorizontalBarChartFilterDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class HorizontalBarChartFilterDto {
    
    /** The company. */
    private String company;
    
    /** The short name. */
    private String shortName;
    
    /** The count. */
    private Object count;
}
