package com.recoveryportal.transfer.object.dto;

/**
 * The Enum MonthEnum.
 */
public enum MonthEnum {
	
	/** The jan. */
	JAN, 
 /** The feb. */
 FEB, 
 /** The mar. */
 MAR, 
 /** The apr. */
 APR, 
 /** The may. */
 MAY, 
 /** The jun. */
 JUN, 
 /** The jul. */
 JUL, 
 /** The aug. */
 AUG, 
 /** The sep. */
 SEP, 
 /** The oct. */
 OCT, 
 /** The nov. */
 NOV, 
 /** The dec. */
 DEC
}
