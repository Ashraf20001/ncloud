package com.recoveryportal.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The Class EnableNotificationDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EnableNotificationDto {
    
    /** The menu data. */
    private List<AccessMappingMenuDto> menuData;

}
