package com.recoveryportal.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ReceivableDashboardDto.
 */
@Data
@NoArgsConstructor
public class ReceivableDashboardDto {
    
    /** The title. */
    private String title;
    
    /** The amount title. */
    private String amountTitle;
    
    /** The total receivable amount. */
    private String totalReceivableAmount;
    
    /** The receivable count. */
    private String receivableCount;
    
    /** The notification count. */
    private String notificationCount;
    
    /** The claim inspection count. */
    private String claimInspectionCount;
    
    /** The liability count. */
    private String liabilityCount;
    
    /** The settlement count. */
    private String settlementCount;
}
