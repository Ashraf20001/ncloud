package com.recoveryportal.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ActiveStatusDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ActiveStatusDto {

/** The id. */
private long id;

/** The no of active. */
private long noOfActive;

/** The is active. */
private Boolean isActive;
}
