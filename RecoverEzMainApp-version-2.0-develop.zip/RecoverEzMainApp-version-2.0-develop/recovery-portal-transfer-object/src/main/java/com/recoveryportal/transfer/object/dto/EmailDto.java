package com.recoveryportal.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class EmailDto.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class EmailDto {

    /** The email id. */
    private String emailId;
}
