package com.recoveryportal.transfer.object.chart;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class PieChartFilterDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
    public class PieChartFilterDto {
        
        /** The label. */
        private String label;
        
        /** The count. */
        private Object count;
}
