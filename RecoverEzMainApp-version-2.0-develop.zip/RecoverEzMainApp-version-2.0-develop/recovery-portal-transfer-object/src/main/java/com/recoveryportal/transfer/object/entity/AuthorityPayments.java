package com.recoveryportal.transfer.object.entity;


import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * The Class AuthorityPayments.
 */
@Entity
@Table(name = "authority_payments")
@Data
@NoArgsConstructor
public class AuthorityPayments {

    /** The authority payment id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="authority_payment_id")
    private Integer authorityPaymentId;
    
    /** The report card. */
    @OneToOne
    @JoinColumn(name="report_id")
    private ReportCard reportCard;
    
    /** The payment details. */
    @OneToOne
    @JoinColumn(name="payment_id")
    private PaymentDetails paymentDetails;
    
    /** The payment from. */
    @Column(name="payment_from")
    private String paymentFrom;
    
    /** The payment to. */
    @Column(name="payment_to")
    private String paymentTo;
    
    /** The amount. */
    @Column(name="amount")
    private String amount;
    
    /** The status. */
    @Column(name="status")
    private String status;
    
    /** The created date. */
    @Column(name="created_date")
    private LocalDateTime createdDate;
    
    /** The created by. */
    @Column(name="created_by")
    private Integer createdBy;
    
    /** The modified date. */
    @Column(name="modified_date")
    private LocalDateTime modifiedDate;
    
    /** The modified by. */
    @Column(name="modified_by")
    private Integer modifiedBy;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private Boolean isDeleted = false;
}
