package com.recoveryportal.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class PrivilegeDto.
 */
@Data
@NoArgsConstructor
public class PrivilegeDto {
    
    /** The privilege id. */
    private Integer privilegeId;
    
    /** The privilege name. */
    private String privilegeName;
    
    /** The page id. */
    private Integer pageId;
}
