package com.recoveryportal.transfer.object;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.recoveryportal.*")
public class RecoveryPortalTransferObjectApplication {

	public static void main(String[] args) {

	}

}
