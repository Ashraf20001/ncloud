package com.recoveryportal.transfer.object.reportloss.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.envers.Audited;

import com.recoveryportal.transfer.object.entity.Auditable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class GarageInfo.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rl_garage_info")
@Audited
public class GarageInfo extends Auditable implements Serializable{
    
    /** The Constant serialVersionUID. */
	private static final long serialVersionUID = -971786379140994427L;
	
	/** The garage id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "garage_id")
    private int garageId;
    
    /** The name. */
    @Column(name = "name")
    private String name;
    
    /** The location. */
    @Column(name = "location")
    private String location;
    
    /** The contact details. */
    @Column(name = "contact_details")
    private String contactDetails;
    
    /** The type. */
    @Column(name = "type")
    private String type;
    
    /** The invoice name. */
    @Column(name="invoice_name")
    private String invoiceName;

    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;

    /** The is deleted. */
    @Column(name = "is_deleted")
    private boolean isDeleted = false;
}
