package com.recoveryportal.transfer.object.enums;

/**
 * The Enum DataFilterEnum.
 */
public enum DataFilterEnum {

		/** The insurancecompany. */
		INSURANCECOMPANY("INSURANCE_COMPANY");
		
		/** The user type. */
		private String userType;
		
		/**
		 * Instantiates a new data filter enum.
		 *
		 * @param userType the user type
		 */
		private DataFilterEnum(String userType) {
			this.userType = userType;
		}
		
		/**
		 * Gets the user type.
		 *
		 * @return the user type
		 */
		private String getUserType() {
			return this.userType;
		}
		
		/**
		 * Gets the user type.
		 *
		 * @param userType the user type
		 * @return the user type
		 */
		public static String getUserType(String userType) {
			for (DataFilterEnum enumValue : DataFilterEnum.values()) {
				if (enumValue.getUserType().equals(userType)) {
					return enumValue.getUserType();
				}
			}
			return null;
		}

}
