package com.recoveryportal.transfer.object.entity;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class SchedulerNotification.
 */
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity(name="scheduler_notification")
public class SchedulerNotification {
	 
 	/** The schedular id. */
 	@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "scheduler_id")
	    private Integer schedularId;
	    
    	/** The notification name. */
    	@Column(name = "notification_name")
	    private String notificationName;
	    
    	/** The triggered status. */
    	@Column(name = "triggered_status")
	    private String triggeredStatus;
	    
    	/** The message. */
    	@Column(name = "message")
	    private String message;
	    
    	/** The remainder. */
    	@Column(name = "reminder")
	    private Integer remainder;
	    
    	/** The action. */
    	@Column(name = "action")
	    private String action;
	    
    	/** The is deleted. */
    	@Column(name = "is_deleted")
	    private Boolean isDeleted;
	    
    	/** The is active. */
    	@Column(name = "is_active")
	    private Boolean isActive;
	    
    	/** The status map id. */
    	@OneToMany(mappedBy="statusMapId",cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	    private List<TriggerStatusMap> statusMapId;


}
