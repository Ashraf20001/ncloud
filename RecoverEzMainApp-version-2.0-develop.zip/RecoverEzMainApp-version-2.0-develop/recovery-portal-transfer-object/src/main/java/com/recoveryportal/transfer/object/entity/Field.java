package com.recoveryportal.transfer.object.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class Field.
 */
@Entity
@Table(name = "field")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Field {
	
	/** The field id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="field_id")
	private int fieldId;
	
	/** The field name. */
	@Column(name="field_name")
	private String fieldName;
	
	/** The field type. */
	@Column(name="field_type")
	private String fieldType;
	
	/** The alias name. */
	@Column(name="alias_name")
	private String aliasName;
	
	/** The is mandatory. */
	@Column(name="is_mandatory")
	private boolean isMandatory;
	
	/** The is core data. */
	@Column(name="is_core_data")
	private Boolean isCoreData;
	
	/** The reference id. */
	@Column(name="reference_id")
	private Integer referenceId;
	
	/** The is deleted. */
	@Column(name="is_deleted")
	private boolean isDeleted;
	
	/** The identity. */
	@Column(name="identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;

	/** The created date. */
	@Column(name="created_date")
	private Date createdDate;

	/** The created by. */
	@Column(name="created_by")
	private int createdBy;
	
	/** The modified date. */
	@Column(name="modified_date")
	private Date modifiedDate;

	/** The modified by. */
	@Column(name="modified_by")
	private int modifiedBy;

	/** The min length. */
	@Column(name="min_length")
	private Integer minLength;

	/** The max length. */
	@Column(name="max_length")
	private Integer maxLength;

	/** The regex. */
	@Column(name="regex")
	private String regex;
	
	/** The is system generated. */
	@Column(name="is_sys_generated")
	private Boolean isSystemGenerated;
	
	/** The order by. */
	@Column(name="order_by")
	private Integer orderBy;
	
}
