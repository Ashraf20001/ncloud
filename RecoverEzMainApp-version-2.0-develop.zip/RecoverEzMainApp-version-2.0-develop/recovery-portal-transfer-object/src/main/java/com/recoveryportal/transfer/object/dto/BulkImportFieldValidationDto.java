package com.recoveryportal.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * The Class BulkImportFieldValidationDto.
 */
@Data
@NoArgsConstructor
public class BulkImportFieldValidationDto {
    
    /** The user id. */
    private String userId;
    
    /** The insurer name. */
    private String insurerName;
    
    /** The initial row number. */
    private Integer initialRowNumber;
    
    /** The bulk import history dto. */
    private BulkImportHistoryDto bulkImportHistoryDto;
    
    /** The map list. */
    private List<Map<String,String>> mapList;
    
    /** The field list. */
    private List<FieldDto> fieldList;
    
    /** The mandatory field list. */
    private List<FieldDto> mandatoryFieldList;
}
