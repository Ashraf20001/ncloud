package com.recoveryportal.crypto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * The Class RecoveryPortalCryptoApplication.
 */
@ComponentScan("com.recoveryportal.*")
@SpringBootApplication
public class RecoveryPortalCryptoApplication {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		SpringApplication.run(RecoveryPortalCryptoApplication.class, args);
	}

}
