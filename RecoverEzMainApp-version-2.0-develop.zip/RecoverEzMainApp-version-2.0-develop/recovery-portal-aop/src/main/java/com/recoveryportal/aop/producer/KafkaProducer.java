package com.recoveryportal.aop.producer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.recoveryportal.transfer.object.dto.BulkImportTriggerConsumerDto;

/**
 * The Class KafkaProducer.
 */
@Component
public class KafkaProducer {
	
	/** The bulk import kafka template. */
	@Autowired
	KafkaTemplate<String, String> bulkImportKafkaTemplate;
	
	/** The object mapper. */
	@Autowired
	private ObjectMapper objectMapper;
	
	/** The bulk import topic. */
	@Value("${recovery.kafka.topic.bulk-import}")
	String bulkImportTopic;
	

	/**
	 * Trigger bulk import.
	 *
	 * @param bulkImportTriggerConsumerDto the bulk import trigger consumer dto
	 * @throws JsonProcessingException the json processing exception
	 */
	public void triggerBulkImport(BulkImportTriggerConsumerDto bulkImportTriggerConsumerDto) throws JsonProcessingException{
		
		String stringValueOfBulkImportTriggerConsumerDto = objectMapper.writeValueAsString(bulkImportTriggerConsumerDto);
		bulkImportKafkaTemplate.send(bulkImportTopic,stringValueOfBulkImportTriggerConsumerDto);
		
	}

}