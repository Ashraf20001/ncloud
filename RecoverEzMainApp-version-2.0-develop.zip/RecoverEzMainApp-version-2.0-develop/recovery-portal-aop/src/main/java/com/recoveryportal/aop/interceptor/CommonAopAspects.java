package com.recoveryportal.aop.interceptor;

import org.aspectj.lang.annotation.Pointcut;

/**
 * The Class CommonAopAspects.
 */
public class CommonAopAspects {
	
	/**
	 * Service log.
	 */
	@Pointcut("(execution(* com.recoveryportal.*.*.*(..)) && !(within(com.recoveryportal..*dao*..*) || within(com.recoveryportal..*daoImpl*..*)))")
	public void serviceLog() {}
	
	/**
	 * Audit annotation.
	 */
	@Pointcut("@within(com.recoveryportal.aop.annotation.Auditable)")
	public void auditAnnotation() {}

}
