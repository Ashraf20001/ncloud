package com.recoveryportal.aop;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;


/**
 * The Class RecoveryPortalAopApplication.
 */
@SpringBootApplication
@ComponentScan("com.recoveryportal.*")
public class RecoveryPortalAopApplication {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		
	}
	

}
