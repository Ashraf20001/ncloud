package com.recoveryportal.constants.enums;

public enum ResultCodeEnum {
	OK("200", "OK"), BAD_REQUEST("400", "bad request"), INTERNAL_SERVER_ERROR("500", "internal server error"),

	FAILD("4400", "Operation failed"),

	PARAMS_MISS("4300", "PARAMS MISS"), PARAM_ERROR("4301", "PARAM ERROR"), MORE_REQUEST("4302", "MORE REQUEST"),;

	private String code;
	private String msg;

	ResultCodeEnum(String code, String msg) {
		this.code = code;
		this.msg = msg;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

}
