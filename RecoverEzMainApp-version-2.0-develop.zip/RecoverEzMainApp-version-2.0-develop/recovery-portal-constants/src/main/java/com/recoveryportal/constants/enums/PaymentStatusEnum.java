package com.recoveryportal.constants.enums;

public enum PaymentStatusEnum {
	SUBMITTED(1,"Submitted"),
	APPROVED(2,"Approved"),
	REJECTED(3,"Rejected"),
	PAID(4,"Paid");
	
	Integer id;
	String paymentStatus;

	private PaymentStatusEnum(Integer id, String paymentStatus) {
		this.id = id;
		this.paymentStatus = paymentStatus;
	}

	public Integer getId() {
		return id;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public static Integer getPaymentStatusEnum(String paymentStatusEnum) {
		for (PaymentStatusEnum onePaymentStatusEnum : PaymentStatusEnum.values()) {
			if (onePaymentStatusEnum.name().equalsIgnoreCase(paymentStatusEnum)) {
				return onePaymentStatusEnum.getId();
			}
		}

		return null;
	}


		public static PaymentStatusEnum getPaymentStatusEnumById(Integer id) {
			for (PaymentStatusEnum onePaymentStatusEnum : PaymentStatusEnum.values()) {
				if (onePaymentStatusEnum.ordinal() + 1 == id) {
					return onePaymentStatusEnum;
				}
			}
				return null;
		}


}
