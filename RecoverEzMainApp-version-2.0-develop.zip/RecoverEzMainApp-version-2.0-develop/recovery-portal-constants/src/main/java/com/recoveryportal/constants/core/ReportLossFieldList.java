package com.recoveryportal.constants.core;

public class ReportLossFieldList {

	public static final String IS_MAKE_EMPTY = "isMakeEmpty";
	public static final String IS_MODEL_EMPTY = "isModelEmpty";
	public static final String IS_POLICYNO_EMPTY = "isPolicyNoEmpty";
	public static final String IS_POLICE_REPORT_NUMBER_EMPTY = "isPoliceReportNoEmpty";
	public static final String IS_REGISTRATION_NO_EMPTY = "isRegistrationNoEmpty";
	public static final String IS_THIRDPARTY_CLAIMNO_EMPTY = "isThirdPartyClaimNoEmpty";
	public static final String IS_CLAIMOPENED = "isClaimOpened";
	public static final String IS_SURVEYDUEDATE_EMPTY = "isSurveyDueDateEmpty";
	public static final String IS_SURVEYALLOCATIONDATE_EMPTY = "isSurveyAllocationDateEmpty";
	public static final String IS_GARAGELOCATION_EMPTY = "isGarageLocationEmpty";
	public static final String IS_GARAGENAME_EMPTY = "isGarageNameEmpty";
	public static final String IS_DUAlCURRENCY_EMPTY = "isDualCurrencyEmpty";

	public static final String IS_NOTIFICATION_REJECTED = "isnotificationRejected";
	public static final String IS_NOTIFICATION_REOPEN = "isnotificationRepoen";
	public static final String IS_NOTFICATIONNEEDMOREDETAIL_EMPTY = "notficationNeedMoreDetail";
	public static final String IS_RECEIVEDREJECTEDNOTIFICATION_VIEWED = "receivedRejectedNotification";
	public static final String IS_DISPUTE = "dispute";
	public static final String IS_DISPUTE_REOPEN = "disputeReopen";
	 public static final String IS_TPCOMPANY_EMPTY="isTpCompanyEmpty";
	 //REPORT METHODS
	 public static final String IS_DEBITNOTE_VIEWED = "isDebitNoteViewed";
	 public static final String IS_CREDITNOTE_GENERATED = "isCreditNoteGenerated";
	 public static final String IS_SURVEYREPORT_EXIST = "isSurveyReportExist";
	 public static final String IS_POLICEREPORT_EXIST = "isPoliceReportExist";
	 public static final String IS_GARAGEREPORT_EXIST = "isGarageReportExist";
	 
	 public static final String IS_GSDTLS_OPENED="isGsDtlsOpened";
	 public static final String IS_GSDETAILVIEWEDBY_SURVEYOR="isGsDetailViewedBySurveyor";
	 public static final String IS_EXPENSES_AND_DOCUMENT_VIEWED="isExpensesAndDocumentViewed";
	 public static final String IS_LIABLITYACCEPTED="isLiablityAccepted";
	 public static final String IS_DEBITNOTEGENERATED="isDebitNoteGenerated";
	

	 public static final String IS_TOTAL_LOSS_EMPTY="isTotalLossEmpty";
	 public static final String IS_TOTAL_LOSS_ACCEPTED_EMPTY="isTotalLossAcceptedEmpty";
	 public static final String IS_SURVEYOR_ASSIGNED="isSurveyorAssigned";
	 
	 //expense and document reserve review
	 public static final String IS_SPARPART_ENTERED="isSparPartEntered";
	 public static final String IS_SURVEY_AMOUNT_ENTERED="isSurveyAmountEntered";
	 public static final String IS_LABOUR_CHARGE_ENTERED="isLabourChargeEntered";
	 public static final String IS_CONFIRM_LIABLITY_ACCEPTED="isConfirmLiablityAccepted";
	 
	 
	 //DETAIL PROVIDED
	 public static final String IS_DETAILPROVIDED="isDetailProvided";
	 
	 public static final String IS_DATE_OF_LOSS_EPMTY="isDateOfLossEmpty";
	 public static final String IS_LS_CLAIM_NO_EMPTY="isLsClaimNoEmpty";

	 //Total Loss Inited method
	 
	 public static final String IS_ADJUSTER_NAME1_ENTERED="isAdjusterName1Entered";
	 public static final String IS_TOTAL_LOSS_AMOUNT_1_ENTERD="isTotalLossAmount1Entered";
	 public static final String IS_SURVEY_DATE_1_ENTERED="isSurveyDate1Entered";
	 
	 
	 
}
