package com.recoveryportal.constants.serverproperties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@ConfigurationProperties(prefix = "recovery")
@Data
public class PropertyValueProvider {
private String mysqlDataSourceUrl;
	
	private String mysqlIp;
	
	private String mysqlPort;
	
	private String mysqlUsername;
	
	private String mysqlPassword;
	
	private String mysqlDataBase;
	
	private String mysqlDriver;
	
	private String timeZone;

	private String countryCode;

	private String currencyFormat;

	private String timeFormat;

	private String dateFormat;
	
	private String fileDownloadUrl;
	
	private String fileUploadPath;
	
	private String springMailUsername;
	
	private String bulkUploadReportlossPath;
	
	private String notificationUpdateUrl;
	
	private String notificationSaveUrl;
	
	private String approvalLimitNotificationUrl;
	
	private String schedulerUrl;
	
	private String schedulerUpdateUrl;
	
	private String notificationHistoryListUrl;
	
	private String notificationHistoryCountUrl;
	
	private String notificationApprovalLimitUpdateUrl;
	
	private String maxTime;
	
	private String maxAttempt;
	
	private String notificationSaveWalletUrl;
	
	private String walletPaymentReminderGracePeriod;
	
	private String walletReportGenerationCron;
	
	private String recoveryHostPort;
	
	private String notificationHostPort;
	
	private String notificationConsumerHostPort;
	
	private String nschedulerHostPort;
	
	private String bulkuploadConsumerHostPort;
	
	private String webApplicationHostPort;
	
	private String mySqlHostPort;
	
	private String kafkaHostPort;
	
	private String antivirusApiKey;
	
	private String antivirusApiEndpoint;
	
	private String logoUploadPath;
	
	private String loginUrl;
	
	private String mysqlPreferredQuery;
	
	private String mysqlConnectionCheckout;
	
	private String mysqlMinPoolsize;
	
	private String mysqlMaxPoolSize;
	
	private String mysqlIdleConnectionTestperiod;
	
	private String mysqlMaxIdleTimeout;
	
	private String mysqlMaxIdleExcessConnections;
	
	private String timeEnd;
	
	private String commonServiceUrl;
}
