package com.recoveryportal.constants.core;

public class ReportUploadType {
	 public static final String CREDIT_NOTE="Credit_Note";
	 public static final String DEBIT_NOTE="Debit_Note";
	 public static final String SURVEY_REPORT="survey_report";
}
