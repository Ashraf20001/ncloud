package com.recoveryportal.constants.externalApi.core;

import java.time.LocalDateTime;

public class ReportLossDtoField {
	//claimDetails
	public static final String STATE="state";
	public static final String CLAIM_SEQUENCE_ID= "claimSequenceId";


    //InsurerInfo
     public static final String IN_INSURER_NAME= "inInsurerName";
     public static final String IN_REGISRATION_NO= "inRegistrationNo";
     public static final String IN_MAKE= "inMake";
     public static final String IN_MODEL= "inModel";
     public static final String IN_PURCHASE_DATE= "inPurchaseDate";
     public static final String IN_SUM_INSURED= "inSumInsured";
     public static final String DUAL_CURRENCY = "dualCurrency";

    //ThirdPartyInfo
     public static final String TP_NAME= "tpName";
     public static final String TP_POLICY_NUMBER= "tpPolicyNumber";
     public static final String TP_CLAIM_NO= "tpClaimNo";
     public static final String TP_REGISTRATION_NO= "tpRegistrationNo";
     public static final String TP_REGISTRATION_TYPE= "tpRegistrationType";
     public static final String TP_MAKE= "tpMake";
     public static final String TP_MODEL= "tpModel";

    //loss details
     public static final String LD_DATE_OF_LOSS= "ldDateOfLoss";
     public static final String LD_CLAIM_NUMBER= "ldClaimNumber";
     public static final String LD_REPORTED_DATE= "ldReportedDate";
     public static final String LD_POLICY_NUMBER= "ldPolicyNumber";
     public static final String LD_RESERVE_AMOUNT= "ldReserveAmount";
     public static final String LD_POLICE_REPORT_NUMBER= "ldPoliceReportNumber";

    //police report
     public static final String PR_DOCUMENT_UPLOAD= "prDocumentUpload";
     public static final String PR_POLICE_REPORTID= "policeReportId";

    //garageInfo
     public static final String GARAGE_NAME= "garageName";
     public static final String GARAGE_LOCATION= "garageLocation";
     public static final String GARAGE_TYPE= "garageType";

    //survey Details
     public static final String SD_SURVEY_ALLOCATION_DATE= "sdSurveyAllocationDate";
     public static final String SD_SURVEY_DUE_DATE= "sdSurveyDueDate";

    //survey report
     public static final String SR_SPARE_PARTS= "srSpareParts";
     public static final String SR_LABOUR_COSR= "srLabourCost";
     public static final String SR_SURVEY_REPORT_UPLOAD= "srSurveyReportUpload";

    //recovery details
     public static final String RD_POLICE_REPORT_FREE= "rdPoliceReportFee";
     public static final String RD_TOWING_CHARGE= "rdTowingCharge";
     public static final String RD_INSPECTION_FREE= "rdInspectionFee";
     public static final String RD_OTHER_EXPENSES="rdOtherExpenses";
     public static final String RD_CASH_SETTLEMENT= "rdCashSettlement";
     public static final String RD_CLAIM_AMOUNT= "rdClaimAmount";

    //reserve review
     public static final String RR_RESERVE_AMOUNT= "rrReserveAmount";
     public static final String RR_TOTAL_CLAIM_AMOUNT= "rrTotalClaimAmount";

    //garage invoice
     public static final String GI_DOCUMENT= "giDocument";
     public static final String GI_GARAGE_INVOICE_ID= "garageInvoiceId";

    //debit note number
     public static final String DN_DEBITNOTE_NUMBER = "dnDebitNoteNumber";
     public static final String DN_DEBITNOTE_ID = "debitNoteId";
     public static final String DN_DEBITNOTE_DOCUMENT= "dnDebitNoteDocument";

    //credit note number
     public static final String CN_CREDITNOTE_NUMBER= "cnCreditNoteNumber";
     public static final String CN_CREDITNOTE_ID= "creditNoteId";
     public static final String CN_CREDITNOTE_DOCUMENT= "cnCreditNoteDocument";
     
     
     //totalLossFields
     public static final String ADJUSTORNAME1= "adjustorName1";
     public static final String ADJUSTORNAME2= "adjustorName2";
     public static final String SURVEYDATE1= "surveyDate1";
     public static final String SURVEYDATE2= "surveyDate2";
     public static final String TOTALLOSSAMOUNT1= "totalLossAmount1";
     public static final String TOTALLOSSAMOUNT2= "totalLossAmount2";
     public static final String ESTIMATEDTOTALLOSSAMOUNT= "estimatedTotalLossAmount";
     public static final String SALVAGESELLERNAME= "salvageSellerName";
     public static final String SALVAGEAMOUNT= "salvageAmount";
     public static final String SALVAGEBUYERNAME= "salvageBuyerName";
    
}
