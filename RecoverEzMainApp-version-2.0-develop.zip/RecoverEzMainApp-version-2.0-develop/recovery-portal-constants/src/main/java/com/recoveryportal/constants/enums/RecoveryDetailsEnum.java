package com.recoveryportal.constants.enums;

public enum RecoveryDetailsEnum {
	
	POLICE_REPORT_FEE("policeReportFee","Police Report Fee"),
	TOWING_CHARGE("towingCharge","Towing Charge"),
	INSPECTION_FEE("inspectionFee","Inspection Fee"),
	OTHER_EXPENSES("otherExpenses","Other Expenses"),
	CASH_SETTLEMENT("cashSettlement","Cash Settlement"),
	LABOUR_COST("labourCost","Labour Cost"),
	SPARE_PARTS("spareParts","Spare Amount");
	
	String columnName;
	String AliasName;
	
	private RecoveryDetailsEnum(String columnName, String aliasName) {
		this.columnName = columnName;
		AliasName = aliasName;
	}
	
	/**
	 * @param columnName
	 * @return
	 */
	public static String getAliasNameByColumnName(String columnName) {
		String aliasName = null;
		for(RecoveryDetailsEnum enums : RecoveryDetailsEnum.values()) {
			if(enums.columnName.equals(columnName)) {
				aliasName = enums.AliasName;
			}
		}
		return aliasName;
	}
	
			
}
