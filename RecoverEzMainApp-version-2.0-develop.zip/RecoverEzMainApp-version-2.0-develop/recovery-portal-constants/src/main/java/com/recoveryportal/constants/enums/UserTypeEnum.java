package com.recoveryportal.constants.enums;


public enum UserTypeEnum {
	ASSOCIATION(1,"ASSOCIATION"),
	INSURANCE_COMPANY(2,"INSURANCE_COMPANY"),
	SUPER_ADMIN(3,"SUPER_ADMIN");
	
	public Integer userTypeId;
	public String userTypeName;
	
	private UserTypeEnum(Integer userTypeId, String userTypeName) {
		this.userTypeId = userTypeId;
		this.userTypeName = userTypeName;
	}
	
}

