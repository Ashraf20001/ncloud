package com.recoveryportal.constants.core;

public class PropertyConstants {

	public static final String MAIN_APP_MYSQL_IP = "[MAIN_APP_MYSQL_IP]";
	public static final String MAIN_APP_MYSQL_PORT = "[MAIN_APP_MYSQL_PORT]";
	public static final String DB_NAME = "[DB_NAME]";



}
