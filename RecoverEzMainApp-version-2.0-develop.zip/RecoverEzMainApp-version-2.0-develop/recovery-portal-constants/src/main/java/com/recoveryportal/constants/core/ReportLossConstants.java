package com.recoveryportal.constants.core;

public class ReportLossConstants {

	public static final String CURRENCY_STATUS              = "currency";
	public static final String INSURER_COMPANY_NAME         = "companyName";
	public static final String COMPANY_ADDRESS              = "companyAddress";
	public static final String INSURER_LOSS_DATE            = "lossDate";
	public static final String INSURER_CLAIM_NO             = "claimNo";
	public static final String INSURER_VEHICLE_MAKE         = "vehicleMake";
	public static final String INSURER_VEHICLE_MODEL        = "vehicleModel"; 
	public static final String THIRD_PARTY_POLICY_NO        = "tpPolicyNo";
	public static final String THIRD_PARTY_CLAIM_NO         = "tpClaimNo";
	public static final String THIRD_PARTY_VEHICLE_MAKE     = "tpVehicleMake";
	public static final String THIRD_PARTY_VEHICLE_MODEL    = "tpVehicleModel"; 
	public static final String THIRD_PARTY_COMPANY_NAME     = "tpCompanyName";
	public static final String ESTIMATED_TOTAL_LOSS_AMOUNT  = "totalLossAmount";
	public static final String CLAIM_AMOUNT                 = "claimAmount";
	public static final String INSURED_REG_NUMBER           = "registrationNo";
	public static final String THIRD_PARTY_REG_NUMBER       = "tpRegistrationNo";
	public static final String CURRENT_DATE                 = "currentDate";
	public static final String SUM_INSURED                  = "sumInsured";

	public static final String COMPANY_LOGO_PATH            = "companyLogoPath";
	public static final String URL                          = "url";
	public static final String TP_COMPANY_ADDRESS           = "tpCompanyAddress";
	public static final String THIRD_PARTY_COMPANY_LOGO     = "tpCompanyLogoPath";
	
	public static final String SALVAGE_AMT                    = "salvageAmount";
	public static final String DATE_OF_PURCHASE 			  = "dateOfPurchase";
}
