package com.recoveryportal.constants.core;

import java.util.ArrayList;

public class NegativeFlowList {
public static final ArrayList<String> negativeStatusList=new ArrayList<>();

static {
	negativeStatusList.add(RecoveryStatusConstant.NEEDMOREDETAIL);
	negativeStatusList.add(RecoveryStatusConstant.DISPUTE);
	
}

}
