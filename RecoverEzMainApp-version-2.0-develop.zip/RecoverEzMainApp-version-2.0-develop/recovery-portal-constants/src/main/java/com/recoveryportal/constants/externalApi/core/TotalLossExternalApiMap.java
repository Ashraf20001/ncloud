package com.recoveryportal.constants.externalApi.core;

import java.util.LinkedHashMap;
import java.util.Map;

public class TotalLossExternalApiMap {
	public static final Map<String,String> totalLossExternalMap=new LinkedHashMap();
	
	static {
		totalLossExternalMap.put(ReportLossDtoField.ADJUSTORNAME1, ReportLossExternalDtoField.ADJUSTORNAMEONE);
		totalLossExternalMap.put(ReportLossDtoField.ADJUSTORNAME2, ReportLossExternalDtoField.ADJUSTORNAMETWO);
		totalLossExternalMap.put(ReportLossDtoField.SURVEYDATE1, ReportLossExternalDtoField.SURVEYDATEONE);
		totalLossExternalMap.put(ReportLossDtoField.SURVEYDATE2, ReportLossExternalDtoField.SURVEYDATETWO);
		totalLossExternalMap.put(ReportLossDtoField.TOTALLOSSAMOUNT1, ReportLossExternalDtoField.TOTALOSSAMOUNTONE);
		totalLossExternalMap.put(ReportLossDtoField.TOTALLOSSAMOUNT2, ReportLossExternalDtoField.TOTALLOSSAMOUNTTWO);
		totalLossExternalMap.put(ReportLossDtoField.ESTIMATEDTOTALLOSSAMOUNT, ReportLossExternalDtoField.ESTIMATEDTOTALLOSS);
		totalLossExternalMap.put(ReportLossDtoField.SALVAGEAMOUNT, ReportLossExternalDtoField.SALVAGEAMOUNT);
		totalLossExternalMap.put(ReportLossDtoField.SALVAGEBUYERNAME, ReportLossExternalDtoField.SALVAGEBUYERNAME);
		totalLossExternalMap.put(ReportLossDtoField.SALVAGESELLERNAME, ReportLossExternalDtoField.SLAVAGESELLERNAME);
	}

}
