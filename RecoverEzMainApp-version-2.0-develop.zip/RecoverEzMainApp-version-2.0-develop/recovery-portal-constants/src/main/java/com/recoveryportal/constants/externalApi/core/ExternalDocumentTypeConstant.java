package com.recoveryportal.constants.externalApi.core;

public class ExternalDocumentTypeConstant {
	public static final String POLICE_REPORT="Police report";
	public static final String GARAGE_INVOICE="Garage Invoice";
	public static final String DEBIT_NOTE="Debit Note";
	public static final String CREDIT_NOTE="Credit Note";
	public static final String SURVEY_REPORT="Survey Report Upload";

}
