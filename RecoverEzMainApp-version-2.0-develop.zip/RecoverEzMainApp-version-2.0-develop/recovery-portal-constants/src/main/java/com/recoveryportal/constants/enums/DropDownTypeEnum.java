package com.recoveryportal.constants.enums;

public enum DropDownTypeEnum {
	COMMON(1, "common"),
	CURRENCY(3, "currency");
	
	public int typeId;
	public String typeName;
	
	DropDownTypeEnum(int typeId, String typeName) {
		this.typeId = typeId;
		this.typeName = typeName;
	}
}
