package com.recoveryportal.constants.externalApi.core;


public class ReportLossExternalDtoField {
	//claimDetails
	public static final String STATUS= "status";

	//InsurerInfo AND ThirdPartyInfoExternalDto
	public static final String POLICYNUMBER="policyNumber";
	

	public static final String NAME = "name";
	

	//Vechile External dto
	public static final String REGISTRATION_NO ="registrationNo";

	public static final String MODEL="model";

	public static final String MAKE="make";

	public static final String REGISTRATION_TYPE="registrationType";

	public static final String PURCHASE_DATE="purchaseDate";

	public static final String SUM_INSURED="sumInsured";
	
	public static final String DUAL_CURRENCY = "dualCurrency";
      
	public static final String ID= "id";

	public static final String FNOL_NO = "fnolNo";



	public static final String DATE_OF_LOSS = "dateOfloss";

	public static final String DATE_OF_REPORTED = "dateOfReported";

	public static final String POLICE_REPORT_NO = "policeReportNo";

	public static final String INSURED_CLAIM_NO = "insuredClaimNo";

	public static final String THIRD_PARTY_CLAIM_NO = "thirdPartyClaimNo";
	  

	public static final String RESERVE_AMOUNT="reserveAmount";

	public static final String TOTAL_RESERVE_AMOUNT="totalReserveAmount";

	public static final String THIRD_PARTY_RESERVE_AMOUNT="thirdPartyReserveAmount";

	public static final String CLAIM_AMOUNT="claimAmount";

	public static final String SETTLE_AMOUNT="settleAmount";

	public static final String THIRD_PARTY_SETTLES_AMOUNT="thirdPartySettleAmount";	
	
	public static final String SPARE_PARTS="sparePartCost";	
	
	public static final String LABOUR_COSR="labourCost";	
	


	public static final String TYPE="type";

	public static final String ADDRESS_LOCATION="addressLocation";

	public static final String SURVEY_ALLOCATION_DATE="surveyAllocationDate";

	public static final String SURVEY_DUE_DATE="surveyDueDate";
	



	
	
	
	//Document List
	public static final String CATEGORY="category";
	public static final String DOCUMENT="document";
	public static final String DOC_REF_NO="docRefNo";
	public static final String DOCUMENT_URL="documentUrl";

	
	
	
	//entity variable name
	public static final String  INSURED_INFO= "insuredInfo";
	public static final String  THIRD_PARTY_INFO= "thirdPartyInfo";
	public static final String  GARAGE_INFO= "garageInfo";
	public static final String  COMPANY= "company";
	public static final String  VECHILE_INFO= "vehicleDetails";
	public static final String  TOTALLOSSDETAILS= "totalLossDetails";

	
	//TotalLoss External fields
	
	public static final String  ADJUSTORNAMEONE= "adjustorNameOne";
	public static final String  ADJUSTORNAMETWO= "adjustorNameTwo";
	public static final String  SURVEYDATEONE= "surveyDateOne";
	public static final String  SURVEYDATETWO= "surveyDateTwo";
	public static final String  TOTALOSSAMOUNTONE= "totalLossAmountOne";
	public static final String  TOTALLOSSAMOUNTTWO= "totalLossAmountTwo";
	public static final String  ESTIMATEDTOTALLOSS= "estimatedTotalLossAmount";
	public static final String  SLAVAGESELLERNAME= "salvageSellerName";
	public static final String  SALVAGEAMOUNT= "salvageAmount";
	public static final String  SALVAGEBUYERNAME= "salvageBuyerName";

	public static final String TOWING_CHARGE = "towingCharge";
	public static final String Police_Report_Fee = "policeReportFee";
	public static final String Inspection_Fee = "inspectionFee";
	public static final String Other_Expenses = "otherExpenses";
	public static final String Cash_Settlement = "cashSettlement";
	
}
