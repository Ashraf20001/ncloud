/*
\ * @author codeboard
 */
package com.recoveryportal.constants.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The Class ApplicationConstants.
 */
public class ApplicationConstants {
	
	public static final String DISABLE = "Disabled";



	public static final String ADMIN = "admin";

	public static final String ALL = "ALL";


	public static final String AUTHORIZATION = "Authorization";

	public static final String BEARER = "Bearer ";

	/**
	 * The Constant BETWEEN.
	 */
	public static final String BETWEEN = "BW";


	public static final String COMMA = ",";


	/**
	 * The Constant DEFAULT_FULL_DATE_FORMAT.
	 */
	public static final String DEFAULT_FULL_DATE_FORMAT = "MM/dd/yyyy HH:mm";


	/**
	 * The Constant DOT_REGEX.
	 */
	public static final String DOT_REGEX = "\\.";



	/**
	 * The Constant EMPTY_STRING.
	 */
	public static final String EMPTY_STRING = " ";

	/**
	 * The Constant EQUAL.
	 */
	public static final String EQUAL = "Equal";



	/**
	 * The Constant FILTER.
	 */
	public static final String FILTER = "FILTER";

	/**
	 * The Constant FILTER_TYPE_BOOLEAN.
	 */
	public static final String FILTER_TYPE_BOOLEAN = "Boolean";

	/**
	 * The Constant FILTER_TYPE_DATE.
	 */
	public static final String FILTER_TYPE_DATE = "Date";

	/**
	 * The Constant FILTER_TYPE_DOUBLE.
	 */
	public static final String FILTER_TYPE_DOUBLE = "Double";

	/**
	 * The Constant FILTER_TYPE_INTEGER.
	 */
	// ******* for common filter constants start
	public static final String FILTER_TYPE_INTEGER = "Integer";

	/**
	 * The Constant FILTER_TYPE_TEXT.
	 */
	public static final String FILTER_TYPE_TEXT = "String";


	/**
	 * The Constant GT.
	 */
	public static final String GT = "Gt";

	/**
	 * The Constant GTE.
	 */
	public static final String GTE = "Ge";

	/**
	 * The Constant IDENTITY.
	 */
	public static final String IDENTITY = "Identity";


	public static final String INACTIVE = "InActive";


	/**
	 * The Constant LIKE.
	 */
	public static final String LIKE = "Like";


	/**
	 * The Constant LT.
	 */
	public static final String LT = "Lt";

	/**
	 * The Constant LTE.
	 */
	public static final String LTE = "Le";


	/**
	 * The Constant MINUS_ONE.
	 */
	public static final String MINUS_ONE = "-1";


	/**
	 * The Constant ONE.
	 */
	public static final int ONE = 1;


	/**
	 * The Constant ORDERBY.
	 */
	public static final String ORDERBY = "orderBy";


	public static final String RLE_ACTIVE = "Active";
	
	public static final String  UR_Mapped= "Mapped";
	
	public static final String  UR_UnMapped= "UnMapped";


	/**
	 * The Constant ROUNDOFF.
	 */
	public static final String ROUNDOFF = "ROUNDOFF";

	public static final String SET_IDENTITY = "setIdentity";


	/**
	 * The Constant SLASH.
	 */
	public static final String SLASH = "/";

	/**
	 * The Constant SORTING.
	 */
	public static final String SORTING = "SORTING";
	// for common filter constants end *******\


	/**
	 * The Constant TOO_MANY_REQUEST_FOUND.
	 */
	public static final String TOO_MANY_REQUEST_FOUND = "Too Many Request found for the input URL : ";



	/**
	 * The Constant SEMI_COLON.
	 */
	public static final String WITHOUT_SPACE = "";

	/**
	 * The Constant ZERO.
	 */
	public static final int ZERO = 0;





	public static final String NULL = "null";

	public static final String LOCAL = "LOCAL";

	public static final String _USER = "USER";

	public static final String CLAIM = "CLAIM";



	/**
	 * WEBSOCKET ENDPOINT
	 */
	public static final String WEBSOCKET_ENDPOINT = "/topic/notification/";


	/**
	 * NOTIFICATION_RECIEVED
	 */
	public static final String NOTIFICATION_RECIEVED = "Notification Recieved";

	/**
	 * ADDITIONAL_EXPENSES
	 */
	public static final List<String> ADDITIONAL_EXPENSES = new ArrayList<>(Arrays.asList("policeReportFee",
			"towingCharge", "inspectionFee", "otherExpenses", "cashSettlement", "labourCost", "spareParts"));

	public static final String mandatoryAdditional="labourCost,spareParts";
	/**
	 * TOTAL_EXPENSES_AMOUNT
	 */
	public static final String TOTAL_EXPENSES_AMOUNT = "Total Expenses Amount";
	
	/**
	 * DEBIT_NOTE_PATH
	 */
	public static final String DEBIT_NOTE_PATH = "/DEBIT_NOTE.jrxml";
	
	/**
	 * DEBIT_NOTE_PATH
	 */
	public static final String CREDIT_NOTE_PATH = "/CREDIT_NOTE.jrxml";
	
	/**
	 * CREDIT_NOTE
	 */
	public static final String CREDIT_NOTE="Credit_Note";
	/**
	 * DEBIT_NOTE
	 */
	public static final String DEBIT_NOTE="Debit_Note";
	
	/**
	 * DECIMAL_ZERO
	 */
	public static final Double DECIMAL_ZERO = 0.0;
	/*
	 * Date formate contant.
	 */
	public static final String DEFAULT_DATE_FORMAT = "MM/dd/yyyy";
	/**
	 * DATABASE_DATE_FORMAT
	 */
	public static final String DATABASE_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
	
	/**
	 * CLAIM_NUMBER
	 */
	public static final String CLAIM_NUMBER = "CLAIM_NO";
	
	/**
	 * COMPANY_NAME
	 */
	public static final String COMPANY_NAME = "COMPANY_NAME";

	public static final String RECEIVABLE = "Receivables";
	public static final String PAYABLE = "Payables";
	public static final String HYPHEN = "—";
	
	public static final String NULLVALUE="N/A"; 
	
	public static final String REMINDER_TEMPLATE = "Claim CLAIM_NO has been in the State of [status] for More than Five hours";
	
	public static final String SCHEDULER = "SCHEDULER";
	

	public static final String CLAIM_HISTORY = "claim_history";


	public static final String REPORTS = "REPORT";
	
	public static final String RECEIVABLEAMT = "Total Receivable Amount";
	
	public static final String PAYABLEAMT = "Total Payable Amount";
	
	public static final String CROSSAMT = " Total Gross Amount";


	public static final String INSURANCE_COMPANY_CAP = "INSURANCE_COMPANY";


    public static final String INSURANCE_RP_TYPE="emInsLogo";
    
    public static final String ASSOCIATION_RP_TYPE="association";
    

	public static final int TEN = 10;
	

	public static final String CREDIT_NOTE_GENERATED = "CREDIT NOTE GENERATED";
	
	public static final String GROUP_REFERENCE_TYPE = "group";

	public static final String COMMENTS_ADDED = "comments_added";
	

	public static final String SAVE = "SAVE";

	public static final String DOCUMENTS = "documents";
	
	public static final String POLICE_REPORT = "Police report";
	
	public static final String _DEBIT_NOTE = "Debit Note";
	
	public static final String _CREDIT_NOTE = "Credit Note";
	
	public static final String SURVEY_REPORT = "Survey Report Upload";
	
	public static final String GARAGE_INVOICE = "Garage Invoice";
	
	public static final String SUCCESS_STATUS_CHANGE = "Status Changed Successfully";
	
	public static final String FAILED_STATUS_CHANGE = "Status Change failed";
	
	public static final String SEEK_CLARITY = "seek-clarification";
	
	public static final String REJECT = "reject";
	

	public static final String ACCEPTD = "ACCEPTED";
	
	public static final String PROVIDE_CLARITY = "provide-clarification";
	
	public static final String DISPUTE = "dispute";
	
	public static final String REOPEN = "reopen";
	
	public static final String DOWNLOAD_SLASH = "downloadFile/";
	
	public static final String VIEW = "VIEW";
	
	public static final String UNDER_SCORE = "_";
	

	public static final String SURVEY_REPORT_NAME = "Survey Report";
	public static final String ADD = "ADD";
	public static final String ADDED = "Added";
	public static final String GENERATED = "Generate";
	public static final String UPDATED = "Updated";
	public static final String REGENERATED = "Regenerated";
	public static final String NOTIFICATION_STAGE = "Notification Stage";
	public static final String INSURED_DETAILS="InsuredDetails";
	public static final String THIRD_PARTY_DETAILS="ThirdPartyDetails";
	public static final String LOSS_DETAILS="LossDetails";
	public static final String INSUREDETAILS="Insured Details";
	public static final String REGISTRATION_NO="inRegistrationNo";
	public static final String TP_DETAILS="TP Details";
	public static final String TP_POLICY_NO="tpPolicyNumber";
	public static final String TP_CLAIM_NO="tpClaimNo";
	public static final String TP_REG_NO="tpRegistrationNo";
	public static final String LD_POLICY_NO="ldPolicyNumber";
	public static final String LD_CLAIM_NO="ldClaimNumber";
	public static final String LD_POLICE_NO="ldPoliceReportNumber";
	public static final String LOSSDETAILS="Loss Details";
	public static final String EDIT_APPROVAL_LIMIT="Edit Approval Limit";
	public static final String ADD_APPROVAL_LIMIT="Add Approval Limit";
	public static final String ROLENAME="(role name)";
	public static final String DRAFT="Draft";
	public static final String SUBJECT="Your Password Has Been Reset";
	public static final String ASSOCIATION="Association";

	public static final String PAYMENT_FROM_INSURANCE_SUBMITTED_TO_INSURANCE="Payment From Insurance Submitted To Insurance";
	public static final String PAYMENT_FROM_INSURANCE_APPROVED_BY_INSURANCE="Payment From Insurance Approved By Insurance";
	public static final String PAYMENT_FROM_INSURANCE_REJECTED_BY_INSURANCE="Payment From Insurance Rejected By Insurance";

	public static final String PAYMENT_FROM_INSURANCE_SUBMITTED_TO_ASSOCIATION="Payment From Insurance Submitted To Association";
	public static final String PAYMENT_FROM_INSURANCE_APPROVED_BY_ASSOCIATION="Payment From Insurance Approved By Association";
	public static final String PAYMENT_FROM_INSURANCE_REJECTED_BY_ASSOCIATION="Payment From Insurance Rejected By Association";

	public static final String PAYMENT_FROM_ASSOCIATION_SUBMITTED_TO_INSURANCE="Payment From Association Submitted To Insurance";
	public static final String PAYMENT_FROM_ASSOCIATION_APPROVED_BY_INSURANCE="Payment From Association Approved By Insurance";
	public static final String PAYMENT_FROM_ASSOCIATION_REJECTED_BY_INSURANCE="Payment From Association Rejected By Insurance";

	public static final String PAYMENT_FROM_ASSOCIATION_APPROVED_BY_INSURANCE_TO_ALL="Payment From Insurance Approved By Association(send all mail)";



	public static final List<String> STATUS_FOR_NOTES = new ArrayList<>(Arrays.asList(RecoveryStatusConstant.CONFIRM_LIABLITY,RecoveryStatusConstant.LIABLITY_ACCEPTED, RecoveryStatusConstant.CLAIM_SETTLED));


	public static final Map<String, String> templateUpdates=new LinkedHashMap<>();

	public static final String NO_COMPANY_LOGO = "no_company_logo.jpg";
	public static final String DOT_PDF = ".pdf";

    public static final String INSURANCE = "Insurance";


	public static final String CONFIRMED = "Confirmed";


	public static final String INS_PAID = "Payment has been approved and the amount has been successfully credited to your wallet by (Insurance Company Name).";

	public static final String ASSOCIATION_PAID = "The (association name) has validated and confirmed the payment amount on your behalf. The funds have been successfully credited to (Not At Fault Company’s) wallet.";


	public static final String EXCEED_APPROVAL_LIMIT = "EXCEED APPROVAL LIMIT";

	public static final CharSequence MIN_AMOUNT = "(Min Amount)";


	public static final String MONTHLY_REPORT = "Monthly Report";
	
	public static final String PAYMENT_REMINDER = "Payment Reminder";
	
	public static final String RECOVEREZ_PLATFORM = "Recover EZ";
	

	public static final String WALLET_PAYMENT_REMINDER = "Wallet Payment Reminder";
	


	public static final String ASSOCIATION_ID = "associationId";
	

	public static final String _UPDATED = "Updated";

	public static final String TP_DETAILS_CLAIM_NO = "TP ClaimNo";
	
	
	public static final String _SAVED = "Saved";
	
	public static final String SPACE = " ";
	
	public static final String AUTO_GENERATE_REPORT_TYPE_FORMAT = "MMM-yyyy";
	
	public static final String AUTHORITY_PAID = "Authority Paid";

	public static final String INS_COMPANY_PAID = "Company Paid";
	
	public static final String SURVEY_AMOUNT = "Survey Amount";


	public static final String USER_TYPE = "user_type";
	public static final String RECEIVABLE_CLAIM= "receivable_claims";
	public static final String PAYABLE_CLAIM="payable_claims";

	public static final String KAFKA_TOPIC = "recovery_audit";

	public static final String ID ="id";

	public static final String USER_NAME = "user_name";

	public static final String EMAIL = "email";

	public static final String PLATFORM_IDENTITY = "platform_identity";

	public static final String PLATFORM_DETAILS = "platform_details";

	public static final String COMPANY_ID = "company_id";

	public static final String ALLOCATION_USER_TYPE = "allocationUserType";

	public static final String ROLES = "roles"; 
	
	public static final String GET_USER_COMPANY_MAPPING = "/company/get-company";
	
	public static final String GET_USER_COMPANY_BY_USER_ID = "/company/get-company-by-user";
	
	public static final String GET_USER_COMPANY_EMAIL_IDS = "/company/get-user-company-emailIds";
	
	public static final String GET_USER_LIST_FOR_NOTIFICATION = "/company/get-user-company-userListForNotification";
	
	public static final String GET_USER_PROFILE_BY_ASSOCIATION_ID = "/user-profile/get-association-profile";
	
	public static final String GET_USER_PROFILE_LIST_BY_ASSOCIATION_ID = "/user-profile/get-association-profile-list";
	
	public static final String GET_ALL_COMPANIES_FROM_COMMON = "/entitymanagement/get-all-company";
	
	public static final String GET_ALL_GARAGE_FROM_COMMON = "/entitymanagement/getGarageData";
	
	public static final String GET_ALL_OTHER_COMPANIES_FROM_COMMON = "/get-all-other-companiesList";
	
	public static final String GET_USER_COMPANY_LIST_DTO = "/company/get-users-by-companyId";
	
	public static final String GET_COMPANY_LOGO = "/company/get-logo-using-rptype";
	
	public static final String GET_ACCESS_DETAILS = "/get-access-details";
	
	public static final String GET_USER_FROM_USERID = "/user-profile/get-user-from-userId";
	
	public static final String GET_USER_FROM_USERNAME = "/user-profile/get-user-from-userName";
	
	public static final String GET_USER_FROM_ROLEIDS = "/user-profile/get-users-from-roleIds";
	
	public static final String GET_APPROVAL_LEVEL_FOR_KNOCK_CHECK ="/Approvallimit/get-approval-level-for-knockcheck";
	
	public static final String GET_APPROVAL_LEVEL_FOR_ROLE_LIMIT_CHECK ="/Approvallimit/get-approval-level-for-roleLimitCheck";
	
	public static final String GET_APPROVAL_LEVEL_FOR_ROLE_LIMIT ="/Approvallimit/get-approval-level-for-roleLimit";

	public static final String GET_ALL_COMPANY = "/get-allCompanyList";
	
	public static final String GET_ALL_COMPANYDTOS = "/get-allCompanyDtos";
	
	public static final String GET_COMPANY_FROM_COMPANY_NAME = "/get-company-from-companyName";
	
	public static final String GET_COMPANY_FROM_COMPANY_ID = "/get-company-from-companyId";
	
	public static final String GET_FILE_STORAGE_FROM_COMPANY_ID = "/get-file-storage-from-companyId";
	
	public static final String GET_COMPANIES_FROM_COMPANY_ID_LIST = "/get-companies-from-companyIdList";
	
	public static final String USER_ROLE_MAPPING  = "UserRoleMapping";
	
	public static final String GET_COMPANY_IDS_FROM_COMPANY_NAME_LIST = "/get-companyIds-from-companyNameList";

	public static final String STATUS_CHANGE = "status_change";

	public static final List<String> NEGATIVE_FLOW_STATUS = new ArrayList<>(Arrays.asList(
			"REOPEN",
			"DISPUTE",
			"DISPUTE REOPEN",
			"NEED MORE DETAILS",
			"DETAILS PROVIDED",
			"RECEIVED REJECTED NOTIFICATION",
			"NOTIFICATION REJECTED",
			"REJECTED","COMMENTS ADDED"));

	public static final String MIN="MIN";
	public static final String MAX="MAX";
	public static final String ROLE_NAME = "ROLENAME";
	public static final String CLAIM_ID = "claimId";
	public static final String NOTIFICATION_COMPANY_NAME = "companyName";
	public static final String STATUS_BRACED = "[STATUS]";
	public static final String REMINDER_BRACED = "[REMINDER]";
	public static final String TEMPLATE_PERIOD = "PERIOD";
	public static final String ASSOCIATION_NAME = "ASSOCIATION_NAME";
	public static final String REPOSITORY_IDENTITY = "repositoryIdentity";
	public static final String REPORT_TIME = "reportTime";
	public static final String TRIGGERED_STATUS = "triggeredStatus";
	public static final String MAIL_TEMPLATE = "/mail-template/";
	public static final String UPLOAD_REMINDER_FTL = "upload-reminder.ftl";
	public static final String REPOSITORY = "repository";
	public static final String UPLOAD_REMINDER = "Upload Reminder";

	private ApplicationConstants() {
		}

    static {
    	templateUpdates.put(ADDED, UPDATED);
    	templateUpdates.put(GENERATED, REGENERATED);
    }

}