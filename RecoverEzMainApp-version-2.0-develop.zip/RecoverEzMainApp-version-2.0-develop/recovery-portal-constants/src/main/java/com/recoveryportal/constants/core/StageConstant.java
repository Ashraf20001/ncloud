package com.recoveryportal.constants.core;

public class StageConstant {
public static final String NOTIFICATION_STAGE="Notification Stage";
public static final String CLAIM_INSPECTION_STAGE="Claim Inspection Stage";
public static final String LIABILITY_CONFIRMATION_STAGE="Liability Confirmation Stage";
public static final String SETTLEMENT_STAGE="Settlement Stage";
}
