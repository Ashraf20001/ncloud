package com.recoveryportal.constants.core;

public class RoleConstant {
	 public static final String SURVEYOR="surveyor";
}
