package com.recoveryportal.constants.core;

public class PlatformConstants {

    public static final String RECOVEREZ_PLATFORM = "Recover EZ";

}
