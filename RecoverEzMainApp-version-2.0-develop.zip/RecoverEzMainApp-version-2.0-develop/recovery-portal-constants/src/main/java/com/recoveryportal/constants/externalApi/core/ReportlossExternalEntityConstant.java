package com.recoveryportal.constants.externalApi.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ReportlossExternalEntityConstant {
	public static final Map<String,String> entityNameMap=new LinkedHashMap();
	public static final String COLON=":";
	static {
		//tpinfo
		entityNameMap.put(ReportLossExternalDtoField.THIRD_PARTY_INFO+COLON+ReportLossExternalDtoField.NAME, ReportLossDtoField.TP_NAME);
		entityNameMap.put(ReportLossExternalDtoField.THIRD_PARTY_INFO+COLON+ReportLossExternalDtoField.POLICYNUMBER, ReportLossDtoField.TP_POLICY_NUMBER);
		entityNameMap.put(ReportLossExternalDtoField.THIRD_PARTY_INFO+COLON+ReportLossExternalDtoField.REGISTRATION_NO,ReportLossDtoField.TP_REGISTRATION_NO);
		entityNameMap.put(ReportLossExternalDtoField.THIRD_PARTY_INFO+COLON+ReportLossExternalDtoField.MAKE,ReportLossDtoField.TP_MAKE);
		entityNameMap.put(ReportLossExternalDtoField.THIRD_PARTY_INFO+COLON+ReportLossExternalDtoField.MODEL,ReportLossDtoField.TP_MODEL);

		entityNameMap.put(ReportLossExternalDtoField.INSURED_INFO+COLON+ReportLossExternalDtoField.NAME, ReportLossDtoField.IN_INSURER_NAME);
		entityNameMap.put(ReportLossExternalDtoField.INSURED_INFO+COLON+ReportLossExternalDtoField.POLICYNUMBER, ReportLossDtoField.LD_POLICY_NUMBER);
		entityNameMap.put(ReportLossExternalDtoField.INSURED_INFO+COLON+ReportLossExternalDtoField.REGISTRATION_NO,ReportLossDtoField.IN_REGISRATION_NO);
		entityNameMap.put(ReportLossExternalDtoField.INSURED_INFO+COLON+ReportLossExternalDtoField.MAKE,ReportLossDtoField.IN_MAKE);
		entityNameMap.put(ReportLossExternalDtoField.INSURED_INFO+COLON+ReportLossExternalDtoField.MODEL,ReportLossDtoField.IN_MODEL);

		
		//GARAGENAME
		entityNameMap.put(ReportLossExternalDtoField.GARAGE_INFO+COLON+ReportLossExternalDtoField.NAME,ReportLossDtoField.GARAGE_NAME);
		entityNameMap.put(COLON + ReportLossExternalDtoField.SETTLE_AMOUNT,ReportLossDtoField.RD_CLAIM_AMOUNT);
		entityNameMap.put(COLON + ReportLossExternalDtoField.THIRD_PARTY_RESERVE_AMOUNT,ReportLossDtoField.RR_RESERVE_AMOUNT);

		entityNameMap.put(ReportLossExternalDtoField.THIRD_PARTY_RESERVE_AMOUNT,ReportLossDtoField.RR_RESERVE_AMOUNT);
		
		//police report
		entityNameMap.put(ExternalDocumentTypeConstant.POLICE_REPORT+COLON+ReportLossExternalDtoField.DOCUMENT,ReportLossDtoField.PR_DOCUMENT_UPLOAD);
		entityNameMap.put(ExternalDocumentTypeConstant.POLICE_REPORT+COLON+ReportLossExternalDtoField.ID,ReportLossDtoField.PR_POLICE_REPORTID);
		entityNameMap.put(ExternalDocumentTypeConstant.POLICE_REPORT+COLON+ReportLossExternalDtoField.NAME,ReportLossDtoField.PR_DOCUMENT_UPLOAD);
		entityNameMap.put(ExternalDocumentTypeConstant.POLICE_REPORT+COLON+ReportLossExternalDtoField.DOCUMENT_URL,ReportLossDtoField.PR_DOCUMENT_UPLOAD);
		
		//DEBIT NOTE
		entityNameMap.put(ExternalDocumentTypeConstant.DEBIT_NOTE+COLON+ReportLossExternalDtoField.DOCUMENT_URL,ReportLossDtoField.DN_DEBITNOTE_DOCUMENT);
		entityNameMap.put(ExternalDocumentTypeConstant.DEBIT_NOTE+COLON+ReportLossExternalDtoField.DOCUMENT,ReportLossDtoField.DN_DEBITNOTE_DOCUMENT);
		entityNameMap.put(ExternalDocumentTypeConstant.DEBIT_NOTE+COLON+ReportLossExternalDtoField.DOC_REF_NO,ReportLossDtoField.DN_DEBITNOTE_NUMBER);
		entityNameMap.put(ExternalDocumentTypeConstant.DEBIT_NOTE+COLON+ReportLossExternalDtoField.ID,ReportLossDtoField.DN_DEBITNOTE_ID);

		//CREDIT NOTE
		entityNameMap.put(ExternalDocumentTypeConstant.CREDIT_NOTE+COLON+ReportLossExternalDtoField.DOCUMENT_URL,ReportLossDtoField.CN_CREDITNOTE_DOCUMENT);
		entityNameMap.put(ExternalDocumentTypeConstant.CREDIT_NOTE+COLON+ReportLossExternalDtoField.DOCUMENT,ReportLossDtoField.CN_CREDITNOTE_DOCUMENT);
		entityNameMap.put(ExternalDocumentTypeConstant.CREDIT_NOTE+COLON+ReportLossExternalDtoField.DOC_REF_NO,ReportLossDtoField.CN_CREDITNOTE_NUMBER);
		entityNameMap.put(ExternalDocumentTypeConstant.CREDIT_NOTE+COLON+ReportLossExternalDtoField.ID,ReportLossDtoField.CN_CREDITNOTE_ID);

		//GARAGE INVOICE
		entityNameMap.put(ExternalDocumentTypeConstant.GARAGE_INVOICE+COLON+ReportLossExternalDtoField.DOCUMENT_URL,ReportLossDtoField.GI_DOCUMENT);
		entityNameMap.put(ExternalDocumentTypeConstant.GARAGE_INVOICE+COLON+ReportLossExternalDtoField.NAME,ReportLossDtoField.GI_DOCUMENT);
		entityNameMap.put(ExternalDocumentTypeConstant.GARAGE_INVOICE+COLON+ReportLossExternalDtoField.DOCUMENT,ReportLossDtoField.GI_DOCUMENT);
		
		//survey report
		entityNameMap.put(ExternalDocumentTypeConstant.SURVEY_REPORT+COLON+ReportLossExternalDtoField.DOCUMENT_URL,ReportLossDtoField.SR_SURVEY_REPORT_UPLOAD);
		entityNameMap.put(ExternalDocumentTypeConstant.SURVEY_REPORT+COLON+ReportLossExternalDtoField.NAME,ReportLossDtoField.SR_SURVEY_REPORT_UPLOAD);
		entityNameMap.put(ExternalDocumentTypeConstant.SURVEY_REPORT+COLON+ReportLossExternalDtoField.DOCUMENT,ReportLossDtoField.SR_SURVEY_REPORT_UPLOAD);


		
		
		
	}

}
