package com.recoveryportal.constants.core;

public class FileUploadTypeConstant {
	 public static final String CLAIM="CLAIM";
}
