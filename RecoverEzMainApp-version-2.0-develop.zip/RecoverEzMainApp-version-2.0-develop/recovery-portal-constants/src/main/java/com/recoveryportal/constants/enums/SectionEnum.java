package com.recoveryportal.constants.enums;

public enum SectionEnum {
	Insured_Details,
	TP_Details,
	Loss_Details,
	Police_Report,
	Garage_Details,
	Survey_Details,
	Survey_Report,
	Recovery_Details,
	Reserve_Review,
	Garage_Invoice,
	Debit_Note,
	Credit_Note
	
}
