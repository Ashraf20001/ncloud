package com.recoveryportal.constants.externalApi.core;

import java.util.HashMap;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.recoveryportal.constants.core.RecoveryStatusConstant;


@Component
public class GetActionButtonFromStatus {
	final String COLON = ":";
	final String ACCEPT = "accept";
	final String REJECT = "reject";
	final String DISPUTE = "dispute";
	final String DISPUTE_REOPEN = "reopen";
	final String T1 = "type1";
	final String T2 = "type2";
	final String NEED_INFO = "seek-clarification";
	final String DETAILS_PROVIDED = "provide-clarification";
	final boolean TRUE = true;
	final boolean FALSE = false;
	final String VIEW = "VIEW";
	final String SAVE = "SAVE";
	final String APPROVED = "APPROVED";
	final String ACCEPTED = "ACCEPTED";
	final String NEED_MORE_DETAILS = "NEED_MORE_DETAILS";
	final String DETAILS_PROVIDED_ = "DETAILS_PROVIDED";
	final String REJECTED = "REJECTED";
	final String REOPEN = "REOPEN";
	final String DISPUTE_ = "DISPUTE";
	final String DISPUTE_REOPEND = "DISPUTE_REOPEND";

	HashMap<String, String> getActionButton = new HashMap<>();
	
	@PostConstruct
	void constructActionButtonMap() {
		getActionButton.put(RecoveryStatusConstant.DRAFT+COLON+TRUE+COLON+ACCEPT, SAVE);
		getActionButton.put(RecoveryStatusConstant.NOTIFICATION_OPEN+COLON+FALSE+COLON+VIEW, VIEW);
		getActionButton.put(RecoveryStatusConstant.NOTIFICATION_RECEIVED+COLON+FALSE+COLON+ACCEPT, ACCEPTED);
		getActionButton.put(RecoveryStatusConstant.NOTIFICATION_ACCEPTED +COLON+TRUE+COLON+ACCEPT, SAVE);
		getActionButton.put(RecoveryStatusConstant.GS_DETAILS_UPDATED+COLON+FALSE+COLON+VIEW , VIEW);
		getActionButton.put(RecoveryStatusConstant.MOVED_INSPECTION+COLON+FALSE+COLON+VIEW , VIEW);
		getActionButton.put(RecoveryStatusConstant.UNDER_INSPECTION+COLON+FALSE+COLON+ACCEPT, SAVE);
		getActionButton.put(RecoveryStatusConstant.EXPENSES_AND_DOCUMENT_UPDATED+COLON+TRUE+COLON+VIEW , VIEW);
		getActionButton.put(RecoveryStatusConstant.RECEIVED_LIABILITY+COLON+TRUE+COLON+ACCEPT , SAVE);
		getActionButton.put(RecoveryStatusConstant.LIABLITY_REVIEW+COLON+FALSE+COLON+ACCEPT, ACCEPTED);
		getActionButton.put(RecoveryStatusConstant.LIABLITY_ACCEPTED+COLON+TRUE+COLON+ACCEPT , SAVE);
		getActionButton.put(RecoveryStatusConstant.CONFIRM_LIABLITY+COLON+FALSE+COLON+ACCEPT , APPROVED);
		
		getActionButton.put(RecoveryStatusConstant.TOTALLOSS_INITITED+COLON+FALSE+COLON+VIEW, VIEW);
		getActionButton.put(RecoveryStatusConstant.NOTIFICATION_RECEIVED+COLON+FALSE+COLON+NEED_INFO , NEED_MORE_DETAILS);
		getActionButton.put(RecoveryStatusConstant.DETAILS_PROVIDED+COLON+FALSE+COLON+DETAILS_PROVIDED , ACCEPTED);
		
		getActionButton.put(RecoveryStatusConstant.NOTIFICATION_RECEIVED+COLON+FALSE+COLON+REJECT , REJECTED);
		getActionButton.put(RecoveryStatusConstant.NOTIFICATION_REJECTED+COLON+TRUE+COLON+VIEW , VIEW);
		getActionButton.put(RecoveryStatusConstant.RECEIVED_REJECTED_NOTIFICATION+COLON+TRUE+COLON+ACCEPT , REOPEN);
		getActionButton.put(RecoveryStatusConstant.REOPEN+COLON+FALSE+COLON+VIEW , VIEW);
		
		getActionButton.put(RecoveryStatusConstant.NEEDMOREDETAIL+COLON+TRUE+COLON+DETAILS_PROVIDED , DETAILS_PROVIDED_);
		getActionButton.put(RecoveryStatusConstant.DETAILS_PROVIDED+COLON+FALSE+COLON+NEED_INFO , NEED_MORE_DETAILS);
		
		getActionButton.put(RecoveryStatusConstant.DETAILS_PROVIDED+COLON+FALSE+COLON+REJECT , REJECTED);
		
		getActionButton.put(RecoveryStatusConstant.RECEIVED_LIABILITY+COLON+TRUE+COLON+NEED_INFO , NEED_MORE_DETAILS);
		getActionButton.put(RecoveryStatusConstant.NEEDMOREDETAIL+COLON+FALSE+COLON+DETAILS_PROVIDED , DETAILS_PROVIDED_);
		getActionButton.put(RecoveryStatusConstant.DETAILS_PROVIDED+COLON+TRUE+COLON+VIEW , VIEW);
		
		getActionButton.put(RecoveryStatusConstant.LIABLITY_REVIEW+COLON+FALSE+COLON+NEED_INFO , NEED_MORE_DETAILS);
		getActionButton.put(RecoveryStatusConstant.DETAILS_PROVIDED+COLON+FALSE+COLON+VIEW , VIEW);
		
		getActionButton.put(RecoveryStatusConstant.CONFIRM_LIABLITY+COLON+FALSE+COLON+NEED_INFO , NEED_MORE_DETAILS);
		
		getActionButton.put(RecoveryStatusConstant.DETAILS_PROVIDED+COLON+FALSE+COLON+ACCEPT , APPROVED);
		
		getActionButton.put(RecoveryStatusConstant.MOVED_INSPECTION+COLON+FALSE+COLON+NEED_INFO , NEED_MORE_DETAILS);
		
		getActionButton.put(RecoveryStatusConstant.DEBIT_NOTE_GENERATED+COLON+FALSE+COLON+NEED_INFO , NEED_MORE_DETAILS);
		
		getActionButton.put(RecoveryStatusConstant.RECEIVED_LIABILITY+COLON+TRUE+COLON+DISPUTE , DISPUTE_);
		getActionButton.put(RecoveryStatusConstant.DISPUTE+COLON+TRUE+COLON+DISPUTE_REOPEN , DISPUTE_REOPEND);
		getActionButton.put(RecoveryStatusConstant.DISPUTE_REOPEN+COLON+FALSE+COLON+VIEW , VIEW);
		
		getActionButton.put(RecoveryStatusConstant.LIABLITY_REVIEW+COLON+FALSE+COLON+DISPUTE , DISPUTE_);
		getActionButton.put(RecoveryStatusConstant.DISPUTE+COLON+FALSE+COLON+DISPUTE_REOPEN , DISPUTE_REOPEND);
		getActionButton.put(RecoveryStatusConstant.DISPUTE_REOPEN+COLON+TRUE+COLON+VIEW , VIEW);
		
		getActionButton.put(RecoveryStatusConstant.DEBIT_NOTE_GENERATED+COLON+FALSE+COLON+DISPUTE , DISPUTE_);
		
		getActionButton.put(RecoveryStatusConstant.CONFIRM_LIABLITY+COLON+FALSE+COLON+DISPUTE , DISPUTE_);
		
		getActionButton.put(RecoveryStatusConstant.UNDER_INSPECTION+COLON+TRUE+COLON+ACCEPT , SAVE);
		getActionButton.put(RecoveryStatusConstant.MOVED_INSPECTION+COLON+FALSE+COLON+ACCEPT , SAVE);

		//totalLoss
		getActionButton.put(RecoveryStatusConstant.UNDER_INSPECTION+COLON+FALSE+COLON+ACCEPT+T1 , SAVE);
		getActionButton.put(RecoveryStatusConstant.MOVED_INSPECTION+COLON+FALSE+COLON+ACCEPT+T1 , SAVE);
		getActionButton.put(RecoveryStatusConstant.MOVED_INSPECTION+COLON+FALSE+COLON+VIEW+T1 , VIEW);
		getActionButton.put(RecoveryStatusConstant.TOTALLOSS_INITITED+COLON+TRUE+COLON+ACCEPT+T1 , ACCEPTED);
		getActionButton.put(RecoveryStatusConstant.TOTALLOSS_ACCEPTED+COLON+FALSE+COLON+ACCEPT+T1 , ACCEPTED);
		getActionButton.put(RecoveryStatusConstant.LIABLITY_REVIEW+COLON+TRUE+COLON+VIEW+T1 , VIEW);
		getActionButton.put(RecoveryStatusConstant.DEBIT_NOTE_GENERATED+COLON+FALSE+COLON+ACCEPT+T1 , APPROVED);
		
		getActionButton.put(RecoveryStatusConstant.UNDER_INSPECTION+COLON+FALSE+COLON+ACCEPT+T2 , SAVE);
		getActionButton.put(RecoveryStatusConstant.MOVED_INSPECTION+COLON+FALSE+COLON+ACCEPT+T2 , SAVE);
		getActionButton.put(RecoveryStatusConstant.MOVED_INSPECTION+COLON+FALSE+COLON+VIEW+T2, VIEW);
		getActionButton.put(RecoveryStatusConstant.TOTALLOSS_INITITED+COLON+TRUE+COLON+VIEW+T2 , VIEW);
		getActionButton.put(RecoveryStatusConstant.SURVEYOR_ASSIGNED+COLON+FALSE+COLON+ACCEPT+T2 , ACCEPTED);
		getActionButton.put(RecoveryStatusConstant.LIABLITY_REVIEW+COLON+TRUE+COLON+VIEW+T2 , VIEW);
		getActionButton.put(RecoveryStatusConstant.DEBIT_NOTE_GENERATED+COLON+FALSE+COLON+ACCEPT+T2 , APPROVED);

	}
	
	public String getStatus(String status){
		return getActionButton.get(status);
	}

}
