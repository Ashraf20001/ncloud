package com.recoveryportal.constants.enums;

public enum PaymentModeEnum {
	CASH(1,"CASH"),
	CHEQUE(2,"CHEQUE"),
	CREDITCARD(3,"CREDIT CARD"),
	NETBANKING(4,"NET BANKING"),
	UPI(5,"UPI"),
	BONUS(6,"BONUS"),
	PAID(7,"PAID"),
	AIRTELMONEY(8,"AIRTEL MONEY"),
	DEBITCARD(9,"DEBIT CARD");



	Integer id;
	String paymentMode;

	private PaymentModeEnum(Integer id, String paymentMode) {
		this.id = id;
		this.paymentMode = paymentMode;
	}


	public Integer getId() {
		return id;
	}


	public String getPaymentMode() {
		return paymentMode;
	}


	public static Integer getPaymentModeByValue(String value){

		for (PaymentModeEnum paymentMode : PaymentModeEnum.values()) {
			if (paymentMode.name().equalsIgnoreCase(value)) {
				return paymentMode.getId();
			}
		}
		return null;
	}

	public static PaymentModeEnum getPaymentModeById(Integer value){

			for (PaymentModeEnum paymentMode : PaymentModeEnum.values()) {
				if (paymentMode.ordinal() + 1 == value) {
					return paymentMode;
				}
			}
			return null;
		}
	
	public static PaymentModeEnum getPaymentModeByValues(String value){

		for (PaymentModeEnum paymentMode : PaymentModeEnum.values()) {
			if (paymentMode.paymentMode.equalsIgnoreCase(value)) {
				return paymentMode;
			}
		}
		return null;
	}

}
