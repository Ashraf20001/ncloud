package com.recoveryportal.constants.core;

public class RecoveryStatusConstant {

	public static final String NOTIFICATION_OPEN = "Notification Open";
	public static final String REOPEN = "Reopen";
	public static final String DRAFT = "Draft";
	public static final String NOTIFICATION_RECEIVED = "Notification Received";
	public static final String NOTIFICATION_ACCEPTED = "Notification Accepted";
	public static final String NOTIFICATION_REJECTED = "Notification Rejected";
	public static final String GS_DETAILS_UPDATED = "Garage And Survey Details Updated";
	public static final String MOVED_INSPECTION = "Moved To Inspection";
	public static final String UNDER_INSPECTION = "Under Inspection";
	public static final String RECEIVED_LIABILITY = "Received Liability";
    public static final String LIABLITY_ACCEPTED = "Liability Accepted";
	public static final String LIABLITY_REVIEW="Liability Review";
	public static final String CLAIM_SETTLED = "Claim Settled";
	public static final String CONFIRM_LIABLITY = "Confirmed Liability";
	public static final String DEBIT_NOTE_GENERATED = "Debit Note Generated";
	public static final String EXPENSES_AND_DOCUMENT_UPDATED = "Expenses And Document Updated";
	public static final String NEEDMOREDETAIL = "Need More Details";
	public static final String DETAILS_PROVIDED = "Details Provided";
	public static final String RECEIVED_REJECTED_NOTIFICATION = "Received Rejected Notification";
	public static final String DISPUTE = "Dispute";
	public static final String DISPUTE_REOPEN = "Dispute Reopen";

	public static final String TOTALLOSS_INITITED = "Total Loss Initiated";
	public static final String TOTALLOSS_ACCEPTED = "Total Loss Accepted";
	public static final String SURVEYOR_ASSIGNED = "Surveyor Assigned";
	public static final String DEFAULT = "Default";
	public static final String KNOCKTOKNOCK = "Knock For Knock";
	public static final String PAID = "Paid";
	public static final String TOTAL_LOSS_DEBIT_NOTE_GENERATED = "Total Loss Debit Note Generated";
}
