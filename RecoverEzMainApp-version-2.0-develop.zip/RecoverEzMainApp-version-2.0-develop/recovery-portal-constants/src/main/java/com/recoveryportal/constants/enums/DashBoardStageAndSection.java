package com.recoveryportal.constants.enums;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.recoveryportal.constants.core.RecoveryStatusConstant;

public enum DashBoardStageAndSection {

	NOTIFICATION_STAGE(RecoveryStatusConstant.DRAFT + "," + RecoveryStatusConstant.NOTIFICATION_OPEN + ","
			+ RecoveryStatusConstant.NOTIFICATION_RECEIVED + "," + RecoveryStatusConstant.NOTIFICATION_ACCEPTED),
	
	CLAIM_INSPECTION_STAGE(RecoveryStatusConstant.MOVED_INSPECTION + "," + RecoveryStatusConstant.UNDER_INSPECTION + ","
			+ RecoveryStatusConstant.GS_DETAILS_UPDATED + "," + RecoveryStatusConstant.EXPENSES_AND_DOCUMENT_UPDATED
			+ "," + RecoveryStatusConstant.TOTALLOSS_INITITED + "," + RecoveryStatusConstant.TOTALLOSS_ACCEPTED + ","
			+ RecoveryStatusConstant.SURVEYOR_ASSIGNED),
	
	LIABILITY_CONFIRMATION_STAGE(RecoveryStatusConstant.RECEIVED_LIABILITY + ","
			+ RecoveryStatusConstant.LIABLITY_REVIEW + "," + RecoveryStatusConstant.LIABLITY_ACCEPTED),
	
	SETTLEMENT_STAGE(RecoveryStatusConstant.CONFIRM_LIABLITY + "," + RecoveryStatusConstant.DEBIT_NOTE_GENERATED + ","
			+ RecoveryStatusConstant.CLAIM_SETTLED + "," + RecoveryStatusConstant.PAID + "," + RecoveryStatusConstant.KNOCKTOKNOCK);

	public List<String> statusList;
	
	private DashBoardStageAndSection(String statusArr) {
		this.statusList= Arrays.asList(statusArr.split(","));

	}
}
