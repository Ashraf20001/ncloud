package com.recoveryportal.constants.core;

public class LoginUserType {
public static final boolean RECEIVABLE=true;
public static final boolean PAYABLE=false;

}
