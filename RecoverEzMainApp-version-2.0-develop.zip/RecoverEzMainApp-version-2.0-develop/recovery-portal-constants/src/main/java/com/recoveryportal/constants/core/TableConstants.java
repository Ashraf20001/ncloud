package com.recoveryportal.constants.core;

public class TableConstants {
	public static final String CURRENCY_TYPE="Currency Type";
	
	public static final String NOT_TP_INS_COMPANY="Not At Fault Company";

	public static final String LOGIN_CAPTCHA_CHECK="login_captcha_check";
	public static final String REPORTLOSS = "report_loss";
	public static final String IDENTITY = "identity";
	public static final String CLAIM_ID = "claimId";
	public static final String STORAGE_DATA = "storage_data";
	public static final String REF_ID="referenceId";
	public static final String RP_TYPE="reportType";
	public static final String IS_VIEWED = "isViewed";
	public static final String COMMENT_ID = "commentId";

	public static final String ISDELETED = "isDeleted";
	public static final String CLAIM_SUMMARY_DETAILS = "claim_summary_details";
	public static final String CLAIM_SUMMARY_DETAILS_DELETED = "claim_summary_details deleted successfully";
	public static final String CLAIM_SUMMARY_DETAILS_DELETE_FAILED = "claim_summary_details failed to delete";
    public static final String COMPANY_ID = "companyId";
    public static final String INSURED_INFO = "insuredInfo";
	public static final String COMPANY = "company";
	public static final String THIRD_PARTY_INFO = "thirdPartyInfo";
	public static final String MODIFIED_DATE = "modifiedDate";
	public static final String STATE = "state";
	public static final String COMPANY_NAME = "name";
	public static final String MODIF_DATE = "modified_date";
    public static final String FIELD = "field";
    public static final String NAME = "name";
    public static final String DROP_DOWN = "Dropdown";
    public static final String BULK_IMPORT_MAPPING = "bulk_import_mapping";

    public static final String CREATED_DATE ="createdDate";

    public static final String RL_VEHICLE_DETAILS = "rl_vehicle_details";

    public static final String REPORT_CARD = "report_card";

    public static final String COMMENTS="comments";
    public static final String RL_INSURED_INFO = "rl_insured_info";
    public static final String RL_THIRD_PARTY_INFO = "rl_third_party_info";
    public static final String RL_LOSS_DETAILS = "rl_loss_details";
    public static final String RL_POLICE_REPORT = "rl_police_report";
    public static final String RL_GARAGE_DETAILS = "rl_garage_details";
    public static final String RL_SURVEY_DETAILS = "rl_survey_details";
    public static final String RL_SURVEY_REPORT = "rl_survey_report";
    public static final String RL_RECOVERY_DETAILS = "rl_recovery_details";
    public static final String RL_RESERVE_REVIEW = "rl_reserve_review";
    public static final String RL_GARAGE_INVOICE = "rl_garage_invoice";
    public static final String RL_DEBIT_NOTE = "rl_debit_note";
    public static final String RL_CREDIT_NOTE = "rl_credit_note";
	public static final String RL_II_INSURER_COMPANY = "insurerCompany";
	public static final String RL_TPI_TP_COMPANY = "tpCompany";
	public static final String IN_SURED_NAME = "insuredName";

	public static final String LAST_STATUS = "lastStatus";
	public static final String REFERENCE_ID = "referenceId";
	public static final String REPORT_TYPE = "reportType";
	public static final String UPLOAD_TYPE = "uploadType";

	public static final String TOTAL_LOSS = "total_loss";
	public static final String TOTAL_LOSS_REPORT_LOSS = "reportLoss";
	public static final String ID = "id";
	
	
    /** 
	 * Report Selected Columns
	 */
	
	public static final String INSURED_NAME = "Insured Name";
	public static final String CLAIM_NO_INS = "Claim No.Of Insured Company";
	public static final String CLAIM_NO_TP = "Claim No.Of Tp Company";
	public static final String POLICY_NO_INS = "Policy No.Of Insured Company";
	public static final String POLICY_NO_TP = "Policy No.Of Tp Company";
	public static final String INSURED_INS_COMPANY = "Not At Fault Company";
	public static final String TP_INS_COMPANY = "At Fault Company";
	public static final String CLAIM_NO = "Claim Number";
	public static final String INS_REG_NO = "Insured Registration Number";
	public static final String TP_REG_NO = "Tp Registration Number";
	public static final String TOTAL_LOSS_AMOUNT = "Total Loss Amount";
	public static final String REC_RESERVE_AMOUNT = "Receivable Reserve Amount";
	public static final String REC_CLAIM_AMOUNT = "Receivable Claim Amount";
	public static final String PAY_CLAIM_AMOUNT = "Payable Claim Amount";
	public static final String CREDIT_NOTE_INS_COMPANY= "Credit Note Of Insured Company";
	public static final String DEBIT_NOTE_INS_COMPANY = "Debit Note Of Insured Company";
	public static final String CREDIT_NOTE_TP_COMPANY = "Credit Note Of Tp Company";
	public static final String DEBIT_NOTE_TP_COMAPNY = "Debit Note Of Tp Company";
	
	/** 
	 * ReportLossviewDto
	 */

	public static final String CLAIMID = "claimId";

	public static final String TP_NAME = "tpName";

	public static final String SR_SPARE_PARTS = "srSpareParts";
	public static final String SR_LABOUR_COST = "srLabourCost";

	public static final String RECOVERY_DETAILS_ID = "recoveryDetailsId";

    public static final String TP_DETAILS = "TP Details";
    public static final String MODIFIED_BY = "modifiedBy";
    public static final String DASHBOARD = "Dashboard";
	public static final String TOTAL_PAYABLE_AMOUNT = "Total Payable Amount";
	public static final String TOTAL_RECEIVABLE_AMOUNT = "Total Receivable Amount";
    public static final String RECOVERY_DETAILS = "recoveryDetails";
	public static final String CLAIM_AMOUNT = "claimAmount";
    public static final String CHART_COUNT = "Count";
    public static final String CHART_AMOUNT = "Amount";
    public static final String CHART_YEAR = "Year";
    public static final String CHART_MONTH = "Month";

	public static final String NOTIFICATION_EVENT = "notificationEvent";
	public static final String EVENT_NAME = "eventName";
	public static final String IS_DLT_STS = "isDeleted";
	public static final String NOTIFICATION_HISTORY = "notification_history";
	public static final String STATUS = "status";
	public static final String STATUS_REPORT = "Status";
	public static final String STORAGE_ID = "storageId";
	public static final String CREATEDATE = "created_date";
	public static final String CREATED_BY = "created_by";
	public static final String TO_NOTIFY = "toNotify";
	public static final String CLAIM_DETAILS = "claimDetails";
	public static final String IS_READ = "isRead";
	public static final String LAST_ACTED = "lastActed";
	
	
	public static final String CLAIM_HISTORY = "claim_history";
	public static final String FIELD_ID = "fieldId";
	public static final String SECTION_ID = "sectionId";
	public static final String PAGE_ID = "pageId";
	public static final String META_DATA = "meta_data";
	public static final String FIELD_OPTION_MAPPING = "field_option_mapping";
	public static final String DROP_DOWN_OPTIONS = "dropdown_options";
	
	public static final int MAX_DATA_LIMIT_FOR_BAR_CHART = 12;
	public static final int MAX_DATA_LIMIT_FOR_VERTICAL_BAR_CHART = 6;
	public static final int MAX_DATA_LIMIT_FOR_STACKED_BAR_CHART = 5;

    public static final String MENU_ID = "menuId";

	public static final String PAGE = "pageDetails";
	public static final String SECTION = "sectionDetails";
	public static final String FIELD_DETAILS = "fieldDetails";
	public static final String SECTION_NAME = "sectionName";
	public static final String STAGE_NAME = "stageName";
	public static final String STAGE = "stage";
	public static final String TEMPLATE_SECTION = "section";
	public static final String ACTION = "action";
	public static final String EVENTID = "eventId";
	public static final String IS_RECEIVABLE = "isReceivable";
	

	public static final String DATE = "Date";
	public static final String TYPE = "Type";


	public static final String ID_DEFAULT = "isDefault";
	public static final String ORDER_BY = "orderBy";
	public static final String PRIVILLEGE_PAGE_ID = "pageId";
    public static final String UPLOAD_ID = "uploadId";
    public static final String UPLOAD_DATA_ID = "identity";
    public static final String TOTAL_COUNT = "totalCount";
    public static final String FAILURE_COUNT = "failureCount";
    public static final String ERROR_DATA_DELETED = "Error Data Deleted SuccessFully";
    public static final String USER = "USER";
    public static final String LOCAL = "LOCAL";
	public static final String BULK_UPLOAD_REPORTLOSS = "BULK_UPLOAD_REPORTLOSS";
	public static final String BULK_IMPORT_HISTORY = "bulk_import_history";
    public static final String NEW = "New";
    public static final String URL = "url";
    public static final String BULK_IMPORT_FIELD_NAME = "bulkImportFieldName";



    /*
     * Approval Limit
     */

    public static final String BULK_IMPORT_ERROR_DATA = "bulk_import_error_data";
    
    public static final String REPORT_LOSS_UPLOAD_DATA = "report_loss_upload_data";

    //bulk-upload-consumer-path
    
    public static final String BULK_UPLOAD_PROCESS = "/api/auth/process-upload/bulk-upload";
	
	public static final String ERR_TOTALLOSSESTIMATED_MAX="TotalLossEstimatedAmountMax";
	public static final String ERR_RESERVEAMOUNT_MAX="ReserveAmountMax";
	public static final String ERR_SUMINSURED_MAX="SumInsuredMax";
	public static final String ERR_CLAIMANOUNT_MAX="ClaimAmountMax";
	public static final String ERR_TOTALCALIMAMOUNT_MAX="TotalClaimAmountMax";
	public static final String ERR_SURVEYAMOUNT_MAX="SurveyAmountMax";
	public static final String ERR_SURVEYAMOUNT_MIN="SurveyAmountMin";
	public static final String ERR_TPSURVEYAMOUNT_MAX="TPSurveyAmountMax";
	public static final String ERR_TPSURVEYAMOUNT_MIN="TPSurveyAmountMin";
	public static final String ERR_TOTALLOSSESTIMATED_MIN="TotalLossEstimatedAmountMin";
	public static final String ERR_RESERVEAMOUNT_MIN="ReserveAmountMin";
	public static final String ERR_SUMINSURED_MIN="SumInsuredMin";
	public static final String ERR_CLAIMANOUNT_MIN="ClaimAmountMin";
	public static final String ERR_TOTALCALIMAMOUNT_MIN="TotalClaimAmountMain";
	public static final String DROPDOWN_ID = "dropdownListId";

	//Exceed Approval Limit 
	
	public static final String ERR_EXCEED_TOTALLOSSESTIMATED_MAX="TotalLossEstimatedAmount";
	public static final String ERR_EXCEED_RESERVEAMOUNT_MAX="ReserveAmount";
	public static final String ERR_EXCEED_SUMINSURED_MAX="SumInsured";
	public static final String ERR_EXCEED_CLAIMANOUNT_MAX="ClaimAmount";
	public static final String ERR_EXCEED_TOTALCALIMAMOUNT_MAX="TotalClaimAmount";
	public static final String ERR_EXCEED_SURVEYAMOUNT_MAX="SurveyAmount";
	public static final String ERR_EXCEED_TPSURVEYAMOUNT_MAX="TPSurveyAmount";
	
	public static final String DROPDOWNLIST = "dropDownList";
	public static final String DROPDOWNLIST_ID = "dropdownListId";
	public static final String DROPDOWNLISTID = "dropDownListId";
	public static final String DROPDOWN_OPTIONS = "dropDownOptionsId";
	public static final String DROPDOWN_OPTIONS_PARENT_ID = "parant_option";
	public static final String DROPDOWN_OPTIONS_NAME = "dropdownOption";
	
	public static final String FIELD_DROPDOWN_LIST_MAP = "field_dropdown_map";
	
	public static final String RECEIVALE = "Receivable";
	public static final String PAYABLE = "Payable";
	
	public static final String CONTENT = "content";
	public static final String DOCUMENT_URL = "url";

	public static final String LOSS_DETAILS = "lossDetails";
	public static final String CLAIM_NUMBER = "claimNumber";
	public static final String CLAIM_SEQUENCE = "claimSequenceId";
	public static final String TRIGGERED_STATUS = "triggeredStatus";
	public static final String SCHEDULER_ID = "schedularId";
	public static final String NOTIFICATION_NAME = "notificationName";
	public static final String REMAINDER="remainder";
	// BUlk Import Field Validation Error Messages

	public static final String ERMSG_EMPTY_EXCEL_FILE = "No Data to process";
	public static final String ERMSG_MANDATORY_FIELD = "Mandatory Field Not Entered";
	public static final String ERMSG_INVALID_FORMAT = "Invalid Format, Type should be ";
	public static final String ERMSG_MIN_LENGTH = "Minimum length should be ";
	public static final String ERMSG_MAX_LENGTH = "Maximum length should be ";
	public static final String ERMSG_INVALID_CHARACTER = "Invalid character in ";
	public static final String ERMSG_INVALID_DATE_FORMAT = "Invalid Date format ";
	public static final String ERMSG_INVALID_DATA = "Invalid Data";
	public static final String ERROR_FAILED = "FAILED";
    public static final String ERROR_NO_DATA = "No Data";
    public static final String STATUS_COMPLETED = "COMPLETED";
	public static final String ERMSG_TP_NAME = "Invalid TP company";
	public static final String FILE_TYPE = "file";
	public static final String INSURER_NAME = "inInsurerName";
    public static final String ERMSG_DUPLICATE_FIELD_VALUE = "Duplicate Field Value";
    public static final String REGISTRATION_NO = "registrationNo";
    public static final String TIME="time";
	public static final String IP="ip";
	public static final String ATTEMPT="attempt";

    public static final String POLICY_NUMBER= "policyNumber";
    public static final String VEHICLES_DETAILS = "vehicleDetails";
    public static final String TP_CLAIM_NO="claimNo";
    public static final String POLICE_REPORT_NUMBER= "policeReportNumber";
    public static final String IS_ACTIVE= "isActive";

    public static final String TO_COMPANY= "toCompany";

	public static final String PDF="Pdf";
	public static final String PAYABLES="Payables";
	public static final String PAYMENT_DETAILS="payment_details";
	public static final String PAYMENTID="id";
    public static final String PAYMENT_REPORT_CARD = "reportCard";
    public static final String IS_AUTOGENERATED = "isAutoGenerated";
    public static final String RL_COMPANY_NAME = "companyName";
	public static final String REPORT_LOSS_PAGE_IDENTITY = "sdjashbsdadajdkui";
	public static final String REPORT_LOSS_PAYABLE_PAGE_IDENTITY = "sdjashbsdadajdkui222";
    public static final String REPORT_LOSS_USER_ID = "reportLossId";
	public static final String REPORT_LOSS_WORKING_USER = "report_loss_working_user";
	public static final String IS_PAID = "isPaid";
	public static final String DROPDOWN_OPTIONS_ID = "dropdownOptionsId";
	public static final String DROPDOWN_TYPE = "dropDownType";
    public static final String AUTHORITY_PAYMENTS = "authority_payments";
    public static final String DROP_DOWN_LIST = "dropdownlist";
	public static final String DROP_DOWN_LIST_OPTION_MAP = "dropdownlist_option_map";
	public static final String GET= "get";
	public static final String OPTION_ID = "optionId";
	public static final String OPTION_NAME = "optionName";

	public static final Object ID_DUAlCURRENCY_EMPTY = "isDualCurrencyEmpty";
	public static final String REPORT_LOSS_PAGE_NAME = "reportloss";

	public static final String PLATFORM_ID = "platformId";
	public static final String NOTIFICATION_HISTORY_ID= "id";
	public static final String RL_NOTIFICATION_HISTORY = "notificationHistory";
	public static final String USER_IDENTITY = "userIdentity";
	 public static final String NOTIFICATION_HISTORY_USER_MAP = "notification_history_user_map";

	private TableConstants() {

		}

}
