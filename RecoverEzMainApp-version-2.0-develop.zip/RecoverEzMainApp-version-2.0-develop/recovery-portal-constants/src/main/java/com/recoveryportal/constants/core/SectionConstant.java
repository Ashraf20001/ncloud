package com.recoveryportal.constants.core;

public class SectionConstant {
public static final String Insured_Details="Insured Details";
public static final String TP_Details="TP Details";
public static final String Loss_Details="Loss Details";
public static final String Police_Report="Police Report";
public static final String Garage_Details="Garage Details";
public static final String Survey_Details="Survey Details";
public static final String Survey_Report="Survey Report";
public static final String Recovery_Details="Recovery Details";
public static final String Reserve_Review="Reserve Review";
public static final String Garage_Invoice="Garage Invoice";
public static final String Debit_Note="Debit Note";
public static final String Credit_Note="Credit Note";
}
