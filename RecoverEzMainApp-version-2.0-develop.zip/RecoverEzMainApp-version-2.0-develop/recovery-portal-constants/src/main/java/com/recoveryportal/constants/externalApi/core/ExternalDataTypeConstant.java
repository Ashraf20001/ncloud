package com.recoveryportal.constants.externalApi.core;

public class ExternalDataTypeConstant {
	public static final String STRING="class java.lang.String";
	public static final String LOCALDATETIME="class java.time.LocalDateTime";
	public static final String DOUBLE="class java.lang.Double";
	public static final String INTEGER="class java.lang.Integer";
	public static final String LONG="class java.lang.Long";
	public static final String BOOLEAN="class java.lang.Boolean";
	public static final String LOCALDATE="Class java.time.LocalDate";
	

}
