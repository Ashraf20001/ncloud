package com.recoveryportal.constants.enums;

import com.recoveryportal.constants.core.SectionConstant;
import com.recoveryportal.constants.core.StageConstant;

public enum StageAndSectionEnum {
	
	INSUREDDETAILS(SectionConstant.Insured_Details,StageConstant.NOTIFICATION_STAGE),
	THIRDPARTYDETAILS(SectionConstant.TP_Details,StageConstant.NOTIFICATION_STAGE),
	LOSSDETAILS(SectionConstant.Loss_Details,StageConstant.NOTIFICATION_STAGE),
	POLICEREPORT(SectionConstant.Police_Report,StageConstant.NOTIFICATION_STAGE),
	GARAGEINFO(SectionConstant.Garage_Details,StageConstant.CLAIM_INSPECTION_STAGE),
	SURVEYDETAILS(SectionConstant.Survey_Details,StageConstant.CLAIM_INSPECTION_STAGE),
	SURVEYREPORT(SectionConstant.Survey_Report,StageConstant.CLAIM_INSPECTION_STAGE),
	RECOVERYDETAILS(SectionConstant.Recovery_Details,StageConstant.LIABILITY_CONFIRMATION_STAGE),
	RESERVEREVIEW(SectionConstant.Reserve_Review,StageConstant.LIABILITY_CONFIRMATION_STAGE),
	GARAGEINVOICE(SectionConstant.Garage_Invoice,StageConstant.SETTLEMENT_STAGE),
	DEBITNOTE(SectionConstant.Debit_Note,StageConstant.SETTLEMENT_STAGE),
	CREDITNOTE(SectionConstant.Credit_Note,StageConstant.SETTLEMENT_STAGE);
	
	public String section;
	public String stage;

	private StageAndSectionEnum(String section, String stage) {
		this.stage = stage;
		this.section=section;
	}

}
