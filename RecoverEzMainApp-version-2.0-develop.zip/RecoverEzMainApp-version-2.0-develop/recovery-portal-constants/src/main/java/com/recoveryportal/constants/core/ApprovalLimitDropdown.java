package com.recoveryportal.constants.core;

public enum ApprovalLimitDropdown{
	TotalLossEstimatedAmount(0,"TotalLossEstimatedAmount","Survey Report","Claim Inspection Stage"),
	SumInsured(1,"SumInsured","Insured Details","Notification Stage"),
	ReserveAmount(2,"ReserveAmount","Loss Details","Notification Stage"),
	SurveyAmount(3,"SurveyAmount","Survey Report","Claim Inspection Stage"),
	ClaimAmount(4,"ClaimAmount","Recovery Details","Liability Confirmation Stage"),
	ClaimReserveAmount(5,"ClaimReserveAmount","Reserve Review","Liability Confirmation Stage"),
	TPSurveyAmount(6,"TPSurveyAmount","Reserve Review","Liability Confirmation Stage"),
	TotalClaimAmount(7,"TotalClaimAmount","Reserve Review","Liability Confirmation Stage"),
	KnockForKnock(8,"KnockForKnock","Reserve Review","Liability Confirmation Stage");
	


	private int id;
	private String field;
	private String section;
	private String stageName;
	
	public int getId() {
		return id;
	}

	public String getField() {
		return field;
	}

	public String getSection() {
		return section;
	}
	
	public String getStageName() {
		return stageName;
	}

	
	private	ApprovalLimitDropdown(Integer id,String Field,String section,String stageName) {
		this.id=id;
		this.field=Field;
		this.section=section;
		this.stageName=stageName;
		
	}
	
	public static ApprovalLimitDropdown getApprovalLimitDropdown(String approvalLimitStr) {
		for (ApprovalLimitDropdown ApprovalLimitDropdownEnum : ApprovalLimitDropdown.values()) {
			if(ApprovalLimitDropdownEnum.name().equalsIgnoreCase(approvalLimitStr)) {
				return ApprovalLimitDropdownEnum;
			}
		}
		return null;
	}
	
	public static ApprovalLimitDropdown getApprovalLimitDropdown(Integer enumId) {
		for(ApprovalLimitDropdown ApprovalLimitDropdownEnum : ApprovalLimitDropdown.values()) {
			if(ApprovalLimitDropdownEnum.ordinal()==enumId) {
				return ApprovalLimitDropdownEnum;
			}
		}
		return null;

	}
	
		
}
