package com.recoveryportal.constants.core;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class SessionScopeClass {
	private static final ThreadLocal<Map<String,Object>> predicateMap= new ThreadLocal<>(); 

	public  Map<String,Object> getPredicateMap() {
		return predicateMap.get();
	}
	
	public  void setPredicateMap(String userType,Object value) {
		Map<String, Object> map = getPredicateMap();
		if(map == null) {
			map = new HashMap<String,Object>();
		}
		map.put(userType, value);
		predicateMap.set(map);
	}
	
	
	public void removePredicate() {
		SessionScopeClass.predicateMap.remove();
	}

}
