package com.recoveryportal.utils.core;

import org.springframework.stereotype.Component;

import com.recoveryportal.transfer.object.dto.UserInfo;

/**
 * The Class LoggedInContextHolder.
 */
@Component
public class LoggedInContextHolder {
	
	/** The Constant appUserId. */
	private static final ThreadLocal<String> appUserId = new ThreadLocal<String>();
	
	/** The Constant appUserName. */
	private static final ThreadLocal<String> appUserName = new ThreadLocal<String>();
	
	/** The Constant userDetails. */
	private static final ThreadLocal<UserInfo> userDetails = new ThreadLocal<UserInfo>();
	
	/**
	 * Sets the logged in user ID.
	 *
	 * @param loggedInUser the new logged in user ID
	 */
	public  void setLoggedInUserID(String loggedInUser) {
		if (loggedInUser == null) {
			throw new NullPointerException();
		}
		appUserId.set(loggedInUser);
	}

	/**
	 * Clear logged in user id holder.
	 */
	public  void clearLoggedInUserIdHolder() {
		appUserId.remove();
	}

	/**
	 * Gets the app user ID.
	 *
	 * @return the app user ID
	 */
	public  String getAppUserID() {
		return appUserId.get();
	}

	/**
	 * Sets the logged in user name.
	 *
	 * @param loggedInUser the new logged in user name
	 */
	public  void setLoggedInUserName(String loggedInUser) {
		if (loggedInUser == null) {
			throw new NullPointerException();
		}
		appUserName.set(loggedInUser);
	}

	/**
	 * Clear logged in user name holder.
	 */
	public  void clearLoggedInUserNameHolder() {
		appUserName.remove();
	}

	/**
	 * Gets the app user name.
	 *
	 * @return the app user name
	 */
	public  String getAppUserName() {
		return appUserName.get();
	}

	/**
	 * Sets the logged in user.
	 *
	 * @param loggedInUser the new logged in user
	 */
	public  void setLoggedInUser(UserInfo loggedInUser) {
		if (loggedInUser == null) {
			throw new NullPointerException();
		}
		userDetails.set(loggedInUser);
	}
	
	/**
	 * Gets the logged in user.
	 *
	 * @return the logged in user
	 */
	public  UserInfo getLoggedInUser() {
		return userDetails.get();
	}

}
