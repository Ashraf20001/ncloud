package com.recoveryportal.utils.core;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.recoveryportal.constants.serverproperties.PropertyValueProvider;


/**
 * The Class EnvironmentPropertiesUtil.
 */
@Configuration
public class EnvironmentPropertiesUtil {
	
	
	/** The configuration properties. */
	@Autowired
	private PropertyValueProvider configurationProperties;

	
		
	/**
	 * Gets the time zone.
	 *
	 * @return the time zone
	 */
	public String getTimeZone() {
		return configurationProperties.getTimeZone();
	}
	
	/**
	 * Gets the date format.
	 *
	 * @return the date format
	 */
	public String getDateFormat() {
		return configurationProperties.getDateFormat();
	}
	
	/**
	 * Gets the currency format.
	 *
	 * @return the currency format
	 */
	public String getCurrencyFormat() {
		return configurationProperties.getCurrencyFormat();
	}
	
	/**
	 * Gets the country code.
	 *
	 * @return the country code
	 */
	public String getCountryCode() {
		return configurationProperties.getCountryCode();
	}
	
	/**
	 * Gets the bulk upload report loss path.
	 *
	 * @return the bulk upload report loss path
	 */
	public String getBulkUploadReportLossPath() {
		return configurationProperties.getBulkUploadReportlossPath();
	}

	/**
	 * Gets the notification update url.
	 *
	 * @return the notification update url
	 */
	public String getNotificationUpdateUrl() {
		return configurationProperties.getNotificationUpdateUrl();
	}
/**
 * Gets the notification save url.
 *
 * @return the notification save url
 */
public String getNotificationSaveUrl() {
		return configurationProperties.getNotificationSaveUrl();
	}
	
	/**
	 * Gets the approval limit notification url.
	 *
	 * @return the approval limit notification url
	 */
	public String getApprovalLimitNotificationUrl() {
		return configurationProperties.getApprovalLimitNotificationUrl();
	}
/**
 * Gets the scheduler url.
 *
 * @return the scheduler url
 */
public String getSchedulerUrl() {
		return configurationProperties.getSchedulerUrl();
	}
/**
 * Gets the schedule update url.
 *
 * @return the schedule update url
 */
public String getScheduleUpdateUrl() {
		return configurationProperties.getSchedulerUpdateUrl();
	}
	
	/**
	 * Gets the notification history list url.
	 *
	 * @return the notification history list url
	 */
	public String getNotificationHistoryListUrl() {
		return configurationProperties.getNotificationHistoryListUrl();
	}
	
	/**
	 * Gets the notification history count url.
	 *
	 * @return the notification history count url
	 */
	public String getNotificationHistoryCountUrl() {
		return configurationProperties.getNotificationHistoryCountUrl();
	}
	
	/**
	 * Update notification url.
	 *
	 * @return the string
	 */
	public String updateNotificationUrl() {
		return configurationProperties.getNotificationApprovalLimitUpdateUrl();
	}
	
	/**
	 * Gets the max time.
	 *
	 * @return the max time
	 */
	public Integer getMaxTime() {
		return Integer.parseInt(configurationProperties.getMaxTime());
	}
	
	/**
	 * Gets the max attempt.
	 *
	 * @return the max attempt
	 */
	public Integer getMaxAttempt() {
		return Integer.parseInt(configurationProperties.getMaxAttempt());
	}
	
	/**
	 * Gets the notification wallet url.
	 *
	 * @return the notification wallet url
	 */
	public String getNotificationWalletUrl() {
		return configurationProperties.getNotificationSaveWalletUrl();
	}
	
	/**
	 * Gets the wallet payment reminder grace period.
	 *
	 * @return the wallet payment reminder grace period
	 */
	public Integer getWalletPaymentReminderGracePeriod() {
		return Integer.parseInt(configurationProperties.getWalletPaymentReminderGracePeriod());
    }
	
	/**
	 * Gets the wallet report generation cron.
	 *
	 * @return the wallet report generation cron
	 */
	public String getWalletReportGenerationCron() {
		return configurationProperties.getWalletReportGenerationCron();
	}

	/**
	 * Gets the recovery port.
	 *
	 * @return the recovery port
	 */
	public String getRecoveryPort() {
		return configurationProperties.getRecoveryHostPort();
	}

	/**
	 * Gets the notification port.
	 *
	 * @return the notification port
	 */
	public String getNotificationPort() {
		return configurationProperties.getNotificationHostPort();
	}

	/**
	 * Gets the notification consumer port.
	 *
	 * @return the notification consumer port
	 */
	public String getNotificationConsumerPort() {
		return configurationProperties.getNotificationConsumerHostPort();
	}
	
	/**
	 * Gets the nschedular port.
	 *
	 * @return the nschedular port
	 */
	public String getNschedularPort() {
		return configurationProperties.getNschedulerHostPort();
	}

	/**
	 * Gets the bulk upload consumer port.
	 *
	 * @return the bulk upload consumer port
	 */
	public String getBulkUploadConsumerPort() {
		return configurationProperties.getBulkuploadConsumerHostPort();
	}

	/**
	 * Gets the web application port.
	 *
	 * @return the web application port
	 */
	public String getWebApplicationPort() {
		return configurationProperties.getWebApplicationHostPort();
	}

	/**
	 * Gets the mysql port.
	 *
	 * @return the mysql port
	 */
	public String getMysqlPort() {
		return configurationProperties.getMySqlHostPort();
	}

	/**
	 * Gets the kafka port.
	 *
	 * @return the kafka port
	 */
	public String getKafkaPort() {
		return configurationProperties.getKafkaHostPort();

	}

	
}