package com.recoveryportal.adapter.service;

import java.util.HashMap;

import javax.annotation.PostConstruct;

import com.recoveryportal.transfer.object.dto.UserDetailsViewDto;
import com.recoveryportal.transfer.object.dto.UserRoleMgmtViewDto;
import org.springframework.stereotype.Component;

import com.recoveryportal.transfer.object.dto.GarageDto;
import com.recoveryportal.transfer.object.dto.companyViewDto;
import com.recoveryportal.transfer.object.reportloss.dto.ReportLossDto;
import com.recoveryportal.transfer.object.vo.dto.IConfigurable;

/**
 * The Class FieldMapperInstanceConfig.
 */
@Component
public class FieldMapperInstanceConfig {
	
	/** The class map. */
	HashMap<String, Class<?>> classMap = new HashMap<>();
	
	/** The prefix map. */
	HashMap<String, String> prefixMap = new HashMap<>();
	
	/**
	 * Construct class map.
	 */
	@PostConstruct
	void constructClassMap() {
		classMap.put("ClaimDetailsDto", ReportLossDto.class);
		classMap.put("Company Details", companyViewDto.class);
		classMap.put("Threshold Limit", companyViewDto.class);
    	classMap.put("Garage Details", GarageDto.class);
		classMap.put("UserRoleManagementDto", UserRoleMgmtViewDto.class);
		classMap.put("UserManagementDto", UserDetailsViewDto.class);
		prefixMap.put("Insured Details", "In");
		prefixMap.put("TP Details", "Tp");
		prefixMap.put("Loss Details", "Ls");
		prefixMap.put("Police Details", "Pc");
	}
	
	/**
	 * Gets the class.
	 *
	 * @param className the class name
	 * @return the class
	 */
	public Class<?> getClass(String className){
		Class<?> class1 = classMap.get(className);
		return class1;
	}

	/**
	 * Gets the object.
	 *
	 * @param className the class name
	 * @return the object
	 */
	public IConfigurable getObject(Class<?> className) {
		try {
			Object obj = className.getConstructor().newInstance();
			
			if( !(obj instanceof IConfigurable) ) {
				throw new Exception("Invalid Configurable");
			}
			
			return (IConfigurable)obj;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return  null;
	}
	
	/**
	 * Gets the prefix.
	 *
	 * @param groupName the group name
	 * @return the prefix
	 */
	public String getPrefix(String groupName) {
		return prefixMap.getOrDefault(groupName, null);
	}
}
