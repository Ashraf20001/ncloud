package com.recoveryportal.adapter.service;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.poi.ss.formula.functions.T;
import org.springframework.stereotype.Component;

import com.recoveryportal.transfer.object.entity.APIDetails;
import com.recoveryportal.transfer.object.entity.APIPageMapping;
import com.recoveryportal.transfer.object.entity.Association;
import com.recoveryportal.transfer.object.entity.BulkImportMapping;
import com.recoveryportal.transfer.object.entity.ClaimHistoryTemplate;
import com.recoveryportal.transfer.object.entity.DropDownList;
import com.recoveryportal.transfer.object.entity.DropDownListOptionMapping;
import com.recoveryportal.transfer.object.entity.Field;
import com.recoveryportal.transfer.object.entity.FieldDropDownListMap;
import com.recoveryportal.transfer.object.entity.MetaData;
import com.recoveryportal.transfer.object.entity.Page;
import com.recoveryportal.transfer.object.entity.Privilege;
import com.recoveryportal.transfer.object.entity.Section;
import com.recoveryportal.transfer.object.notification.entity.NotificationEvent;
import com.recoveryportal.transfer.object.notification.entity.NotificationTemplate;
import com.recoveryportal.transfer.object.reportloss.entity.DropdownOptions;
import com.recoveryportal.transfer.object.reportloss.entity.FieldOptionMapping;
import com.recoveryportal.transfer.object.reportloss.entity.NextStatusEntity;


/**
 * A factory for creating EntityTableMapping objects.
 */
@Component
public class EntityTableMappingFactory {
	
	/** The table entit map. */
	Map<String, Object> tableEntitMap = new HashMap<>();
	
	/**
	 * Entity table map.
	 */
	@PostConstruct
	void entityTableMap() {
		tableEntitMap.put("page", Page.class);
		tableEntitMap.put("section", Section.class);
		tableEntitMap.put("field", Field.class);
		tableEntitMap.put("um_api_details", APIDetails.class);
		tableEntitMap.put("um_privilege", Privilege.class);
		tableEntitMap.put("um_page_api_mapping", APIPageMapping.class);
		tableEntitMap.put("notification_event", NotificationEvent.class);
		tableEntitMap.put("association", Association.class);
		tableEntitMap.put("notification_template", NotificationTemplate.class);
		tableEntitMap.put("claim_history_template", ClaimHistoryTemplate.class);
		tableEntitMap.put("bulk_import_mapping", BulkImportMapping.class);
		tableEntitMap.put("field_dropdown_map", FieldDropDownListMap.class);
		tableEntitMap.put("dropdownlist", DropDownList.class);
		tableEntitMap.put("dropdown_options", DropdownOptions.class);
		tableEntitMap.put("dropdownlist_option_map", DropDownListOptionMapping.class);
		tableEntitMap.put("meta_data", MetaData.class);
		tableEntitMap.put("field_option_mapping", FieldOptionMapping.class);
		tableEntitMap.put("rp_next_status", NextStatusEntity.class);
		
	}
	
	/**
	 * Gets the entity name by table name.
	 *
	 * @param tableName the table name
	 * @return the entity name by table name
	 */
	@SuppressWarnings("unchecked")
	public Class<T> getEntityNameByTableName(String tableName) {
		return (Class<T>)tableEntitMap.get(tableName);
	}

}
