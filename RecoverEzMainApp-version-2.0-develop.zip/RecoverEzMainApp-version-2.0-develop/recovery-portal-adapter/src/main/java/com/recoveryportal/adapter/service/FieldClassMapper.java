package com.recoveryportal.adapter.service;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashMap;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.recoveryportal.transfer.object.vo.dto.DataTypeConstantsDto;

/**
 * The Class FieldClassMapper.
 */
@Component
public class FieldClassMapper {
	
	/** The class map. */
	HashMap<String, Class<?>> classMap = new HashMap<>();
	
	
	
	/**
	 * Construct class map.
	 */
	@PostConstruct
	void constructClassMap() {
		classMap.put(DataTypeConstantsDto.STRING, String.class);
		classMap.put(DataTypeConstantsDto.TEXT, String.class);
		classMap.put(DataTypeConstantsDto.FILE, String.class);
		classMap.put(DataTypeConstantsDto.BOOLEAN,  Boolean.class);
		classMap.put(DataTypeConstantsDto.INTEGER, Integer.class);
		classMap.put(DataTypeConstantsDto.DOUBLE, Double.class);
		classMap.put(DataTypeConstantsDto.FDATE, Date.class);
		classMap.put(DataTypeConstantsDto.PDATE, Date.class);
		classMap.put(DataTypeConstantsDto.LOCAL_DATE_TIME, LocalDateTime.class);
		classMap.put(DataTypeConstantsDto.LONG, Long.class);
	}
	
	
	
	/**
	 * Gets the class.
	 *
	 * @param className the class name
	 * @return the class
	 */
	public Class<?> getClass(String className){
		return classMap.get(className);
	}
	
	

}
