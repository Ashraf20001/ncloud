package com.recoveryportal.adapter.dao.daoImpl;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.recoveryportal.adapter.dao.FieldOptionDao;
import com.recoveryportal.config.common.base.dao.BaseDao;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.transfer.object.reportloss.entity.FieldOptionMapping;

/**
 * The Class FieldOptionDaoImpl.
 */
@Repository
@Transactional
public class FieldOptionDaoImpl extends BaseDao implements FieldOptionDao {
    
    /**
     * Gets the field options.
     *
     * @param fieldId the field id
     * @return the field options
     */
    @Override
    public List<FieldOptionMapping> getFieldOptions(String fieldId) {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<FieldOptionMapping> criteria = builder.createQuery(FieldOptionMapping.class);
        Root<FieldOptionMapping> root = criteria.from(FieldOptionMapping.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
        predicates.add(builder.and(builder.equal(
                root.get(TableConstants.FIELD)
                .get(TableConstants.IDENTITY), fieldId)));
        return (List<FieldOptionMapping>)getResultList(createQuery(builder, criteria, root, predicates));
    }

    /**
     * Save field option mapping.
     *
     * @param fieldOptionMapping the field option mapping
     * @return the field option mapping
     * @throws ApplicationException the application exception
     */
	public FieldOptionMapping saveFieldOptionMapping(FieldOptionMapping fieldOptionMapping) throws ApplicationException {
		 save(fieldOptionMapping, TableConstants.FIELD);
	        return fieldOptionMapping;
	}
    
    /**
     * Register data filters.
     */
    @Override
    public void registerDataFilters() {

    }

	/**
	 * Update field option mapping.
	 *
	 * @param option the option
	 * @return the field option mapping
	 * @throws ApplicationException the application exception
	 */
	@Override
	public FieldOptionMapping updateFieldOptionMapping(FieldOptionMapping option) throws ApplicationException {
		update(option);
		return option;
	}
}
