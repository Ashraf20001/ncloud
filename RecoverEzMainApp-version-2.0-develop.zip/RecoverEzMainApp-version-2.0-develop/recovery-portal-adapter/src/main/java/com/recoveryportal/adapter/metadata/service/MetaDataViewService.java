package com.recoveryportal.adapter.metadata.service;

import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.transfer.object.dto.*;

import com.recoveryportal.transfer.object.entity.MetaData;
import com.recoveryportal.transfer.object.reportloss.dto.ReportLossViewDto;

import java.util.List;

/**
 * The Interface MetaDataViewService.
 */
public interface MetaDataViewService {
    
    /**
     * Convert meta data entity into DTO.
     *
     * @param metaList the meta list
     * @param reportLossViewDto the report loss view dto
     * @return the meta data view dto
     * @throws ApplicationException the application exception
     */
    public MetaDataViewDto convertMetaDataEntityIntoDTO(List<MetaData> metaList, ReportLossViewDto reportLossViewDto) throws ApplicationException;

	/**
	 * Convert meta data entity into DTO insurance company.
	 *
	 * @param metaList the meta list
	 * @param companyDto the company dto
	 * @return the meta data view dto
	 * @throws ApplicationException the application exception
	 */
	MetaDataViewDto convertMetaDataEntityIntoDTOInsuranceCompany(List<MetaData> metaList, companyViewDto companyDto)
			throws ApplicationException;

	/**
	 * Convert meta data entity into DTO garage.
	 *
	 * @param metaList the meta list
	 * @param garagedto the garagedto
	 * @return the meta data view dto
	 * @throws ApplicationException the application exception
	 */
	MetaDataViewDto convertMetaDataEntityIntoDTOGarage(List<MetaData> metaList, GarageDto garagedto)
			throws ApplicationException;

    /**
     * Convert meta data entity into user mgmt DTO.
     *
     * @param metaList the meta list
     * @param viewDto the view dto
     * @return the meta data view dto
     * @throws ApplicationException the application exception
     */
    MetaDataViewDto convertMetaDataEntityIntoUserMgmtDTO(List<MetaData> metaList, Object viewDto) throws ApplicationException;

}
