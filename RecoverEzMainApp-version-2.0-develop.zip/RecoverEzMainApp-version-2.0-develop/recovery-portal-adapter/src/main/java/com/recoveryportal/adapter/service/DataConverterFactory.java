package com.recoveryportal.adapter.service;


import com.recoveryportal.exception.core.ApplicationException;
import org.springframework.stereotype.Component;

import com.recoveryportal.transfer.object.vo.dto.DataTypeConstantsDto;

import java.time.ZonedDateTime;

/**
 * A factory for creating DataConverter objects.
 */
@Component
public class DataConverterFactory {
	
	/**
	 * Data converter.
	 *
	 * @param type the type
	 * @param value the value
	 * @return the object
	 * @throws ApplicationException the application exception
	 */
	public Object dataConverter(String type,String value) throws ApplicationException{
		if (value == null || value.equals("") || value.isBlank() || value.isEmpty()){
			return null;
		}

		switch (type) {

			case DataTypeConstantsDto.DROPDOWN:
				case DataTypeConstantsDto.TEXT:
				case DataTypeConstantsDto.MULTI_SELECT:
					case DataTypeConstantsDto.DOWNLOAD:
						case DataTypeConstantsDto.FILE:
							case DataTypeConstantsDto.STRING:
				return value;

			case DataTypeConstantsDto.BOOLEAN:
				case DataTypeConstantsDto.CHECKBOX:
				case DataTypeConstantsDto.TOGGLE:
				case DataTypeConstantsDto.RADIO_BUTTON:
				return Boolean.parseBoolean(value);
			
			case DataTypeConstantsDto.INTEGER:
				return Integer.parseInt(value);

			case DataTypeConstantsDto.LONG:
				return Long.parseLong(value);

			case DataTypeConstantsDto.DOUBLE:
				return Double.parseDouble(value);
			
			case DataTypeConstantsDto.PDATE: 
			case DataTypeConstantsDto.FDATE: {
				return ZonedDateTime.parse(value).toLocalDateTime();
			}
		}
		return null;
		
	}
	
	
}
