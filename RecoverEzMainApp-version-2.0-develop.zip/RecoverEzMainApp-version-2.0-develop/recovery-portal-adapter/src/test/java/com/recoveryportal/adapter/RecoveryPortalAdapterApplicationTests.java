package com.recoveryportal.adapter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecoveryPortalAdapterApplicationTests {

	@Test
	void contextLoads() {
	}

}
