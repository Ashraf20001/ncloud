package com.recoveryportal.adapter.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.recoveryportal.adapter.RecoveryPortalAdapterApplication;
import com.recoveryportal.adapter.mock.MockData;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.transfer.object.vo.dto.ClaimDetailsFields;
import com.recoveryportal.transfer.object.vo.dto.FieldGroup;


@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = RecoveryPortalAdapterApplication.class)
public class AdapterServiceTest {
	
	@InjectMocks
	@Autowired
	private AdapterServiceImpl adapterService;
	
	@Mock
	private FieldMapperInstanceConfig config;
	
	@Mock
	private FieldClassMapper classMapper;
	
	@Mock
	private DataConverterFactory converterFactory;
	
	
	@Test
	public void Happy_Flow() throws ApplicationException {
		FieldGroup data = MockData.getClaimDetails();
		ClaimDetailsFields buildFieldGroup = (ClaimDetailsFields) adapterService.buildFieldGroup(data);
		String value = data.getFieldValues().get(2).getValue();
		long parseLong = Long.parseLong(value);
		assertEquals(buildFieldGroup.getReserveAmount(), parseLong);
	}

}
