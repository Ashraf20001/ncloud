package com.recoveryportal.adapter.mock;

import java.util.ArrayList;
import java.util.List;

import com.recoveryportal.transfer.object.vo.dto.ClaimDetailsFields;
import com.recoveryportal.transfer.object.vo.dto.Field;
import com.recoveryportal.transfer.object.vo.dto.FieldGroup;
import com.recoveryportal.transfer.object.vo.dto.FieldValue;
import com.recoveryportal.transfer.object.vo.dto.IConfigurable;

public  class MockData {
	
	public static IConfigurable getClaimDetailsFields() {
		ClaimDetailsFields fields = new ClaimDetailsFields();
		fields.setRecoveryLetter(true);
		fields.setFnolNo("hello");
		fields.setReserveAmount(1000);
		fields.setGarageFnolNo("fnolNo value");
		fields.setGarageContactName("calling contactName");
		
		return fields;
		
	}
	
	
	public static FieldGroup getClaimDetails() {
		Field field = new Field();
		field.setFieldName("recoveryLetter");
		field.setFieldId("asdf");
		field.setFieldType("Boolean");
		Field field1 = new Field();
		field1.setFieldName("fnolNo");
		field1.setFieldId("hasdlfj");
		field1.setFieldType("String");
		Field field2 = new Field();
		field2.setFieldName("reserveAmount");
		field2.setFieldId("weiursdf");
		field2.setFieldType("Long");
		
		FieldValue value = new FieldValue();
		value.setField(field);
		value.setValue("true");
		FieldValue value1 = new FieldValue();
		value1.setField(field1);
		value1.setValue("fnolno string");
		FieldValue value2 = new FieldValue();
		value2.setField(field2);
		value2.setValue("1000");
		
		
		List<FieldValue> fieldValueList = new ArrayList<>();
		fieldValueList.add(value);
		fieldValueList.add(value1);
		fieldValueList.add(value2);
		
		List<FieldGroup> fieldGroupList = new ArrayList<>();
		FieldGroup garageInfoDto = MockData.getGarageInfoDto();
		FieldGroup userCommentDto = MockData.getUserCommentDto();
		FieldGroup insuredInfoDto = MockData.getInsuredInfoDto();
		fieldGroupList.add(insuredInfoDto);
		fieldGroupList.add(userCommentDto);
		fieldGroupList.add(garageInfoDto);
		
		
		FieldGroup group = new FieldGroup();
		group.setGroupName("ClaimDetailsDto");
		group.setFieldValues(fieldValueList);
		group.setFieldGroups(fieldGroupList);
		
		return group;
	}
	
	public static FieldGroup getGarageInfoDto() {
		Field field = new Field();
		field.setFieldName("claimNo");
		field.setFieldId("weroisdf");
		field.setFieldType("String");
		Field field1 = new Field();
		field1.setFieldName("fnolNo");
		field1.setFieldId("nskjdf");
		field1.setFieldType("String");
		Field field2 = new Field();
		field2.setFieldName("name");
		field2.setFieldId("woeis");
		field2.setFieldType("String");
		
		FieldValue value = new FieldValue();
		value.setField(field);
		value.setValue("claimValue");
		FieldValue value1 = new FieldValue();
		value1.setField(field1);
		value1.setValue("fnolno string");
		FieldValue value2 = new FieldValue();
		value2.setField(field2);
		value2.setValue("name value");
		
		
		List<FieldValue> fieldValueList = new ArrayList<>();
		fieldValueList.add(value);
		fieldValueList.add(value1);
		fieldValueList.add(value2);
		
		List<FieldGroup> fieldGroupList = new ArrayList<>();
		fieldGroupList.add(getContactDto());
		
		
		FieldGroup group = new FieldGroup();
		group.setGroupName("GarageInfoDto");
		group.setFieldValues(fieldValueList);
		group.setFieldGroups(fieldGroupList);
		
		return group;
	}
	
	
	
	public static FieldGroup getContactDto() {
		Field field = new Field();
		field.setFieldName("contactName");
		field.setFieldId("1234");
		field.setFieldType("String");
		Field field1 = new Field();
		field1.setFieldName("contactPhone");
		field1.setFieldId("wersdf");
		field1.setFieldType("String");
		Field field2 = new Field();
		field2.setFieldName("emailAdress");
		field2.setFieldId("e45e");
		field2.setFieldType("String");
		
		FieldValue value = new FieldValue();
		value.setField(field);
		value.setValue("contact name value");
		FieldValue value1 = new FieldValue();
		value1.setField(field1);
		value1.setValue("contactPhone string");
		FieldValue value2 = new FieldValue();
		value2.setField(field2);
		value2.setValue("emailAdress value");
		
		
		List<FieldValue> fieldValueList = new ArrayList<>();
		fieldValueList.add(value);
		fieldValueList.add(value1);
		fieldValueList.add(value2);
		
		
		
		FieldGroup group = new FieldGroup();
		group.setGroupName("ContactDto");
		group.setFieldValues(fieldValueList);
		group.setFieldGroups(null);
		
		return group;
	}
	
	public static FieldGroup getUserCommentDto() {
		Field field = new Field();
		field.setFieldName("reason");
		field.setFieldId("jdke");
		field.setFieldType("String");
		Field field1 = new Field();
		field1.setFieldName("lastComment");
		field1.setFieldId("wersd");
		field1.setFieldType("String");
		
		
		FieldValue value = new FieldValue();
		value.setField(field);
		value.setValue("reason  value");
		FieldValue value1 = new FieldValue();
		value1.setField(field1);
		value1.setValue("lastComment string");
		
		
		
		List<FieldValue> fieldValueList = new ArrayList<>();
		fieldValueList.add(value);
		fieldValueList.add(value1);
		
		
		
		FieldGroup group = new FieldGroup();
		group.setGroupName("UserCommentDto");
		group.setFieldValues(fieldValueList);
		group.setFieldGroups(null);
		
		return group;
	}
	
	
	public static FieldGroup getInsuredInfoDto() {
		Field field = new Field();
		field.setFieldName("policyNumber");
		field.setFieldId("5sdfa");
		
		
		FieldValue value = new FieldValue();
		value.setField(field);
		value.setValue("contact name value");
		
		
		
		List<FieldValue> fieldValueList = new ArrayList<>();
		fieldValueList.add(value);
		
		List<FieldGroup> fieldGroupList = new ArrayList<>();
		fieldGroupList.add(getCompanyDto());
		fieldGroupList.add(getVehicleDetailsDto());
		
		
		
		FieldGroup group = new FieldGroup();
		group.setGroupName("InsuredInfoDto");
		group.setFieldValues(fieldValueList);
		group.setFieldGroups(fieldGroupList);
		
		return group;
	}
	
	public static FieldGroup getCompanyDto() {
		Field field = new Field();
		field.setFieldName("name");
		field.setFieldId("gsepor");
		field.setFieldType("String");
		Field field1 = new Field();
		field1.setFieldName("shortName");
		field1.setFieldId("sdg4");
		field1.setFieldType("String");
		
		
		FieldValue value = new FieldValue();
		value.setField(field);
		value.setValue(" name value");
		FieldValue value1 = new FieldValue();
		value1.setField(field1);
		value1.setValue("shortName string");
		
		
		
		List<FieldValue> fieldValueList = new ArrayList<>();
		fieldValueList.add(value);
		fieldValueList.add(value1);
		
		
		
		FieldGroup group = new FieldGroup();
		group.setGroupName("CompanyDto");
		group.setFieldValues(fieldValueList);
		group.setFieldGroups(null);
		
		return group;
	}
	
	public static FieldGroup getVehicleDetailsDto() {
		Field field = new Field();
		field.setFieldName("registrationNo");
		field.setFieldId("asdf23");
		field.setFieldType("String");
		Field field1 = new Field();
		field1.setFieldName("model");
		field1.setFieldId("sdfse2");
		field1.setFieldType("String");
		Field field2 = new Field();
		field2.setFieldName("make");
		field2.setFieldId("szxcv");
		field2.setFieldType("String");
		
		FieldValue value = new FieldValue();
		value.setField(field);
		value.setValue("registrationNo  value");
		FieldValue value1 = new FieldValue();
		value1.setField(field1);
		value1.setValue("model string");
		FieldValue value2 = new FieldValue();
		value2.setField(field2);
		value2.setValue("make value");
		
		
		List<FieldValue> fieldValueList = new ArrayList<>();
		fieldValueList.add(value);
		fieldValueList.add(value1);
		fieldValueList.add(value2);
		
		
		
		FieldGroup group = new FieldGroup();
		group.setGroupName("VehicleDetailsDto");
		group.setFieldValues(fieldValueList);
		group.setFieldGroups(null);
		
		return group;
	}

}
