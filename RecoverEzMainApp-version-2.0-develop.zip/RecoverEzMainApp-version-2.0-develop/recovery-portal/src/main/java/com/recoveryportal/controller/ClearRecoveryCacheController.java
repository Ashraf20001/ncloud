package com.recoveryportal.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.recoveryportal.security.jwt.RecoveryCache;

import io.swagger.annotations.ApiOperation;

/**
 * The Class ClearRecoveryCacheController.
 */
@RestController
public class ClearRecoveryCacheController {
	
	/** The Constant Logger. */
	public static final Logger Logger= LoggerFactory.getLogger(ClearRecoveryCacheController.class);
	
	/**
	 * Clearcache in company list.
	 *
	 * @return the boolean
	 */
	@ApiOperation(value = "Cache clear", notes = "Internal caches deletion operation",response = Boolean.class)
	@GetMapping("/clear-recovery-cache-companyList")
	public Boolean ClearcacheInCompanyList() {
		RecoveryCache.setCompanyList(null);
		RecoveryCache.setCompanyNameIdMap(null);
		RecoveryCache.setCompanyDtoIdMap(null);
		Logger.info("Company List Cleared successfully................");
		return Boolean.TRUE;
	} 

}
