package com.recoveryportal.dao;

import java.util.List;

import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.transfer.object.entity.FileStorageDetails;

/**
 * The Interface IStorageDataDao.
 */
public interface IStorageDataDao {
	
	/**
	 * Save file in local.
	 *
	 * @param response the response
	 * @throws ApplicationException the application exception
	 */
	void saveFileInLocal(FileStorageDetails response) throws ApplicationException;

	/**
	 * Gets the file list by group id.
	 *
	 * @param groupId the group id
	 * @return the file list by group id
	 */
	List<FileStorageDetails> getFileListByGroupId(Integer groupId);
	
	/**
	 * Gets the file list by file ids.
	 *
	 * @param fileIdList the file id list
	 * @return the file list by file ids
	 */
	List<FileStorageDetails> getFileListByFileIds(List<Integer> fileIdList);
	
	/**
	 * Update file storage details.
	 *
	 * @param fileStorageDetails the file storage details
	 */
	void updateFileStorageDetails(FileStorageDetails fileStorageDetails);
	
	/**
	 * Gets the file url by ref.
	 *
	 * @param refId the ref id
	 * @param rp_type the rp type
	 * @return the file url by ref
	 */
	FileStorageDetails getFileUrlByRef(Integer refId, String rp_type );
	
	/**
	 * Gets the file list url by ref.
	 *
	 * @param refId the ref id
	 * @param rpType the rp type
	 * @return the file list url by ref
	 */
	List<FileStorageDetails>  getFileListUrlByRef(Integer refId, String rpType );
	
	/**
	 * Gets the file by file name.
	 *
	 * @param fileName the file name
	 * @return the file by file name
	 */
	FileStorageDetails getFileByFileName(String fileName);
}
