package com.recoveryportal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.recoveryportal.aop.annotation.Auditable;
import com.recoveryportal.config.base.controller.BaseController;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.service.DashboardChartService;
import com.recoveryportal.transfer.object.core.ApplicationResponse;
import com.recoveryportal.transfer.object.dto.InsuredAndTpArray;
import com.recoveryportal.transfer.object.dto.RecentClaimDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class DashboardChartController.
 */
@RestController
@RequestMapping("/dashboard-chart")
@Auditable
public class DashboardChartController extends BaseController {

    /** The dashboard chart service. */
    @Autowired
    DashboardChartService dashboardChartService;
    
    /**
     * Gets the bar chart data.
     *
     * @param xlabel the xlabel
     * @param xvalue the xvalue
     * @param ylabel the ylabel
     * @param yvalue the yvalue
     * @param currencyId the currency id
     * @return the bar chart data
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "All Receivables and Payables", notes = "Get total number of receivables and payables",response = ApplicationResponse.class)
    @PostMapping("/total-receivables-payables")
    public ApplicationResponse getBarChartData(
          @ApiParam(value="Bar chart x label",required = true)  @RequestParam(value="xlabel",required = true) String xlabel,  @ApiParam(value="Bar chart x value",required = true)@RequestParam("xvalue") String xvalue,
          @ApiParam(value="Bar chart y label",required = true)  @RequestParam("ylabel") String ylabel, @ApiParam(value="Bar chart y value",required = true) @RequestParam("yvalue") String yvalue,
          @ApiParam(value="Currency ID",required = true)  @RequestParam("cur") Integer currencyId) throws ApplicationException {
        return getApplicationResponse(dashboardChartService.getBarChartData(xlabel,xvalue,ylabel,yvalue, currencyId));
    }
    
    /**
     * Gets the pie chart data.
     *
     * @param isReceivable the is receivable
     * @param currencyId the currency id
     * @return the pie chart data
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Receivable claim count", notes = "Get total number of receivables claim counts",response = ApplicationResponse.class)
    @PostMapping("/receivable-claim-count")
    public ApplicationResponse getPieChartData(@ApiParam(value = "is Receivable flag",required = true) @RequestParam (name="isReceivable") Boolean isReceivable,
    		@ApiParam(value = "currency",required = true) @RequestParam("cur") Integer currencyId) throws ApplicationException {
    	System.out.println(isReceivable);
        return getApplicationResponse(dashboardChartService.getPieChartData(isReceivable, currencyId));
    }
    
    /**
     * Gets the horizontal bar chart data.
     *
     * @param isReceivable the is receivable
     * @param currencyId the currency id
     * @return the horizontal bar chart data
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Top recovery", notes = "Get top recoveries of all companies",response = ApplicationResponse.class)
    @PostMapping("/top-recovery")
    public ApplicationResponse getHorizontalBarChartData(@ApiParam(value = "isReceivable",required = true) @RequestParam(name="isReceivable")Boolean isReceivable,
    		@ApiParam(value = "currency",required = true)	@RequestParam("cur") Integer currencyId) throws ApplicationException {
        return getApplicationResponse(dashboardChartService.getHorizontalBarChartData(isReceivable, currencyId));
    }
    
    /**
     * Gets the vertical bar chart data.
     *
     * @param isReceivable the is receivable
     * @param currencyId the currency id
     * @return the vertical bar chart data
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Pending receivables", notes = "Get pending receivable count",response = ApplicationResponse.class)
    @PostMapping("/pending-receivables")
    public ApplicationResponse getVerticalBarChartData(@ApiParam(value = "isreceivable flag",required = true) @RequestParam(name="isReceivable")Boolean isReceivable,
    		@ApiParam(value = "currency",required = true) @RequestParam("cur") Integer currencyId) throws ApplicationException {
        return getApplicationResponse(dashboardChartService.getVerticalBarChartData(isReceivable, currencyId));
    }
    
    /**
     * Gets the stacked bar chart data.
     *
     * @param isReceivable the is receivable
     * @param currencyId the currency id
     * @return the stacked bar chart data
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Not settled claims", notes = "Get total number of not settled claims",response = ApplicationResponse.class)
    @PostMapping("/non-settled-claims")
    public ApplicationResponse getStackedBarChartData( @ApiParam(value = "is Receivable flag" , required = true) @RequestParam(name="isReceivable")Boolean isReceivable, 
    		@ApiParam(value = "currency",required = true)	@RequestParam("cur") Integer currencyId) throws ApplicationException {
        return getApplicationResponse(dashboardChartService.getStackedBarChartData(isReceivable, currencyId));
    }
    
    /**
     * Gets the bar chart data filter.
     *
     * @param filterCompany the filter company
     * @param xlabel the xlabel
     * @param xvalue the xvalue
     * @param ylabel the ylabel
     * @param yvalue the yvalue
     * @param currencyId the currency id
     * @return the bar chart data filter
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Bar chart data filter", notes = "Get all companies receivable and payable as bar chart",response = ApplicationResponse.class)
    @PostMapping("/bar-chart-data-filter")
    public ApplicationResponse getBarChartDataFilter(@ApiParam(value="Insured and Tp Companies payload",required = true) @RequestBody InsuredAndTpArray filterCompany,
    		@ApiParam(value="Bar chart x label",required = true)   @RequestParam("xlabel") String xlabel,@ApiParam(value="Bar chart x value",required = true)   @RequestParam("xvalue") String xvalue,
    		@ApiParam(value="Bar chart y label",required = true)  @RequestParam("ylabel") String ylabel,@ApiParam(value="Bar chart y value",required = true) @RequestParam("yvalue") String yvalue,
    		@ApiParam(value = "currency",required = true) @RequestParam("cur") Integer currencyId) throws ApplicationException{	
        return getApplicationResponse(dashboardChartService.getBarChartDataFilter(filterCompany,xlabel,xvalue,ylabel,yvalue, currencyId));
    }
    
    /**
     * Gets the pie chart data filter.
     *
     * @param isReceivable the is receivable
     * @param currencyId the currency id
     * @param filterCompany the filter company
     * @return the pie chart data filter
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Pie chart data filter", notes = "Get all companies claims as pie chart",response = ApplicationResponse.class)
    @PostMapping("/pie-chart-data-filter")
    public ApplicationResponse getPieChartDataFilter(@ApiParam(value="is receivable flag",required = true) @RequestParam(name="isReceivable")Boolean isReceivable,
    		@ApiParam(value="currency",required = true)  @RequestParam("cur") Integer currencyId,@ApiParam(value="Insured and Tp Companies payload",required = true) @RequestBody InsuredAndTpArray filterCompany) throws ApplicationException {
        return getApplicationResponse(dashboardChartService.getPieChartDataFilter(isReceivable,filterCompany, currencyId));
    }
    
    /**
     * Gets the horizontal bar chart data filter.
     *
     * @param isReceivable the is receivable
     * @param currencyId the currency id
     * @param filterCompany the filter company
     * @return the horizontal bar chart data filter
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Horizontal chart data filter", notes = "Get all companies top recovery count",response = ApplicationResponse.class)
    @PostMapping("/horizontal-chart-data-filter")
    public ApplicationResponse getHorizontalBarChartDataFilter(@ApiParam(value="is receivable flag",required = true) @RequestParam(name="isReceivable")Boolean isReceivable,
    		@ApiParam(value="currency",required = true)	@RequestParam("cur") Integer currencyId,@ApiParam(value="Insured and Tp Companies payload",required = true) @RequestBody InsuredAndTpArray filterCompany) throws ApplicationException {
        return getApplicationResponse(dashboardChartService.getHorizontalBarChartDataFilter(isReceivable,filterCompany, currencyId));
    }
            
    /**
     * Gets the vertical bar chart data filter.
     *
     * @param isReceivable the is receivable
     * @param currencyId the currency id
     * @param filterCompany the filter company
     * @return the vertical bar chart data filter
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Pending receivable data filter", notes = "Get all companies pending receivable",response = ApplicationResponse.class)
    @PostMapping("/pending-receivables-filter")
    public ApplicationResponse getVerticalBarChartDataFilter(@ApiParam(value="is receivable flag",required = true) @RequestParam(name="isReceivable")Boolean isReceivable,
    		@ApiParam(value="currency",required = true)	@RequestParam("cur") Integer currencyId, 
    		@ApiParam(value="Insured and Tp Companies payload",required = true) @RequestBody InsuredAndTpArray filterCompany) throws ApplicationException {
        return getApplicationResponse(dashboardChartService.getVerticalBarChartDataFilter(isReceivable,filterCompany, currencyId));
    }
    
    /**
     * Gets the stacked bar chart data filter.
     *
     * @param isReceivable the is receivable
     * @param currencyId the currency id
     * @param filterCompany the filter company
     * @return the stacked bar chart data filter
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Not settled data filter", notes = "Get all companies not settled claims",response = ApplicationResponse.class)
    @PostMapping("/non-settled-claims-filter")
    public ApplicationResponse getStackedBarChartDataFilter(@ApiParam(value="is receivable flag",required = true) @RequestParam(name="isReceivable")Boolean isReceivable,
    		@ApiParam(value="currency",required = true)	@RequestParam("cur") Integer currencyId, @ApiParam(value="Insured and Tp Companies payload",required = true) @RequestBody InsuredAndTpArray filterCompany) throws ApplicationException {
        return getApplicationResponse(dashboardChartService.getStackedBarChartDataFilter(isReceivable,filterCompany, currencyId));
    }
    
    /**
     * Gets the recent claims.
     *
     * @param value the value
     * @param currencyId the currency id
     * @param filterCompany the filter company
     * @return the recent claims
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Recent claims", notes = "Get all recent receivable and payable claims",response = ApplicationResponse.class)
    @PostMapping("/getRecentClaims")
    public List<RecentClaimDto> getRecentClaims(@ApiParam(value="is receivable flag",required = true) @RequestParam("isReceivable") boolean value,
    		@ApiParam(value="currency",required = true)	@RequestParam("cur") Integer currencyId,@ApiParam(value="Insured and Tp Companies payload",required = true) @RequestBody InsuredAndTpArray filterCompany) throws ApplicationException{
        return dashboardChartService.getRecentClaims(value,filterCompany, currencyId);
    }
    
    /**
     * Gets the class name.
     *
     * @return the class name
     */
    @Override
    protected Class<?> getClassName() {
        return this.getClass();
    }

    /**
     * Gets the vo.
     *
     * @param identity the identity
     * @return the vo
     * @throws ApplicationException the application exception
     */
    @Override
    public Object getVo(String identity) throws ApplicationException {return null;}

    /**
     * Register interceptor.
     */
    @Override
    protected void registerInterceptor() {}
}
