package com.recoveryportal.dao.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.recoveryportal.config.common.base.dao.BaseDao;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.dao.BulkImportErrorDataDao;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.transfer.object.entity.BulkImportErrorData;
import com.recoveryportal.transfer.object.entity.BulkImportTempData;

/**
 * The Class BulkImportErrorDataDaoImpl.
 */
@Repository
@Transactional
public class BulkImportErrorDataDaoImpl extends BaseDao implements BulkImportErrorDataDao {
    
    /**
     * Save bulk import error data.
     *
     * @param bulkImportErrorData the bulk import error data
     * @return the bulk import error data
     * @throws ApplicationException the application exception
     */
    @Override
    public BulkImportErrorData saveBulkImportErrorData(BulkImportErrorData bulkImportErrorData) throws ApplicationException {
        save(bulkImportErrorData, TableConstants.BULK_IMPORT_ERROR_DATA);
        return bulkImportErrorData;
    }

    /**
     * Register data filters.
     */
    @Override
    public void registerDataFilters() {

    }

	/**
	 * Save bulk import temp data.
	 *
	 * @param importData the import data
	 * @return the bulk import temp data
	 * @throws ApplicationException the application exception
	 */
	@Override
	public BulkImportTempData saveBulkImportTempData(BulkImportTempData importData) throws ApplicationException {
		save(importData, TableConstants.REPORT_LOSS_UPLOAD_DATA);
        return importData;
	}

	/**
	 * Error data delete.
	 *
	 * @param uploadIdentity the upload identity
	 * @param userId the user id
	 * @return the int
	 */
	@Override
	public int errorDataDelete(String uploadIdentity,Integer userId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaUpdate<BulkImportTempData> criteria = builder.createCriteriaUpdate(BulkImportTempData.class);
		Root<BulkImportTempData> root = criteria.from(BulkImportTempData.class);
		criteria.set(root.get(TableConstants.ISDELETED), true);
		criteria.set(root.get(TableConstants.MODIFIED_DATE), LocalDateTime.now());
		criteria.set(root.get(TableConstants.MODIFIED_BY),userId);
		criteria.where(builder.equal(root.get(TableConstants.UPLOAD_DATA_ID), uploadIdentity));	
		int deleteSts = createQueryupdate(criteria).executeUpdate();
		return deleteSts;
	}

	/**
	 * Gets the error data by upload id.
	 *
	 * @param uploadDataId the upload data id
	 * @return the error data by upload id
	 */
	@Override
	public BulkImportTempData getErrorDataByUploadId(String uploadDataId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<BulkImportTempData> criteria = builder.createQuery(BulkImportTempData.class);
		Root<BulkImportTempData> root = criteria.from(BulkImportTempData.class);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IDENTITY),uploadDataId)));
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.STATUS))));
		return (BulkImportTempData)getSingleResult(createQuery(builder, criteria, root, predicates));
	}
}
