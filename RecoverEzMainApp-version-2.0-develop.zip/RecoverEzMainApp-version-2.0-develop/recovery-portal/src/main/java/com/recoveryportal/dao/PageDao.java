package com.recoveryportal.dao;

import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.transfer.object.entity.Page;

import java.util.List;

/**
 * The Interface PageDao.
 */
public interface PageDao {
    
    /**
     * Gets the all page dto details.
     *
     * @return the all page dto details
     */
    List<Page> getAllPageDtoDetails();

    /**
     * Gets the all page data by user id.
     *
     * @param pageIdList the page id list
     * @return the all page data by user id
     */
    List<Page> getAllPageDataByUserId(List<String> pageIdList);

    /**
     * Gets the page by identity.
     *
     * @param pageIdentity the page identity
     * @return the page by identity
     */
    Page getPageByIdentity(String pageIdentity);

}
