package com.recoveryportal.config;

import java.util.Collections;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * The Class SwaggerConfig.
 */
@Configuration
@EnableSwagger2
public class SwaggerConfig extends WebMvcConfigurationSupport {

   /**
    * Adds the resource handlers.
    *
    * @param registry the registry
    */
   @Override
   public void addResourceHandlers(ResourceHandlerRegistry registry) {
       registry.addResourceHandler("swagger-ui.html")
               .addResourceLocations("classpath:/META-INF/resources/");

       registry.addResourceHandler("/webjars/**")
               .addResourceLocations("classpath:/META-INF/resources/webjars/");
   }

   /**
    * Api.
    *
    * @return the docket
    */
   @Bean
   public Docket api() {
       return new Docket(DocumentationType.SWAGGER_2)
               .select()
               .apis(RequestHandlerSelectors.any())
               .paths(PathSelectors.any())
               .build()
               .securityContexts(Collections.singletonList(securityContext()))
               .securitySchemes(Collections.singletonList(apiKey()))
               .apiInfo(apiInfo());
   }

   /**
    * Api key.
    *
    * @return the api key
    */
   private ApiKey apiKey() {
       return new ApiKey("JWT", HttpHeaders.AUTHORIZATION, "header");
   }

   /**
    * Security context.
    *
    * @return the security context
    */
   private SecurityContext securityContext() {
       return SecurityContext.builder()
               .securityReferences(Collections.singletonList(new SecurityReference("JWT", new AuthorizationScope[0])))
               .forPaths(PathSelectors.any())
               .build();
   }

   /**
    * Api info.
    *
    * @return the api info
    */
   private ApiInfo apiInfo() {
       return new ApiInfoBuilder()
               .title("My API")
               .description("My API description")
               .version("1.0")
               .build();
   }
}
