package com.recoveryportal.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.recoveryportal.config.common.base.dao.BaseDao;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.dao.PageDao;
import com.recoveryportal.transfer.object.entity.Page;

/**
 * The Class PageDaoImpl.
 */
@Repository
@Transactional
public class PageDaoImpl extends BaseDao implements PageDao {

    /** The model mapper. */
    @Autowired
    ModelMapper modelMapper;
    
    /**
     * Register data filters.
     */
    @Override
    public void registerDataFilters() {

    }


    /**
     * Gets the all page dto details.
     *
     * @return the all page dto details
     */
    @Override
    public List<Page> getAllPageDtoDetails() {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<Page> criteria = builder.createQuery(Page.class);
        Root<Page> root = criteria.from(Page.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.isFalse(root.get(TableConstants.ISDELETED)));
        return  (List<Page>) getResultList(createQuery(builder, criteria, root, predicates));
    }

    /**
     * Gets the all page data by user id.
     *
     * @param pageIdList the page id list
     * @return the all page data by user id
     */
    @Override
    public List<Page> getAllPageDataByUserId(List<String> pageIdList) {

        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<Page> criteria = builder.createQuery(Page.class);
        Root<Page> root = criteria.from(Page.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.isFalse(root.get(TableConstants.ISDELETED)));

        Expression<String> parentExpression = root.get(TableConstants.PAGE_ID);
        Predicate parentPredicate = parentExpression.in(pageIdList);
        predicates.add(builder.and(parentPredicate));

        return (List<Page>) getResultList(createQuery(builder, criteria, root, predicates));
    }
    

    /**
     * Gets the page by identity.
     *
     * @param pageIdentity the page identity
     * @return the page by identity
     */
    @Override
    public Page getPageByIdentity(String pageIdentity) {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<Page> criteria = builder.createQuery(Page.class);
        Root<Page> root = criteria.from(Page.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.isFalse(root.get(TableConstants.ISDELETED)));
        predicates.add(builder.equal(root.get(TableConstants.IDENTITY),pageIdentity));
        return   (Page) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);
    }

}
