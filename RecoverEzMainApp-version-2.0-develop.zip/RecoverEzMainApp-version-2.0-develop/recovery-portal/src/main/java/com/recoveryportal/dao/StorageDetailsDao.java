package com.recoveryportal.dao;

import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.transfer.object.entity.FileStorageDetails;

/**
 * The Interface StorageDetailsDao.
 */
public interface StorageDetailsDao {
    
    /**
     * Save storage details.
     *
     * @param fileStorageDetails the file storage details
     * @return the file storage details
     * @throws ApplicationException the application exception
     */
    FileStorageDetails saveStorageDetails(FileStorageDetails fileStorageDetails) throws ApplicationException;
}
