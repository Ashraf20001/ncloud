package com.recoveryportal.controller;

import com.recoveryportal.transfer.object.entity.SchedulerNotification;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.recoveryportal.config.base.controller.BaseController;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.service.SchedulerService;
import com.recoveryportal.transfer.object.core.ApplicationResponse;
import com.recoveryportal.transfer.object.dto.SchedulerNotificationDto;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * The Class SchedulerController.
 */
@RestController
public class SchedulerController extends BaseController {
	
	/** The scheduler service. */
	@Autowired
	SchedulerService schedulerService;
	
    /**
     * Gets the scheduler details list.
     *
     * @return the scheduler details list
     */
	@ApiOperation(value="Scheduler data",notes="Get all scheduler data",response = ApplicationResponse.class)
    @GetMapping("/get-scheduler-details")
	public ApplicationResponse getSchedulerDetailsList() {
		return getApplicationResponse(schedulerService.getSchedulerDetailsList()) ;

	}
    
    /**
     * Gets the scheduler detail by id.
     *
     * @param schedularId the schedular id
     * @return the scheduler detail by id
     */
	@ApiOperation(value="Schedular details",notes="Get scheduler details by id",response = ApplicationResponse.class)
    @GetMapping("/get-scheduler-details-by-id")
	public ApplicationResponse getSchedulerDetailById(@ApiParam(value = "Scheduler id",required = true) @RequestParam(name = "schedularId")Integer schedularId) {
		return getApplicationResponse(schedulerService.getSchedulerDetailsById(schedularId)) ;

	}
    
    /**
     * Upadate scheduler detail.
     *
     * @param schedulerNotificationDto the scheduler notification dto
     */
	@ApiOperation(value="Update schedular details",notes="Update scheduler details by scheduler notification details")
    @PostMapping("/update-scheduler-details")
	public void upadateSchedulerDetail(@ApiParam(value = "Scheduler notification paylaod",required = true) @RequestBody SchedulerNotificationDto schedulerNotificationDto) {
		 schedulerService.upadateSchedulerDetail(schedulerNotificationDto);
	}
    
    /**
     * Trigger monthly report generation.
     */
	@ApiOperation(value="Trigger report generation",notes="Trigger scheduler for monthly report")
    @PostMapping("/trigger-monthly-report-generation")
    public void triggerMonthlyReportGeneration() {
    	schedulerService.triggerMonthlyReportGeneration();
    }
    
    /**
     * Trigger payment reminder.
     */
	@ApiOperation(value="Trigger payment reminder",notes="Trigger scheduler for payment reminder")
    @PostMapping("/trigger-payment-reminder-setup")
    public void triggerPaymentReminder() {
    	schedulerService.triggerPaymentReminder();
    }
    
    /**
     * Gets the payment reminder notification template.
     *
     * @return the payment reminder notification template
     */
    @GetMapping("/notification/get-payment-reminder-notification-template")
    public String getPaymentReminderNotificationTemplate() {
    	return schedulerService.getPaymentReminderNotificationTemplate();
    }
	
	/**
	 * Gets the reminder notification from scheduler.
	 *
	 * @param triggeredStatus the triggered status
	 * @return the reminder notification from scheduler
	 */
	@GetMapping("/notification/get-reminder-notification-template")
    public SchedulerNotification getReminderNotificationFromScheduler(@RequestParam("triggeredStatus") String triggeredStatus) {
		triggeredStatus = URLDecoder.decode(triggeredStatus, StandardCharsets.UTF_8);
    	return schedulerService.getReminderNotificationFromScheduler(triggeredStatus);
    }


	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {
		
	}

}
