package com.recoveryportal.dao;

import java.util.List;

import com.recoveryportal.transfer.object.entity.DropDownListOptionMapping;

/**
 * The Interface IDropDownListOptionMapDAO.
 */
public interface IDropDownListOptionMapDAO {

	/**
	 * Gets the drop down options list by drop down id.
	 *
	 * @param dropdownId the dropdown id
	 * @param parentOptionId the parent option id
	 * @return the drop down options list by drop down id
	 */
	List<DropDownListOptionMapping> getDropDownOptionsListByDropDownId(Integer dropdownId, Integer parentOptionId);
}
