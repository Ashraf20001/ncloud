package com.recoveryportal.dao.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.recoveryportal.config.common.base.dao.BaseDao;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.dao.BulkImportHistoryDao;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.transfer.object.entity.BulkImportErrorData;
import com.recoveryportal.transfer.object.entity.BulkImportHistory;

/**
 * The Class BulkImportHistoryDaoImpl.
 */
@Repository
@Transactional
public class BulkImportHistoryDaoImpl extends BaseDao implements BulkImportHistoryDao {
    
    /**
     * Gets the all import history by company.
     *
     * @param companyId the company id
     * @return the all import history by company
     */
    @Override
    public List<BulkImportHistory> getAllImportHistoryByCompany(Integer companyId) {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<BulkImportHistory> criteria = builder.createQuery(BulkImportHistory.class);
        Root<BulkImportHistory> root = criteria.from(BulkImportHistory.class);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.COMPANY_ID),companyId)));
        predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
        criteria.orderBy(builder.desc(root.get(TableConstants.UPLOAD_ID)));
        return (List<BulkImportHistory>)getResultList(createQuery(builder, criteria, root, predicates));
    }

    /**
     * Gets the bulk import error data by upload id.
     *
     * @param uploadId the upload id
     * @return the bulk import error data by upload id
     */
    @Override
    public List<BulkImportErrorData> getBulkImportErrorDataByUploadId(String uploadId) {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<BulkImportErrorData> criteria = builder.createQuery(BulkImportErrorData.class);
        Root<BulkImportErrorData> root = criteria.from(BulkImportErrorData.class);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.UPLOAD_ID).get(TableConstants.IDENTITY),uploadId)));
        predicates.add(builder.and(builder.isFalse(root.get(TableConstants.UPLOAD_ID).get(TableConstants.ISDELETED))));
        criteria.orderBy(builder.desc(root.get(TableConstants.UPLOAD_ID)));
        return (List<BulkImportErrorData>)getResultList(createQuery(builder, criteria, root, predicates));
    }

    /**
     * Save bulk upload history.
     *
     * @param bulkImportHistory the bulk import history
     * @return the bulk import history
     * @throws ApplicationException the application exception
     */
    @Override
    public BulkImportHistory saveBulkUploadHistory(BulkImportHistory bulkImportHistory) throws ApplicationException {
        save(bulkImportHistory,TableConstants.BULK_IMPORT_HISTORY);
        return bulkImportHistory;
    }

    /**
     * Updatebulk import history.
     *
     * @param bulkImportHistory the bulk import history
     * @return the bulk import history
     */
    @Override
    public BulkImportHistory updatebulkImportHistory(BulkImportHistory bulkImportHistory) {
        update(bulkImportHistory);
        return bulkImportHistory;
    }

    /**
     * Gets the file path by bulk upload id.
     *
     * @param uploadId the upload id
     * @return the file path by bulk upload id
     */
    @Override
    public String getFilePathByBulkUploadId(Integer uploadId) {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<String> criteria = builder.createQuery(String.class);
        Root<BulkImportHistory> root = criteria.from(BulkImportHistory.class);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.UPLOAD_ID),uploadId)));
        criteria.select(root.get(TableConstants.STORAGE_ID).get(TableConstants.URL));
        return (String)getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst()
                .orElse(null);
    }

    /**
     * Gets the bulk import history by id.
     *
     * @param identity the identity
     * @return the bulk import history by id
     */
    @Override
    public BulkImportHistory getBulkImportHistoryById(String identity) {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<BulkImportHistory> criteria = builder.createQuery(BulkImportHistory.class);
        Root<BulkImportHistory> root = criteria.from(BulkImportHistory.class);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.IDENTITY),identity)));
        criteria.orderBy(builder.desc(root.get(TableConstants.UPLOAD_ID)));
        return (BulkImportHistory)getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);
    }
    
    
    /**
     * Gets the bulk import history by upload id.
     *
     * @param id the id
     * @return the bulk import history by upload id
     */
    @Override
    public BulkImportHistory getBulkImportHistoryByUploadId(Integer id) {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<BulkImportHistory> criteria = builder.createQuery(BulkImportHistory.class);
        Root<BulkImportHistory> root = criteria.from(BulkImportHistory.class);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.UPLOAD_ID),id)));
        return (BulkImportHistory)getSingleResult(createQuery(builder, criteria, root, predicates));
    }

    /**
     * Register data filters.
     */
    @Override
    public void registerDataFilters() {

    }

	/**
	 * 	UpdateDeletedCount.
	 *
	 * @param uploadId the upload id
	 * @param userId the user id
	 * @param totalCount the total count
	 * @param failureCount the failure count
	 */
	@Override
	public void updateDeletedCount(Integer uploadId, String userId, Integer totalCount, Integer failureCount) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaUpdate<BulkImportHistory> criteria = builder.createCriteriaUpdate(BulkImportHistory.class);
		Root<BulkImportHistory> root = criteria.from(BulkImportHistory.class);
		criteria.set(root.get(TableConstants.MODIFIED_DATE), LocalDateTime.now());
		criteria.set(root.get(TableConstants.MODIFIED_BY), Integer.parseInt(userId));
		criteria.set(root.get(TableConstants.TOTAL_COUNT), totalCount - 1);
		criteria.set(root.get(TableConstants.FAILURE_COUNT), failureCount - 1);
		criteria.where(builder.equal(root.get(TableConstants.UPLOAD_ID), uploadId));
		createQueryupdate(criteria).executeUpdate();

	}
}
