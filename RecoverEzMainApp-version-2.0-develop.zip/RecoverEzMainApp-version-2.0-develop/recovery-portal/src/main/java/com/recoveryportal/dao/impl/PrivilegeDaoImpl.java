package com.recoveryportal.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.recoveryportal.config.common.base.dao.BaseDao;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.dao.PrivilegeDao;
import com.recoveryportal.transfer.object.entity.Privilege;

/**
 * The Class PrivilegeDaoImpl.
 */
@Repository
@Transactional
public class PrivilegeDaoImpl extends BaseDao implements PrivilegeDao {
    
    /** The model mapper. */
    @Autowired
    ModelMapper modelMapper;
    
    /** The entity manager. */
    @PersistenceContext
	@Autowired
	private EntityManager entityManager;
    
    /**
     * Register data filters.
     */
    @Override
    public void registerDataFilters() {

    }


    /**
     * Gets the all privilege dto details.
     *
     * @return the all privilege dto details
     */
    @Override
    public List<Privilege> getAllPrivilegeDtoDetails() {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<Privilege> criteria = builder.createQuery(Privilege.class);
        Root<Privilege> root = criteria.from(Privilege.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.isFalse(root.get(TableConstants.ISDELETED)));
        predicates.add(builder.isFalse(root.get(TableConstants.ID_DEFAULT)));
        return (List<Privilege>) getResultList(createQuery(builder, criteria, root, predicates));
    }
    

}
