package com.recoveryportal.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.recoveryportal.config.common.base.dao.BaseDao;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.constants.enums.DropDownTypeEnum;
import com.recoveryportal.dao.IFieldDropDownListMapDao;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.transfer.object.entity.FieldDropDownListMap;

/**
 * The Class FieldDropDownListMapDaoImpl.
 */
@Repository
public class FieldDropDownListMapDaoImpl extends BaseDao implements IFieldDropDownListMapDao {

	/**
	 * Save field drop down list map.
	 *
	 * @param fieldDropDownListMap the field drop down list map
	 * @return the field drop down list map
	 * @throws ApplicationException the application exception
	 */
	@Override
	public FieldDropDownListMap saveFieldDropDownListMap(FieldDropDownListMap fieldDropDownListMap)
			throws ApplicationException {
		save(fieldDropDownListMap, TableConstants.FIELD_DROPDOWN_LIST_MAP);
		return fieldDropDownListMap;
	}

	/**
	 * Update field drop down list map.
	 *
	 * @param fieldDropDownListMap the field drop down list map
	 * @return the field drop down list map
	 */
	@Override
	public FieldDropDownListMap updateFieldDropDownListMap(FieldDropDownListMap fieldDropDownListMap) {
		update(fieldDropDownListMap);
		return fieldDropDownListMap;
	}

	/**
	 * Gets the field drop down list map by field id.
	 *
	 * @param fieldId the field id
	 * @return the field drop down list map by field id
	 */
	@Override
	public FieldDropDownListMap getFieldDropDownListMapByFieldId(int fieldId) {
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<FieldDropDownListMap> criteria = builder.createQuery(FieldDropDownListMap.class);
        Root<FieldDropDownListMap> root = criteria.from(FieldDropDownListMap.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.isFalse(root.get(TableConstants.ISDELETED)));
        predicates.add(builder.equal(root.get(TableConstants.FIELD).get(TableConstants.FIELD_ID), fieldId));
		return (FieldDropDownListMap)getSingleResult(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Gets the field drop down list map by field identity.
	 *
	 * @param fieldIdentity the field identity
	 * @return the field drop down list map by field identity
	 */
	@Override
	public FieldDropDownListMap getFieldDropDownListMapByFieldIdentity(String fieldIdentity) {
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<FieldDropDownListMap> criteria = builder.createQuery(FieldDropDownListMap.class);
        Root<FieldDropDownListMap> root = criteria.from(FieldDropDownListMap.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.isFalse(root.get(TableConstants.ISDELETED)));
        predicates.add(builder.equal(root.get(TableConstants.FIELD).get(TableConstants.IDENTITY), fieldIdentity));
		return (FieldDropDownListMap)getSingleResult(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Gets the field drop down list map.
	 *
	 * @return the field drop down list map
	 */
	@Override
	public List<FieldDropDownListMap> getFieldDropDownListMap() {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<FieldDropDownListMap> criteria = builder.createQuery(FieldDropDownListMap.class);
		Root<FieldDropDownListMap> root = criteria.from(FieldDropDownListMap.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.isFalse(root.get(TableConstants.ISDELETED)));
		return (List<FieldDropDownListMap>)getResultList(createQuery(builder, criteria, root, predicates));
	}
	
	/**
	 * Gets the currency field drop down list map.
	 *
	 * @return the currency field drop down list map
	 * @throws ApplicationException the application exception
	 */
	@Override
	public FieldDropDownListMap getCurrencyFieldDropDownListMap() throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<FieldDropDownListMap> criteria = builder.createQuery(FieldDropDownListMap.class);
		Root<FieldDropDownListMap> root = criteria.from(FieldDropDownListMap.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.isFalse(root.get(TableConstants.ISDELETED)));
		predicates.add(builder.equal(root.get(TableConstants.DROPDOWNLIST).get(TableConstants.DROPDOWN_TYPE), DropDownTypeEnum.CURRENCY.typeId));
		return (FieldDropDownListMap)getSingleResult(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
	}

}
