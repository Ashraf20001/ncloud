package com.recoveryportal.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.service.IRecoveryManageDataService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;


/**
 * The Class ManageDataController.
 */
@RestController
@RequestMapping("/data")
public class ManageDataController {

	/** The recovery manage data service. */
	@Autowired
	private IRecoveryManageDataService recoveryManageDataService;

	/**
	 * Export master datas.
	 *
	 * @param tableEntityList the table entity list
	 * @return the list
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@ApiOperation(value="export master data",notes="Endpoint for export master data operation",response=List.class)
	@PostMapping("/export-master-datas")
	public List<Map<String, Object>> exportMasterDatas(@ApiParam(value="tableEntityList payload", required=true) @RequestBody List<String> tableEntityList) throws IOException {
		return recoveryManageDataService.exportMasterDatas(tableEntityList);
	}

	/**
	 * Import master datas.
	 *
	 * @param recoveryMasterDataMap the recovery master data map
	 * @throws ApplicationException the application exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@ApiOperation(value="import master data",notes="Endpoint for import master data operation")
	@RequestMapping("/import-master-datas")
	public void importMasterDatas(@ApiParam(value="import master data type parameters") @RequestBody(required = false) Map<String, Object> recoveryMasterDataMap)
			throws ApplicationException, IOException {
		recoveryManageDataService.importMasterData(recoveryMasterDataMap);
	}

}
