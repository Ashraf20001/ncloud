package com.recoveryportal.dao;

import java.util.List;

import com.recoveryportal.transfer.object.entity.Menu;

/**
 * The Interface MenuDao.
 */
public interface MenuDao {

    /**
     * Gets the all menu dto details.
     *
     * @return the all menu dto details
     */
    List<Menu> getAllMenuDtoDetails();

    /**
     * Gets the all menu data by user id.
     *
     * @param menuIdList the menu id list
     * @return the all menu data by user id
     */
    List<Menu> getAllMenuDataByUserId(List<String> menuIdList);

}
