package com.recoveryportal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.recoveryportal.aop.annotation.Auditable;
import com.recoveryportal.config.base.controller.BaseController;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.service.DashboardDetailsService;
import com.recoveryportal.transfer.object.core.ApplicationResponse;
import com.recoveryportal.transfer.object.dto.InsuredAndTpArray;
import com.recoveryportal.transfer.object.dto.PayableDashboardDto;
import com.recoveryportal.transfer.object.dto.ReceivableDashboardDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class DashboardDetailsController.
 */
@RestController
@RequestMapping("/dashboard")
@Auditable
public class DashboardDetailsController extends BaseController {
    
    /** The dashboard details service. */
    @Autowired
    DashboardDetailsService dashboardDetailsService;
    
    /**
     * Gets the payable dashboard details.
     *
     * @param insuredAndTpArray the insured and tp array
     * @param currencyId the currency id
     * @return the payable dashboard details
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Total Payable Details", notes = "Get total payable details for dashboard header",response = ApplicationResponse.class)
    @PostMapping("/payable-details")
    public ApplicationResponse getPayableDashboardDetails( @ApiParam(value="Insured and Tp Companies payload",required = true) @RequestBody InsuredAndTpArray insuredAndTpArray,
    		@ApiParam(value="currency",required = true)	@RequestParam("cur") Integer currencyId) throws ApplicationException {
        PayableDashboardDto payableDashboardDto = dashboardDetailsService.getPayableDashboardDetails(insuredAndTpArray, currencyId);
        return getApplicationResponse(payableDashboardDto);
    }
    
    /**
     * Gets the receivable dashboard details.
     *
     * @param insuredAndTpArray the insured and tp array
     * @param currencyId the currency id
     * @return the receivable dashboard details
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Total Receivable Details", notes = "Get total receivable details for dashboard header",response = ApplicationResponse.class)
    @PostMapping("receivable-details")
    public ApplicationResponse getReceivableDashboardDetails(@ApiParam(value="Insured and Tp Companies payload",required = true) @RequestBody InsuredAndTpArray insuredAndTpArray,
    		@ApiParam(value="currency",required = true) @RequestParam("cur") Integer currencyId) throws ApplicationException {
        ReceivableDashboardDto receivableDashboardDto = dashboardDetailsService.getReceivableDashboardDetails(insuredAndTpArray, currencyId);
        return getApplicationResponse(receivableDashboardDto);
    }
    
    /**
     * Gets the currency type list.
     *
     * @return the currency type list
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Currency type Details", notes = "Get currency type list",response = ApplicationResponse.class)
    @GetMapping("currency-types")
    public ApplicationResponse getCurrencyTypeList() throws ApplicationException {
    	return getApplicationResponse(dashboardDetailsService.getCurrencyTypeList());
    }

    /**
     * Gets the class name.
     *
     * @return the class name
     */
    @Override
    protected Class<?> getClassName() {
        return this.getClass();
    }

    /**
     * Gets the vo.
     *
     * @param identity the identity
     * @return the vo
     * @throws ApplicationException the application exception
     */
    @Override
    public Object getVo(String identity) throws ApplicationException {return null; }

    /**
     * Register interceptor.
     */
    @Override
    protected void registerInterceptor() {}
}
