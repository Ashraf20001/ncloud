package com.recoveryportal.dao;

import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.transfer.object.entity.BulkImportErrorData;
import com.recoveryportal.transfer.object.entity.BulkImportTempData;

import java.util.List;

/**
 * The Interface BulkImportErrorDataDao.
 */
public interface BulkImportErrorDataDao {
    
    /**
     * Save bulk import error data.
     *
     * @param bulkImportErrorData the bulk import error data
     * @return the bulk import error data
     * @throws ApplicationException the application exception
     */
    BulkImportErrorData saveBulkImportErrorData(BulkImportErrorData bulkImportErrorData) throws ApplicationException;

    /**
     * Save bulk import temp data.
     *
     * @param importData the import data
     * @return the bulk import temp data
     * @throws ApplicationException the application exception
     */
    BulkImportTempData saveBulkImportTempData(BulkImportTempData importData) throws ApplicationException;

    /**
     * Error data delete.
     *
     * @param uploadIdentity the upload identity
     * @param userId the user id
     * @return the int
     */
    int errorDataDelete(String uploadIdentity, Integer userId);

    /**
     * Gets the error data by upload id.
     *
     * @param uploadDataId the upload data id
     * @return the error data by upload id
     */
    BulkImportTempData getErrorDataByUploadId(String uploadDataId);
}
