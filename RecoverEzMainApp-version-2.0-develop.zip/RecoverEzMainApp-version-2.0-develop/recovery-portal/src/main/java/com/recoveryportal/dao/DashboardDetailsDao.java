package com.recoveryportal.dao;

import java.util.List;

/**
 * The Interface DashboardDetailsDao.
 */
public interface DashboardDetailsDao {
    
    /**
     * Gets the total receivable count.
     *
     * @param companyList the company list
     * @param isAssociate the is associate
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the total receivable count
     */
    Long getTotalReceivableCount(List<String>companyList,boolean isAssociate, String currencyFieldName, String currencyValue);

    /**
     * Gets the total payable count.
     *
     * @param companyList the company list
     * @param isAssociate the is associate
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the total payable count
     */
    Long getTotalPayableCount(List<String>companyList,boolean isAssociate, String currencyFieldName, String currencyValue);

    /**
     * Gets the count by stage list.
     *
     * @param isReceivable the is receivable
     * @param companyList the company list
     * @param stateList the state list
     * @param isAssociate the is associate
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the count by stage list
     */
    Long getCountByStageList(boolean isReceivable, List<String> companyList, List<String> stateList,boolean isAssociate, String currencyFieldName, String currencyValue);

    /**
     * Gets the total receivable amount.
     *
     * @param companyList the company list
     * @param isAssociate the is associate
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the total receivable amount
     */
    Double getTotalReceivableAmount(List<String>companyList,boolean isAssociate, String currencyFieldName, String currencyValue);

    /**
     * Gets the total payable amount.
     *
     * @param companyList the company list
     * @param isAssociate the is associate
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the total payable amount
     */
    Double getTotalPayableAmount(List<String>companyList,boolean isAssociate, String currencyFieldName, String currencyValue);
}
