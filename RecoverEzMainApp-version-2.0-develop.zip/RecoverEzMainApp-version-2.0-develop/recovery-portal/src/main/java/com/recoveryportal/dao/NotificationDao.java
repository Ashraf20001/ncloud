package com.recoveryportal.dao;

import com.recoveryportal.transfer.object.notification.entity.NotificationEvent;

/**
 * The Interface NotificationDao.
 */
public interface NotificationDao {

	/**
	 * Gets the notification event by event name.
	 *
	 * @param state the state
	 * @return the notification event by event name
	 */
	NotificationEvent getNotificationEventByEventName(String state);

}
