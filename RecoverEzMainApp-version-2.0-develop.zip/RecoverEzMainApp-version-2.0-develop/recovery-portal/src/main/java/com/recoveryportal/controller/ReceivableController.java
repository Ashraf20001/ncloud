package com.recoveryportal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.recoveryportal.aop.annotation.Auditable;
import com.recoveryportal.config.base.controller.BaseController;
import com.recoveryportal.dao.ReceivableDao;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.service.ReceivableService;
import com.recoveryportal.transfer.object.core.ApplicationResponse;
import com.recoveryportal.transfer.object.dto.ListOfString;
import com.recoveryportal.transfer.object.reportloss.dto.ReportLossViewDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class ReceivableController.
 */
@RestController
@Auditable
public class ReceivableController extends BaseController{
	
	/** The receivable dao. */
	@Autowired private ReceivableDao receivableDao;
	
	/** The receivable service. */
	@Autowired private ReceivableService receivableService;

	/**
	 * Gets the receivable list.
	 *
	 * @param list the list
	 * @return the receivable list
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Receivable list",notes="Get list of receivable for the list of companies",response=ApplicationResponse.class)
	@PostMapping("/get-receivable-list")
	public ApplicationResponse getReceivableList( @ApiParam(value="company id list payload",required=true) @RequestBody ListOfString list) throws ApplicationException{
	List<ReportLossViewDto> reportLossDto=	receivableService.getRecivableList(list);
				return getApplicationResponse(reportLossDto);
		}
	
	/**
	 * Gets the receivable list count.
	 *
	 * @param list the list
	 * @return the receivable list count
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Receivable count",notes="Get receivable count for the list of companies",response=ApplicationResponse.class)
	@PostMapping("/get-receivable-listCount")
	public ApplicationResponse getReceivableListCount(@ApiParam(value="company id list payload",required=true) @RequestBody ListOfString list) throws ApplicationException{
	Long reportLossDto=	receivableService.getRecivableListCount(list);
				return getApplicationResponse(reportLossDto);
		}
	
	 /**
 	 * Delete recivable data.
 	 *
 	 * @param claimId the claim id
 	 * @return the application response
 	 * @throws ApplicationException the application exception
 	 * @throws ClassNotFoundException the class not found exception
 	 */
	@ApiOperation(value="Receivable delete",notes="Delete receivable using claim id",response=ApplicationResponse.class)
 	@PostMapping("/receivable/DeleteId")
	    public ApplicationResponse DeleteRecivableData(@ApiParam(value="claim id",required=true)  @RequestParam(name="claimId")String claimId) throws ApplicationException, ClassNotFoundException{
	    	return getApplicationResponse(receivableService.DeleteRecivableData(claimId));
	    }
	 
 	/**
 	 * Gets the all receivable list.
 	 *
 	 * @param list the list
 	 * @return the all receivable list
 	 * @throws ApplicationException the application exception
 	 */
	@ApiOperation(value="All receivable list",notes="Get all receivable list for the authority",response=ApplicationResponse.class)
 	@PostMapping("/all-receivable-list")
	 public ApplicationResponse getAllReceivableList(@ApiParam(value="company id list payload",required=true) @RequestBody ListOfString list) throws ApplicationException{
		 List<ReportLossViewDto> reportLossDto=	receivableService.getAllReceivables(list);
			return getApplicationResponse(reportLossDto);
	 }
	 
	 /**
 	 * Gets the all receivable list count.
 	 *
 	 * @param list the list
 	 * @return the all receivable list count
 	 * @throws ApplicationException the application exception
 	 */
	@ApiOperation(value="All receivable list count",notes="Get all receivable list count for the authority",response=ApplicationResponse.class)
 	@PostMapping("/all-receivable-listCount")
	 public ApplicationResponse getAllReceivableListCount(@ApiParam(value="company id list payload",required=true) @RequestBody ListOfString list) throws ApplicationException{
		Long reportLossDto=	receivableService.getAllReceivablesCount(list);
			return getApplicationResponse(reportLossDto);
	 }
	 
		/**
		 * ExportReceivableListAsExcel.
		 *
		 * @param list the list
		 * @return the response entity
		 * @throws Exception the exception
		 */
	    @ApiOperation(value="Export receivable list as excel",notes="Export the receivable list for certain companies",response=ApplicationResponse.class)
		@PostMapping("/generate/recivableList/export-to-excel")
		public ResponseEntity<InputStreamResource> exportReceivableListAsExcel(@ApiParam(value="company id list payload",required=true) @RequestBody ListOfString list)
				throws Exception {

			return receivableService.exportReceivableListAsExcel(list);
		}

		/**
		 * GET RECEIVABLELIST FILTER.
		 *
		 * @param filterVo the filter vo
		 * @return the filtred receivable list
		 * @throws ApplicationException the application exception
		 */
	    @ApiOperation(value="Filtered receivable list",notes="Filtered receivable list for the company list",response=ApplicationResponse.class)
		@PostMapping("/filter/recivableList")
		public ApplicationResponse getFiltredReceivableList( @ApiParam(value="company id list filter payload",required=true) @RequestBody ListOfString filterVo)
				throws ApplicationException {
			return getApplicationResponse(receivableService.getReceivableListFilter(filterVo));
		}

		/**
		 * GET RECEIVABLELIST FILTER COUNT.
		 *
		 * @param filterVo the filter vo
		 * @return the filterd receivable list count
		 * @throws ApplicationException the application exception
		 */
	    @ApiOperation(value="Filtered receivable count",notes="Filtered receivable count for the company list",response=ApplicationResponse.class)
		@PostMapping("/filter/recivableListCount")
		public ApplicationResponse getFilterdReceivableListCount(@ApiParam(value="company id list filter payload",required=true) @RequestBody ListOfString filterVo)
				throws ApplicationException {
			return getApplicationResponse(receivableService.getFilterdReceivableListCount(filterVo));
		}

		/**
		 * GET FILTERED ALL RECEIVABLE-LIST.
		 *
		 * @param filterVo the filter vo
		 * @return the filtered all receivable list
		 * @throws ApplicationException the application exception
		 */
	    @ApiOperation(value="Filtered  all receivable list",notes="Filtered receivable list for the authority",response=ApplicationResponse.class)
		@PostMapping("/filter/all-recivableList")
		public ApplicationResponse getFilteredAllReceivableList(@ApiParam(value="company id list filter payload",required=true)  @RequestBody ListOfString filterVo)
				throws ApplicationException {
			List<ReportLossViewDto> reportLossDto = receivableService.getFilteredAllReceivableList(filterVo);
			return getApplicationResponse(reportLossDto);
		}

		/**
		 * GET FILTERD ALL RECEIVABLE-LIST COUNT.
		 *
		 * @param filterVo the filter vo
		 * @return the associate filterd receivable list count
		 * @throws ApplicationException the application exception
		 */
	    @ApiOperation(value="Filtered  all receivable count",notes="Filtered receivable count for the authority",response=ApplicationResponse.class)
		@PostMapping("/filter/all-recivableListCount")
		public ApplicationResponse getAssociateFilterdReceivableListCount( @ApiParam(value="company id list filter payload",required=true) @RequestBody ListOfString filterVo)
				throws ApplicationException {
			return getApplicationResponse(receivableService.getAssociateFilterdReceivableListCount(filterVo));
		}

	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {
		
	}

}
