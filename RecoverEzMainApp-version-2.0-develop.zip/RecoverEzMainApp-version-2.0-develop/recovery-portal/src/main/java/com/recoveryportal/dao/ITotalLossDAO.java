package com.recoveryportal.dao;

import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.transfer.object.entity.DropDownList;
import com.recoveryportal.transfer.object.entity.Field;
import com.recoveryportal.transfer.object.entity.TotalLoss;
import com.recoveryportal.transfer.object.reportloss.entity.DropdownOptions;

/**
 * The Interface ITotalLossDAO.
 */
public interface ITotalLossDAO {

	/**
	 * Save total loss.
	 *
	 * @param totalLoss the total loss
	 * @return the total loss
	 * @throws ApplicationException the application exception
	 */
	TotalLoss saveTotalLoss(TotalLoss totalLoss) throws ApplicationException;
	
	/**
	 * Update total loss.
	 *
	 * @param totalLoss the total loss
	 * @return the total loss
	 */
	TotalLoss updateTotalLoss(TotalLoss totalLoss);
	
	/**
	 * Gets the total loss by claim id.
	 *
	 * @param claimId the claim id
	 * @return the total loss by claim id
	 */
	TotalLoss getTotalLossByClaimId(Integer claimId);
	
	/**
	 * Gets the total loss by id.
	 *
	 * @param id the id
	 * @return the total loss by id
	 */
	TotalLoss getTotalLossById(Integer id);

	/**
	 * Gets the field id.
	 *
	 * @param fieldId the field id
	 * @return the field id
	 */
	Field getFieldId(String fieldId);

	/**
	 * Gets the drop down value.
	 *
	 * @param reasonForTotalLoss the reason for total loss
	 * @return the drop down value
	 */
	DropdownOptions getDropDownValue(String reasonForTotalLoss);

	/**
	 * Gets the drop down data.
	 *
	 * @param reasonForTotalLoss the reason for total loss
	 * @return the drop down data
	 */
	DropdownOptions getDropDownData(DropdownOptions reasonForTotalLoss);
}
