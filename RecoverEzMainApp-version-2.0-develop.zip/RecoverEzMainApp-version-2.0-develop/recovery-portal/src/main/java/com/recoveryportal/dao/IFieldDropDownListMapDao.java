package com.recoveryportal.dao;

import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.transfer.object.entity.FieldDropDownListMap;

import java.util.List;

/**
 * The Interface IFieldDropDownListMapDao.
 */
public interface IFieldDropDownListMapDao {

	/**
	 * Save field drop down list map.
	 *
	 * @param fieldDropDownListMap the field drop down list map
	 * @return the field drop down list map
	 * @throws ApplicationException the application exception
	 */
	FieldDropDownListMap saveFieldDropDownListMap(FieldDropDownListMap fieldDropDownListMap) throws ApplicationException;
	
	/**
	 * Update field drop down list map.
	 *
	 * @param fieldDropDownListMap the field drop down list map
	 * @return the field drop down list map
	 */
	FieldDropDownListMap updateFieldDropDownListMap(FieldDropDownListMap fieldDropDownListMap);
	
	/**
	 * Gets the field drop down list map by field id.
	 *
	 * @param fieldId the field id
	 * @return the field drop down list map by field id
	 */
	FieldDropDownListMap getFieldDropDownListMapByFieldId(int fieldId);
	
	/**
	 * Gets the field drop down list map by field identity.
	 *
	 * @param fieldIdentity the field identity
	 * @return the field drop down list map by field identity
	 */
	FieldDropDownListMap getFieldDropDownListMapByFieldIdentity(String fieldIdentity);
	
	/**
	 * Gets the field drop down list map.
	 *
	 * @return the field drop down list map
	 */
	List<FieldDropDownListMap> getFieldDropDownListMap();
	
	/**
	 * Gets the currency field drop down list map.
	 *
	 * @return the currency field drop down list map
	 * @throws ApplicationException the application exception
	 */
	FieldDropDownListMap getCurrencyFieldDropDownListMap() throws ApplicationException;
}
