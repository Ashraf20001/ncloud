package com.recoveryportal.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.recoveryportal.transfer.object.entity.AuthorityPayments;
import org.springframework.stereotype.Repository;

import com.recoveryportal.config.common.base.dao.BaseDao;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.dao.PaymentDetailsDao;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.transfer.object.constants.BasePredicateEntityColumnMap;
import com.recoveryportal.transfer.object.entity.PaymentDetails;
import com.recoveryportal.utils.core.ApplicationUtils;

/**
 * The Class PaymentDetailsDaoImpl.
 */
@Repository
public class PaymentDetailsDaoImpl extends BaseDao implements PaymentDetailsDao{

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {		
	}
	
	/**
	 * Save.
	 *
	 * @param paymentDetails the payment details
	 * @return the payment details
	 * @throws ApplicationException the application exception
	 */
	@Override
	public PaymentDetails save(PaymentDetails paymentDetails) throws ApplicationException {
		save(paymentDetails,TableConstants.PAYMENT_DETAILS);
		return paymentDetails;
	}

	/**
	 * Gets the payment details.
	 *
	 * @param toCompany the to company
	 * @param min the min
	 * @param max the max
	 * @return the payment details
	 */
	@Override
	public List<PaymentDetails> getPaymentDetails(Integer toCompany, Integer min, Integer max){
	CriteriaBuilder builder = getCriteriaBuilder();
	CriteriaQuery<PaymentDetails> criteria = builder.createQuery(PaymentDetails.class);
	Root<PaymentDetails> root = criteria.from(PaymentDetails.class);
	criteria.select(root);
	List<Predicate> predicates = new ArrayList<>();
	predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
	String javaTypeInString=null;
	if(ApplicationUtils.isValidateObject(toCompany)) {
		javaTypeInString = root.getModel().getJavaType().toString();
	}else {
		predicates.add(builder.and(builder.isNull(root.get(TableConstants.TO_COMPANY))));
	}
	criteria.orderBy(builder.desc(root.get(TableConstants.MODIFIED_DATE)));
	String joinColumn = BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(javaTypeInString);
	return (List<PaymentDetails>) getResultList(getBasePredicateResult(builder, criteria, root, joinColumn, predicates).setFirstResult(min).setMaxResults(max));
	}
	
	/**
	 * Gets the payment details count.
	 *
	 * @param toCompany the to company
	 * @return the payment details count
	 */
	@Override
	public Long getPaymentDetailsCount(Integer toCompany){
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<PaymentDetails> root = criteria.from(PaymentDetails.class);
		criteria.select(builder.count(root));
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		String javaTypeInString=null;
		if(ApplicationUtils.isValidateObject(toCompany)) {
				javaTypeInString = root.getModel().getJavaType().toString();
		}
		else {
			predicates.add(builder.and(builder.isNull(root.get(TableConstants.TO_COMPANY))));
		}
		String joinColumn = BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(javaTypeInString);
		return (Long) getSingleResult(getBasePredicateResult(builder, criteria, root, joinColumn, predicates));
		
	}
	
	/**
	 * Gets the payment details for id.
	 *
	 * @param companyId the company id
	 * @return the payment details for id
	 */
	@Override
	public PaymentDetails getPaymentDetailsForId(Integer companyId){
	CriteriaBuilder builder = getCriteriaBuilder();
	CriteriaQuery<PaymentDetails> criteria = builder.createQuery(PaymentDetails.class);
	Root<PaymentDetails> root = criteria.from(PaymentDetails.class);
	criteria.select(root);
	List<Predicate> predicates = new ArrayList<>();
	predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
	predicates.add(builder.and(builder.equal(root.get(TableConstants.PAYMENTID), companyId)));
	return (PaymentDetails) getSingleResult(createQuery(builder, criteria, root, predicates));
	}
	
	/**
	 * Gets the payment details by identity.
	 *
	 * @param companyId the company id
	 * @return the payment details by identity
	 */
	@Override
	public PaymentDetails getPaymentDetailsByIdentity(String companyId){
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<PaymentDetails> criteria = builder.createQuery(PaymentDetails.class);
		Root<PaymentDetails> root = criteria.from(PaymentDetails.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IDENTITY), companyId)));
		return (PaymentDetails) getSingleResult(createQuery(builder, criteria, root, predicates));
	}
	
	/**
	 * Update payment details.
	 *
	 * @param paymentDetails the payment details
	 * @return the payment details
	 */
	@Override
	public PaymentDetails updatePaymentDetails(PaymentDetails paymentDetails) {
		update(paymentDetails);
		return paymentDetails;
	}

	/**
	 * Gets the payment details by report id.
	 *
	 * @param reportId the report id
	 * @return the payment details by report id
	 */
	@Override
	public List<PaymentDetails> getPaymentDetailsByReportId(Integer reportId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<PaymentDetails> criteria = builder.createQuery(PaymentDetails.class);
		Root<PaymentDetails> root = criteria.from(PaymentDetails.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.PAYMENT_REPORT_CARD).get(TableConstants.ID), reportId)));
		return (List<PaymentDetails>) getResultList(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Gets the authority payment details by report id.
	 *
	 * @param reportId the report id
	 * @return the authority payment details by report id
	 */
	@Override
	public List<AuthorityPayments> getAuthorityPaymentDetailsByReportId(int reportId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<AuthorityPayments> criteria = builder.createQuery(AuthorityPayments.class);
		Root<AuthorityPayments> root = criteria.from(AuthorityPayments.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.PAYMENT_REPORT_CARD).get(TableConstants.ID), reportId)));
		return (List<AuthorityPayments>) getResultList(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Save authority payments.
	 *
	 * @param authorityPayment the authority payment
	 * @return the authority payments
	 * @throws ApplicationException the application exception
	 */
	@Override
	public AuthorityPayments saveAuthorityPayments(AuthorityPayments authorityPayment) throws ApplicationException {

		save(authorityPayment,TableConstants.AUTHORITY_PAYMENTS);
		return authorityPayment;
	}

	/**
	 * Update authority payments.
	 *
	 * @param authorityPayment the authority payment
	 * @return the authority payments
	 */
	@Override
	public AuthorityPayments updateAuthorityPayments(AuthorityPayments authorityPayment) {
		update(authorityPayment);
		return authorityPayment;
	}

}
