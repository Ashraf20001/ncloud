package com.recoveryportal.config;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.recoveryportal.constants.core.ApplicationConstants;
import com.recoveryportal.constants.core.SessionScopeClass;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.security.jwt.JwtUtils;
import com.recoveryportal.security.jwt.RecoveryCache;
import com.recoveryportal.transfer.object.dto.CompanyDto;
import com.recoveryportal.transfer.object.dto.PlatformDetailsDto;
import com.recoveryportal.transfer.object.dto.RoleListDto;
import com.recoveryportal.transfer.object.dto.UserInfo;
import com.recoveryportal.transfer.object.entity.UserType;
import com.recoveryportal.transfer.object.enums.DataFilterEnum;
import com.recoveryportal.utils.CommonServiceRestTemplateUtils;
import com.recoveryportal.utils.core.ApplicationUtils;
import com.recoveryportal.utils.core.LoggedInContextHolder;

import io.jsonwebtoken.Claims;

/**
 * The Class RecoveryHttpInterceptor.
 */
@Component
public class RecoveryHttpInterceptor implements HandlerInterceptor{
	
	/** JwtUtils. */
	@Autowired
	private JwtUtils jwtUtils;
	
	/** The logged in user context holder. */
	@Autowired
	private LoggedInContextHolder loggedInUserContextHolder;
	
	/** The common service rest template utils. */
	@Autowired
	private CommonServiceRestTemplateUtils commonServiceRestTemplateUtils;
	
	/** The session scope class. */
	@Autowired
	private SessionScopeClass sessionScopeClass;

	
	/** The Constant logger. */
	private static final Logger logger= LoggerFactory.getLogger(RecoveryHttpInterceptor.class);
	
		
	/**
	 * Pre handle.
	 *
	 * @param request the request
	 * @param response the response
	 * @param handler the handler
	 * @return true, if successful
	 * @throws Exception the exception
	 */
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		try {
			String jwtToken = parseJwt(request);
			if (jwtToken != null && jwtUtils.validateJwtToken(jwtToken)) {
				Claims userDetailsMap = jwtUtils.getUserDetailsFromJwtToken(jwtToken);
				UserInfo userInfo = buildUserInfo(userDetailsMap);
				loggedInUserContextHolder.setLoggedInUser(userInfo);
				setBasePredicateVariableValue(userInfo);
			}
			getAllCompanyData(request);
			
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		
		return HandlerInterceptor.super.preHandle(request, response, handler);
	}
	
	
	/**
	 * Parses the jwt.
	 *
	 * @param request the request
	 * @return the string
	 */
	private String parseJwt(HttpServletRequest request) {
		String headerAuth = request.getHeader(ApplicationConstants.AUTHORIZATION);
		if (StringUtils.hasText(headerAuth) && headerAuth.startsWith(ApplicationConstants.BEARER)) {
			return headerAuth.substring(7, headerAuth.length());
		}
		return null;
	}
	
	/**
	 * Gets the all company data.
	 *
	 * @param request the request
	 * @return the all company data
	 * @throws ApplicationException the application exception
	 */
	private void getAllCompanyData(HttpServletRequest request) throws ApplicationException {

		HashMap<Integer, String> companyList = RecoveryCache.getCompanyList();
		if (!ApplicationUtils.isValidateObject(companyList)) {

			companyList = commonServiceRestTemplateUtils.getAllCompany(request);
			RecoveryCache.setCompanyList(companyList);
			getCompanyDtoMapCache(request);
			HashMap<String, Integer> companyListNameAndIntegerMap = companyList.entrySet().stream().collect(Collectors.toMap(Map.Entry::getValue, Map.Entry::getKey,(value1,value2)->value1, HashMap::new));
			RecoveryCache.setCompanyNameIdMap(companyListNameAndIntegerMap);
		}
		
	}
	
	/**
	 * Gets the company dto map cache.
	 *
	 * @param request the request
	 * @return the company dto map cache
	 * @throws ApplicationException the application exception
	 */
	private void getCompanyDtoMapCache(HttpServletRequest request) throws ApplicationException {
			HashMap<Integer, CompanyDto> allCompanyDtosMap = commonServiceRestTemplateUtils.getAllCompanyDtosMap(request);
			RecoveryCache.setCompanyDtoIdMap(allCompanyDtosMap);
	}


	/**
	 * Builds the user info.
	 *
	 * @param userDetailsMap the user details map
	 * @return the user info
	 */
	private UserInfo buildUserInfo(Claims userDetailsMap) {
		UserInfo userInfo = new UserInfo();
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.ID))) {
			userInfo.setId(Integer.parseInt(userDetailsMap.get(ApplicationConstants.ID).toString()));
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.USER_NAME))) {
			userInfo.setUsername(userDetailsMap.get(ApplicationConstants.USER_NAME).toString());
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.EMAIL))) {
			userInfo.setEmail(userDetailsMap.get(ApplicationConstants.EMAIL).toString());
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.PLATFORM_IDENTITY))) {
			userInfo.setPlatformIdentity(userDetailsMap.get(ApplicationConstants.PLATFORM_IDENTITY).toString());
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.USER_TYPE))) {
			ModelMapper modelMapper = new ModelMapper();
			UserType userType = modelMapper.map(userDetailsMap.get(ApplicationConstants.USER_TYPE), UserType.class);
			userInfo.setUserTypeId(userType);
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.IDENTITY))) {
			userInfo.setIdentity(userDetailsMap.get(ApplicationConstants.IDENTITY).toString());
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.ASSOCIATION_ID))) {
			userInfo.setAssociationId(
					Integer.parseInt(userDetailsMap.get(ApplicationConstants.ASSOCIATION_ID).toString()));
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.PLATFORM_DETAILS))) {
			ModelMapper modelMapper = new ModelMapper();
			PlatformDetailsDto platformDetails = modelMapper
					.map(userDetailsMap.get(ApplicationConstants.PLATFORM_DETAILS), PlatformDetailsDto.class);
			userInfo.setPlatformDetailsDto(platformDetails);
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.COMPANY_ID))) {
			userInfo.setCompanyId(Integer.parseInt(userDetailsMap.get(ApplicationConstants.COMPANY_ID).toString()));
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.ALLOCATION_USER_TYPE))) {
			userInfo.setAllocationUserType(
					Integer.parseInt(userDetailsMap.get(ApplicationConstants.ALLOCATION_USER_TYPE).toString()));
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.COMPANY_NAME))) {
			userInfo.setCompanyName(userDetailsMap.get(ApplicationConstants.COMPANY_NAME).toString());
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.ROLES))) {
			String object = (String) userDetailsMap.get(ApplicationConstants.ROLES);
			String string = "{" + '"' + "userRoleList" + '"' + ":" + object + "}";
			RoleListDto readValue = null;
			try {
				readValue = new com.fasterxml.jackson.databind.ObjectMapper().readValue(string, RoleListDto.class);
			} catch (JsonMappingException e) {
				logger.error(e.getMessage());
			} catch (JsonProcessingException e) {
				logger.error(e.getMessage());
			}
			if (ApplicationUtils.isValidObject(readValue)) {
				userInfo.setRoles(readValue.getUserRoleList());
			}
		}
		return userInfo;
	}
	
	/**
	 * Sets the base predicate variable value.
	 *
	 * @param userInfo the new base predicate variable value
	 */
	private void setBasePredicateVariableValue(UserInfo userInfo) {
		String userType = DataFilterEnum.getUserType(userInfo.getUserTypeId().getUserTypeName());
		if(ApplicationUtils.isValidString(userType)   &&  userType.equalsIgnoreCase(ApplicationConstants.INSURANCE_COMPANY_CAP)) {
			sessionScopeClass.setPredicateMap(userType,userInfo.getCompanyId());
		}else {
			sessionScopeClass.removePredicate();
		}
	}
	
	
}
