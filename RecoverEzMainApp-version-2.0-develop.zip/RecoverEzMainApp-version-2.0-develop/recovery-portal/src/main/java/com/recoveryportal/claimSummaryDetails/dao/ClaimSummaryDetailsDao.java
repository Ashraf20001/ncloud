package com.recoveryportal.claimSummaryDetails.dao;

import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.transfer.object.claimSummaryDetails.dto.ClaimSummaryDetailsDto;
import com.recoveryportal.transfer.object.claimSummaryDetails.entity.ClaimSummaryDetails;

import java.util.List;

/**
 * The Interface ClaimSummaryDetailsDao.
 */
public interface ClaimSummaryDetailsDao {
    
    /**
     * Gets the all claim summary details.
     *
     * @return the all claim summary details
     */
    List<ClaimSummaryDetails> getAllClaimSummaryDetails();

    /**
     * Gets the claim summary details by identity.
     *
     * @param identity the identity
     * @return the claim summary details by identity
     */
    ClaimSummaryDetails getClaimSummaryDetailsByIdentity(String identity);

    /**
     * Save claim summary details.
     *
     * @param claimSummaryDetails the claim summary details
     * @return the claim summary details
     * @throws ApplicationException the application exception
     */
    ClaimSummaryDetails saveClaimSummaryDetails(ClaimSummaryDetails claimSummaryDetails) throws ApplicationException;

    /**
     * Update claim summary details.
     *
     * @param claimSummaryDetails the claim summary details
     * @return the claim summary details
     */
    ClaimSummaryDetails updateClaimSummaryDetails(ClaimSummaryDetails claimSummaryDetails);
}
