package com.recoveryportal.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.recoveryportal.config.common.base.dao.BaseDao;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.dao.IDropDownListDAO;
import com.recoveryportal.transfer.object.dto.DropDownOptionDTO;
import com.recoveryportal.transfer.object.entity.DropDownList;

/**
 * The Class DropDownListDAOImpl.
 */
@Repository
@Transactional
public class DropDownListDAOImpl extends BaseDao implements IDropDownListDAO {

	/**
	 * Gets the drop down list by id.
	 *
	 * @param dropDownListId the drop down list id
	 * @return the drop down list by id
	 */
	@Override
	public DropDownList getDropDownListById(Integer dropDownListId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<DropDownList> criteria = builder.createQuery(DropDownList.class);
		Root<DropDownList> root = criteria.from(DropDownList.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.DROPDOWNLIST_ID), dropDownListId)));
		return (DropDownList)getSingleResult(createQuery(builder, criteria, root, predicates));
	}
	
	/**
	 * Gets the custom option list by drop down list id.
	 *
	 * @param referencedTableName the referenced table name
	 * @param referenceColumnId the reference column id
	 * @param displayColumnName the display column name
	 * @return the custom option list by drop down list id
	 */
	public List<DropDownOptionDTO> getCustomOptionListByDropDownListId(Class<?> referencedTableName, String referenceColumnId, String displayColumnName) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<DropDownOptionDTO> criteria = builder.createQuery(DropDownOptionDTO.class);
		Root root = criteria.from(referencedTableName);
		criteria.multiselect(root.get(referenceColumnId).alias(TableConstants.OPTION_ID), root.get(displayColumnName).alias(TableConstants.OPTION_NAME), root.get(TableConstants.IDENTITY));
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
		predicates.add(builder.and(builder.isTrue(root.get(TableConstants.IS_ACTIVE))));
		return (List<DropDownOptionDTO>)getResultList(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
	}

}
