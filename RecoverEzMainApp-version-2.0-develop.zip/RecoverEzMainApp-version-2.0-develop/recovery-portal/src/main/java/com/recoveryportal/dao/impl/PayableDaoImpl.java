package com.recoveryportal.dao.impl;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.recoveryportal.config.common.base.dao.BaseDao;
import com.recoveryportal.config.property.EnvironmentProperties;
import com.recoveryportal.constants.core.ApplicationConstants;
import com.recoveryportal.constants.core.RecoveryStatusConstant;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.constants.enums.DashBoardStageAndSection;
import com.recoveryportal.dao.PayableDao;
import com.recoveryportal.security.jwt.RecoveryCache;
import com.recoveryportal.transfer.object.constants.BasePredicateEntityColumnMap;
import com.recoveryportal.transfer.object.dto.CompanyAndCountDto;
import com.recoveryportal.transfer.object.dto.ListOfString;
import com.recoveryportal.transfer.object.reportloss.entity.ReportLoss;
import com.recoveryportal.utils.core.ApplicationUtils;

/**
 * The Class PayableDaoImpl.
 */
@Repository
@Transactional
public class PayableDaoImpl extends BaseDao implements PayableDao{
	
	/** The environment properties. */
	@Autowired
	private EnvironmentProperties environmentProperties;
	
    /**
     * Gets the payable list by company.
     *
     * @param payableCompanyId the payable company id
     * @param receivableCompanyIdList the receivable company id list
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the payable list by company
     */
    @Override
    public List<ReportLoss> getPayableListByCompany(Integer payableCompanyId, ListOfString receivableCompanyIdList, String currencyFieldName, String currencyValue) {

        CriteriaBuilder cb = getCriteriaBuilder();
        CriteriaQuery<ReportLoss> cq = cb.createQuery(ReportLoss.class);
        Root<ReportLoss> root = cq.from(ReportLoss.class);
        cq.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(cb.and(cb.equal(root.get(TableConstants.THIRD_PARTY_INFO)
        		.get(TableConstants.RL_TPI_TP_COMPANY),payableCompanyId)));
        
        predicates.add(cb.and(cb.equal(root.get(TableConstants.ISDELETED),false)));
        
        predicates.add(cb.and(cb.notEqual(root.get(TableConstants.STATE), RecoveryStatusConstant.DRAFT)));
        
        if(receivableCompanyIdList != null && receivableCompanyIdList.getList() != null && !receivableCompanyIdList.getList().isEmpty()) {
            Expression<Integer> parentExpression = root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY);
            List<Integer> idList = receivableCompanyIdList.getList().stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
            Predicate parentPredicate = parentExpression.in(idList);
            predicates.add(cb.and(parentPredicate));    
        }
        if(!ApplicationUtils.isBlank(receivableCompanyIdList.getStageName())) {
        	payablePredicte(receivableCompanyIdList,predicates,cb,root);
        }
        if(ApplicationUtils.isValidString(currencyValue)) {
			predicates.add(cb.and(cb.equal(root.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue)));
		}
        cq.orderBy(cb.desc(cb.selectCase()
				.when(cb.isNotNull(root.get(TableConstants.MODIFIED_DATE)), 
				root.get(TableConstants.MODIFIED_DATE))
				.otherwise(root.get(TableConstants.CREATED_DATE))));
        String joinColumn = BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(ApplicationConstants.PAYABLE);
        
        if( ApplicationUtils.isValidId(receivableCompanyIdList.getSkip())){
        	 return (List<ReportLoss>) getResultList(getBasePredicateResult(cb, cq, root, joinColumn, predicates).setFirstResult(receivableCompanyIdList.getLimit()).setMaxResults(receivableCompanyIdList.getSkip()));
        }
        return (List<ReportLoss>) getResultList(getBasePredicateResult(cb, cq, root,joinColumn, predicates));
    }
    
    /**
     * Gets the total count for payable.
     *
     * @param payableCompanyId the payable company id
     * @param receivableCompanyIdList the receivable company id list
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the total count for payable
     */
    @Override
    public Long getTotalCountForPayable(Integer payableCompanyId, ListOfString receivableCompanyIdList, String currencyFieldName, String currencyValue) {

        CriteriaBuilder cb = getCriteriaBuilder();
        CriteriaQuery<Long> cq = cb.createQuery(Long.class);
        Root<ReportLoss> root = cq.from(ReportLoss.class);
        cq.select(cb.count(root));
        List<Predicate> predicates = new ArrayList<>();
        
        predicates.add(cb.and(cb.equal(root.get(TableConstants.THIRD_PARTY_INFO)
        		.get(TableConstants.RL_TPI_TP_COMPANY),payableCompanyId)));
        
        predicates.add(cb.and(cb.equal(root.get(TableConstants.ISDELETED),false)));
        
        predicates.add(cb.and(cb.notEqual(root.get(TableConstants.STATE), RecoveryStatusConstant.DRAFT)));
        if(receivableCompanyIdList != null && receivableCompanyIdList.getList() != null && !receivableCompanyIdList.getList().isEmpty()) {
        	List<Integer> idlist = receivableCompanyIdList.getList().stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
            Expression<Integer> parentExpression = root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY);
            Predicate parentPredicate = parentExpression.in(idlist);
            predicates.add(cb.and(parentPredicate));    
        }
        if(!ApplicationUtils.isBlank(receivableCompanyIdList.getStageName())) {
        	payablePredicte(receivableCompanyIdList,predicates,cb,root);
        }
        if(ApplicationUtils.isValidString(currencyValue)) {
			predicates.add(cb.and(cb.equal(root.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue)));
		}
        cq.orderBy(cb.desc(root.get(TableConstants.MODIFIED_DATE)));
        String joinColumn = BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(ApplicationConstants.PAYABLE);

        return (Long) getSingleResult(getBasePredicateResult(cb, cq, root, joinColumn, predicates));
    }
    
    /**
     * Payable predicte.
     *
     * @param payableCompanyId the payable company id
     * @param predicates the predicates
     * @param cb the cb
     * @param root the root
     */
    public void payablePredicte(ListOfString payableCompanyId,
    		List<Predicate> predicates, CriteriaBuilder cb, Root<ReportLoss> root) {
    		DashBoardStageAndSection dashBoardStageAndSection = DashBoardStageAndSection.valueOf(payableCompanyId.getStageName().replace(" ", "_").toUpperCase());
    		Expression<String> parentExpression = root.get(TableConstants.STATE);
            Predicate parentPredicate = parentExpression.in(dashBoardStageAndSection.statusList);
            Expression<String> laststatusExperssion = root.get(TableConstants.LAST_STATUS);
            Predicate lastStatusPredicate = laststatusExperssion.in(dashBoardStageAndSection.statusList);
            predicates.add(cb.or(parentPredicate,lastStatusPredicate));
    	}

    /**
     * Gets the payable list grouped by company.
     *
     * @return the payable list grouped by company
     */
    @Override
    public List<ReportLoss> getPayableListGroupedByCompany() {
        CriteriaBuilder cb = getCriteriaBuilder();
        CriteriaQuery<ReportLoss> cq = cb.createQuery(ReportLoss.class);
        Root<ReportLoss> root = cq.from(ReportLoss.class);
        cq.select(root);
        cq.groupBy(root.get(TableConstants.THIRD_PARTY_INFO)
                );
        List<Predicate> predicates = new ArrayList<>();
        return (List<ReportLoss>) getResultList(createQuery(cb, cq, root, predicates));
    }

	/**
	 * Gets the company claims count.
	 *
	 * @param userCompanyId the user company id
	 * @param insuranceCompanyId the insurance company id
	 * @return the company claims count
	 */
	@Override
	public Long getCompanyClaimsCount(Integer userCompanyId,Integer insuranceCompanyId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<ReportLoss> root = criteria.from(ReportLoss.class);
		Expression<Long> count = builder.count(root);
		criteria.select(count);
		List<Predicate> predicate=new ArrayList<>();
		predicate.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED),false)));
		predicate.add(builder.and(builder.equal(root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY),userCompanyId)));
		predicate.add(builder.and(builder.equal(root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY), insuranceCompanyId)));
		return (Long) getSingleResult(createQuery(builder, criteria, root, predicate));				 
		
	}
	
    /**
     * Gets the payable count by stage list.
     *
     * @param userCompanyId the user company id
     * @param insurerCompanyId the insurer company id
     * @param stateList the state list
     * @return the payable count by stage list
     */
    @Override
    public Long getPayableCountByStageList(Integer userCompanyId,Integer insurerCompanyId, List<String> stateList) {
        
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
        Root<ReportLoss> root = criteria.from(ReportLoss.class);
        Expression<Long> countExpression = builder.count(root);
        criteria.select(countExpression);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED),false)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY),userCompanyId)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY), insurerCompanyId)));
        Expression<String> parentExpression = root.get(TableConstants.STATE);
        Predicate parentPredicate = parentExpression.in(stateList);
        predicates.add(builder.and(parentPredicate));
        return (Long) getSingleResult(createQuery(builder, criteria, root, predicates));
    }
    
    /**
     * Gets the all payable counts.
     *
     * @param companyId the company id
     * @return the all payable counts
     */
    @Override
    public Long getAllPayableCounts(Integer companyId) {
    	CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
        Root<ReportLoss> root = criteria.from(ReportLoss.class);
        Expression<Long> countExpression = builder.count(root);
        criteria.select(countExpression);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED),false)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY),companyId)));
        
        String joinColumn = BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(TableConstants.PAYABLE);
        return (Long) getSingleResult(getBasePredicateResult(builder, criteria, root, joinColumn, predicates));

    }

    /**
     * Gets the all payable count by stage list.
     *
     * @param companyId the company id
     * @param stateList the state list
     * @return the all payable count by stage list
     */
    @Override
    public Long getAllPayableCountByStageList(Integer companyId,List<String> stateList) {
    	CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
        Root<ReportLoss> root = criteria.from(ReportLoss.class);
        Expression<Long> countExpression = builder.count(root);
        criteria.select(countExpression);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED),false)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY),companyId)));
        Expression<String> parentExpression = root.get(TableConstants.STATE);
        Predicate parentPredicate = parentExpression.in(stateList);
        predicates.add(builder.and(parentPredicate));
        String joinColumn = BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(TableConstants.PAYABLE);
        
        return (Long) getSingleResult(getBasePredicateResult(builder, criteria, root, joinColumn, predicates));



    }
    
    /**
     * Register data filters.
     */
    @Override
    public void registerDataFilters() {

    }

	/**
	 * Gets the receivable count by stage.
	 *
	 * @param companyId the company id
	 * @param stateList the state list
	 * @param isAssociation the is association
	 * @return the receivable count by stage
	 */
	@Override
	public List<CompanyAndCountDto> getReceivableCountByStage(Integer companyId, List<String> stateList,boolean isAssociation) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Object[]> criteria = builder.createQuery(Object[].class);
		Root<ReportLoss> root = criteria.from(ReportLoss.class);
		
		Expression<Integer> countExpression1;
        Expression<Long> countExpression2 = builder.count(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED),false)));
        Expression<String> parentExpression = root.get(TableConstants.STATE);
        Predicate parentPredicate = parentExpression.in(stateList);
        Expression<String> laststatusExperssion = root.get(TableConstants.LAST_STATUS);
        Predicate lastStatusPredicate = laststatusExperssion.in(stateList);
        
        predicates.add(builder.or(parentPredicate,lastStatusPredicate));
        if(!isAssociation) {
            countExpression1= root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY);
            predicates.add(builder.and(builder.equal(root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY),companyId)));
        }else {
            countExpression1= root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY);
        }
        
        criteria.multiselect(countExpression1,countExpression2);
        criteria.groupBy(countExpression1);
        
        String joinColumns = BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(ApplicationConstants.RECEIVABLE);
        List<Object[]> resultList =  (List<Object[]>)getResultList(getBasePredicateResult(builder, criteria, root, joinColumns, predicates));
        return resultList.stream().map( el -> new CompanyAndCountDto(RecoveryCache.getCompanyList().get((Integer)el[0]),(Long)el[1])).collect(Collectors.toList());

	}

	/**
	 * Gets the all receivable count.
	 *
	 * @param userCompanyId the user company id
	 * @param isAssociation the is association
	 * @return the all receivable count
	 */
	@Override
	public List<CompanyAndCountDto> getAllReceivableCount(Integer userCompanyId,boolean isAssociation) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Object[]> criteria = builder.createQuery(Object[].class);
		Root<ReportLoss> root = criteria.from(ReportLoss.class);
		
        Expression<Long> countExpression2 = builder.count(root);
        Expression<Integer> countExpression1;
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED),false)));
        if(!isAssociation) {
            countExpression1= root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY);
            predicates.add(builder.and(builder.equal(root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY),userCompanyId)));
        }else {
            countExpression1= root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY);
        }
  
        
        criteria.multiselect(countExpression1,countExpression2);
        criteria.groupBy(countExpression1);
        String joinColumns = BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(ApplicationConstants.RECEIVABLE);
        List<Object[]> resultList = (List<Object[]>) getResultList(getBasePredicateResult(builder, criteria, root, joinColumns, predicates));
        
        return resultList.stream().map( el -> new CompanyAndCountDto(RecoveryCache.getCompanyList().get((Integer)el[0]),(Long)el[1])).collect(Collectors.toList());

	}
	
	/**
	 * Gets the all payable count.
	 *
	 * @param userCompanyId the user company id
	 * @param isAssociation the is association
	 * @return the all payable count
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CompanyAndCountDto> getAllPayableCount(Integer userCompanyId, boolean isAssociation) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Object[]> criteria = builder.createQuery(Object[].class);
		Root<ReportLoss> root = criteria.from(ReportLoss.class);
		Expression<Integer> countExpression1;
        Expression<Long> countExpression2 = builder.count(root);
       
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED),false)));
        predicates.add(builder.and(builder.notEqual(root.get(TableConstants.STATE), RecoveryStatusConstant.DRAFT)));
        if(!isAssociation) {
            countExpression1= root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY);
        	predicates.add(builder.and(builder.equal(root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY),userCompanyId)));
        }else {
            countExpression1= root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY);
        }
        
        criteria.multiselect(countExpression1,countExpression2);
        criteria.groupBy(countExpression1);
        
        String joinColumn = BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(ApplicationConstants.PAYABLE);
        List<Object[]> resultList = (List<Object[]>) getResultList(getBasePredicateResult(builder, criteria, root, joinColumn, predicates));
        return  resultList.stream().map( el -> new CompanyAndCountDto(RecoveryCache.getCompanyList().get((Integer)el[0]),(Long)el[1])).collect(Collectors.toList());
	}
	
	/**
	 * Gets the payable count by stage.
	 *
	 * @param companyId the company id
	 * @param stateList the state list
	 * @param isAssociation the is association
	 * @return the payable count by stage
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CompanyAndCountDto> getPayableCountByStage(Integer companyId, List<String> stateList, boolean isAssociation) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Object[]> criteria = builder.createQuery(Object[].class);
		Root<ReportLoss> root = criteria.from(ReportLoss.class);
		Expression<Integer> countExpression1;
		
        Expression<Long> countExpression2 = builder.count(root);
       
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.notEqual(root.get(TableConstants.STATE), RecoveryStatusConstant.DRAFT)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED),false)));
        
        Expression<String> parentExpression = root.get(TableConstants.STATE);
        Predicate parentPredicate = parentExpression.in(stateList);
        
        Expression<String> laststatusExperssion = root.get(TableConstants.LAST_STATUS);
        Predicate lastStatusPredicate = laststatusExperssion.in(stateList);
        
        predicates.add(builder.or(parentPredicate,lastStatusPredicate));

        if(!isAssociation) {
            countExpression1= root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY);
        	predicates.add(builder.and(builder.equal(root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY),companyId)));
        }else {
            countExpression1= root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY);
        }
        criteria.multiselect(countExpression1,countExpression2);
        criteria.groupBy(countExpression1);
        
        String joinColumn = BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(ApplicationConstants.PAYABLE);
        List<Object[]> resultList =  (List<Object[]>)getResultList(getBasePredicateResult(builder, criteria, root, joinColumn, predicates));
        return resultList.stream().map(el->new CompanyAndCountDto(RecoveryCache.getCompanyList().get((Integer)el[0]), (Long)el[1])).toList();
	}

	/**
	 * Gets the payable listby grp name.
	 *
	 * @param companyId the company id
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the payable listby grp name
	 */
	@Override
	public List<ReportLoss> getPayableListbyGrpName(ListOfString companyId, String currencyFieldName, String currencyValue) {
		List<ReportLoss> payableList=new ArrayList<ReportLoss>();
		CriteriaBuilder cb = getCriteriaBuilder();
		CriteriaQuery<ReportLoss> cq = cb.createQuery(ReportLoss.class);
		Root<ReportLoss> root = cq.from(ReportLoss.class);

		List<Predicate> predicates = new ArrayList<>();
		predicates.add(cb.and(cb.equal(root.get(TableConstants.ISDELETED),false)));
		
		if(ApplicationUtils.isValidateObject(companyId.getList())) {
			List<Integer> companyIdList = companyId.getList().stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
			Expression<Integer> parentExpression = root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY);
			Predicate parentPredicate = parentExpression.in(companyIdList);
			predicates.add(cb.and(parentPredicate));
			
		}
		 if(!ApplicationUtils.isBlank(companyId.getStageName())) {
        	payablePredicte(companyId,predicates,cb,root);
        }
		if(ApplicationUtils.isValidString(currencyValue)) {
			predicates.add(cb.and(cb.equal(root.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue)));
		}
		cq.select(root);
		
		cq.orderBy(cb.desc(cb.selectCase()
				.when(cb.isNotNull(root.get(TableConstants.MODIFIED_DATE)), 
				root.get(TableConstants.MODIFIED_DATE))
				.otherwise(root.get(TableConstants.CREATED_DATE))));
		if(ApplicationUtils.isValidId(companyId.getSkip())) {
			payableList = (List<ReportLoss>) getResultList(createQuery(cb, cq, root, predicates).setFirstResult(companyId.getLimit()).setMaxResults(companyId.getSkip()));
		}else {
			payableList = (List<ReportLoss>) getResultList(createQuery(cb, cq, root, predicates));
		}
		return payableList;
		
	}
	
	/**
	 * Gets the receivable listby grp name count.
	 *
	 * @param companyId the company id
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the receivable listby grp name count
	 */
	@Override
	public Long getReceivableListbyGrpNameCount(ListOfString companyId, String currencyFieldName, String currencyValue) {
		CriteriaBuilder cb = getCriteriaBuilder();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<ReportLoss> root = cq.from(ReportLoss.class);

		List<Predicate> predicates = new ArrayList<>();
		predicates.add(cb.and(cb.equal(root.get(TableConstants.ISDELETED),false)));
		
		if(ApplicationUtils.isValidateObject(companyId.getList())) {
			List<Integer> idlist = companyId.getList().stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
			Expression<Integer> parentExpression = root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY);
			Predicate parentPredicate = parentExpression.in(idlist);
			predicates.add(cb.and(parentPredicate));
			
		}
		if(!ApplicationUtils.isBlank(companyId.getStageName())) {
        	payablePredicte(companyId, predicates, cb, root);
	    }
		if(ApplicationUtils.isValidString(currencyValue)) {
			predicates.add(cb.and(cb.equal(root.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue)));
		}
		cq.select(cb.count(root));
		cq.orderBy(cb.desc(root.get(TableConstants.MODIFIED_DATE)));

		return (Long) getSingleResult(createQuery(cb, cq, root, predicates));
		
	}


	/**
	 * Gets the payable count.
	 *
	 * @param userCompanyId the user company id
	 * @param isAssociation the is association
	 * @return the payable count
	 */
	@Override
	public Long getPayableCount(Integer userCompanyId, boolean isAssociation) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<ReportLoss> root = criteria.from(ReportLoss.class);
		Expression countExpression1;
		List<Predicate> predicates = new ArrayList<>();
		
		if(!isAssociation) {
            countExpression1= root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY);
            predicates.add(builder.and(builder.equal(root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY),userCompanyId)));
        }else {
            countExpression1= root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY);
        }		
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED),false))); 
		criteria.multiselect(countExpression1);
		String joinColumn = BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(TableConstants.PAYABLE);
		return (Long)getSingleResult(getBasePredicateResult(builder, criteria, root, joinColumn, predicates));

	}
	
	/**
	 * 	getRecivableListbyGrpName.
	 *
	 * @param companyId the company id
	 * @return the recivable listby grp name
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<ReportLoss> getRecivableListbyGrpName(ListOfString companyId) {
		List<ReportLoss> receivableList = new ArrayList<ReportLoss>();
		CriteriaBuilder cb = getCriteriaBuilder();
		CriteriaQuery<ReportLoss> cq = cb.createQuery(ReportLoss.class);
		Root<ReportLoss> root = cq.from(ReportLoss.class);

		List<Predicate> predicates = new ArrayList<>();
		predicates.add(cb.and(cb.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(cb.and(cb.notEqual(root.get(TableConstants.STATE), RecoveryStatusConstant.DRAFT)));
		if (ApplicationUtils.isValidateObject(companyId.getList())) {
			List<Integer> idlist = companyId.getList().stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
			Expression<Integer> parentExpression = root.get(TableConstants.THIRD_PARTY_INFO)
					.get(TableConstants.RL_TPI_TP_COMPANY);
			Predicate parentPredicate = parentExpression.in(idlist);
			predicates.add(cb.and(parentPredicate));

		}
		if (!ApplicationUtils.isBlank(companyId.getStageName())) {
			receivablePredicte(companyId, predicates, cb, root);
		}
		cq.select(root);
		cq.orderBy(cb.desc(cb.selectCase()
				.when(cb.isNotNull(root.get(TableConstants.MODIFIED_DATE)), root.get(TableConstants.MODIFIED_DATE))
				.otherwise(root.get(TableConstants.CREATED_DATE))));
		if (ApplicationUtils.isValidId(companyId.getSkip())) {
			receivableList = (List<ReportLoss>) getResultList(createQuery(cb, cq, root, predicates)
					.setFirstResult(companyId.getLimit()).setMaxResults(companyId.getSkip()));
		} else {
			receivableList = (List<ReportLoss>) getResultList(createQuery(cb, cq, root, predicates));
		}

		return receivableList;
	}

	/**
	 * receivablePredicte.
	 *
	 * @param payableCompanyId the payable company id
	 * @param predicates the predicates
	 * @param cb the cb
	 * @param root the root
	 */
	private void receivablePredicte(ListOfString payableCompanyId,
			List<Predicate> predicates, CriteriaBuilder cb, Root<ReportLoss> root) {
		DashBoardStageAndSection dashBoardStageAndSection = DashBoardStageAndSection
				.valueOf(payableCompanyId.getStageName().replace(" ", "_").toUpperCase());
		Expression<String> parentExpression = root.get(TableConstants.STATE);
		Predicate parentPredicate = parentExpression.in(dashBoardStageAndSection.statusList);
		Expression<String> laststatusExperssion = root.get(TableConstants.LAST_STATUS);
		Predicate lastStatusPredicate = laststatusExperssion.in(dashBoardStageAndSection.statusList);
		predicates.add(cb.or(parentPredicate, lastStatusPredicate));
	}

	/**
	 * GET FILTRED PAYABLE-LIST.
	 *
	 * @param payableCompanyId the payable company id
	 * @param filterVo the filter vo
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the filtred payable list
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<ReportLoss> getFiltredPayableList(Integer payableCompanyId, ListOfString filterVo, String currencyFieldName, String currencyValue) {

		List<ReportLoss> receivableList = new ArrayList<ReportLoss>();
		CriteriaBuilder cb = getCriteriaBuilder();
		CriteriaQuery<ReportLoss> cq = cb.createQuery(ReportLoss.class);
		Root<ReportLoss> root = cq.from(ReportLoss.class);
		cq.select(root);
		List<Predicate> predicates = new ArrayList<>();
		String searchValue = filterVo.getSearchValue();
		Integer searchValueNumber = 0;
		try {
			searchValueNumber = Integer.parseInt(searchValue);

		} catch (Exception e) {
			searchValueNumber = 0;
		}

		String formatDateTime = "";
		try {

			DateTimeFormatter format = DateTimeFormatter.ofPattern(environmentProperties.getDateFormat());
			formatDateTime = searchValue.formatted(format);
		} catch (Exception e) {
			formatDateTime = "";
		}

		predicates.add(cb.and(cb.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(cb.and(cb.equal(root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY)
				, payableCompanyId)));
		predicates.add(cb.and(cb.notEqual(root.get(TableConstants.STATE), RecoveryStatusConstant.DRAFT)));
		predicates.add(cb.or(cb.like(root.get(TableConstants.CLAIM_SEQUENCE), "%" + searchValue + "%"),
				(cb.like(root.get(TableConstants.INSURED_INFO).get(TableConstants.IN_SURED_NAME),
						"%" + searchValue + "%")),
				cb.or(cb.equal(cb.function("DATE_FORMAT", String.class, root.get(TableConstants.CREATED_DATE),
						cb.literal("%Y")), searchValueNumber)),
				cb.or(cb.equal(cb.function("DATE_FORMAT", String.class, root.get(TableConstants.CREATED_DATE),
						cb.literal("%d")), searchValueNumber)),
				cb.or(cb.equal(cb.function("DATE_FORMAT", String.class, root.get(TableConstants.CREATED_DATE),
						cb.literal("%m")), searchValueNumber)),
				cb.or(cb.equal(cb.function("DATE_FORMAT", String.class, root.get(TableConstants.CREATED_DATE),
						cb.literal("%d-%m")), searchValue)),
				cb.or(cb.equal(cb.function("DATE_FORMAT", String.class, root.get(TableConstants.CREATED_DATE),
						cb.literal("%d-%m-%Y")), formatDateTime)),
				cb.or(cb.like(root.get(TableConstants.SECTION_NAME), "%" + searchValue + "%")),
				cb.or(cb.like(root.get(TableConstants.STATE), "%" + searchValue + "%"))));

		if (!ApplicationUtils.isBlank(filterVo.getStageName())) {
			receivablePredicte(filterVo, predicates, cb, root);
		}
		if (filterVo != null && filterVo.getList() != null && !filterVo.getList().isEmpty()) {
			List<Integer> idlist = filterVo.getList().stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
			Expression<Integer> parentExpression = root.get(TableConstants.THIRD_PARTY_INFO)
					.get(TableConstants.RL_TPI_TP_COMPANY);
			Predicate parentPredicate = parentExpression.in(idlist);
			predicates.add(cb.and(parentPredicate));
		}
		if(ApplicationUtils.isValidString(currencyValue)) {
			predicates.add(cb.and(cb.equal(root.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue)));
		}
		cq.orderBy(cb.desc(cb.selectCase()
				.when(cb.isNotNull(root.get(TableConstants.MODIFIED_DATE)), root.get(TableConstants.MODIFIED_DATE))
				.otherwise(root.get(TableConstants.CREATED_DATE))));
		String joinColumn = BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(TableConstants.PAYABLE);
		List<ReportLoss> result= new ArrayList<>();
		if (ApplicationUtils.isValidId(filterVo.getSkip())) {
			result = (List<ReportLoss>) getResultList(getBasePredicateResult(cb, cq, root, joinColumn, predicates)
					.setFirstResult(filterVo.getLimit()).setMaxResults(filterVo.getSkip()));
		}
		 result =  (List<ReportLoss>) getResultList(getBasePredicateResult(cb, cq, root, joinColumn, predicates));
		 
		 if(searchValueNumber==0 && formatDateTime.equals("") && !result.isEmpty()) {
				List<ReportLoss> resultList = result.parallelStream().filter(el->RecoveryCache.getCompanyList().getOrDefault(el.getInsuredInfo().getInsurerCompany(),"").contains(searchValue) || 
						RecoveryCache.getCompanyList().getOrDefault(el.getThirdPartyInfo().getTpCompany(),"").contains(searchValue)	).toList();
				if(!resultList.isEmpty()) {
					result = resultList;
				}
			}
		 return result;
	}

	/**
	 * GET FILTERED PAYABLE-LIST COUNT.
	 *
	 * @param payableCompanyId the payable company id
	 * @param filterVo the filter vo
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the filtered payable list count
	 */
	@Override
	public Long getFilteredPayableListCount(Integer payableCompanyId, ListOfString filterVo, String currencyFieldName, String currencyValue) {
		CriteriaBuilder cb = getCriteriaBuilder();
		CriteriaQuery<ReportLoss> cq = cb.createQuery(ReportLoss.class);
		Root<ReportLoss> root = cq.from(ReportLoss.class);
		cq.select(root);
		List<Predicate> predicates = new ArrayList<>();
		String searchValue = filterVo.getSearchValue();
		Integer searchValueNumber = 0;
		try {
			searchValueNumber = Integer.parseInt(searchValue);

		} catch (Exception e) {
			searchValueNumber = 0;
		}

		String formatDateTime = "";
		try {

			DateTimeFormatter format = DateTimeFormatter.ofPattern(environmentProperties.getDateFormat());
			formatDateTime = searchValue.formatted(format);
		} catch (Exception e) {
			formatDateTime = "";
		}
		predicates.add(cb.and(cb.equal(root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY)
				, payableCompanyId)));
		predicates.add(cb.and(cb.notEqual(root.get(TableConstants.STATE), RecoveryStatusConstant.DRAFT)));
		predicates.add(cb.or(cb.like(root.get(TableConstants.CLAIM_SEQUENCE), "%" + searchValue + "%"),
				(cb.like(root.get(TableConstants.INSURED_INFO).get(TableConstants.IN_SURED_NAME),
						"%" + searchValue + "%")),
				cb.or(cb.equal(cb.function("DATE_FORMAT", String.class, root.get(TableConstants.CREATED_DATE),
						cb.literal("%Y")), searchValueNumber)),
				cb.or(cb.equal(cb.function("DATE_FORMAT", String.class, root.get(TableConstants.CREATED_DATE),
						cb.literal("%d")), searchValueNumber)),
				cb.or(cb.equal(cb.function("DATE_FORMAT", String.class, root.get(TableConstants.CREATED_DATE),
						cb.literal("%m")), searchValueNumber)),
				cb.or(cb.equal(cb.function("DATE_FORMAT", String.class, root.get(TableConstants.CREATED_DATE),
						cb.literal("%d-%m")), searchValue)),
				cb.or(cb.equal(cb.function("DATE_FORMAT", String.class, root.get(TableConstants.CREATED_DATE),
						cb.literal("%d-%m-%Y")), formatDateTime)),
				cb.or(cb.like(root.get(TableConstants.SECTION_NAME), "%" + searchValue + "%")),
				cb.or(cb.like(root.get(TableConstants.STATE), "%" + searchValue + "%"))));
		if (filterVo != null && filterVo.getList() != null && !filterVo.getList().isEmpty()) {
			List<Integer> idlist = filterVo.getList().stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
			Expression<Integer> parentExpression = root.get(TableConstants.INSURED_INFO)
					.get(TableConstants.RL_II_INSURER_COMPANY);
			Predicate parentPredicate = parentExpression.in(idlist);
			predicates.add(cb.and(parentPredicate));
		}
		if (!ApplicationUtils.isBlank(filterVo.getStageName())) {
			payablePredicte(filterVo, predicates, cb, root);
		}
		if(ApplicationUtils.isValidString(currencyValue)) {
			predicates.add(cb.and(cb.equal(root.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue)));
		}
		cq.orderBy(cb.desc(root.get(TableConstants.MODIFIED_DATE)));
		String joinColumn = BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(TableConstants.PAYABLE);
		
		List<ReportLoss> resultList =(List<ReportLoss>) getResultList(getBasePredicateResult(cb, cq, root, joinColumn, predicates));
		if(searchValueNumber==0 && formatDateTime.equals("") && !resultList.isEmpty()) {
			List<ReportLoss> result = resultList.parallelStream().filter(el->RecoveryCache.getCompanyList().getOrDefault(el.getInsuredInfo().getInsurerCompany(),"").contains(searchValue) || 
					RecoveryCache.getCompanyList().getOrDefault(el.getThirdPartyInfo().getTpCompany(),"").contains(searchValue)	).toList();
			if(!result.isEmpty()) {
				resultList = result;
			}
		}
		return Integer.valueOf(resultList.size()).longValue();

	}

	/**
	 * GET FILTERED ALL PAYABLE-LIST.
	 *
	 * @param filterVo the filter vo
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the filtered all payable list
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<ReportLoss> getFilteredAllPayableList(ListOfString filterVo, String currencyFieldName, String currencyValue) {
		List<ReportLoss> payableList = new ArrayList<ReportLoss>();
		CriteriaBuilder cb = getCriteriaBuilder();
		CriteriaQuery<ReportLoss> cq = cb.createQuery(ReportLoss.class);
		Root<ReportLoss> root = cq.from(ReportLoss.class);
		String searchValue = filterVo.getSearchValue();
		Integer searchValueNumber = 0;
		try {
			searchValueNumber = Integer.parseInt(searchValue);

		} catch (Exception e) {
			searchValueNumber = 0;
		}

		String formatDateTime = "";
		try {

			DateTimeFormatter format = DateTimeFormatter.ofPattern(environmentProperties.getDateFormat());
			formatDateTime = searchValue.formatted(format);
		} catch (Exception e) {
			formatDateTime = "";
		}
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(cb.and(cb.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(cb.or(cb.like(root.get(TableConstants.CLAIM_SEQUENCE), "%" + searchValue + "%"),
				(cb.like(root.get(TableConstants.INSURED_INFO).get(TableConstants.IN_SURED_NAME),
						"%" + searchValue + "%")),
				cb.or(cb.equal(cb.function("DATE_FORMAT", String.class, root.get(TableConstants.CREATED_DATE),
						cb.literal("%Y")), searchValueNumber)),
				cb.or(cb.equal(cb.function("DATE_FORMAT", String.class, root.get(TableConstants.CREATED_DATE),
						cb.literal("%d")), searchValueNumber)),
				cb.or(cb.equal(cb.function("DATE_FORMAT", String.class, root.get(TableConstants.CREATED_DATE),
						cb.literal("%m")), searchValueNumber)),
				cb.or(cb.equal(cb.function("DATE_FORMAT", String.class, root.get(TableConstants.CREATED_DATE),
						cb.literal("%d-%m")), searchValue)),
				cb.or(cb.equal(cb.function("DATE_FORMAT", String.class, root.get(TableConstants.CREATED_DATE),
						cb.literal("%d-%m-%Y")), formatDateTime)),
				cb.or(cb.like(root.get(TableConstants.SECTION_NAME), "%" + searchValue + "%")),
				cb.or(cb.like(root.get(TableConstants.STATE), "%" + searchValue + "%"))));
		if (ApplicationUtils.isValidateObject(filterVo.getList())) {
			List<Integer> idlist = filterVo.getList().stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
			Expression<Integer> parentExpression = root.get(TableConstants.INSURED_INFO)
					.get(TableConstants.RL_II_INSURER_COMPANY);
			Predicate parentPredicate = parentExpression.in(idlist);
			predicates.add(cb.and(parentPredicate));

		}
		if (!ApplicationUtils.isBlank(filterVo.getStageName())) {
			payablePredicte(filterVo, predicates, cb, root);
		}
		cq.select(root);
		if(ApplicationUtils.isValidString(currencyValue)) {
			predicates.add(cb.and(cb.equal(root.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue)));
		}
		cq.orderBy(cb.desc(cb.selectCase()
				.when(cb.isNotNull(root.get(TableConstants.MODIFIED_DATE)), root.get(TableConstants.MODIFIED_DATE))
				.otherwise(root.get(TableConstants.CREATED_DATE))));
		if (ApplicationUtils.isValidId(filterVo.getSkip())) {
			payableList = (List<ReportLoss>) getResultList(createQuery(cb, cq, root, predicates)
					.setFirstResult(filterVo.getLimit()).setMaxResults(filterVo.getSkip()));
		} else {
			payableList = (List<ReportLoss>) getResultList(createQuery(cb, cq, root, predicates));
		}
		if(searchValueNumber==0 && formatDateTime.equals("") && !payableList.isEmpty()) {
			List<ReportLoss> resultList = payableList.parallelStream().filter(el->RecoveryCache.getCompanyList().getOrDefault(el.getInsuredInfo().getInsurerCompany(),"").contains(searchValue) || 
					RecoveryCache.getCompanyList().getOrDefault(el.getThirdPartyInfo().getTpCompany(),"").contains(searchValue)	).toList();
			if(!resultList.isEmpty()) {
				payableList = resultList;
			}
		}
		return payableList;

	}

	/**
	 * GET FILTERED ALL PAYABLE-LIST COUNT.
	 *
	 * @param filterVo the filter vo
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the filtered all payable list count
	 */
	@Override
	public Long getFilteredAllPayableListCount(ListOfString filterVo, String currencyFieldName, String currencyValue) {
		CriteriaBuilder cb = getCriteriaBuilder();
		CriteriaQuery<ReportLoss> cq = cb.createQuery(ReportLoss.class);
		Root<ReportLoss> root = cq.from(ReportLoss.class);
		String searchValue = filterVo.getSearchValue();
		Integer searchValueNumber = 0;
		try {
			searchValueNumber = Integer.parseInt(searchValue);

		} catch (Exception e) {
			searchValueNumber = 0;
		}

		String formatDateTime = "";
		try {

			DateTimeFormatter format = DateTimeFormatter.ofPattern(environmentProperties.getDateFormat());
			formatDateTime = searchValue.formatted(format);
		} catch (Exception e) {
			formatDateTime = "";
		}
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(cb.and(cb.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(cb.or(cb.like(root.get(TableConstants.CLAIM_SEQUENCE), "%" + searchValue + "%"),
				(cb.like(root.get(TableConstants.INSURED_INFO).get(TableConstants.IN_SURED_NAME),
						"%" + searchValue + "%")),
				cb.or(cb.equal(cb.function("DATE_FORMAT", String.class, root.get(TableConstants.CREATED_DATE),
						cb.literal("%Y")), searchValueNumber)),
				cb.or(cb.equal(cb.function("DATE_FORMAT", String.class, root.get(TableConstants.CREATED_DATE),
						cb.literal("%d")), searchValueNumber)),
				cb.or(cb.equal(cb.function("DATE_FORMAT", String.class, root.get(TableConstants.CREATED_DATE),
						cb.literal("%m")), searchValueNumber)),
				cb.or(cb.equal(cb.function("DATE_FORMAT", String.class, root.get(TableConstants.CREATED_DATE),
						cb.literal("%d-%m")), searchValue)),
				cb.or(cb.equal(cb.function("DATE_FORMAT", String.class, root.get(TableConstants.CREATED_DATE),
						cb.literal("%d-%m-%Y")), formatDateTime)),
				cb.or(cb.like(root.get(TableConstants.SECTION_NAME), "%" + searchValue + "%")),
				cb.or(cb.like(root.get(TableConstants.STATE), "%" + searchValue + "%"))));

		if (ApplicationUtils.isValidateObject(filterVo.getList())) {
			List<Integer> idlist = filterVo.getList().stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
			Expression<Integer> parentExpression = root.get(TableConstants.INSURED_INFO)
					.get(TableConstants.RL_II_INSURER_COMPANY);
			Predicate parentPredicate = parentExpression.in(idlist);
			predicates.add(cb.and(parentPredicate));

		}
		if (!ApplicationUtils.isBlank(filterVo.getStageName())) {
			payablePredicte(filterVo, predicates, cb, root);
		}
		if(ApplicationUtils.isValidString(currencyValue)) {
			predicates.add(cb.and(cb.equal(root.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue)));
		}
		cq.select(root);
		cq.orderBy(cb.desc(root.get(TableConstants.MODIFIED_DATE)));

	   List<ReportLoss> result =	(List<ReportLoss>) getResultList(createQuery(cb, cq, root, predicates));
	   if(searchValueNumber==0 && formatDateTime.equals("") && !result.isEmpty()) {
			List<ReportLoss> resultList = result.parallelStream().filter(el->RecoveryCache.getCompanyList().getOrDefault(el.getInsuredInfo().getInsurerCompany(),"").contains(searchValue) || 
					RecoveryCache.getCompanyList().getOrDefault(el.getThirdPartyInfo().getTpCompany(),"").contains(searchValue)	).toList();
			if(!resultList.isEmpty()) {
				result = resultList;
			}
		}
	   
	   return Integer.valueOf(result.size()).longValue();
	}
}
