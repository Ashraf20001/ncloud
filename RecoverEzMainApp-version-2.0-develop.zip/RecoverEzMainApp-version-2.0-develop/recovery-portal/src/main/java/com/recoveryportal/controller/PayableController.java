package com.recoveryportal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;

import com.recoveryportal.aop.annotation.Auditable;
import com.recoveryportal.config.base.controller.BaseController;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.service.PayableService;
import com.recoveryportal.transfer.object.core.ApplicationResponse;
import com.recoveryportal.transfer.object.dto.ListOfString;
import com.recoveryportal.transfer.object.reportloss.dto.ReportLossViewDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class PayableController.
 */
@RestController
@Auditable
public class PayableController extends BaseController {

    /** The payable service. */
    @Autowired
    PayableService payableService;

    /**
     * Gets the payable list.
     *
     * @param list the list
     * @return the payable list
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value="Payable list",notes="Get list of payables for the list of companies",response=ApplicationResponse.class)
    @PostMapping("/get-payable-list")
    public ApplicationResponse getPayableList( @ApiParam(value="company id list payload",required=true) @RequestBody ListOfString list) throws ApplicationException{
        List<ReportLossViewDto> reportLossViewDto=	payableService.getPayableListByCompany(list);
        return getApplicationResponse(reportLossViewDto);
    }
    
    /**
     * Gets the total count.
     *
     * @param list the list
     * @return the total count
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value="Payable count",notes="Get payable count for the list of companies",response=ApplicationResponse.class)
    @PostMapping("/get-payableCount")
    public ApplicationResponse getTotalCount(@ApiParam(value="company id list payload",required=true) @RequestBody ListOfString list) throws ApplicationException{
    	Long reportLossViewDto=	payableService.getTotalCount(list);
        return getApplicationResponse(reportLossViewDto);
    }

    /**
     * Gets the all receivable list.
     *
     * @param list the list
     * @return the all receivable list
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value="All Payable list",notes="Get all payable list for the authority",response=ApplicationResponse.class)
    @PostMapping("/all-payable-list")
  	 public ApplicationResponse getAllReceivableList(@ApiParam(value="company id list payload",required=true) @RequestBody ListOfString list) throws ApplicationException{
      	List<ReportLossViewDto> reportLossDto=	payableService.getAllPayables(list);
  			return getApplicationResponse(reportLossDto);
  	 }
    
    /**
     * Gets the all receivable list count.
     *
     * @param list the list
     * @return the all receivable list count
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value="All receivable list",notes="Get all receivable list for the authority",response=ApplicationResponse.class)
    @PostMapping("/all-receivable-list-count")
 	 public ApplicationResponse getAllReceivableListCount(@ApiParam(value="company id list payload",required=true) @RequestBody ListOfString list) throws ApplicationException{
     	Long reportLossDto=	payableService.getAllReceivableCount(list);
 			return getApplicationResponse(reportLossDto);
 	 }
    
    /**
     * Export PayableTable-List As Excel.
     *
     * @param list the list
     * @return the response entity
     * @throws Exception the exception
     */
    @ApiOperation(value="Export payable list",notes="Export payable list for the company list",response=ApplicationResponse.class)
    @PostMapping("/generate/payableList/export-to-excel")
    public ResponseEntity<InputStreamResource> exportPayableListAsExcel(@ApiParam(value="company id list payload",required=true)  @RequestBody ListOfString list) throws Exception{
	
    	return payableService.exportPayableListAsExcel(list);
    }

	/**
	 * GET PAYABLE-LIST FILTER.
	 *
	 * @param filterVo the filter vo
	 * @return the payable list filter
	 * @throws ApplicationException the application exception
	 */
    @ApiOperation(value="Filtered payable list",notes="Filtered payable list for the company list",response=ApplicationResponse.class)
	@PostMapping("/filter/payableList")
	public ApplicationResponse getPayableListFilter(@ApiParam(value="company id list filter payload",required=true) @RequestBody ListOfString filterVo) throws ApplicationException {
		return getApplicationResponse(payableService.getPayableListFilter(filterVo));
	}

	/**
	 * GET FILTERED PAYABLE-LIST COUNT.
	 *
	 * @param filterVo the filter vo
	 * @return the filtered payable list count
	 * @throws ApplicationException the application exception
	 */
    @ApiOperation(value="Filtered payable count",notes="Filtered payable count for the company list",response=ApplicationResponse.class)
	@PostMapping("/filter/payableListCount")
	public ApplicationResponse getFilteredPayableListCount(@ApiParam(value="company id list filter payload",required=true) @RequestBody ListOfString filterVo)
			throws ApplicationException {
		return getApplicationResponse(payableService.getFilteredPayableListCount(filterVo));
	}

	/**
	 * GET ALL PAYABLE-LIST FILTER.
	 *
	 * @param filterVo the filter vo
	 * @return the all payable list filter
	 * @throws ApplicationException the application exception
	 */
    @ApiOperation(value="Filtered  all payable list",notes="Filtered payable list for the authority",response=ApplicationResponse.class)
	@PostMapping("/filter/all-payableList")
	public ApplicationResponse getAllPayableListFilter(@ApiParam(value="company id list filter payload",required=true) @RequestBody ListOfString filterVo) throws ApplicationException {
		return getApplicationResponse(payableService.getAllPayableListFilter(filterVo));
	}

	/**
	 * GET FILTERED ALL PAYABLE-LIST COUNT.
	 *
	 * @param filterVo the filter vo
	 * @return the associate filterd payable list count
	 * @throws ApplicationException the application exception
	 */
    @ApiOperation(value="Filtered  all payable count",notes="Filtered payable count for the authority",response=ApplicationResponse.class)
	@PostMapping("/filter/all-payableListCount")
	public ApplicationResponse getAssociateFilterdPayableListCount(@ApiParam(value="company id list filter payload",required=true) @RequestBody ListOfString filterVo)
			throws ApplicationException {
		return getApplicationResponse(payableService.getAssociateFilterdPayableListCount(filterVo));
	}
	
    /**
     * Gets the class name.
     *
     * @return the class name
     */
    @Override
    protected Class<?> getClassName() {
        return this.getClass();
    }

    /**
     * Gets the vo.
     *
     * @param identity the identity
     * @return the vo
     * @throws ApplicationException the application exception
     */
    @Override
    public Object getVo(String identity) throws ApplicationException {
        return null;
    }

    /**
     * Register interceptor.
     */
    @Override
    protected void registerInterceptor() {

    }
}
