package com.recoveryportal.dao;

import java.util.List;

import org.aspectj.weaver.ast.Not;

import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.transfer.object.notification.entity.NotificationHistory;

/**
 * The Interface NotificationHistoryDao.
 */
public interface NotificationHistoryDao {
	
	/**
	 * Save notification.
	 *
	 * @param notificationHistory the notification history
	 * @return the notification history
	 * @throws ApplicationException the application exception
	 */
	NotificationHistory saveNotification(NotificationHistory notificationHistory) throws ApplicationException;
	
	/**
	 * Gets the all notifications.
	 *
	 * @param companyName the company name
	 * @return the all notifications
	 */
	List<NotificationHistory> getAllNotifications(String companyName);
	
	/**
	 * Gets the claim history for claim.
	 *
	 * @param claimId the claim id
	 * @return the claim history for claim
	 */
	List<NotificationHistory> getClaimHistoryForClaim(Integer claimId);
	
	/**
	 * Gets the un read notification for claim and company.
	 *
	 * @param claimId the claim id
	 * @param toNotifyCompany the to notify company
	 * @return the un read notification for claim and company
	 */
	NotificationHistory getUnReadNotificationForClaimAndCompany(Integer claimId, String toNotifyCompany);
	
	/**
	 * Update notification history.
	 *
	 * @param notificationHistory the notification history
	 */
	void updateNotificationHistory(NotificationHistory notificationHistory);

	/**
	 * Update notification by notification identity.
	 *
	 * @param identity the identity
	 * @param userId the user id
	 * @return true, if successful
	 */
	public boolean updateNotificationByNotificationIdentity(String identity, Integer userId);
	
	/**
	 * Check for exisiting remainder.
	 *
	 * @param claimId the claim id
	 * @param toNotify the to notify
	 * @return the notification history
	 */
	NotificationHistory checkForExisitingRemainder(Integer claimId, String toNotify);

}
