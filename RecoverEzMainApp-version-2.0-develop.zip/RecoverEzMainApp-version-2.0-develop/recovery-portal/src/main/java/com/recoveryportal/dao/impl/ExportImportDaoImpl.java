package com.recoveryportal.dao.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.poi.ss.formula.functions.T;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.recoveryportal.config.common.base.dao.BaseDao;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.dao.IExportImportDao;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.transfer.object.entity.DropDownListOptionMapping;
import com.recoveryportal.transfer.object.entity.TableEntityMapping;
import com.recoveryportal.utils.core.ApplicationUtils;

/**
 * The Class ExportImportDaoImpl.
 */
@Repository
@Transactional
public class ExportImportDaoImpl extends BaseDao implements IExportImportDao{
	
	/** The entity manager. */
	@PersistenceContext
	EntityManager entityManager;
	
	/** The jdbc template. */
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
	}
	
	/**
	 * Fetch all master data.
	 *
	 * @param className the class name
	 * @return the list
	 */
	@Override
	public List<T> fetchAllMasterData(Class<T> className) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
	    CriteriaQuery<T> criteria = builder.createQuery(className);
	    Root<T> root = criteria.from(className);
	    criteria.select(root);
	    return entityManager.createQuery(criteria).getResultList();
	}
	
	/**
	 * Fetch all master data by identity.
	 *
	 * @param className the class name
	 * @param childObjectId the child object id
	 * @param idFieldName the id field name
	 * @return the object
	 */
	@Override
	public Object fetchAllMasterDataByIdentity(Class<T> className, Integer childObjectId, String idFieldName) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
	    CriteriaQuery<T> criteria = builder.createQuery(className);
	    Root<T> root = criteria.from(className);
	    criteria.select(root);
	    List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.equal(root.get(idFieldName), childObjectId));
	    try {
	    	return (Object) getSingleResult(createQuery(builder, criteria, root, predicates));
	    } catch (NoResultException e) {
	        return null;
	    }
	}
	
	/**
	 * Truncate table for I nser.
	 *
	 * @param tableName the table name
	 */
	@Override
	public void truncateTableForINser(String tableName) {
		entityManager.createNativeQuery("SET FOREIGN_KEY_CHECKS = 0").executeUpdate();
	    entityManager.createNativeQuery("TRUNCATE TABLE "+tableName).executeUpdate();
	    entityManager.createNativeQuery("SET FOREIGN_KEY_CHECKS = 1").executeUpdate();
	}
	
	/**
	 * Save all master datas.
	 *
	 * @param masterObjects the master objects
	 * @param tableName the table name
	 * @param isIdentity the is identity
	 * @param isUpdate the is update
	 * @return the integer
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Integer saveAllMasterDatas(Object masterObjects, String tableName, Boolean isIdentity, Boolean isUpdate)
			throws ApplicationException {
		Integer savedrefId = 0;
		if (isIdentity && Boolean.FALSE.equals(isUpdate)) {
			hibernateTemplate.getSessionFactory().getCurrentSession().clear();
		    savedrefId = save(masterObjects, tableName);
		} else if(Boolean.FALSE.equals(isIdentity)) {
			savedrefId = saveWithoutIdentityWithoutSetter(masterObjects);
		}else if (Boolean.TRUE.equals(isUpdate)) {
			savedrefId = save(masterObjects, tableName);
		}
		return savedrefId;
	}
	
	/**
	 * Save all master datas mock.
	 *
	 * @param masterObjects the master objects
	 * @param tableName the table name
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void saveAllMasterDatasMock(Object masterObjects, String tableName) throws ApplicationException {
		hibernateTemplate.getSessionFactory().getCurrentSession().clear();
	    save(masterObjects, tableName);
	}
	
	/**
	 * Update master data.
	 *
	 * @param masterObject the master object
	 * @param entityName the entity name
	 */
	@Override
	public void updateMasterData(Object masterObject, String entityName) {
		try {
			hibernateTemplate.merge(masterObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Gets the entity table mapping.
	 *
	 * @return the entity table mapping
	 */
	@Override
	public List<TableEntityMapping> getEntityTableMapping() {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<TableEntityMapping> criteria = builder.createQuery(TableEntityMapping.class);
		Root<TableEntityMapping> root = criteria.from(TableEntityMapping.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		
		criteria.orderBy(builder.asc(root.get("order")));
		return (List<TableEntityMapping>) getResultList(createQuery(builder, criteria, root, predicates));
	}
	
	/**
	 * Gets the child master data by identity.
	 *
	 * @param identity the identity
	 * @return the child master data by identity
	 */
	public List<TableEntityMapping> getchildMasterDataByIdentity(String identity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<TableEntityMapping> criteria = builder.createQuery(TableEntityMapping.class);
		Root<TableEntityMapping> root = criteria.from(TableEntityMapping.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.equal(root.get("identity"), identity));
		return (List<TableEntityMapping>) getResultList(createQuery(builder, criteria, root, predicates));
	}
	
	/**
	 * Gets the join master table.
	 *
	 * @param platformId the platform id
	 * @return the join master table
	 */
	@Override
	public List<TableEntityMapping> getJoinMasterTable(Integer platformId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<TableEntityMapping> criteria = builder.createQuery(TableEntityMapping.class);
		Root<TableEntityMapping> root = criteria.from(TableEntityMapping.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.equal(root.get("joinStatus"), true));
		predicates.add(builder.equal(root.get("platform"), platformId));
		criteria.orderBy(builder.asc(root.get("order")));
		return (List<TableEntityMapping>) getResultList(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Gets the all test.
	 *
	 * @return the all test
	 */
	public DropDownListOptionMapping getAllTest() {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<DropDownListOptionMapping> criteria = builder.createQuery(DropDownListOptionMapping.class);
		Root<DropDownListOptionMapping> root = criteria.from(DropDownListOptionMapping.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		return (DropDownListOptionMapping) getSingleResult(createQuery(builder, criteria, root, predicates));
	}
	
	/**
	 * Gets the list of master datas.
	 *
	 * @param tableName the table name
	 * @return the list of master datas
	 */
	@Override
	public List<Map<String, Object>> getListOfMasterDatas(String tableName){
		String selectSql = "SELECT * FROM "+tableName;
		return jdbcTemplate.queryForList(selectSql);
	}
	
	/**
	 * Gets the map result by primary id.
	 *
	 * @param tableName the table name
	 * @param columnName the column name
	 * @param primaryId the primary id
	 * @return the map result by primary id
	 */
	@Override
	public Map<String, Object> getMapResultByPrimaryId(String tableName, String columnName, Integer primaryId) {
		String selectQuery = "SELECT * FROM " + tableName + " WHERE " + columnName + " = " + primaryId;
		List<Map<String, Object>>resultMap = jdbcTemplate.queryForList(selectQuery);
		return ApplicationUtils.isValidateObject(resultMap) ? resultMap.get(0) : null;
	}
	
	/**
	 * Check foreign key constraints disable.
	 */
	@Override
	public void checkForeignKeyConstraintsDisable() {
		entityManager.createNativeQuery("SET FOREIGN_KEY_CHECKS = 0").executeUpdate();
	}
	
	/**
	 * Check foreign key constraints enable.
	 */
	@Override
	public void checkForeignKeyConstraintsEnable() {
		entityManager.createNativeQuery("SET FOREIGN_KEY_CHECKS = 1").executeUpdate();
	}
	
	/**
	 * Save master data native query.
	 *
	 * @param columnValues the column values
	 * @param tableName the table name
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void saveMasterDataNativeQuery(Map<String, Object> columnValues, String tableName) throws ApplicationException {
		StringBuilder sql = new StringBuilder("INSERT INTO " + tableName + " (");
        StringBuilder valuesPlaceholder = new StringBuilder(" VALUES (");
        int index = 0;
        for (String column : columnValues.keySet()) {
            sql.append(column);
            valuesPlaceholder.append(":").append(column);
            if (index < columnValues.size() - 1) {
                sql.append(", ");
                valuesPlaceholder.append(", ");
            }
            index++;
        }
        sql.append(")").append(valuesPlaceholder).append(")");
        var query = entityManager.createNativeQuery(sql.toString());
        for (Map.Entry<String, Object> entry : columnValues.entrySet()) {
			formatCreateAndModifiedDate(entry);
            query.setParameter(entry.getKey(), entry.getValue());
        }
        query.executeUpdate();
	}

	/**
	 * Format create and modified date.
	 *
	 * @param entry the entry
	 */
	private void formatCreateAndModifiedDate(Map.Entry<String, Object> entry) {
		if (entry.getKey().equals(TableConstants.CREATEDATE) || entry.getKey().equals(TableConstants.MODIF_DATE)) {
			if(ApplicationUtils.isValidObject(entry.getValue())) {
				Date date = null;
				try {
					date = new Date(Long.parseLong(entry.getValue().toString()));
					entry.setValue(date);
				} catch (Exception e) {
					
					List<Integer> dateList = new ArrayList<>((List<Integer>) entry.getValue());
					LocalDateTime dateTime = LocalDateTime.of(
				            dateList.get(0),
				            dateList.get(1),
				            dateList.get(2),
				            dateList.get(3),
				            dateList.get(4)
				        );
					entry.setValue(dateTime);
				}
			}
		}
	}
	
	/**
	 * Update dynamic record.
	 *
	 * @param tableName the table name
	 * @param columnValues the column values
	 * @param conditionColumn the condition column
	 * @param conditionValue the condition value
	 */
	@Override
	public void updateDynamicRecord(String tableName, Map<String, Object> columnValues, String conditionColumn, Object conditionValue) {
        if (columnValues == null || columnValues.isEmpty()) {
            throw new IllegalArgumentException("Column values cannot be empty");
        }
        StringBuilder sql = new StringBuilder("UPDATE " + tableName + " SET ");
        int index = 0;
        for (String column : columnValues.keySet()) {
        	if(!column.equals(conditionColumn)) {
        		sql.append(column).append(" = :").append(column);

                if (index < columnValues.size() - 1) {
                    sql.append(", ");
                }        		
        	}
            index++;
        }
        sql.append(" WHERE ").append(conditionColumn).append(" = :conditionValue");
        var query = entityManager.createNativeQuery(sql.toString());
        for (Map.Entry<String, Object> entry : columnValues.entrySet()) {
        	if(!entry.getKey().equals(conditionColumn)) {
        		formatCreateAndModifiedDate(entry);
        		query.setParameter(entry.getKey(), entry.getValue());
        	}
        }
        query.setParameter("conditionValue", conditionValue);
        query.executeUpdate();
    }

}
