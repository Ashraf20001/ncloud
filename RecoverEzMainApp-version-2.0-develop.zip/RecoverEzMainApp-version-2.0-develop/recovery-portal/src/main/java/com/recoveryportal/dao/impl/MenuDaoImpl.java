package com.recoveryportal.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.recoveryportal.config.common.base.dao.BaseDao;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.dao.MenuDao;
import com.recoveryportal.transfer.object.entity.Menu;

/**
 * The Class MenuDaoImpl.
 */
@Repository
@Transactional
public class MenuDaoImpl extends BaseDao implements MenuDao {
	
    /** The model mapper. */
    @Autowired
    ModelMapper modelMapper;
    


    /**
     * Gets the all menu dto details.
     *
     * @return the all menu dto details
     */
    @Override
    public List<Menu> getAllMenuDtoDetails() {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<Menu> criteria = builder.createQuery(Menu.class);
        Root<Menu> root = criteria.from(Menu.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.isFalse(root.get(TableConstants.ISDELETED)));
        return (List<Menu>) getResultList(createQuery(builder, criteria, root, predicates));
    }
    


    /**
     * Gets the all menu data by user id.
     *
     * @param menuIdList the menu id list
     * @return the all menu data by user id
     */
    @Override
    public List<Menu> getAllMenuDataByUserId(List<String> menuIdList) {

        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<Menu> criteria = builder.createQuery(Menu.class);
        Root<Menu> root = criteria.from(Menu.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.isFalse(root.get(TableConstants.ISDELETED)));

        Expression<String> parentExpression = root.get(TableConstants.MENU_ID);
        Predicate parentPredicate = parentExpression.in(menuIdList);
        predicates.add(builder.and(parentPredicate));

        return (List<Menu>) getResultList(createQuery(builder, criteria, root, predicates));
    }

    /**
     * Register data filters.
     */
    @Override
    public void registerDataFilters() {

    }
}
