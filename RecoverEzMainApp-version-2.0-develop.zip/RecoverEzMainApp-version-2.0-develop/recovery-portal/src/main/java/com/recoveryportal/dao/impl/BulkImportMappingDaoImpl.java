package com.recoveryportal.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.recoveryportal.config.common.base.dao.BaseDao;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.dao.BulkImportMappingDao;
import com.recoveryportal.transfer.object.entity.BulkImportMapping;

/**
 * The Class BulkImportMappingDaoImpl.
 */
@Repository
@Transactional
public class BulkImportMappingDaoImpl extends BaseDao implements BulkImportMappingDao {

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {

	}
    
    /**
     * All get field names.
     *
     * @return the list
     */
    @SuppressWarnings("unchecked")
	@Override
	public List<BulkImportMapping> allGetFieldNames() {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<BulkImportMapping> criteria = builder.createQuery(BulkImportMapping.class);
		Root<BulkImportMapping> root = criteria.from(BulkImportMapping.class);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
		criteria.select(root);
		List<Order> orderList = new ArrayList<>();
		orderList.add(builder.asc(root.get(TableConstants.SECTION).get(TableConstants.SECTION_ID)));
		orderList.add(builder.asc(root.get(TableConstants.ORDER_BY)));
		criteria.orderBy(orderList);
		return (List<BulkImportMapping>) getResultList(createQuery(builder, criteria, root, predicates));
	}

}
