package com.recoveryportal.dao;

import com.recoveryportal.transfer.object.dto.CompanyAndCountDto;
import com.recoveryportal.transfer.object.dto.ListOfString;
import com.recoveryportal.transfer.object.reportloss.entity.ReportLoss;

import java.util.List;

/**
 * The Interface PayableDao.
 */
public interface PayableDao {
    
    /**
     * Gets the payable list by company.
     *
     * @param payableCompanyId the payable company id
     * @param receivableCompanyIdList the receivable company id list
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the payable list by company
     */
    List<ReportLoss> getPayableListByCompany(Integer payableCompanyId, ListOfString receivableCompanyIdList, String currencyFieldName, String currencyValue);

    /**
     * Gets the payable list grouped by company.
     *
     * @return the payable list grouped by company
     */
    List<ReportLoss> getPayableListGroupedByCompany();

	/**
	 * Gets the company claims count.
	 *
	 * @param userCompanyId the user company id
	 * @param insuranceCompanyId the insurance company id
	 * @return the company claims count
	 */
	Long getCompanyClaimsCount(Integer userCompanyId,Integer insuranceCompanyId);

	/**
	 * Gets the payable count by stage list.
	 *
	 * @param userCompanyId the user company id
	 * @param companyId the company id
	 * @param notificationList the notification list
	 * @return the payable count by stage list
	 */
	Long getPayableCountByStageList(Integer userCompanyId,Integer companyId, List<String> notificationList);

	/**
	 * Gets the all payable counts.
	 *
	 * @param companyId the company id
	 * @return the all payable counts
	 */
	Long getAllPayableCounts(Integer companyId);

	/**
	 * Gets the all payable count by stage list.
	 *
	 * @param companyId the company id
	 * @param stateList the state list
	 * @return the all payable count by stage list
	 */
	Long getAllPayableCountByStageList(Integer companyId, List<String> stateList);
	
	/**
	 * Gets the payable count by stage.
	 *
	 * @param companyId the company id
	 * @param notificationList the notification list
	 * @param isAssociation the is association
	 * @return the payable count by stage
	 */
	List<CompanyAndCountDto> getPayableCountByStage(Integer companyId,List<String> notificationList,boolean isAssociation);


	/**
	 * Gets the all payable count.
	 *
	 * @param userCompanyId the user company id
	 * @param isAssociation the is association
	 * @return the all payable count
	 */
	List<CompanyAndCountDto> getAllPayableCount(Integer userCompanyId,boolean isAssociation);
	
	/**
	 * Gets the all receivable count.
	 *
	 * @param userCompanyId the user company id
	 * @param isAssociation the is association
	 * @return the all receivable count
	 */
	List<CompanyAndCountDto> getAllReceivableCount(Integer userCompanyId,boolean isAssociation);
	
	/**
	 * Gets the receivable count by stage.
	 *
	 * @param companyId the company id
	 * @param stateList the state list
	 * @param isAssociation the is association
	 * @return the receivable count by stage
	 */
	List<CompanyAndCountDto> getReceivableCountByStage(Integer companyId, List<String> stateList,boolean isAssociation);
	
	/**
	 * Gets the payable listby grp name.
	 *
	 * @param companyId the company id
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the payable listby grp name
	 */
	public List<ReportLoss> getPayableListbyGrpName(ListOfString companyId, String currencyFieldName, String currencyValue);

	/**
	 * Gets the payable count.
	 *
	 * @param userCompanyId the user company id
	 * @param isAssociation the is association
	 * @return the payable count
	 */
	Long getPayableCount(Integer userCompanyId, boolean isAssociation);

	/**
	 * Gets the total count for payable.
	 *
	 * @param userCompanyId the user company id
	 * @param companyIdList the company id list
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the total count for payable
	 */
	Long getTotalCountForPayable(Integer userCompanyId, ListOfString companyIdList, String currencyFieldName, String currencyValue);

	/**
	 * Gets the receivable listby grp name count.
	 *
	 * @param companyId the company id
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the receivable listby grp name count
	 */
	Long getReceivableListbyGrpNameCount(ListOfString companyId, String currencyFieldName, String currencyValue);
	
	/**
	 * GetRecivableListbyGrpName.
	 *
	 * @param companyId the company id
	 * @return the recivable listby grp name
	 */
	List<ReportLoss> getRecivableListbyGrpName(ListOfString companyId);

	/**
	 * GET FILTRED PAYABLE-LIST.
	 *
	 * @param userCompanyId the user company id
	 * @param filterVo the filter vo
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the filtred payable list
	 */
	List<ReportLoss> getFiltredPayableList(Integer userCompanyId, ListOfString filterVo, String currencyFieldName, String currencyValue);

	/**
	 * GET FILTERED PAYABLE-LIST COUNT.
	 *
	 * @param userCompanyName the user company name
	 * @param filterVo the filter vo
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the filtered payable list count
	 */
	Long getFilteredPayableListCount(Integer userCompanyName, ListOfString filterVo, String currencyFieldName, String currencyValue);

	/**
	 * GET FILTERED ALL PAYABLE-LIST.
	 *
	 * @param filterVo the filter vo
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the filtered all payable list
	 */
	List<ReportLoss> getFilteredAllPayableList(ListOfString filterVo, String currencyFieldName, String currencyValue);

	/**
	 * GET FILTERED ALL PAYABLE-LIST COUNT.
	 *
	 * @param filterVo the filter vo
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the filtered all payable list count
	 */
	Long getFilteredAllPayableListCount(ListOfString filterVo, String currencyFieldName, String currencyValue);
}
