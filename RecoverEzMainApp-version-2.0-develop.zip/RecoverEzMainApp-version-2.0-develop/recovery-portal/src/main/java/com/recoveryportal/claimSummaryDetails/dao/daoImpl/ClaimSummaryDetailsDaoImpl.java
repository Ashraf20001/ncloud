package com.recoveryportal.claimSummaryDetails.dao.daoImpl;

import com.recoveryportal.claimSummaryDetails.dao.ClaimSummaryDetailsDao;
import com.recoveryportal.config.common.base.dao.BaseDao;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.transfer.object.claimSummaryDetails.dto.ClaimSummaryDetailsDto;
import com.recoveryportal.transfer.object.claimSummaryDetails.entity.ClaimSummaryDetails;
import com.recoveryportal.transfer.object.reportloss.entity.ReportLoss;
import org.springframework.stereotype.Repository;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

/**
 * The Class ClaimSummaryDetailsDaoImpl.
 */
@Repository
@Transactional
public class ClaimSummaryDetailsDaoImpl extends BaseDao implements ClaimSummaryDetailsDao {

    /**
     * Gets the all claim summary details.
     *
     * @return the all claim summary details
     */
    @Override
    public List<ClaimSummaryDetails> getAllClaimSummaryDetails() {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<ClaimSummaryDetails> criteria = builder.createQuery(ClaimSummaryDetails.class);
        Root<ClaimSummaryDetails> root = criteria.from(ClaimSummaryDetails.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
        return (List<ClaimSummaryDetails>) getResultList(createQuery(builder, criteria, root, predicates));    }

    /**
     * Gets the claim summary details by identity.
     *
     * @param identity claim summary details identity
     * @return the claim summary details by identity
     */
    @Override
    public ClaimSummaryDetails getClaimSummaryDetailsByIdentity(String identity) {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<ClaimSummaryDetails> criteria = builder.createQuery(ClaimSummaryDetails.class);
        Root<ClaimSummaryDetails> root = criteria.from(ClaimSummaryDetails.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.IDENTITY), identity)));
        return (ClaimSummaryDetails) getSingleResult(createQuery(builder, criteria, root, predicates));    }

    /**
     * Save claim summary details.
     *
     * @param claimSummaryDetails the claim summary details
     * @return the claim summary details
     * @throws ApplicationException the application exception
     */
    @Override
    public ClaimSummaryDetails saveClaimSummaryDetails(ClaimSummaryDetails claimSummaryDetails) throws ApplicationException {
        save(claimSummaryDetails,TableConstants.CLAIM_SUMMARY_DETAILS);
        return claimSummaryDetails;
    }

    /**
     * Update claim summary details.
     *
     * @param claimSummaryDetails the claim summary details
     * @return the claim summary details
     */
    @Override
    public ClaimSummaryDetails updateClaimSummaryDetails(ClaimSummaryDetails claimSummaryDetails) {
        update(claimSummaryDetails);
        return claimSummaryDetails;
    }

    /**
     * Register data filters.
     */
    @Override
    public void registerDataFilters() {

    }
}
