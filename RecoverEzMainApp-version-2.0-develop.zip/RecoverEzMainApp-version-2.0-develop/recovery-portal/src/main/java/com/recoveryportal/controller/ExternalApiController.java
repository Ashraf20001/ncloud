package com.recoveryportal.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.recoveryportal.config.base.controller.BaseController;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.service.IExternalApiService;
import com.recoveryportal.transfer.object.core.ApplicationResponse;
import com.recoveryportal.transfer.object.dto.CommentExternalDto;
import com.recoveryportal.transfer.object.externalApi.Dto.ReportLossExternalDto;
import com.recoveryportal.transfer.object.reportloss.dto.ReportLossViewDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class ExternalApiController.
 */
@RestController
public class ExternalApiController extends BaseController{

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ExternalApiController.class);

	/** The external api service. */
	@Autowired
	private IExternalApiService externalApiService;
	
	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {
		
	}
	
	/**
	 * Save external report loss.
	 *
	 * @param reportLossExternalDto the report loss external dto
	 * @return the application response
	 * @throws ApplicationException the application exception
	 * @throws ClassNotFoundException the class not found exception
	 */
	@ApiOperation(value = "External api report loss save",notes = "Report loss claims save operation in external api", response = ApplicationResponse.class)
	@PostMapping(value = "/external/claims", produces = MediaType.APPLICATION_JSON_VALUE)
	public ApplicationResponse saveExternalReportLoss(@ApiParam(value = "External report loss dto payload",required = true)  @RequestBody ReportLossExternalDto reportLossExternalDto) throws ApplicationException, ClassNotFoundException {
		logger.info("Starting of ExternalApiController saveExternalReportLoss()");
		ReportLossViewDto saveExternalReportLoss = externalApiService.saveExternalReportLoss(reportLossExternalDto);
		return getApplicationResponse(saveExternalReportLoss);
	}
	
	/**
	 * Gets the external report loss.
	 *
	 * @param ClaimNumber the claim number
	 * @return the external report loss
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "External api get report loss claims",notes = "Get report loss claim using claim number in external api", response = ApplicationResponse.class)
	@GetMapping(value = "/external/claims/get", produces = MediaType.APPLICATION_JSON_VALUE)
	public ApplicationResponse getExternalReportLoss(@ApiParam(value="claim number",required = true) @RequestParam String ClaimNumber) throws ApplicationException {
		logger.info("Starting of ExternalApiController saveExternalReportLoss()");
		ReportLossExternalDto saveExternalReportLoss = externalApiService.getExternalReportLoss(ClaimNumber);
		return getApplicationResponse(saveExternalReportLoss);
	}
	
	/**
	 * Update external report loss.
	 *
	 * @param reportLossExternalDto the report loss external dto
	 * @return the application response
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="External api update report loss claims",notes="Update report loss claims in external api", response=ApplicationResponse.class)
	@PutMapping(value = "/external/update/claims", produces = MediaType.APPLICATION_JSON_VALUE)
	public ApplicationResponse updateExternalReportLoss(@ApiParam(value = "report loss external dto payload", required= true) @RequestBody ReportLossExternalDto reportLossExternalDto) throws ApplicationException {
		logger.info("Starting of ExternalApiController updateExternalReportLoss()");
		ReportLossViewDto updateExternalReportLoss = externalApiService.updateExternalReportLoss(reportLossExternalDto);
		return getApplicationResponse(updateExternalReportLoss);
	}
	
	/**
	 * Change status by action button.
	 *
	 * @param comment the comment
	 * @param id the id
	 * @param button the button
	 * @return the application response
	 * @throws ApplicationException the application exception
	 * @throws ClassNotFoundException the class not found exception
	 */
	@ApiOperation(value ="External api status change",notes="Change status of claims by button action using external api", response=ApplicationResponse.class)
	@PostMapping(value = "claims/{id}/{button}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ApplicationResponse changeStatusByActionButton(@ApiParam(value="comments dto payload") @RequestBody(required=false) CommentExternalDto comment , @ApiParam(value="claim id",required = true) @PathVariable String id, @ApiParam(value="action button",required=true) @PathVariable String button ) throws ApplicationException, ClassNotFoundException {
		logger.info("Starting of ExternalApiController changeStatusByActionButton()");
		String changeStatusByActionButton = externalApiService.changeStatusByActionButton(id,button,comment);
		return getApplicationResponse(changeStatusByActionButton);
	}

}
