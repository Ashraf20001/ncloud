package com.recoveryportal.dao;

import java.util.List;

import com.recoveryportal.transfer.object.dto.SchedulerNotificationDto;
import com.recoveryportal.transfer.object.entity.SchedulerNotification;

/**
 * The Interface SchedulerNotifiactionDao.
 */
public interface SchedulerNotifiactionDao {
	
	/**
	 * Gets the scheduler notification by state.
	 *
	 * @param state the state
	 * @return the scheduler notification by state
	 */
	SchedulerNotification getSchedulerNotificationByState(String state);

	/**
	 * Gets the all scheduler list.
	 *
	 * @return the all scheduler list
	 */
	List<SchedulerNotification> getAllSchedulerList();

	/**
	 * Gets the scheduler details by id.
	 *
	 * @param id the id
	 * @return the scheduler details by id
	 */
	SchedulerNotification getSchedulerDetailsById(Integer id);

	/**
	 * Update scheduler details.
	 *
	 * @param schedulerNotificationDto the scheduler notification dto
	 */
	void updateSchedulerDetails(SchedulerNotificationDto schedulerNotificationDto);

	/**
	 * Gets the reminder by notification name.
	 *
	 * @param notificationName the notification name
	 * @return the reminder by notification name
	 */
	Integer getReminderByNotificationName(String notificationName);

	/**
	 * Gets the scheduler notification by name.
	 *
	 * @param notificationName the notification name
	 * @return the scheduler notification by name
	 */
	SchedulerNotification getSchedulerNotificationByName(String notificationName);

	/**
	 * Gets the scheduler notification by triggered status.
	 *
	 * @param triggeredStatus the triggered status
	 * @return the scheduler notification by triggered status
	 */
	SchedulerNotification getSchedulerNotificationByTriggeredStatus(String triggeredStatus);
}
