package com.recoveryportal.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.recoveryportal.config.common.base.dao.BaseDao;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.dao.BulkImportTempDataDao;
import com.recoveryportal.transfer.object.dto.SortingDto;
import com.recoveryportal.transfer.object.entity.BulkImportTempData;
import com.recoveryportal.utils.core.ApplicationUtils;

/**
 * The Class BulkImportTempDataDaoImpl.
 */
@Repository
@Transactional
public class BulkImportTempDataDaoImpl extends BaseDao implements BulkImportTempDataDao {
	
	/**
	 * Gets the bulk import temp data for error excel.
	 *
	 * @param uploadid the uploadid
	 * @param sortingDto the sorting dto
	 * @return the bulk import temp data for error excel
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<BulkImportTempData> getBulkImportTempDataForErrorExcel(Integer uploadid,SortingDto sortingDto){
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<BulkImportTempData> criteria = builder.createQuery(BulkImportTempData.class);
		Root<BulkImportTempData> root = criteria.from(BulkImportTempData.class);
				criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.UPLOAD_ID), uploadid)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.STATUS),false)));
		if(ApplicationUtils.isValidId(sortingDto.getSkip())) {
			if(ApplicationUtils.isValidString(sortingDto.getColumnName())) {
				if(sortingDto.getIsAscending()) {
					criteria.select(root) .orderBy(builder.asc(root.get(sortingDto.getColumnName())));
				}else {
					criteria.select(root) .orderBy(builder.desc(root.get(sortingDto.getColumnName())));
				}
			}
			return (List<BulkImportTempData>) getResultList(createQuery(builder, criteria, root, predicates).setFirstResult(sortingDto.getLimit()).setMaxResults(sortingDto.getSkip()));
		}
		return (List<BulkImportTempData>) getResultList(createQuery(builder, criteria, root, predicates));
		
	}
	
	/**
	 * Gets the bulk import temp data for success excel.
	 *
	 * @param uploadid the uploadid
	 * @param sortingDto the sorting dto
	 * @return the bulk import temp data for success excel
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<BulkImportTempData> getBulkImportTempDataForSuccessExcel(Integer uploadid,SortingDto sortingDto){
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<BulkImportTempData> criteria = builder.createQuery(BulkImportTempData.class);
		Root<BulkImportTempData> root = criteria.from(BulkImportTempData.class);
				criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.UPLOAD_ID), uploadid)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.STATUS),true)));
		if(ApplicationUtils.isValidId(sortingDto.getSkip())) {
			if(ApplicationUtils.isValidString(sortingDto.getColumnName())) {
				if(sortingDto.getIsAscending()) {
					criteria.select(root) .orderBy(builder.asc(root.get(sortingDto.getColumnName())));
				}else {
					criteria.select(root) .orderBy(builder.desc(root.get(sortingDto.getColumnName())));
				}
			}
			return (List<BulkImportTempData>) getResultList(createQuery(builder, criteria, root, predicates).setFirstResult(sortingDto.getLimit()).setMaxResults(sortingDto.getSkip()));
		}
		return (List<BulkImportTempData>) getResultList(createQuery(builder, criteria, root, predicates));
		
	}

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {		
	}
	 
	
	
	

	

}
