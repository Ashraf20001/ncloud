package com.recoveryportal.dao;

import java.util.List;

import com.recoveryportal.transfer.object.dto.SortingDto;
import com.recoveryportal.transfer.object.entity.BulkImportTempData;

/**
 * The Interface BulkImportTempDataDao.
 */
public interface BulkImportTempDataDao {

	/**
	 * Gets the bulk import temp data for error excel.
	 *
	 * @param uploadid the uploadid
	 * @param sortingDto the sorting dto
	 * @return the bulk import temp data for error excel
	 */
	List<BulkImportTempData> getBulkImportTempDataForErrorExcel(Integer uploadid,SortingDto sortingDto);

	/**
	 * Gets the bulk import temp data for success excel.
	 *
	 * @param uploadId the upload id
	 * @param sortingDto the sorting dto
	 * @return the bulk import temp data for success excel
	 */
	List<BulkImportTempData> getBulkImportTempDataForSuccessExcel(Integer uploadId,SortingDto sortingDto);
}
