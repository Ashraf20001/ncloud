package com.recoveryportal.config;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

@Component
public class ShellScriptRunner {
	
	 @PostConstruct
	    public void runScript() {
	        try {
	        	 String command;
	             String osName = System.getProperty("os.name").toLowerCase();

	             if (osName.contains("win")) {
	                 // Windows environment
	                 command = "C:\\Program Files\\Git\\bin\\bash.exe /C/sample_project/Recover_live/repo/RecoverEZPlatformMainApp/recovery-portal/src/main/resources/run-scripts.sh";
	             } else {
	                 // Linux/Unix environment
	                 command = "/mnt/MainApp/removelog.sh";
	             }
	        	
	        	
		            Process process = Runtime.getRuntime().exec(command);
		

	            int exitCode = process.waitFor();

	            if (exitCode == 0) {
	                System.out.println("Script executed successfully!");
	            } else {
	                System.err.println("Script execution failed with exit code " + exitCode);
	            }

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

}
