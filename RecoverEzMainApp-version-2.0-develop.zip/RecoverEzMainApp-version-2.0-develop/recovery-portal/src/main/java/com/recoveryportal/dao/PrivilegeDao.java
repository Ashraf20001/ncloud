package com.recoveryportal.dao;

import java.util.List;

import com.recoveryportal.transfer.object.entity.Privilege;

/**
 * The Interface PrivilegeDao.
 */
public interface PrivilegeDao {


    /**
     * Gets the all privilege dto details.
     *
     * @return the all privilege dto details
     */
    List<Privilege> getAllPrivilegeDtoDetails();

    
}
