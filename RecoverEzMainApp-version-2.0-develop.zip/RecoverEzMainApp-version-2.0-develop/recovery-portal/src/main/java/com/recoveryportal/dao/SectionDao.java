package com.recoveryportal.dao;

import java.util.List;

import com.recoveryportal.transfer.object.entity.Section;

/**
 * The Interface SectionDao.
 */
public interface SectionDao {
	
    
    /**
     * Gets the all section dto details.
     *
     * @return the all section dto details
     */
    List<Section> getAllSectionDtoDetails();
    
}
