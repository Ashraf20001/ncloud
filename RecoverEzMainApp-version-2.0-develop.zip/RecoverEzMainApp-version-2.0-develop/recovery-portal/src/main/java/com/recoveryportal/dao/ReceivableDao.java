package com.recoveryportal.dao;

import java.util.List;

import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.transfer.object.dto.ListOfString;
import com.recoveryportal.transfer.object.entity.TotalLoss;
import com.recoveryportal.transfer.object.reportloss.entity.ReportLoss;

/**
 * The Interface ReceivableDao.
 */
public interface ReceivableDao {


	/**
	 * Gets the recivable list.
	 *
	 * @param receivableCompanyId the receivable company id
	 * @param payableCompanyIdList the payable company id list
	 * @param knocktoknock the knocktoknock
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the recivable list
	 */
	public List<ReportLoss> getRecivableList(Integer receivableCompanyId, ListOfString payableCompanyIdList, String knocktoknock, String currencyFieldName, String currencyValue);

	/**
	 * Gets the recivable listby grp.
	 *
	 * @return the recivable listby grp
	 */
	public List<ReportLoss> getRecivableListbyGrp();

	/**
	 * Gets the report loss identity.
	 *
	 * @param claimId the claim id
	 * @return the report loss identity
	 */
	ReportLoss getReportLossIdentity(String claimId);

	/**
	 * Update report loss.
	 *
	 * @param data the data
	 * @throws ApplicationException the application exception
	 */
	void UpdateReportLoss(ReportLoss data) throws ApplicationException;

	/**
	 * Gets the company claims count.
	 *
	 * @param userCompanyId the user company id
	 * @param tpCompanyId the tp company id
	 * @return the company claims count
	 */
	Long getCompanyClaimsCount(Integer userCompanyId,Integer tpCompanyId);

	/**
	 * Gets the receivable count by stage list.
	 *
	 * @param userCompanyId the user company id
	 * @param companyId the company id
	 * @param stateList the state list
	 * @return the receivable count by stage list
	 */
	Long getReceivableCountByStageList(Integer userCompanyId,Integer companyId, List<String> stateList);

	/**
	 * Gets the all receivable count.
	 *
	 * @param companyName the company name
	 * @return the all receivable count
	 */
	Long getAllReceivableCount(Integer companyName);

	/**
	 * Gets the all receivable count by stage list.
	 *
	 * @param companyId the company id
	 * @param stateList the state list
	 * @return the all receivable count by stage list
	 */
	Long getAllReceivableCountByStageList(Integer companyId, List<String> stateList);


	/**
	 * Gets the recivable listby grp name.
	 *
	 * @param companyId the company id
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the recivable listby grp name
	 */
	public List<ReportLoss> getRecivableListbyGrpName(ListOfString companyId, String currencyFieldName, String currencyValue);

	/**
	 * Gets the total amoutn.
	 *
	 * @param claimId the claim id
	 * @return the total amoutn
	 */
	public TotalLoss getTotalAmoutn(Integer claimId);

	/**
	 * Gets the recivable listby grp name count.
	 *
	 * @param companyId the company id
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the recivable listby grp name count
	 */
	public Long getRecivableListbyGrpNameCount(ListOfString companyId, String currencyFieldName, String currencyValue);

	/**
	 * Gets the recivable list count.
	 *
	 * @param userCompanyId the user company id
	 * @param companyId the company id
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the recivable list count
	 */
	public Long getRecivableListCount(Integer userCompanyId, ListOfString companyId, String currencyFieldName, String currencyValue);
	
	/**
	 * GetPayableListbyGrpName.
	 *
	 * @param companyId the company id
	 * @return the payable listby grp name
	 * @throws ApplicationException the application exception
	 */
	public  List<ReportLoss> getPayableListbyGrpName(ListOfString companyId) throws ApplicationException;

	/**
	 * GET FILTRED RECEIVABLE-LIST.
	 *
	 * @param userCompanyId the user company id
	 * @param companyId the company id
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the filtred receivable list
	 */
	public List<ReportLoss> getFiltredReceivableList(Integer userCompanyId, ListOfString companyId, String currencyFieldName, String currencyValue);

	/**
	 * GET FILTERED RECIVABLE-LIST COUNT.
	 *
	 * @param userCompanyId the user company id
	 * @param filterVo the filter vo
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the filtered recivable list count
	 */
	public Long getFilteredRecivableListCount(Integer userCompanyId, ListOfString filterVo, String currencyFieldName, String currencyValue);

	/**
	 * GET FILTERD ALL RECEIVABLE-LIST COUNT.
	 *
	 * @param filterVo the filter vo
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the associate filterd receivable list count
	 */
	public Long getAssociateFilterdReceivableListCount(ListOfString filterVo, String currencyFieldName, String currencyValue);

	/**
	 * GET FILTERED ALL RECEIVABLE-LIST.
	 *
	 * @param filterVo the filter vo
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the filtered all receivable list
	 */
	public List<ReportLoss> getFilteredAllReceivableList(ListOfString filterVo, String currencyFieldName, String currencyValue);
}
