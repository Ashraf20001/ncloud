package com.recoveryportal.dao;

import java.util.List;

import com.recoveryportal.transfer.object.entity.BulkImportMapping;

/**
 * The Interface BulkImportMappingDao.
 */
public interface BulkImportMappingDao {
	
	/**
	 * All get field names.
	 *
	 * @return the list
	 */
	List<BulkImportMapping> allGetFieldNames();

}
