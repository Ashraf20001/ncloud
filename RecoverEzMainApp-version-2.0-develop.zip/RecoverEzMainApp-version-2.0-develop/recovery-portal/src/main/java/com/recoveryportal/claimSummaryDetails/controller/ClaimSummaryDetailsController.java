package com.recoveryportal.claimSummaryDetails.controller;

import org.bouncycastle.oer.its.LinkageData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.recoveryportal.claimSummaryDetails.service.ClaimSummaryDetailsService;
import com.recoveryportal.config.base.controller.BaseController;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.transfer.object.claimSummaryDetails.dto.ClaimSummaryDetailsDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;


/**
 * {Claim summary details controller}
 * @author CBT
 *
 */
@RestController
@RequestMapping("/claim-summary-details")
public class ClaimSummaryDetailsController extends BaseController {
	
    /**
     *  Represents the Dependency Injection of ClaimSummaryDetailsService
     */
    @Autowired
    private ClaimSummaryDetailsService claimSummaryDetailsService;

    /**
     * Get claim summary details using claim summary identity
     * 
     * @param claimSummaryDetailsIdentity Identity of claim summary details
     * @return {@link ClaimSummaryDetailsDto} returns claim summary details
     * @throws {@link ApplicationException} Throws ApplicationException for errors
     */
	@ApiOperation(value = "Claim summary details", notes = " Get claim summary details using claim summary identity ",response = ClaimSummaryDetailsDto.class)
	@GetMapping("/getbyid")
	public ClaimSummaryDetailsDto getClaimSummaryDetailsByIdentity(@ApiParam(value = "Claim summary details identity") @RequestParam("identity") String identity)
			throws ApplicationException {
		return claimSummaryDetailsService.getClaimSummaryDetailsByIdentity(identity);
	}
	
	
    /**
     *  Create claim summary details 
     *  
     * @param claimSummaryDetailsDto {@link ClaimSummaryDetailsDto} Claim summary details dto object
     * @return {@link ClaimSummaryDetailsDto} returns claim summary details with generated id
     * @throws ApplicationException
     */
	@ApiOperation(value = "Claim summary details save", notes = " Save claim summary details using claim summary dto object ",response = ClaimSummaryDetailsDto.class)
    @PostMapping("/save")
    public ClaimSummaryDetailsDto saveClaimSummaryDetails(
    		@ApiParam(value = "Claim summary details payload", required = true)
            @RequestBody ClaimSummaryDetailsDto claimSummaryDetailsDto
            ) throws ApplicationException{
        return claimSummaryDetailsService.saveClaimSummaryDetails(claimSummaryDetailsDto);
    }
	
	
    /**
     * Update claim summary details 
     * 
     * @param claimSummaryDetailsDto  {@link ClaimSummaryDetailsDto} Claim summary details dto object
     * @param id id of Claim summary details
     * @return {@link ClaimSummaryDetailsDto} returns updated claim summary details
     * @throws ApplicationException
     */
	@ApiOperation(value = "Claim summary details update", notes = " Update claim summary details using claim summary dto object and claim summary id ",
			response = ClaimSummaryDetailsDto.class)
    @PostMapping("/update")
    public ClaimSummaryDetailsDto updateClaimSummaryDetails(
    		@ApiParam("Claim summary details payload")
            @RequestBody ClaimSummaryDetailsDto claimSummaryDetailsDto,
            @RequestParam("claim_summary_details_id") String id
    ) throws ApplicationException {
        return claimSummaryDetailsService.updateClaimSummaryDetails(id,claimSummaryDetailsDto);
    }

    @Override
    protected Class<?> getClassName() {
        return this.getClass();
    }

    @Override
    public Object getVo(String identity) throws ApplicationException {
        return null;
    }

    @Override
    protected void registerInterceptor() {

    }
}
