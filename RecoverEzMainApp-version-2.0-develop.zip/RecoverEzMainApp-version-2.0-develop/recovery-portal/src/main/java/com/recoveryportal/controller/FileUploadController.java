package com.recoveryportal.controller;


import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.recoveryportal.config.base.controller.BaseController;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.reportloss.controller.SequenceGenerator;
import com.recoveryportal.service.FileUploadService;
import com.recoveryportal.transfer.object.core.ApplicationResponse;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;



/**
 * The Class FileUploadController.
 */
@RestController
public class FileUploadController extends BaseController {
	
	/** The file upload service. */
	@Autowired
	private FileUploadService  fileUploadService;
	
	/** The sequence generator. */
	@Autowired
	private SequenceGenerator sequenceGenerator;
	
	
	/** The Constant MAX_SIZE. */
	public static final long MAX_SIZE=20;
	
	/**
	 * Upload file.
	 *
	 * @param referenceType the reference type
	 * @param referenceId the reference id
	 * @param fileList the file list
	 * @return the application response
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="file upload",notes="Endpoint which serves the file upload operation",response=ApplicationException.class)
	@PostMapping("/upload-file/{referenceId}/{referenceType}")
	public ApplicationResponse uploadFile(@ApiParam(value="File upload reference type like claim, company logo and so on",required=true) @PathVariable String referenceType,
			@ApiParam(value="File upload reference id",required=true)	@PathVariable String referenceId, @ApiParam(value="Upload File",required=true)@RequestParam("file") MultipartFile[] fileList) throws IOException, ApplicationException{

		return getApplicationResponse(fileUploadService.uploadFileByRefId(referenceType,referenceId,fileList));
	}


	/**
	 * Download file.
	 *
	 * @param fileName the file name
	 * @return the response entity
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@ApiOperation(value="File download",notes="Endpoint which serves the file download operation",response=ResponseEntity.class)
	@GetMapping("/downloadFile/{fileCode}")
	public ResponseEntity<Resource> downloadFile( @ApiParam(value="file name or uploaded file download url",required=true) @PathVariable("fileCode") String fileName) throws IOException{
		
    	Resource resource = null;
    	try {
    		resource = fileUploadService.downloadFile(fileName);
    	} catch (IOException e) {
    		return ResponseEntity.internalServerError().build();
    	}
       
    	if (resource == null) {
    		return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
    	}
       
    	String contentType = "application/octet-stream";
    	String headerValue = "attachment; filename=\"" + resource.getFilename() + "\"";
     
    	return ResponseEntity.ok()
            .contentType(MediaType.parseMediaType(contentType))
            .header(HttpHeaders.CONTENT_DISPOSITION, headerValue)
            .body(resource); 
		
	}
	
	/**
	 * Gets the file list.
	 *
	 * @param referenceId the reference id
	 * @return the file list
	 * @throws ApplicationException the application exception
	 */
	@GetMapping("/getFileList/{referenceId}")
	@ApiOperation(value="File list",notes="Endpoint which serves the list of files",response=ResponseEntity.class)
	public ApplicationResponse getFileList(@ApiParam(value="reference id", required=true) @PathVariable("referenceId") Integer referenceId) throws ApplicationException {
		return getApplicationResponse(fileUploadService.getFileListByGroupId(referenceId));
	}
	
	/**
	 * Delete file list.
	 *
	 * @param fileIdList the file id list
	 * @return the application response
	 * @throws ApplicationException the application exception
	 */
	@PostMapping("/deleteFileList")
	@ApiOperation(value="Delete file",notes="Endpoint which delete files", response=ApplicationResponse.class)
	public ApplicationResponse deleteFileList(@ApiParam(value="file id list payload",required=true) @RequestBody List<Integer> fileIdList) throws ApplicationException {
		return getApplicationResponse(fileUploadService.deleteFilesByFileIdList(fileIdList));
	}

	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return FileUploadController.class;
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {
		
	}

}
