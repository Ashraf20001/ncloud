package com.recoveryportal.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.recoveryportal.config.common.base.dao.BaseDao;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.dao.NotificationDao;
import com.recoveryportal.transfer.object.notification.entity.NotificationEvent;

/**
 * The Class NotificationDaoImpl.
 */
@Repository
public class NotificationDaoImpl extends BaseDao implements NotificationDao {

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
	}

	/**
	 * Gets the notification event by event name.
	 *
	 * @param state the state
	 * @return the notification event by event name
	 */
	@Override
	public NotificationEvent getNotificationEventByEventName(String state) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<NotificationEvent> criteria = builder.createQuery(NotificationEvent.class);
		Root<NotificationEvent> root = criteria.from(NotificationEvent.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.EVENT_NAME), state)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		return (NotificationEvent) getResultList(createQuery(builder, criteria, root, predicates)).stream()
				.findFirst().orElse(null);
	}

}
