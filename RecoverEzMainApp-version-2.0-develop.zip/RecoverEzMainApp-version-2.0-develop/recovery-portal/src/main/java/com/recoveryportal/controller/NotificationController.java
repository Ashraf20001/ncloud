package com.recoveryportal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.recoveryportal.aop.annotation.Auditable;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.service.NotificationService;
import com.recoveryportal.service.ReportService;
import com.recoveryportal.transfer.object.dto.ClaimHistoryDto;
import com.recoveryportal.transfer.object.dto.NotificationCountDto;
import com.recoveryportal.transfer.object.dto.NotificationHistoryDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class NotificationController.
 */
@RestController
@Auditable
public class NotificationController {

	/** NotificationService. */
	@Autowired
	private NotificationService notificationService;
	
	/** The report service. */
	@Autowired
	private ReportService reportService;
	
	/**
	 * Gets the notification history.
	 *
	 * @return the notification history
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Claim Notification",notes="Get list of notification for specific claims",response=List.class)
	@GetMapping("/claim/notification")
	public List<NotificationHistoryDto> getNotificationHistory() throws ApplicationException {
		List<NotificationHistoryDto> response = notificationService.getAllNotifications();
		return response;
	}
	
	/**
	 * Gets the claim history by claim id.
	 *
	 * @param claimId the claim id
	 * @return the claim history by claim id
	 * @throws ApplicationException the application exception
	 * @throws ClassNotFoundException the class not found exception
	 */
	@ApiOperation(value="Claim History",notes="Get list of claim history for the claim id",response=List.class)
	@GetMapping("/claim/history")
	public List<ClaimHistoryDto> getClaimHistoryByClaimId(@ApiParam(value="Id for the claim") @RequestParam("claimId") String claimId) throws ApplicationException, ClassNotFoundException{
		List<ClaimHistoryDto> response = notificationService.getClaimHistoryForClaim(claimId);
		return response;
	}
	
	/**
	 * Gets the notification count.
	 *
	 * @return the notification count
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Notification count",notes="Get the total notification count",response=NotificationCountDto.class)
	@GetMapping("/notification/count")
	public NotificationCountDto getNotificationCount() throws ApplicationException{
		NotificationCountDto response = notificationService.getNotificationCount();
		return response;
	}
	
	/**
	 * Notification count.
	 *
	 * @param approvalId the approval id
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Notification update",notes="Update notification based on approval")
	@GetMapping("/notification/update")
	public void NotificationCount(@ApiParam(value="Approval id",required=true) @RequestParam("approvalId") Integer approvalId) throws ApplicationException{
		notificationService.updateNotification(approvalId);
	}
	
	/**
	 * Gets the upaid company name list.
	 *
	 * @param reportTime the report time
	 * @return the upaid company name list
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Unpaid company list notification",notes="Get notification of unpaid company list based on report time")
	@GetMapping(value = "/notification/report/get-unpaid-company-list")
	public List<String> getUpaidCompanyNameList(@ApiParam(value = "report time",required=true) @RequestParam(name="reportTime") Long reportTime) throws ApplicationException {
		return reportService.getUpaidCompanyNameList(reportTime);
	}
}
