package com.recoveryportal.dao;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.recoveryportal.transfer.object.entity.LoginCallCaptchaCheck;

/**
 * The Interface LoginCallCaptchaCheckRepo.
 */
public interface LoginCallCaptchaCheckRepo extends MongoRepository<LoginCallCaptchaCheck, String>{

}
