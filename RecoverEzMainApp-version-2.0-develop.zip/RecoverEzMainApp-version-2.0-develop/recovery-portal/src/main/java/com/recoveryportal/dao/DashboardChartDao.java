package com.recoveryportal.dao;

import com.recoveryportal.transfer.object.chart.*;
import com.recoveryportal.transfer.object.dto.InsuredAndTpArray;
import com.recoveryportal.transfer.object.reportloss.entity.ReportLoss;

import java.time.LocalDateTime;
import java.util.List;

/**
 * The Interface DashboardChartDao.
 */
public interface DashboardChartDao {
    
    /**
     * Gets the bar chart data.
     *
     * @param xlabel the xlabel
     * @param xvalue the xvalue
     * @param ylabel the ylabel
     * @param yvalue the yvalue
     * @param userCompanyId the user company id
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the bar chart data
     */
    List<BarChartFilterDto> getBarChartData(String xlabel, String xvalue, String ylabel, String yvalue, Integer userCompanyId, String currencyFieldName, String currencyValue);

    /**
     * Gets the pie chart data.
     *
     * @param companyId the company id
     * @param isReceivable the is receivable
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the pie chart data
     */
    List<PieChartFilterDto> getPieChartData(Integer companyId,boolean isReceivable, String currencyFieldName, String currencyValue);

    /**
     * Gets the vertical bar chart data.
     *
     * @param companyId the company id
     * @param isReceivable the is receivable
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the vertical bar chart data
     */
    List<VerticalBarChartFilterDto> getVerticalBarChartData(Integer companyId,boolean isReceivable, String currencyFieldName, String currencyValue);

    /**
     * Gets the top companies by claim amount.
     *
     * @param companyId the company id
     * @param max the max
     * @param isReceivable the is receivable
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the top companies by claim amount
     */
    List<TopCompanyDto> getTopCompaniesByClaimAmount(Integer companyId,int max,boolean isReceivable, String currencyFieldName, String currencyValue);

    /**
     * Gets the counts by days.
     *
     * @param insuredCompanyId the insured company id
     * @param topCompanies the top companies
     * @param fromDate the from date
     * @param toDate the to date
     * @param isReceivable the is receivable
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the counts by days
     */
    List<CompanyCountByDateDiffDto> getCountsByDays(Integer insuredCompanyId, List<String> topCompanies, LocalDateTime fromDate, LocalDateTime toDate,boolean isReceivable, String currencyFieldName, String currencyValue);

    /**
     * Filtered bar chart.
     *
     * @param insurenceCompanyIds the insurence company ids
     * @param tpCompanyIds the tp company ids
     * @param xlabel the xlabel
     * @param xvalue the xvalue
     * @param ylabel the ylabel
     * @param yvalue the yvalue
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the list
     */
    List<BarChartFilterDto> filteredBarChart(List<Integer> insurenceCompanyIds,List<Integer> tpCompanyIds , String xlabel, String xvalue, String ylabel, String yvalue, String currencyFieldName, String currencyValue);

	/**
	 * Gets the recent claims.
	 *
	 * @param companyId the company id
	 * @param isReceivable the is receivable
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the recent claims
	 */
	List<ReportLoss> getRecentClaims(Integer companyId, boolean isReceivable, String currencyFieldName, String currencyValue);

	/**
	 * Gets the pie chart data filter.
	 *
	 * @param isReceivable the is receivable
	 * @param filterCompany the filter company
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the pie chart data filter
	 */
	List<PieChartFilterDto> getPieChartDataFilter(Boolean isReceivable, InsuredAndTpArray filterCompany, String currencyFieldName, String currencyValue);

	/**
	 * Gets the top companies by claim amount filter.
	 *
	 * @param isReceivable the is receivable
	 * @param filterCompany the filter company
	 * @param max the max
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the top companies by claim amount filter
	 */
	List<TopCompanyDto> getTopCompaniesByClaimAmountFilter(Boolean isReceivable,InsuredAndTpArray filterCompany, int max, String currencyFieldName, String currencyValue);

	/**
	 * Gets the vertical bar chart data filter.
	 *
	 * @param isReceivable the is receivable
	 * @param filterCompany the filter company
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the vertical bar chart data filter
	 */
	List<VerticalBarChartFilterDto> getVerticalBarChartDataFilter(Boolean isReceivable,InsuredAndTpArray filterCompany, String currencyFieldName, String currencyValue);

	/**
	 * Gets the counts by days filter.
	 *
	 * @param isReceivable the is receivable
	 * @param filterCompany the filter company
	 * @param topCompanies the top companies
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the counts by days filter
	 */
	List<CompanyCountByDateDiffDto> getCountsByDaysFilter(Boolean isReceivable,InsuredAndTpArray filterCompany, List<String> topCompanies,
			LocalDateTime fromDate, LocalDateTime toDate, String currencyFieldName, String currencyValue);
}
