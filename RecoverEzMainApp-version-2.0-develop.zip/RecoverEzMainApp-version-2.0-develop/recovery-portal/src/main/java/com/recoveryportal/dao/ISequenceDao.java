package com.recoveryportal.dao;

/**
 * The Interface ISequenceDao.
 */
public interface ISequenceDao {
	
	/**
	 * Save sequence.
	 *
	 * @param obj the obj
	 * @return the int
	 */
	public int saveSequence(Object obj);

}
