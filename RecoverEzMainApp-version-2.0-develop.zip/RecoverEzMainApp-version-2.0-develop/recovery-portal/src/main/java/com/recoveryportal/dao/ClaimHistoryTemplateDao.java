package com.recoveryportal.dao;

import java.util.List;

import com.recoveryportal.transfer.object.entity.ClaimHistory;
import com.recoveryportal.transfer.object.entity.ClaimHistoryTemplate;
import com.recoveryportal.transfer.object.reportloss.entity.ReportLoss;

/**
 * The Interface ClaimHistoryTemplateDao.
 */
public interface ClaimHistoryTemplateDao {
	
	
/**
 * getClaimHistoryTemplate.
 *
 * @param state the state
 * @param stage the stage
 * @param section the section
 * @param action the action
 * @param eventId the event id
 * @return the claim history template
 */
ClaimHistoryTemplate getClaimHistoryTemplate(String state,String stage,String section,String action,Integer eventId);


/**
 * Gets the existing claim history.
 *
 * @param claim the claim
 * @param action the action
 * @return the existing claim history
 */
List<ClaimHistory> getExistingClaimHistory(ReportLoss claim,String action); 
}
