package com.recoveryportal.claimSummaryDetails.service.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.recoveryportal.claimSummaryDetails.dao.ClaimSummaryDetailsDao;
import com.recoveryportal.claimSummaryDetails.service.ClaimSummaryDetailsService;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.exception.core.codes.ErrorCodes;
import com.recoveryportal.transfer.object.claimSummaryDetails.dto.ClaimSummaryDetailsDto;
import com.recoveryportal.transfer.object.claimSummaryDetails.entity.ClaimSummaryDetails;
import com.recoveryportal.transfer.object.dto.UserInfo;
import com.recoveryportal.utils.core.ApplicationUtils;
import com.recoveryportal.utils.core.LoggedInContextHolder;

/**
 * The Class ClaimSummaryDetailsServiceImpl.
 */
@Service
@Transactional
public class ClaimSummaryDetailsServiceImpl implements ClaimSummaryDetailsService {
    
    /** The claim summary details dao. */
    @Autowired
    ClaimSummaryDetailsDao claimSummaryDetailsDao;
    
    /** The logged in context holder. */
    @Autowired
    LoggedInContextHolder loggedInContextHolder;

    /**
     * Gets the all claim summary details.
     *
     * @return the all claim summary details
     * @throws ApplicationException the application exception
     */
    @Override
    public List<ClaimSummaryDetailsDto> getAllClaimSummaryDetails() throws ApplicationException {
        List<ClaimSummaryDetails> list = claimSummaryDetailsDao.getAllClaimSummaryDetails();
        List<ClaimSummaryDetailsDto> dtoList = new ArrayList<>();
        for (ClaimSummaryDetails csd:list){
            dtoList.add(convertClaimSummaryDetailsEntityIntoDto(csd));
        }
        return dtoList;
    }

    /**
     * Gets the claim summary details by identity.
     *
     * @param identity claim summary details identity
     * @return the claim summary details by identity
     * @throws ApplicationException the application exception
     */
    @Override
    public ClaimSummaryDetailsDto getClaimSummaryDetailsByIdentity(String identity) throws ApplicationException {
        if(!ApplicationUtils.isValidString(identity.trim())){
            throw new ApplicationException(ErrorCodes.INVALID_IDENTITY);
        }
        ClaimSummaryDetails claimSummaryDetails = claimSummaryDetailsDao.getClaimSummaryDetailsByIdentity(identity);
        if (!ApplicationUtils.isValidateObject(claimSummaryDetails)){
            throw new ApplicationException(ErrorCodes.INVALID_CLAIM_SUMMARY_DETAILS);
        }
        ClaimSummaryDetailsDto claimSummaryDetailsDto = convertClaimSummaryDetailsEntityIntoDto(claimSummaryDetails);
        return claimSummaryDetailsDto;
    }

    /**
     * Save claim summary details.
     *
     * @param claimSummaryDetailsDto the claim summary details dto
     * @return the claim summary details dto
     * @throws ApplicationException the application exception
     */
    @Override
    public ClaimSummaryDetailsDto saveClaimSummaryDetails(ClaimSummaryDetailsDto claimSummaryDetailsDto) throws ApplicationException {
        if(!ApplicationUtils.isValidateObject(claimSummaryDetailsDto)){
            throw new ApplicationException(ErrorCodes.INVALID_CLAIM_SUMMARY_DETAILS);
        }
        
        UserInfo userDetails = loggedInContextHolder.getLoggedInUser();

        ClaimSummaryDetails claimSummaryDetails = convertClaimSummaryDetailsDtoIntoEntity(claimSummaryDetailsDto, new ClaimSummaryDetails());
        claimSummaryDetails.setCreatedDate(new Date());
        claimSummaryDetails.setCreatedBy(userDetails.getId());

        ClaimSummaryDetails saved = claimSummaryDetailsDao.saveClaimSummaryDetails(claimSummaryDetails);

        return convertClaimSummaryDetailsEntityIntoDto(saved);
    }

    /**
     * Update claim summary details.
     *
     * @param id the claim summary details identity
     * @param claimSummaryDetailsDto the claim summary details dto
     * @return the claim summary details dto
     * @throws ApplicationException the application exception
     */
    @Override
    public ClaimSummaryDetailsDto updateClaimSummaryDetails(String id, ClaimSummaryDetailsDto claimSummaryDetailsDto) throws ApplicationException {

        if(!ApplicationUtils.isValidateObject(claimSummaryDetailsDto)){
            throw new ApplicationException(ErrorCodes.INVALID_CLAIM_SUMMARY_DETAILS);
        }

        ClaimSummaryDetails previousData = claimSummaryDetailsDao.getClaimSummaryDetailsByIdentity(id);
        if(!ApplicationUtils.isValidateObject(previousData)){
            throw new ApplicationException(ErrorCodes.INVALID_CLAIM_SUMMARY_DETAILS);
        }

        UserInfo userDetails = loggedInContextHolder.getLoggedInUser();

        ClaimSummaryDetails claimSummaryDetails = convertClaimSummaryDetailsDtoIntoEntity(claimSummaryDetailsDto,previousData);
        if (!ApplicationUtils.isValidateObject(claimSummaryDetails)){
            throw new ApplicationException(ErrorCodes.INVALID_CLAIM_SUMMARY_DETAILS);
        }
        claimSummaryDetails.setModifiedDate(new Date());
        claimSummaryDetails.setModifiedBy(userDetails.getId());

        ClaimSummaryDetails updated = claimSummaryDetailsDao.updateClaimSummaryDetails(claimSummaryDetails);

        return convertClaimSummaryDetailsEntityIntoDto(updated);
    }

    /**
     * Delete claim summary details.
     *
     * @param identity the claim summary details identity
     * @return the string
     * @throws ApplicationException the application exception
     */
    @Override
    public String deleteClaimSummaryDetails(String identity) throws ApplicationException {
        if(!ApplicationUtils.isValidString(identity.trim())){
            throw new ApplicationException(ErrorCodes.INVALID_IDENTITY);
        }
        UserInfo userDetails = loggedInContextHolder.getLoggedInUser();

        ClaimSummaryDetails claimSummaryDetails = claimSummaryDetailsDao.getClaimSummaryDetailsByIdentity(identity);
        if (!ApplicationUtils.isValidateObject(claimSummaryDetails)){
            throw new ApplicationException(ErrorCodes.INVALID_CLAIM_SUMMARY_DETAILS);
        }
        claimSummaryDetails.setModifiedDate(new Date());
        claimSummaryDetails.setModifiedBy(userDetails.getId());
        claimSummaryDetails.setDeleted(true);

        ClaimSummaryDetails deleted = claimSummaryDetailsDao.updateClaimSummaryDetails(claimSummaryDetails);
        convertClaimSummaryDetailsEntityIntoDto(deleted);

        return deleted.isDeleted()?TableConstants.CLAIM_SUMMARY_DETAILS_DELETED
                :TableConstants.CLAIM_SUMMARY_DETAILS_DELETE_FAILED;
    }

    /**
     * Convert claim summary details dto into entity.
     *
     * @param claimSummaryDetailsDto the claim summary details dto
     * @param claimSummaryDetails the claim summary details
     * @return the claim summary details
     */
    private ClaimSummaryDetails convertClaimSummaryDetailsDtoIntoEntity(ClaimSummaryDetailsDto claimSummaryDetailsDto, ClaimSummaryDetails claimSummaryDetails) {

        claimSummaryDetails.setClaimSummaryDetailsId(claimSummaryDetailsDto.getClaimSummaryDetailsId());
        claimSummaryDetails.setNotificationStage(claimSummaryDetailsDto.getNotificationStage());
        claimSummaryDetails.setInspectionStage(claimSummaryDetailsDto.getInspectionStage());
        claimSummaryDetails.setLiabilityConfirmationStage(claimSummaryDetailsDto.getLiabilityConfirmationStage());
        claimSummaryDetails.setSettlementStage(claimSummaryDetailsDto.getSettlementStage());
        claimSummaryDetails.setTotalPayableAmount(claimSummaryDetailsDto.getTotalPayableAmount());
        claimSummaryDetails.setTotalReceivableAmount(claimSummaryDetailsDto.getTotalReceivableAmount());
        return claimSummaryDetails;
    }

    /**
     * Convert claim summary details entity into dto.
     *
     * @param csd the ClaimSummaryDetails
     * @return the claim summary details dto
     * @throws ApplicationException the application exception
     */
    private ClaimSummaryDetailsDto convertClaimSummaryDetailsEntityIntoDto(ClaimSummaryDetails csd) throws ApplicationException {
        if(!ApplicationUtils.isValidateObject(csd)){
            throw new ApplicationException(ErrorCodes.INVALID_CLAIM_SUMMARY_DETAILS);
        }
        ClaimSummaryDetailsDto claimSummaryDetailsDto = new ClaimSummaryDetailsDto();
        claimSummaryDetailsDto.setClaimSummaryDetailsId(csd.getClaimSummaryDetailsId());
        claimSummaryDetailsDto.setNotificationStage(csd.getNotificationStage());
        claimSummaryDetailsDto.setInspectionStage(csd.getInspectionStage());
        claimSummaryDetailsDto.setLiabilityConfirmationStage(csd.getLiabilityConfirmationStage());
        claimSummaryDetailsDto.setSettlementStage(csd.getSettlementStage());
        claimSummaryDetailsDto.setTotalPayableAmount(csd.getTotalPayableAmount());
        claimSummaryDetailsDto.setTotalReceivableAmount(csd.getTotalReceivableAmount());

        return claimSummaryDetailsDto;
    }
}
