package com.recoveryportal.dao;

import java.util.List;

import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.transfer.object.entity.AuthorityPayments;
import com.recoveryportal.transfer.object.entity.PaymentDetails;
import com.recoveryportal.transfer.object.entity.ReportCard;

/**
 * The Interface PaymentDetailsDao.
 */
public interface PaymentDetailsDao {
	
	/**
	 * Save.
	 *
	 * @param paymentDetails the payment details
	 * @return the payment details
	 * @throws ApplicationException the application exception
	 */
	PaymentDetails save(PaymentDetails paymentDetails) throws ApplicationException;

	/**
	 * Gets the payment details.
	 *
	 * @param toCompany the to company
	 * @param min the min
	 * @param max the max
	 * @return the payment details
	 * @throws ApplicationException the application exception
	 */
	List<PaymentDetails> getPaymentDetails(Integer toCompany, Integer min, Integer max) throws ApplicationException;

	/**
	 * Gets the payment details count.
	 *
	 * @param toCompany the to company
	 * @return the payment details count
	 */
	Long getPaymentDetailsCount(Integer toCompany);

	/**
	 * Gets the payment details for id.
	 *
	 * @param toCompany the to company
	 * @return the payment details for id
	 */
	PaymentDetails getPaymentDetailsForId(Integer toCompany);
	
	/**
	 * Gets the payment details by identity.
	 *
	 * @param company the company
	 * @return the payment details by identity
	 */
	PaymentDetails getPaymentDetailsByIdentity(String company);

    /**
     * Update payment details.
     *
     * @param paymentDetails the payment details
     * @return the payment details
     */
    PaymentDetails updatePaymentDetails(PaymentDetails paymentDetails);

    /**
     * Gets the payment details by report id.
     *
     * @param reportId the report id
     * @return the payment details by report id
     */
    List<PaymentDetails> getPaymentDetailsByReportId(Integer reportId);

    /**
     * Gets the authority payment details by report id.
     *
     * @param reportId the report id
     * @return the authority payment details by report id
     */
    List<AuthorityPayments> getAuthorityPaymentDetailsByReportId(int reportId);
	
	/**
	 * Save authority payments.
	 *
	 * @param authorityPayment the authority payment
	 * @return the authority payments
	 * @throws ApplicationException the application exception
	 */
	AuthorityPayments saveAuthorityPayments(AuthorityPayments authorityPayment) throws ApplicationException;
	
	/**
	 * Update authority payments.
	 *
	 * @param authorityPayment the authority payment
	 * @return the authority payments
	 */
	AuthorityPayments updateAuthorityPayments(AuthorityPayments authorityPayment);

}
