package com.recoveryportal.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.recoveryportal.config.common.base.dao.BaseDao;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.dao.ClaimHistoryTemplateDao;
import com.recoveryportal.statusFlow.Action;
import com.recoveryportal.transfer.object.entity.ClaimHistory;
import com.recoveryportal.transfer.object.entity.ClaimHistoryTemplate;
import com.recoveryportal.transfer.object.reportloss.entity.ReportLoss;

/**
 * The Class ClaimHistoryTemplateDaoImpl.
 */
@Repository
@Transactional
public class ClaimHistoryTemplateDaoImpl extends BaseDao implements ClaimHistoryTemplateDao
{
	
	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ClaimHistoryTemplateDaoImpl.class);
	
	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
		
	}

	/**
	 * getClaimHistoryTemplate.
	 *
	 * @param state the state
	 * @param stage the stage
	 * @param section the section
	 * @param action the action
	 * @param eventId the event id
	 * @return the claim history template
	 */
	@Override
	public ClaimHistoryTemplate getClaimHistoryTemplate(String state,String stage, String section,String action, Integer eventId) {
		logger.info("========> Claim History :"+ "State = " + state + " Stage = " + stage + " Section = " + section);
	CriteriaBuilder builder = getCriteriaBuilder();
    CriteriaQuery<ClaimHistoryTemplate> criteria = builder.createQuery(ClaimHistoryTemplate.class);
    Root<ClaimHistoryTemplate> root = criteria.from(ClaimHistoryTemplate.class);
    criteria.select(root);
    List<Predicate> predicates = new ArrayList<>();

    predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
    if(action.equals(Action.SUBMIT.toString())) {
        predicates.add(builder.and(builder.equal(root.get(TableConstants.TEMPLATE_SECTION),section)));
	    predicates.add(builder.and(builder.equal(root.get(TableConstants.STAGE),stage)));
    }
    predicates.add(builder.and(builder.equal(root.get(TableConstants.STATE),state)));
    predicates.add(builder.and(builder.equal(root.get(TableConstants.NOTIFICATION_EVENT).get(TableConstants.EVENTID),eventId)));
    return (ClaimHistoryTemplate) getSingleResult(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * GET EXISTING CLAIM HISTORY.
	 *
	 * @param claim the claim
	 * @param action the action
	 * @return the existing claim history
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<ClaimHistory> getExistingClaimHistory(ReportLoss claim,String action) {
		CriteriaBuilder builder = getCriteriaBuilder();
	    CriteriaQuery<ClaimHistory> criteria = builder.createQuery(ClaimHistory.class);
	    Root<ClaimHistory> root = criteria.from(ClaimHistory.class);
	    criteria.select(root);
	    List<Predicate> predicates = new ArrayList<>();
	    predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
	    if(action.equals(Action.SUBMIT.toString())) {
	        predicates.add(builder.and(builder.equal(root.get(TableConstants.SECTION_NAME),claim.getSectionName())));
		    predicates.add(builder.and(builder.equal(root.get(TableConstants.STAGE_NAME),claim.getStageName())));
		    predicates.add(builder.and(builder.isTrue(root.get(TableConstants.ACTION))));
	    }else {
	    	predicates.add(builder.and(builder.equal(root.get(TableConstants.STATE),claim.getState())));
	    }
	    predicates.add(builder.and(builder.equal(root.get(TableConstants.CLAIMID).get(TableConstants.CLAIMID),claim.getClaimId())));
	    return (List<ClaimHistory>) getResultList(createQuery(builder, criteria, root, predicates));
	} 

}
