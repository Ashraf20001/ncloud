package com.recoveryportal.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.recoveryportal.config.common.base.dao.BaseDao;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.dao.IDropDownListOptionMapDAO;
import com.recoveryportal.transfer.object.entity.DropDownListOptionMapping;
import com.recoveryportal.utils.core.ApplicationUtils;

/**
 * The Class DropDownListOptionMapDAOImpl.
 */
@Repository
@Transactional
public class DropDownListOptionMapDAOImpl extends BaseDao implements IDropDownListOptionMapDAO {

	/**
	 * Gets the drop down options list by drop down id.
	 *
	 * @param dropdownId the dropdown id
	 * @param parentOptionId the parent option id
	 * @return the drop down options list by drop down id
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<DropDownListOptionMapping> getDropDownOptionsListByDropDownId(Integer dropdownId, Integer parentOptionId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<DropDownListOptionMapping> criteria = builder.createQuery(DropDownListOptionMapping.class);
		Root<DropDownListOptionMapping> root = criteria.from(DropDownListOptionMapping.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.DROPDOWNLISTID).get(TableConstants.DROPDOWNLIST_ID), dropdownId)));
		if(ApplicationUtils.isValidId(parentOptionId)) {
			predicates.add(builder.and(builder.equal(root.get(TableConstants.DROPDOWN_OPTIONS).get(TableConstants.DROPDOWN_OPTIONS_PARENT_ID), parentOptionId)));
		}
		return (List<DropDownListOptionMapping>) getResultList(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
	}

}
