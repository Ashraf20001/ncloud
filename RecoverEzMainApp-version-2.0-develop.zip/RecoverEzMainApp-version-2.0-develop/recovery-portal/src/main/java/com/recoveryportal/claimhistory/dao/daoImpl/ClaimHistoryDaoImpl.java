package com.recoveryportal.claimhistory.dao.daoImpl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Subquery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.recoveryportal.claimhistory.dao.ClaimHistoryDao;
import com.recoveryportal.config.common.base.dao.BaseDao;
import com.recoveryportal.constants.core.ApplicationConstants;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.security.jwt.RecoveryCache;
import com.recoveryportal.transfer.object.constants.BasePredicateEntityColumnMap;
import com.recoveryportal.transfer.object.dto.InsuredAndTpArray;
import com.recoveryportal.transfer.object.entity.ClaimHistory;
import com.recoveryportal.transfer.object.reportloss.entity.ReportLoss;

/**
 * The Class ClaimHistoryDaoImpl.
 */
@Repository
@Transactional
public class ClaimHistoryDaoImpl extends BaseDao implements ClaimHistoryDao {

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
		
	}

	/**
	 * Save claim history details.
	 *
	 * @param claimHistory the claim history
	 * @return the claim history
	 * @throws ApplicationException the application exception
	 */
	@Override
	public ClaimHistory saveClaimHistoryDetails(ClaimHistory claimHistory) throws ApplicationException {
		save(claimHistory, TableConstants.CLAIM_HISTORY);
		return claimHistory;
	}

	/**
	 * Gets the claim history by claim id.
	 *
	 * @param claimId the claim id
	 * @return the claim history by claim id
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<ClaimHistory> getClaimHistoryByClaimId(Integer claimId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<ClaimHistory> criteria = builder.createQuery(ClaimHistory.class);
		Root<ClaimHistory> root = criteria.from(ClaimHistory.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(
				builder.and(builder.equal(root.get(TableConstants.CLAIM_ID).get(TableConstants.CLAIM_ID), claimId)));
		criteria.orderBy(builder.asc(root.get(TableConstants.CREATED_DATE)));
		return (List<ClaimHistory>) getResultList(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Gets the recent claim history.
	 *
	 * @param hasAssociationPrivilege is association privilege
	 * @param isReceivable is receivable
	 * @param filterCompany the filter company
	 * @param companyName the company name
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the recent claim history
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<ClaimHistory> getRecentClaimHistory(boolean hasAssociationPrivilege, boolean isReceivable, 
			InsuredAndTpArray filterCompany, String companyName, String currencyFieldName, String currencyValue) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<ClaimHistory> criteriaQuery = builder.createQuery(ClaimHistory.class);
		Root<ClaimHistory> root = criteriaQuery.from(ClaimHistory.class);
		criteriaQuery.select(root);

		Subquery<Long> subQuery = criteriaQuery.subquery(Long.class);
		Root<ClaimHistory> subRoot = subQuery.from(ClaimHistory.class);
		subQuery.select(builder.max(subRoot.get(TableConstants.ID)));
		subQuery.groupBy(subRoot.get(TableConstants.CLAIMID));

		List<Predicate> predicates = new ArrayList<>();
		predicates.add(root.get(TableConstants.ID).in(subQuery));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));

		Expression<Integer> insuranceExpression = root.get(TableConstants.CLAIM_ID).get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY);
		Expression<Integer> tpExpression = root.get(TableConstants.CLAIM_ID).get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY);

		String joinColumn=null;
		if (hasAssociationPrivilege){
			Predicate insurancePredicate,tpPredicate;
			List<Integer> idList = filterCompany.getInsurenceCompanyNames().stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
			List<Integer> tpIdList = filterCompany.getTpCompanyNames().stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
			if(isReceivable){
				insurancePredicate = insuranceExpression.in(idList);
				tpPredicate = tpExpression.in(tpIdList);
				if(filterCompany.getInsurenceCompanyNames().size()>0) {
					predicates.add(insurancePredicate);
				}
				if(filterCompany.getTpCompanyNames().size()>0) {
					predicates.add(tpPredicate);
				}
			} else {
				insurancePredicate = insuranceExpression.in(tpIdList);
				tpPredicate = tpExpression.in(idList);
				if(filterCompany.getInsurenceCompanyNames().size()>0) {
					predicates.add(tpPredicate);
				}
				if(filterCompany.getTpCompanyNames().size()>0) {
					predicates.add(insurancePredicate);
				}
			}
		} else {
			if (isReceivable){
				joinColumn=BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(ApplicationConstants.RECEIVABLE_CLAIM);
			}else{
				joinColumn=BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(ApplicationConstants.PAYABLE_CLAIM);
			}
		}
		if(currencyFieldName != null && currencyValue != null) {
			predicates.add(builder.equal(root.get(TableConstants.CLAIM_ID).get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue));
		}

		criteriaQuery.orderBy(builder.desc(root.get(TableConstants.ID)));
		
		return (List<ClaimHistory>) getResultList(
				getBasePredicateResult(builder, criteriaQuery, root, joinColumn, predicates).setMaxResults(ApplicationConstants.TEN));
	}

	/**
	 * Gets the claim history by claim id and state.
	 *
	 * @param claimId the claim id
	 * @param state the claim state
	 * @return the claim history by claim id and claim state
	 */
	@Override
	public ClaimHistory getClaimHistoryByClaimIdAndState(Integer claimId, String state) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<ClaimHistory> criteria = builder.createQuery(ClaimHistory.class);
		Root<ClaimHistory> root = criteria.from(ClaimHistory.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.CLAIM_ID).get(TableConstants.CLAIM_ID), claimId)));
		criteria.orderBy(builder.desc(root.get(TableConstants.ID)));
		return (ClaimHistory) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);
	}

	/**
	 * Gets the recently created claim history.
	 *
	 * @param claim the claim
	 * @return the recently created claim history
	 */
	@Override
	public ClaimHistory getRecentlyCreatedClaimHistory(ReportLoss claim) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<ClaimHistory> criteria = builder.createQuery(ClaimHistory.class);
		Root<ClaimHistory> root = criteria.from(ClaimHistory.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		predicates.add(builder.and(builder.isNotNull(root.get(TableConstants.COMMENT_ID))));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.CLAIM_ID).get(TableConstants.CLAIM_ID), claim.getClaimId())));
		criteria.orderBy(builder.desc(root.get(TableConstants.ID)));
		return (ClaimHistory) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst()
				.orElse(null);
	}
	
	/**
	 * 	Get RecentlyCreated ClaimHistory Template.
	 *
	 * @param claim the claim
	 * @return the recently created claim history template
	 */
	@Override
	public ClaimHistory getRecentlyCreatedClaimHistoryTemplate(ReportLoss claim) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<ClaimHistory> criteria = builder.createQuery(ClaimHistory.class);
		Root<ClaimHistory> root = criteria.from(ClaimHistory.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		predicates.add(builder.and(builder.isNotNull(root.get(TableConstants.STATE))));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.CLAIM_ID).get(TableConstants.CLAIM_ID), claim.getClaimId())));
		criteria.orderBy(builder.desc(root.get(TableConstants.ID)));
		return (ClaimHistory) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst()
				.orElse(null);
	}

	/**
	 * 	Update ClaimHistory.
	 *
	 * @param claimHistory the claim history
	 */
	@Override
	public void updateClaimHistory(ClaimHistory claimHistory) {
		 update(claimHistory);
	}

	/**
	 * Check claim history by template.
	 *
	 * @param claimHistory the claim history
	 * @return the long
	 */
	@Override
	public Long checkClaimHistoryByTemplate(ClaimHistory claimHistory) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<ClaimHistory> root = criteria.from(ClaimHistory.class);
		criteria.select(builder.count(root));
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.CLAIM_ID).get(TableConstants.CLAIM_ID), claimHistory.getClaimId().getClaimId())));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.CONTENT), claimHistory.getContent())));	
		return (Long) getSingleResult(createQuery(builder, criteria, root, predicates));
	}
}
