package com.recoveryportal.dao.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.recoveryportal.config.common.base.dao.BaseDao;
import com.recoveryportal.constants.core.ApplicationConstants;
import com.recoveryportal.constants.core.RecoveryStatusConstant;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.dao.DashboardChartDao;
import com.recoveryportal.security.jwt.RecoveryCache;
import com.recoveryportal.transfer.object.chart.BarChartFilterDto;
import com.recoveryportal.transfer.object.chart.CompanyCountByDateDiffDto;
import com.recoveryportal.transfer.object.chart.PieChartFilterDto;
import com.recoveryportal.transfer.object.chart.TopCompanyDto;
import com.recoveryportal.transfer.object.chart.VerticalBarChartFilterDto;
import com.recoveryportal.transfer.object.constants.BasePredicateEntityColumnMap;
import com.recoveryportal.transfer.object.dto.CompanyDto;
import com.recoveryportal.transfer.object.dto.InsuredAndTpArray;
import com.recoveryportal.transfer.object.reportloss.entity.InsuredInfo;
import com.recoveryportal.transfer.object.reportloss.entity.ReportLoss;
import com.recoveryportal.transfer.object.reportloss.entity.ThirdPartyInfo;
import com.recoveryportal.utils.core.ApplicationUtils;

/**
 * The Class DashboardChartDaoImpl.
 */
@Repository
@Transactional
public class DashboardChartDaoImpl extends BaseDao implements DashboardChartDao {
	
    /**
     * Gets the bar chart data.
     *
     * @param xlabel the xlabel
     * @param xvalue the xvalue
     * @param ylabel the ylabel
     * @param yvalue the yvalue
     * @param userCompanyId the user company id
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the bar chart data
     */
    @Override
    public List<BarChartFilterDto> getBarChartData(String xlabel, String xvalue, String ylabel, String yvalue, Integer userCompanyId, String currencyFieldName, String currencyValue) {

        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<BarChartFilterDto> criteria = builder.createQuery(BarChartFilterDto.class);
        Root<ReportLoss> root = criteria.from(ReportLoss.class);
        Expression<String> countExpression1;
        Expression<Long> countExpression2 = null;
        Expression<Long> countExpression3 = null;

        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
        if(currencyFieldName != null && currencyValue != null) {
        	predicates.add(builder.and(builder.equal(root.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue)));
        }
		Expression notDraftStateExpression = builder.notEqual(root.get(TableConstants.STATE),RecoveryStatusConstant.DRAFT);
//      x-axis
        if(xvalue.equals("%b")){
            countExpression1 = builder.function("DATE_FORMAT",
                    String.class,root.get(TableConstants.CREATED_DATE), builder.literal("%b"));
        }else {
            countExpression1 = builder.function("DATE_FORMAT",
                    String.class, root.get(TableConstants.CREATED_DATE), builder.literal(xvalue));
        }
//      y-axis for count
        if (ylabel.equals(TableConstants.CHART_COUNT)){
            countExpression2 = builder.count(builder.selectCase()
                    .when(builder.equal(root.get(TableConstants.INSURED_INFO)
                            .get(TableConstants.RL_II_INSURER_COMPANY), userCompanyId), 1));
            countExpression3 = builder.count(builder.selectCase()
                    .when(builder.and(builder.equal(root.get(TableConstants.THIRD_PARTY_INFO)
							.get(TableConstants.RL_TPI_TP_COMPANY),userCompanyId),notDraftStateExpression),1));
        } else if (ylabel.equals(TableConstants.CHART_AMOUNT)){
            countExpression2 = builder.sumAsLong(builder.<Integer>selectCase()
                    .when(builder.equal(root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY), userCompanyId),
                            root.get(TableConstants.RECOVERY_DETAILS).get(TableConstants.CLAIM_AMOUNT)));
            countExpression3 = builder.sumAsLong(builder.<Integer>selectCase()
                    .when(builder.and(builder.equal(root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY),userCompanyId),notDraftStateExpression),
                            root.get(TableConstants.RECOVERY_DETAILS).get(TableConstants.CLAIM_AMOUNT)));
        }
        
        criteria.multiselect(countExpression1,countExpression2,countExpression3);
        criteria.groupBy(countExpression1);
		if(xvalue.equals("%b")){
			criteria.orderBy(builder.asc(
					builder.function("DATE_FORMAT", String.class,
							root.get(TableConstants.CREATED_DATE), builder.literal("%m"))));
		}

        return (List<BarChartFilterDto>)getResultList(createQuery(builder, criteria, root, predicates).setFirstResult(0).setMaxResults(TableConstants.MAX_DATA_LIMIT_FOR_BAR_CHART));
    }

    /**
     * Gets the pie chart data.
     *
     * @param companyId the company id
     * @param isReceivable the is receivable
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the pie chart data
     */
    @SuppressWarnings("unchecked")
	@Override
    public List<PieChartFilterDto> getPieChartData(Integer companyId,boolean isReceivable, String currencyFieldName, String currencyValue) {
    	CriteriaBuilder builder = getCriteriaBuilder();
    	CriteriaQuery<PieChartFilterDto[]> criteriaQuery = builder.createQuery(PieChartFilterDto[].class);

    	Root<ReportLoss> reportLossRoot = criteriaQuery.from(ReportLoss.class);
    	Join<ReportLoss, InsuredInfo> insuredInfoJoin = reportLossRoot.join("insuredInfo");
    	Join<ReportLoss, ThirdPartyInfo> thirdPartyInfoJoin = reportLossRoot.join("thirdPartyInfo");

    	criteriaQuery.multiselect(
    		builder.count(reportLossRoot),
    	    builder.selectCase()
    	        .when(reportLossRoot.get("state").in(RecoveryStatusConstant.TOTALLOSS_ACCEPTED, RecoveryStatusConstant.TOTALLOSS_INITITED), "Total Loss Claims")
    	        .otherwise(reportLossRoot.get("state"))
    	        .alias("group_status")
    	);
    	List<Predicate> predicates = new ArrayList<>();
    	Predicate statePredicate = reportLossRoot.get("state").in(
    	    RecoveryStatusConstant.NOTIFICATION_OPEN,
    	    RecoveryStatusConstant.GS_DETAILS_UPDATED,
    	    RecoveryStatusConstant.EXPENSES_AND_DOCUMENT_UPDATED,
    	    RecoveryStatusConstant.LIABLITY_REVIEW,
    	    RecoveryStatusConstant.TOTALLOSS_ACCEPTED,
    	    RecoveryStatusConstant.TOTALLOSS_INITITED,
    	    RecoveryStatusConstant.CONFIRM_LIABLITY,
    	    RecoveryStatusConstant.CLAIM_SETTLED,
    	    RecoveryStatusConstant.PAID,
    	    RecoveryStatusConstant.KNOCKTOKNOCK
    	);
    	predicates.add(statePredicate);
    	predicates.add(builder.equal(reportLossRoot.get("isDeleted"), false));
    	Predicate companyNamePredicate;
    	String joinColumn=null;
    	if (isReceivable) {
    	    joinColumn=BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(ApplicationConstants.RECEIVABLE);
    	} else {
    	    joinColumn=BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(ApplicationConstants.PAYABLE);
    	    predicates.add(builder.notEqual(reportLossRoot.get("state"), RecoveryStatusConstant.DRAFT));
    	}
    	if(currencyFieldName != null && currencyValue != null) {
        	predicates.add(builder.and(builder.equal(reportLossRoot.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue)));
        }
    	criteriaQuery.groupBy(reportLossRoot.get("state"));

		List<PieChartFilterDto> results = (List<PieChartFilterDto>)getResultList(getBasePredicateResult(builder, criteriaQuery, reportLossRoot, joinColumn, predicates));
        return results;
    }

    /**
     * Gets the vertical bar chart data.
     *
     * @param companyId the company id
     * @param isReceivable the is receivable
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the vertical bar chart data
     */
    @Override
    public List<VerticalBarChartFilterDto> getVerticalBarChartData(Integer companyId,boolean isReceivable, String currencyFieldName, String currencyValue) {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<VerticalBarChartFilterDto> criteria = builder.createQuery(VerticalBarChartFilterDto.class);
        Root<ReportLoss> root = criteria.from(ReportLoss.class);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
        String joinColumn=null;
        if(isReceivable) {
        	joinColumn= BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(ApplicationConstants.RECEIVABLE);
        }else {
        	joinColumn= BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(ApplicationConstants.PAYABLE);
        }
        predicates.add(builder.and(builder.notEqual(root.get(TableConstants.STATE), RecoveryStatusConstant.CLAIM_SETTLED)));
        predicates.add(builder.and(builder.notEqual(root.get(TableConstants.STATE), RecoveryStatusConstant.KNOCKTOKNOCK)));
        predicates.add(builder.and(builder.notEqual(root.get(TableConstants.STATE), RecoveryStatusConstant.PAID)));
        if(currencyFieldName != null && currencyValue != null) {
        	predicates.add(builder.and(builder.equal(root.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue)));
        }
        Expression<Long> daysDiff = builder.function("DATEDIFF", Long.class,
                builder.currentDate(), root.get(TableConstants.CREATED_DATE));
        Expression<Double> recoveryAmount = builder.sum(root.get(TableConstants.RECOVERY_DETAILS).get(TableConstants.CLAIM_AMOUNT));
        criteria.multiselect(recoveryAmount,daysDiff);
        criteria.groupBy(daysDiff);
        criteria.orderBy(builder.asc(daysDiff));

        return (List<VerticalBarChartFilterDto>)getResultList(getBasePredicateResult(builder, criteria, root, joinColumn, predicates).setFirstResult(0).setMaxResults(TableConstants.MAX_DATA_LIMIT_FOR_VERTICAL_BAR_CHART));
    }


    /**
     * Gets the top companies by claim amount.
     *
     * @param companyId the company id
     * @param max the max
     * @param isReceivable the is receivable
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the top companies by claim amount
     */
    @Override
    public List<TopCompanyDto> getTopCompaniesByClaimAmount(Integer companyId,int max,boolean isReceivable, String currencyFieldName, String currencyValue) {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<Object[]> criteria = builder.createQuery(Object[].class);
        Root<ReportLoss> root = criteria.from(ReportLoss.class);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
        if(currencyFieldName != null && currencyValue != null) {
        	predicates.add(builder.and(builder.equal(root.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue)));
        }
        String joinColumn=null;
        if(isReceivable) {
        joinColumn= BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(ApplicationConstants.RECEIVABLE);
        predicates.add(builder.and(builder.notEqual(root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY),companyId)));
        criteria.multiselect(
        		root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY),
                builder.sum(root.get(TableConstants.RECOVERY_DETAILS).get(TableConstants.CLAIM_AMOUNT)),
                builder.count(root));
        criteria.groupBy(root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY));
        }else {
            predicates.add(builder.and(builder.notEqual(root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY),companyId)));
            joinColumn= BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(ApplicationConstants.PAYABLE);
             criteria.multiselect(
            		 root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY),
                     builder.sum(root.get(TableConstants.RECOVERY_DETAILS).get(TableConstants.CLAIM_AMOUNT)),
                     builder.count(root));
             criteria.groupBy(root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY));
        }
        criteria.orderBy(builder.desc(builder.sum(root.get(TableConstants.RECOVERY_DETAILS).get(TableConstants.CLAIM_AMOUNT))));
        
        List<Object[]> result = (List<Object[]>)getResultList(getBasePredicateResult(builder, criteria, root, joinColumn, predicates).setFirstResult(0).setMaxResults(max));
       
        return	result.parallelStream().map(el->{
        		TopCompanyDto topCompanyDto = new TopCompanyDto();
        		CompanyDto companyFromCompanyId = RecoveryCache.getCompanyIdDtoMap().get((Integer) el[0]);
        		if(companyFromCompanyId!=null) {
        			topCompanyDto.setCompanyName(companyFromCompanyId.getName());
        			topCompanyDto.setShortName(companyFromCompanyId.getShortName());
        			topCompanyDto.setTotalClaimAmount((Double)el[1]);
        			topCompanyDto.setTotalClaimCount((Long)el[2]);
        		}
        		return topCompanyDto;
        	}).toList();
        
    }

    /**
     * Gets the counts by days.
     *
     * @param insuredCompanyId the insured company id
     * @param topCompanies the top companies
     * @param fromDate the from date
     * @param toDate the to date
     * @param isReceivable the is receivable
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the counts by days
     */
    @Override
    public List<CompanyCountByDateDiffDto> getCountsByDays(Integer insuredCompanyId, List<String> topCompanies, LocalDateTime fromDate, LocalDateTime toDate,boolean isReceivable, String currencyFieldName, String currencyValue) {

        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<Object[]> criteria = builder.createQuery(Object[].class);
        Root<ReportLoss> root = criteria.from(ReportLoss.class);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
        List<Integer> idList = topCompanies.stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
        if(isReceivable) {
        predicates.add(builder.and(builder.equal(root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY),insuredCompanyId)));
        if(currencyFieldName != null && currencyValue != null) {
        	predicates.add(builder.and(builder.equal(root.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue)));
        }
        predicates.add(builder.and(builder.greaterThanOrEqualTo(root.get(TableConstants.MODIFIED_DATE),fromDate)));
        predicates.add(builder.and(builder.lessThanOrEqualTo(root.get(TableConstants.MODIFIED_DATE),toDate)));

        Expression<Integer> parentExpression = root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY);
        Predicate parentPredicate = parentExpression.in(idList);
        predicates.add(builder.and(parentPredicate));
        criteria.multiselect(root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY),
				builder.count(root));
        criteria.groupBy(root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY));
        }else {
        	  predicates.add(builder.and(builder.equal(root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY),insuredCompanyId)));
              predicates.add(builder.and(builder.greaterThanOrEqualTo(root.get(TableConstants.MODIFIED_DATE),fromDate)));
              predicates.add(builder.and(builder.lessThanOrEqualTo(root.get(TableConstants.MODIFIED_DATE),toDate)));
              Expression<Integer> parentExpression = root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY);
              Predicate parentPredicate = parentExpression.in(idList);
              predicates.add(builder.and(parentPredicate));
              criteria.multiselect(root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY),
					  builder.count(root));
              criteria.groupBy(root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY));
        }
        List<Object[]> res =(List<Object[]>) getResultList(createQuery(builder, criteria, root, predicates).setFirstResult(0).setMaxResults(TableConstants.MAX_DATA_LIMIT_FOR_STACKED_BAR_CHART));
        return res.stream().map(el->{
        	CompanyCountByDateDiffDto companyCountByDateDiffDto = new CompanyCountByDateDiffDto();
        	companyCountByDateDiffDto.setCompany(RecoveryCache.getCompanyList().get((Integer)el[0]));
        	companyCountByDateDiffDto.setCount((Long) el[1]);
        	return companyCountByDateDiffDto;
        }).toList();
        
    }
    
	/**
	 * Gets the recent claims.
	 *
	 * @param companyId the company id
	 * @param isReceivable the is receivable
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the recent claims
	 */
	@Override
	public List<ReportLoss> getRecentClaims(Integer companyId,boolean isReceivable, String currencyFieldName, String currencyValue){
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<ReportLoss> query = builder.createQuery(ReportLoss.class);
		Root<ReportLoss> root = query.from(ReportLoss.class);
		query.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), 0)));
		if(currencyFieldName != null && currencyValue != null) {
        	predicates.add(builder.and(builder.equal(root.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue)));
        }
		   if(ApplicationUtils.isValidId(companyId)) {
		   if(isReceivable) {
	        predicates.add(builder.and(builder.notEqual(root.get(TableConstants.INSURED_INFO)
					.get(TableConstants.RL_II_INSURER_COMPANY), companyId)));
		   }else {
	        predicates.add(builder.and(builder.notEqual(root.get(TableConstants.THIRD_PARTY_INFO)
					.get(TableConstants.RL_TPI_TP_COMPANY), companyId)));
		   }
		   }
		query.orderBy(builder.desc(root.get(TableConstants.MODIFIED_DATE)));
		List<ReportLoss> rep= (List<ReportLoss>) getResultList(createQuery(builder, query, root, predicates).setMaxResults(5));
		return rep;
		
	}

    /**
     * Register data filters.
     */
    @Override
    public void registerDataFilters() {

    }

	/**
	 * Filtered bar chart.
	 *
	 * @param insurenceCompanyIds the insurence company ids
	 * @param tpCompanyIds the tp company ids
	 * @param xlabel the xlabel
	 * @param xvalue the xvalue
	 * @param ylabel the ylabel
	 * @param yvalue the yvalue
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the list
	 */
	@Override
	public List<BarChartFilterDto> filteredBarChart(List<Integer> insurenceCompanyIds,List<Integer> tpCompanyIds, String xlabel, String xvalue,
			String ylabel, String yvalue, String currencyFieldName, String currencyValue) {
		    CriteriaBuilder builder = getCriteriaBuilder();
	        CriteriaQuery<BarChartFilterDto> criteria = builder.createQuery(BarChartFilterDto.class);
	        Root<ReportLoss> root = criteria.from(ReportLoss.class);
	        Expression<String> countExpression1;
	        Expression<Long> countExpression2 = null;
	        Expression<Long> countExpression3 = null;

	        List<Predicate> predicates = new ArrayList<>();
	        predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
	        Predicate currencyPredicate;
	        if(currencyFieldName != null && currencyValue != null) {
	        	currencyPredicate = builder.equal(root.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue);
	        } else {
	        	currencyPredicate = builder.conjunction();
	        }
		Expression<Boolean> notDraftStateExpression = builder.notEqual(root.get(TableConstants.STATE),RecoveryStatusConstant.DRAFT);
//	      x-axis
	        if(xvalue.equals("%b")){
	            countExpression1 = builder.function("DATE_FORMAT",
	                    String.class,root.get(TableConstants.CREATED_DATE), builder.literal("%b"));
	        }else {
	            countExpression1 = builder.function("DATE_FORMAT",
	                    String.class, root.get(TableConstants.CREATED_DATE), builder.literal(xvalue));
	        }
//	      y-axis for count
	        Expression<Integer> tpExpression = root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY);
			Predicate tpPredicate = tpExpression.in(tpCompanyIds);
			
			Expression<Integer> insuranceExpression = root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY);
			Predicate insurancePredicate = insuranceExpression.in(insurenceCompanyIds);
			boolean isInsNamesEmpty = false, isTpNamesEmpty = false;
	        if (ylabel.equals(TableConstants.CHART_COUNT)){
					if (insurenceCompanyIds !=null && insurenceCompanyIds.size()>0){
						isInsNamesEmpty = false;
						countExpression2 = builder.count(builder.selectCase()
								.when(builder.and(insurancePredicate, currencyPredicate), 1));
					} else {
						countExpression2 = builder.count(insuranceExpression);
						isInsNamesEmpty = true;
					}
	            	if (tpCompanyIds!=null && tpCompanyIds.size()>0){
	            		isTpNamesEmpty = false;
						countExpression3 = builder.count(builder.selectCase()
								.when(builder.and(builder.and(tpPredicate,notDraftStateExpression), currencyPredicate),1));
					}else{
						countExpression3 = builder.count(tpExpression);
						isTpNamesEmpty = true;
					}
	        } else if (ylabel.equals(TableConstants.CHART_AMOUNT)){
	        	if(insurenceCompanyIds.isEmpty() && tpCompanyIds.isEmpty()) {
	        		  countExpression2 = builder.sumAsLong( root.get(TableConstants.RECOVERY_DETAILS).get(TableConstants.CLAIM_AMOUNT));
	  	            countExpression3 = builder.sumAsLong( root.get(TableConstants.RECOVERY_DETAILS).get(TableConstants.CLAIM_AMOUNT));
	        		
	        	}else {
	            countExpression2 = builder.sumAsLong(builder.<Integer>selectCase()
	                    .when(builder.equal(root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY),insurenceCompanyIds),
	                            root.get(TableConstants.RECOVERY_DETAILS).get(TableConstants.CLAIM_AMOUNT)));
	            countExpression3 = builder.sumAsLong(builder.<Integer>selectCase()
	                    .when(builder.and(builder.equal(root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY),tpCompanyIds),notDraftStateExpression),
	                            root.get(TableConstants.RECOVERY_DETAILS).get(TableConstants.CLAIM_AMOUNT)));
	        	}
	        }
	        if(isInsNamesEmpty || isTpNamesEmpty) {
	        	predicates.add(builder.and(currencyPredicate));
	        }
	        criteria.multiselect(countExpression1,countExpression2,countExpression3);
	        criteria.groupBy(countExpression1);
			criteria.orderBy(builder.asc(countExpression1));
			if(xvalue.equals("%b")){
				criteria.orderBy(builder.asc(
						builder.function("DATE_FORMAT", String.class,
								root.get(TableConstants.CREATED_DATE), builder.literal("%m"))));
			}
			
	        return (List<BarChartFilterDto>)getResultList(createQuery(builder, criteria, root, predicates).setFirstResult(0).setMaxResults(TableConstants.MAX_DATA_LIMIT_FOR_BAR_CHART));

	}
	
	/**
	 * Gets the pie chart data filter.
	 *
	 * @param isReceivable the is receivable
	 * @param filterCompany the filter company
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the pie chart data filter
	 */	
	@SuppressWarnings("unchecked")
	@Override
	 public List<PieChartFilterDto> getPieChartDataFilter(Boolean isReceivable, InsuredAndTpArray filterCompany, String currencyFieldName, String currencyValue) {
			CriteriaBuilder builder = getCriteriaBuilder();
			CriteriaQuery<PieChartFilterDto[]> query = builder.createQuery(PieChartFilterDto[].class);

			Root<ReportLoss> reportLossRoot = query.from(ReportLoss.class);
			Join<ReportLoss, InsuredInfo> insuredInfoJoin = reportLossRoot.join("insuredInfo");
			Join<ReportLoss, ThirdPartyInfo> thirdPartyInfoJoin = reportLossRoot.join("thirdPartyInfo");

			List<Predicate> predicates = new ArrayList<>();
			Predicate statePredicate = reportLossRoot.get("state").in(
			    RecoveryStatusConstant.NOTIFICATION_OPEN,
			    RecoveryStatusConstant.GS_DETAILS_UPDATED,
			    RecoveryStatusConstant.EXPENSES_AND_DOCUMENT_UPDATED,
			    RecoveryStatusConstant.LIABLITY_REVIEW,
			    RecoveryStatusConstant.TOTALLOSS_ACCEPTED,
			    RecoveryStatusConstant.TOTALLOSS_INITITED,
			    RecoveryStatusConstant.KNOCKTOKNOCK,
			    RecoveryStatusConstant.PAID,
			    RecoveryStatusConstant.CONFIRM_LIABLITY,
			    RecoveryStatusConstant.CLAIM_SETTLED
			);
			predicates.add(statePredicate);
			predicates.add(builder.equal(reportLossRoot.get("isDeleted"), false));

			List<Integer> insuredInfoCompanyIds = !filterCompany.getInsurenceCompanyNames().isEmpty() ? filterCompany.getInsurenceCompanyNames().stream().map(el->RecoveryCache.getCompanyNameIdMap().get(el)).toList()
					: new ArrayList<>();
			List<Integer> tpCompanyIds = !filterCompany.getTpCompanyNames().isEmpty() ? filterCompany.getTpCompanyNames().stream().map(el->RecoveryCache.getCompanyNameIdMap().get(el)).toList():
				new ArrayList<>();
			Predicate companyNamePredicate;
			if (isReceivable) {
			    if (!filterCompany.getInsurenceCompanyNames().isEmpty()) {
			        companyNamePredicate = insuredInfoJoin.get("insurerCompany").in(insuredInfoCompanyIds);
			    } else {
			        companyNamePredicate = builder.conjunction(); // True condition if no filter
			    }
			    predicates.add(companyNamePredicate);
			    Predicate tpCompanyPredicate;
			    if (!filterCompany.getTpCompanyNames().isEmpty()) {
			        tpCompanyPredicate = thirdPartyInfoJoin.get("tpCompany").in(tpCompanyIds);
			    } else {
			        tpCompanyPredicate = builder.conjunction(); // True condition if no filter
			    }
			    predicates.add(tpCompanyPredicate);
			    predicates.add(builder.notEqual(reportLossRoot.get("state"), RecoveryStatusConstant.DRAFT));

			    query.multiselect(
			        builder.count(reportLossRoot),
			        builder.selectCase()
			            .when(reportLossRoot.get("state").in(RecoveryStatusConstant.TOTALLOSS_ACCEPTED, RecoveryStatusConstant.TOTALLOSS_INITITED), "Total Loss Claims")
			            .otherwise(reportLossRoot.get("state"))
			            .alias("group_status")
			    );
			} else {
			    if (!filterCompany.getTpCompanyNames().isEmpty()) {
			    	companyNamePredicate = insuredInfoJoin.get("insurerCompany").in(tpCompanyIds);
			    } else {
			        companyNamePredicate = builder.conjunction(); // True condition if no filter
			    }
			    predicates.add(companyNamePredicate);
			    Predicate insCompanyPredicate;
			    if (!filterCompany.getInsurenceCompanyNames().isEmpty()) {
			        insCompanyPredicate = thirdPartyInfoJoin.get("tpCompany").in(insuredInfoCompanyIds);
			    } else {
			        insCompanyPredicate = builder.conjunction(); // True condition if no filter
			    }
			    predicates.add(insCompanyPredicate);
			    predicates.add(builder.notEqual(reportLossRoot.get("state"), RecoveryStatusConstant.DRAFT));

			    query.multiselect(
			        builder.count(reportLossRoot),
			        builder.selectCase()
			            .when(reportLossRoot.get("state").in(RecoveryStatusConstant.TOTALLOSS_ACCEPTED, RecoveryStatusConstant.TOTALLOSS_INITITED), "Total Loss Claims")
			            .otherwise(reportLossRoot.get("state"))
			            .alias("group_status")
			    );
			}
			if(currencyFieldName != null && currencyValue != null) {
	        	predicates.add(builder.and(builder.equal(reportLossRoot.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue)));
	        }
			query.groupBy(reportLossRoot.get("state"));
			
			List<PieChartFilterDto> results = (List<PieChartFilterDto>)getResultList(createQuery(builder, query, reportLossRoot, predicates));
	        return results;
	    }
	/**
	 * Gets the top companies by claim amount filter.
	 *
	 * @param isReceivable the is receivable
	 * @param filterCompany the filter company
	 * @param max the max
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the top companies by claim amount filter
	 */
	@Override
    public List<TopCompanyDto> getTopCompaniesByClaimAmountFilter(Boolean isReceivable,InsuredAndTpArray filterCompany,int max, String currencyFieldName, String currencyValue) {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<Object[]> criteria = builder.createQuery(Object[].class);
        Root<ReportLoss> root = criteria.from(ReportLoss.class);
        List<Predicate> predicates = new ArrayList<>();
		Expression<Integer> insuranceExpression = root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY);
		Expression<Integer> tpExpression = root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY);
		Predicate insurancePredicate,tpPredicate;
		List<Integer> idList = filterCompany.getInsurenceCompanyNames().stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
		List<Integer> tpIdList = filterCompany.getTpCompanyNames().stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
		if(isReceivable){
			insurancePredicate = insuranceExpression.in(idList);
			tpPredicate = tpExpression.in(tpIdList);
			if(filterCompany.getInsurenceCompanyNames().size()>0) {
				predicates.add(insurancePredicate);
			}
			if(filterCompany.getTpCompanyNames().size()>0) {
				predicates.add(tpPredicate);
			}
		} else {
			insurancePredicate = insuranceExpression.in(tpIdList);
			tpPredicate = tpExpression.in(idList);
			if(filterCompany.getInsurenceCompanyNames().size()>0) {
				predicates.add(tpPredicate);
			}
			if(filterCompany.getTpCompanyNames().size()>0) {
				predicates.add(insurancePredicate);
			}
		}
		
        predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
        if(currencyFieldName != null && currencyValue != null) {
        	predicates.add(builder.and(builder.equal(root.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue)));
        }
        criteria.multiselect(root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY),
                builder.sum(root.get(TableConstants.RECOVERY_DETAILS).get(TableConstants.CLAIM_AMOUNT)),
                builder.count(root));
        criteria.groupBy(root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY));
        criteria.orderBy(builder.desc(builder.sum(root.get(TableConstants.RECOVERY_DETAILS).get(TableConstants.CLAIM_AMOUNT))));
        List<Object[]> res= (List<Object[]>)getResultList(createQuery(builder, criteria, root, predicates).setFirstResult(0).setMaxResults(max));
        return res.parallelStream().map(el->{
        	TopCompanyDto topCompanyDto = new TopCompanyDto();
    		CompanyDto companyFromCompanyId = RecoveryCache.getCompanyIdDtoMap().get((Integer) el[0]);
    		if(companyFromCompanyId!=null) {
    			topCompanyDto.setCompanyName(companyFromCompanyId.getName());
    			topCompanyDto.setShortName(companyFromCompanyId.getShortName());
    			topCompanyDto.setTotalClaimAmount((Double)el[1]);
    			topCompanyDto.setTotalClaimCount((Long)el[2]);
    		}
    		return topCompanyDto;
        }).toList();
    }

	 /**
 	 * Gets the vertical bar chart data filter.
 	 *
 	 * @param isReceivable the is receivable
 	 * @param filterCompany the filter company
 	 * @param currencyFieldName the currency field name
 	 * @param currencyValue the currency value
 	 * @return the vertical bar chart data filter
 	 */
 	@Override
	    public List<VerticalBarChartFilterDto> getVerticalBarChartDataFilter(Boolean isReceivable,InsuredAndTpArray filterCompany, String currencyFieldName, String currencyValue) {
	        CriteriaBuilder builder = getCriteriaBuilder();
	        CriteriaQuery<VerticalBarChartFilterDto> criteria = builder.createQuery(VerticalBarChartFilterDto.class);
	        Root<ReportLoss> root = criteria.from(ReportLoss.class);
	        List<Predicate> predicates = new ArrayList<>();
	        
	        Expression<Integer> insuranceExpression = root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY);
			Expression<Integer> tpExpression = root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY);
		 	Predicate insurancePredicate,tpPredicate;
		 	List<Integer> idList = filterCompany.getInsurenceCompanyNames().stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
			List<Integer> tpIdList = filterCompany.getTpCompanyNames().stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
			if (isReceivable){
				insurancePredicate = insuranceExpression.in(idList);
				tpPredicate = tpExpression.in(tpIdList);
				if(filterCompany.getInsurenceCompanyNames().size()>0) {
					predicates.add(insurancePredicate);
				}
				if(filterCompany.getTpCompanyNames().size()>0) {
					predicates.add(tpPredicate);
				}
			}else{
				insurancePredicate = insuranceExpression.in(tpIdList);
				tpPredicate = tpExpression.in(idList);
				if(filterCompany.getInsurenceCompanyNames().size()>0) {
					predicates.add(tpPredicate);
				}
				if(filterCompany.getTpCompanyNames().size()>0) {
					predicates.add(insurancePredicate);
				}
			}
			
	        predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
	        predicates.add(builder.and(builder.notEqual(root.get(TableConstants.STATE), RecoveryStatusConstant.CLAIM_SETTLED)));
	        predicates.add(builder.and(builder.notEqual(root.get(TableConstants.STATE), RecoveryStatusConstant.KNOCKTOKNOCK)));
	        predicates.add(builder.and(builder.notEqual(root.get(TableConstants.STATE), RecoveryStatusConstant.PAID)));
	        if(currencyFieldName != null && currencyValue != null) {
	        	predicates.add(builder.and(builder.equal(root.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue)));
	        }
	        Expression<Long> daysDiff = builder.function("DATEDIFF", Long.class,
	                builder.currentDate(), root.get(TableConstants.CREATED_DATE));
	        Expression<Double> recoveryAmount = builder.sum(root.get(TableConstants.RECOVERY_DETAILS).get(TableConstants.CLAIM_AMOUNT));
	        criteria.multiselect(recoveryAmount,daysDiff);
	        criteria.groupBy(daysDiff);
	        criteria.orderBy(builder.asc(daysDiff));

	        return (List<VerticalBarChartFilterDto>)getResultList(createQuery(builder, criteria, root, predicates).setFirstResult(0).setMaxResults(TableConstants.MAX_DATA_LIMIT_FOR_VERTICAL_BAR_CHART));
	    }
	 
 	/**
 	 * Gets the counts by days filter.
 	 *
 	 * @param isReceivable the is receivable
 	 * @param filterCompany the filter company
 	 * @param topCompanies the top companies
 	 * @param fromDate the from date
 	 * @param toDate the to date
 	 * @param currencyFieldName the currency field name
 	 * @param currencyValue the currency value
 	 * @return the counts by days filter
 	 */
 	@Override
	    public List<CompanyCountByDateDiffDto> getCountsByDaysFilter(Boolean isReceivable,InsuredAndTpArray filterCompany, List<String> topCompanies, LocalDateTime fromDate, LocalDateTime toDate, String currencyFieldName, String currencyValue) {

	        CriteriaBuilder builder = getCriteriaBuilder();
	        CriteriaQuery<Object[]> criteria = builder.createQuery(Object[].class);
	        Root<ReportLoss> root = criteria.from(ReportLoss.class);
	        List<Predicate> predicates = new ArrayList<>();
	        Expression<Integer> insuranceExpression = root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY);
			Expression<Integer> tpExpression = root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY);
		 	Predicate insurancePredicate,tpPredicate;
		 	List<Integer> idList = filterCompany.getInsurenceCompanyNames().stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
		 	List<Integer> tpIdList = filterCompany.getTpCompanyNames().stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
			if (isReceivable){
				insurancePredicate = insuranceExpression.in(idList);
				tpPredicate = tpExpression.in(tpIdList);
				if(!filterCompany.getInsurenceCompanyNames().isEmpty()) {
					predicates.add(insurancePredicate);
				}
				if(!filterCompany.getTpCompanyNames().isEmpty()) {
					predicates.add(tpPredicate);
				}
			}else{
				insurancePredicate = insuranceExpression.in(tpIdList);
				tpPredicate = tpExpression.in(idList);
				if(!filterCompany.getInsurenceCompanyNames().isEmpty()) {
					predicates.add(tpPredicate);
				}
				if(!filterCompany.getTpCompanyNames().isEmpty()) {
					predicates.add(insurancePredicate);
				}
			}
			
	        predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
	        if(currencyFieldName != null && currencyValue != null) {
	        	predicates.add(builder.and(builder.equal(root.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue)));
	        }
	        predicates.add(builder.and(builder.greaterThanOrEqualTo(root.get(TableConstants.MODIFIED_DATE),fromDate)));
	        predicates.add(builder.and(builder.lessThanOrEqualTo(root.get(TableConstants.MODIFIED_DATE),toDate)));

	        Expression<Integer> parentExpression = root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY);
	        List<Integer> topCompanyIdList = topCompanies.stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
	        Predicate parentPredicate = parentExpression.in(topCompanyIdList);
	        predicates.add(builder.and(parentPredicate));
	        
	        criteria.multiselect(root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY),
					builder.count(root));
	        criteria.groupBy(root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY));
	        List<Object[]> res =(List<Object[]>) getResultList(createQuery(builder, criteria, root, predicates).setFirstResult(0).setMaxResults(TableConstants.MAX_DATA_LIMIT_FOR_STACKED_BAR_CHART));
	        return res.stream().map(el->{
	        	CompanyCountByDateDiffDto companyCountByDateDiffDto = new CompanyCountByDateDiffDto();
	        	companyCountByDateDiffDto.setCompany(RecoveryCache.getCompanyList().get((Integer)el[0]));
	        	companyCountByDateDiffDto.setCount((Long) el[1]);
	        	return companyCountByDateDiffDto;
	        }).toList();
	    }


}
