package com.recoveryportal.controller;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.recoveryportal.config.base.controller.BaseController;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.exception.core.codes.ErrorCodes;
import com.recoveryportal.service.BulkImportService;
import com.recoveryportal.transfer.object.core.ApplicationResponse;
import com.recoveryportal.transfer.object.dto.BulkImportFieldValidationDto;
import com.recoveryportal.transfer.object.dto.BulkImportHistoryDto;
import com.recoveryportal.transfer.object.dto.BulkImportTriggerConsumerDto;
import com.recoveryportal.transfer.object.dto.SortingDto;
import com.recoveryportal.transfer.object.reportloss.dto.BulkUploadSuccessErrorList;
import com.recoveryportal.transfer.object.reportloss.dto.ReportLossPageDto;
import com.recoveryportal.utils.core.ApplicationUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;


/**
 * The Class BulkImportController.
 */
@RestController
public class BulkImportController extends BaseController {

    /** The bulk import service. */
    @Autowired
    private BulkImportService bulkImportService;

    /**
     * Report loss bulk upload sample excel.
     *
     * @return the response entity of input stream
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws ApplicationException the application exception
     */
    
    @ApiOperation(value = "Sample excel for bulk import", notes = " Get bulk import sample excel for report loss ",response = ResponseEntity.class)
    @GetMapping("/report-loss/bulk-import/download-sample-excel")
    public ResponseEntity<InputStreamResource> reportLossBulkUploadSampleExcel() throws IOException, ApplicationException{
        return bulkImportService.downloadSampleExcelForBulkUpload();
    }

    /**
     * Gets the import history.
     *
     * @return the import history
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Bulk import history", notes = " Get bulk import history for report loss ",response = ApplicationResponse.class)
    @GetMapping("/report-loss/bulk-import/import-history")
    public ApplicationResponse getImportHistory() throws ApplicationException {
        return getApplicationResponse(bulkImportService.getImportHistory());
    }

    /**
     * Gets the error data.
     *
     * @param uploadId the upload id
     * @return the error data as InputStreamResource
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Bulk import error data input stream resource", notes = " Get bulk import error data for report loss as input stream resource",response = ResponseEntity.class)
    @GetMapping("/report-loss/bulk-import/error-data")
    public ResponseEntity<InputStreamResource> getErrorData(@ApiParam(value = "Bulk import id")  @RequestParam(name = "upload_id") String uploadId) throws ApplicationException {
        return bulkImportService.getErrorData(uploadId);
    }
    
    /**
     * Gets the error data excel.
     *
     * @param uploadId the upload id
     * @param isSuccessData the is success data
     * @return the error data excel
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Bulk import error data excel", notes = " Get bulk import error data as excel",response = ResponseEntity.class)
    @GetMapping("/report-loss/bulk-import/download-error-data-excel")
    public ResponseEntity<InputStreamResource> getErrorDataExcel(@ApiParam(name="Bulk import upload id",required=  true) @RequestParam(name = "uploadId") Integer uploadId,
                                                                 @ApiParam("is Success data flag")  @RequestParam(name = "isSuccessData") Boolean isSuccessData) throws ApplicationException {
        return bulkImportService.getErrorDataExcel(uploadId,isSuccessData);
    }
    
    /**
     * Gets the error data list.
     *
     * @param uploadId the upload id
     * @param sortingDto the sorting dto
     * @return the error data list
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Bulk import error data list ", notes = " Get bulk import error data for report loss with bulk import history",response = ApplicationResponse.class)
    @PostMapping("/report-loss/bulk-import/get-error-data-list")
    public ApplicationResponse getErrorDataList(@ApiParam(value = "Bulk import upload id",required = true) @RequestParam(name = "uploadId") Integer uploadId,
    		@ApiParam(value = "SortingDto payload",required = true) @RequestBody SortingDto sortingDto) throws ApplicationException {
        return getApplicationResponse(bulkImportService.getErrorDataList(uploadId,sortingDto));
    }
    
    /**
     * Gets the success data list.
     *
     * @param uploadId the upload id
     * @param sortingDto the sorting dto
     * @return the success data list
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Bulk import success data list ", notes = " Get bulk import success data for report loss with bulk import history",response = ApplicationResponse.class)
    @PostMapping("/report-loss/bulk-import/get-success-data-list")
    public ApplicationResponse getSuccessDataList(@ApiParam(value = "Bulk import upload id",required = true) @RequestParam(name = "uploadId") Integer uploadId,
    		@ApiParam(value = "SortingDto payload",required = true)	 @RequestBody SortingDto sortingDto) throws ApplicationException {
        return getApplicationResponse(bulkImportService.getSuccessDataList(uploadId,sortingDto));
    }
    

    /**
     * Bulk import from excel.
     *
     * @param file the file
     * @param pageIdentity the page identity
     * @return the application response
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Bulk import using excel", notes = "Bulk import operation using excel",response = ApplicationResponse.class)
    @PostMapping("/report-loss/bulk-import/excel")
    public ApplicationResponse bulkImportFromExcel(@ApiParam(value = "Bulk import file")  @RequestParam(name="bulk_import_file", required = false) MultipartFile file, @ApiParam(value = "Bulk import page id",required = true)  @RequestParam("page_id") String pageIdentity) throws IOException, ApplicationException{

        if (Boolean.FALSE.equals(ApplicationUtils.isValidateObject(file))) {
            throw new ApplicationException(ErrorCodes.INVALID_FILE);
        }
        BulkImportTriggerConsumerDto bb = bulkImportService.bulkImportFromExcel(file,pageIdentity);
        //trigger kafka producer
        bulkImportService.triggerKafkaProducerForBulkUpload(bb);

        return getApplicationResponse(bb.getBulkImportHistoryDto());
    }
    
    /**
     * Update bulk import history.
     *
     * @param bulkImportHistoryDto the bulk import history dto
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Update bulk import history", notes = "Updating bulk import history using bulk import history dto")
    @PostMapping("/auth/report-loss/bulk-import/update-import-history")
    public void bulkImportFromExcel(@ApiParam(value = "Bulk import history dto payload",required = true)  @RequestBody BulkImportHistoryDto bulkImportHistoryDto) throws IOException, ApplicationException{
        bulkImportService.updateBulkImportHistory(bulkImportHistoryDto);
    }

    /**
     * Gets the file path by upload id.
     *
     * @param uploadId the upload id
     * @return the file path by upload id
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "File path retrieval", notes = "Get file path using uploadId as resource")
    @GetMapping("/auth/report-loss/bulk-import/get-file-path")
    public Resource getFilePathByUploadId(@ApiParam(value = "Bulk upload id", required = true) @RequestParam("upload_id") Integer uploadId) throws IOException, ApplicationException{
        return bulkImportService.getFilePathByBulkUploadId(uploadId);
    }

    /**
     * Save success error data.
     *
     * @param userId the user id
     * @param uploadId the upload id
     * @param bulkUploadSuccessErrorList the bulk upload success error list
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Save success error data", notes = "Saves bulk import success and error data.")
    @PostMapping("/auth/report-loss/bulk-import/save-success-error-data")
    public void saveSuccessErrorData(
    		@ApiParam(value = "User ID", required = true) @RequestParam("user_id") String userId,
    		 @ApiParam(value = "Bulk Import ID", required = true) @RequestParam("upload_id") String uploadId,
    		 @ApiParam(value = "Bulk upload success error list payload", required = true)   @RequestBody BulkUploadSuccessErrorList bulkUploadSuccessErrorList) throws IOException, ApplicationException{
        bulkImportService.saveSuccessErrorData(bulkUploadSuccessErrorList,Integer.parseInt(userId),Integer.parseInt(uploadId));
    }
    
    /**
     * Error data delete.
     *
     * @param uploadIdentity the upload identity
     * @return the application response
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Delete error data", notes = "Deletes error data based on upload identity.",response = ApplicationResponse.class)
    @GetMapping("/auth/report-loss/bulk-import/Delete")
    public ApplicationResponse errorDataDelete(
    		@ApiParam(value = "Bulk import upload identity", required = true)	@RequestParam("uploadIdentity") String uploadIdentity) throws IOException, ApplicationException{
        bulkImportService.errorDataDelete(uploadIdentity);
        return getApplicationResponse(TableConstants.ERROR_DATA_DELETED);
    }
    
    /**
     * Validate fields.
     *
     * @param validationDto the validation dto
     * @return the bulk upload success error list
     * @throws NoSuchMethodException the no such method exception
     * @throws InvocationTargetException the invocation target exception
     * @throws IllegalAccessException the illegal access exception
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Validate fields", notes = "Validates bulk import fields based on Bulk import field validation dto",response = BulkUploadSuccessErrorList.class)
    @PostMapping("/auth/report-loss/bulk-import/validate-fields")
    public BulkUploadSuccessErrorList validateFields( @ApiParam(value = "Bulk import field validation DTO", required = true) @RequestBody BulkImportFieldValidationDto validationDto) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, ApplicationException {
        return bulkImportService.validateFields(validationDto);
    }
    
    /**
     * Edits the error data by upload data id.
     *
     * @param uploadId the upload id
     * @return the report loss page dto
     * @throws ApplicationException the application exception
     */
    @ApiOperation(value = "Edit error data", notes = "Edits error data based on upload ID.",response = ReportLossPageDto.class)
    @GetMapping("/auth/report-loss/bulk-import/edit-error-data/{uploadId}")
    public ReportLossPageDto editErrorDataByUploadDataId(@ApiParam(value = "Bulk import upload ID", required = true)  @PathVariable(name = "uploadId") String uploadId) throws ApplicationException {
        return bulkImportService.editErrorDataByUploadDataId(uploadId);
    }
    
    /**
     * Gets the class name.
     *
     * @return the class name
     */
    @Override
    protected Class<?> getClassName() {
        return this.getClass();
    }

    /**
     * Gets the vo.
     *
     * @param identity the identity
     * @return the vo
     * @throws ApplicationException the application exception
     */
    @Override
    public Object getVo(String identity) throws ApplicationException {
        return null;
    }

    /**
     * Register interceptor.
     */
    @Override
    protected void registerInterceptor() {

    }
}
