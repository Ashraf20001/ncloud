package com.recoveryportal.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.recoveryportal.config.common.base.dao.BaseDao;
import com.recoveryportal.constants.core.RecoveryStatusConstant;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.dao.DashboardDetailsDao;
import com.recoveryportal.security.jwt.RecoveryCache;
import com.recoveryportal.transfer.object.reportloss.entity.ReportLoss;

/**
 * The Class DashboardDetailsDaoImpl.
 */
@Repository
@Transactional
public class DashboardDetailsDaoImpl extends BaseDao implements DashboardDetailsDao {
    
    /**
     * Gets the total receivable count.
     *
     * @param companyList the company list
     * @param isAssociate the is associate
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the total receivable count
     */
    @Override
    public Long getTotalReceivableCount(List<String>companyList,boolean isAssociate, String currencyFieldName, String currencyValue) {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
        Root<ReportLoss> root = criteria.from(ReportLoss.class);
        Expression<Long> countExpression = builder.count(root);
        criteria.select(countExpression);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED),false)));
        if(!companyList.isEmpty()) {
        	List<Integer> idList = companyList.stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
        predicates.add(builder.and((root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY).in(idList))));
        }
        if(currencyFieldName != null && currencyValue != null) {
        	predicates.add(builder.and(builder.equal(root.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue)));
        }
        return (Long) getSingleResult(createQuery(builder, criteria, root, predicates));
    }

    /**
     * Gets the total payable count.
     *
     * @param companyList the company list
     * @param isAssociate the is associate
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the total payable count
     */
    @Override
    public Long getTotalPayableCount(List<String>companyList,boolean isAssociate, String currencyFieldName, String currencyValue) {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
        Root<ReportLoss> root = criteria.from(ReportLoss.class);
        Expression<Long> countExpression = builder.count(root);
        criteria.select(countExpression);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED),false)));
        predicates.add(builder.and(builder.notEqual(root.get(TableConstants.STATE),RecoveryStatusConstant.DRAFT)));
        if(!companyList.isEmpty()) {
        	List<Integer> idList = companyList.stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
        predicates.add(builder.and((root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY).in(idList))));
        }
        if(currencyFieldName != null && currencyValue != null) {
        	predicates.add(builder.and(builder.equal(root.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue)));
        }
        return (Long) getSingleResult(createQuery(builder, criteria, root, predicates));
    }

    /**
     * Gets the count by stage list.
     *
     * @param isReceivable the is receivable
     * @param companyList the company list
     * @param stateList the state list
     * @param isAssociate the is associate
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the count by stage list
     */
    @Override
    public Long getCountByStageList(boolean isReceivable,List<String>companyList, List<String> stateList,boolean isAssociate, String currencyFieldName, String currencyValue) {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
        Root<ReportLoss> root = criteria.from(ReportLoss.class);
        Expression<Long> countExpression = builder.count(root);
        criteria.select(countExpression);
        List<Predicate> predicates = new ArrayList<>();
        if (!isReceivable){
            predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED),false)));
            if(!companyList.isEmpty()) {
            	List<Integer> idList = companyList.stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
            predicates.add(builder.and((root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY).in(idList))));
            }
        }else{
            predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED),false)));
            if(!companyList.isEmpty()) {
            	List<Integer> idList = companyList.stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
            predicates.add(builder.and((root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY).in(idList))));
            }
        }
        if(currencyFieldName != null && currencyValue != null) {
        	predicates.add(builder.and(builder.equal(root.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue)));
        }
        Expression<String> parentExpression = root.get(TableConstants.STATE);
        Predicate parentPredicate = parentExpression.in(stateList);
        Expression<String> laststatusExperssion = root.get(TableConstants.LAST_STATUS);
        Predicate lastStatusPredicate = laststatusExperssion.in(stateList);
        predicates.add(builder.or(parentPredicate,lastStatusPredicate));

        return (Long) getSingleResult(createQuery(builder, criteria, root, predicates));
    }

    /**
     * Gets the total receivable amount.
     *
     * @param companyList the company list
     * @param isAssociate the is associate
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the total receivable amount
     */
    @Override
    public Double getTotalReceivableAmount(List<String>companyList,boolean isAssociate, String currencyFieldName, String currencyValue) {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<Double> criteria = builder.createQuery(Double.class);
        Root<ReportLoss> root = criteria.from(ReportLoss.class);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
        if(!companyList.isEmpty()) {
        	List<Integer> idList = companyList.stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
        predicates.add(builder.and((root.get(TableConstants.INSURED_INFO).get(TableConstants.RL_II_INSURER_COMPANY).in(idList))));
        }
        if(currencyFieldName != null && currencyValue != null) {
        	predicates.add(builder.and(builder.equal(root.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue)));
        }
        criteria.select(builder.sum(root.get(TableConstants.RECOVERY_DETAILS).get(TableConstants.CLAIM_AMOUNT)));
        return (Double)getSingleResult(createQuery(builder, criteria, root, predicates));

    }

    /**
     * Gets the total payable amount.
     *
     * @param companyList the company list
     * @param isAssociate the is associate
     * @param currencyFieldName the currency field name
     * @param currencyValue the currency value
     * @return the total payable amount
     */
    @Override
    public Double getTotalPayableAmount(List<String>companyList,boolean isAssociate, String currencyFieldName, String currencyValue) {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<Double> criteria = builder.createQuery(Double.class);
        Root<ReportLoss> root = criteria.from(ReportLoss.class);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
        if(!companyList.isEmpty()) {
        	List<Integer> idList = companyList.stream().map(RecoveryCache.getCompanyNameIdMap()::get).toList();
        	predicates.add(builder.and((root.get(TableConstants.THIRD_PARTY_INFO).get(TableConstants.RL_TPI_TP_COMPANY).in(idList))));
        }
        if(currencyFieldName != null && currencyValue != null) {
        	predicates.add(builder.and(builder.equal(root.get(TableConstants.INSURED_INFO).get(currencyFieldName), currencyValue)));
        }
        criteria.select(builder.sum(root.get(TableConstants.RECOVERY_DETAILS).get(TableConstants.CLAIM_AMOUNT)));
        return (Double)getSingleResult(createQuery(builder, criteria, root, predicates));
    }

    /**
     * Register data filters.
     */
    @Override
    public void registerDataFilters() {

    }
}
