package com.recoveryportal.claimhistory.dao;

import java.util.List;

import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.transfer.object.dto.InsuredAndTpArray;
import com.recoveryportal.transfer.object.dto.RecentClaimDto;
import com.recoveryportal.transfer.object.entity.ClaimHistory;
import com.recoveryportal.transfer.object.reportloss.entity.ReportLoss;

/**
 * The Interface ClaimHistoryDao.
 */
public interface ClaimHistoryDao {

	/**
	 * Save claim history details.
	 *
	 * @param notificationHistory the notification history
	 * @return the claim history
	 * @throws ApplicationException the application exception
	 */
	public ClaimHistory saveClaimHistoryDetails(ClaimHistory notificationHistory) throws ApplicationException;

	/**
	 * Gets the claim history by claim id.
	 *
	 * @param claimId the claim id
	 * @return the claim history by claim id
	 */
	public List<ClaimHistory> getClaimHistoryByClaimId(Integer claimId);
	
	/**
	 * Gets the recent claim history.
	 *
	 * @param hasAssociationPrivilege is association privilege
	 * @param isReceivable  is receivable
	 * @param filterCompany the filter company
	 * @param companyName the company name
	 * @param currencyFieldName the currency field name
	 * @param currencyValue the currency value
	 * @return the recent claim history
	 */
	public List<ClaimHistory> getRecentClaimHistory(boolean hasAssociationPrivilege, boolean isReceivable, 
			InsuredAndTpArray filterCompany, String companyName, String currencyFieldName, String currencyValue);

	/**
	 * Gets the claim history by claim id and state.
	 *
	 * @param claimId claim id
	 * @param state claim state
	 * @return the claim history by claim id and claim state
	 */
	public ClaimHistory getClaimHistoryByClaimIdAndState(Integer claimId, String state);

	/**
	 * Gets the recently created claim history.
	 *
	 * @param claim the claim
	 * @return the recently created claim history
	 */
	public ClaimHistory getRecentlyCreatedClaimHistory(ReportLoss claim);
	
	/**
	 * Update Claim History.
	 *
	 * @param claimHistory  claim history
	 */
	public void updateClaimHistory(ClaimHistory claimHistory);
	
	/**
	 * Get Recently Created ClaimHistory.
	 *
	 * @param claim report loss claim
	 * @return the recently created claim history template
	 */
	public ClaimHistory getRecentlyCreatedClaimHistoryTemplate(ReportLoss claim);

	/**
	 * Check claim history by template.
	 *
	 * @param claimHistory the claim history
	 * @return the long
	 */
	public Long checkClaimHistoryByTemplate(ClaimHistory claimHistory);
}
