package com.recoveryportal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.recoveryportal.aop.annotation.Auditable;
import com.recoveryportal.config.base.controller.BaseController;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.service.ReportService;
import com.recoveryportal.transfer.object.core.ApplicationResponse;
import com.recoveryportal.transfer.object.dto.NotificationDto;
import com.recoveryportal.transfer.object.dto.PayReportReqDto;
import com.recoveryportal.transfer.object.dto.PaymentDto;
import com.recoveryportal.transfer.object.dto.ReportCardDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class ReportsController.
 */
@RestController
@RequestMapping("/report")
@Auditable
public class ReportsController extends BaseController {

	/** The report service. */
	@Autowired
	private ReportService reportService;
	
	
	/**
	 * Save report details.
	 *
	 * @param list the list
	 * @return the application response
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Reports save",notes="Save companies reports",response=ApplicationResponse.class)
	@PostMapping("/saveData")
	public ApplicationResponse saveReportDetails(@ApiParam(value = "Reports Dto payload",required=true) @RequestBody ReportCardDto list) throws ApplicationException{
		return  getApplicationResponse(reportService.SaveReportDetails(list));
	}
	
	/**
	 * Gets the report fields.
	 *
	 * @return the report fields
	 */
	@ApiOperation(value="Reports additional fields",notes="Get fields to be added while creating reports",response = List.class)
	@GetMapping("/ReportFields")
	public List<String> getReportFields() {
		return reportService.getReportFields();
	}

	/**
	 * Gets the report details.
	 *
	 * @return the report details
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Reports data",notes="Get all reports data",response = List.class)
	@GetMapping("/getData")
	public List<ReportCardDto> getReportDetails()throws ApplicationException {
		return reportService.getAllData();	
	}
	
	/**
	 * Report card update.
	 *
	 * @param list the list
	 * @return the application response
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Reports update",notes="Update reports data",response = ApplicationResponse.class)
	@PostMapping("/updateData")
	public ApplicationResponse ReportCardUpdate( @ApiParam(value="Reports dto payload") @RequestBody ReportCardDto list) throws ApplicationException {
		return  getApplicationResponse(reportService.UpdateValues(list));
	}
	
	/**
	 * Gets the single data.
	 *
	 * @param Identity the identity
	 * @return the single data
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Reports fetch",notes="Get reports data based on reports identity",response = ReportCardDto.class)
	@PostMapping("/getByIdentity")
	public ReportCardDto getSingleData( @ApiParam(value="Reports identity")  @RequestBody String Identity) throws ApplicationException {
		return reportService.getSingleValue(Identity);
	}

	/**
	 * Gets the option list.
	 *
	 * @param fieldIdentity the field identity
	 * @param fieldValue the field value
	 * @param fieldName the field name
	 * @return the option list
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Dropdown data",notes="Get option list using field details",response = List.class)
	@GetMapping("/getDropDownData")
	public List<String> getOptionList(@ApiParam(value="field identity",required=true) @RequestParam("fieldIdentity") String fieldIdentity
									,@ApiParam(value="field value",required=true) @RequestParam("fieldValue") String fieldValue,
									@ApiParam(value="field name",required=true)  @RequestParam("fieldName") String fieldName)throws ApplicationException {
		
		return reportService.getDropDownValue(fieldIdentity,fieldValue,fieldName);
	}

	/**
	 * Gets the drop down field map.
	 *
	 * @return the drop down field map
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Dropdown field map",notes="Get dropdown field mapping details",response = ApplicationResponse.class)
	@GetMapping("/getDropDownFieldMap")
	public ApplicationResponse getDropDownFieldMap() throws ApplicationException {
		return  getApplicationResponse(reportService.getDropDownFieldMap());
	}

	/**
	 * Generate report details.
	 *
	 * @param notificationDto the notification dto
	 * @throws Exception the exception
	 */
	@ApiOperation(value="Generate report",notes="Generate monthly report using notification object")
	@PostMapping("/generateData")
	public void generateReportDetails(@ApiParam(value="Notification data payload", required=true) @RequestBody NotificationDto notificationDto) throws Exception {
		reportService.generateDataMonthly(notificationDto);
	}
	
	/**
	 * Pay for report.
	 *
	 * @param payReportReqData the pay report req data
	 * @return the application response
	 * @throws Exception the exception
	 */
	@ApiOperation(value="Report payment",notes="Endpoint useful for payment in report", response = ApplicationResponse.class)
	@PostMapping("/pay-report")
	public ApplicationResponse payForReport(@ApiParam(value="Report request payload",required=true)  @RequestBody PayReportReqDto payReportReqData)throws Exception{
		return  getApplicationResponse(reportService.getComapnyAmountData(payReportReqData));
	}
	
	/**
	 * Pay to pay.
	 *
	 * @param paymentDto the payment dto
	 * @return the application response
	 * @throws Exception the exception
	 */
	@ApiOperation(value="Save report payment",notes="Endpoint useful for saving payment details", response = ApplicationResponse.class)
	@PostMapping("/save-payment")
	public ApplicationResponse payToPay(@ApiParam(value="Payment payload",required=true)  @RequestBody PaymentDto paymentDto)throws Exception{
		return  getApplicationResponse(reportService.savePayment(paymentDto));
	}
	
	/**
	 * Gets the payment details.
	 *
	 * @param min the min
	 * @param max the max
	 * @return the payment details
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Payment details",notes="Endpoint useful for getting payment details", response = ApplicationResponse.class)
	@GetMapping("/get-payment-details")
	public ApplicationResponse getPaymentDetails(@ApiParam(value="Skip data count",required=true) @RequestParam(name = "min") Integer min, @ApiParam(value="Limit data count",required = true) @RequestParam(name = "max")Integer max) throws ApplicationException {
		return  getApplicationResponse(reportService.getPaymentDetails(min,max));
	}
	
	/**
	 * Gets the payment details count.
	 *
	 * @return the payment details count
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Payment details count",notes="Endpoint useful for getting payment count", response = ApplicationResponse.class)
	@GetMapping("/payment-details-count")
	public ApplicationResponse getPaymentDetailsCount() throws ApplicationException {
		return  getApplicationResponse(reportService.getPaymentDetailsCount());
	}

	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}
	
	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}
	
	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {
		
	}
}

