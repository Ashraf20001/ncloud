package com.recoveryportal.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.recoveryportal.config.common.base.dao.BaseDao;
import com.recoveryportal.constants.core.ApplicationConstants;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.dao.NotificationHistoryDao;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.transfer.object.notification.entity.NotificationHistory;

/**
 * The Class NotificationHistoryDaoImpl.
 */
@Repository
@Transactional
public class NotificationHistoryDaoImpl extends BaseDao implements NotificationHistoryDao {

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
		
	}

	/**
	 * Save notification.
	 *
	 * @param notificationHistory the notification history
	 * @return the notification history
	 * @throws ApplicationException the application exception
	 */
	@Override
	public NotificationHistory saveNotification(NotificationHistory notificationHistory) throws ApplicationException {
		 save(notificationHistory, TableConstants.NOTIFICATION_HISTORY);
	        return notificationHistory;
	}

	/**
	 * Gets the all notifications.
	 *
	 * @param companyName the company name
	 * @return the all notifications
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<NotificationHistory> getAllNotifications(String companyName) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<NotificationHistory> criteria = builder.createQuery(NotificationHistory.class);
		Root<NotificationHistory> root = criteria.from(NotificationHistory.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.TO_NOTIFY).get(TableConstants.NAME), companyName)));
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.IS_READ))));
		return (List<NotificationHistory>) getResultList(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Gets the claim history for claim.
	 *
	 * @param claimId the claim id
	 * @return the claim history for claim
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<NotificationHistory> getClaimHistoryForClaim(Integer claimId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<NotificationHistory> criteria = builder.createQuery(NotificationHistory.class);
		Root<NotificationHistory> root = criteria.from(NotificationHistory.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.CLAIM_DETAILS).get(TableConstants.CLAIM_ID), claimId)));
		criteria.orderBy(builder.asc(root.get(TableConstants.CREATED_DATE)));
		return (List<NotificationHistory>) getResultList(createQuery(builder, criteria, root, predicates));
	}
	
	 /**
 	 * Update notification by notification identity.
 	 *
 	 * @param identity the identity
 	 * @param userId the user id
 	 * @return true, if successful
 	 */
 	@Override
		public boolean updateNotificationByNotificationIdentity(String identity, Integer userId) {
	        boolean flag = false;
			CriteriaBuilder builder = getCriteriaBuilder();
			CriteriaUpdate<NotificationHistory> criteria = builder.createCriteriaUpdate(NotificationHistory.class);
			Root<NotificationHistory> root = criteria.from(NotificationHistory.class);
			criteria.set(root.get(TableConstants.IS_READ), true);
			criteria.set(root.get(TableConstants.MODIFIED_BY), userId);
			criteria.set(root.get(TableConstants.MODIFIED_DATE), new Date());
			criteria.where(builder.equal(root.get(TableConstants.IDENTITY), identity));
			int executeUpdate = createQueryupdate(criteria).executeUpdate();
			if (executeUpdate > 0) {
				flag = true;
			}  
			return flag;
		}
	
	/**
	 * Gets the un read notification for claim and company.
	 *
	 * @param claimId the claim id
	 * @param toNotifyCompany the to notify company
	 * @return the un read notification for claim and company
	 */
	@Override
	public NotificationHistory getUnReadNotificationForClaimAndCompany(Integer claimId, String toNotifyCompany) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<NotificationHistory> criteria = builder.createQuery(NotificationHistory.class);
		Root<NotificationHistory> root = criteria.from(NotificationHistory.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.CLAIM_DETAILS).get(TableConstants.CLAIM_ID), claimId)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.TO_NOTIFY).get(TableConstants.NAME), toNotifyCompany)));
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.IS_READ))));
		return (NotificationHistory) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);
	}
	
	/**
	 * Update notification history.
	 *
	 * @param notificationHistory the notification history
	 */
	@Override
	public void updateNotificationHistory(NotificationHistory notificationHistory) {
		update(notificationHistory);
	}

	/**
	 * Check for exisiting remainder.
	 *
	 * @param claimId the claim id
	 * @param toNotify the to notify
	 * @return the notification history
	 */
	@Override
	public NotificationHistory checkForExisitingRemainder(Integer claimId, String toNotify) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<NotificationHistory> criteria = builder.createQuery(NotificationHistory.class);
		Root<NotificationHistory> root = criteria.from(NotificationHistory.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder
				.and(builder.equal(root.get(TableConstants.CLAIM_DETAILS).get(TableConstants.CLAIM_ID), claimId)));
		predicates.add(builder
				.and(builder.equal(root.get(TableConstants.STATUS), ApplicationConstants.NOTIFICATION_RECIEVED)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.LAST_ACTED).get(TableConstants.NAME), ApplicationConstants.SCHEDULER)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.TO_NOTIFY).get(TableConstants.NAME), toNotify)));
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.IS_READ))));
		return (NotificationHistory) getResultList(createQuery(builder, criteria, root, predicates)).stream()
				.findFirst().orElse(null);
	}

}
