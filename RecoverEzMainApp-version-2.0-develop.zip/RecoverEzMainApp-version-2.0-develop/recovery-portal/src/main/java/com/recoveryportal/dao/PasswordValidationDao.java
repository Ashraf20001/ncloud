package com.recoveryportal.dao;

import java.util.List;

import com.recoveryportal.transfer.object.entity.CommonWords;

/**
 * The Interface PasswordValidationDao.
 */
public interface PasswordValidationDao {
    
    /**
     * Gets the common words list.
     *
     * @return the common words list
     */
    List<CommonWords> getCommonWordsList();
}
