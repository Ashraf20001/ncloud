package com.recoveryportal.claimSummaryDetails.service;

import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.transfer.object.claimSummaryDetails.dto.ClaimSummaryDetailsDto;

import java.util.List;

/**
 * The Interface ClaimSummaryDetailsService.
 */
public interface ClaimSummaryDetailsService {
    
    /**
     * Gets the all claim summary details.
     *
     * @return the all claim summary details
     * @throws ApplicationException the application exception
     */
    List<ClaimSummaryDetailsDto> getAllClaimSummaryDetails() throws ApplicationException;

    /**
     * Gets the claim summary details by identity.
     *
     * @param identity the identity
     * @return the claim summary details by identity
     * @throws ApplicationException the application exception
     */
    ClaimSummaryDetailsDto getClaimSummaryDetailsByIdentity(String identity) throws ApplicationException;

    /**
     * Save claim summary details.
     *
     * @param claimSummaryDetailsDto the claim summary details dto
     * @return the claim summary details dto
     * @throws ApplicationException the application exception
     */
    ClaimSummaryDetailsDto saveClaimSummaryDetails(ClaimSummaryDetailsDto claimSummaryDetailsDto) throws ApplicationException;

    /**
     * Update claim summary details.
     *
     * @param id the id
     * @param claimSummaryDetailsDto the claim summary details dto
     * @return the claim summary details dto
     * @throws ApplicationException the application exception
     */
    ClaimSummaryDetailsDto updateClaimSummaryDetails(String id, ClaimSummaryDetailsDto claimSummaryDetailsDto) throws ApplicationException;

    /**
     * Delete claim summary details.
     *
     * @param identity the identity
     * @return the string
     * @throws ApplicationException the application exception
     */
    String deleteClaimSummaryDetails(String identity) throws ApplicationException;
}
