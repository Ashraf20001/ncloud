package com.ncloud.dl.constants.serverproperties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

/**
 * The Class PropertyValueProvider.
 */
@Component
@ConfigurationProperties(prefix = "dlmainapp")
@Data
public class PropertyValueProvider {
	
	/** The mysql data source url. */
	private String mysqlDataSourceUrl;
	
	/** The mysql ip. */
	private String mysqlIp;
	
	/** The mysql port. */
	private String mysqlPort;
	
	/** The mysql username. */
	private String mysqlUsername;
	
	/** The mysql password. */
	private String mysqlPassword;
	
	/** The mysql data base. */
	private String mysqlDataBase;
	
	/** The mysql driver. */
	private String mysqlDriver;
	
	/** The time zone. */
	private String timeZone;
	
	/** The number format. */
	private String numberFormat;
	
	/** The country code. */
	private String countryCode;
	
	/** The currency format. */
	private String currencyFormat;
	
	/** The time format. */
	private String timeFormat;
	
	/** The date format. */
	private String dateFormat;
	
	/** The file download url. */
	private String fileDownloadUrl;
	
	/** The spring mail username. */
	private String springMailUsername;
	
	/** The file upload path. */
	private String fileUploadPath;
	
	/** The frontend url. */
	private String frontendUrl;	
	
	/** The send email name. */
	private String sendEmailName;
	
	/** The common service path. */
	private String commonServicePath;
	
	/** The notification scheduler trigger url. */
	private String notificationSchedulerTriggerUrl;
	
	/** The notification update status. */
	private String notificationUpdateStatus;
	
	/** The upload path. */
	private String uploadPath;
	
	/** The elastic search schema. */
	private String elasticSearchSchema;
	
	/** The elastic search host. */
	private String elasticSearchHost;
	
	/** The elastic syncup kafka. */
	private String elasticSyncupKafka;
	
	/** The elastic search port. */
	private String elasticSearchPort;
	
	/** The elastic search username. */
	private String elasticSearchUsername;
	
	/** The elastic search password. */
	private String elasticSearchPassword;
	
	/** The spring kafka converter. */
	private String springKafkaConverter;
	
	/** The spring kafka partitions. */
	private String springKafkaPartitions;
	
	/** The spring kafka replication factor. */
	private String springKafkaReplicationFactor;
}
