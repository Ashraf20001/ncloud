package com.ncloud.dl.constants.core;

/**
 * The Class QueryConstants.
 */
public class QueryConstants {

	/** The Constant SELECT_QUERY. */
	public static final String SELECT_QUERY = "SELECT * FROM " + ApplicationConstants.DOUBLE_QUOTES + "<table>"
			+ ApplicationConstants.DOUBLE_QUOTES + " scratch"
			+ " LEFT JOIN error_maintainence error ON scratch.dclm_identity = error.unique_id"
			+ " LEFT JOIN field_config field ON error.field_id = field.field_id"
			+ " WHERE dclm_bulk_upload_id = <bulk_upload_id>" + " AND error.repository_id = <repository_id>"
			+ " AND dclm_status = <status>" + " GROUP BY #";
	
	/** The Constant COUNT_QUERY. */
	public static final String COUNT_QUERY = "SELECT count(id) AS total_count FROM " + ApplicationConstants.DOUBLE_QUOTES
			+ "<table>" + ApplicationConstants.DOUBLE_QUOTES + " WHERE dclm_bulk_upload_id = <bulk_upload_id>"
			+ " AND dclm_status = <status>";
	
	/** The Constant SEARCH_RESULT_QUERY. */
	public static final String SEARCH_RESULT_QUERY = "SELECT * FROM " + ApplicationConstants.DOUBLE_QUOTES
			+ "<table>" + ApplicationConstants.DOUBLE_QUOTES + " WHERE dclm_identity IN (#) ORDER BY id asc";

	/** The Constant PAGINATION_QUERY. */
	public static final String PAGINATION_QUERY = " LIMIT <limit> OFFSET <offset>";

	/** The Constant SORTING_QUERY. */
	public static final String SORTING_QUERY = " ORDER BY <column> <condition>";

	/** The Constant ASC. */
	public static final String ASC = "ASC";

	/** The Constant DESC. */
	public static final String DESC = "DESC";

	/** The Constant LIMIT. */
	public static final String LIMIT = "<limit>";

	/** The Constant OFFSET. */
	public static final String OFFSET = "<offset>";

	/** The Constant TABLE. */
	public static final String TABLE = "<table>";

	/** The Constant CONDITION. */
	public static final String CONDITION = "<condition>";

	/** The Constant BULK_UPLOAD_ID. */
	public static final String BULK_UPLOAD_ID = "<bulk_upload_id>";

	/** The Constant REPOSITORY_ID. */
	public static final String REPOSITORY_ID = "<repository_id>";

	/** The Constant STATUS. */
	public static final String STATUS = "<status>";

	/** The Constant COLUMN. */
	public static final String COLUMN = "<column>";
	
	/** The Constant ERR_REP_ID. */
	public static final String ERR_REP_ID = " AND error.repository_id = <repository_id>";
	
	/** The Constant GROUP_BY_COLS. */
	public static final String GROUP_BY_COLS = ",scratch.dclm_identity, scratch.id";
	
	/** The Constant SYSTEM_DEFAULT_COLUMNS. */
	public static final String SYSTEM_DEFAULT_COLUMNS = " dclm_status BOOLEAN , dclm_bulk_upload_id INT DEFAULT NULL, "
												+ "dclm_identity VARCHAR(300) DEFAULT NULL, dclm_hash_code VARCHAR(300) ";
	
	/** The Constant ON. */
	public static final String ON = " ON ";
	
	/** The Constant CREATE_INDEX. */
	public static final String CREATE_INDEX = " CREATE INDEX ";
	
	/** The Constant IDX_NAME. */
	public static final String IDX_NAME = " (dclm_hash_code)";
	
	/**
	 * The Class ColumnConstants.
	 */
	public class ColumnConstants {

		/** The Constant BULK_UPLOAD_ID. */
		public static final String BULK_UPLOAD_ID = "dclm_bulk_upload_id";

		/** The Constant STATUS. */
		public static final String STATUS = "dclm_status";
		
		/** The Constant IDENTITY. */
		public static final String IDENTITY = "dclm_identity";
		
		/** The Constant ERROR. */
		public static final String ERROR = "error";
		
		/** The Constant ID. */
		public static final String ID = "id";
		
		/** The Constant ERR_FLDS. */
		public static final String ERR_FLDS = "err_flds";
		
		/** The Constant SCRATCH. */
		public static final String SCRATCH = "scratch.";
		
		/** The Constant DEFAULT_COLUMNS. */
		public static final String DEFAULT_COLUMNS = ",scratch.id, STRING_AGG(error.err_msg, ',') error, STRING_AGG(field.column_name, ',') err_flds";
		
		/** The Constant IDX_PREFIX. */
		public static final String IDX_PREFIX = "dl_";
		
	}
}
