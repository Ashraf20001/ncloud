package com.ncloud.dl.constants.core;

public class TableConstants {
	public static final String REPOSITORY_ID ="repositoryId";
	public static final String IS_DELETE_STS = "isDltSts";

	public static final String EFFECTIVE_DATE = "effectiveTo";
	public static final String SCHEDULER_NOTI_ID = "schedulerNotificationId";

	public static final String DROP_OPTION_NAME = "dropdownOptions";
	public static final String DATAREPOSITORY = "dataRepository";

	public static final String REPO_STATUS="repoStatus";
	public static final String ASSOCIATION_ID = "associationId";
	
	public static final String IDENTITY = "identity";

	public static final String REPO_NAME = "repositoryName";
	public static final String ID = "id";

	public static final String STOCK_EVENT_NAME = "eventName";


	public static final String ISDELETED = "isDeleted";

    public static final String COMPANY_ID = "companyId";

	public static final String STATE = "state";

	public static final String REPO_ID = "repoId";
	public static final String REPOSITORY_NAME = "repositoryName";
	public static final String REPOSITORY_API_NAME = "repoApiName";
	public static final String REPOSITORY_TABLE_NAME = "repoTableName";
	

	public static final String REPOSITORYID = "repositoryId";

	public static final String NOTIFICATION_EVENT = "notificationEvent";

	public static final String IS_DLTSTS = "isDltSts";
	public static final String SEARCH_TYPE = "searchType";

	public static final String STATUS = "status";
	public static final String CRT_DTE_TME = "crt_dte_tme";
	public static final String MDY_DTE_TME = "mdy_dte_tme";

	public static final String TO_NOTIFY = "toNotify";

	public static final String IS_READ = "isRead";

	public static final String FIELD_ID = "fieldId";

	public static final String CREATED_DATE = "crtDteTme";
	public static final String MODI_DATE = "mdyDteTme";

	public static final String UPLOAD_STATUS = "uploadStatus";


	public static final String DL_FILE_STORAGE = "file_storage";

	public static final String BULK_UPLOAD_ID = "bulkUploadId";
	public static final String IS_DUPLICATE = "isDuplicate";
	public static final String SCRATCH_ID = "scratchId";

	// search History
	public static final String SEARCH_HISTORY = "SearchHistory";

	public static final String IS_ACTIVE = "isActive";


	// data lake table names
	public static final String COMMENTS= "Comments";
	public static final String DATA_REPOSITORY = "data_repository";
	public static final String FIELD_SEARCH_LINK = "field_search_lnk";
	public static final String FIELD_OPTION_LINK = "field_option_linking";
	public static final String FIELD_CONFIG = "field_config";
	public static final String CREATED_DATE_TIME = "crtDteTme";
	public static final String REPOSITROY_NOTIFICATION = "repository_notification";
	public static final String BULK_UPLOAD_HISTORY = "bulk_upload_history";
	public static final String FIELD_ORDER = "fieldOrder";
	public static final String SCHEDULER_NOTIFICATION = "scheduler_notification";
	public static final String REPOSITORY_SCHEDULE_DETAILS = "repository_schedule_details";
	public static final String ERROR_MAINTENANCE = "error_maintainence";

	
	/**
	 * FIELD_NAME
	 */
	public static final String FIELD_NAME  = "fieldName";
	
	public static final String COLUMN_NAME = "columnName";
	public static final String FIELD_COUNT = "fieldCount"; 
	public static final String REPO_VERSION = "repoVersion";
	public static final String PERCENTAGE = "%";
	public static final String SUCCESS_COUNT = "successCount";
    private TableConstants() {

		}

}
