/*
 * @author codeboard
 */
package com.ncloud.dl.constants.core;

/**
 * The Class ApplicationConstants.
 */
public class ApplicationConstants {


	/**
	 * ARIAL
	 */
	public static final String ARIAL = "Arial";
	
	/**
	 * hash_code
	 */
	public static final String HASH_CODE = "dclm_hash_code";
	
	/**
	 * Select query
	 */
	public static final String SELECT_DUPLICATE_CHECK = "SELECT * FROM \"%s\" WHERE " + HASH_CODE +  " = '%s';";
	
	/**
	 * XLSX
	 */
	public static final String XLSX = ".xls";
	
	/** The Constant REPLACE_CONSTANTS. */
	public static final String REPLACE_CONSTANTS = "%20";

	/** The Constant DL_. */
	public static final String DL_ = "dl_";
	
	/** The Constant ERROR_FIELD. */
	public static final String ERROR_FIELD = "err_flds";
	
	/** The Constant ALL. */
	public static final String ALL = "ALL";
	
	/** The Constant UNDERSCORE. */
	public static final String UNDERSCORE = "_";

	/** The Constant AUTHORIZATION. */
	public static final String AUTHORIZATION = "Authorization";

	/** The Constant MAIL_TEMPALTE_PATH. */
	public static final String MAIL_TEMPALTE_PATH = "/mail-template";
	
	/** The Constant MAIL__TEMPLATE_FILE. */
	public static final String MAIL__TEMPLATE_FILE = "email-template.ftl";
	
	/** The Constant DATA_LAKE. */
	public static final String DATA_LAKE = "Data Lake";

	/** The Constant BEARER. */
	public static final String BEARER = "Bearer ";

	/** The Constant BETWEEN. */
	public static final String BETWEEN = "BW";

	/** The Constant ERROR_FIELD_MAP. */
	public static final String ERROR_FIELD_MAP = "errorFields";

	/** The Constant COMMA. */
	public static final String COMMA = ",";

	/** The Constant DOT_REGEX. */
	public static final String DOT_REGEX = "\\.";

	/** The Constant DOUBLE_QUOTES. */
	public static final char DOUBLE_QUOTES = '"';
	
	/** The Constant SINGLE_QUOTES. */
	public static final String SINGLE_QUOTES = "'";
	
	/** The Constant WHERE. */
	public static final String WHERE = " where ";
	
	/** The Constant SELECT_QUERY. */
	public static final String SELECT_QUERY = "select * from ";
	
	/** The Constant ASTERIK. */
	public static final String ASTERIK = "*";
	
	/** The Constant HASHTAG. */
	public static final String HASHTAG = "#";
	
	/** The Constant KEYWORD. */
	public static final String KEYWORD = ".keyword";

	/** The Constant EMPTY_STRING. */
	public static final String EMPTY_STRING = " ";

	/** The Constant EQUAL. */
	public static final String EQUAL = "Equal";
	
	/** The Constant EQUAL_STRING. */
	public static final String EQUAL_STRING = "=";

	/** The Constant FILTER. */
	public static final String FILTER = "FILTER";

	/** The Constant FILTER_TYPE_BOOLEAN. */
	public static final String FILTER_TYPE_BOOLEAN = "Boolean";

	/** The Constant FILTER_TYPE_DATE. */
	public static final String FILTER_TYPE_DATE = "Date";

	/** The Constant FILTER_TYPE_DOUBLE. */
	public static final String FILTER_TYPE_DOUBLE = "Double";

	/** The Constant FILTER_TYPE_INTEGER. */
	public static final String FILTER_TYPE_INTEGER = "Integer";

	/** The Constant FILTER_TYPE_TEXT. */
	public static final String FILTER_TYPE_TEXT = "String";

	/** The Constant GT. */
	public static final String GT = "Gt";

	/** The Constant GTE. */
	public static final String GTE = "Ge";

	/** The Constant IDENTITY. */
	public static final String IDENTITY = "Identity";

	/** The Constant LIKE. */
	public static final String LIKE = "Like";

	/** The Constant IN. */
	public static final String IN = "IN";
	
	/** The Constant DATEFORMAT. */
	public static final String DATEFORMAT="yyyy-MM-dd HH:mm:ss";

	/** The Constant LT. */
	public static final String LT = "Lt";

	/** The Constant LTE. */
	public static final String LTE = "Le";

	/** The Constant MINUS_ONE. */
	public static final String MINUS_ONE = "-1";

	/** The Constant ONE. */
	public static final int ONE = 1;

	/** The Constant OPEN_BRACE. */
	public static final String OPEN_BRACE = "(";

	/** The Constant ORDERBY. */
	public static final String ORDERBY = "orderBy";

	/** The Constant ROUNDOFF. */
	public static final String ROUNDOFF = "ROUNDOFF";

	/** The Constant SET_IDENTITY. */
	public static final String SET_IDENTITY = "setIdentity";

	/** The Constant SLASH. */
	public static final String SLASH = "/";

	/** The Constant SORTING. */
	public static final String SORTING = "SORTING";

	/** The Constant TOO_MANY_REQUEST_FOUND. */
	public static final String TOO_MANY_REQUEST_FOUND = "Too Many Request found for the input URL : ";

	/** The Constant WITHOUT_SPACE. */
	public static final String WITHOUT_SPACE = "";

	/** The Constant ZERO. */
	public static final int ZERO = 0;

	/** The Constant FIVE. */
	public static final Integer FIVE = 5;

	/** The Constant DEFAULT_DATE_FORMAT. */
	public static final String DEFAULT_DATE_FORMAT = "MM/dd/yyyy";
	
	/** The Constant COMPANY_NAME. */
	public static final String COMPANY_NAME = "COMPANY_NAME";
	
	/** The Constant NEW_REPOSITORY. */
	public static final String NEW_REPOSITORY = "NEW_REPOSITORY";

	/** The Constant HYPHEN. */
	public static final String HYPHEN = "-";
	
	/** The Constant ERROR_MSG. */
	public static final String ERROR_MSG = "errorMsg";
	
	/** The Constant IDENTITY_MAP. */
	public static final String IDENTITY_MAP = "dclm_identity";

	/** The Constant DROP_DOWN. */
	public static final String DROP_DOWN = "Dropdown";

	/** The Constant REPOSITORY_CREATION. */
	public static final String REPOSITORY_CREATION= "Repository Creation";

	/** The Constant ID. */
	public static final String ID = "id";

	/** The Constant USER_NAME. */
	public static final String USER_NAME = "user_name";
	
	/** The Constant USER_INFO. */
	public static final String USER_INFO = "USER_NAME";

	/** The Constant EMAIL. */
	public static final String EMAIL = "email";

	/** The Constant USER_TYPE. */
	public static final String USER_TYPE = "user_type";

	/** The Constant ROLES. */
	public static final String ROLES = "roles";

	/** The Constant PLATFORM_IDENTITY. */
	public static final String PLATFORM_IDENTITY = "platform_identity";

	/** The Constant PLATFORM_DETAILS. */
	public static final String PLATFORM_DETAILS = "platform_details";

	/** The Constant COMPANY_ID. */
	public static final String COMPANY_ID = "company_id";

	/** The Constant DRAFTED. */
	public static final String DRAFTED ="Drafted";
	
	/** The Constant DP_USER_DETAILS. */
	public static final String DP_USER_DETAILS= "http://164.52.217.22:6063/api/user-details";

	/** The Constant GET_IMAGE. */
	public static final String GET_IMAGE = "/user-profile/get-profile";
	
	/** The Constant ALLOCATION_USER_TYPE. */
	public static final String ALLOCATION_USER_TYPE="allocationUserType";
	
	/** The Constant REPOSITORY_REPORT. */
	public static final String REPOSITORY_REPORT = "Repository Reports";
	
	/** The Constant DATA_LAKE_USER_INFO. */
	public static final String DATA_LAKE_USER_INFO = "/user-info";
	
	/** The Constant DATA_LAKE_PRIVILIGE_INFO. */
	public static final String DATA_LAKE_PRIVILIGE_INFO = "/user-privilege";
	
	/** The Constant COMPANY_NAME_LIST_URL. */
	public static final String COMPANY_NAME_LIST_URL = "/entitymanagement/get-company-id-And-Name-list";
	
	/** The Constant ERROR_MESSAGE. */
	public static final String ERROR_MESSAGE="Error Message";
	
    /**
     * Instantiates a new application constants.
     */
    private ApplicationConstants() {
		}

	/** The Constant ASSOCIATION_ID. */
	public static final String ASSOCIATION_ID = "associationId";
	
	/** The Constant TABLE_REPO. */
	public static final String TABLE_REPO = "_repo_scratch";
	
	/** The Constant API_REPO. */
	public static final String API_REPO = "-repo";

	/** The Constant DECIMAL. */
	public static final String DECIMAL = " DECIMAL DEFAULT NUL,";
	
	/** The Constant BOOLEAN. */
	public static final String BOOLEAN = " BOOLEAN DEFAULT NULL,";
	
	/** The Constant CLOASE_BRACES. */
	public static final String CLOASE_BRACES = " );";
	
	/** The Constant VARCHAR. */
	public static final String VARCHAR = " VARCHAR(300) DEFAULT NULL,";
	
	/** The Constant NULL. */
	public static final String NULL = "null";

	/** The Constant CREATE. */
	public static final String CREATE = "CREATE";
	
	/** The Constant SPACE. */
	public static final String SPACE = " ";

	/** The Constant TABLE. */
	public static final String TABLE = "TABLE";
	
	/** The Constant DATE. */
	public static final String DATE = " TIMESTAMP DEFAULT NULL,";
	
	/** The Constant FORMAT. */
	public static final String FORMAT = "yyyy-MM-dd";
	
	/** The Constant ID_PK. */
	public static final String ID_PK = "ID BIGSERIAL PRIMARY KEY NOT NULL";

	/** The Constant V1. */
	public static final Double V1 = 1.0;
	
	/** The Constant INSERT. */
	public static final String INSERT = "INSERT";
	
	/** The Constant SPACES. */
	public static final String SPACES = " ";
	
	/** The Constant INTO. */
	public static final String INTO = "INTO";
	
	/** The Constant OPEN_BRACES. */
	public static final String OPEN_BRACES = "(";
	
	/** The Constant CLOSE_BRACES. */
	public static final String CLOSE_BRACES = ")";
	
	/** The Constant VALUES. */
	public static final String VALUES = "VALUES";
	
	/** The Constant SEMICOLON. */
	public static final String SEMICOLON = ";";
	
	/** The Constant ERROR. */
	public static final String ERROR = "error";
	
	/** The Constant USER_ID. */
	public static final String USER_ID = "userId";
	
	/** The Constant COMPANY_NAMES. */
	public static final String COMPANY_NAMES = "companyName";
	
	/** The Constant REPOSITORY_ID. */
	public static final String REPOSITORY_ID = "repositoryId";
	
	/** The Constant REPO_NAME. */
	public static final String REPO_NAME = "repositoryName";
	
	/** The Constant TABLE_ROW_OPEN. */
	/*
	 * Mail Template
	 */
	public static final String TABLE_ROW_OPEN = "<tr>";
	
	/** The Constant TABLE_ROW_CLOSE. */
	public static final String TABLE_ROW_CLOSE = "</tr>";
	
	/** The Constant TABLE_DATA_CLOSE. */
	public static final String TABLE_DATA_CLOSE = "</td>";
	
	/** The Constant PARAGRAPH. */
	public static final String PARAGRAPH = "<p style='text-align: center; margin-bottom : 39.2px'>";
	
	/** The Constant REPOSITORY_NAME. */
	public static final String REPOSITORY_NAME = "<strong>REPOSITORY NAME : </strong>" ;
	
	/** The Constant PARAGRAPH_END. */
	public static final String PARAGRAPH_END = "</p>";
	
	/** The Constant NEXT_LINE. */
	public static final String NEXT_LINE = "\n";
	
	/** The Constant BREAK. */
	public static final String BREAK = "<br>";
	
	/** The Constant HTML_START. */
	public static final String HTML_START = "<html><body>";
	
	/** The Constant TABLE_ST. */
	public static final String TABLE_ST = "<table style='border-collapse: collapse; margin: 0px auto;text-align: center;'>";
	
	/** The Constant HTML_END. */
	public static final String HTML_END = "</table>" + "</body></html>";
	
	/** The Constant TEXT_STYLE. */
	public static final String TEXT_STYLE = "<td style='padding: 8px; font-style:  sans-serif; font-weight: 300;  text-align:center; font-family: Inter, sans-serif !important; border: 1px solid #000;min-width: 200px;'>";
	
	/** The Constant TABLE_STYLE. */
	public static final String TABLE_STYLE ="<td style='padding: 8px; font-style: sans-serif; color:#688F99; background-color:#e7edee; text-align:center; font-family: Inter, sans-serif !important; border: 1px solid #000; min-width: 200px;'>";
	
	/** The Constant HI. */
	public static final String HI = "<p>Hi ,</p>";
	
	/** The Constant CONTENT. */
	public static final String CONTENT = "<p> Please find the below attachement information shared from Data Lake.</p>";
	
	/** The Constant ABC_ASSOCIATION. */
	public static final String ABC_ASSOCIATION = "abc Association";
	
	/** The Constant APPLICATION_PDF. */
	public static final String APPLICATION_PDF = "application/pdf";
	
	/** The Constant DOWNLOAD_PDF. */
	public static final String DOWNLOAD_PDF = "shared-info.pdf";
	
	/** The Constant SET_SUBJECT. */
	public static final String SET_SUBJECT = "RE: DataLake: ";
	
	/** The Constant DUPLICATE_OPTION_VALUE. */
	public static final String DUPLICATE_OPTION_VALUE = "OPTIONVALUE";
	
	/** The Constant USER_ROLE_MAPPING. */
	public static final String USER_ROLE_MAPPING  = "UserRoleMapping";
	
	/** The Constant INDEX_MAX_RESULT_ADDITION. */
	/*
	 * Index addition and max pagination
	 */
	public static final Integer INDEX_MAX_RESULT_ADDITION=10000;
	
	/** The Constant INDEX_MAX_RESULT_WINDOW. */
	public static final String INDEX_MAX_RESULT_WINDOW="index.max_result_window";
	
	/** The Constant MAX_PAGINATION. */
	public static final Integer MAX_PAGINATION=50;
	
	/** The Constant KAFKA_TOPIC. */
	public static final String KAFKA_TOPIC="dlake_audit";
	
	/** The Constant DATA_LAKE_. */
	public static final String DATA_LAKE_ = "datalake.";
	
	/** The Constant IS_OVERRIDE. */
	public static final String IS_OVERRIDE = "isOverride";
	
	/** The Constant PLATFORM_TABLES. */
	public static final String PLATFORM_TABLES = "platformTables";
	
	
}
