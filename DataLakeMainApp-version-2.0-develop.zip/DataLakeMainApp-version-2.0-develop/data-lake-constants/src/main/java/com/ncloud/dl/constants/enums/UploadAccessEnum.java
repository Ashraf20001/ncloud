package com.ncloud.dl.constants.enums;

/**
 * The Enum UploadAccessEnum.
 */
public enum UploadAccessEnum {
	
	/** The association. */
	ASSOCIATION(1, "Association"),
	/** The insurance company. */
	INSURANCE_COMPANY(2, "Insurance Company"),
	/** The both. */
	BOTH(3, "Both");

	/** The user type id. */
	Integer userTypeId;
	
	/** The user type name. */
	String userTypeName;

	/**
	 * Instantiates a new upload access enum.
	 *
	 * @param userTypeId the user type id
	 * @param userTypeName the user type name
	 */
	UploadAccessEnum(Integer userTypeId, String userTypeName) {
		this.userTypeId = userTypeId;
		this.userTypeName = userTypeName;
	}


	/**
	 * Gets the upload access by id.
	 *
	 * @param userTypeId the user type id
	 * @return the upload access by id
	 */
	public static String getUploadAccessById(Integer userTypeId) {
		for (UploadAccessEnum enums : UploadAccessEnum.values()) {
			if (enums.getUserTypeId().equals(userTypeId)) {
				return enums.getUserTypeName();
			}
		}
		return null;
	}
	

	/**
	 * Gets the upload access id by user type.
	 *
	 * @param uploadAccess the upload access
	 * @return the upload access id by user type
	 */
	public static Integer getUploadAccessIdByUserType(String uploadAccess) {
		for (UploadAccessEnum enums : UploadAccessEnum.values()) {
			if (enums.getUserTypeName().equals(uploadAccess)) {
				return enums.getUserTypeId();
			}
		}
		return null;
	}
	

	/**
	 * Gets the upload access enum by id.
	 *
	 * @param id the id
	 * @return the upload access enum by id
	 */
	public static UploadAccessEnum getUploadAccessEnumById(Integer id) {
		for (UploadAccessEnum enums : UploadAccessEnum.values()) {
			if (enums.getUserTypeId().equals(id)) {
				return enums;
			}
		}
		return null;
	}
	

	/**
	 * Gets the user type id.
	 *
	 * @return the user type id
	 */
	public Integer getUserTypeId() {
		return userTypeId;
	}

	/**
	 * Sets the user type id.
	 *
	 * @param userTypeId the new user type id
	 */
	public void setUserTypeId(Integer userTypeId) {
		this.userTypeId = userTypeId;
	}

	/**
	 * Gets the user type name.
	 *
	 * @return the user type name
	 */
	public String getUserTypeName() {
		return userTypeName;
	}

	/**
	 * Sets the user type name.
	 *
	 * @param userTypeName the new user type name
	 */
	public void setUserTypeName(String userTypeName) {
		this.userTypeName = userTypeName;
	}
}
