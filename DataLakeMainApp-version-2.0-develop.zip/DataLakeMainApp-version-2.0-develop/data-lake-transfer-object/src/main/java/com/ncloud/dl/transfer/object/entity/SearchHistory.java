package com.ncloud.dl.transfer.object.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SearchHistory.
 */
@Data
@Entity
@Table(name="search_history")
@NoArgsConstructor
public class SearchHistory {

	
	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Integer id;
	
	/** The repository count. */
	@Column(name="repository_Count")
	private Integer repositoryCount;
	
	/** The record count. */
	@Column(name="records_Count")
	private Long recordCount;
	
	/** The search value. */
	@Column(name="search_Value")
	private String searchValue;
	
	/** The identity. */
	@Column(name="identity")
	private String identity;
	
	/** The search type. */
	@Column(name="searchType")
	private Integer searchType;
}
