package com.ncloud.dl.transfer.object.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

 

/**
* To string.
*
* @return the java.lang. string
*/
@Data

 

/**
* Instantiates a new base entity.
*
* @param createdBy the created by
* @param createdDate the created date
* @param id the id
* @param identity the identity
* @param isDeleted the is deleted
* @param modifiedBy the modified by
* @param modifiedDate the modified date
*/
@AllArgsConstructor

 

/**
* Instantiates a new base entity.
*/
@NoArgsConstructor
@MappedSuperclass
public class MandatoryFields {

 

    /**
     * CRT_USR_ID
     */
    public static final String CRT_USR_ID = "crtUsrId";

    /**
     * IS_DLT_STS
     */
    public static final String IS_DLT_STS = "isDltSts";

    /**
     * CrtDteTme
     */
    public static final String CrtDteTme = "crtDteTme";
   

 

    /** The is deleted. */
    @Column(name = "is_dlt_sts")
    private Boolean isDltSts;

 

    /** The created by. */
    @NonNull
    @Column(name = "created_by")
    private Integer crtUsrId;

 

    /** The modified by. */
    @Column(name = "modified_by")
    private Integer mdyUsrId;

 

    /** The modified date. */
    @Column(name = "mdy_dte_tme")
    private LocalDateTime mdyDteTme;

 

    /** The created date. */
    @NonNull
    @Column(name = "crt_dte_tme")
    private LocalDateTime crtDteTme;
    
    /**
     * identity
     */
    @NonNull
	@Column(name="identity")
	private String identity;

 

}
