package com.ncloud.dl.transfer.object.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class FileStorage.
 */
@Getter
@Setter
@Entity
@Table(name="file_storage")
@NoArgsConstructor
@AllArgsConstructor
public class FileStorage extends MandatoryFields {

	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	/** The repository id. */
	@Column(name = "repository_id")
	private Integer repositoryId;
	
	/** The file name. */
	@Column(name = "file_name")
	private String fileName;
	
}
