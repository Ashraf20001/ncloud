package com.ncloud.dl.transfer.object.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * The Enum NotificationStatusEnum.
 */
@Getter
@AllArgsConstructor
public enum NotificationStatusEnum {
   
	/** The submit. */
	SUBMIT(1,"Submit"),  
	
	/** The approved. */
	APPROVED(3,"Approve Repository"), 
	
	/** The rejected. */
	REJECTED(4,"Reject Repository"), 
	
	/** The request to modity. */
	REQUEST_TO_MODITY(5,"Request To Modify");
	
	/** The field type id. */
	private Integer fieldTypeId;
	
	/** The field type name. */
	private String fieldTypeName;
	
	/**
	 * @param value
	 * @return
	 */
	public static Integer getFieldTypeIdByTypeName(String value) {
		for (NotificationStatusEnum enums : NotificationStatusEnum.values()) {
			if (enums.getFieldTypeName().equals(value)) {
				return enums.getFieldTypeId();
			}
		}
		return null;
	}

	/**
	 * @param typeId
	 * @return
	 */
	public static String getFieldTypeNameByTypeId(Integer typeId) {
		for (NotificationStatusEnum enums : NotificationStatusEnum.values()) {
			if (enums.getFieldTypeId().equals(typeId)) {
				return enums.getFieldTypeName();
			}
		}
		return null;
	}
	
	/**
	 * @param typeId
	 * @return
	 */
	public static String getFieldTypeEnumByFieldType(String value) {
		for (NotificationStatusEnum enums : NotificationStatusEnum.values()) {
			if (enums.name().equals(value)) {
				return enums.getFieldTypeName();
			}
		}
		return null;
	}
}
