package com.ncloud.dl.transfer.object.dto;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FieldsConfiguratorDto.
 */
@Data
@NoArgsConstructor
public class FieldsConfiguratorDto {
	
	/**
	 * fieldName
	 */
	String fieldName;
	
	/**
	 * fieldType
	 */
	String fieldType;
	
	/**
	 * dataType
	 */
	String dataType;
	
	/**
	 * listOfOptions
	 */
	List<FieldOptionLinkingDto> listofFieldOptions;
	
	/**
	 * isMandatory
	 */
	Boolean isMandatory;
	
	/**
	 * searchType
	 */
	String searchType;
	
	/**
	 * errorMessage
	 */
	String errorMessage;
	
	/**
	 * fieldIdentity
	 */
	String fieldIdentity;
	
	/**
	 * fieldPosition
	 */
	Integer posistion;
	
	/**
	 * columnName
	 */
	String columnName;
	
	/**
	 * deleteOptions
	 */
	List<String> deletedOptions;
}
