package com.ncloud.dl.transfer.object.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * The Enum FieldSearchTypeEnum.
 */
@Getter
@AllArgsConstructor
public enum FieldSearchTypeEnum {
	
	/** The global search. */
	GLOBAL_SEARCH(1, "Global Search"),
	/** The repository search. */
	REPOSITORY_SEARCH(2, "Repository Search"),
	/** The both search. */
	BOTH_SEARCH(3, "Both");
	
	/** The id. */
	Integer id;
	
	/** The description. */
	String description;
	
	/**
	 * @param statusDesc
	 * @return
	 */
	public static Integer getFieldSearchTypeByDesc(String statusDesc) {
		for (FieldSearchTypeEnum enums : FieldSearchTypeEnum.values()) {
			if (enums.getDescription().equals(statusDesc)) {
				return enums.getId();
			}
		}
		return null;
	}
	
	
	/**
	 * @param statusId
	 * @return
	 */
	public static String getFieldSearchTypeById(Integer id) {
		for (FieldSearchTypeEnum enums : FieldSearchTypeEnum.values()) {
			if (enums.getId().equals(id)) {
				return enums.getDescription();
			}
		}
		return null;
	}

}
