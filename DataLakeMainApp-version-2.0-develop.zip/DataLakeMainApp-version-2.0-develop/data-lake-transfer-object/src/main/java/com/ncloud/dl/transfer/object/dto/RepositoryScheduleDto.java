package com.ncloud.dl.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class RepositoryScheduleDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RepositoryScheduleDto {

	/** The repository name. */
	private String repositoryName;
	
	/** The notification message. */
	private String notificationMessage;

	/** The is active scheduler. */
	private Boolean isActiveScheduler;

	/** The is active repository. */
	private Boolean isActiveRepository;

}
