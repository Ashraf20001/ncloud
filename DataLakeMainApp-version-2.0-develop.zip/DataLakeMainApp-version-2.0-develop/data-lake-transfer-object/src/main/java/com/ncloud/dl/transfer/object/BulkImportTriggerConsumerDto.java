package com.ncloud.dl.transfer.object;


import com.ncloud.dl.transfer.object.dto.BulkImportHistoryDto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BulkImportTriggerConsumerDto.
 */
@Data
@NoArgsConstructor
public class BulkImportTriggerConsumerDto {
	
	/** The bulk import history dto. */
	private BulkImportHistoryDto bulkImportHistoryDto;
    
    /** The page identity. */
    private String pageIdentity;
    
    /** The insurer. */
    private String insurer;
    
    /** The user id. */
    private Integer userId;
    
    /** The bulk import identity. */
    private String bulkImportIdentity;
    
    /** The upload type. */
    private String uploadType;
    
    /** The upload action. */
    private String uploadAction;
    
    /** The bulk upload id. */
    private Integer bulkUploadId;
    
    /** The file path. */
    private String filePath;
    
    /** The repository name. */
    private String repositoryName;
    
    /** The association id. */
    private Integer associationId;
}
