package com.ncloud.dl.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class RepositoryDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RepositoryDto {
	
	/**
	 * repositoryIdentity
	 */
	String fieldName;
	
	/** The repository name. */
	String repositoryName;
	
	/** The repo table name. */
	String repoTableName;
	
}
