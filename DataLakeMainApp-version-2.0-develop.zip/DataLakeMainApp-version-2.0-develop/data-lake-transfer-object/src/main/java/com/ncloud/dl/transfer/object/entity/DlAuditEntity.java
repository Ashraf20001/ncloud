package com.ncloud.dl.transfer.object.entity;
import java.time.LocalDateTime;

import javax.persistence.Id;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

/**
 * The Class DlAuditEntity.
 */
@Document(collection = "audit")
@Getter
@Setter
@ToString
@Accessors(chain = true)
public class DlAuditEntity {
    
    /** The id. */
    @Id
    private String id;

    /** The request url. */
    private String requestUrl;

    /** The user id. */
    private String userId;

    /** The audited date*/
    private LocalDateTime auditDate;

    /** The response. */
    private String response;
}
