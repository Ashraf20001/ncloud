package com.ncloud.dl.transfer.object.dto;

import java.time.LocalDate;
import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FieldRepositoryDto.
 */
@Data
@NoArgsConstructor
public class FieldRepositoryDto {
	
	/**
	 * FieldRepositoryDto
	 */
	String repositoryName;
	
	/**
	 * FieldRepositoryDto
	 */
	String repositoryId;
	
	/**
	 * repositoryDesc
	 */
	String repositoryDesc;
	
	/**
	 * uploadAccess
	 */
	String uploadAccess;
	
	/**
	 * isCommented
	 */
	Boolean isCommented;
	
	/**
	 * repositoryVersion
	 */
	Double repositoryVersion;
	
	/**
	 * repositoryStatus
	 */
	String repositoryStatus;
	
	/**
	 * repositoryIdentity
	 */
	String repositoryIdentity;
	
	/**
	 * isCloned
	 */
	Boolean isCloned;
	
	/**
	 * fieldRepositoryDto
	 */
	List<FieldsConfiguratorDto> fieldsConfiguratorDto;
	
	/**
	 * deletedFields
	 */
	List<String> deletedFields;
	
	/**
	 * updatedFields
	 */
	List<String> updatedFields;

	/**
	 * action
	 */
	String action;
	
	/**
	 * effectiveTo
	 */
	LocalDate effectiveTo;
	
}
