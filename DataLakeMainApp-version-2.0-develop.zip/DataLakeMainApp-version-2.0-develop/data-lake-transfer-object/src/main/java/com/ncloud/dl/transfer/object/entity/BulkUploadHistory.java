package com.ncloud.dl.transfer.object.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class BulkUploadHistory.
 */
@Getter
@Setter
@Entity
@Table(name="bulk_upload_history")
@NoArgsConstructor
@AllArgsConstructor
public class BulkUploadHistory extends MandatoryFields {

	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	/** The total count. */
	@Column(name = "total_cnt")
	private Integer totalCount;
	
	/** The success count. */
	@Column(name = "sucess_cnt")
	private Integer successCount;
	
	/** The failure count. */
	@Column(name = "failure_cnt")
	private Integer failureCount;
	
	/** The upload status. */
	@Column(name = "upld_sts")
	private Integer uploadStatus;
	
	/** The file storage. */
	@OneToOne
	@JoinColumn(name = "storage_id")
	private FileStorage fileStorage;
	
	/** The data repository. */
	@OneToOne
	@JoinColumn(name = "repository_id")
	private DataRepository dataRepository;
	
	/** The company id. */
	@Column(name = "company_id")
	private Integer companyId;
	
	/** The association id. */
	@Column(name = "association_id")
	private Integer associationId;
	
}
