package com.ncloud.dl.transfer.object.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The Class Comments.
 */
@Data
@Entity
@Table(name="comments")
@NoArgsConstructor
public class Comments extends MandatoryFields{
	
	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Integer id;

	/** The repository id. */
	@ManyToOne
	@JoinColumn(name = "repository_id")
	private DataRepository repositoryId;
	
	/** The comments. */
	@Column(name="repo_comments")
	private String comments;
  
    /** The is creator. */
    @Column(name="is_creator")
    private Integer isCreator;
  
}
