package com.ncloud.dl.transfer.object.enums;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * The Enum CreatorApprover.
 */
@Getter
@AllArgsConstructor
public enum CreatorApprover {

	/** The creator. */
	CREATOR(1, "Submitted","Submit Repository"),
	
	/** The approver. */
	APPROVER(2, "Approve", "Approve Repository"),
	
	/** The drafted. */
	DRAFTED(1,"Draft", "Draft Repository"),
	
	/** The rejector. */
	REJECTOR(2,"Reject", "Reject Repository"),
	
	/** The request modify. */
	REQUEST_MODIFY(2,"Request to modify", "Request Repository");

	/**
	 * typeId
	 */
	private Integer typeId;

	/**
	 * action
	 */
	private String action;
	
	/**
	 * privelege
	 */
	private String privelege;
	
	/**
	 * @param action
	 * @return
	 */
	public static List<String> getListOfPrivilegeByAction(String action){
		Integer enumId = getAuthorityTypeByPrivelegeId(action);
		List<String> listPfPrivilege = new ArrayList<>();
		for(CreatorApprover enums : CreatorApprover.values()) {
			if(enums.getTypeId().equals(enumId)) {
				listPfPrivilege.add(enums.getPrivelege());
			}
		}
		return listPfPrivilege;
	}
	
	/**
	 * @param value
	 * 
	 * @return
	 */
	public static Integer getAuthorityTypeByPrivelegeId(String action) {
		for (CreatorApprover enums : CreatorApprover.values()) {
				if ( enums.getAction().equals(action)) {
					return enums.getTypeId();
				}
			
		}
		return null;
	}
	
	/**
	 * Gets the authority type privelege id.
	 *
	 * @param action the action
	 * @return the authority type privelege id
	 */
	public static Integer getAuthorityTypePrivelegeId(String action) {
		for (CreatorApprover enums : CreatorApprover.values()) {
				if ( enums.getPrivelege().equals(action)) {
					return enums.getTypeId();
				}
			
		}
		return null;
	}
	
	/**
	 * Gets the authority type by privelege name.
	 *
	 * @param action the action
	 * @return the authority type by privelege name
	 */
	public static String getAuthorityTypeByPrivelegeName(String action) {
		for (CreatorApprover enums : CreatorApprover.values()) {
				if ( enums.getAction().equals(action)) {
					return enums.getPrivelege();
				}
			
		}
		return null;
	}
	
	/**
	 * @param privilegeList
	 * @return
	 */
	public static List<Integer> getPrivilegeIdByList(List<String> privilegeList) {
		List<Integer> privilegeId = new ArrayList<>();
		for(String enums : privilegeList) {
			privilegeId.add(getAuthorityTypeByPrivelegeId(enums));
		}
		return privilegeId;
	}
	
	/**
	 * @param privilegeList
	 * @return
	 */
	public static List<Integer> getPrivilegeIdByPrivilegeName(List<String> privilegeList) {
		List<Integer> privilegeId = new ArrayList<>();
		for(String enums : privilegeList) {
			privilegeId.add(getAuthorityTypePrivelegeId(enums));
		}
		return privilegeId;
	}
	
	/**
	 * @param value
	 * @return
	 */
	public static Integer getInverseAuthorityTypeById(Integer id) {
		for (CreatorApprover enums : CreatorApprover.values()) {
			if(!enums.getTypeId().equals(id)) {
				return enums.getTypeId();
			}
		}
		return null;
	}
	
	/**
	 * @param id
	 * @return
	 */
	public static String getUserRolePrivellageAction(Integer id) {
		for (CreatorApprover enums : CreatorApprover.values()) {
			if(enums.getTypeId().equals(id)) {
				return enums.name();
			}
		}
		return null;
	}
	
	/**
	 * @param enumName
	 * @return
	 */
	public static Integer getEnumIdByEnumName(String enumName) {
		for (CreatorApprover enums : CreatorApprover.values()) {
			if(enums.name().equals(enumName)) {
				return enums.getTypeId();
			}
		}
		return null;
	}
	
	

}
