package com.ncloud.dl.transfer.object.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * The Enum BulkUploadStatusEnum.
 */
@Getter
@AllArgsConstructor
public enum BulkUploadStatusEnum {
	
	/** The new. */
	NEW(1, "New"),
	/** The in progress. */
	IN_PROGRESS(2, "In Progress"),
	/** The completed. */
	COMPLETED(3, "Completed"),
	/** The failed. */
	FAILED(4, "Failed");
	
	/** The status id. */
	Integer statusId;
	
	/** The status desc. */
	String statusDesc;
	
	/**
	 * @param statusDesc
	 * @return
	 */
	public static Integer getBulkUploadStatusIdByDesc(String value) {
		for (BulkUploadStatusEnum enums : BulkUploadStatusEnum.values()) {
			if (enums.getStatusDesc().equals(value)) {
				return enums.getStatusId();
			}
		}
		return null;
	}
	
	
	/**
	 * @param statusId
	 * @return
	 */
	public static String getBulkUploadStatusDescById(Integer typeId) {
		for (BulkUploadStatusEnum enums : BulkUploadStatusEnum.values()) {
			if (enums.getStatusId().equals(typeId)) {
				return enums.getStatusDesc();
			}
		}
		return null;
	}
	

}
