package com.ncloud.dl.transfer.object.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * The Enum FieldTypeEnum.
 */
@Getter
@AllArgsConstructor
public enum FieldTypeEnum {

	/** The text box. */
	TEXT_BOX(1, "Text Box"), 
	
	/** The dropdown. */
	DROPDOWN(2, "Dropdown"), 
	
	/** The date. */
	DATE(3, "Date");

	/** The field type id. */
	private Integer fieldTypeId;
	
	/** The value. */
	private String value;

	/**
	 * @param value
	 * @return
	 */
	public static Integer getFieldTypeIdByTypeName(String value) {
		for (FieldTypeEnum enums : FieldTypeEnum.values()) {
			if (enums.getValue().equals(value)) {
				return enums.getFieldTypeId();
			}
		}
		return null;
	}

	/**
	 * @param typeId
	 * @return
	 */
	public static String getFieldTypeNameByTypeId(Integer typeId) {
		for (FieldTypeEnum enums : FieldTypeEnum.values()) {
			if (enums.getFieldTypeId().equals(typeId)) {
				return enums.getValue();
			}
		}
		return null;
	}
	
	/**
	 * @param typeId
	 * @return
	 */
	public static FieldTypeEnum getFieldTypeEnumByFieldType(String value) {
		for (FieldTypeEnum enums : FieldTypeEnum.values()) {
			if (enums.getValue().equals(value)) {
				return enums;
			}
		}
		return null;
	}
}
