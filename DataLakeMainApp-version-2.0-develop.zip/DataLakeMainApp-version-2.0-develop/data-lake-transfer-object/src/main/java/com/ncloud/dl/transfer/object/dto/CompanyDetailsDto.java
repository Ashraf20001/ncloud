package com.ncloud.dl.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CompanyDetailsDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CompanyDetailsDto {

    /**
     * companyId
     */
    Integer companyId;
	
	/**
	 * companyName
	 */
	String companyName;
}
