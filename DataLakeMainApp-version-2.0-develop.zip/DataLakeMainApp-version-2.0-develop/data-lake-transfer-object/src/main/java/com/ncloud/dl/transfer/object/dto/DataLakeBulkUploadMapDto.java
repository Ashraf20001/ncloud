package com.ncloud.dl.transfer.object.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

import lombok.Data;

/**
 * The Class DataLakeBulkUploadMapDto.
 */
@Data
public class DataLakeBulkUploadMapDto implements Serializable {
	
	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 5988016141095508139L;
	
	/**
	 * bulkUploadId
	 */
	private Integer bulkUploadId;
	
    /**
     * filePath
     */
    private String filePath;
    
    /**
     * repositoryName
     */
    private String repositoryName;
    
    /**
     * UserInfo
     */
    private UserInfo userInfo;
    
	/** The unique rows. */
	private List<HashMap<String, Object>> uniqueRows;

	/** The duplicate rows. */
	private List<HashMap<String, Object>> duplicateRows;

}
