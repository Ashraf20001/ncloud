package com.ncloud.dl.transfer.object.enums;

/**
 * The Enum RepeatFormatEnum.
 */
public enum RepeatFormatEnum {
	
	/** The day. */
	DAY,
	/** The week. */
	WEEK,
	/** The month. */
	MONTH,
	/** The year. */
	YEAR
}
