package com.ncloud.dl.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SchedulerNotificationDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SchedulerNotificationDto {
	
	/**
	 * notificationName
	 */
	
	private String notificationName;
	
	/**
	 * triggeredStatus
	 */
	
	private String triggeredStatus;
	
	/**
	 * message
	 */

	private String message;
	
	/**
	 * remainder
	 */

	private Integer remainder;
	
	/**
	 * status
	 */

	private Boolean status;
	
	
	/**
	 * Identity
	 */
	private String Identity;


}
