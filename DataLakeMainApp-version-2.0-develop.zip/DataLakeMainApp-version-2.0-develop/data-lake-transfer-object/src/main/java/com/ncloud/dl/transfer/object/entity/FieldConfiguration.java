package com.ncloud.dl.transfer.object.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class FieldConfiguration.
 */
@Audited
@Setter
@Getter
@Entity
@Table(name="field_config")
@NoArgsConstructor
public class FieldConfiguration extends Auditable<String> implements Serializable {
	
	/**
	 * VERSION ID
	 */
	private static final long serialVersionUID = 8246556758737874321L;

	/** The field id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="field_id")
	private Integer fieldId;
	
	/** The field name. */
	@Column(name="field_name")
	private String fieldName;
	
	/** The repo id. */
	@ManyToOne
	@JoinColumn(name="repo_id")
	private DataRepository repoId; 
	
	/** The data type. */
	@Column(name="data_type")
	private Integer dataType;
	
	/** The upd acs for. */
	@Column(name="upd_acs_for")
	private Integer updAcsFor;
	
	/** The is mandatory. */
	@Column(name="is_mandatory")
	private Boolean isMandatory;
	
	/** The err msg. */
	@Column(name="err_msg")
	private String errMsg;
	
	/** The field order. */
	@Column(name="field_order")
	private Integer fieldOrder;
	
	/** The field type. */
	@Column(name="field_type")
	private Integer fieldType;
	
	/** The search type. */
	@Column(name="search_type")
	private Integer searchType;
	
	/** The column name. */
	@Column(name = "column_name")
	private String columnName;
	
	/** The is dlt sts. */
	@Column(name = "is_dlt_sts")
	private Boolean isDltSts;
		
	/** The identity. */
	@Column(name ="identity")
	private String identity;
}
