package com.ncloud.dl.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FieldMapperDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FieldMapperDto {
	
	/**
	 * displayName 
	 */
	private String displayName;
	
	/**
	 * columnName
	 */
	private String columnName;

}
