package com.ncloud.dl.transfer.object.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class TableEntityMapping.
 */
@Data
@Entity
@Table(name ="table_entity_mapping")
@AllArgsConstructor
@NoArgsConstructor
public class TableEntityMapping {
	
	/** The id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    /** The table name. */
    @Column(name = "table_name")
    private String tableName;

    /** The display name. */
    @Column(name = "display_name")
    private String displayName;

    /** The parent table id. */
    @Column(name = "parent_table_id")
    private String parentTableId;

    /** The order. */
    @Column(name = "order")
    private Integer order;

    /** The platform. */
    @Column(name = "platform")
    private Integer platform;

    /** The join status. */
    @Column(name = "join_sts")
    private Boolean joinStatus;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private Boolean isDeleted;

}
