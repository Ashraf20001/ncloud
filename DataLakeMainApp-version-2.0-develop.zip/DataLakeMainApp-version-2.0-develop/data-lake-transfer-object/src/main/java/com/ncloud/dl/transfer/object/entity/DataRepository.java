package com.ncloud.dl.transfer.object.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

/**
 * The Class DataRepository.
 */
@Audited
@Data
@Entity
@Table(name="data_repository")
@NoArgsConstructor
public class DataRepository extends Auditable<String> implements Serializable {
	
	/**
	 * version
	 */
	private static final long serialVersionUID = 383810717840907017L;

	/** The Constant REPO_STATUS. */
	public static final String REPO_STATUS = "repoStatus";
	
	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Integer id;
	
	/** The repository id. */
	@Column(name="repo_id")
	private String repositoryId;
	
	/** The repo table name. */
	@Column(name="repo_table_name")
	private String repoTableName;
	
	/** The repo api name. */
	@Column(name="repo_api_name")
	private String repoApiName;
	
	/** The repository name. */
	@Column(name="repository_name")
	private String repositoryName;
	
	/** The repo description. */
	@Column(name="repo_description")
	private String repoDescription;
	
	/** The repo status. */
	@Column(name="repo_status")
	private Integer repoStatus;
	
	/** The upload access. */
	@Column(name="upload_access")
	private Integer uploadAccess;
	
	/** The is active. */
	@Column(name="is_active")
	private Boolean isActive;
	
	/** The effective from. */
	@Column(name="effective_from")
	private LocalDateTime effectiveFrom;
	
	/** The effective to. */
	@Column(name="effective_to")
	private LocalDate effectiveTo;
	
	/** The repo version. */
	@Column(name="repo_version")
	private Double repoVersion;
	
	/** The association id. */
	@Column(name="association_id")
	private Integer associationId;
	
	/** The parent repository. */
	@OneToOne
	@JoinColumn(name="parent_repository")
	private DataRepository parentRepository;
	
	/** The field count. */
	@Column(name ="field_count")
	private Integer fieldCount;
	
	/** The is dlt sts. */
	@Column(name = "is_dlt_sts")
	private Boolean isDltSts;

	/** The identity. */
	@NonNull
	@Column(name = "identity")
	private String identity;
	
}
