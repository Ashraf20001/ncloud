package com.ncloud.dl.transfer.object.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class ErrorMaintenance.
 */
@Getter
@Setter
@Entity
@Table(name="error_maintainence")
@NoArgsConstructor
@AllArgsConstructor
public class ErrorMaintenance extends MandatoryFields {

	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	/** The repository id. */
	@Column(name = "repository_id")
	private Integer repositoryId;
	
	/** The scratch id. */
	@Column(name = "scratch_id")
	private String scratchId;
	
	/** The bulk upload id. */
	@Column(name = "bulkupload_id")
	private Integer bulkUploadId;
	
	/** The field configuration. */
	@OneToOne
	@JoinColumn(name = "field_id")
	private FieldConfiguration fieldConfiguration;
	
	/** The error message. */
	@Column(name = "err_msg")
	private String errorMessage;
	
	/** The unique id. */
	@Column(name = "unique_id")
	private String uniqueId;
	
	/** The is duplicate. */
	@Column(name = "is_duplicate")
	private Boolean isDuplicate;
	
	/** The error fields. */
	@Column(name = "error_fields")
	private String errorFields;
	
}
