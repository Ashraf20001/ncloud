package com.ncloud.dl.transfer.object.dto;

import java.time.LocalDate;
import java.time.LocalTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CommentsDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CommentsDto {
	
	/**
	 * message
	 */
	private String message;
	
    /**
     * isCreator
     */
    private String isCreator;
    
    /**
     * isRepoCmts
     */
    private Boolean isRepoCmts;
    
    /**
     * isRightCmts
     */
    private Boolean isRightCmts;
    
    /**
     * userName
     */
    private String userName;
    
    /**
     * repoName
     */
    private String repoName;
    
    /**
     * createdDate
     */
    private LocalDate createdDate;
    
    /**
     * createdTime
     */
    private LocalTime createdTime;
    
    /**
     * repositoryName
     */
    private String repositoryName;
    
    /**
     * Identity
     */
    private String identity;
    
    /**
     * status
     */
    private String status;
    
    /**
     * action
     */
    private String action;
    
    /**
     * repoIdendity
     */
    private String repoIdentity;

	/**
	 * logoUrl
	 */
	private String logoUrl;
}
