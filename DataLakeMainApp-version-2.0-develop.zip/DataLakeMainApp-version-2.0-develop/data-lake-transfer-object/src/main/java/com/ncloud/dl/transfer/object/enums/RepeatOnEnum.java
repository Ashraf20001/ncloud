package com.ncloud.dl.transfer.object.enums;

/**
 * The Enum RepeatOnEnum.
 */
public enum RepeatOnEnum {
	
	/** The first. */
	FIRST,
	/** The second. */
	SECOND,
	/** The third. */
	THIRD,
	/** The fourth. */
	FOURTH,
	/** The fifth. */
	FIFTH
}
