package com.ncloud.dl.transfer.object.dto;

import java.time.LocalDateTime;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class NotificationDto.
 */
@Component
@Data
@AllArgsConstructor
@NoArgsConstructor
public class NotificationDto {

	/**
	 * notificationContent
	 */
	private String notificationContent;
	
	/**
	 * status
	 */
	private String status;
	
	/**
	 * isRepoCmts
	 */
	private Boolean isRepoCmts;
	
	/**
	 * isRead
	 */
	private Boolean isRead;
	
	/**
	 * notificationContent
	 */
	private String identity;
	
	/**
	 * createdDate
	 */
	private LocalDateTime createdDate;
	
	/**
	 * repositoryIdentity
	 */
	private String repositoryIdentity;
	
	/**
	 * logoUrl
	 */
	private String logoUrl;
	
	/**
	 * notificationJson
	 */
	private String notificationJson;
	
}
