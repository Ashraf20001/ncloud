package com.ncloud.dl.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BulkImportHistoryDto.
 */
@Data
@NoArgsConstructor
public class BulkImportHistoryDto {

    /** The success count. */
    private Integer successCount;
    
    /** The failure count. */
    private Integer failureCount;
    
    /** The total count. */
    private Integer totalCount;
    
    /** The Date. */
    private String Date;
    
    /** The Time. */
    private String Time;
    
    /** The identity. */
    private String identity;
    
    /** The repo identity. */
    private String repoIdentity;
    
    /** The file name. */
    private String fileName;
    
    /** The created date. */
    private String createdDate;
}