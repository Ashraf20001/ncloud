package com.ncloud.dl.transfer.object.dto;

import java.util.HashMap;
import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BulkUploadMapDto.
 */
@Data
@NoArgsConstructor
public class BulkUploadMapDto {
	
	/**
	 * listOfKeyValues
	 */
	private HashMap<String, Object> listOfKeyValues;
	
	/**
	 * repoTableName
	 */
	private String repoTableName;
	
	/**
	 * isErrorBooleanList
	 */
	private List<Boolean> isErrorBooleanList;
	
	/**
	 * repoId
	 */
	private Integer repoId;

}
