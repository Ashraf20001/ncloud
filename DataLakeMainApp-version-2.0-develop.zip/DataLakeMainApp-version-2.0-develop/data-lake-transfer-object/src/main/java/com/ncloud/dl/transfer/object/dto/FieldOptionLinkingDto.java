package com.ncloud.dl.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FieldOptionLinkingDto.
 */
@Data
@NoArgsConstructor
public class FieldOptionLinkingDto {
	
	 /**
	 * fieldOptionName
	 */
	String fieldOptionName;
	 
	 /**
	 * fieldOptionIdentity
	 */
	String fieldOptionIdentity;

}
