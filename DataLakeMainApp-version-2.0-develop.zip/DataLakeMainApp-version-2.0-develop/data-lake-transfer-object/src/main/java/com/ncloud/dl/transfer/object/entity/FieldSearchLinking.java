package com.ncloud.dl.transfer.object.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class FieldSearchLinking.
 */
@Setter
@Getter
@Entity
@Table(name="field_search_lnk")
@NoArgsConstructor
public class FieldSearchLinking extends MandatoryFields{
	
	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Integer id;
	
	/** The field id. */
	@ManyToOne
	@JoinColumn(name="field_id")
	private FieldConfiguration fieldId;
	
	/** The is glb repo. */
	@Column(name="is_glb_repo")
	private Integer isGlbRepo;

}
