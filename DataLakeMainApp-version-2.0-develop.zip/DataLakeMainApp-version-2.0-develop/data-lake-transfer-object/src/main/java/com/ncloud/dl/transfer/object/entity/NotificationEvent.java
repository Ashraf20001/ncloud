package com.ncloud.dl.transfer.object.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;

/**
 * The Class NotificationEvent.
 */
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "notification_event")
public class NotificationEvent {
	
	/** The event id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "event_id")
    private Integer eventId;
	
	/** The event name. */
	@Column(name = "event_name")
    private String eventName;
	
	/** The event code. */
	@Column(name = "event_code")
    private String eventCode;
	
	/** The identity. */
	@Column(name = "identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;

	/** The is deleted. */
	@Column(name = "is_dlt_sts")
	private Boolean isDeleted = false;
	
	/** The created by. */
    @NonNull
    @Column(name = "created_by")
    private Integer crtUsrId;

 

    /** The modified by. */
//    @NonNull
    @Column(name = "modified_by")
    private Integer mdyUsrId;

 

    /** The modified date. */
//    @NonNull
    @Column(name = "mdy_dte_tme")
    private LocalDateTime mdyDteTme;

 

    /** The created date. */
    @NonNull
    @Column(name = "crt_dte_tme")
    private LocalDateTime crtDteTme;
	
}
