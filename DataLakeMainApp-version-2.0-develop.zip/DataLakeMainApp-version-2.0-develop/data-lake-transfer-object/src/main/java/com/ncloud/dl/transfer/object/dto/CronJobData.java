package com.ncloud.dl.transfer.object.dto;

import java.util.List;

import com.ncloud.dl.transfer.object.enums.DayEnum;
import com.ncloud.dl.transfer.object.enums.MonthEnum;
import com.ncloud.dl.transfer.object.enums.RepeatFormatEnum;
import com.ncloud.dl.transfer.object.enums.RepeatOnEnum;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class CronJobData.
 */
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CronJobData {

	/** The start date with time. */
	private String startDateWithTime;
	
	/** The repeat count. */
	private Integer repeatCount;
	
	/** The repeat format. */
	private RepeatFormatEnum repeatFormat;
	
	/** The selected days. */
	private List<DayEnum> selectedDays;
	
	/** The selected date. */
	private Integer selectedDate;
	
	/** The repeat on. */
	private RepeatOnEnum repeatOn;
	
	/** The repeat on day. */
	private DayEnum repeatOnDay;
	
	/** The selected month. */
	private MonthEnum selectedMonth;
	
	/** The end date. */
	private String endDate;
}
