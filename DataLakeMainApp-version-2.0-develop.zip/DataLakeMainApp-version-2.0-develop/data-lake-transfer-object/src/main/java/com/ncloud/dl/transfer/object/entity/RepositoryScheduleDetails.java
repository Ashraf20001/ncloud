package com.ncloud.dl.transfer.object.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class RepositoryScheduleDetails.
 */
@Data
@Entity
@Table(name="REPOSITORY_SCHEDULE_DETAILS")
@NoArgsConstructor
public class RepositoryScheduleDetails extends MandatoryFields {
	
	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Integer id;
	
	/** The scheduler notification id. */
	@ManyToOne
    @JoinColumn(name = "schedule_notification_id")
	private SchedulerNotification schedulerNotificationId;
	
	/** The start datewithtime. */
	@Column(name="start_date_with_time")
	private String startDatewithtime;
	
	/** The repeat count. */
	@Column(name="repeat_count")
	private Integer repeatCount;
	
	/** The repeat format. */
	@Column(name="repeat_format")
	private String repeatFormat;
	
	/** The selected days. */
	@Column(name="selected_days")
	private String selectedDays;
	
	/** The selected date. */
	@Column(name="selected_date")
	private Integer selectedDate;
	
	/** The repeat on. */
	@Column(name="repeat_on")
	private String repeatOn;
	
	/** The repeat onday. */
	@Column(name="repeat_on_day")
	private String repeatOnday;
	
	/** The repeat on month. */
	@Column(name="repeat_on_month")
	private String repeatOnMonth;
	
	/** The selected month. */
	@Column(name="selected_month")
	private String selectedMonth;
	
	/** The end date. */
	@Column(name="end_date")
	private String endDate;
	
}
