package com.ncloud.dl.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class RepositoryScheduleDetailsDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RepositoryScheduleDetailsDto {

	/**
	 * NotificationMessage
	 */
	String NotificationMessage;

	/**
	 * remainderPeriod
	 */
	Integer repeatCount;

	/**
	 * startdate
	 */
	String startdate;

	/**
	 * endDate
	 */
	String endDate;

	/**
	 * repeatSchedular
	 */
	String repeatFormat;

	/**
	 * schedulerIdentity
	 */
	String schedulerIdentity;

	/**
	 * selectedDays
	 */
	String selectedDays;
	
	/**
	 * selectedDay
	 */
	Integer selectedDay;

	/**
	 * repeatOn
	 */
	String repeatOn;

	/**
	 * repeatOnDay
	 */
	String repeatOnDay;

	/**
	 * repeatOnMonth
	 */
	String repeatOnMonth;

	/**
	 * repeatOnMonth
	 */

	String selectedOnMonth;

	/**
	 * remainderPeriod
	 */
	Integer remainderPeriod;
	
	/**
	 * isActive
	 */
	Boolean isActive;
	
	
	/**
	 * triggeredStatus
	 */
	String triggeredStatus;
	
	/**
	 * repositoryName
	 */
	String repositoryName;
	
	/**
	 * time
	 */
	String time;


}
