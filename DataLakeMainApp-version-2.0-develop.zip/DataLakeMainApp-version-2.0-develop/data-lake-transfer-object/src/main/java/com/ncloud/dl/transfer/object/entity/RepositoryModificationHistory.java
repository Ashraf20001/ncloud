package com.ncloud.dl.transfer.object.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class RepositoryModificationHistory.
 */
@Data
@Entity
@Table(name="repository_modification_history")
@NoArgsConstructor
public class RepositoryModificationHistory extends MandatoryFields{
	
	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Integer id;
	
	/** The repo action. */
	@Column(name="repo_action")
	private String repoAction;
	
	/** The repository id. */
	@Column(name="repositroy_id")
	private Integer repositoryId;
	
	/** The log message. */
	@Column(name="log_message")
	private String logMessage;
	

}
