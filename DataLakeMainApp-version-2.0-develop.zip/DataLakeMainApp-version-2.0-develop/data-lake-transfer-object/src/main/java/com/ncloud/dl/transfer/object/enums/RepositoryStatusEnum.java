package com.ncloud.dl.transfer.object.enums;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * The Enum RepositoryStatusEnum.
 */
@Getter
@AllArgsConstructor
public enum RepositoryStatusEnum {
	
	/** The submitted. */
	SUBMITTED(1, "Submitted"),
	/** The draft. */
	DRAFT(2, "Drafted"),
	/** The approved. */
	APPROVED(3, "Approved"),
	/** The rejected. */
	REJECTED(4, "Rejected"),
	/** The disabled. */
	DISABLED(5, "Disabled");
	
	/** The status id. */
	Integer statusId;
	
	/** The status desc. */
	String statusDesc;
	
	
	/**
	 * @param statusDesc
	 * @return
	 */
	public static Integer getRepositoryStatusByDesc(String statusDesc) {
		for (RepositoryStatusEnum enums : RepositoryStatusEnum.values()) {
			if (enums.getStatusDesc().equals(statusDesc)) {
				return enums.getStatusId();
			}
		}
		return null;
	}
	
	
	/**
	 * @param statusId
	 * @return
	 */
	public static String getRepositoryStatusById(Integer statusId) {
		for (RepositoryStatusEnum enums : RepositoryStatusEnum.values()) {
			if (enums.getStatusId().equals(statusId)) {
				return enums.getStatusDesc();
			}
		}
		return null;
	}
	
	/**
	 * @param repositoryStatusList
	 * @return
	 */
	public static List<Integer> getRepositoryStatusIds(List<String> repositoryStatusList) {
		List<Integer> reposioryStatusIds = new ArrayList<>();
		for(String enums : repositoryStatusList) {
			reposioryStatusIds.add(getRepositoryStatusId(enums));
		}
		return reposioryStatusIds;
	}

	/**
	 * @param repositoryName
	 * @return
	 */
	public static Integer getRepositoryStatusId(String repositoryName) {
		for (RepositoryStatusEnum enums : RepositoryStatusEnum.values()) {
			if (enums.getStatusDesc().equalsIgnoreCase(repositoryName)) {
				return enums.getStatusId();
			}
		}
		return null;
	}
	
	/**
	 * Gets the all repository status.
	 *
	 * @return the all repository status
	 */
	public static List<String> getAllRepositoryStatus(){
		List<String> reposioryStatus = new ArrayList<>();
		for (RepositoryStatusEnum enums : RepositoryStatusEnum.values()) {
			reposioryStatus.add(enums.getStatusDesc());
		}
		return reposioryStatus;
	}

}
