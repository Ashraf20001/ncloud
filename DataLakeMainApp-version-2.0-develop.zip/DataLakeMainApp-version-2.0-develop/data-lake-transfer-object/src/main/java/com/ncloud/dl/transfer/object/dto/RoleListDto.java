package com.ncloud.dl.transfer.object.dto;

import java.util.List;

import lombok.Data;

/**
 * The Class RoleListDto.
 */
@Data
public class RoleListDto {
	
	/** The user role list. */
	public List<UserRoleDto> userRoleList;

}
