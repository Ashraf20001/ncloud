package com.ncloud.dl.transfer.object.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SchedulerNotification.
 */
@Entity
@Data
@Table(name="SCHEDULER_NOTIFICATION")
@NoArgsConstructor
public class SchedulerNotification extends MandatoryFields{
	
	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Integer id;
	
	/** The notification name. */
	@Column(name="notification_name")
	private String notificationName;
	
	/** The triggered status. */
	@Column(name="triggered_status")
	private String triggeredStatus;
	
	/** The message. */
	@Column(name="message")
	private String message;
	
	/** The remainder. */
	@Column(name="remainder")
	private Integer remainder;

	/** The repository id. */
	@ManyToOne
	@JoinColumn(name = "repository_id")
	private DataRepository repositoryId;
	
	/** The status. */
	@Column(name="status")
	private Boolean status;
}
