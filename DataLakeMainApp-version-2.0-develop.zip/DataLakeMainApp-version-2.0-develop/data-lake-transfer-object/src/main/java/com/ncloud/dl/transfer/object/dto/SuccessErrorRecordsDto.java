package com.ncloud.dl.transfer.object.dto;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SuccessErrorRecordsDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SuccessErrorRecordsDto {
	
	/**
	 * fieldMapperDto
	 */
	List<FieldMapperDto> fieldMapperDto;
	
	/**
	 * successErrorList
	 */
	List<Map<String, Object>> successErrorList;
	
}
