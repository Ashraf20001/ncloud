package com.ncloud.dl.transfer.object.dto;

import java.util.List;

import lombok.Data;

/**
 * The Class CustomSortingVo.
 */
@Data
public class CustomSortingVo {

	/**
	 * columnName
	 */
	private String columnName;
	
	/**
	 * isAsc
	 */
	private Boolean isAsc;
	
	/**
	 * primaryKeyId
	 */
	private List<Integer> repositoryPrimaryId;
}
