package com.ncloud.dl.transfer.object.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;

import org.hibernate.envers.Audited;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class Auditable.
 *
 * @param <T> the generic type
 */
@Audited
@Getter
@Setter
@EntityListeners(AuditingEntityListener.class)
@MappedSuperclass
public abstract class Auditable<T> {
	
	/**
	 * crtUsrId
	 */
	@CreatedBy
	@Column(name = "created_by")
	private Integer crtUsrId;

	/**
	 * mdyUsrId
	 */
	@LastModifiedBy
	@Column(name = "modified_by")
	private Integer mdyUsrId;

	/**
	 * mdyDteTme
	 */
	@LastModifiedDate
	@Column(name = "mdy_dte_tme")
	private LocalDateTime mdyDteTme;

	/**
	 * crtDteTme
	 */
	@CreatedDate
	@Column(name = "crt_dte_tme")
	private LocalDateTime crtDteTme;
    
}
