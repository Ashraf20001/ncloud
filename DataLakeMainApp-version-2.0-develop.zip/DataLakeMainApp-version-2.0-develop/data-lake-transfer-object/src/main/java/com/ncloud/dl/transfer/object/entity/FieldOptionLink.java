package com.ncloud.dl.transfer.object.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FieldOptionLink.
 */
@Audited
@Data
@Entity
@Table(name="field_option_mapping")
@NoArgsConstructor
public class FieldOptionLink extends Auditable<String> implements Serializable {

	
	/**
	 * VERSION ID
	 */
	private static final long serialVersionUID = 1906442592891895823L;

	/** The fldoption id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="field_option_id")
	private Integer fldoptionId;
	
	/** The field id. */
	@ManyToOne
	@JoinColumn(name="field_id")
	private FieldConfiguration fieldId;
	
	/** The dropdown options. */
	@Column(name="dropdown_option")
	private String dropdownOptions;
	
	/** The is dlt sts. */
	@Column(name = "is_dlt_sts")
	private Boolean isDltSts;

	/** The identity. */
	@Column(name = "identity")
	private String identity;
	
	
}
