package com.ncloud.dl.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserPrivillageDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserPrivillageDto {

	/**
	 * PrivillageId
	 */
	private Integer PrivillageId;

	/**
	 * PrivillageName
	 */
	private String PrivillageName;

}