package com.ncloud.dl.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BulkUploadHistoryDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BulkUploadHistoryDto {

	/**
	 * successCount
	 */
	private Integer successCount;
	
	/**
	 * failureCount
	 */
	private Integer failureCount;
	
	/**
	 * status
	 */
	private String status;
	
	/**
	 * totalCount
	 */
	private Integer totalCount;
	
	/**
	 * repositoryIdentity
	 */
	private String bulkUploadIdentity;
}
