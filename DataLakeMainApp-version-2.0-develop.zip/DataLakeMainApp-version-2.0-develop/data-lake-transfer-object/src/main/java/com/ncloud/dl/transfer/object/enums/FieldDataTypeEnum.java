package com.ncloud.dl.transfer.object.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * The Enum FieldDataTypeEnum.
 */
@Getter
@AllArgsConstructor
public enum FieldDataTypeEnum {

	/** The decimal. */
	DECIMAL(1, "Decimal"),
	/** The boolean. */
	BOOLEAN(2, "Boolean"),
	/** The string. */
	STRING(3, "String"),
	/** The number. */
	NUMBER(4, "Number"),
	/** The date. */
	DATE(5, "Date");
	
	/** The type id. */
	private Integer typeId;
	
	/** The value. */
	private String value;
	
	/**
	 * @param statusDesc
	 * @return
	 */
	public static Integer getFieldDataTypeByDesc(String value) {
		for (FieldDataTypeEnum enums : FieldDataTypeEnum.values()) {
			if (enums.getValue().equals(value)) {
				return enums.getTypeId();
			}
		}
		return null;
	}
	
	
	/**
	 * @param statusId
	 * @return
	 */
	public static String getFieldDataTypeById(Integer typeId) {
		for (FieldDataTypeEnum enums : FieldDataTypeEnum.values()) {
			if (enums.getTypeId().equals(typeId)) {
				return enums.getValue();
			}
		}
		return null;
	}
	
	
}
