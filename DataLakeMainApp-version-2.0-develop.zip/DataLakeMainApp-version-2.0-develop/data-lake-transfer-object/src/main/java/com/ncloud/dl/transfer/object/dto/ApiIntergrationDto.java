package com.ncloud.dl.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ApiIntergrationDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApiIntergrationDto {
	
	/** The search query. */
	String searchQuery;

}
