package com.ncloud.dl.transfer.object.dto;

import java.util.HashMap;

import lombok.Data;

/**
 * The Class CustomFilterSortingVo.
 */
@Data
public class CustomFilterSortingVo {

	/** The filter map. */
	private HashMap<String, String> filterMap;

	/** The sorting map. */
	private CustomSortingVo sortingMap;
}
