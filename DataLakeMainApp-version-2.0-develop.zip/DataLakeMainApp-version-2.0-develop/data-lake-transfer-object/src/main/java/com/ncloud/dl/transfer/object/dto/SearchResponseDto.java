package com.ncloud.dl.transfer.object.dto;

import lombok.Data;

/**
 * The Class SearchResponseDto.
 */
@Data
public class SearchResponseDto {

	/** The index. */
	private String index;
	
	/** The matched object. */
	private Object matchedObject;
	
}
