package com.ncloud.dl.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class SchedulerRequestDto.
 */
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SchedulerRequestDto {
	
	/** The claim id. */
	private Integer claimId;		//will be repository schedule details id

	/** The status. */
	private String status;			//will be repository identity for data lake

	/** The time interval. */
	private Integer timeInterval;
	
	/** The is receivable. */
	private Boolean isReceivable;	//not related to data lake
	
	/** The platform name. */
	private String platformName;
	
	/** The association id. */
	private Integer associationId;
	
	/** The is cron job. */
	private Boolean isCronJob;
	
	/** The cron data. */
	private CronJobData cronData;

}
