package com.ncloud.dl.transfer.object.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class DataRepositoryDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DataRepositoryDto {
	
	/**
	 * repositoryId
	 */
	private String repositoryId;
	
	/**
	 * repositoryTableName
	 */
	private String repositoryTableName;
	
	/**
	 * repositoryApiName
	 */
	private String repositoryApiName;
	
	/**
	 * repositoryName
	 */
	private String repositoryName;
	
	/**
	 * repositoryDescription
	 */
	private String repositoryDescription;
	
	/**
	 * repositoryStatus
	 */
	private String repositoryStatus;
	
	/**
	 * isActive
	 */
	private Boolean isActive;
	
	/**
	 * effectiveFrom
	 */
	private LocalDateTime effectiveFrom;
	
	/**
	 * effectiveTo
	 */
	private LocalDate effectiveTo;
	
	/**
	 * repositoryVersion
	 */
	private Double repositoryVersion;
	
	/**
	 * associationId
	 */
	private Integer associationId;
	
	/**
	 * numberOfFields
	 */
	private Integer numberOfFields;
	
	/**
	 * identity
	 */
	private String identity;
	
	/**
	 * id
	 */
	private Integer id;
	
	/**
	 * uploadAccess
	 */
	private Integer uploadAccess;

	
}
