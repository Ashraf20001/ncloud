package com.ncloud.dl.transfer.object.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class RepositoryNotification.
 */
@Data
@Entity
@Table(name="repository_notification")
@NoArgsConstructor
public class RepositoryNotification extends MandatoryFields{
	
	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Integer id;
	
	/** The repository id. */
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "repository_id")
	private DataRepository repositoryId;
	
	/** The last acted. */
	@Column(name="last_acted")
	private Integer lastActed;
	
	/** The to notify. */
	@Column(name="to_notify")
	private Integer toNotify;
	
	/** The is read. */
	@Column(name="is_read_sts")
	private Boolean isRead;
	
	/** The is repo cmts. */
	@Column(name="is_repo_cmts")
	private Boolean isRepoCmts;
	
	/** The notification message. */
	@Column(name="notification_message")
	private String notificationMessage;
	
    /** The replace template data. */
    @Column(name="replace_template")
	private String replaceTemplateData;

}
