package com.ncloud.dl.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserDetailsDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDetailsDto {
	
	/**
	 * userName
	 */
	private Integer id;
	
	/**
	 * userId
	 */
	private String username;

}
