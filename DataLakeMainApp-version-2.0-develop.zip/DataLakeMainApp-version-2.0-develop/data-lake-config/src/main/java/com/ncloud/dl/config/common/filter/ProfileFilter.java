/*
 * @author codeboard
 */
package com.ncloud.dl.config.common.filter;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;


/**
 * The Class ProfileFilter.
 */
@Component
@Qualifier("profileFilter")
public class ProfileFilter implements IDataFilter {

	/** The logger. */
	Logger logger = LoggerFactory.getLogger(ProfileFilter.class);

	/**
	 * Gets the filter.
	 *
	 * @param root the root
	 * @param key the key
	 * @return the filter
	 */
	@Override
	public Predicate getFilter(Root<?> root, Object key) {
		return null;
	}

}
