/*
 * @author codeboard
 */
package com.ncloud.dl.config.property;

/**
 * The Enum DbType.
 */
public enum DbType {
	/**
	 * The master & TEST .
	 */
	MASTER, TEST
}