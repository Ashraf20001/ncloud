/*
 * @author codeboard
 */
package com.ncloud.dl.config.model;

import java.util.List;

/**
 * The Class FilterSupportVo.
 */
public class FilterSupportVo {

	/**
	 * The inner filter.
	 */
	private List<FilterOrSortingVo> innerFilter;

	/**
	 * The root filter list.
	 */
	private List<FilterOrSortingVo> rootFilterList;

	/**
	 * Gets the inner filter.
	 *
	 * @return the inner filter
	 */
	public List<FilterOrSortingVo> getInnerFilter() {
		return innerFilter;
	}

	/**
	 * Gets the root filter list.
	 *
	 * @return the root filter list
	 */
	public List<FilterOrSortingVo> getRootFilterList() {
		return rootFilterList;
	}

	/**
	 * Sets the inner filter.
	 *
	 * @param innerFilter the new inner filter
	 */
	public void setInnerFilter(List<FilterOrSortingVo> innerFilter) {
		this.innerFilter = innerFilter;
	}

	/**
	 * Sets the root filter list.
	 *
	 * @param rootFilterList the new root filter list
	 */
	public void setRootFilterList(List<FilterOrSortingVo> rootFilterList) {
		this.rootFilterList = rootFilterList;
	}

}