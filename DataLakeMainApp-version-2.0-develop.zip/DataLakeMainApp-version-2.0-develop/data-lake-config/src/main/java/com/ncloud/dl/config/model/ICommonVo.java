/*
 * @author codeboard
 */
package com.ncloud.dl.config.model;

/**
 * The Interface CommonVo.
 */
public interface ICommonVo {

}
