package com.ncloud.dl.config.property;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

import com.ncloud.dl.constants.core.PropertyConstants;
import com.ncloud.dl.constants.serverproperties.PropertyValueProvider;
import com.ncloud.dl.crypto.core.TwoWayEncryption;

import lombok.RequiredArgsConstructor;



/**
 * The Class EnvironmentProperties.
 */
@Configuration
@RequiredArgsConstructor
public class EnvironmentProperties {
	
	/**
	 * The Constant logger.
	 */
	private static final Logger logger = LoggerFactory.getLogger(EnvironmentProperties.class);
	
	/** The configuration provider. */
	private final PropertyValueProvider configurationProvider;	
	
	/** The enc. */
	private final TwoWayEncryption enc;
	
	/** The data base name. */
	private String dataBaseName = "";

	/**
	 * Gets the data source url.
	 *
	 * @return the data source url
	 */
	public String getDataSourceUrl() {
		return configurationProvider.getMysqlDataSourceUrl();
	}
	
	/**
	 * Gets the driver name.
	 *
	 * @return the driver name
	 */
	public String getDriverName() {
		return configurationProvider.getMysqlDriver();
	}

	/**
	 * Gets the jdbc password.
	 *
	 * @return the jdbc password
	 */
	public String getJdbcPassword() {
		return enc.doDecryption(configurationProvider.getMysqlPassword());
	}
	
	/**
	 * Gets the jdbc url.
	 *
	 * @return the jdbc url
	 */
	public String getJdbcUrl() {
		String url = replaceDateBaseName(configurationProvider.getMysqlDataSourceUrl());
		logger.info(url);
		url = url.replace(PropertyConstants.MAIN_APP_MYSQL_IP,
				configurationProvider.getMysqlIp());
		url = url.replace(PropertyConstants.MAIN_APP_MYSQL_PORT,
				configurationProvider.getMysqlPort());
		return url;
	}
	
	/**
	 * Gets the jdbc user.
	 *
	 * @return the jdbc user
	 */
	public String getJdbcUser() {
		return enc.doDecryption(configurationProvider.getMysqlUsername());
	}
	
	/**
	 * Gets the my sql date base.
	 *
	 * @return the my sql date base
	 */
	public String getMySqlDateBase() {
		if (dataBaseName.isEmpty()) {
			dataBaseName = configurationProvider.getMysqlDataBase();
		}
		return dataBaseName;
	}
	
	/**
	 * Gets the sql ip.
	 *
	 * @return the sql ip
	 */
	public String getSqlIp() {
		return enc.doDecryption(configurationProvider.getMysqlIp());
	}

	/**
	 * Gets the sql port.
	 *
	 * @return the sql port
	 */
	public String getSqlPort() {
		return  enc.doDecryption(configurationProvider.getMysqlPort());
	}

	/**
	 * Replace date base name.
	 *
	 * @param data the data
	 * @return the string
	 */
	public String replaceDateBaseName(String data) {
		data = data.replace(PropertyConstants.DB_NAME, getMySqlDateBase());
		return data;
	}
	
	/**
	 * Gets the jdbc driver.
	 *
	 * @return the jdbc driver
	 */
	public String getJdbcDriver() {
		return configurationProvider.getMysqlDriver();
	}
	
	/**
	 * Gets the time zone.
	 *
	 * @return the time zone
	 */
	public String getTimeZone() {
		return configurationProvider.getTimeZone();
	}
	
	/**
	 * Gets the date format.
	 *
	 * @return the date format
	 */
	public String getDateFormat() {
		return configurationProvider.getDateFormat();
	}
	
	/**
	 * Gets the time format.
	 *
	 * @return the time format
	 */
	public String getTimeFormat() {
		return configurationProvider.getTimeFormat();
	}
	
	/**
	 * Gets the currency format.
	 *
	 * @return the currency format
	 */
	public String getCurrencyFormat() {
		return configurationProvider.getCurrencyFormat();
	}
	
	/**
	 * Gets the country code.
	 *
	 * @return the country code
	 */
	public String getCountryCode() {
		return configurationProvider.getCountryCode();
	}
	
	/**
	 * Gets the file download url.
	 *
	 * @return the file download url
	 */
	public String getFileDownloadUrl() {
		return configurationProvider.getFileDownloadUrl();
	}

    /**
     * Gets the from E mail.
     *
     * @return the from E mail
     */
    public String getFromEMail() {
		return configurationProvider.getSpringMailUsername();
    }

    /**
     * Gets the file upload path.
     *
     * @return the file upload path
     */
    public String getFileUploadPath() {
		return configurationProvider.getFileUploadPath();
    }
    
    /**
     * Gets the send email name.
     *
     * @return the send email name
     */
    public String getSendEmailName() {
		return configurationProvider.getSendEmailName();
    }

	/**
	 * Gets the common service path.
	 *
	 * @return the common service path
	 */
	public String getCommonServicePath() {
		return configurationProvider.getCommonServicePath();
	}

	/**
	 * Gets the url.
	 *
	 * @return the url
	 */
	public String getUrl() {
		return configurationProvider.getFrontendUrl();
	}
	
	/**
	 * Gets the notification scheduler trigger url.
	 *
	 * @return the notification scheduler trigger url
	 */
	public String getNotificationSchedulerTriggerUrl() {
		return configurationProvider.getNotificationSchedulerTriggerUrl();
	}

	/**
	 * Gets the notification status.
	 *
	 * @return the notification status
	 */
	public String getNotificationStatus() {
		return configurationProvider.getNotificationUpdateStatus();
	}

	/**
	 * Gets the upload path.
	 *
	 * @return the upload path
	 */
	public String getUploadPath() {
		return configurationProvider.getUploadPath();
	}
	
	/**
	 * Gets the elastic search host.
	 *
	 * @return the elastic search host
	 */
	public String getElasticSearchHost() {
		return configurationProvider.getElasticSearchHost();
	}
	
	/**
	 * Gets the elastic search port.
	 *
	 * @return the elastic search port
	 */
	public String getElasticSearchPort() {
		return configurationProvider.getElasticSearchPort();
	}

    /**
     * Gets the kaf ka replication factor.
     *
     * @return the kaf ka replication factor
     */
    public String getKafKaReplicationFactor() {
		return configurationProvider.getSpringKafkaReplicationFactor();
    }
    
    /**
     * Gets the kaf ka partitions.
     *
     * @return the kaf ka partitions
     */
    public String getKafKaPartitions() {
		return configurationProvider.getSpringKafkaPartitions();
    }
    
    /**
     * Gets the elastic sync up kafka.
     *
     * @return the elastic sync up kafka
     */
    public String getElasticSyncUpKafka() {
		return configurationProvider.getElasticSyncupKafka();
    }

    /**
     * Gets the kafka converter.
     *
     * @return the kafka converter
     */
    public String getKafkaConverter() {
		return configurationProvider.getSpringKafkaConverter();
    }
    
    /**
     * Gets the elastic search schema.
     *
     * @return the elastic search schema
     */
    public String getElasticSearchSchema() {
		return configurationProvider.getElasticSearchSchema();
    }
    
    /**
     * Gets the elastic search username.
     *
     * @return the elastic search username
     */
    public String getElasticSearchUsername() {
		return configurationProvider.getElasticSearchUsername();
    }
    
    /**
     * Gets the elastic search password.
     *
     * @return the elastic search password
     */
    public String getElasticSearchPassword() {
		return configurationProvider.getElasticSearchPassword();
    }
}