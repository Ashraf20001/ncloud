/*
 * @author codeboard
 */
package com.ncloud.dl.config.common.filter;

import java.util.EnumMap; 
import java.util.Map;

import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;

/**
 * A factory for creating DataFilter objects.
 */
@Component
@RequiredArgsConstructor
public class DataFilterFactory {

	/**
	 * The filter map.
	 */
	private Map<FilterNameEnum, IDataFilter> filterMap = null;

	/**
	 * The profile filiter.
	 */
	@Qualifier("profileFilter")
	private final IDataFilter profileFiliter;

	/**
	 * Builds the map.
	 */
	@PostConstruct
	private void buildMap() {
		filterMap = new EnumMap<>(FilterNameEnum.class);
		filterMap.put(FilterNameEnum.PROFILE_FILTER, profileFiliter);
	}

	/**
	 * Gets the filter by name.
	 *
	 * @param filterName the filter name
	 * @return the filter by name
	 */
	public IDataFilter getFilterByName(FilterNameEnum filterName) {
		return filterMap.get(filterName);
	}
}