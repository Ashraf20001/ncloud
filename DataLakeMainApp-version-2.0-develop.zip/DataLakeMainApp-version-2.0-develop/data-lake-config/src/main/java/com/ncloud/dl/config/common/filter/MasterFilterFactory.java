/*
 * @author codeboard
 */
package com.ncloud.dl.config.common.filter;

import java.util.HashMap; 
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.ncloud.dl.constants.core.ApplicationConstants;




/**
 * A factory for creating MasterFilter objects.
 */
@Component
public class MasterFilterFactory {

	/**
	 * The bw filter.
	 */
	@Qualifier("BWFilter")
	private IMasterFilter bwFilter;

	/**
	 * The equals filter.
	 */
	@Qualifier("EqualFilter")
	private IMasterFilter equalsFilter;

	/**
	 * The gte filter.
	 */
	@Qualifier("GTEFilter")
	private IMasterFilter gteFilter;

	/**
	 * The gt filter.
	 */
	@Qualifier("GTFilter")
	private IMasterFilter gtFilter;

	/**
	 * The like filter.
	 */
	@Qualifier("LikeFilter")
	private IMasterFilter likeFilter;

	/**
	 * The lte filter.
	 */
	@Qualifier("LTEFilter")
	private IMasterFilter lteFilter;

	/**
	 * The lt filter.
	 */
	@Qualifier("LTFilter")
	private IMasterFilter ltFilter;

	/**
	 * The master filter factory map.
	 */
	private Map<String, IMasterFilter> masterFilterFactoryMap = null;

	/**
	 * The round off filter.
	 */
	@Qualifier("RoundOffFilter")
	private IMasterFilter roundOffFilter;

	/**
	 * The sorting filters.
	 */
	@Qualifier("SortingFilters")
	private IMasterFilter sortingFilters;
	
	@Qualifier("INFilter")
	private IMasterFilter inFilter;

	/**
	 * Bulid map.
	 */
	@PostConstruct
	public void bulidMap() {
		masterFilterFactoryMap = new HashMap<>();
		masterFilterFactoryMap.put(ApplicationConstants.EQUAL, equalsFilter);
		masterFilterFactoryMap.put(ApplicationConstants.LIKE, likeFilter);
		masterFilterFactoryMap.put(ApplicationConstants.GTE, gteFilter);
		masterFilterFactoryMap.put(ApplicationConstants.GT, gtFilter);
		masterFilterFactoryMap.put(ApplicationConstants.LTE, lteFilter);
		masterFilterFactoryMap.put(ApplicationConstants.LT, ltFilter);
		masterFilterFactoryMap.put(ApplicationConstants.BETWEEN, bwFilter);
		masterFilterFactoryMap.put(ApplicationConstants.ORDERBY, sortingFilters);
		masterFilterFactoryMap.put(ApplicationConstants.ROUNDOFF, roundOffFilter);
		masterFilterFactoryMap.put(ApplicationConstants.IN, inFilter);
	}

	/**
	 * Gets the filter by name.
	 *
	 * @param filterName the filter name
	 * @return the filter by name
	 */
	public IMasterFilter getFilterByName(String filterName) {
		return masterFilterFactoryMap.get(filterName);
	}

}
