/*
 * @author codeboard
 */
package com.ncloud.dl.config.property;

import java.beans.PropertyVetoException; 

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.ncloud.dl.config.property.DataSourceConfig;
import com.mchange.v2.c3p0.ComboPooledDataSource;



/**
 * The Class DataSourceConfig.
 */
@Configuration
@EnableTransactionManagement
public class DataSourceConfig {

	/**
	 * The Constant logger.
	 */
	private static final Logger logger = LoggerFactory.getLogger(DataSourceConfig.class);

	/**
	 * The master data source.
	 */
	private final ComboPooledDataSource masterDataSource = new ComboPooledDataSource();

	/**
	 * Gets the master data source.
	 *
	 * @return the master data source
	 * @throws ApplicationException
	 */
	@Autowired
	@Bean(name = "masterDataSource")
	@Primary
	public DataSource getMasterDataSource(DatabaseProperties databaseProperties) {
		try {
			masterDataSource.setDriverClass(databaseProperties.getJdbcDriver());
			masterDataSource.setJdbcUrl(databaseProperties.getJdbcUrl());
			masterDataSource.setUser(databaseProperties.getJdbcUser());
			masterDataSource.setPassword(databaseProperties.getJdbcPassword());
		} catch (PropertyVetoException e) {
			logger.error("Can't Set Data Source for Master %s", e);
		}

		return masterDataSource;
	}

}
