/*
 * @author codeboard
 */
package com.ncloud.dl.config.master;

import javax.persistence.criteria.CriteriaBuilder; 
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.config.common.filter.IMasterFilter;
import com.ncloud.dl.config.infrastructure.DataTypeConvertor;
import com.ncloud.dl.config.model.FilterOrSortingVo;

import lombok.RequiredArgsConstructor;




/**
 * The Class LTEFilter.
 */
@Service
@Qualifier("LTEFilter")
@RequiredArgsConstructor
public class LTEFilter implements IMasterFilter {

	/**
	 * The data type convertor.
	 */
	private final DataTypeConvertor dataTypeConvertor;

	/**
	 * Gets the filter predicate.
	 *
	 * @param root     the root
	 * @param builder  the builder
	 * @param filterVo the filter vo
	 * @param criteria the criteria
	 * @return the filter predicate
	 * @throws ApplicationException the application exception
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Predicate getFilterPredicate(From<?, ?> root, CriteriaBuilder builder, FilterOrSortingVo filterVo,
			CriteriaQuery<?> criteria) throws ApplicationException {
		String[] columnNames = getColumnNames(filterVo.getColumnName());
		Path<Comparable> path = getPath(root, columnNames);
		Comparable com = dataTypeConvertor.converToRealDataType(filterVo.getValue(), filterVo.getType());
		return builder.lessThanOrEqualTo(path, com);
	}

}
