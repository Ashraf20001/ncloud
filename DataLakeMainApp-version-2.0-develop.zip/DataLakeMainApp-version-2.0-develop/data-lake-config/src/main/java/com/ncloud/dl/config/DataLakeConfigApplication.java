package com.ncloud.dl.config;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
@SpringBootApplication
@ComponentScan("com.ncloud.dl.*")
public class DataLakeConfigApplication {

	public static void main(String[] args) {
		
	}

}
