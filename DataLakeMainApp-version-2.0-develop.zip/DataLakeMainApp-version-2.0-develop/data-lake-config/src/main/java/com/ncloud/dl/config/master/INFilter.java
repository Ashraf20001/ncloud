package com.ncloud.dl.config.master;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.ncloud.dl.constants.core.ApplicationConstants;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.utils.core.ApplicationUtils;
import com.ncloud.dl.config.common.filter.IMasterFilter;
import com.ncloud.dl.config.model.FilterOrSortingVo;

/**
 * The Class INFilter.
 */
@Service
@Qualifier("INFilter")
public class INFilter implements IMasterFilter {
	


	/**
	 * Gets the filter predicate.
	 *
	 * @param root the root
	 * @param builder the builder
	 * @param filterVo the filter vo
	 * @param criteria the criteria
	 * @return the filter predicate
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Predicate getFilterPredicate(From<?, ?> root, CriteriaBuilder builder, FilterOrSortingVo filterVo,
			CriteriaQuery<?> criteria) throws ApplicationException {
		String[] columnNames = getColumnNames(filterVo.getColumnName());
		Predicate predicate = null;
		Expression<String> path = getPath(root, columnNames);
		if (ApplicationUtils.isValidList(filterVo.getIntgerValueList())) {
			predicate = builder.and(path.in(filterVo.getIntgerValueList()));
		} else if (Boolean.FALSE.equals(ApplicationUtils.isValidList(filterVo.getIntgerValueList()))
				&& filterVo.getValue() != null
				&& filterVo.getValue().trim().equalsIgnoreCase(ApplicationConstants.ALL)) {
			predicate = builder.and(builder.isNull(path));
		} else if (ApplicationUtils.isValidList(filterVo.getValueList())) {
			predicate = builder.and(path.in(filterVo.getValueList()));
		} else if (Boolean.FALSE.equals(ApplicationUtils.isValidList(filterVo.getValueList()))
				&& filterVo.getValue().trim().equalsIgnoreCase(ApplicationConstants.ALL)) {
			predicate = builder.and(builder.isNull(path));
		} else {
			predicate = builder.and(path.in(new ArrayList<>(List.of(-1))));
		}
		return predicate;
	}

}
