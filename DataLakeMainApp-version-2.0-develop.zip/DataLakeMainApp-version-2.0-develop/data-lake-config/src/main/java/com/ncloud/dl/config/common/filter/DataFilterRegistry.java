/*
 * @author codeboard
 */
package com.ncloud.dl.config.common.filter;

import java.util.EnumMap; 
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

/**
 * The Class DataFilterRegistry.
 */
@Component
public class DataFilterRegistry {

	/**
	 * The Constant filterRegisty.
	 */
	private static final Map<Object, Map<FilterNameEnum, String>> filterRegisty = new HashMap<>();

	/**
	 * Adds the.
	 *
	 * @param key             current object
	 * @param filterNameEnum  which filter we want
	 * @param referenceColumn the reference column
	 */
	public void add(Object key, FilterNameEnum filterNameEnum, String referenceColumn) {
		if (key == null) {
			return;
		}

		if (filterRegisty.get(key) == null) {
			filterRegisty.put(key, new EnumMap<>(FilterNameEnum.class));
		}

		filterRegisty.get(key).put(filterNameEnum, referenceColumn);
	}

	/**
	 * Gets the data filters.
	 *
	 * @param key the key
	 * @return the data filters
	 */
	public Map<FilterNameEnum, String> getDataFilters(Object key) {
		return filterRegisty.get(key);
	}

}
