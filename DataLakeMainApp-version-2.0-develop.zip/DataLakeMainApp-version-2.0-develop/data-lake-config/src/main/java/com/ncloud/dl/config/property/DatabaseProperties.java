/*
 * @author codeboard
 */
package com.ncloud.dl.config.property;
 
import org.springframework.context.annotation.Configuration;
import com.ncloud.dl.constants.core.PropertyConstants;

import lombok.RequiredArgsConstructor;

/**
 * The Class DatabaseProperties.
 */
@Configuration
@RequiredArgsConstructor
public class DatabaseProperties {

	/**
	 * The data base name.
	 */
	private String dataBaseName = "";

	/**
	 * The environment.
	 */
	private final EnvironmentProperties environmentProperties;

	/**
	 * Gets the jdbc driver.
	 *
	 * @return the jdbc driver
	 */
	public String getJdbcDriver() {
		return environmentProperties.getJdbcDriver();
	}

	/**
	 * Gets the jdbc password.
	 *
	 * @return the jdbc password
	 */
	public String getJdbcPassword() {
		return environmentProperties.getJdbcPassword().trim();
	}

	/**
	 * Gets the jdbc url.
	 *
	 * @return the jdbc url
	 * @throws ApplicationException
	 */
	public String getJdbcUrl() {
		String url = replaceDateBaseName(environmentProperties.getDataSourceUrl());
		url = url.replace(PropertyConstants.MAIN_APP_MYSQL_IP, environmentProperties.getSqlIp().trim());
		url = url.replace(PropertyConstants.MAIN_APP_MYSQL_PORT, environmentProperties.getSqlPort().trim());
		return url;
	}

	/**
	 * Gets the jdbc user.
	 *
	 * @return the jdbc user
	 */
	public String getJdbcUser() {
		return environmentProperties.getJdbcUser();
	}

	/**
	 * Gets the my sql date base.
	 *
	 * @return the my sql date base
	 */
	public String getMySqlDateBase() {
		if (dataBaseName.isEmpty()) {
			dataBaseName = environmentProperties.getMySqlDateBase();
		}
		return dataBaseName;
	}

	/**
	 * Replace date base name.
	 *
	 * @param data the data
	 * @return the string
	 */
	public String replaceDateBaseName(String data) {
		data = data.replace(PropertyConstants.DB_NAME, getMySqlDateBase());
		return data;
	}

}
