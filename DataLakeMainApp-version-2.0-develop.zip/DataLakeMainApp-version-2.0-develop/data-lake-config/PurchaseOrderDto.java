package com.ncloud.dl.transfer.object.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PurchaseOrderDto {
	
	 private Integer orderId;
	 private String orderNo;
	 private Integer stockCount;
	 private LocalDateTime purchaseDate;
	 private Integer companyId;	
	 private String order_status;
	 private Integer orderAmt;
	 

}
