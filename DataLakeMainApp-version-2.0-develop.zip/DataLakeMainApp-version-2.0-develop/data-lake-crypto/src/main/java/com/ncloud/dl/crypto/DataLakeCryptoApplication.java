package com.ncloud.dl.crypto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com.ncloud.dl.*")
@SpringBootApplication
public class DataLakeCryptoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataLakeCryptoApplication.class, args);
	}

}
