package com.ncloud.dl.crypto.core;

import java.security.Key; 
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.ncloud.dl.utils.core.ApplicationUtils;



/**
* The Class TwoWayEncryption.
*/
@Component
public class TwoWayEncryption {
	
	
	/**
	 * The algorithm.
	 */
	@Value("${algorithm}")
	private String algorithm;
	
	/** The logger. */
	Logger logger = LoggerFactory.getLogger(TwoWayEncryption.class);
	
	/**
	 * The secret key.
	 */
	@Value("${secretKey}")
	private String secretKey;
	
	/**
	 * Convert to database column.
	 *
	 * @param data the data
	 * @return the string
	 */
	
	public String doEncryption(String data) {
		String secrKey = secretKey;
		if (secrKey != null) {
			Key key = new SecretKeySpec(secrKey.getBytes(), "AES");
			try {
				if (ApplicationUtils.isNotBlank(data)) {
					Cipher cf = Cipher.getInstance(algorithm);
					cf.init(Cipher.ENCRYPT_MODE, key);
					return Base64.getEncoder().encodeToString(data.getBytes());
				}
			} catch (Exception e) {
				logger.error(e.getMessage());
			}
		}
		return null;

	}
	
	/**
	 * Do decryption.
	 *
	 * @param data the data
	 * @return the string
	 */
	public String doDecryption(String data) {

		String secrKey = secretKey;
		if (secrKey != null) {
			Key key = new SecretKeySpec(secrKey.getBytes(), "AES");
			try {
				if (ApplicationUtils.isNotBlank(data)) {
					Cipher cf = Cipher.getInstance(algorithm);
					cf.init(Cipher.ENCRYPT_MODE, key);
					return new String(Base64.getDecoder().decode(data.getBytes()));
				}
			} catch (Exception e) {
				logger.error(e.getMessage());
				return data;
			}
		}
		return null;

	}
	
		

}
