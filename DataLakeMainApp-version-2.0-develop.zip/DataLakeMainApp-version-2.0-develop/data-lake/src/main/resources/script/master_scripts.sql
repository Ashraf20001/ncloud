CREATE DATABASE datalake
    WITH
    OWNER = postgres
    ENCODING = 'UTF8'
    CONNECTION LIMIT = -1
    IS_TEMPLATE = False;

 -- -----------Create Table Query ---------------
   
   CREATE TABLE DATA_REPOSITORY (
    ID SERIAL PRIMARY KEY NOT NULL,
    repo_id VARCHAR(45),
    repo_table_name VARCHAR(45),
    repo_api_name VARCHAR(45),
    repository_name VARCHAR(45),
    repo_description VARCHAR(145),
    repo_status INT,
    upload_access INT,
    is_active BOOLEAN,
    effective_from TIMESTAMPTZ,
    effective_to TIMESTAMPTZ,
    repo_version NUMERIC,
    parent_repository INT DEFAULT NULL, FOREIGN KEY (parent_repository) REFERENCES data_repository(ID),
    association_id INT,
    field_count INT,
    crt_dte_tme TIMESTAMP,
    mdy_dte_tme TIMESTAMP,
	created_by INT NOT NULL,
    modified_by INT NOT NULL,
    is_dlt_sts BOOLEAN NOT NULL,
    identity VARCHAR(45)
	);
   
   CREATE TABLE comments (
    ID SERIAL PRIMARY KEY NOT NULL,
    repository_id INT NOT NULL,
    FOREIGN KEY (repository_id) REFERENCES data_repository(ID),
    is_creator INT NOT NULL,
    repo_comments VARCHAR(500),
    crt_dte_tme TIMESTAMPTZ,
    mdy_dte_tme TIMESTAMPTZ,
	created_by INT NOT NULL,
    modified_by INT NOT NULL,
    is_dlt_sts BOOLEAN NOT NULL,
    identity VARCHAR(45)
	);


   CREATE TABLE search_history (
    ID SERIAL PRIMARY KEY NOT NULL,
    repository_Count int ,
	records_Count int not null,
	search_Value varchar(300),
	searchType int,
   identity varchar(45)
);


CREATE TABLE REPOSITORY_NOTIFICATION (
    ID SERIAL PRIMARY KEY NOT NULL,
   repository_id INT NOT NULL,
    	FOREIGN KEY (repository_id) REFERENCES data_repository(ID),
    last_acted INT,
    to_notify INT,
    notification_message VARCHAR(150),
    is_read_sts BOOLEAN,
    is_repo_cmts BOOLEAN NOT NULL,
    replace_template VARCHAR(150),
	created_by INT NOT NULL,
    modified_by INT NOT NULL,
    crt_dte_tme TIMESTAMPTZ,
    mdy_dte_tme TIMESTAMPTZ,
    is_dlt_sts BOOLEAN NOT NULL,
    identity VARCHAR(45)
);

CREATE TABLE REPOSITORY_MODIFICATION_HISTORY (
    ID SERIAL PRIMARY KEY NOT NULL,
    repo_action VARCHAR(30) NOT NULL,
    repository_id INT NOT NULL,
    log_message VARCHAR(60) NOT NULL,
    crt_dte_tme TIMESTAMPTZ,
    mdy_dte_tme TIMESTAMPTZ,
	created_by INT NOT NULL,
    modified_by INT NOT NULL,
    is_dlt_sts BOOLEAN NOT NULL,
    identity VARCHAR(45)
);

CREATE TABLE field_config (
      field_id SERIAL PRIMARY KEY NOT NULL,
    field_name VARCHAR(150),
	repo_id INT,
		FOREIGN KEY (repo_id) REFERENCES data_repository(ID),
    data_type VARCHAR(50),
    field_type INT,
    upd_acs_for BIGINT,
    is_mandatory BOOLEAN,
    err_msg VARCHAR(150),
    column_name VARCHAR(50),
    field_order INT,
    search_type INT,
    crt_dte_tme TIMESTAMPTZ,
    mdy_dte_tme TIMESTAMPTZ,
	created_by INT NOT NULL,
    modified_by INT NOT NULL,
    is_dlt_sts BOOLEAN NOT NULL,
    identity VARCHAR(45)
);

create table field_option_mapping(
		field_option_id SERIAL PRIMARY KEY NOT NULL,
    	field_id INT,
			FOREIGN KEY(field_id) 
	  		REFERENCES field_config(field_id),
		dropdown_option VARCHAR(150),
		crt_dte_tme TIMESTAMPTZ,
    	mdy_dte_tme TIMESTAMPTZ,
		created_by INT NOT NULL,
    modified_by INT NOT NULL,
		is_dlt_sts  Boolean not null,
		identity VARCHAR(45)
);

create table field_search_lnk(
		id SERIAL PRIMARY KEY NOT NULL,
    	field_id INT,
			FOREIGN KEY(field_id) 
	  		REFERENCES field_config(field_id),
		crt_dte_tme TIMESTAMPTZ,
    	mdy_dte_tme TIMESTAMPTZ,
		created_by INT NOT NULL,
    modified_by INT NOT NULL,
    is_glb_repo INT,
		is_dlt_sts  Boolean not null,
		identity VARCHAR(45)
);


CREATE TABLE notification_event (
    event_id SERIAL PRIMARY KEY NOT NULL,
    event_name VARCHAR(45),
       event_code INT NOT NULL,
    crt_dte_tme TIMESTAMP,
        mdy_dte_tme TIMESTAMP,
        created_by INT NOT NULL,
        modified_by INT NOT NULL,
    is_dlt_sts BOOLEAN NOT NULL,
    identity VARCHAR(45)
);

INSERT INTO notification_event(event_id, event_name, event_code, crt_dte_tme, mdy_dte_tme, created_by, modified_by, is_dlt_sts, identity)
VALUES (1,'Repository Creation',1,'2023-07-05 23:49:43.175982','2023-07-05 23:49:43.175982',1,1,FALSE,'ededwsdefsx');


CREATE TABLE notification_template (
    notification_id SERIAL PRIMARY KEY NOT NULL,
       event_id INT NOT NULL,
        FOREIGN KEY (event_id) REFERENCES notification_event(event_id),
       state VARCHAR(145),
       notification_name VARCHAR(145),
       notification_desc VARCHAR(45),
       notification_template_type INT,
        notification_subject VARCHAR(45) ,
        notification_content VARCHAR(150) NOT NULL,
    crt_dte_tme TIMESTAMP,
        mdy_dte_tme TIMESTAMP,
        created_by INT NOT NULL,
        modified_by INT NOT NULL,
    is_dlt_sts BOOLEAN NOT NULL,
    identity VARCHAR(45)
);

INSERT INTO notification_template(notification_id, event_id, state, notification_name, notification_desc, notification_template_type, notification_subject, notification_content, crt_dte_tme, mdy_dte_tme, created_by, modified_by, is_dlt_sts, identity)
VALUES (1,1,'Submitted','deded','deded',1,'frfrf','NEW_REPOSITORY has been created by USER_NAME','2023-07-05 23:49:43.175982','2023-07-05 23:49:43.175982',1,1,FALSE,'oweryuiwefgckvhtovilgwvnyfhfwdtfludyfdw'),(2,1,'Request to modify',NULL,NULL,NULL,NULL,'Comments has been added for NEW_REPOSITORY by USER_NAME',NULL,NULL,1,1,FALSE,'ycuwocksuyvlsviufpqoueritrotu'),(3,1,'Approved',NULL,NULL,NULL,NULL,'NEW_REPOSITORY has been approved by USER_NAME',NULL,NULL,1,1,FALSE,'ey6f7i397792jh804i80c3iur030rf'),(4,1,'Rejected',NULL,NULL,NULL,NULL,'NEW_REPOSITORY has been rejected by USER_NAME',NULL,NULL,1,1,FALSE,'yfowprhf7wpytgfwyhgfw87ty98rhf4');

CREATE TABLE SCHEDULER_NOTIFICATION (
	ID SERIAL PRIMARY KEY NOT NULL,
	notification_name VARCHAR(150) NOT NULL,
	triggered_status VARCHAR(150) NOT NULL,
	message VARCHAR(200),
	remainder INT,
	status BOOLEAN NOT NULL,
	repository_id INT NOT NULL,
	FOREIGN KEY (repository_id) REFERENCES data_repository(ID),
	crt_dte_tme TIMESTAMPTZ,
    mdy_dte_tme TIMESTAMPTZ,
	created_by INT NOT NULL,
    modified_by INT NOT NULL,
    is_dlt_sts BOOLEAN NOT NULL,
    identity VARCHAR(45)
);

CREATE TABLE REPOSITORY_SCHEDULE_DETAILS (
	ID SERIAL PRIMARY KEY NOT NULL,
	schedule_notification_id INT NOT NULL,
	FOREIGN KEY (schedule_notification_id) REFERENCES scheduler_notification(ID),
	start_date_with_time VARCHAR(100),
	repeat_count INT,
	repeat_format VARCHAR(45),
	selected_days VARCHAR(150),
	selected_date INT,
	repeat_on VARCHAR(45),
	repeat_on_day VARCHAR(45),
	repeat_on_month VARCHAR(45),
	selected_month VARCHAR(45),
	end_date VARCHAR(100),
	crt_dte_tme TIMESTAMPTZ,
    mdy_dte_tme TIMESTAMPTZ,
	created_by INT NOT NULL,
    modified_by INT NOT NULL,
    is_dlt_sts BOOLEAN NOT NULL,
    identity VARCHAR(45)
);



-- ******************************** BULK UPLOAD - SCRPITS ***************************************************

CREATE TABLE file_storage (
    id serial PRIMARY KEY NOT NULL,
    repository_id INT,
    file_name VARCHAR(145),
    created_by INT,
    crt_dte_tme TIMESTAMPTZ,
    modified_by INT,
    mdy_dte_tme TIMESTAMPTZ,
    identity VARCHAR(45),
    is_dlt_sts boolean
);

CREATE TABLE bulk_upload_history (
    id serial PRIMARY KEY NOT NULL,
    total_cnt BIGINT NOT NULL,
    sucess_cnt BIGINT NOT NULL,
    failure_cnt BIGINT NOT NULL,
    upld_sts INT,
    storage_id INT,
    association_id INT,
	FOREIGN KEY (storage_id) REFERENCES file_storage(id),
	repository_id INT NOT NULL,
    FOREIGN KEY (repository_id) REFERENCES data_repository(ID),
    company_id INT,
    created_by INT,
    crt_dte_tme TIMESTAMPTZ,
    modified_by INT,
    mdy_dte_tme TIMESTAMPTZ,
    identity VARCHAR(45),
    is_dlt_sts boolean
);

CREATE TABLE error_maintainence (
    id serial PRIMARY KEY NOT NULL,
    repository_id INT,
    scratch_id INT,
    field_id INT,
    FOREIGN KEY(field_id) 
	  		REFERENCES field_config(field_id),
    err_msg VARCHAR(200),
    err_sts boolean,
    created_by INT,
    crt_dte_tme TIMESTAMPTZ,
    modified_by INT,
    mdy_dte_tme TIMESTAMPTZ,
    identity VARCHAR(45),
    is_dlt_sts boolean,
    unique_id VARCHAR(50),
    bulkupload_id INT,
    error_fields VARCHAR(50),
    is_duplicate boolean
);


-- **************************** AUDIT SCRIPTS ************************************

CREATE TABLE DATA_REPOSITORY_AUD (
    ID INT,
    repo_id VARCHAR(45),
    repo_table_name VARCHAR(45),
    repo_api_name VARCHAR(45),
    repository_name VARCHAR(45),
    repo_description VARCHAR(145),
    repo_status INT,
    is_active BOOLEAN,
    parent_repository INT DEFAULT NULL, FOREIGN KEY (parent_repository) REFERENCES data_repository(ID),
    upload_access INT,
    effective_from TIMESTAMPTZ,
    effective_to TIMESTAMPTZ,
    repo_version NUMERIC,
    association_id INT,
    field_count INT,
	revtype INT,
	rev INT,
    crt_dte_tme TIMESTAMP,
    mdy_dte_tme TIMESTAMP,
	created_by INT NOT NULL,
	modified_by INT NOT NULL,
    is_dlt_sts BOOLEAN NOT NULL,
    identity VARCHAR(45)
);

CREATE TABLE FIELD_CONFIG_AUD (
      field_id INT,
    field_name VARCHAR(150),
	repo_id INT,
	FOREIGN KEY (repo_id) REFERENCES data_repository(ID),
    data_type VARCHAR(50),
    field_type INT,
    upd_acs_for BIGINT,
    is_mandatory BOOLEAN,
    err_msg VARCHAR(150),
    field_order INT,
    search_type INT,
    column_name VARCHAR(50),
    revtype INT,
	rev INT,
    created_by INT NOT NULL,
    crt_dte_tme TIMESTAMP,
    mdy_dte_tme TIMESTAMP,
    modified_by INT NOT NULL,
    is_dlt_sts BOOLEAN NOT NULL,
    identity VARCHAR(45)
);

create table field_option_mapping_aud(
	field_option_id INT,
    field_id INT,
	FOREIGN KEY(field_id) 
	REFERENCES field_config(field_id),
	dropdown_option VARCHAR(150),
	revtype INT,
	rev INT,
	crt_dte_tme TIMESTAMPTZ,
    mdy_dte_tme TIMESTAMPTZ,
	created_by INT NOT NULL,
    modified_by INT NOT NULL,
	is_dlt_sts  Boolean not null,
	identity VARCHAR(45)
);

CREATE SEQUENCE hibernate_sequence START 1;

CREATE TABLE REVINFO(
  REV INTEGER NOT NULL,
  REVTSTMP BIGINT,
  PRIMARY KEY (REV)
);

    
