package com.ncloud.dl.search.eswrapper;

import java.util.Map;

/**
 * The Interface ISearchHit.
 */
public interface ISearchHit {

	 /**
 	 * Gets the source as map.
 	 *
 	 * @return the source as map
 	 */
 	public Map<String, Object> getSourceAsMap();
}
