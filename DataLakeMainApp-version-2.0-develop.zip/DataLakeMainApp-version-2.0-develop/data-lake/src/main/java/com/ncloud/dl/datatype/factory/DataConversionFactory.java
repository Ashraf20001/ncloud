package com.ncloud.dl.datatype.factory;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.ncloud.dl.transfer.object.enums.FieldDataTypeEnum;

import lombok.RequiredArgsConstructor;

/**
 * A factory for creating DataConversion objects.
 */
@Component
@RequiredArgsConstructor
public class DataConversionFactory {
	
	/**
	 * stringDataTypeConvertor
	 */
	@Qualifier("stringConvert")
	private final IDataTypeConversionFactory stringDataTypeConvertor;
	
	/**
	 * dateDataTypeConvertor
	 */
	@Qualifier("dateConvert")
	private final IDataTypeConversionFactory dateDataTypeConvertor;
	
	/**
	 * numberDataTypeConvertor
	 */
	@Qualifier("numberConvert")
	private final IDataTypeConversionFactory numberDataTypeConvertor;
	
	/**
	 * booleanDataTypeConvertor
	 */
	@Qualifier("booleanConvert")
	private final IDataTypeConversionFactory booleanDataTypeConvertor;
	
	/**
	 * decimalDataTypeConvertor
	 */
	@Qualifier("decimalConvert")
	private final IDataTypeConversionFactory decimalDataTypeConvertor;
	
	
	/**
	 * dataTypeConversionFactory
	 */
	private final Map<String, IDataTypeConversionFactory> dataTypeConversionFactory = new HashMap<>();

	/**
	 * Inits the calculator map.
	 */
	@PostConstruct
	private void initCalculatorMap() {
		dataTypeConversionFactory.put(FieldDataTypeEnum.STRING.getValue(), stringDataTypeConvertor);
		dataTypeConversionFactory.put(FieldDataTypeEnum.DECIMAL.getValue(), decimalDataTypeConvertor);
		dataTypeConversionFactory.put(FieldDataTypeEnum.BOOLEAN.getValue(), booleanDataTypeConvertor);
		dataTypeConversionFactory.put(FieldDataTypeEnum.NUMBER.getValue(), numberDataTypeConvertor);
		dataTypeConversionFactory.put(FieldDataTypeEnum.DATE.getValue(), dateDataTypeConvertor);
	}
	
	  /**
     * @param fieldType
     * @return
     */
    public IDataTypeConversionFactory getFieldDataType(String fieldType) {
    	return dataTypeConversionFactory.get(fieldType);
    }
	
}
