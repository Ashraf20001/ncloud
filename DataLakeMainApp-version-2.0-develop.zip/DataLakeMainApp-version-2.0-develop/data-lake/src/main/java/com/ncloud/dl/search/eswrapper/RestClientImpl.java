package com.ncloud.dl.search.eswrapper;

import java.io.IOException;

import org.elasticsearch.client.Request;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;

/**
 * The Class RestClientImpl.
 */
public class RestClientImpl implements IRestClient {

	/** The rest client. */
	private final RestClient restClient;

	/**
	 * Instantiates a new rest client impl.
	 *
	 * @param restClient the rest client
	 */
	public RestClientImpl(RestClient restClient) {
		this.restClient=restClient;
	}
	
	/**
	 * Perform request.
	 *
	 * @param request the request
	 * @return the response
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	public Response performRequest(Request request) throws IOException {	
		return restClient.performRequest(request);
	}

	/**
	 * Close.
	 *
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	public void close() throws IOException {
		restClient.close();
	}

}
