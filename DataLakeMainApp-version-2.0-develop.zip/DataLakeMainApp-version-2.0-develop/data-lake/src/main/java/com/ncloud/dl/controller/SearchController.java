package com.ncloud.dl.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lowagie.text.DocumentException;
import com.ncloud.dl.aop.annotation.Auditable;
import com.ncloud.dl.config.base.controller.BaseController;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.service.ISearchService;
import com.ncloud.dl.transfer.object.core.ApplicationResponse;
import com.ncloud.dl.transfer.object.dto.CustomFilterSortingVo;
import com.ncloud.dl.transfer.object.dto.FieldsConfiguratorDto;
import com.ncloud.dl.transfer.object.dto.SearchResponseDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/search")
@RequiredArgsConstructor
@Auditable
public class SearchController extends BaseController {
	
	/**
	 * {@link ISearchService}
	 */
	private final ISearchService iSearchService;
	
	/**
	 * Fetches the advanced filter configuration for a given repository.
	 *
	 * @param repositoryName The name of the repository.
	 * @return ResponseEntity containing the list of eligible filters.
	 * @throws ApplicationException If a business logic error occurs.
	 */
	@ApiOperation(value = "Fetch Advanced Filter Configuration",
	              notes = "Retrieves the eligible fields for advanced filtering in the specified repository.",
	              response = FieldsConfiguratorDto.class,
	              responseContainer = "List")
	@GetMapping("/advance-filter")
	public List<FieldsConfiguratorDto> advanceFilterForRepository(
			@ApiParam(value = "Repository Name", required = true) @RequestParam(name = "repositoryName") String repositoryName) {
		return iSearchService.getadvanceFilterForRepository(repositoryName);  
	}
	
	/**
	 * Fetches the globally approved repository names based on a list of repository IDs.
	 *
	 * @param repositoryId The list of repository IDs to search for.
	 * @return ResponseEntity containing the approved repository names.
	 * @throws ApplicationException If a business logic error occurs.
	 */
	@ApiOperation(value = "Fetch Approved Repository Names",
	              notes = "Retrieves the names of repositories that are approved for global search.",
	              response = ApplicationResponse.class)
	@PostMapping("/global-search-approved-name")
	public ApplicationResponse getApprovedRepositoryName(
			@ApiParam(value = "List of Repository ID", required = true) @RequestParam(name = "repositoryId") List<Integer> repositoryId)
			throws ApplicationException {
		return getApplicationResponse(iSearchService.getApprovedRepositoryName(repositoryId));
	}
	
	/**
	 * Sends search value details to the customer via email.
	 *
	 * @param identity       Unique identifier of the search value.
	 * @param email          Email of the recipient (optional).
	 * @param repositoryName Name of the repository (optional).
	 * @return ResponseEntity containing the status of the email sending operation.
	 * @throws DocumentException     If there is an issue generating the document.
	 * @throws IOException           If there is an issue with I/O operations.
	 * @throws ApplicationException  If a business logic error occurs.
	 */
	@ApiOperation(value = "Send Search Value via Email",
	              notes = "Shares the search value with the customer via email.",
	              response = ApplicationResponse.class)
	@PostMapping("/mail-services")
	public ApplicationResponse mailService(
			@ApiParam(value = "Notification Identity", required = true) @RequestParam(name = "identity") String identity,
			@ApiParam(value = "Email Address") @RequestParam(name = "email", required = false) String email,
			@ApiParam(value = "Repository Name") @RequestParam(name = "repositoryName", required = false) String repositoryname)
			throws DocumentException, IOException, ApplicationException {
		return getApplicationResponse(iSearchService.sendMail(identity, email, repositoryname));
	}

	/**
	 * Fetches table headers based on the repository name.
	 *
	 * @param repositoryName The name of the repository.
	 * @return A ResponseEntity containing the table headers.
	 * @throws ApplicationException If there is a business logic error.
	 */
	@ApiOperation(value = "Get Table Header",
	              notes = "Retrieves table header fields for the given repository name.",
	              response = ApplicationResponse.class)
	@GetMapping("/table-header")
	public ApplicationResponse getRepositoryFields(
			@ApiParam(value = "Repository Name", required = true) @RequestParam(name = "repositoryName") String repositoryName)
			throws ApplicationException {
		return getApplicationResponse(iSearchService.getRepositoryFiedsForTableHeader(repositoryName));
	}
	
	/**
	 * Performs a repository-based search and returns matching data.
	 *
	 * @param filterValue    Criteria to refine the search results (optional).
	 * @param skip           Number of records to skip for pagination.
	 * @param limit          Maximum number of records to return.
	 * @param searchType     Type of search to perform (e.g., predefined search categories).
	 * @param repositoryName The name of the repository to search within.
	 * @param filterVo       {@link CustomFilterSortingVo} containing filtering and sorting details.
	 * @return               {@link ApplicationResponse} containing the search results.
	 * @throws IOException   If an error occurs during the search operation.
	 */
	@ApiOperation(value = "Repository Search",
	              notes = "Searches within a specified repository based on filtering and sorting criteria.",
	              response = ApplicationResponse.class)
	@PostMapping("/{repositoryName}/repository-search")
	public ApplicationResponse getRepositorySearchList(
			@ApiParam(value = "Filter value") @RequestParam(name = "filterValue", required = false) String filterValue,
			@ApiParam(value = "Minimum number of records to skip", required = true) @RequestParam(name = "skip") Long skip,
			@ApiParam(value = "Maximum number of records to return", required = true) @RequestParam(name = "limit") Long limit,
			@ApiParam(value = "Search Type", required = true) @RequestParam(name = "searchType") Integer searchType,
			@ApiParam(value = "Repository Name", required = true) @PathVariable(name = "repositoryName") String repositoryName,
			@ApiParam(value = "Filter or Sorting criteria details in CustomFilterSortingVo", required = true) @RequestBody CustomFilterSortingVo filterVo)
			throws IOException {
		return getApplicationResponse(iSearchService.commonSearch(filterValue, repositoryName, skip, limit, searchType, filterVo, Boolean.FALSE));
	}
	
	/**
	 * Retrieves the total count of records for a given repository based on the specified query.
	 *
	 * @param repositoryName The name of the repository to search within.
	 * @param query          Search query used to filter records.
	 * @param searchType     Type of search to be performed (e.g., predefined search categories).
	 * @param filterVo       {@link CustomFilterSortingVo} containing filtering and sorting details.
	 * @return               {@link ApplicationResponse} containing the total record count.
	 * @throws IOException   If an error occurs during data retrieval.
	 * @throws ApplicationException If there is a business logic error related to the query execution.
	 */
	@ApiOperation(value = "Get Total Records Count",
	              notes = "Retrieves the total count of records for a given repository based on the specified query.",
	              response = ApplicationResponse.class)
	@PostMapping("/{repositoryName}/total-records-count")
	public ApplicationResponse getTotalRecordsCount(
			@ApiParam(value = "Repository Name", required = true) @PathVariable(name = "repositoryName") String repositoryName,
			@ApiParam(value = "Search Value", required = true) @RequestParam(name = "query") String query,
			@ApiParam(value = "Search Type", required = true) @RequestParam(name = "searchType") Integer searchType,
			@ApiParam(value = "Filter or Sorting criteria details in CustomFilterSortingVo", required = true) @RequestBody CustomFilterSortingVo filterVo)
			throws IOException, ApplicationException {
		return getApplicationResponse(iSearchService.getTotalRecordsCount(repositoryName, query, searchType, filterVo));
	}
	
	/**
	 * Performs a global search based on the provided query and repository.
	 *
	 * @param searchQuery The search term used to fetch relevant data.
	 * @param skip        Number of records to skip for pagination.
	 * @param limit       Maximum number of records to return.
	 * @param repository  (Optional) The repository to search within.
	 * @return {@link ApplicationResponse} containing the search results.
	 * @throws ApplicationException If an error occurs during the search operation.
	 */
	@ApiOperation(value = "Global Search",
	              notes = "Fetches search results from the specified repository based on the search query.",
	              response = ApplicationResponse.class)
	@GetMapping("/global-search")
	public ApplicationResponse globalSearch(@RequestParam("searchQuery") String searchQuery,
			@ApiParam(value = "Number of records to skip", required = true) @RequestParam("skip") Long skip,
			@ApiParam(value = "Maximum number of records to return", required = true) @RequestParam("limit") Long limit,
			@ApiParam(value = "Repository Name", required = true) @RequestParam(name = "repository", required = false) String repository) throws ApplicationException {
		List<SearchResponseDto> reponse = iSearchService.globalSearch(searchQuery, skip, limit, repository, Boolean.FALSE);
		return getApplicationResponse(reponse);
	}
	
	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}

	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	@Override
	protected void registerInterceptor() {
		
	}

}
