package com.ncloud.dl.dao.impl.notification.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.ncloud.dl.config.common.base.dao.BaseDao;
import com.ncloud.dl.constants.core.ApplicationConstants;
import com.ncloud.dl.constants.core.TableConstants;
import com.ncloud.dl.dao.notification.repository.IRepositoryNotificationDao;
import com.ncloud.dl.transfer.object.entity.RepositoryNotification;

/**
 * The Class NotificationRepositoryDaoImpl.
 */
@Repository
public class NotificationRepositoryDaoImpl extends BaseDao implements IRepositoryNotificationDao {

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {

	}

	/**
	 * Fetch unRead Notification detail from repository notification.
	 * @param authorityPrivelege
	 * @param isViewAllNotifications
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<RepositoryNotification> getRepositoryNotificationBasedOnRolePrivelege(List<Integer> authorityPrivelege,
			Boolean isViewAllNotifications) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<RepositoryNotification> createQuery = builder.createQuery(RepositoryNotification.class);
		Root<RepositoryNotification> root = createQuery.from(RepositoryNotification.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(root.get(TableConstants.TO_NOTIFY).in(authorityPrivelege)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_READ), Boolean.FALSE)));
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.IS_DELETE_STS))));
		createQuery.orderBy(builder.desc(root.get(TableConstants.CREATED_DATE_TIME)));
		return isViewAllNotifications
				? (List<RepositoryNotification>) getResultList(createQuery(builder, createQuery, root, predicates))
				: (List<RepositoryNotification>) getResultList(createQuery(builder, createQuery, root, predicates)
						.setFirstResult(ApplicationConstants.ZERO).setMaxResults(ApplicationConstants.FIVE));
	}

	/**
	 * Fetch Repository Notification by repository identity.
	 *@param identity
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<RepositoryNotification> getRepositoryNotificationByIdentity(String identity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<RepositoryNotification> createQuery = builder.createQuery(RepositoryNotification.class);
		Root<RepositoryNotification> root = createQuery.from(RepositoryNotification.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.REPOSITORY_ID).get(TableConstants.IDENTITY), identity)));
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.IS_READ))));
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.IS_DELETE_STS))));
		return (List<RepositoryNotification>) getResultList(createQuery(builder, createQuery, root, predicates));
	}

	/**
	 * Update Repository Notification.
	 *@param repositoryNotification
	 * @return 
	 */
	@Override
	public boolean updateRepositoryNotification(RepositoryNotification repositoryNotification) {
		update(repositoryNotification);
		return true;
	}

}
