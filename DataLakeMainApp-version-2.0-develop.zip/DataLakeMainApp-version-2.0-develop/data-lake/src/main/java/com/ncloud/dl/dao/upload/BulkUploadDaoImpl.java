package com.ncloud.dl.dao.upload;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.hibernate.query.NativeQuery;
import org.hibernate.transform.AliasToEntityMapResultTransformer;
import org.springframework.stereotype.Repository;

import com.ncloud.dl.config.common.base.dao.BaseDao;
import com.ncloud.dl.constants.core.TableConstants;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.entity.BulkUploadHistory;
import com.ncloud.dl.transfer.object.entity.ErrorMaintenance;
import com.ncloud.dl.utils.core.ApplicationUtils;

/**
 * The Class BulkUploadDaoImpl.
 */
@Repository
public class BulkUploadDaoImpl  extends BaseDao implements IBulkUploadDao {

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
		
	}

	/**
	 * Save Bulk UploadHistory.
	 * @param bulkUploadHistory
	 * @throws ApplicationException
	 */
	@Override
	public BulkUploadHistory saveBulkUploadHsitory(BulkUploadHistory bulkUploadHistory) throws ApplicationException {
		save(bulkUploadHistory, TableConstants.BULK_UPLOAD_HISTORY);
		return bulkUploadHistory;
	}

	/**
	 * Get Bulk Upload By Id.
	 * @param bulkUploadId
	 * @return
	 */
	@Override
	public BulkUploadHistory getBulkUploadByIdAndAssocicationId(Integer bulkUploadId, Integer associationId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<BulkUploadHistory> createQuery = builder.createQuery(BulkUploadHistory.class);
		Root<BulkUploadHistory> root = createQuery.from(BulkUploadHistory.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLTSTS), false)));
		predicates.add(builder
				.and(builder.equal(root.get(TableConstants.ID), bulkUploadId)));
		return (BulkUploadHistory) getSingleResult(createQuery(builder, createQuery, root, predicates));
	}

	
	/**
	 * Get upkload history details.
	 * @param dataRepoId
	 * @param UserTypeName
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<BulkUploadHistory> getUploadHistorydetails(Integer dataRepoId,Integer companyId, Integer associationId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<BulkUploadHistory> createQuery = builder.createQuery(BulkUploadHistory.class);
		Root<BulkUploadHistory> root = createQuery.from(BulkUploadHistory.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETE_STS), false)));
		predicates.add(
				builder.and(builder.equal(root.get(TableConstants.DATAREPOSITORY).get(TableConstants.ID), dataRepoId)));
		if(ApplicationUtils.isValidId(companyId)) {
			predicates.add(builder.and(builder.equal(root.get(TableConstants.COMPANY_ID), companyId)));
		}
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ASSOCIATION_ID), associationId)));
		createQuery.orderBy(builder.desc(root.get(TableConstants.MODI_DATE)));
		return (List<BulkUploadHistory>) getResultList(createQuery(builder, createQuery, root, predicates));
	}
	
	/**
	 * Get total success count by repository Id.
	 *@param Integer ID.
	 */
	@Override
	public Long getTotalSuccessCountByRepositoryId(Integer id) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<BulkUploadHistory> root = criteria.from(BulkUploadHistory.class);
		criteria.multiselect(builder.sum(root.get(TableConstants.SUCCESS_COUNT)));
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.DATAREPOSITORY).get(TableConstants.ID), id)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETE_STS), false)));
		return (Long) getSingleResult(createQuery(builder, criteria, root, predicates));
	}
	
	/**
	 * Get Bulk upload details by identity.
	 * @param uploadIdentity
	 * @return
	 */
	@Override
	public BulkUploadHistory getBulkUploadDetailsByIdentity(String uploadIdentity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<BulkUploadHistory> criteria = builder.createQuery(BulkUploadHistory.class);
		Root<BulkUploadHistory> root = criteria.from(BulkUploadHistory.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IDENTITY), uploadIdentity)));
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.IS_DELETE_STS))));
		return (BulkUploadHistory) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);
	}
	
	/**
	 * Get Error Maintenance record by bulkUploadId.
	 * @param repositoryId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<ErrorMaintenance> getListForFieldsErrorMaintenance(String uniqueId, Boolean isDuplicate, Integer bulkUploadId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<ErrorMaintenance> criteria = builder.createQuery(ErrorMaintenance.class);
		Root<ErrorMaintenance> root = criteria.from(ErrorMaintenance.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.isNull(root.get(TableConstants.SCRATCH_ID))));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.BULK_UPLOAD_ID), bulkUploadId)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IDENTITY), uniqueId)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DUPLICATE), isDuplicate)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETE_STS), Boolean.FALSE)));
		return (List<ErrorMaintenance>) getResultList(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Get Map data by native query
	 *@param query
	 */
	@SuppressWarnings({ "unchecked", "deprecation" })
	@Override
	public List<Map<String,Object>> getScratchDataUsingBulkUploadId(String query) {
		NativeQuery<?> nativeQuery = getSession().createNativeQuery(query);
		nativeQuery.setResultTransformer(AliasToEntityMapResultTransformer.INSTANCE);
		return (List<Map<String,Object>>) nativeQuery.getResultList();
	}

	/**
	 * count data.
	 *@query
	 */
	@Override
	public Long getScratchCountUsingUploadId(String query) {
		NativeQuery<?> nativeQuery = getSession().createNativeQuery(query);
		Object result = nativeQuery.getSingleResult();
		Long count = ((Number) result).longValue();
		return count;
	}

	/**
	 * Update bulk upload history.
	 * @param bulkUploadHistory
	 * @return
	 */
	@Override
	public String updateBulkUploadHistory(BulkUploadHistory bulkUploadHistory) {
		update(bulkUploadHistory);
		return bulkUploadHistory.getIdentity();
	}
	
	/**
	 * Update ErrorMaintenance.
	 * @param errorMaintenance
	 * @return
	 */
	@Override
	public String updateErrorMaintenance(ErrorMaintenance errorMaintenance) {
		update(errorMaintenance);
		return errorMaintenance.getIdentity();
	}

}
