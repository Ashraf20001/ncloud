package com.ncloud.dl.dao.upload;

import java.util.List;
import java.util.Map;

import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.entity.BulkUploadHistory;
import com.ncloud.dl.transfer.object.entity.ErrorMaintenance;

/**
 * The Interface IBulkUploadDao.
 */
public interface IBulkUploadDao {
	
	/**
	 * @param bulkUploadHistory
	 * @throws ApplicationException
	 */
	BulkUploadHistory saveBulkUploadHsitory(BulkUploadHistory bulkUploadHistory) throws ApplicationException;

	/**
	 * @param bulkUploadId
	 * @return
	 */
	BulkUploadHistory getBulkUploadByIdAndAssocicationId(Integer bulkUploadId, Integer asscoiationId);

	/**
	 * @param uploadIdentity
	 * @return
	 */
	BulkUploadHistory getBulkUploadDetailsByIdentity(String uploadIdentity);

	/**
	 * @param query
	 * @return
	 */
	List<Map<String, Object>> getScratchDataUsingBulkUploadId(String query);

	/**
	 * @param string
	 * @return
	 */
	Long getScratchCountUsingUploadId(String string);

	/**
	 * @param bulkUploadHistory
	 * @return 
	 */
	String updateBulkUploadHistory(BulkUploadHistory bulkUploadHistory);

	/**
	 * @param errorMaintenance
	 * @return
	 */
	String updateErrorMaintenance(ErrorMaintenance errorMaintenance);
	

	/**
	 * @param dataRepoId
	 * @param UserTypeName
	 * @return
	 */
	List<BulkUploadHistory> getUploadHistorydetails(Integer dataRepoId,Integer companyId, Integer associationId);

	/**
	 * @param id
	 * @return
	 */
	Long getTotalSuccessCountByRepositoryId(Integer id);

	/**
	 * @param repositoryId
	 * @return
	 */
	List<ErrorMaintenance> getListForFieldsErrorMaintenance(String uniqueId, Boolean isDuplicate,
			Integer bulkUploadId);
}
