package com.ncloud.dl.datatype.factory;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map.Entry;

import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.entity.FieldConfiguration;

/**
 * The Interface IDataTypeFactoryValidationBuilder.
 */
public interface IDataTypeFactoryValidationBuilder {

	/**
	 * @param errorMsg
	 * @param entry
	 * @param mandatory
	 * @param fieldConfig 
	 * @return
	 * @throws ApplicationException
	 * @throws ParseException
	 */
	String getDataTypeValidationBuilder(String errorMsg, Entry<String, Object> entry, Boolean mandatory,
			HashMap<String, Object> successRecord, FieldConfiguration fieldConfig) throws ApplicationException, ParseException;

}
