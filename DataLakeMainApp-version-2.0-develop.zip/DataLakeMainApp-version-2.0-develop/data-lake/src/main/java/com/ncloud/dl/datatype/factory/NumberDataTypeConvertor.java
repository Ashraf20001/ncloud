package com.ncloud.dl.datatype.factory;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.ncloud.dl.constants.core.QueryConstants.ColumnConstants;
import com.ncloud.dl.transfer.object.entity.FieldConfiguration;
import com.ncloud.dl.utils.core.ApplicationUtils;

/**
 * The Class NumberDataTypeConvertor.
 */
@Service
@Qualifier("numberConvert")
public class NumberDataTypeConvertor implements IDataTypeConversionFactory{

	/**
	 * @param valMap
	 * @param fieldConfiguration
	 * @param entry
	 * @throws ParseException 
	 */
	@Override
	public void buildBulkRecordMap(HashMap<String, Object> valMap, FieldConfiguration fieldConfiguration,
			Entry<String, Object> entry) {
		if(!entry.getValue().equals("null") && ApplicationUtils.isValidDouble(entry.getValue().toString())) {
			double doubleValue = Double.parseDouble(entry.getValue().toString());
			Integer integerValue = (int) doubleValue;
			valMap.put(fieldConfiguration.getColumnName(), integerValue.toString());
		}
		else {
			valMap.put(fieldConfiguration.getColumnName(), entry.getValue().toString());
		}
		valMap.put(ColumnConstants.STATUS, Boolean.FALSE);
	}


}
