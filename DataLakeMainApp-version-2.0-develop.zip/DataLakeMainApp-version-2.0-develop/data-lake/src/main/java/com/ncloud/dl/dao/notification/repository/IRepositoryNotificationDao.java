package com.ncloud.dl.dao.notification.repository;

import java.util.List;

import com.ncloud.dl.transfer.object.entity.RepositoryNotification;

/**
 * The Interface IRepositoryNotificationDao.
 */
public interface IRepositoryNotificationDao {

	/**
	 * @param authorityPrivelege
	 * @param isViewAllNotifications
	 * @return
	 */
	List<RepositoryNotification> getRepositoryNotificationBasedOnRolePrivelege(List<Integer> authorityPrivelege,
			Boolean isViewAllNotifications);

	/**
	 * Gets the repository notification by identity.
	 *
	 * @param identity the identity
	 * @return the repository notification by identity
	 */
	List<RepositoryNotification> getRepositoryNotificationByIdentity(String identity);

	/**
	 * Update repository notification.
	 *
	 * @param repositoryNotification the repository notification
	 * @return true, if successful
	 */
	boolean updateRepositoryNotification(RepositoryNotification repositoryNotification);

}
