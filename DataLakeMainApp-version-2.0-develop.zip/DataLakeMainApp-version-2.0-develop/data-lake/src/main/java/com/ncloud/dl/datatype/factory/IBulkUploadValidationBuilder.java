package com.ncloud.dl.datatype.factory;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map.Entry;

import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.entity.FieldConfiguration;

/**
 * The Interface IBulkUploadValidationBuilder.
 */
public interface IBulkUploadValidationBuilder {
	
	/**
	 * @param errorMsg
	 * @param entry
	 * @param mandatory
	 * @return
	 * @throws ApplicationException
	 * @throws ParseException 
	 */
	Boolean getDataTypeValidationBuilder(HashMap<String, Object> successRecord,FieldConfiguration fieldConfiguration, Entry<String, Object> entry,
			Boolean mandatory, Integer userId) throws ApplicationException, ParseException;
}
