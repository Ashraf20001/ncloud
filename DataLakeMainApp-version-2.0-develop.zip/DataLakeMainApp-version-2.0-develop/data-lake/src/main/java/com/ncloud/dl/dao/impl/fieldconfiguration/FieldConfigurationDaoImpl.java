package com.ncloud.dl.dao.impl.fieldconfiguration;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.hibernate.query.NativeQuery;
import org.springframework.stereotype.Repository;

import com.ncloud.dl.config.common.base.dao.BaseDao;
import com.ncloud.dl.constants.core.ApplicationConstants;
import com.ncloud.dl.constants.core.QueryConstants;
import com.ncloud.dl.constants.core.TableConstants;
import com.ncloud.dl.dao.fieldconfiguration.IFieldConfigurationDao;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.entity.FieldConfiguration;
import com.ncloud.dl.transfer.object.enums.RepositoryStatusEnum;


/**
 * The Class FieldConfigurationDaoImpl.
 */
@Repository
public class FieldConfigurationDaoImpl extends BaseDao implements IFieldConfigurationDao{

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
		
	}
	
	/**
	 * Creates the table query.
	 *
	 * @param scriptMap the script map
	 * @param tableName the table name
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void createTableQuery(LinkedHashMap<String, String> scriptMap, String tableName) throws ApplicationException {
		for (Entry<String, String> map : scriptMap.entrySet()) {
			String craeteQuery = ApplicationConstants.CREATE + ApplicationConstants.SPACE + ApplicationConstants.TABLE	
					+ ApplicationConstants.SPACE + map.getKey() + ApplicationConstants.SPACE
					+ ApplicationConstants.OPEN_BRACE + ApplicationConstants.ID_PK + ApplicationConstants.COMMA;
			String tableQuery = craeteQuery.concat(map.getValue()).substring(0,
					craeteQuery.concat(map.getValue()).length()-1) + ApplicationConstants.CLOASE_BRACES;
			NativeQuery<?> nativeQuery = getSession().createNativeQuery(tableQuery + QueryConstants.CREATE_INDEX
					+ ApplicationConstants.DOUBLE_QUOTES + tableName + ApplicationConstants.UNDERSCORE
					+ ApplicationConstants.HASH_CODE + ApplicationConstants.DOUBLE_QUOTES + QueryConstants.ON
					+ ApplicationConstants.DOUBLE_QUOTES + tableName + ApplicationConstants.DOUBLE_QUOTES
					+ QueryConstants.IDX_NAME + ApplicationConstants.SEMICOLON);
			nativeQuery.executeUpdate();
		}
	}

	/**
	 * Save field configuration.
	 *
	 * @param fieldsConfiguration the fields configuration
	 * @return the field configuration
	 * @throws ApplicationException the application exception
	 */
	@Override
	public FieldConfiguration saveFieldConfiguration(FieldConfiguration fieldsConfiguration)
			throws ApplicationException {
		save(fieldsConfiguration, TableConstants.FIELD_CONFIG);
		return fieldsConfiguration;
	}

	/**
	 * Gets the field details.
	 *
	 * @param repositoryId the repository id
	 * @return the field details
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<FieldConfiguration> getFieldDetails(Integer repositoryId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<FieldConfiguration> createQuery = builder.createQuery(FieldConfiguration.class);
		Root<FieldConfiguration> root = createQuery.from(FieldConfiguration.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETE_STS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.REPO_ID), repositoryId)));
		createQuery.orderBy(builder.asc(root.get(TableConstants.FIELD_ORDER)));
		return (List<FieldConfiguration>) getResultList(createQuery(builder, createQuery, root, predicates));
	}
	
	/**
	 * Update field configuration.
	 *
	 * @param fieldDetails the field details
	 */
	@Override
	public void updateFieldConfiguration(FieldConfiguration fieldDetails) {
		update(fieldDetails);
		
	}

	/**
	 * Gets the field configurationdetails.
	 *
	 * @param fieldIdentity the field identity
	 * @return the field configurationdetails
	 */
	@Override
	public FieldConfiguration getFieldConfigurationdetails(String fieldIdentity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<FieldConfiguration> createQuery = builder.createQuery(FieldConfiguration.class);
		Root<FieldConfiguration> root = createQuery.from(FieldConfiguration.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETE_STS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IDENTITY), fieldIdentity)));
		return (FieldConfiguration) getSingleResult(createQuery(builder, createQuery, root, predicates));
	}

	/**
	 * Gets the field mapped in repository.
	 *
	 * @param repositoryName the repository name
	 * @return the field mapped in repository
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<FieldConfiguration> getFieldMappedInRepository(String repositoryName) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<FieldConfiguration> createQuery = builder.createQuery(FieldConfiguration.class);
		Root<FieldConfiguration> root = createQuery.from(FieldConfiguration.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETE_STS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.REPO_ID).get(TableConstants.IS_DELETE_STS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.REPO_ID).get(TableConstants.REPOSITORY_API_NAME), repositoryName)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.REPO_ID).get(TableConstants.IS_DELETE_STS), false))); 
		return (List<FieldConfiguration>) getResultList(createQuery(builder, createQuery, root, predicates));
	}

	/**
	 * Gets the field detail list.
	 *
	 * @param repositoryName the repository name
	 * @return the field detail list
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<FieldConfiguration> getFieldDetailList(String repositoryName) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<FieldConfiguration> createQuery = builder.createQuery(FieldConfiguration.class);
		Root<FieldConfiguration> root = createQuery.from(FieldConfiguration.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETE_STS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.REPO_ID).get(TableConstants.REPOSITORY_NAME), repositoryName)));
		predicates.add(builder.and(builder.notEqual(root.get(TableConstants.REPO_ID).get(TableConstants.REPO_STATUS), RepositoryStatusEnum.DISABLED.getStatusId())));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.REPO_ID).get(TableConstants.IS_ACTIVE), true)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.REPO_ID).get(TableConstants.IS_DELETE_STS), false)));
		createQuery.orderBy(builder.asc(root.get(TableConstants.FIELD_ORDER)));
		return (List<FieldConfiguration>) getResultList(createQuery(builder, createQuery, root, predicates));
	}

}
