package com.ncloud.dl.search.eswrapper;

/**
 * The Interface ISearchHits.
 */
public interface ISearchHits {
	
	/**
	 * Gets the hits.
	 *
	 * @return the hits
	 */
	public ISearchHit[] getHits();
}
