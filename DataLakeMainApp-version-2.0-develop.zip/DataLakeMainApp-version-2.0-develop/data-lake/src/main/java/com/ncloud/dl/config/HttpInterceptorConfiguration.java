package com.ncloud.dl.config;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import lombok.RequiredArgsConstructor;


/**
 * The Class HttpInterceptorConfiguration.
 */
@SuppressWarnings("deprecation")
@Component
@RequiredArgsConstructor
public class HttpInterceptorConfiguration extends WebMvcConfigurerAdapter {

	/** HttpInterceptor. */
	private final HttpInterceptor httpInterceptor;

	/**
	 * Adds the interceptors.
	 *
	 * @param registry the registry
	 */
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(httpInterceptor);
	}
}
