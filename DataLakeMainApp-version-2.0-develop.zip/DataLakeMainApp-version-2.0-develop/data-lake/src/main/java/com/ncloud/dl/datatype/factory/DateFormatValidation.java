package com.ncloud.dl.datatype.factory;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ncloud.dl.constants.core.ApplicationConstants;
import com.ncloud.dl.constants.core.QueryConstants.ColumnConstants;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.exception.core.codes.ErrorCodes;
import com.ncloud.dl.transfer.object.entity.FieldConfiguration;
import com.ncloud.dl.utils.core.ApplicationUtils;

/**
 * The Class DateFormatValidation.
 */
@Service
@Qualifier("dateValidator")
public class DateFormatValidation implements IBulkUploadValidationBuilder {

	/**
	 * dateFormat
	 */
	@Value("${dlmainapp.date-format}")
	private String dateFormat;

	/**
	 * @param errorMsg
	 * @param entry
	 * @param mandatory
	 * @return
	 * @throws ApplicationException
	 * @throws ParseException
	 */
	
	public Boolean getDataTypeValidationBuilder(HashMap<String, Object> successRecord,
			FieldConfiguration fieldConfiguration, Entry<String, Object> entry, Boolean mandatory, Integer userId)
			throws ApplicationException, ParseException {

		successRecord.put(fieldConfiguration.getColumnName(), entry.getValue());
		successRecord.put(ColumnConstants.STATUS, Boolean.FALSE);

		if (Boolean.TRUE.equals(mandatory)) {
			return handleMandatoryField(successRecord, fieldConfiguration, entry);
		} else if (Boolean.FALSE.equals(mandatory)) {
			return handleNonMandatoryField(successRecord, fieldConfiguration, entry);
		}

		return Boolean.FALSE;
	}
	
	
	/**
	 * Handle mandatory field.
	 *
	 * @param successRecord the success record
	 * @param fieldConfiguration the field configuration
	 * @param entry the entry
	 * @return the boolean
	 * @throws ApplicationException the application exception
	 * @throws ParseException the parse exception
	 */
	private Boolean handleMandatoryField(HashMap<String, Object> successRecord, FieldConfiguration fieldConfiguration,
			Entry<String, Object> entry) throws ApplicationException, ParseException {

		String value = entry.getValue().toString();
		
		if (ApplicationUtils.isBlank(value)) {
			return buildErrorMessageForMandatory(successRecord, fieldConfiguration);
		}

		String slashDateFormat = "";
		if (value.contains(ApplicationConstants.SLASH)) {
			slashDateFormat = value;
			value = value.replace(ApplicationConstants.SLASH, ApplicationConstants.HYPHEN);
		}

		if (ApplicationUtils.isValidDateFormat(dateFormat, value)) {
			if (ApplicationUtils.isValidString(slashDateFormat)) {
				Entry<String, Object> convertedDateEntry = convertDateEntryInSuccessRecordMap(successRecord,
						slashDateFormat);
				if (convertedDateEntry != null) {
					successRecord.put(convertedDateEntry.getKey(), value);
				}
			}
			return Boolean.FALSE;
		} else {
			return buildSystemErrorMessage(successRecord, fieldConfiguration);
		}
	}

	/**
	 * Handle non mandatory field.
	 *
	 * @param successRecord the success record
	 * @param fieldConfiguration the field configuration
	 * @param entry the entry
	 * @return the boolean
	 * @throws ApplicationException the application exception
	 * @throws ParseException the parse exception
	 */
	private Boolean handleNonMandatoryField(HashMap<String, Object> successRecord,
			FieldConfiguration fieldConfiguration, Entry<String, Object> entry)
			throws ApplicationException, ParseException {

		String value = entry.getValue().toString();

		if (ApplicationUtils.isValidDateFormat(dateFormat, value)) {
			return Boolean.FALSE;
		} else {
			return buildSystemErrorMessage(successRecord, fieldConfiguration);
		}
	}
	

	/**
	 * Convert date entry in success record map.
	 *
	 * @param successRecord the success record
	 * @param slashDateFormat the slash date format
	 * @return the entry
	 */
	private Entry<String, Object> convertDateEntryInSuccessRecordMap(HashMap<String, Object> successRecord, String slashDateFormat) {
		
		for (Entry<String, Object> entry : successRecord.entrySet()) {
			if(slashDateFormat.equals(entry.getValue())) {
				return entry;
			}
		}
		return null;
	}

	/**
	 * 
	 * @param successRecord
	 * @param fieldConfiguration
	 * @return
	 */
	private Boolean buildErrorMessageForMandatory(HashMap<String, Object> successRecord,
			FieldConfiguration fieldConfiguration) {
		String errorMessage = fieldConfiguration.getErrMsg();
		String errorMsg = ApplicationUtils.isValidateObject(errorMessage) && ApplicationUtils.isNotBlank(errorMessage)
				? errorMessage
				: ErrorCodes.MANDATORY_FIELD.getErrorMessage();
		successRecord.put(ApplicationConstants.ERROR_MSG, errorMsg+ApplicationConstants.EMPTY_STRING+fieldConfiguration.getFieldName());
		return Boolean.TRUE;
	}

	/**
	 * 
	 * @param successRecord
	 * @param fieldConfiguration
	 * @return
	 */
	private Boolean buildSystemErrorMessage(HashMap<String, Object> successRecord,
			FieldConfiguration fieldConfiguration) {
		String errorMsg = ErrorCodes.INVALID_DATE_FORMAT.getErrorMessage();
		successRecord.put(ApplicationConstants.ERROR_MSG, errorMsg+ApplicationConstants.EMPTY_STRING+fieldConfiguration.getFieldName());
		return Boolean.TRUE;
	}

}