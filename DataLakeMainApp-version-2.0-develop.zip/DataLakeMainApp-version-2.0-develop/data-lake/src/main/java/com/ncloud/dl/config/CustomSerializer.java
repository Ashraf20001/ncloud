package com.ncloud.dl.config;

import java.io.Serializable;

import org.apache.commons.lang3.SerializationUtils;
import org.apache.kafka.common.serialization.Serializer;

/**
 * The Class CustomSerializer.
 *
 * @param <T> the generic type
 */
public class CustomSerializer<T extends Serializable> implements Serializer<T> {

	/**
	 * Serialize.
	 *
	 * @param topic the topic
	 * @param data the data
	 * @return the byte[]
	 */
	@Override
	public byte[] serialize(String topic, T data) {
		return SerializationUtils.serialize(data);
	}

}
