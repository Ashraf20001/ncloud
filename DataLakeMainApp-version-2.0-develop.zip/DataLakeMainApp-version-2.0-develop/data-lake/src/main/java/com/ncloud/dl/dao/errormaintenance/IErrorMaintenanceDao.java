package com.ncloud.dl.dao.errormaintenance;

import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.entity.ErrorMaintenance;

public interface IErrorMaintenanceDao {
	
	/**
	 * 
	 * @param errorMaitainence
	 * @throws ApplicationException
	 */
	void saveErrorMaintenanceHistory(ErrorMaintenance errorMaitainence) throws ApplicationException;

}
