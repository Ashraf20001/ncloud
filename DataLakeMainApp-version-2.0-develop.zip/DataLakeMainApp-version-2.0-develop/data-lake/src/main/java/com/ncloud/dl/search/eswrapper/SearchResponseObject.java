package com.ncloud.dl.search.eswrapper;

import java.io.IOException;

import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;

/**
 * The Class SearchResponseObject.
 */
public class SearchResponseObject {

	/** The rest high level client. */
	private final RestHighLevelClient restHighLevelClient;

	/**
	 * Instantiates a new search response object.
	 *
	 * @param restHighLevelClient the rest high level client
	 */
	public SearchResponseObject(RestHighLevelClient restHighLevelClient) {
		super();
		this.restHighLevelClient = restHighLevelClient;
	}
	
	/**
	 * Search.
	 *
	 * @param searchRequest the search request
	 * @param options the options
	 * @return the i search response
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public ISearchResponse search(SearchRequest searchRequest, RequestOptions options) throws IOException {
		SearchResponse searchResponse = restHighLevelClient.search(searchRequest, options);
		return new SearchResponseImpl(searchResponse);
	}
}
