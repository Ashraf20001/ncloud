package com.ncloud.dl.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.dto.NotificationDto;
import com.ncloud.dl.transfer.object.dto.UserInfo;

/**
 * The Interface IRepositoryNotificationService.
 */
public interface IRepositoryNotificationService {

	/**
	 * Gets the un read notifications count.
	 *
	 * @param httpServletRequest the http servlet request
	 * @return the un read notifications count
	 * @throws ApplicationException the application exception
	 */
	Long getUnReadNotificationsCount(HttpServletRequest httpServletRequest) throws ApplicationException;

	/**
	 * Gets the un read notifications.
	 *
	 * @param isViewAllNotifications the is view all notifications
	 * @param httpServletRequest the http servlet request
	 * @return the un read notifications
	 * @throws ApplicationException the application exception
	 */
	List<NotificationDto> getUnReadNotifications(Boolean isViewAllNotifications, HttpServletRequest httpServletRequest) throws ApplicationException;

	/**
	 * Mark as read notification.
	 *
	 * @param identity the identity
	 * @param userInfo the user info
	 * @return the boolean
	 * @throws ApplicationException the application exception
	 */
	Boolean markAsReadNotification(String identity, UserInfo userInfo) throws ApplicationException;

}
