package com.ncloud.dl.service.impl.repository;


import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.apache.commons.math3.util.Precision;
import org.apache.commons.text.WordUtils;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import com.ncloud.dl.constants.core.ApplicationConstants;
import com.ncloud.dl.constants.core.QueryConstants;
import com.ncloud.dl.constants.core.QueryConstants.ColumnConstants;
import com.ncloud.dl.constants.enums.UploadAccessEnum;
import com.ncloud.dl.dao.datarespository.IDataRepositoryDao;
import com.ncloud.dl.dao.fieldconfiguration.IFieldConfigurationDao;
import com.ncloud.dl.dao.fieldoptionlkn.IFieldOptionLinkingDao;
import com.ncloud.dl.dao.notification.INotificationDao;
import com.ncloud.dl.dao.repository.IRepositoryDao;
import com.ncloud.dl.dao.repositoryscheduledetails.IRepositoryScheduleDetailsDao;
import com.ncloud.dl.dao.schedulernotification.ISchedulerNotificationDao;
import com.ncloud.dl.datatype.factory.DataTypeFactory;
import com.ncloud.dl.datatype.factory.IDataTypeFactoryBuilder;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.exception.core.codes.ErrorCodes;
import com.ncloud.dl.exception.core.codes.ErrorId;
import com.ncloud.dl.service.IRepositoryNotificationService;
import com.ncloud.dl.service.IRepositoryService;
import com.ncloud.dl.service.impl.resttemplate.RestTemplateServiceImpl;
import com.ncloud.dl.transfer.object.dto.AccessMappingPrivilegeDto;
import com.ncloud.dl.transfer.object.dto.CommentsDto;
import com.ncloud.dl.transfer.object.dto.CompanyDetailsDto;
import com.ncloud.dl.transfer.object.dto.CronJobData;
import com.ncloud.dl.transfer.object.dto.DataRepositoryDto;
import com.ncloud.dl.transfer.object.dto.FieldOptionLinkingDto;
import com.ncloud.dl.transfer.object.dto.FieldRepositoryDto;
import com.ncloud.dl.transfer.object.dto.FieldsConfiguratorDto;
import com.ncloud.dl.config.model.FilterOrSortingVo;
import com.ncloud.dl.transfer.object.dto.RepositoryScheduleDetailsDto;
import com.ncloud.dl.transfer.object.dto.SchedulerNotificationDto;
import com.ncloud.dl.transfer.object.dto.SchedulerRequestDto;
import com.ncloud.dl.transfer.object.dto.UserDetailsDto;
import com.ncloud.dl.transfer.object.dto.UserInfo;
import com.ncloud.dl.transfer.object.dto.UserPrivillageDto;
import com.ncloud.dl.transfer.object.entity.BulkUploadHistory;
import com.ncloud.dl.transfer.object.entity.Comments;
import com.ncloud.dl.transfer.object.entity.DataRepository;
import com.ncloud.dl.transfer.object.entity.FieldConfiguration;
import com.ncloud.dl.transfer.object.entity.FieldOptionLink;
import com.ncloud.dl.transfer.object.entity.NotificationEvent;
import com.ncloud.dl.transfer.object.entity.NotificationTemplate;
import com.ncloud.dl.transfer.object.entity.RepositoryNotification;
import com.ncloud.dl.transfer.object.entity.RepositoryScheduleDetails;
import com.ncloud.dl.transfer.object.entity.SchedulerNotification;
import com.ncloud.dl.transfer.object.enums.CreatorApprover;
import com.ncloud.dl.transfer.object.enums.DayEnum;
import com.ncloud.dl.transfer.object.enums.FieldDataTypeEnum;
import com.ncloud.dl.transfer.object.enums.FieldSearchTypeEnum;
import com.ncloud.dl.transfer.object.enums.FieldTypeEnum;
import com.ncloud.dl.transfer.object.enums.MonthEnum;
import com.ncloud.dl.transfer.object.enums.RepeatFormatEnum;
import com.ncloud.dl.transfer.object.enums.RepeatOnEnum;
import com.ncloud.dl.transfer.object.enums.RepositoryStatusEnum;
import com.ncloud.dl.utils.core.ApplicationDateUtils;
import com.ncloud.dl.utils.core.ApplicationUtils;

import lombok.RequiredArgsConstructor;



/**
 * The Class RepositoryServiceImpl.
 */
@Service
@Transactional(rollbackOn = Exception.class)
@RequiredArgsConstructor
public class RepositoryServiceImpl implements IRepositoryService {

	/**
	 * IRepositoryDao
	 */
	private final IRepositoryDao repositoryDao;
	
	/** The messaging template. */
	private final SimpMessagingTemplate messagingTemplate;

	/**
	 * iDataRepositoryDao
	 */
	private final IDataRepositoryDao iDataRepositoryDao;
	
	/** The repository notification service. */
	private final IRepositoryNotificationService repositoryNotificationService;
	
	/**
	 * fieldConfigurationDao
	 */
	private final IFieldConfigurationDao fieldConfigurationDao;

	/**
	 * IDataTypeFactoryBuilder
	 */
	private IDataTypeFactoryBuilder iDataTypeFactoryBuilder;
	
	/**
	 * DataTypeFactory
	 */
	private final DataTypeFactory dataTypeFactory;

	/**
	 * fieldOptionLinkingDao
	 */
	private final IFieldOptionLinkingDao fieldOptionLinkingDao;

	/**
	 * RestTemplateServiceImpl
	 */
	private final RestTemplateServiceImpl restTemplateServiceImpl;

	/**
	 * INotificationDao
	 */
	private final INotificationDao iNotificationDao;

	/**
	 * iSchedulerNotificationDao
	 */
	private final ISchedulerNotificationDao iSchedulerNotificationDao;

	/**
	 * IRepositoryScheduleDetailsDao
	 */
	private final IRepositoryScheduleDetailsDao iScheduleDetailsDao;
	
	/**
	 * kafkaTemplate
	 */
	private final KafkaTemplate<String, String> kafkaTemplate;

	/**
	 * @param commentsDto
	 * @param userInfo
	 * @throws ApplicationException
	 */
	@Override
	public String saveCommentsForRepository(CommentsDto commentsDto, UserInfo userInfo,
			HttpServletRequest httpServletRequest) throws ApplicationException {
		String commentsIdentity = null;
		if (ApplicationUtils.isValidateObject(commentsDto)) {
			if (Boolean.FALSE.equals(ApplicationUtils.isValidateObject(userInfo))) {
				throw new ApplicationException(ErrorCodes.INVALID_USER);
			}
			DataRepository dataRepository = getDataRepository(commentsDto.getRepoIdentity());
			if (commentsDto.getAction().equals(CreatorApprover.REQUEST_MODIFY.getAction())) {
				if(dataRepository.getRepoStatus().equals(RepositoryStatusEnum.SUBMITTED.getStatusId())){
					dataRepository.setRepoStatus(RepositoryStatusEnum.DRAFT.getStatusId());
				}
				dataRepository.setMdyDteTme(LocalDateTime.now());
				dataRepository.setMdyUsrId(userInfo.getId());
				iDataRepositoryDao.updateRepostioryDetails(dataRepository);
			}
			Comments comments = wrapCommentsDetails(commentsDto, userInfo, dataRepository);
			repositoryDao.saveComments(comments);
			commentsIdentity = comments.getIdentity();
			saveNotificationDetails(dataRepository, userInfo,
					CreatorApprover.getEnumIdByEnumName(commentsDto.getIsCreator()), commentsDto.getAction(),
					commentsIdentity);
		}
		messagingTemplate.convertAndSend("/topic/notification/", true);
		return commentsIdentity;
	}

	/**
	 * @param commentsDto
	 * @param userInfo
	 * @param dataRepository
	 * @return
	 */
	private Comments wrapCommentsDetails(CommentsDto commentsDto, UserInfo userInfo, DataRepository dataRepository) {
		Comments comments = new Comments();
		comments.setComments(commentsDto.getMessage());
		comments.setRepositoryId(dataRepository);
		comments.setCrtDteTme(LocalDateTime.now());
		comments.setIsCreator(CreatorApprover.getEnumIdByEnumName(commentsDto.getIsCreator()));
		comments.setMdyDteTme(LocalDateTime.now());
		comments.setIsDltSts(Boolean.FALSE);
		comments.setCrtUsrId(userInfo.getId());
		comments.setMdyUsrId(userInfo.getId());
		return comments;
	}

	/**
	 * @param fieldRepositoryDto
	 * @param userInfo
	 * @throws ApplicationException
	 */
	@Override
	public String saveFieldRepostiory(FieldRepositoryDto fieldRepositoryDto, UserInfo userInfo,
			HttpServletRequest httpServletRequest) throws ApplicationException {
		DataRepository dataRepository= null;
		if (ApplicationUtils.isValidList(fieldRepositoryDto.getFieldsConfiguratorDto())
				|| fieldRepositoryDto.getRepositoryStatus().equals(RepositoryStatusEnum.DRAFT.getStatusDesc())) {
			if (ApplicationUtils.isValidateObject(fieldRepositoryDto)) {
				dataRepository = buildDataRepositoryValues(fieldRepositoryDto, userInfo,
						fieldRepositoryDto.getIsCloned());	
				
				validateRepoNameAndId(fieldRepositoryDto, dataRepository.getRepoTableName(), dataRepository.getRepoVersion(), getAllRelatedIds(dataRepository));
				iDataRepositoryDao.saveRepostioryDetails(dataRepository);
				saveFieldConfigurationAndFieldLinkingOption(fieldRepositoryDto, userInfo, dataRepository);
				if (!dataRepository.getRepoStatus()
						.equals(RepositoryStatusEnum.getRepositoryStatusByDesc(ApplicationConstants.DRAFTED))) {
					if(userInfo.getAssociationId() != null) {
						Integer authorityType = preCheck(fieldRepositoryDto, userInfo, httpServletRequest);
						saveNotificationDetails(dataRepository, userInfo, authorityType, fieldRepositoryDto.getAction(),
								null);
					}	
				}
			}
		} else {
			throw new ApplicationException(ErrorCodes.FIELD_VALIDATION);
		}
		if(dataRepository != null) {		
			return dataRepository.getIdentity();
		}else {
			return null;
		}
	}
	
	/**
	 * @param dataRepository
	 * @return
	 */
	public List<String> getAllRelatedIds(DataRepository dataRepository) {
		List<String> identityList = new ArrayList<>();
		DataRepository tempRepository = dataRepository;
		while (tempRepository != null) 
		{
			identityList.add(tempRepository.getIdentity());
			tempRepository = getAllRelatedIdsRecursive(tempRepository);
			if (tempRepository != null) {
				identityList.add(tempRepository.getIdentity());
			}
		}
		return identityList;
	}

    /**
     * @param dataRepository
     * @return
     */
    private DataRepository getAllRelatedIdsRecursive(DataRepository dataRepository) {
       if(dataRepository.getParentRepository() != null) {
    	   return dataRepository.getParentRepository();
       }
       return null;
    }

	/**
	 * @param fieldRepositoryDto
	 * @param repoTableName 
	 * @param repoVersion 
	 * @param list 
	 * @throws ApplicationException 
	 */
	private void validateRepoNameAndId(FieldRepositoryDto fieldRepositoryDto, String repoTableName, Double repoVersion, List<String> list) throws ApplicationException {
		List<DataRepository> dataRepositories = iDataRepositoryDao.getDataRepositoryByRepoNameAndId(
				fieldRepositoryDto.getRepositoryName(), fieldRepositoryDto.getRepositoryId(),
				fieldRepositoryDto.getRepositoryIdentity(), fieldRepositoryDto.getIsCloned(), repoVersion, list);
		DataRepository repositoryName = dataRepositories.stream()
				.filter(a -> a.getRepositoryName().equals(fieldRepositoryDto.getRepositoryName())).findFirst()
				.orElse(null);
		DataRepository repositoryid = dataRepositories.stream()
				.filter(a -> a.getRepositoryId().equals(fieldRepositoryDto.getRepositoryId())).findFirst().orElse(null);
		
		if (ApplicationUtils.isValidateObject(repositoryName)) {
			throw new ApplicationException(ErrorCodes.REPOSITORY_VALIDATION);
		} else if (ApplicationUtils.isValidateObject(repositoryid)) {
			throw new ApplicationException(ErrorCodes.REPOSITORY_ID_VALIDATION);
		}
	}

	/**
	 * @param fieldRepositoryDto
	 * @param userInfo
	 * @param httpServletRequest
	 * @return
	 * @throws ApplicationException
	 */
	private Integer preCheck(FieldRepositoryDto fieldRepositoryDto, UserInfo userInfo,
			HttpServletRequest httpServletRequest) throws ApplicationException {
		if (Boolean.FALSE.equals(ApplicationUtils.isValidateObject(userInfo))) {
			throw new ApplicationException(ErrorCodes.INVALID_USER);
		}
		Integer authorityType = validateUserRoleDetails(fieldRepositoryDto.getAction(), userInfo, httpServletRequest);
		repositoryNotificationService.markAsReadNotification(fieldRepositoryDto.getRepositoryIdentity(), userInfo);
		return authorityType;
	}
	
	/**
	 * @param fieldRepositoryDto
	 * @param userInfo
	 * @param httpServletRequest
	 * @return
	 * @throws ApplicationException
	 */
	private Integer validateUserRoleDetails(String action, UserInfo userInfo, HttpServletRequest httpServletRequest)
			throws ApplicationException {
		List<UserPrivillageDto> userPrivillageDto = restTemplateServiceImpl.checkForPrivelege(httpServletRequest);
		if (!ApplicationUtils.isValidList(userPrivillageDto)) {
			throw new ApplicationException(ErrorCodes.ACCESS_DENIED);
		}
		List<String> privileges = CreatorApprover.getListOfPrivilegeByAction(action);
		if (ApplicationUtils.isValidList(privileges)) {
			boolean userPrivilegeDto = privileges.stream().anyMatch(privilege -> userPrivillageDto.stream()
					.anyMatch(privilegeDto -> privilege.equals(privilegeDto.getPrivillageName())));
			if (Boolean.FALSE.equals(userPrivilegeDto)) {
				throw new ApplicationException(ErrorCodes.ACCESS_DENIED);
			}
		}
		return CreatorApprover.getAuthorityTypeByPrivelegeId(action);
	}

	/**
	 * @param fieldRepositoryDto
	 * @param userInfo
	 * @throws ApplicationException
	 * @param dataRepositorySaved
	 * @throws ApplicationException
	 */
	private void saveFieldConfigurationAndFieldLinkingOption(FieldRepositoryDto fieldRepositoryDto, UserInfo userInfo,
			DataRepository dataRepositorySaved) throws ApplicationException {
		for (FieldsConfiguratorDto fieldsConfiguratorDto : fieldRepositoryDto.getFieldsConfiguratorDto()) {
			FieldConfiguration fieldConfigurationData = ApplicationUtils
					.isValidateObject(fieldsConfiguratorDto.getFieldIdentity())
							? fieldConfigurationDao
									.getFieldConfigurationdetails(fieldsConfiguratorDto.getFieldIdentity())
							: new FieldConfiguration();
			FieldConfiguration fieldConfiguration = saveupdateFieldConfiguration(userInfo, dataRepositorySaved,
					fieldsConfiguratorDto, fieldConfigurationData);
			saveOrUpdateDropdownOptions(fieldsConfiguratorDto, fieldConfiguration, userInfo);
			deleteDropdownOptions(userInfo, fieldsConfiguratorDto);
		}
	}

	/**
	 * @param userInfo
	 * @param fieldsConfiguratorDto
	 */
	private void deleteDropdownOptions(UserInfo userInfo, FieldsConfiguratorDto fieldsConfiguratorDto) {
		if (ApplicationUtils.isValidList(fieldsConfiguratorDto.getDeletedOptions())) {
			for (String optionIdentity : fieldsConfiguratorDto.getDeletedOptions()) {
				FieldOptionLink fieldOptionLink = fieldOptionLinkingDao.getFieldOptionLinking(optionIdentity);
				if (ApplicationUtils.isValidateObject(fieldOptionLink)) {
					fieldOptionLink.setIsDltSts(Boolean.TRUE);
					fieldOptionLink.setMdyDteTme(LocalDateTime.now());
					fieldOptionLink.setMdyUsrId(userInfo.getId());
					fieldOptionLinkingDao.updateFieldOptionLnk(fieldOptionLink);
				}
			}
		}
	}

	/**
	 * @param userInfo
	 * @param dataRepositorySaved
	 * @param fieldsConfiguratorDto
	 * @param fieldConfigurationData
	 * @return
	 * @throws ApplicationException
	 */
	private FieldConfiguration saveupdateFieldConfiguration(UserInfo userInfo, DataRepository dataRepositorySaved,
			FieldsConfiguratorDto fieldsConfiguratorDto, FieldConfiguration fieldConfigurationData)
			throws ApplicationException {
		FieldConfiguration fieldsConfiguration = buildFieldConfigurationDetails(dataRepositorySaved,
				fieldsConfiguratorDto, userInfo, fieldConfigurationData);
		if (!ApplicationUtils.isValidateObject(fieldsConfiguration.getIdentity())) {
			fieldsConfiguration = fieldConfigurationDao.saveFieldConfiguration(fieldsConfiguration);
		} else {
			fieldConfigurationDao.updateFieldConfiguration(fieldsConfiguration);
		}
		return fieldsConfiguration;
	}

	/**
	 * @param fieldRepositoryDto
	 * @param userInfo
	 * @param httpServletRequest
	 * @throws ApplicationException
	 */
	@Override
	public void approveRepository(FieldRepositoryDto fieldRepositoryDto, UserInfo userInfo, HttpServletRequest httpServletRequest) throws ApplicationException {
		updateRepositoryDetails(fieldRepositoryDto, userInfo, httpServletRequest);
		DataRepository dataRepository = repositoryDao.getRepositoryDetails(fieldRepositoryDto.getRepositoryIdentity());
		List<FieldConfiguration> fieldDataList = iDataRepositoryDao.getFieldRepository(dataRepository.getIdentity());
		if (ApplicationUtils.isValidList(fieldDataList)) {
			dataEntryInTable(userInfo, dataRepository);
			String tableName = dataRepository.getRepoTableName().trim().toLowerCase();
			String valQuery = null;
			valQuery = buildFieldQueryByDataType(fieldDataList, valQuery);
			if (ApplicationUtils.isValidString(valQuery)) {
				LinkedHashMap<String, String> scriptMap = new LinkedHashMap<>();
				scriptMap.put(ApplicationConstants.DOUBLE_QUOTES + tableName + ApplicationConstants.DOUBLE_QUOTES,
						valQuery + QueryConstants.SYSTEM_DEFAULT_COLUMNS);
				fieldConfigurationDao.createTableQuery(scriptMap, tableName);
				kafkaTemplate.send(ColumnConstants.IDX_PREFIX + dataRepository.getRepoTableName(), "{}");
			}
		}
	}

	/**
	 * @param userInfo
	 * @param dataRepository
	 * @throws ApplicationException
	 */
	private void dataEntryInTable(UserInfo userInfo, DataRepository dataRepository) throws ApplicationException {
		SchedulerNotification schedulerNotification = new SchedulerNotification();
		schedulerNotification.setMessage("Upload Data For " + dataRepository.getRepositoryName());
		schedulerNotification.setNotificationName(dataRepository.getRepositoryName());
		schedulerNotification.setIdentity(ApplicationUtils.getUniqueId());
		schedulerNotification.setMdyDteTme(LocalDateTime.now());
		schedulerNotification.setRemainder(1);
		schedulerNotification.setRepositoryId(dataRepository);
		schedulerNotification.setStatus(true);
		schedulerNotification.setTriggeredStatus(RepositoryStatusEnum.getRepositoryStatusById(dataRepository.getRepoStatus()));
		schedulerNotification.setCrtUsrId(userInfo.getId());
		schedulerNotification.setCrtDteTme(LocalDateTime.now());
		schedulerNotification.setMdyUsrId(userInfo.getId());
		schedulerNotification.setMdyDteTme(LocalDateTime.now());
		schedulerNotification.setIsDltSts(Boolean.FALSE);
		SchedulerNotification scNotification = iSchedulerNotificationDao
				.saveSchedulerNotification(schedulerNotification);
		saveRepositorySchedulerDetails(scNotification,userInfo);
	}

	/**
	 * Save repository scheduler details.
	 *
	 * @param scNotification the sc notification
	 * @param userInfo the user info
	 * @throws ApplicationException the application exception
	 */
	private void saveRepositorySchedulerDetails(SchedulerNotification scNotification,UserInfo userInfo) throws ApplicationException {
		RepositoryScheduleDetails repositoryScheduleDetails = new RepositoryScheduleDetails();
		repositoryScheduleDetails.setCrtDteTme(LocalDateTime.now());
		repositoryScheduleDetails.setCrtUsrId(userInfo.getId());
		repositoryScheduleDetails.setEndDate(LocalDateTime.now().toString());
		repositoryScheduleDetails.setIdentity(ApplicationUtils.getUniqueId());
		repositoryScheduleDetails.setIsDltSts(Boolean.FALSE);
		repositoryScheduleDetails.setMdyDteTme(LocalDateTime.now());
		repositoryScheduleDetails.setRepeatCount(1);
		repositoryScheduleDetails.setRepeatFormat("DAY");
		repositoryScheduleDetails.setRepeatOn("FIRST");
		repositoryScheduleDetails.setRepeatOnday("MON");
		repositoryScheduleDetails.setRepeatOnMonth("JAN");
		repositoryScheduleDetails.setSchedulerNotificationId(scNotification);
		repositoryScheduleDetails.setSelectedDate(1);
		repositoryScheduleDetails.setSelectedDays("MON");
		repositoryScheduleDetails.setSelectedMonth("JAN");
		repositoryScheduleDetails.setMdyUsrId(userInfo.getId());
		repositoryScheduleDetails.setStartDatewithtime(LocalDate.now() +" "+ "00:00");
		iScheduleDetailsDao.saveRepositoryScheduleDetails(repositoryScheduleDetails);
	}

	
	/**
	 * Trigger scheduler.
	 *
	 * @param schedulerIdentity the scheduler identity
	 * @param timeInterval the time interval
	 * @param repositoryScheduleDetails the repository schedule details
	 * @param platformName the platform name
	 * @param associationId the association id
	 * @throws ApplicationException the application exception
	 */
	private void triggerScheduler(String schedulerIdentity, Integer timeInterval, RepositoryScheduleDetails repositoryScheduleDetails, String platformName, Integer associationId) throws ApplicationException {
		if(ApplicationUtils.isValidateObject(repositoryScheduleDetails)) {
			SchedulerRequestDto schedulerRequestDto = new SchedulerRequestDto();
			schedulerRequestDto.setClaimId(repositoryScheduleDetails.getId());
			schedulerRequestDto.setStatus(schedulerIdentity);
			schedulerRequestDto.setIsReceivable(false);		//dummy value
			schedulerRequestDto.setTimeInterval(timeInterval);
			schedulerRequestDto.setPlatformName(platformName);
			schedulerRequestDto.setAssociationId(associationId);
			schedulerRequestDto.setIsCronJob(true);
			CronJobData cronJobData = new CronJobData();
			cronJobData.setStartDateWithTime(repositoryScheduleDetails.getStartDatewithtime());
			cronJobData.setRepeatCount(repositoryScheduleDetails.getRepeatCount());
			cronJobData.setRepeatFormat(RepeatFormatEnum.valueOf(repositoryScheduleDetails.getRepeatFormat()));
			String selectedDays = repositoryScheduleDetails.getSelectedDays();
			if (ApplicationUtils.isNotBlank(selectedDays)) {
				cronJobData.setSelectedDays(
						Arrays.asList(selectedDays.split(",")).stream().map(s -> DayEnum.valueOf(s)).toList());
			} else {
				cronJobData.setSelectedDays(null);
			}
			if (ApplicationUtils.isNotBlank(repositoryScheduleDetails.getRepeatOn())) {
				cronJobData.setRepeatOn(RepeatOnEnum.valueOf(repositoryScheduleDetails.getRepeatOn()));
			} else {
				cronJobData.setRepeatOn(null);
			}
			if (ApplicationUtils.isNotBlank(repositoryScheduleDetails.getRepeatOnday())) {
				cronJobData.setRepeatOnDay(DayEnum.valueOf(repositoryScheduleDetails.getRepeatOnday()));
			} else {
				cronJobData.setRepeatOnDay(null);
			}
			if (ApplicationUtils.isNotBlank(repositoryScheduleDetails.getSelectedMonth())) {
				cronJobData.setSelectedMonth(MonthEnum.valueOf(repositoryScheduleDetails.getSelectedMonth()));
			} else {
				cronJobData.setSelectedMonth(null);
			}
			cronJobData.setSelectedDate(repositoryScheduleDetails.getSelectedDate());
			cronJobData.setEndDate(repositoryScheduleDetails.getEndDate());
			schedulerRequestDto.setCronData(cronJobData);
			restTemplateServiceImpl.triggerScheduler(schedulerRequestDto);
		}
	}
	
	
	/**
	 * @param userInfo
	 * @return
	 * @throws ApplicationException
	 * @throws UnsupportedEncodingException 
	 */
	public List<String> getCompanyUploadStatus(Integer associationId, String fromDate) throws ApplicationException, UnsupportedEncodingException {
		List<String> companyNamList;
		if (!ApplicationUtils.isValidateObject(associationId)) {
			throw new ApplicationException(ErrorCodes.INVALID_USER);
		}
		List<CompanyDetailsDto> companyDetailsDtos = restTemplateServiceImpl.getCompanyNameList(associationId);
		if (!ApplicationUtils.isValidList(companyDetailsDtos)) {
			throw new ApplicationException(ErrorCodes.INVALID_DATA);
		}
		List<Integer> companyIdList = companyDetailsDtos.stream().map(CompanyDetailsDto::getCompanyId)
				.collect(Collectors.toList());
		String decodedString = URLDecoder.decode(fromDate, StandardCharsets.UTF_8);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy");
		LocalDateTime localDateTime = LocalDateTime.parse(decodedString, formatter);
		companyNamList = getCompanyNamesToRemindForDataUpload(companyDetailsDtos, companyIdList, localDateTime);
		return companyNamList;
	}

	/**
	 * @param companyDetailsDtos
	 * @param companyIdList
	 * @param localDateTime
	 * @return
	 */
	private List<String> getCompanyNamesToRemindForDataUpload(List<CompanyDetailsDto> companyDetailsDtos,
			List<Integer> companyIdList, LocalDateTime localDateTime) {
		List<String> companyNamList;
		List<BulkUploadHistory> bulkUploadHistory = iDataRepositoryDao.getBulkUploadHistoryDetails(companyIdList,
				localDateTime, LocalDateTime.now());
		if (ApplicationUtils.isValidList(bulkUploadHistory)) {
			companyNamList = companyDetailsDtos.stream()
					.filter(dto -> bulkUploadHistory.stream()
							.anyMatch(history -> !history.getCompanyId().equals(dto.getCompanyId())))
					.map(CompanyDetailsDto::getCompanyName).collect(Collectors.toList());
		} else {
			companyNamList = companyDetailsDtos.stream().map(CompanyDetailsDto::getCompanyName)
					.collect(Collectors.toList());
		}
		return companyNamList;
	}
	
	
	

	/**
	 * @param fieldDataList
	 * @param valQuery
	 * @return
	 */
	private String buildFieldQueryByDataType(List<FieldConfiguration> fieldDataList, String valQuery) {
		for (FieldConfiguration fieldConfiguration : fieldDataList) {
			if(ApplicationUtils.isValidateObject(fieldConfiguration.getDataType())) {
				iDataTypeFactoryBuilder = dataTypeFactory.getFieldDetailManagerType(
						FieldDataTypeEnum.getFieldDataTypeById(fieldConfiguration.getDataType()));
			} else {
				iDataTypeFactoryBuilder = dataTypeFactory.getFieldDetailManagerType(FieldDataTypeEnum.STRING.getValue());
			}
			if (ApplicationUtils.isValidateObject(iDataTypeFactoryBuilder)) {
				valQuery = iDataTypeFactoryBuilder.getDataTypeWithColQuery(
						fieldConfiguration.getFieldName().toLowerCase().trim().replace(ApplicationConstants.SPACE, "_"),
						valQuery);
			}
		}
		return valQuery;
	}

	/**
	 * @param repoId
	 * @return
	 * @throws ApplicationException
	 */
	private DataRepository getDataRepository(String repositoryId) throws ApplicationException {
		DataRepository repository = repositoryDao.getRepositoryDetails(repositoryId);
		if (!ApplicationUtils.isValidateObject(repositoryId)) {
			throw new ApplicationException(ErrorCodes.INVALID_IDENTITY);
		}
		return repository;
	}

	/**
	 * @param dataRepositorySaved
	 * @param fieldsConfiguratorDto
	 * @param userInfo
	 * @return
	 */
	private FieldConfiguration buildFieldConfigurationDetails(DataRepository dataRepositorySaved,
			FieldsConfiguratorDto fieldsConfiguratorDto, UserInfo userInfo, FieldConfiguration fieldsConfiguration) {
		fieldsConfiguration.setCrtDteTme(LocalDateTime.now());
		fieldsConfiguration.setDataType(FieldDataTypeEnum.getFieldDataTypeByDesc(fieldsConfiguratorDto.getDataType()));
		fieldsConfiguration.setErrMsg(fieldsConfiguratorDto.getErrorMessage().trim());
		fieldsConfiguration.setFieldName(fieldsConfiguratorDto.getFieldName().trim());
		fieldsConfiguration.setColumnName(fieldsConfiguratorDto.getFieldName().toLowerCase().trim().replace(ApplicationConstants.SPACE, "_"));
		fieldsConfiguration.setFieldOrder(fieldsConfiguratorDto.getPosistion());
		fieldsConfiguration.setIsDltSts(Boolean.FALSE);
		fieldsConfiguration.setIsMandatory(fieldsConfiguratorDto.getIsMandatory());
		fieldsConfiguration.setRepoId(dataRepositorySaved);
		fieldsConfiguration.setCrtUsrId(userInfo.getId());
		fieldsConfiguration.setMdyUsrId(userInfo.getId());
		fieldsConfiguration.setMdyDteTme(LocalDateTime.now());
		fieldsConfiguration.setFieldType(FieldTypeEnum.getFieldTypeIdByTypeName(fieldsConfiguratorDto.getFieldType()));
		fieldsConfiguration
				.setSearchType(FieldSearchTypeEnum.getFieldSearchTypeByDesc(fieldsConfiguratorDto.getSearchType()));
		return fieldsConfiguration;
	}

	/**
	 * @param fieldsConfiguratorDto
	 * @param fieldConfiguration
	 * @param userInfo
	 * @throws ApplicationException
	 */
	private void saveOrUpdateDropdownOptions(FieldsConfiguratorDto fieldsConfiguratorDto,
			FieldConfiguration fieldConfiguration, UserInfo userInfo) throws ApplicationException {
		if (ApplicationUtils.isValidList(fieldsConfiguratorDto.getListofFieldOptions())) {
			// Duplicate optionValue check
			Set<String> uniqueValues =  new HashSet<>();
			boolean hasDuplicates = false;
			String duplicateValue = null;
			
			for (FieldOptionLinkingDto fieldOptionLinkingDto : fieldsConfiguratorDto.getListofFieldOptions()) {
				String lowercaseValue = fieldOptionLinkingDto.getFieldOptionName().toLowerCase();
				if(uniqueValues.contains(lowercaseValue)) {
					duplicateValue = fieldOptionLinkingDto.getFieldOptionName();
					hasDuplicates = true;
				}
				uniqueValues.add(lowercaseValue);
				if(hasDuplicates) {
					throwDuplicateOptionErrorMessage(duplicateValue,ErrorCodes.DUPLICATE_DROPDOWN);
				}
				if (ApplicationUtils.isValidIdentity(fieldOptionLinkingDto.getFieldOptionIdentity())) {
					persistFieldOption(userInfo, fieldOptionLinkingDto); // UPDATE DROPDOWN OPTIONS
				} else {
					saveFieldConfigurationLinking(fieldConfiguration, userInfo, fieldOptionLinkingDto);
				}
			}
		}
	}
	
	/**
	 * @param minAmount
	 * @param errValue 
	 * @throws ApplicationException
	 */
	private void throwDuplicateOptionErrorMessage(String duplicateDropDown, ErrorId errValue) throws ApplicationException {
		String error = errValue.getErrorMessage().replace(ApplicationConstants.DUPLICATE_OPTION_VALUE,duplicateDropDown) ;
		ErrorId er = new ErrorId();
		List<ErrorId.ErrorHint> errorHintList = new ArrayList<>();
		ErrorId.ErrorHint errorhint = new ErrorId.ErrorHint((String) ApplicationConstants.DUPLICATE_OPTION_VALUE,duplicateDropDown);
		errorHintList.add(errorhint);
		er = new ErrorId(errValue.getErrorCode(),error,errorHintList);
		throw new ApplicationException(er);
	}

	/**
	 * @param userInfo
	 * @param fieldOptionLinkingDto
	 */
	private void persistFieldOption(UserInfo userInfo, FieldOptionLinkingDto fieldOptionLinkingDto) {
		FieldOptionLink fieldOptionLink = fieldOptionLinkingDao
				.getFieldOptionLinking(fieldOptionLinkingDto.getFieldOptionIdentity());
		if (ApplicationUtils.isValidateObject(fieldOptionLink)) {
			fieldOptionLink.setDropdownOptions(fieldOptionLinkingDto.getFieldOptionName());
			fieldOptionLink.setMdyDteTme(LocalDateTime.now());
			fieldOptionLink.setMdyUsrId(userInfo.getId());
			fieldOptionLinkingDao.updateFieldOptionLnk(fieldOptionLink);
		}
	}

	/**
	 * @param fieldConfiguration
	 * @param userInfo
	 * @param option
	 * @throws ApplicationException
	 */
	private void saveFieldConfigurationLinking(FieldConfiguration fieldConfiguration, UserInfo userInfo,
			FieldOptionLinkingDto option) throws ApplicationException {
		FieldOptionLink fieldOptionLink = new FieldOptionLink();
		fieldOptionLink.setCrtDteTme(LocalDateTime.now());
		fieldOptionLink.setDropdownOptions(option.getFieldOptionName());
		fieldOptionLink.setFieldId(fieldConfiguration);
		fieldOptionLink.setCrtUsrId(userInfo.getId());
		fieldOptionLink.setMdyUsrId(userInfo.getId());
		fieldOptionLink.setIsDltSts(Boolean.FALSE);
		fieldOptionLinkingDao.saveFieldOptionLnk(fieldOptionLink);
	}

	/**
	 * @param fieldRepositoryDto
	 * @param isCloneFlow
	 * @return
	 * @throws ApplicationException
	 */
	private DataRepository buildDataRepositoryValues(FieldRepositoryDto fieldRepositoryDto, UserInfo userInfo,
			Boolean isCloneFlow) throws ApplicationException {
		DataRepository dataRepository = new DataRepository();
		Double repositoryVersion = ApplicationConstants.V1;
		if (ApplicationUtils.isValidBoolean(isCloneFlow) && isCloneFlow) {
			DataRepository updatedRepository = versionUpgradeForClonedRepository(fieldRepositoryDto, userInfo);
			repositoryVersion = Precision.round(updatedRepository.getRepoVersion() + 0.1, 2);
			dataRepository.setParentRepository(updatedRepository);
		}
		dataRepository.setRepositoryName(fieldRepositoryDto.getRepositoryName().trim());
		dataRepository.setRepositoryId(fieldRepositoryDto.getRepositoryId().trim());
		dataRepository.setRepoDescription(fieldRepositoryDto.getRepositoryDesc().trim());
		dataRepository.setRepoVersion(repositoryVersion);
		dataRepository.setUploadAccess(UploadAccessEnum.getUploadAccessIdByUserType(fieldRepositoryDto.getUploadAccess()));
		dataRepository.setRepoApiName(ApplicationUtils.isValidBoolean(isCloneFlow) && isCloneFlow
				? fieldRepositoryDto.getRepositoryName().trim().toLowerCase().replace(" ", ApplicationConstants.HYPHEN)
						+ repositoryVersion + ApplicationConstants.API_REPO
				: fieldRepositoryDto.getRepositoryName().trim().toLowerCase().replace(" ", ApplicationConstants.HYPHEN)
						+ ApplicationConstants.API_REPO);
		dataRepository.setRepoTableName(ApplicationUtils.isValidBoolean(isCloneFlow) && isCloneFlow
				? fieldRepositoryDto.getRepositoryName().toLowerCase().trim().replace(" ",
						ApplicationConstants.UNDERSCORE) + ApplicationConstants.UNDERSCORE
						+ repositoryVersion + ApplicationConstants.TABLE_REPO
				: fieldRepositoryDto.getRepositoryName().toLowerCase().trim().replace(" ",
						ApplicationConstants.UNDERSCORE) + ApplicationConstants.TABLE_REPO);
		dataRepository.setCrtDteTme(LocalDateTime.now());
		dataRepository.setRepoStatus(
				RepositoryStatusEnum.getRepositoryStatusByDesc(fieldRepositoryDto.getRepositoryStatus()));
		dataRepository.setCrtUsrId(userInfo.getId());
		dataRepository.setMdyUsrId(userInfo.getId());
		dataRepository.setIsDltSts(Boolean.FALSE);
		dataRepository.setIsActive(Boolean.TRUE);
		dataRepository.setFieldCount(fieldRepositoryDto.getFieldsConfiguratorDto().size());
		return dataRepository;
	}

	/**
	 * @param fieldRepositoryDto
	 * @param userInfo
	 * @return
	 * @throws ApplicationException
	 */
	private DataRepository versionUpgradeForClonedRepository(FieldRepositoryDto fieldRepositoryDto, UserInfo userInfo)
			throws ApplicationException {
		DataRepository dataRepository = repositoryDao.getRepositoryDetails(fieldRepositoryDto.getRepositoryIdentity());
		if (ApplicationUtils.isValidateObject(dataRepository)) {
			dataRepository.setIsActive(Boolean.FALSE);
			dataRepository.setMdyDteTme(LocalDateTime.now());
			dataRepository.setRepoStatus(RepositoryStatusEnum.DISABLED.getStatusId());
			dataRepository.setEffectiveTo(LocalDate.now().minusDays(ApplicationConstants.ONE));
			dataRepository.setMdyUsrId(userInfo.getId());
			repositoryDao.updateRepostioryDetails(dataRepository);
		}
		return dataRepository;
	}

	/**
	 * @param repositoryIdentity
	 * @return
	 */
	@Override
	public List<CommentsDto> getCommentsValues(String repositoryIdentity, HttpServletRequest httpServletRequest)
			throws ApplicationException {
		List<CommentsDto> commentsDtos = new ArrayList<>();
		if (ApplicationUtils.isValidIdentity(repositoryIdentity)) {
			List<Comments> comments = iDataRepositoryDao.getCommentsValues(repositoryIdentity);
			Map<Integer, String> mapInteger = new HashMap<>();
			List<Integer> userIds = comments.stream().map(Comments::getCrtUsrId).distinct()
					.collect(Collectors.toList());
			if (ApplicationUtils.isValidateObject(userIds)) {
				List<UserDetailsDto> entity = restTemplateServiceImpl.getUserNameByUserIdRestTemplate(httpServletRequest, userIds);
				mapInteger = entity.stream()
						.collect(Collectors.toMap(UserDetailsDto::getId, UserDetailsDto::getUsername));
			}
			if (ApplicationUtils.isValidList(comments)) { 
				List<Integer> userIdList = comments.stream().map(Comments::getCrtUsrId).distinct().toList();
				if(ApplicationUtils.isValidList(userIdList)) {
					Map<Integer, String> userIdProfileMap = restTemplateServiceImpl.getImageName(userIdList,httpServletRequest);
				for (Comments comment : comments) {
					CommentsDto commentsDto = buildComentsDto(comment, repositoryIdentity,
							mapInteger.get(comment.getCrtUsrId()),userIdProfileMap);
					commentsDtos.add(commentsDto);
				}
				}
			}
		}
		return commentsDtos;
	}

	/**
	 * @param comment
	 * @param repositoryIdentity
	 * @return
	 */
	private CommentsDto buildComentsDto(Comments comment, String repositoryIdentity, String userName, Map<Integer, String> userIdProfileMap) {
		CommentsDto commentsDto = new CommentsDto();
		commentsDto.setMessage(comment.getComments());
		commentsDto.setRepositoryName(comment.getRepositoryId().getRepositoryName());
		commentsDto.setIdentity(comment.getIdentity());
		commentsDto.setRepoIdentity(repositoryIdentity);
		commentsDto.setStatus(RepositoryStatusEnum.getRepositoryStatusById(comment.getRepositoryId().getRepoStatus()));
		commentsDto.setIsCreator(CreatorApprover.getUserRolePrivellageAction(comment.getIsCreator()));
		commentsDto.setUserName(
				ApplicationUtils.isValidateObject(userName) ? userName : ApplicationConstants.EMPTY_STRING);
		LocalDateTime dateTime = ApplicationDateUtils.convertDateFormat(comment.getCrtDteTme());
		commentsDto.setCreatedDate(dateTime.toLocalDate());
		commentsDto.setCreatedTime(dateTime.toLocalTime());
		commentsDto.setLogoUrl(userIdProfileMap.get(comment.getCrtUsrId())); 
		commentsDto.setIsRightCmts(Boolean.FALSE);
		commentsDto.setRepoName(ApplicationUtils.isValidateObject(comment.getRepositoryId())
				? comment.getRepositoryId().getRepositoryName()
				: null);
		return commentsDto;
	}

	/**
	 * @param schedulerlist
	 * @return
	 */
	private SchedulerNotificationDto buildSchedulerdto(SchedulerNotification schedulerentity) {
		SchedulerNotificationDto SchedulerDto = new SchedulerNotificationDto();
		SchedulerDto.setMessage(schedulerentity.getMessage());
		SchedulerDto.setNotificationName(schedulerentity.getNotificationName());
		SchedulerDto.setRemainder(schedulerentity.getRemainder());
		SchedulerDto.setStatus(schedulerentity.getStatus());
		SchedulerDto.setTriggeredStatus(schedulerentity.getTriggeredStatus());
		SchedulerDto.setIdentity(schedulerentity.getRepositoryId().getIdentity());
		return SchedulerDto;
	}

	/**
	 * @param identity
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public String updateStatusDataRepository(String repositoryIdentity, String action,UserInfo userInfo,HttpServletRequest httpServletRequest) throws ApplicationException {
		DataRepository dataRepository = iDataRepositoryDao.getUpdateStatusDataRepository(repositoryIdentity);
		if (Boolean.FALSE.equals(ApplicationUtils.isValidateObject(dataRepository))) {
			throw new ApplicationException(ErrorCodes.INVALID_IDENTITY);
		}
		if (Boolean.FALSE.equals(RepositoryStatusEnum.SUBMITTED.getStatusId().equals(dataRepository.getRepoStatus()))) {
			throw new ApplicationException(ErrorCodes.INVALID_STATUS);
		}
		dataRepository.setRepoStatus(
				RepositoryStatusEnum.getRepositoryStatusByDesc(RepositoryStatusEnum.REJECTED.getStatusDesc()));
		dataRepository.setMdyUsrId(dataRepository.getMdyUsrId());
		dataRepository.setMdyDteTme(dataRepository.getCrtDteTme());
		iDataRepositoryDao.saveUpdateStatusDataRepository(dataRepository);
		FieldRepositoryDto fieldRepositoryDto = new FieldRepositoryDto();
		fieldRepositoryDto.setAction(action);
		fieldRepositoryDto.setRepositoryIdentity(repositoryIdentity);
		Integer authorityType=preCheck(fieldRepositoryDto,userInfo,httpServletRequest);
		saveNotificationDetails(dataRepository, userInfo, authorityType, fieldRepositoryDto.getAction(),
				null);
		return repositoryIdentity;
	}

	/**
	 * @param repositoryIdentity
	 * @return
	 */
	@Override
	public FieldRepositoryDto getRepositoryAndFieldDetails(String repositoryIdentity) {
		DataRepository dataRepository = repositoryDao.getRepositoryDetails(repositoryIdentity);
		List<Comments> comments = iDataRepositoryDao.getCommentsValues(repositoryIdentity);
		List<FieldConfiguration> fieldConfiguration = fieldConfigurationDao.getFieldDetails(dataRepository.getId());
		FieldRepositoryDto fieldRepositoryDto = new FieldRepositoryDto();
		fieldRepositoryDto.setIsCommented(ApplicationUtils.isValidList(comments) ? Boolean.TRUE : Boolean.FALSE);
		fieldRepositoryDto.setRepositoryId(dataRepository.getRepositoryId());
		fieldRepositoryDto.setRepositoryIdentity(dataRepository.getIdentity());
		fieldRepositoryDto.setRepositoryDesc(dataRepository.getRepoDescription());
		fieldRepositoryDto.setRepositoryName(dataRepository.getRepositoryName());
		fieldRepositoryDto.setUploadAccess(UploadAccessEnum.getUploadAccessById(dataRepository.getUploadAccess()));
		fieldRepositoryDto
				.setRepositoryStatus(RepositoryStatusEnum.getRepositoryStatusById(dataRepository.getRepoStatus()));
		fieldRepositoryDto.setRepositoryVersion(dataRepository.getRepoVersion());
		fieldRepositoryDto.setFieldsConfiguratorDto(getfieldConfiguration(fieldConfiguration));
		return fieldRepositoryDto;
	}

	/**
	 * @param fieldConfiguration
	 * @return
	 */
	private List<FieldsConfiguratorDto> getfieldConfiguration(List<FieldConfiguration> fieldConfiguration) {
		List<FieldsConfiguratorDto> fieldDetailsList = new ArrayList<>();
		for (FieldConfiguration fieldConfig : fieldConfiguration) {
			FieldsConfiguratorDto fieldsData = new FieldsConfiguratorDto();
			fieldsData.setDataType(FieldDataTypeEnum.getFieldDataTypeById(fieldConfig.getDataType()));
			fieldsData.setErrorMessage(fieldConfig.getErrMsg());
			fieldsData.setFieldName(fieldConfig.getFieldName());
			fieldsData.setColumnName(fieldConfig.getFieldName().toLowerCase().trim().replace(ApplicationConstants.SPACE, "_"));
			fieldsData.setPosistion(fieldConfig.getFieldOrder());
			fieldsData.setFieldType(FieldTypeEnum.getFieldTypeNameByTypeId(fieldConfig.getFieldType()));
			fieldsData.setSearchType(FieldSearchTypeEnum.getFieldSearchTypeById(fieldConfig.getSearchType()));
			fieldsData.setFieldIdentity(fieldConfig.getIdentity());
			fieldsData.setIsMandatory(fieldConfig.getIsMandatory());
			fieldsData.setListofFieldOptions(getfieldOptionList(fieldConfig.getIdentity()));
			fieldDetailsList.add(fieldsData);
		}
		return fieldDetailsList;
	}

	/**
	 * @param fieldId
	 * @return
	 */
	private List<FieldOptionLinkingDto> getfieldOptionList(String fieldId) {
		List<FieldOptionLink> fieldOptionLink = fieldOptionLinkingDao.getFieldOptionList(fieldId);
		List<FieldOptionLinkingDto> dropDownList = new ArrayList<>();
		for (FieldOptionLink fieldOptionDrop : fieldOptionLink) {
			FieldOptionLinkingDto fieldOptionLinkingDto = new FieldOptionLinkingDto();
			fieldOptionLinkingDto.setFieldOptionName(fieldOptionDrop.getDropdownOptions());
			fieldOptionLinkingDto.setFieldOptionIdentity(fieldOptionDrop.getIdentity());
			dropDownList.add(fieldOptionLinkingDto);
		}
		return dropDownList;
	}

	/**
	 * @param fieldRepositoryDto
	 * @param loggedInUser
	 * @throws ApplicationException
	 */
	@Override
	public Boolean updateRepositoryDetails(FieldRepositoryDto fieldRepositoryDto, UserInfo loggedInUser,
			HttpServletRequest httpServletRequest) throws ApplicationException {
	if(loggedInUser.getAssociationId() != null) {
		preCheck(fieldRepositoryDto, loggedInUser, httpServletRequest);
	}		
	if (!ApplicationUtils.isValidateObject(fieldRepositoryDto.getRepositoryIdentity())) {
		String identity = saveFieldRepostiory(fieldRepositoryDto, loggedInUser, httpServletRequest);
		fieldRepositoryDto.setRepositoryIdentity(identity);
	} else {
	    DataRepository dataRepository = repositoryDao.getRepositoryDetails(fieldRepositoryDto.getRepositoryIdentity());
		if (!ApplicationUtils.isValidateObject(dataRepository)) {
			throw new ApplicationException(ErrorCodes.INVALID_IDENTITY);
		}
		DataRepository updatedRepository = updateDataRepository(dataRepository, fieldRepositoryDto, loggedInUser);
		validateRepoNameAndId(fieldRepositoryDto, dataRepository.getRepoTableName(), updatedRepository.getRepoVersion(), getAllRelatedIds(updatedRepository));
		saveNotificationForSubmitStatus(fieldRepositoryDto, loggedInUser, httpServletRequest, dataRepository,
				updatedRepository);
		if (ApplicationUtils.isValidList(fieldRepositoryDto.getFieldsConfiguratorDto())) {
			saveFieldConfigurationAndFieldLinkingOption(fieldRepositoryDto, loggedInUser, dataRepository);
		}
		if (ApplicationUtils.isValidList(fieldRepositoryDto.getDeletedFields())) {
			for (String fieldIdentity : fieldRepositoryDto.getDeletedFields()) {
				if (ApplicationUtils.isValidString(fieldIdentity)) {
					FieldConfiguration fieldConfiguration = fieldConfigurationDao
							.getFieldConfigurationdetails(fieldIdentity);
					fieldConfiguration.setIsDltSts(Boolean.TRUE);
					fieldConfiguration.setMdyUsrId(loggedInUser.getId());
					fieldConfiguration.setMdyDteTme(LocalDateTime.now());
					fieldConfigurationDao.updateFieldConfiguration(fieldConfiguration);
				}
			}
		}
		return Boolean.TRUE;		
	}
	return Boolean.TRUE;
	}

	/**
	 * @param fieldRepositoryDto
	 * @param loggedInUser
	 * @param httpServletRequest
	 * @param dataRepository
	 * @param updatedRepository
	 * @throws ApplicationException
	 */
	private void saveNotificationForSubmitStatus(FieldRepositoryDto fieldRepositoryDto, UserInfo loggedInUser,
			HttpServletRequest httpServletRequest, DataRepository dataRepository, DataRepository updatedRepository)
			throws ApplicationException {
		if (!updatedRepository.getRepoStatus()
				.equals(RepositoryStatusEnum.getRepositoryStatusByDesc(ApplicationConstants.DRAFTED))) {
			iDataRepositoryDao.UpdateRepostioryDetails(updatedRepository);
			if(loggedInUser.getAssociationId() != null) {
				Integer authorityType = validateUserRoleDetails(fieldRepositoryDto.getAction(), loggedInUser,
						httpServletRequest);
				if ( !updatedRepository.getRepoStatus()
						.equals(RepositoryStatusEnum.getRepositoryStatusByDesc(ApplicationConstants.DRAFTED))) {
					saveNotificationDetails(dataRepository, loggedInUser, authorityType, fieldRepositoryDto.getAction(),
							null);
				}
			}
			
		}
	}

	/**
	 * @param dataRepository
	 * @param fieldRepositoryDto
	 * @param loggedInUser
	 * @return
	 * @throws ApplicationException 
	 */
	private DataRepository updateDataRepository(DataRepository dataRepository, FieldRepositoryDto fieldRepositoryDto,
			UserInfo loggedInUser) throws ApplicationException {
		dataRepository.setRepositoryName(fieldRepositoryDto.getRepositoryName().trim());
		dataRepository.setRepositoryId(fieldRepositoryDto.getRepositoryId().trim());
		dataRepository.setRepoDescription(fieldRepositoryDto.getRepositoryDesc().trim());
		if (ApplicationUtils
				.isNotValidId(UploadAccessEnum.getUploadAccessIdByUserType(fieldRepositoryDto.getUploadAccess()))
				&& !fieldRepositoryDto.getRepositoryStatus().equals(RepositoryStatusEnum.DRAFT.getStatusDesc())) {
			throw new ApplicationException(ErrorCodes.INVALID_UPLOAD_ACESSS);
		}
		dataRepository.setUploadAccess(UploadAccessEnum.getUploadAccessIdByUserType(fieldRepositoryDto.getUploadAccess()));
		dataRepository.setRepoApiName((dataRepository.getRepoVersion() != 1)
				? fieldRepositoryDto.getRepositoryName().trim().toLowerCase().replace(" ", ApplicationConstants.HYPHEN)
						+ ApplicationConstants.HYPHEN + dataRepository.getRepoVersion()
						+ ApplicationConstants.API_REPO
				: fieldRepositoryDto.getRepositoryName().trim().toLowerCase().replace(" ", ApplicationConstants.HYPHEN)
						+ ApplicationConstants.API_REPO);
		dataRepository.setRepoTableName((dataRepository.getRepoVersion() != 1)
				? fieldRepositoryDto.getRepositoryName().toLowerCase().trim().toLowerCase().replace(" ",
						ApplicationConstants.UNDERSCORE) + ApplicationConstants.UNDERSCORE
						+ dataRepository.getRepoVersion() + ApplicationConstants.TABLE_REPO
				: fieldRepositoryDto.getRepositoryName().toLowerCase().trim().toLowerCase().replace(" ",
						ApplicationConstants.UNDERSCORE) + ApplicationConstants.TABLE_REPO);
		dataRepository.setCrtDteTme(LocalDateTime.now());
		dataRepository.setMdyDteTme(LocalDateTime.now());
		dataRepository.setRepoStatus(
				RepositoryStatusEnum.getRepositoryStatusByDesc(fieldRepositoryDto.getRepositoryStatus()));
		dataRepository.setCrtUsrId(loggedInUser.getId());
		dataRepository.setMdyUsrId(loggedInUser.getId());
		dataRepository.setIsDltSts(Boolean.FALSE);
		dataRepository.setIsActive(Boolean.TRUE);
		dataRepository.setFieldCount(
				(int) ((dataRepository.getFieldCount() + fieldRepositoryDto.getFieldsConfiguratorDto().stream()
						.filter(field -> Boolean.FALSE.equals(ApplicationUtils.isValidString(field.getFieldIdentity())))
						.count()) - fieldRepositoryDto.getDeletedFields().size()));
		return dataRepository;
	}

	/**
	 * @param dataRepository
	 * @param userInfo
	 * @param fieldRepositoryDto
	 * @param action
	 * @return
	 * @throws ApplicationException
	 */
	public void saveNotificationDetails(DataRepository dataRepository, UserInfo userInfo, Integer authorityType,
			String status, String commentsIdentity) throws ApplicationException {
		NotificationEvent notificationEvent = iNotificationDao
				.getNotificationevent(ApplicationConstants.REPOSITORY_CREATION);
		NotificationTemplate notificationTemplate = new NotificationTemplate();
		if (ApplicationUtils.isValidateObject(notificationEvent)) {
			notificationTemplate = iNotificationDao.getNotificationTemplate(notificationEvent, status);
			StringBuilder finalMessage = new StringBuilder();
			finalMessage.append(notificationTemplate.getContent()
					.replaceAll(ApplicationConstants.NEW_REPOSITORY,
							WordUtils.capitalize(dataRepository.getRepositoryName()))
					.replaceAll(ApplicationConstants.USER_INFO, WordUtils.capitalize(userInfo.getUsername())));
			StringBuilder replaceableData = new StringBuilder();
			replaceableData.append("{\"").append(ApplicationConstants.NEW_REPOSITORY).append("\":\"")
					.append(dataRepository.getRepositoryName()).append("\",\"").append(ApplicationConstants.USER_INFO)
					.append("\":\"").append(userInfo.getUsername()).append("\"}");
			saveNotificationDetails(dataRepository, userInfo, finalMessage, authorityType, commentsIdentity,replaceableData);
		}
	}

	/**
	 * @param dataRepository
	 * @param userInfo
	 * @param finalMessage
	 * @throws ApplicationException
	 */
	private void saveNotificationDetails(DataRepository dataRepository, UserInfo userInfo, StringBuilder finalMessage,
			Integer authorityType, String commentsIdentity,StringBuilder replaceableData) throws ApplicationException {
		RepositoryNotification notification = new RepositoryNotification();
		notification.setNotificationMessage(finalMessage.toString());
		notification.setReplaceTemplateData(replaceableData.toString());
		notification.setCrtDteTme(LocalDateTime.now());
		notification.setIsDltSts(Boolean.FALSE);
		notification.setIsRead(Boolean.FALSE);
		notification.setLastActed(authorityType);
		notification.setCrtUsrId(userInfo.getId());
		notification.setIsRepoCmts(ApplicationUtils.isValidString(commentsIdentity));
		notification.setToNotify(CreatorApprover.getInverseAuthorityTypeById(authorityType));
		notification.setRepositoryId(dataRepository);
		notification.setMdyUsrId(userInfo.getId());
		notification.setMdyDteTme(LocalDateTime.now());
		iNotificationDao.saveNotificationDetails(notification);
		messagingTemplate.convertAndSend("/topic/notification/"+null, true);
		
		
	}

	/**
	 *
	 */
	@Override
	public Long getRepositoryListCount(List<FilterOrSortingVo> filterVo,String search, String userRoleStatus) throws ApplicationException {
		return iDataRepositoryDao.getRepositoryCountValue(filterVo,search,userRoleStatus);
	}

	
	/**
	 * @param min
	 * @param max
	 * @param filterVo
	 * @param userRoleStatus
	 * @param loggedInUser
	 * @param httpServletRequest
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public List<DataRepositoryDto> getRepositoryCardList(Integer min, Integer max, List<FilterOrSortingVo> filterVo,String userRoleStatus, UserInfo loggedInUser,String search,
			HttpServletRequest httpServletRequest)
			throws ApplicationException {
		List<DataRepositoryDto> dataRepositoryDto = new ArrayList<>();
		List<DataRepository> dataRepositories = iDataRepositoryDao.getDataRepositoryList(min, max, filterVo,userRoleStatus,search);
		for (DataRepository dataRepository : dataRepositories) {
			DataRepositoryDto dataRepositoryDetails = new DataRepositoryDto();
			dataRepositoryDetails.setAssociationId(dataRepository.getAssociationId());
			dataRepositoryDetails.setRepositoryApiName(dataRepository.getRepoApiName());
			dataRepositoryDetails.setIsActive(dataRepository.getIsActive());
			dataRepositoryDetails.setEffectiveFrom(dataRepository.getEffectiveFrom());
			dataRepositoryDetails.setEffectiveTo(dataRepository.getEffectiveTo());
			dataRepositoryDetails.setRepositoryDescription(dataRepository.getRepoDescription());
			dataRepositoryDetails.setRepositoryId(dataRepository.getRepositoryId());
			dataRepositoryDetails.setRepositoryName(dataRepository.getRepositoryName());
			dataRepositoryDetails
					.setRepositoryStatus(RepositoryStatusEnum.getRepositoryStatusById(dataRepository.getRepoStatus()));
			dataRepositoryDetails.setRepositoryTableName(dataRepository.getRepoTableName());
			dataRepositoryDetails.setIdentity(dataRepository.getIdentity());
			dataRepositoryDetails.setRepositoryVersion(dataRepository.getRepoVersion());
			dataRepositoryDetails.setNumberOfFields(dataRepository.getFieldCount());
			dataRepositoryDetails.setIdentity(dataRepository.getIdentity());
			dataRepositoryDto.add(dataRepositoryDetails);
		}
		messagingTemplate.convertAndSend("/topic/notification/"+null, true);
		return dataRepositoryDto;
	}
	/**
		 * @param min
	 * @param max
	 * @param filterVo
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public List<DataRepositoryDto> getRepositoryCardListforApproved(Integer min, Integer max, List<FilterOrSortingVo> filterVo,String search,UserInfo userInfo, Boolean isApproved)
			throws ApplicationException {
		List<DataRepository> dataRepositories = iDataRepositoryDao.getDataRepositoryListForApproved(min, max, filterVo,search, isApproved);
		List<DataRepositoryDto> dataRepositoryDto = new ArrayList<>();
		for (DataRepository dataRepository : dataRepositories) {
			DataRepositoryDto dataRepositoryDetails = new DataRepositoryDto();
			dataRepositoryDetails.setAssociationId(dataRepository.getAssociationId());
			dataRepositoryDetails.setRepositoryApiName(dataRepository.getRepoApiName());
			dataRepositoryDetails.setIsActive(dataRepository.getIsActive());
			dataRepositoryDetails.setEffectiveFrom(dataRepository.getEffectiveFrom());
			dataRepositoryDetails.setEffectiveTo(dataRepository.getEffectiveTo());
			dataRepositoryDetails.setRepositoryDescription(dataRepository.getRepoDescription());
			dataRepositoryDetails.setRepositoryId(dataRepository.getRepositoryId());
			dataRepositoryDetails.setRepositoryName(dataRepository.getRepositoryName());
			dataRepositoryDetails
					.setRepositoryStatus(RepositoryStatusEnum.getRepositoryStatusById(dataRepository.getRepoStatus()));
			dataRepositoryDetails.setRepositoryTableName(dataRepository.getRepoTableName());
			dataRepositoryDetails.setIdentity(dataRepository.getIdentity());
			dataRepositoryDetails.setRepositoryVersion(dataRepository.getRepoVersion());
			dataRepositoryDetails.setNumberOfFields(dataRepository.getFieldCount());
			dataRepositoryDetails.setIdentity(dataRepository.getIdentity());
			dataRepositoryDetails.setUploadAccess(dataRepository.getUploadAccess());
			dataRepositoryDto.add(dataRepositoryDetails);
		}
		return dataRepositoryDto;
	}
	
	/**
	 * @param fieldRepositoryDto
	 * @param loggedInUser
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public String updateRepositoryName(FieldRepositoryDto fieldRepositoryDto, UserInfo loggedInUser)
			throws ApplicationException {
		DataRepository dataRepository = iDataRepositoryDao
				.getUpdateStatusDataRepository(fieldRepositoryDto.getRepositoryIdentity());
		if (dataRepository.getRepoStatus().equals(
				RepositoryStatusEnum.getRepositoryStatusByDesc(RepositoryStatusEnum.SUBMITTED.getStatusDesc()))) {
			dataRepository.setRepositoryName(fieldRepositoryDto.getRepositoryName());
			dataRepository.setMdyDteTme(LocalDateTime.now());
			dataRepository.setMdyUsrId(loggedInUser.getId());
			iDataRepositoryDao.saveUpdateStatusDataRepository(dataRepository);
		} else {
			throw new ApplicationException(ErrorCodes.INVALID_STATUS);
		}
		return fieldRepositoryDto.getRepositoryName();
	}
	
	 /**	
	 * @param date
	 * @param loggedInUser
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public String updateCardRepository(String repositoryIdentity, LocalDate date, UserInfo loggedInUser)
			throws ApplicationException {
		DataRepository dataRepository = iDataRepositoryDao.getUpdateStatusDataRepository(repositoryIdentity);
		if (ApplicationUtils.isValidateObject(dataRepository)) {
			dataRepository.setEffectiveTo(date);
			dataRepository.setMdyDteTme(LocalDateTime.now());
			dataRepository.setMdyUsrId(loggedInUser.getId());
			iDataRepositoryDao.saveUpdateStatusDataRepository(dataRepository);
		} else {
			throw new ApplicationException(ErrorCodes.INVALID_IDENTITY);
		}
		return repositoryIdentity;
	}

	/**
	 * @param schedulerIdentity
	 * @param loggedInUser
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public String schedulerDelete(String schedulerIdentity, UserInfo loggedInUser) throws ApplicationException {
		SchedulerNotification schedulerNotification = iDataRepositoryDao.getSchedulerDetails(schedulerIdentity);
		if (ApplicationUtils.isValidateObject(schedulerNotification)) {
			schedulerNotification.setIsDltSts(Boolean.TRUE);
			schedulerNotification.setMdyDteTme(LocalDateTime.now());
			schedulerNotification.setMdyUsrId(loggedInUser.getId());
			iDataRepositoryDao.saveUpdatestatusScheduler(schedulerNotification);
		} else {
			throw new ApplicationException(ErrorCodes.INVALID_IDENTITY);
		}
		return schedulerIdentity;
	}

	/**
	 * Gets the scheduler details.
	 *
	 * @param min the min
	 * @param max the max
	 * @param filterVo the filter vo
	 * @return the scheduler details
	 * @throws ApplicationException the application exception
	 */
	@Override
	public List<SchedulerNotificationDto> getSchedulerDetails(Integer min, Integer max,
			List<FilterOrSortingVo> filterVo) throws ApplicationException {
		List<SchedulerNotification> Schedulers = iDataRepositoryDao.getSchedulerDetailsdao(min, max, filterVo);
		List<SchedulerNotificationDto> schedulers = new ArrayList<>();
		if (ApplicationUtils.isValidList(Schedulers)) {
			for (SchedulerNotification Scheduler : Schedulers) {
				SchedulerNotificationDto schedulerss = buildSchedulerdto(Scheduler);
				schedulers.add(schedulerss);
			}
		}
		return schedulers;

	}

	/**
	 *
	 */
	@Override
	public Long getSchedulerListCount() throws ApplicationException {
		return iDataRepositoryDao.getSchedulerCountValue();
	}

	/**
	 * Gets the user role details.
	 *
	 * @param loggedInUser the logged in user
	 * @param httpServletRequest the http servlet request
	 * @return the user role details
	 * @throws ApplicationException the application exception
	 */
	@Override
	public String getUserRoleDetails(UserInfo loggedInUser, HttpServletRequest httpServletRequest)
			throws ApplicationException {
		List<AccessMappingPrivilegeDto> userPrivillageDto = restTemplateServiceImpl
				.getUserPrivivlegeDto(httpServletRequest);
		if(ApplicationUtils.isValidList(userPrivillageDto)) {
			AccessMappingPrivilegeDto accessMappingPrivilegeDto = userPrivillageDto.stream()
					.filter(a -> a.getPrivilegeName().equals("Submit Repository")).findFirst().orElse(null);
			return ApplicationUtils.isValidateObject(accessMappingPrivilegeDto)? CreatorApprover.CREATOR.name():CreatorApprover.APPROVER.name();
		}
		return null;
	}

	/**̥
	 * @param schedulerIdentity
	 * @return
	 */
	@Override
	public RepositoryScheduleDetailsDto editschedulerDetails(String schedulerIdentity) {
		SchedulerNotification schedulerNotification = iDataRepositoryDao.getSchedulerTableDetails(schedulerIdentity);
		RepositoryScheduleDetailsDto repositoryScheduleDetailsDto = new RepositoryScheduleDetailsDto();
		repositoryScheduleDetailsDto.setNotificationMessage(schedulerNotification.getMessage());
		repositoryScheduleDetailsDto.setTriggeredStatus(schedulerNotification.getTriggeredStatus());
		repositoryScheduleDetailsDto.setRemainderPeriod(schedulerNotification.getRemainder());
		repositoryScheduleDetailsDto.setIsActive(schedulerNotification.getStatus());
		repositoryScheduleDetailsDto.setRepositoryName(schedulerNotification.getRepositoryId().getRepositoryName());
		RepositoryScheduleDetails repositoryScheduleDetails = iDataRepositoryDao
				.getrepositorySchedulerDetails(schedulerNotification.getIdentity());
		repositoryScheduleDetailsDto.setEndDate(repositoryScheduleDetails.getEndDate());
		String[] DateTime  = repositoryScheduleDetails.getStartDatewithtime().split(" ");
		repositoryScheduleDetailsDto.setStartdate(DateTime[0]);
		repositoryScheduleDetailsDto.setTime(DateTime[1]);
		repositoryScheduleDetailsDto.setRepeatFormat(repositoryScheduleDetails.getRepeatFormat());
		repositoryScheduleDetailsDto.setRepeatOn(repositoryScheduleDetails.getRepeatOn()); 
		repositoryScheduleDetailsDto.setRepeatOnDay(repositoryScheduleDetails.getRepeatOnday());
		repositoryScheduleDetailsDto.setSelectedDays(repositoryScheduleDetails.getSelectedDays());
		repositoryScheduleDetailsDto.setRepeatCount(repositoryScheduleDetails.getRepeatCount());
		repositoryScheduleDetailsDto.setSelectedDay(repositoryScheduleDetails.getSelectedDate());
		repositoryScheduleDetailsDto.setRepeatOnMonth(repositoryScheduleDetails.getRepeatOnMonth());
		repositoryScheduleDetailsDto.setSelectedOnMonth(repositoryScheduleDetails.getSelectedMonth());
		repositoryScheduleDetailsDto.setSchedulerIdentity(schedulerIdentity);
		return repositoryScheduleDetailsDto;
	}

	/**
	 * @param repositoryScheduleDetailsDto
	 * @param loggedInUser
	 * @return
	 * @throws ApplicationException
	 * @throws ParseException 
	 */
	@Override
	public String updateSchedulerDetails(RepositoryScheduleDetailsDto repositoryScheduleDetailsDto,
			UserInfo loggedInUser) throws ApplicationException {
		SchedulerNotification schedulerNotification = iSchedulerNotificationDao
				.getSchedulerNotificationbyRepositoryIdentityDetails(repositoryScheduleDetailsDto.getSchedulerIdentity());
		if (ApplicationUtils.isValidateObject(schedulerNotification)) {
			schedulerNotification.setMessage(repositoryScheduleDetailsDto.getNotificationMessage());
			if(ApplicationUtils.isValidId(repositoryScheduleDetailsDto.getRemainderPeriod())){
				schedulerNotification.setRemainder(repositoryScheduleDetailsDto.getRemainderPeriod());
			} else {
				throw new ApplicationException(ErrorCodes.INVALID_REMAINDER_PERIOD);
			}
			schedulerNotification.setMdyDteTme(LocalDateTime.now());
			schedulerNotification.setMdyUsrId(loggedInUser.getId());
			schedulerNotification.setStatus(repositoryScheduleDetailsDto.getIsActive());
			iSchedulerNotificationDao.saveUpdateSchedulerNotification(schedulerNotification);
			RepositoryScheduleDetails repositoryScheduleDetails = saveRepositoryScheduleDetails(schedulerNotification,
					loggedInUser, repositoryScheduleDetailsDto);
			String platformName = "";
			if(loggedInUser.getPlatformDetailsDto() != null) {
				platformName = loggedInUser.getPlatformDetailsDto().getPlatformName();
			}
			triggerScheduler(repositoryScheduleDetailsDto.getSchedulerIdentity(), schedulerNotification.getRemainder(),
					repositoryScheduleDetails, platformName, loggedInUser.getAssociationId());
		}else {
			throw new ApplicationException(ErrorCodes.INVALID_SCHEDULER_DATA);
		}
		return repositoryScheduleDetailsDto.getSchedulerIdentity();
	}

	/**
	 * @param schedulerNotification
	 * @param loggedInUser
	 * @param repositoryScheduleDetailsDto 
	 * @param repositorySchedule 
	 * @throws ApplicationException 
	 * @throws ParseException 
	 */
	private RepositoryScheduleDetails saveRepositoryScheduleDetails(SchedulerNotification schedulerNotification,
			UserInfo loggedInUser, RepositoryScheduleDetailsDto repositoryScheduleDetailsDto)
			throws ApplicationException {
		RepositoryScheduleDetails repositorySchedule = iScheduleDetailsDao
				.getRepositoryScheduleDetailsByIdentity(schedulerNotification.getIdentity());
		repositorySchedule = ApplicationUtils.isValidateObject(repositorySchedule) ? repositorySchedule
				: new RepositoryScheduleDetails();
		repositorySchedule.setSchedulerNotificationId(schedulerNotification);
		repositorySchedule
				.setRepeatFormat(getRepeatFormateValidation(repositoryScheduleDetailsDto, repositorySchedule));
		repositorySchedule.setRepeatCount(repositoryScheduleDetailsDto.getRepeatCount());
		repositorySchedule.setCrtDteTme(LocalDateTime.now());
		repositorySchedule.setCrtUsrId(loggedInUser.getId());
		repositorySchedule.setEndDate(repositoryScheduleDetailsDto.getEndDate());
		repositorySchedule.setIsDltSts(Boolean.FALSE);
		repositorySchedule.setMdyDteTme(LocalDateTime.now());
		repositorySchedule.setMdyUsrId(loggedInUser.getId());
		repositorySchedule.setSelectedDays(repositoryScheduleDetailsDto.getSelectedDays());
		repositorySchedule.setRepeatOn(repositoryScheduleDetailsDto.getRepeatOn());
		repositorySchedule.setRepeatOnday(repositoryScheduleDetailsDto.getRepeatOnDay());
		repositorySchedule.setRepeatOnMonth(repositoryScheduleDetailsDto.getRepeatOnMonth());
		repositorySchedule.setSelectedDate(repositoryScheduleDetailsDto.getSelectedDay());
		repositorySchedule.setSelectedMonth(repositoryScheduleDetailsDto.getSelectedOnMonth());
		if (ApplicationUtils.isBlank(repositorySchedule.getIdentity())) {
			repositorySchedule.setIdentity(ApplicationUtils.getUniqueId());
		}
		return iScheduleDetailsDao.saveRepositoryScheduleDetails(repositorySchedule);
	}

	/**
	 * @param repositoryScheduleDetailsDto
	 * @param repositoryScheduleDetails
	 * @return
	 * @throws ApplicationException
	 * @throws ParseException 
	 */
	private String getRepeatFormateValidation(RepositoryScheduleDetailsDto repositoryScheduleDetailsDto,
			RepositoryScheduleDetails repositoryScheduleDetails) throws ApplicationException {
		if (RepeatFormatEnum.DAY.name().equals(repositoryScheduleDetailsDto.getRepeatFormat())) {
			return validateDayType(repositoryScheduleDetailsDto, repositoryScheduleDetails);

		} else if (RepeatFormatEnum.MONTH.name().equals(repositoryScheduleDetailsDto.getRepeatFormat())) {
			return validateMonthType(repositoryScheduleDetailsDto, repositoryScheduleDetails);

		} else if (RepeatFormatEnum.WEEK.name().equals(repositoryScheduleDetailsDto.getRepeatFormat())) {
			return validateWeekType(repositoryScheduleDetailsDto, repositoryScheduleDetails);

		} else if (RepeatFormatEnum.YEAR.name().equals(repositoryScheduleDetailsDto.getRepeatFormat())) {
			return validateYearType(repositoryScheduleDetailsDto, repositoryScheduleDetails);
		} else {
			throw new ApplicationException(ErrorCodes.INVALID_SCHEDULER_DATA);
		}
	}

	/**
	 * @param repositoryScheduleDetailsDto
	 * @param repositoryScheduleDetails
	 * @return
	 * @throws ApplicationException
	 */
	private String validateYearType(RepositoryScheduleDetailsDto repositoryScheduleDetailsDto,
			RepositoryScheduleDetails repositoryScheduleDetails) throws ApplicationException {
		if (ApplicationUtils.isValidString(repositoryScheduleDetailsDto.getStartdate())
				&& ApplicationUtils.isValidId(repositoryScheduleDetailsDto.getSelectedDay())
				&& ApplicationUtils.isValidString(repositoryScheduleDetailsDto.getSelectedOnMonth())) {
			MonthEnum.valueOf(repositoryScheduleDetailsDto.getSelectedOnMonth());
			String dateTime = convertDateTime(repositoryScheduleDetailsDto,repositoryScheduleDetails,repositoryScheduleDetailsDto.getTime());
			repositoryScheduleDetails.setSelectedDays(repositoryScheduleDetailsDto.getSelectedDays());
			repositoryScheduleDetails.setStartDatewithtime(dateTime);
			repositoryScheduleDetails.setSelectedMonth(repositoryScheduleDetailsDto.getSelectedOnMonth());

		} else if (ApplicationUtils.isValidString(repositoryScheduleDetailsDto.getRepeatOn())
				&& ApplicationUtils.isValidString(repositoryScheduleDetailsDto.getRepeatOnDay())
				&& ApplicationUtils.isValidString(repositoryScheduleDetailsDto.getRepeatOnMonth())
				&& ApplicationUtils.isValidString(repositoryScheduleDetailsDto.getStartdate())) {
			RepeatOnEnum.valueOf(repositoryScheduleDetailsDto.getRepeatOn());
			DayEnum.valueOf(repositoryScheduleDetailsDto.getRepeatOnDay());
			MonthEnum.valueOf(repositoryScheduleDetailsDto.getRepeatOnMonth());
			String dateTime = convertDateTime(repositoryScheduleDetailsDto,repositoryScheduleDetails,repositoryScheduleDetailsDto.getTime());
			repositoryScheduleDetails.setStartDatewithtime(dateTime);
			repositoryScheduleDetails.setRepeatOn(repositoryScheduleDetailsDto.getRepeatOn());
			repositoryScheduleDetails.setRepeatOnday(repositoryScheduleDetailsDto.getRepeatOnDay());
			repositoryScheduleDetails.setRepeatOnMonth(repositoryScheduleDetailsDto.getRepeatOnMonth());
		} else {
			throw new ApplicationException(ErrorCodes.INVALID_SCHEDULER_DATA);
		}
		return repositoryScheduleDetailsDto.getRepeatFormat();
	}

	/**
	 * @param repositoryScheduleDetailsDto
	 * @param repositoryScheduleDetails
	 * @return
	 * @throws ApplicationException
	 */
	private String validateWeekType(RepositoryScheduleDetailsDto repositoryScheduleDetailsDto,
			RepositoryScheduleDetails repositoryScheduleDetails) throws ApplicationException {
		if (ApplicationUtils.isValidString(repositoryScheduleDetailsDto.getStartdate())
				&& ApplicationUtils.isValidString(repositoryScheduleDetailsDto.getSelectedDays())) {
			String[] selectedDays = repositoryScheduleDetailsDto.getSelectedDays().split(",");
			for(String selectedDay : selectedDays) {
			DayEnum.valueOf(selectedDay);
			String dateTime = convertDateTime(repositoryScheduleDetailsDto,repositoryScheduleDetails,repositoryScheduleDetailsDto.getTime());
			repositoryScheduleDetails.setStartDatewithtime(dateTime);
			repositoryScheduleDetails.setSelectedDays(repositoryScheduleDetailsDto.getSelectedDays());
			}

		} else {
			throw new ApplicationException(ErrorCodes.INVALID_SCHEDULER_DATA);
		}
		return repositoryScheduleDetailsDto.getRepeatFormat();
	}

	/**
	 * @param repositoryScheduleDetailsDto
	 * @param repositoryScheduleDetails
	 * @return
	 * @throws ApplicationException
	 */
	private String validateMonthType(RepositoryScheduleDetailsDto repositoryScheduleDetailsDto,
			RepositoryScheduleDetails repositoryScheduleDetails) throws ApplicationException {
		if (ApplicationUtils.isValidString(repositoryScheduleDetailsDto.getStartdate())
				&& ApplicationUtils.isValidId(repositoryScheduleDetailsDto.getSelectedDay())) {
			String dateTime = convertDateTime(repositoryScheduleDetailsDto,repositoryScheduleDetails,repositoryScheduleDetailsDto.getTime());
			repositoryScheduleDetails.setStartDatewithtime(dateTime);
			repositoryScheduleDetails.setSelectedDate(repositoryScheduleDetailsDto.getSelectedDay());
		} else if (ApplicationUtils.isValidString(repositoryScheduleDetailsDto.getRepeatOn())
				&& ApplicationUtils.isValidString(repositoryScheduleDetailsDto.getRepeatOnDay())
				&& ApplicationUtils.isValidString(repositoryScheduleDetailsDto.getStartdate())) {
			RepeatOnEnum.valueOf(repositoryScheduleDetailsDto.getRepeatOn());
			DayEnum.valueOf(repositoryScheduleDetailsDto.getRepeatOnDay());
			String dateTime = convertDateTime(repositoryScheduleDetailsDto,repositoryScheduleDetails,repositoryScheduleDetailsDto.getTime());
			repositoryScheduleDetails.setStartDatewithtime(dateTime);
			repositoryScheduleDetails.setRepeatOn(repositoryScheduleDetailsDto.getRepeatOn());
			repositoryScheduleDetails.setRepeatOnday(repositoryScheduleDetailsDto.getRepeatOnDay());
		} else {
			throw new ApplicationException(ErrorCodes.INVALID_SCHEDULER_DATA);
		}
		return repositoryScheduleDetailsDto.getRepeatFormat();
	}

	/**
	 * @param repositoryScheduleDetailsDto
	 * @param repositoryScheduleDetails̥
	 * @return
	 * @throws ApplicationException
	 * @throws ParseException 
	 */
	private String validateDayType(RepositoryScheduleDetailsDto repositoryScheduleDetailsDto,
			RepositoryScheduleDetails repositoryScheduleDetails) throws ApplicationException {
		if (ApplicationUtils.isValidString(repositoryScheduleDetailsDto.getStartdate())) {
			String dateTime = convertDateTime(repositoryScheduleDetailsDto,repositoryScheduleDetails,repositoryScheduleDetailsDto.getTime());
			repositoryScheduleDetails.setStartDatewithtime(dateTime);
		} else {
			throw new ApplicationException(ErrorCodes.INVALID_SCHEDULER_DATA);
		}
		return repositoryScheduleDetailsDto.getRepeatFormat();
	}

	/**
	 * @param repositoryScheduleDetailsDto 
	 * @param repositoryScheduleDetails
	 * @param string 
	 * @return
	 */
	private String convertDateTime(RepositoryScheduleDetailsDto repositoryScheduleDetailsDto, RepositoryScheduleDetails repositoryScheduleDetails, String time) {
		String[] date = repositoryScheduleDetailsDto.getStartdate().split("T");
		String dateTime = date[0]+" "+ time;
		return dateTime;
	}

	/**
	 * @param filterVo
	 * @param search
	 * @return
	 * @throws ApplicationException 
	 */
	@Override
	public Long getRepositoryApprovedListCount(List<FilterOrSortingVo> filterVo, String search, Boolean isApproved) throws ApplicationException {
		return iDataRepositoryDao.getRepositoryApprovedCountValue(filterVo,search, isApproved);
	}

	/**
	 * @param repositoryIdentity
	 */
	@Override
	public Map<String, Object> getRepositoryStatusByIdentity(String repositoryIdentity) {
		Map<String, Object> response = new HashMap<>();
		Object[] repositoryInfo = repositoryDao.getRepositoryStatusByIdentity(repositoryIdentity);
		response.put("status", RepositoryStatusEnum.getRepositoryStatusById((Integer) repositoryInfo[0]));
		response.put("isDisabled", ApplicationUtils.isValidateObject(repositoryInfo[1]) ? Boolean.TRUE : Boolean.FALSE);
		return response;
	}
}
