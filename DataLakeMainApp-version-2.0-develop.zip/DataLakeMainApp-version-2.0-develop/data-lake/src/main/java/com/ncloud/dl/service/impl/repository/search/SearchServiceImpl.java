package com.ncloud.dl.service.impl.repository.search;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.util.ByteArrayDataSource;
import javax.transaction.Transactional;

import org.apache.http.entity.ContentType;
import org.apache.http.nio.entity.NStringEntity;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.client.Request;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.core.CountRequest;
import org.elasticsearch.client.indices.GetIndexRequest;
import org.elasticsearch.client.indices.GetIndexResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.xhtmlrenderer.pdf.ITextRenderer;

import com.lowagie.text.DocumentException;
import com.ncloud.dl.config.property.EnvironmentProperties;
import com.ncloud.dl.constants.core.ApplicationConstants;
import com.ncloud.dl.constants.core.QueryConstants;
import com.ncloud.dl.constants.core.QueryConstants.ColumnConstants;
import com.ncloud.dl.dao.datarespository.IDataRepositoryDao;
import com.ncloud.dl.dao.fieldconfiguration.IFieldConfigurationDao;
import com.ncloud.dl.dao.fieldoptionlkn.IFieldOptionLinkingDao;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.exception.core.codes.ErrorCodes;
import com.ncloud.dl.search.eswrapper.CountResponseObject;
import com.ncloud.dl.search.eswrapper.EntityUtilsImpl;
import com.ncloud.dl.search.eswrapper.IElasticSearchOperation;
import com.ncloud.dl.search.eswrapper.IRestClient;
import com.ncloud.dl.search.eswrapper.ISearchHit;
import com.ncloud.dl.search.eswrapper.ISearchResponse;
import com.ncloud.dl.service.ISearchDao;
import com.ncloud.dl.service.ISearchService;
import com.ncloud.dl.transfer.object.dto.CustomFilterSortingVo;
import com.ncloud.dl.transfer.object.dto.DataRepositoryDto;
import com.ncloud.dl.transfer.object.dto.FieldMapperDto;
import com.ncloud.dl.transfer.object.dto.FieldOptionLinkingDto;
import com.ncloud.dl.transfer.object.dto.FieldsConfiguratorDto;
import com.ncloud.dl.transfer.object.dto.RepositoryDto;
import com.ncloud.dl.transfer.object.dto.SearchResponseDto;
import com.ncloud.dl.transfer.object.entity.DataRepository;
import com.ncloud.dl.transfer.object.entity.FieldConfiguration;
import com.ncloud.dl.transfer.object.entity.FieldOptionLink;
import com.ncloud.dl.transfer.object.entity.SearchHistory;
import com.ncloud.dl.transfer.object.enums.FieldDataTypeEnum;
import com.ncloud.dl.transfer.object.enums.FieldSearchTypeEnum;
import com.ncloud.dl.transfer.object.enums.FieldTypeEnum;
import com.ncloud.dl.utils.core.ApplicationUtils;

import freemarker.template.Configuration;
import freemarker.template.Template;
import lombok.RequiredArgsConstructor;


/**
 * The Class SearchServiceImpl.
 */
@Service
@Transactional
@RequiredArgsConstructor
public class SearchServiceImpl implements ISearchService {

	/**
	 * iSearchDao
	 */
	private final ISearchDao iSearchDao;

	/**
	 * dataRepositoryDao
	 */
	private final IDataRepositoryDao dataRepositoryDao;
	
	/**
	 * fieldOptionLinkingDao
	 */
	private final IFieldOptionLinkingDao fieldOptionLinkingDao;
	
	/**
	 * The Constant logger.
	 */
	private static final Logger logger = LoggerFactory.getLogger(SearchServiceImpl.class);

	/**
	 * FieldConfigurationDao
	 */
	private final IFieldConfigurationDao fieldConfigurationDao;

	/**
	 * config to send mail
	 */
	private final Configuration config;
	
	/**
	 * environmentProperties
	 */
	private final EnvironmentProperties environmentProperties;

	/**
	 * JavaMailSender
	 */
	private final JavaMailSender mailSender;
	
	/** The elastic search high level client operation. */
	private final IElasticSearchOperation elasticSearchHighLevelClientOperation;
	
	
	/** The rest client impl. */
	private final IRestClient restClientImpl;
	
	/** The entity utils impl. */
	private final EntityUtilsImpl entityUtilsImpl;

	/**
	 * @param repositoryIdentity
	 * @return
	 */
	@Override
	public List<FieldsConfiguratorDto> getadvanceFilterForRepository(String repositoryName) {
		List<FieldsConfiguratorDto> fielDtos = new ArrayList<>();
		if (ApplicationUtils.isValidIdentity(repositoryName)) {
			List<FieldConfiguration> fieldConfigurations = dataRepositoryDao.getFieldRepositorySearch(repositoryName,
					Arrays.asList(FieldSearchTypeEnum.REPOSITORY_SEARCH.getId(),
							FieldSearchTypeEnum.BOTH_SEARCH.getId()));
			if (ApplicationUtils.isValidateObject(fieldConfigurations)) {
				for (FieldConfiguration fieldConfiguration : fieldConfigurations) {
					fielDtos.add(buildObjectInFieldConfiguration(fieldConfiguration));
				}
			}
		}
		return fielDtos;
	}

	/**
	 * @param fieldConfiguration
	 * @return
	 */
	private FieldsConfiguratorDto buildObjectInFieldConfiguration(FieldConfiguration fieldConfiguration) {
		FieldsConfiguratorDto fieldsConfiguratorDto = new FieldsConfiguratorDto();
		fieldsConfiguratorDto.setColumnName(fieldConfiguration.getColumnName());
		fieldsConfiguratorDto.setDataType(ApplicationUtils.isValidId(fieldConfiguration.getDataType())
				? FieldDataTypeEnum.getFieldDataTypeById(fieldConfiguration.getDataType())
				: null);
		fieldsConfiguratorDto.setErrorMessage(fieldConfiguration.getErrMsg());
		fieldsConfiguratorDto.setFieldName(fieldConfiguration.getFieldName());
		fieldsConfiguratorDto.setFieldType(FieldTypeEnum.getFieldTypeNameByTypeId(fieldConfiguration.getFieldType()));
		fieldsConfiguratorDto.setSearchType(fieldConfiguration.getSearchType().toString());
		fieldsConfiguratorDto.setFieldIdentity(fieldConfiguration.getIdentity());
		fieldsConfiguratorDto.setListofFieldOptions(getfieldOptionList(fieldConfiguration.getIdentity()));
		return fieldsConfiguratorDto;
	}

	/**
	 * @param fieldId
	 * @return
	 */
	private List<FieldOptionLinkingDto> getfieldOptionList(String fieldId) {
		List<FieldOptionLink> fieldOptionLink = fieldOptionLinkingDao.getFieldOptionList(fieldId);
		List<FieldOptionLinkingDto> dropDownList = new ArrayList<>();
		for (FieldOptionLink fieldOptionDrop : fieldOptionLink) {
			FieldOptionLinkingDto fieldOptionLinkingDto = new FieldOptionLinkingDto();
			fieldOptionLinkingDto.setFieldOptionName(fieldOptionDrop.getDropdownOptions());
			fieldOptionLinkingDto.setFieldOptionIdentity(fieldOptionDrop.getIdentity());
			dropDownList.add(fieldOptionLinkingDto);
		}
		return dropDownList;
	}

	/**
	 * @param repositoryId
	 * @return
	 */
	@Override
	public List<DataRepositoryDto> getApprovedRepositoryName(List<Integer> repositoryId) {
		List<DataRepository> dataRepository = iSearchDao.getRepositoryDetails(repositoryId);
		List<DataRepositoryDto> dataRepositoryDto = new ArrayList<>();
		for (DataRepository dataRepositoryDetails : dataRepository) {
			dataRepositoryDto.add(buildDataRepository(dataRepositoryDetails));
		}
		return dataRepositoryDto;

	}

	/**
	 * Retrieves search results from the Elasticsearch engine based on repository identity, pagination parameters, 
	 * and search type.
	 * 
	 * @param filterValue        The filter criteria apply to the search value.
	 * @param repoIdentity       The unique identity of the repository being searched.
	 * @param skip               The number of records to skip for pagination.
	 * @param limit              The maximum number of records to return.
	 * @param searchType         The type of search to be performed (e.g., repostiory search or global search).
	 * @param filterVo           {@link CustomFilterSortingVo} containing filtering and sorting details.
	 * @param isrepositorySearch This Boolean parameter build criteria for search page or APIIntegration page.
	 * @return                   {@link SearchResponseDto} containing the search results.
	 * @throws IOException       If an error occurs during communication with Elasticsearch.
	 */
	@Override
	public SearchResponseDto commonSearch(String filterValue, String repoIdentity, Long skip, Long limit,
			Integer searchType, CustomFilterSortingVo filterVo, Boolean isrepositorySearch) throws IOException {
		Integer searchTypeId = FieldSearchTypeEnum.REPOSITORY_SEARCH.getId();
		searchTypeId = FieldSearchTypeEnum.GLOBAL_SEARCH.getId().equals(searchType)
				? FieldSearchTypeEnum.GLOBAL_SEARCH.getId()
				: searchTypeId;
		List<RepositoryDto> fieldAndRepoName = dataRepositoryDao.getSearchableFields(repoIdentity,
				Arrays.asList(searchTypeId, FieldSearchTypeEnum.BOTH_SEARCH.getId()),isrepositorySearch);
		if (ApplicationUtils.isValidList(fieldAndRepoName)) {
			GetIndexRequest request = new GetIndexRequest(ApplicationConstants.DL_ + fieldAndRepoName.get(0).getRepoTableName());
			boolean response = elasticSearchHighLevelClientOperation.indices().exists(request, RequestOptions.DEFAULT);
			if(!response) {
				return new SearchResponseDto();
			}
			ISearchResponse searchResponse = buildSearchRequestAndResponse(filterValue, fieldAndRepoName,
					elasticSearchHighLevelClientOperation, skip, limit, filterVo);
			List<String> uniqueIdentityList = Stream.of(searchResponse.getHits().getHits()).map(ISearchHit::getSourceAsMap)
					.map(source -> source.get(ColumnConstants.IDENTITY).toString()).collect(Collectors.toList());
			SearchResponseDto searchResponseDto = new SearchResponseDto();
			List<HashMap<String, Object>> pSqlRecords = getRecordsByUniqueId(uniqueIdentityList, fieldAndRepoName.get(0).getRepoTableName());
			searchResponseDto.setMatchedObject(pSqlRecords);
			return searchResponseDto;
		}
		return new SearchResponseDto();
	}

	/**
	 * Build search request and response using {@link BoolQueryBuilder}
	 */
	private ISearchResponse buildSearchRequestAndResponse(String filterValue, List<RepositoryDto> fieldAndRepoName,
			IElasticSearchOperation restHighLevelClient, Long skip, Long limit, CustomFilterSortingVo filterVo) throws IOException {
		SearchRequest searchRequest = new SearchRequest(
				ApplicationConstants.DL_ + fieldAndRepoName.get(0).getRepoTableName());
		SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
		BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
		boolQueryBuilder = buildWildCardQuery(filterValue, filterVo, fieldAndRepoName);
		searchSourceBuilder.query(boolQueryBuilder);
		searchSourceBuilder.sort(SortBuilders.fieldSort("_doc").order(SortOrder.ASC));
		if (ApplicationUtils.isValidateObject(filterVo)) {
			if (ApplicationUtils.isValidateObject(filterVo.getSortingMap())) {
				searchSourceBuilder.sort(SortBuilders.fieldSort(filterVo.getSortingMap().getColumnName() + ApplicationConstants.KEYWORD)
						.order(filterVo.getSortingMap().getIsAsc() ? SortOrder.ASC : SortOrder.DESC));
			}
		}
		searchSourceBuilder.from(Integer.parseInt(skip.toString()));
		searchSourceBuilder.size(Integer.parseInt(limit.toString()));
		searchRequest.source(searchSourceBuilder);
		return restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
	}

	/**
	 * @param dataRepositoryDetails
	 * @return
	 */
	private DataRepositoryDto buildDataRepository(DataRepository dataRepositoryDetails) {
		DataRepositoryDto dataRepositoryDto = new DataRepositoryDto();
		dataRepositoryDto.setId(dataRepositoryDetails.getId());
		dataRepositoryDto.setIdentity(dataRepositoryDetails.getIdentity());
		dataRepositoryDto.setRepositoryName(dataRepositoryDetails.getRepositoryName());
		return dataRepositoryDto;
	}
	

	/**
	 * @param searchQuery
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public List<SearchResponseDto> globalSearch(String searchQuery, Long skip, Long limit,
			String activeRepository,Boolean isglobal) throws ApplicationException {
		if (Boolean.FALSE.equals(ApplicationUtils.isValidString(searchQuery))) {
			throw new ApplicationException(ErrorCodes.INVALID_SEARCH);
		}
		try {
			List<RepositoryDto> searchableRespositories = dataRepositoryDao.getSearchableFields(
					ApplicationUtils.isValidString(activeRepository) ? activeRepository : null,
					Arrays.asList(FieldSearchTypeEnum.GLOBAL_SEARCH.getId(), FieldSearchTypeEnum.BOTH_SEARCH.getId()),Boolean.FALSE);
			if (ApplicationUtils.isValidList(searchableRespositories)) {
				List<String> indices = searchableRespositories.stream()
						.map(repository -> ColumnConstants.IDX_PREFIX + repository.getRepoTableName()).distinct()
						.toList();
				List<String> globalSearchFields;
				globalSearchFields = searchableRespositories.stream().map(RepositoryDto::getFieldName).distinct()
						.toList();
				List<String> activeIndices = filterActiveIndices(indices, elasticSearchHighLevelClientOperation);
				String searchString = ApplicationConstants.ASTERIK + searchQuery.toLowerCase() + ApplicationConstants.ASTERIK;
				List<SearchResponseDto> globalSearchResponseDtoList = new ArrayList<SearchResponseDto>();
				if (ApplicationUtils.isValidList(activeIndices)) {
					Response response = performGlobalSearch(skip, limit, restClientImpl, globalSearchFields,
							activeIndices, searchString);
					String jsonResponse = entityUtilsImpl.toString(response.getEntity());
					JSONObject responseObject = new JSONObject(jsonResponse);
					JSONArray responsesArray = responseObject.getJSONArray("responses");
					for (int i = 0; i < responsesArray.length(); i++) {
						JSONObject responseObj = responsesArray.getJSONObject(i);
						JSONObject hitsObject = responseObj.getJSONObject("hits");
						JSONArray responsesArrayw = hitsObject.getJSONArray("hits");
						if (responsesArrayw.length()>0) {
							JSONObject firstObject = responsesArrayw.getJSONObject(0);
							String index = firstObject.getString("_index");
							if (ApplicationUtils.isValidString(index)) {
								List<String> repositoryInfo = searchableRespositories.stream()
										.filter(repository -> repository.getRepoTableName()
												.equals(index.replace("dl_", "")))
										.map(RepositoryDto::getRepositoryName).distinct().toList();
								SearchResponseDto globalSearchResponseDto = new SearchResponseDto();
								globalSearchResponseDto.setIndex(repositoryInfo.get(0));
								if (isglobal.equals(Boolean.TRUE)) {
									List<Object> sourceList;
									sourceList = IntStream.range(0, responsesArrayw.length())
											.mapToObj(responsesArrayw::getJSONObject)
											.map(hit -> {
									            JSONObject sourceObject = hit.getJSONObject("_source");

									            // Convert JSONObject to Map
									            Map<String, Object> sourceMap = new HashMap<>();
									            Iterator<String> keys = sourceObject.keys();
									            while(keys.hasNext()) {
									            	String key = keys.next();
									                sourceMap.put(key, sourceObject.get(key));
									            }

									            return sourceMap;
									        })
											.collect(Collectors.toList());
									globalSearchResponseDto.setMatchedObject(sourceList);
								}
								globalSearchResponseDtoList.add(globalSearchResponseDto);
							}
						}
					}
				}
				return globalSearchResponseDtoList;
			}

		} catch (Exception e) {
			throw new ApplicationException(e.getLocalizedMessage());
		}
		return null;
	}

	/**
	 * @param skip
	 * @param limit
	 * @param restClientImpl
	 * @param globalSearchFields
	 * @param activeIndices
	 * @param searchString
	 * @return
	 * @throws IOException
	 */
	private Response performGlobalSearch(Long skip, Long limit, IRestClient restClientImpl,
			List<String> globalSearchFields, List<String> activeIndices, String searchString) throws IOException {
		StringBuilder multiIndexQuery = new StringBuilder();
		for (String index : activeIndices) {
			String query = buildDynamicQuery(globalSearchFields, searchString);
			multiIndexQuery.append("{\"index\": \"").append(index).append("\"}\n");
			multiIndexQuery.append("{\"size\": ").append(limit).append(", \"from\": ").append(skip)
					.append(",");
			multiIndexQuery.append(query).append("\n");
		}

		Request request = new Request("POST", "/_msearch");
		request.setEntity(new NStringEntity(multiIndexQuery.toString(), ContentType.APPLICATION_JSON));

		return restClientImpl.performRequest(request);
	}

	/**
	 * @param indices
	 * @param restHighLevelClient
	 * @return
	 * @throws IOException
	 */
	private List<String> filterActiveIndices(List<String> indices, IElasticSearchOperation restHighLevelClient) throws IOException {
		GetIndexRequest getIndexRequest = new GetIndexRequest("*"); // Retrieve all active indices from elastic search
		GetIndexResponse indexResponse = restHighLevelClient.indices().get(getIndexRequest, RequestOptions.DEFAULT);

		String[] esIndices = indexResponse.getIndices();
		List<String> esActiveIndices = Arrays.asList(esIndices);
		
		List<String> activeIndices = new ArrayList<>(indices);
		activeIndices.retainAll(esActiveIndices);
		return activeIndices;
	}

	/**
	 * @param globalSearchFields
	 * @param searchString
	 * @return
	 */
	private String buildDynamicQuery(List<String> globalSearchFields, String searchString) {
		StringBuilder shouldClauses = new StringBuilder();
		for (String field : globalSearchFields) {
			String matchQuery = buildMatchQuery(field, searchString);
			shouldClauses.append(matchQuery).append(",");
		}
		shouldClauses.setLength(shouldClauses.length() - 1);

		return String.format("\"query\": {\"bool\": {\"should\": [%s]}}}", shouldClauses);
	}

	/**
	 * @param field
	 * @param searchString
	 * @return
	 */
	private String buildMatchQuery(String field, String searchString) {
		return String.format("{\"wildcard\": {\"%s\": \"%s\"}}", field + ApplicationConstants.KEYWORD, searchString);
	}

	/**
	 * @param repositoryId
	 * @param repositoryName
	 * @param limit
	 * @param skip
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public List<FieldMapperDto> getRepositoryFiedsForTableHeader(String repositoryName) throws ApplicationException {
		List<FieldConfiguration> fieldConfiguration = fetchFieldConfiguration(repositoryName);
		LinkedHashMap<String, String> linkedHashMap = fieldConfiguration.stream()
				.collect(Collectors.toMap(FieldConfiguration::getFieldName, FieldConfiguration::getColumnName,
						(existing, replacement) -> existing, LinkedHashMap::new));
		return linkedHashMap.entrySet().stream()
				.map(value -> new FieldMapperDto(value.getKey(), value.getValue())).collect(Collectors.toList());
	}

	/**
	 * @param repositoryName
	 * @return
	 * @throws ApplicationException
	 */
	private List<FieldConfiguration> fetchFieldConfiguration(String repositoryName) throws ApplicationException {
		List<FieldConfiguration> fieldConfiguration = fieldConfigurationDao.getFieldDetailList(repositoryName);
		if (Boolean.FALSE.equals(ApplicationUtils.isValidList(fieldConfiguration))) {
			throw new ApplicationException(ErrorCodes.INVALID_ID);
		}
		return fieldConfiguration;
	}

	/**
	 * @param id
	 * @param email
	 * @param repositoryName
	 * @return
	 * @throws DocumentException
	 * @throws IOException
	 * @throws ApplicationException
	 */
	@Override
	@Async
	public String sendMail(String identity, String email, String repositoryname)
			throws DocumentException, IOException, ApplicationException {
		logger.info("mail service starts..................");
		if (!ApplicationUtils.isValidEmaildId(email)) {
			throw new ApplicationException(ErrorCodes.INVALID_EMAIL_ID);
		}
		List<FieldConfiguration> fieldConfigurations = fetchFieldConfiguration(repositoryname);
		HashMap<String, Object> pSqlData = getDataWithRepositoryInfo(identity, repositoryname, fieldConfigurations);
		try {
			config.setClassForTemplateLoading(this.getClass(), ApplicationConstants.MAIL_TEMPALTE_PATH);
			Template template = config.getTemplate(ApplicationConstants.MAIL__TEMPLATE_FILE);
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(template, null);
			String emailContent = buildHtmlForEmail(repositoryname, pSqlData, fieldConfigurations);
			logger.debug("Email Content -- " + emailContent);
			ByteArrayDataSource pdfDataSource = buildPdfForAttachment(emailContent);
			buildMimeMessage(email, repositoryname, html, pdfDataSource);
		} catch (MessagingException e) {
			logger.error(e.getLocalizedMessage());
			e.printStackTrace();
		} catch (Exception ex) {
			logger.error(ex.getLocalizedMessage());
			ex.printStackTrace();
		}
		return "Mail Sent Successfully";
	}

	/**
	 * @param emailContent
	 * @return
	 * @throws DocumentException
	 * @throws IOException
	 */
	private ByteArrayDataSource buildPdfForAttachment(String emailContent) throws DocumentException, IOException {
		ByteArrayOutputStream pdfOutputStream = new ByteArrayOutputStream();
		ITextRenderer renderer = new ITextRenderer();
		renderer.setDocumentFromString(emailContent);
		renderer.layout();
		renderer.createPDF(pdfOutputStream);
		pdfOutputStream.close();
		return new ByteArrayDataSource(pdfOutputStream.toByteArray(),
				ApplicationConstants.APPLICATION_PDF);
	}

	/**
	 * @param email
	 * @param repositoryname
	 * @param html
	 * @param pdfDataSource
	 * @throws MessagingException
	 * @throws AddressException
	 * @throws UnsupportedEncodingException
	 */
	private void buildMimeMessage(String email, String repositoryname, String html, ByteArrayDataSource pdfDataSource)
			throws MessagingException, UnsupportedEncodingException {
		MimeMessage message = mailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message, true);
		logger.info("Message / email / .............. " + message + "/ " + email);
		helper.setTo(InternetAddress.parse(email, false));
		helper.addAttachment(ApplicationConstants.DOWNLOAD_PDF, pdfDataSource);
		helper.setFrom(new InternetAddress(environmentProperties.getFromEMail(), ApplicationConstants.DATA_LAKE));
		helper.setText(html, true);
		helper.setSubject(ApplicationConstants.SET_SUBJECT + repositoryname);
		mailSender.send(message);
	}

	/**
	 * Builds the html for email.
	 *
	 * @param repositoryname the repositoryname
	 * @param pSqlData the sql data
	 * @param fieldConfigurations the field configurations
	 * @return the string
	 */
	private String buildHtmlForEmail(String repositoryname, HashMap<String, Object> pSqlData, List<FieldConfiguration> fieldConfigurations) {
		StringBuilder emailContent = new StringBuilder(ApplicationConstants.HTML_START);
		emailContent.append(ApplicationConstants.PARAGRAPH + ApplicationConstants.REPOSITORY_NAME).append(repositoryname).append(ApplicationConstants.PARAGRAPH_END);
		emailContent.append(ApplicationConstants.TABLE_ST);
		
		// Add a row for keys
		for (FieldConfiguration fConfiguration : fieldConfigurations ) {
			emailContent.append(ApplicationConstants.TABLE_ROW_OPEN);
			emailContent.append(ApplicationConstants.TABLE_STYLE).append(fConfiguration.getFieldName()).append(ApplicationConstants.TABLE_DATA_CLOSE);
			emailContent.append(ApplicationConstants.TEXT_STYLE).append(pSqlData.get(fConfiguration.getColumnName())).append(ApplicationConstants.TABLE_DATA_CLOSE);
			emailContent.append(ApplicationConstants.TABLE_ROW_CLOSE);
		}

		emailContent.append(ApplicationConstants.HTML_END);
		return emailContent.toString();
	}

	/**
	 * @param identity
	 * @param repositoryname
	 * @param fieldConfigurations 
	 * @return
     */
	private HashMap<String, Object> getDataWithRepositoryInfo(String identity, String repositoryname, List<FieldConfiguration> fieldConfigurations) {
        String queryTemplate = QueryConstants.SEARCH_RESULT_QUERY;
        String builder = queryTemplate.replace(ApplicationConstants.HASHTAG, "'" + identity + "'")
                .replace(QueryConstants.TABLE, fieldConfigurations.get(0).getRepoId().getRepoTableName());
        HashMap<String, Object> pSqlData;
        pSqlData = iSearchDao.getSqlDataWithIdentity(builder);
		return pSqlData;
	}

	/**
	 *@param repository
	 *@param query
	 *@param searchType
	 *@param customSortingVo
	 * @throws ApplicationException 
	 */
	@Override
	public Long getTotalRecordsCount(String repository, String query, Integer searchType,
			CustomFilterSortingVo filterVo) throws IOException, ApplicationException {
		long totalCount = 0L;
		Integer searchTypeId = FieldSearchTypeEnum.REPOSITORY_SEARCH.getId();
		searchTypeId = FieldSearchTypeEnum.GLOBAL_SEARCH.getId().equals(searchType)
				? FieldSearchTypeEnum.GLOBAL_SEARCH.getId()
				: searchTypeId;
		DataRepository repositoryDto = dataRepositoryDao.getRepositoryInfoByRepositoryName(repository);
		List<RepositoryDto> searchableRespositories = dataRepositoryDao.getSearchableFields(repository,
				Arrays.asList(searchTypeId, FieldSearchTypeEnum.BOTH_SEARCH.getId()),Boolean.FALSE);
		if (ApplicationUtils.isValidList(searchableRespositories)) {
			GetIndexRequest request = new GetIndexRequest(ApplicationConstants.DL_ + repositoryDto.getRepoTableName());
			boolean response = elasticSearchHighLevelClientOperation.indices().exists(request, RequestOptions.DEFAULT);
			if(!response) {
				return 0L;
			}
			BoolQueryBuilder boolQuery = buildWildCardQuery(query, filterVo, searchableRespositories);
			CountRequest countRequest = new CountRequest(ApplicationConstants.DL_ + repositoryDto.getRepoTableName());
			countRequest.query(boolQuery);
			 CountResponseObject countResponse = elasticSearchHighLevelClientOperation.count(countRequest, RequestOptions.DEFAULT);
			totalCount = countResponse.getCount();
			saveSearchHistory(totalCount,query,searchType);
		}
		return totalCount;
	}

	/**
	 * Save search history data
	 * @param {@link Long} TotalCount from search value
	 * @param query
	 * @param searchType
	 * @throws ApplicationException
	 */
	private void saveSearchHistory(long totalCount, String query, Integer searchType) throws ApplicationException {
		SearchHistory searchHistory = new SearchHistory();
		searchHistory.setRepositoryCount(null);
		searchHistory.setRecordCount(totalCount);
		searchHistory.setSearchValue(query);
		searchHistory.setSearchType(searchType);
		dataRepositoryDao.saveBothSearchHistory(searchHistory);
		
	}

	
	/**
	 * Builds the wild card query.
	 *
	 * @param query the query
	 * @param filterVo the filter vo
	 * @param searchableRespositories the searchable respositories
	 * @return the bool query builder
	 */
	private BoolQueryBuilder buildWildCardQuery(String query, CustomFilterSortingVo filterVo,
			List<RepositoryDto> searchableRespositories) {
		List<String> fields = searchableRespositories.stream().map(RepositoryDto::getFieldName)
				.toList();
		Map<String, String> filterMap = new HashMap<String, String>();
		if (ApplicationUtils.isValidateObject(filterVo.getFilterMap())) {
			filterMap = filterVo.getFilterMap().entrySet().stream()
					.filter(entry -> ApplicationUtils.isValidString(entry.getValue()))
					.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
		}
		BoolQueryBuilder filterQuery = QueryBuilders.boolQuery();
		BoolQueryBuilder mustQuery = QueryBuilders.boolQuery();
		BoolQueryBuilder shouldQuery = QueryBuilders.boolQuery();
		Set<String> advanceFilterFields = filterMap.keySet();
		for (String field : fields) {
            if (ApplicationUtils.isValidateObject(filterMap)) {
				if (advanceFilterFields.contains(field)) {
					if (ApplicationUtils.isValidateObject(filterMap.get(field))) {
						mustQuery.must(QueryBuilders.wildcardQuery(field + ApplicationConstants.KEYWORD, ApplicationConstants.ASTERIK
								+ filterMap.get(field).toLowerCase() + ApplicationConstants.ASTERIK));
					}
				}
			}
			shouldQuery.should(QueryBuilders.wildcardQuery(field + ApplicationConstants.KEYWORD,
					ApplicationConstants.ASTERIK + query.toLowerCase() + ApplicationConstants.ASTERIK));
		}
		if (ApplicationUtils.isValidateObject(filterMap.entrySet()) && ApplicationUtils.isValidString(query)) {
			filterQuery.should(shouldQuery);
			filterQuery.should(mustQuery);
			filterQuery.minimumShouldMatch(2);
		} else if (ApplicationUtils.isValidateObject(filterMap.entrySet()) && !ApplicationUtils.isValidString(query)) {
			filterQuery.should(mustQuery);
			filterQuery.minimumShouldMatch(1);
		} else {
			filterQuery.should(shouldQuery);
			filterQuery.minimumShouldMatch(1);
		}
		return filterQuery;
	}

	/**
	 * Before this, we retrieve the search response from the Elasticsearch engine. 
	 * From that response, we extract a list of unique identities and build a raw query 
	 * to fetch results from our environment.
	 * 
	 * @param identityList A {@link List} of {@link String} containing unique identities.
	 * @param repositoryName The {@link String} representing the repository table name.
	 */
	@Override
	public List<HashMap<String, Object>> getRecordsByUniqueId(List<String> uniqueIdList, String repositoryTableName) {
		List<HashMap<String, Object>> pSqlData = new ArrayList<>();
		if (ApplicationUtils.isValidList(uniqueIdList)) {
			String template = QueryConstants.SEARCH_RESULT_QUERY;
            String builder = template.replace(ApplicationConstants.HASHTAG, String.join(", ", uniqueIdList))
                    .replace(QueryConstants.TABLE, repositoryTableName);
			pSqlData = iSearchDao.getDataUsingUniqueId(builder);
		}
		return pSqlData;
	}
	

}
