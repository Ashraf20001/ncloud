package com.ncloud.dl.config;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ncloud.dl.utils.core.LoggedInUserContextHolder;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.ncloud.dl.constants.core.ApplicationConstants;
import com.ncloud.dl.security.jwt.JwtUtils;
import com.ncloud.dl.transfer.object.dto.PlatformDetailsDto;
import com.ncloud.dl.transfer.object.dto.RoleListDto;
import com.ncloud.dl.transfer.object.dto.UserInfo;
import com.ncloud.dl.transfer.object.entity.UserType;
import com.ncloud.dl.utils.core.ApplicationUtils;

import io.jsonwebtoken.Claims;
import lombok.RequiredArgsConstructor;

/**
 * The Class HttpInterceptor.
 */
@Component
@RequiredArgsConstructor
public class HttpInterceptor implements HandlerInterceptor {

	/** JwtUtils. */
	private final JwtUtils jwtUtils;

	/** LoggedInUserContextHolder. */
	private final LoggedInUserContextHolder loggedInUserContextHolder;
	
	/** The Constant logger. */
	private static final Logger logger= LoggerFactory.getLogger(HttpInterceptor.class);
	
	/**
	 * Pre handle.
	 *
	 * @param request the request
	 * @param response the response
	 * @param handler the handler
	 * @return true, if successful
	 * @throws Exception the exception
	 */
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
			String jwtToken = parseJwt(request);
			if (jwtToken != null && jwtUtils.validateJwtToken(jwtToken)) {
				Claims userDetailsMap = jwtUtils.getUserDetailsFromJwtToken(jwtToken);
				UserInfo userInfo = buildUserInfo(userDetailsMap);
				loggedInUserContextHolder.setLoggedInUser(userInfo);
			}
		return HandlerInterceptor.super.preHandle(request, response, handler);
	}

	/**
	 * Builds the user info.
	 *
	 * @param userDetailsMap the user details map
	 * @return the user info
	 */
	private UserInfo buildUserInfo(Claims userDetailsMap) {
		UserInfo userInfo = new UserInfo();
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.ID))) {
			userInfo.setId(Integer.parseInt(userDetailsMap.get(ApplicationConstants.ID).toString()));
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.USER_NAME))) {
			userInfo.setUsername(userDetailsMap.get(ApplicationConstants.USER_NAME).toString());
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.EMAIL))) {
			userInfo.setEmail(userDetailsMap.get(ApplicationConstants.EMAIL).toString());
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.PLATFORM_IDENTITY))) {
			userInfo.setPlatformIdentity(userDetailsMap.get(ApplicationConstants.PLATFORM_IDENTITY).toString());
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.ASSOCIATION_ID))) {
			userInfo.setAssociationId(
					Integer.parseInt(userDetailsMap.get(ApplicationConstants.ASSOCIATION_ID).toString()));
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.USER_TYPE))) {
			ModelMapper modelMapper = new ModelMapper();
			UserType userType = modelMapper.map(userDetailsMap.get(ApplicationConstants.USER_TYPE), UserType.class);
			userInfo.setUserTypeId(userType);
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.IDENTITY))) {
			userInfo.setIdentity(userDetailsMap.get(ApplicationConstants.IDENTITY).toString());
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.PLATFORM_DETAILS))) {
			ModelMapper modelMapper = new ModelMapper();
			PlatformDetailsDto platformDetails = modelMapper.map(userDetailsMap.get(ApplicationConstants.PLATFORM_DETAILS), PlatformDetailsDto.class);
			userInfo.setPlatformDetailsDto(platformDetails);
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.COMPANY_ID))) {
			userInfo.setCompanyId(Integer.parseInt(userDetailsMap.get(ApplicationConstants.COMPANY_ID).toString()));
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.ALLOCATION_USER_TYPE))) {
			userInfo.setAllocationUserType(Integer.parseInt(userDetailsMap.get(ApplicationConstants.ALLOCATION_USER_TYPE).toString()));
		}
		if(ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.COMPANY_NAME))) {
			userInfo.setCompanyName(userDetailsMap.get(ApplicationConstants.COMPANY_NAME).toString());
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.ROLES))) {
			String object = (String) userDetailsMap.get(ApplicationConstants.ROLES);
			String string = "{" + '"'+"userRoleList"+'"'+":"+ object + "}";
			RoleListDto readValue = null;
			try {
				readValue = new com.fasterxml.jackson.databind.ObjectMapper().readValue(string, RoleListDto.class);
			} catch (JsonMappingException e) {
				logger.error(e.getMessage());
			} catch (JsonProcessingException e) {
				logger.error(e.getMessage());
			}
			if(ApplicationUtils.isValidateObject(readValue)) {
			userInfo.setRoles(readValue.getUserRoleList());
			}
		}
		return userInfo;
	}

	/**
	 * Parses the jwt.
	 *
	 * @param request the request
	 * @return the string
	 */
	private String parseJwt(HttpServletRequest request) {
		String headerAuth = request.getHeader(ApplicationConstants.AUTHORIZATION);
		if (StringUtils.hasText(headerAuth) && headerAuth.startsWith(ApplicationConstants.BEARER)) {
			return headerAuth.substring(7);
		}
		return null;
	}
}

