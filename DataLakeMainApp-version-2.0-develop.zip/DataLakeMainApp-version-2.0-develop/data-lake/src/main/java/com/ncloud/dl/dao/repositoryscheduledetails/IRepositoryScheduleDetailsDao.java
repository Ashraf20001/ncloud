package com.ncloud.dl.dao.repositoryscheduledetails;

import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.entity.RepositoryScheduleDetails;

/**
 * The Interface IRepositoryScheduleDetailsDao.
 */
public interface IRepositoryScheduleDetailsDao {

	/**
	 * Gets the repository schedule details by identity.
	 *
	 * @param identity the identity
	 * @return the repository schedule details by identity
	 */
	RepositoryScheduleDetails getRepositoryScheduleDetailsByIdentity(String identity);

	/**
	 * @param repositoryScheduleDetails
	 * @return 
	 * @throws ApplicationException 
	 */
	RepositoryScheduleDetails saveRepositoryScheduleDetails(RepositoryScheduleDetails repositoryScheduleDetails) throws ApplicationException;
}
