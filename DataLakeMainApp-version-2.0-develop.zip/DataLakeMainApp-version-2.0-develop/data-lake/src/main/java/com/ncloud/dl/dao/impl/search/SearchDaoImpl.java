package com.ncloud.dl.dao.impl.search;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.hibernate.query.NativeQuery;
import org.hibernate.transform.AliasToEntityMapResultTransformer;
import org.springframework.stereotype.Repository;

import com.ncloud.dl.config.common.base.dao.BaseDao;
import com.ncloud.dl.constants.core.TableConstants;
import com.ncloud.dl.service.ISearchDao;
import com.ncloud.dl.transfer.object.dto.RepositoryDto;
import com.ncloud.dl.transfer.object.entity.DataRepository;

/**
 * The Class SearchDaoImpl.
 */
@Repository
public class SearchDaoImpl extends BaseDao implements ISearchDao  {

	
	/**
	 * Gets the repository details.
	 *
	 * @param repositoryId the repository id
	 * @return the repository details
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<DataRepository> getRepositoryDetails(List<Integer> repositoryId) {
			CriteriaBuilder builder = getCriteriaBuilder();
			CriteriaQuery<DataRepository> criteria = builder.createQuery(DataRepository.class);
			Root<DataRepository> root = criteria.from(DataRepository.class);
			criteria.select(root);
			List<Predicate> predicates = new ArrayList<Predicate>();
			predicates.add(builder.and(root.get(TableConstants.ID).in(repositoryId)));
			predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLTSTS), false)));
		return (List<DataRepository>) getResultList(createQuery(builder, criteria, root, predicates));
	}
	
	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
		
	}

	
	/**
	 * Gets the repository name by index name.
	 *
	 * @param indexName the index name
	 * @return the repository name by index name
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<RepositoryDto> getRepositoryNameByIndexName(String indexName) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<RepositoryDto> criteria = builder.createQuery(RepositoryDto.class);
		Root<DataRepository> root = criteria.from(DataRepository.class);
		criteria.multiselect(root.get(TableConstants.REPOSITORY_TABLE_NAME), root.get(TableConstants.REPOSITORY_NAME));
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(root.get(TableConstants.REPOSITORY_TABLE_NAME).in(indexName)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLTSTS), Boolean.FALSE)));
		List<?> result =  getResultList(createQuery(builder, criteria, root, predicates));
		return (List<RepositoryDto>) result;
	}

	/**
	 * Gets the data using unique id.
	 *
	 * @param query the query
	 * @return the data using unique id
	 */
	@SuppressWarnings({ "unchecked", "deprecation" })
	@Override
	public List<HashMap<String, Object>> getDataUsingUniqueId(String query) {
		NativeQuery<?> nativeQuery = getSession().createNativeQuery(query);
		nativeQuery.setResultTransformer(AliasToEntityMapResultTransformer.INSTANCE);
		return (List<HashMap<String,Object>>) nativeQuery.getResultList();
	}
	
	/**
	 * Get HashMap by RAW_QUERY
	 * @param query
	 * @return
	 */
	@Override
	@SuppressWarnings({ "unchecked", "deprecation" })
	public HashMap<String, Object> getSqlDataWithIdentity(String query) {
		NativeQuery<?> nativeQuery = getSession().createNativeQuery(query);
		nativeQuery.setResultTransformer(AliasToEntityMapResultTransformer.INSTANCE);
		return (HashMap<String,Object>) nativeQuery.getSingleResult();
	}

}
