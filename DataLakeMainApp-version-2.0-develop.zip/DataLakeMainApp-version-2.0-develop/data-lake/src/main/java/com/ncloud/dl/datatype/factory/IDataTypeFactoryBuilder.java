package com.ncloud.dl.datatype.factory;

/**
 * The Interface IDataTypeFactoryBuilder.
 */
public interface IDataTypeFactoryBuilder {
	
	/**
	 * @param createQuery
	 * @param valQuery 
	 * @return
	 */
	String getDataTypeWithColQuery(String createQuery, String valQuery);

}
