package com.ncloud.dl.utils;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Component;

import com.ncloud.dl.constants.core.TableConstants;
import com.ncloud.dl.transfer.object.entity.DataRepository;
import com.ncloud.dl.transfer.object.enums.RepositoryStatusEnum;

/**
 * The Class BuildQueryUtils.
 */
@Component
public class BuildQueryUtils {
	
	
	/**
	 * @param search
	 * @param builder
	 * @param root
	 * @param predicates
	 * @return
	 */
	public List<Predicate> validateQueryAndBuild(String search, CriteriaBuilder builder, Root<DataRepository> root,
			List<Predicate> predicates) {
		Predicate searchPredicate = null;
		boolean isValidInteger = isInteger(search);
		boolean isValidDouble = isDouble(search);
		if (isValidInteger) {
			Object value = Integer.parseInt(search);
			String[] fieldNames = { TableConstants.FIELD_COUNT};
			searchPredicate = generateQueryBuild(builder, root, searchPredicate, value, fieldNames);
		} else if (isValidDouble) {
			Object value = Double.parseDouble(search);
			String[] fieldNames = { TableConstants.REPO_VERSION };
			searchPredicate = generateQueryBuild(builder, root, searchPredicate, value, fieldNames);
		} else {
			 Expression<String> expression = builder.lower(root.get(TableConstants.REPO_NAME));
			    String searchString = TableConstants.PERCENTAGE + search.toLowerCase() + TableConstants.PERCENTAGE;
			     searchPredicate = builder.like(expression, searchString);
			     
			     List<String> statusList = RepositoryStatusEnum.getAllRepositoryStatus();
			     List<String> matchingStatus = statusList.stream()
			                .filter(status -> status.toLowerCase().contains(search.toLowerCase()))
			                .collect(Collectors.toList());
			     List<Integer> valuesToMatch = RepositoryStatusEnum.getRepositoryStatusIds(matchingStatus);
			     Expression<String> somePropertyExpression = root.get(TableConstants.REPO_STATUS);
			     Predicate inPredicate = somePropertyExpression.in(valuesToMatch);
			     predicates.add(builder.or(searchPredicate, inPredicate));
			     return predicates;
		}
		predicates.add(searchPredicate);
		return predicates;
	}
	
	/**
	 * @param builder
	 * @param root
	 * @param searchPredicate
	 * @param sampl
	 * @param fieldNames
	 * @return
	 */
	private Predicate generateQueryBuild(CriteriaBuilder builder, Root<DataRepository> root, Predicate searchPredicate,
			Object sampl, String[] fieldNames) {
		for (String fieldName : fieldNames) {
			Path<Object> fieldPath = root.get(fieldName);
			Predicate fieldPredicate = builder.equal(fieldPath, sampl);
			if (searchPredicate == null) {
				searchPredicate = fieldPredicate;
			} else {
				searchPredicate = builder.or(searchPredicate, fieldPredicate);
			}
		}
		return searchPredicate;
	}
	
	/**
	 * @param str
	 * @return
	 */
	public boolean isInteger(String str) {
	    return str.matches("^[-+]?\\d+$");
	}
	
	/**
	 * @param str
	 * @return
	 */
	public boolean isDouble(String str) {
	    return str.matches("^[-+]?\\d*\\.?\\d+$");
	}


}
