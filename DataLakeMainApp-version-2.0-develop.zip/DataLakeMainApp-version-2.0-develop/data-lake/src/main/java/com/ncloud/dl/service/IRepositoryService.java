package com.ncloud.dl.service;

import java.io.UnsupportedEncodingException;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.dto.CommentsDto;
import com.ncloud.dl.transfer.object.dto.DataRepositoryDto;
import com.ncloud.dl.transfer.object.dto.FieldRepositoryDto;
import com.ncloud.dl.config.model.FilterOrSortingVo;
import com.ncloud.dl.transfer.object.dto.RepositoryScheduleDetailsDto;
import com.ncloud.dl.transfer.object.dto.SchedulerNotificationDto;
import com.ncloud.dl.transfer.object.dto.UserInfo;

/**
 * The Interface IRepositoryService.
 */
public interface IRepositoryService {


	/**
	 * @param fieldRepositoryDto
	 * @param userInfo 
	 * @return 
	 * @throws ApplicationException 
	 */
	String saveCommentsForRepository(CommentsDto commentsDto, UserInfo userInfo, HttpServletRequest httpServletRequest) throws ApplicationException;

	/**
	 * @param repositoryIdentity
	 * @return
	 */
	FieldRepositoryDto getRepositoryAndFieldDetails(String repositoryIdentity);

	/**
	 * @param fieldRepositoryDto
	 * @param loggedInUser
	 * @param httpServletRequest 
	 * @return 
	 * @throws ApplicationException 
	 */
	Boolean updateRepositoryDetails(FieldRepositoryDto fieldRepositoryDto, UserInfo loggedInUser, HttpServletRequest httpServletRequest) throws ApplicationException;

	/**
	 * @param filterVo
	 * @param search 
	 * @param userRoleStatus 
	 * @return
	 * @throws ApplicationException 
	 */
	Long getRepositoryListCount(List<FilterOrSortingVo> filterVo, String search, String userRoleStatus) throws ApplicationException;


	/**
	 * @param min
	 * @param max
	 * @param filterVo
	 * @param userRoleStatus
	 * @param loggedInUser
	 * @param search
	 * @param httpServletRequest 
	 * @return
	 * @throws ApplicationException
	 */
	List<DataRepositoryDto> getRepositoryCardList(Integer min, Integer max, List<FilterOrSortingVo> filterVo,String userRoleStatus, UserInfo loggedInUser,
			String search, HttpServletRequest httpServletRequest) throws ApplicationException;
	
	/**
	 * @param fieldRepositoryDto
	 * @param userInfo
	 * @param httpServletRequest 
	 * @param isCloneFlow
	 * @return 
	 * @throws ApplicationException
	 */
	String saveFieldRepostiory(FieldRepositoryDto fieldRepositoryDto, UserInfo userInfo, HttpServletRequest httpServletRequest) throws ApplicationException;

	
	/**
	 * @param repositoryIdentity
	 * @param httpServletRequest 
	 * @return
	 * @throws ApplicationException
	 */
	List<CommentsDto> getCommentsValues(String repositoryIdentity, HttpServletRequest httpServletRequest) throws ApplicationException;
	/**
	 * @param identity
	 * @return
	 * @throws ApplicationException
	 */
	String updateStatusDataRepository(String repositoryIdentity, String action, UserInfo userInfo,
			HttpServletRequest httpServletRequest) throws ApplicationException;

	/**
	* @param fieldRepositoryDto
	 * @param userInfo 
	 * @param httpServletRequest 
	 * @return 
	 * @throws ApplicationException 
	 */
	void approveRepository(FieldRepositoryDto fieldRepositoryDto, UserInfo userInfo, HttpServletRequest httpServletRequest) throws ApplicationException;

	/**
	 * @param fieldRepositoryDto
	 * @param loggedInUser
	 * @return
	 * @throws ApplicationException
	 */
	String updateRepositoryName(FieldRepositoryDto fieldRepositoryDto, UserInfo loggedInUser)
			throws ApplicationException;
	
	/**
	 * @param repositoryIdentity
	 * @param date
	 * @param userInfo 
	 * @return
	 * @throws ApplicationException 
	 */
	String updateCardRepository(String repositoryIdentity, LocalDate date,UserInfo loggedInUser ) throws ApplicationException;

	/**
	 * @param schedulerIdentity
	 * @param loggedInUser
	 * @return
	 * @throws ApplicationException
	 */
	String schedulerDelete(String schedulerIdentity, UserInfo loggedInUser) throws ApplicationException; 
	
	/**
	 * @param loggedInUser
	 * @param httpServletRequest 
	 * @return
	 * @throws ApplicationException 
	 */
	String getUserRoleDetails(UserInfo loggedInUser, HttpServletRequest httpServletRequest) throws ApplicationException;

	/**
	 * @param repositoryScheduleDetailsDto
	 * @param loggedInUser
	 * @return
	 * @throws ApplicationException 
	 */
	String updateSchedulerDetails(RepositoryScheduleDetailsDto repositoryScheduleDetailsDto, UserInfo loggedInUser) throws ApplicationException;
	
	/**
	 * @param schedulerIdentity
	 * @return
	 */
	RepositoryScheduleDetailsDto  editschedulerDetails(String schedulerIdentity);
	

	/**
	 * @param min
	 * @param max
	 * @param filterVo
	 * @return
	 * @throws ApplicationException
	 */
	List<SchedulerNotificationDto> getSchedulerDetails(Integer min, Integer max, List<FilterOrSortingVo> filterVo) throws ApplicationException;

	/**
	 * @param filterVo
	 * @return
	 * @throws ApplicationException
	 */
	Long getSchedulerListCount() throws ApplicationException;

	/**
	 * @param min
	 * @param max
	 * @param filterVo
	 * @param search 
	 * @param parsedBoolean 
	 * @param status
	 * @return
	 * @throws ApplicationException
	 */
	List<DataRepositoryDto> getRepositoryCardListforApproved(Integer min, Integer max, List<FilterOrSortingVo> filterVo, String search,UserInfo userInfo, Boolean parsedBoolean) throws ApplicationException;

	/**
	 * @param filterVo
	 * @param search
	 * @param parsedBoolean 
	 * @return
	 * @throws ApplicationException 
	 */
	Long getRepositoryApprovedListCount(List<FilterOrSortingVo> filterVo, String search, Boolean parsedBoolean) throws ApplicationException;

	/**
	 * Gets the repository status by identity.
	 *
	 * @param repositoryIdentity the repository identity
	 * @return the repository status by identity
	 */
	Map<String, Object> getRepositoryStatusByIdentity(String repositoryIdentity);

	/**
	 * @param associationId
	 * @param fromDate 
	 * @return
	 * @throws ApplicationException
	 * @throws UnsupportedEncodingException 
	 */
	List<String> getCompanyUploadStatus(Integer associationId, String fromDate) throws ApplicationException, UnsupportedEncodingException;


	


}