package com.ncloud.dl.config;

import java.io.IOException;

import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ncloud.dl.config.property.EnvironmentProperties;
import com.ncloud.dl.search.eswrapper.ElasticSearchClient;
import com.ncloud.dl.search.eswrapper.EntityUtilsImpl;
import com.ncloud.dl.search.eswrapper.IElasticSearchOperation;
import com.ncloud.dl.search.eswrapper.IIndicesClient;
import com.ncloud.dl.search.eswrapper.IRestClient;
import com.ncloud.dl.search.eswrapper.IndicesClientImpl;
import com.ncloud.dl.search.eswrapper.RestClientImpl;
import com.ncloud.dl.search.eswrapper.SearchResponseObject;

import lombok.RequiredArgsConstructor;



/**
 * The Class ElasticClientConfig.
 */
@Configuration
@RequiredArgsConstructor
public class ElasticClientConfig {

		/** The environment properties. */
		private final EnvironmentProperties environmentProperties;
	
		/**
		 * Gets the elastic client.
		 *
		 * @param getRestHighLevelClient the get rest high level client
		 * @param getIndicesClient the get indices client
		 * @param getSearchResponse the get search response
		 * @return the elastic client
		 */
		@Bean
		IElasticSearchOperation getElasticClient(RestHighLevelClient getRestHighLevelClient
				,IIndicesClient getIndicesClient, SearchResponseObject getSearchResponse) {
			 return new ElasticSearchClient(getRestHighLevelClient, 
					 getSearchResponse,
					 getIndicesClient);
		}
		
		/**
		 * Gets the rest high level client.
		 *
		 * @return the rest high level client
		 */
		@Bean
		public RestHighLevelClient getRestHighLevelClient() {
			return new RestHighLevelClient(createRestHighLevelClientBuilder());
		}

		/**
		 * Creates the rest high level client builder.
		 *
		 * @return the rest client builder
		 */
		@Bean
		public RestClientBuilder createRestHighLevelClientBuilder() {
			final CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
			credentialsProvider.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials(environmentProperties.getElasticSearchUsername(), environmentProperties.getElasticSearchPassword()));

			return RestClient.builder(new HttpHost(environmentProperties.getElasticSearchHost(), Integer.parseInt(environmentProperties.getElasticSearchPort()), environmentProperties.getElasticSearchSchema()));
		}
		
		/**
		 * Gets the indices client.
		 *
		 * @param getRestHighLevelClient the get rest high level client
		 * @return the indices client
		 */
		@Bean
		IIndicesClient getIndicesClient(RestHighLevelClient getRestHighLevelClient) {
			return new IndicesClientImpl(getRestHighLevelClient.indices());
		}
		
		/**
		 * Gets the search response.
		 *
		 * @param getRestHighLevelClient the get rest high level client
		 * @return the search response
		 */
		@Bean
		SearchResponseObject getSearchResponse(RestHighLevelClient getRestHighLevelClient) {
			return new SearchResponseObject(getRestHighLevelClient);
		}
		
		/**
		 * Gets the rest client.
		 *
		 * @param createRestClientBuilder the create rest client builder
		 * @return the rest client
		 */
		@Bean
		IRestClient getRestClient(RestClientBuilder createRestClientBuilder) {
			RestClient restClient = createRestClientBuilder.build();
			RestClientImpl restClientImpl = new RestClientImpl(restClient);
			Runtime.getRuntime().addShutdownHook(new Thread(() -> {
				try {
					restClientImpl.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}));
			return restClientImpl;
		}
		
		/**
		 * Gets the entity utils impl.
		 *
		 * @return the entity utils impl
		 */
		@Bean
		EntityUtilsImpl getEntityUtilsImpl() {
			return new EntityUtilsImpl();
		}
		
}
