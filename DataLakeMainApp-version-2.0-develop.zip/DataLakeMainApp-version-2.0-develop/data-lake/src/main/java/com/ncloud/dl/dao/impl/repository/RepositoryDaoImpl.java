package com.ncloud.dl.dao.impl.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.ncloud.dl.config.common.base.dao.BaseDao;
import com.ncloud.dl.constants.core.TableConstants;
import com.ncloud.dl.dao.repository.IRepositoryDao;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.entity.Comments;
import com.ncloud.dl.transfer.object.entity.DataRepository;

/**
 * The Class RepositoryDaoImpl.
 */
@Repository
@Transactional
public class RepositoryDaoImpl extends BaseDao implements IRepositoryDao {

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
		
	}
	/**
	 * Save Comments
	 * @param comments
	 * @throws ApplicationException 
	 */
	@Override
	public void saveComments(Comments comments) throws ApplicationException {
		save(comments, TableConstants.COMMENTS);
	}

	/**
	 * Fetch DataRepository by identity
	 * @param repoId
	 * @return
	 */
	@Override
	public DataRepository getRepositoryDetails(String repositoryIdentity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<DataRepository> createQuery = builder.createQuery(DataRepository.class);
		Root<DataRepository> root = createQuery.from(DataRepository.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETE_STS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IDENTITY), repositoryIdentity)));
		return (DataRepository) getSingleResult(createQuery(builder, createQuery, root, predicates));
	}
	
	
	/**
	 * Update datarepository
	 * @param dataRepository
	 * @return
	 * @throws ApplicationException 
	 */
	@Override
	public void updateRepostioryDetails(DataRepository dataRepository) throws ApplicationException {
		update(dataRepository);
	}
	
	/**
	 * Save DataRepository
	 * @param dataRepository
	 * @return
	 * @throws ApplicationException 
	 */
	@Override
	public DataRepository saveRepostioryDetails(DataRepository dataRepository) throws ApplicationException {
		save(dataRepository, TableConstants.DATA_REPOSITORY);
		return dataRepository;
	}

	/**
	 * Get Object Array by repository identity
	 * @param {@link String}
	 * @return Object[]
	 */
	@Override
	public Object[] getRepositoryStatusByIdentity(String repositoryIdentity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Object[]> createQuery = builder.createQuery(Object[].class);
		Root<DataRepository> root = createQuery.from(DataRepository.class);
		createQuery.multiselect(root.get(TableConstants.REPO_STATUS), root.get(TableConstants.EFFECTIVE_DATE));
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETE_STS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IDENTITY), repositoryIdentity)));
		return (Object[]) getSingleResult(createQuery(builder, createQuery, root, predicates));
	}

	

}
