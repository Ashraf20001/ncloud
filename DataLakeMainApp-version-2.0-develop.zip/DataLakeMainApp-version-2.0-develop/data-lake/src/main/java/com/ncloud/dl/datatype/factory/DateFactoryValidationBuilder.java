package com.ncloud.dl.datatype.factory;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ncloud.dl.constants.core.QueryConstants.ColumnConstants;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.exception.core.codes.ErrorCodes;
import com.ncloud.dl.transfer.object.entity.FieldConfiguration;
import com.ncloud.dl.utils.core.ApplicationUtils;

/**
 * The Class DateFactoryValidationBuilder.
 */
@Service
@Qualifier("dateFactoryValidationBuilder")
public class DateFactoryValidationBuilder implements IDataTypeFactoryValidationBuilder {

	/** The date format. */
	@Value("${dlmainapp.date-format}")
	private String dateFormat;
	/**
	 * @param errorMsg
	 * @param entry
	 * @param mandatory
	 * @return
	 * @throws ApplicationException
	 * @throws ParseException 
	 */
	@Override
	public String getDataTypeValidationBuilder(String errorMsg, Entry<String, Object> entry, Boolean mandatory,
			HashMap<String, Object> successRecord, FieldConfiguration fieldConfig) throws ApplicationException, ParseException {
		if(mandatory.equals(Boolean.TRUE) && !ApplicationUtils.isValidString(entry.getValue().toString())) {
			throw new ApplicationException(ErrorCodes.MANDATORY_FIELDS);
		}
		if (!ApplicationUtils.isValidDateFormat(dateFormat, entry.getValue().toString())) {
			throw new ApplicationException(ErrorCodes.ERR_DATE_TYPE);
		}
		successRecord.put(fieldConfig.getColumnName(), entry.getValue());
		successRecord.put(ColumnConstants.STATUS, Boolean.FALSE);
		return entry.getValue().toString();

	}
}
