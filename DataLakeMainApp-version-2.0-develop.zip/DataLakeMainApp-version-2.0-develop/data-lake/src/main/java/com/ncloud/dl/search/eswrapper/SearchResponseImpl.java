package com.ncloud.dl.search.eswrapper;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.SearchHits;

/**
 * The Class SearchResponseImpl.
 */
public class SearchResponseImpl implements ISearchResponse {
	
	/** The search response. */
	private final SearchResponse searchResponse;

	/**
	 * Instantiates a new search response impl.
	 *
	 * @param searchResponse the search response
	 */
	public SearchResponseImpl(SearchResponse searchResponse) {
		this.searchResponse=searchResponse;
	}

	/**
	 * Gets the hits.
	 *
	 * @return the hits
	 */
	@Override
	public ISearchHits getHits() {
			SearchHits hits = searchResponse.getHits();
			return new SearchHitsImpl(hits);
	}

}
