package com.ncloud.dl.search.eswrapper;

import java.io.IOException;

import org.elasticsearch.action.admin.indices.settings.put.UpdateSettingsRequest;
import org.elasticsearch.action.support.master.AcknowledgedResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.indices.CreateIndexRequest;
import org.elasticsearch.client.indices.CreateIndexResponse;
import org.elasticsearch.client.indices.GetIndexRequest;
import org.elasticsearch.client.indices.GetIndexResponse;

/**
 * The Interface IIndicesClient.
 */
public interface IIndicesClient {

	/**
	 * Gets the.
	 *
	 * @param getIndexRequest the get index request
	 * @param options the options
	 * @return the gets the index response
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public GetIndexResponse get(GetIndexRequest getIndexRequest, RequestOptions options) throws IOException;
	
	/**
	 * Exists.
	 *
	 * @param request the request
	 * @param options the options
	 * @return true, if successful
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public boolean exists(GetIndexRequest request, RequestOptions options) throws IOException;
	
	/**
	 * Creates the.
	 *
	 * @param createIndexRequest the create index request
	 * @param options the options
	 * @return the creates the index response
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public CreateIndexResponse create(CreateIndexRequest createIndexRequest,
            RequestOptions options) throws IOException;
	
	/**
	 * Put settings.
	 *
	 * @param updateSettingsRequest the update settings request
	 * @param options the options
	 * @return the acknowledged response
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public AcknowledgedResponse putSettings(UpdateSettingsRequest updateSettingsRequest, RequestOptions options) throws IOException;

}
