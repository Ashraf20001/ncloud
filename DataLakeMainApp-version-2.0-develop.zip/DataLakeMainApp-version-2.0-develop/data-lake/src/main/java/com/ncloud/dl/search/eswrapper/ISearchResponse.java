package com.ncloud.dl.search.eswrapper;

/**
 * The Interface ISearchResponse.
 */
public interface ISearchResponse {

	 /**
 	 * Gets the hits.
 	 *
 	 * @return the hits
 	 */
 	public ISearchHits getHits();
}
