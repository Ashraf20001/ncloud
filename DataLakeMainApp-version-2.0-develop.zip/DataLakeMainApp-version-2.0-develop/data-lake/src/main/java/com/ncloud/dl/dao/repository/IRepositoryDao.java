package com.ncloud.dl.dao.repository;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.entity.Comments;
import com.ncloud.dl.transfer.object.entity.DataRepository;

/**
 * The Interface IRepositoryDao.
 */
public interface IRepositoryDao {

	/**
	 * @param comments
	 * @throws ApplicationException 
	 */
	void saveComments(Comments comments) throws ApplicationException;

	/**
	 * @param repoId
	 * @return
	 */
	DataRepository getRepositoryDetails(String repoId);

	/**
	 * @param dataRepository
	 * @return
	 * @throws ApplicationException 
	 */
	DataRepository saveRepostioryDetails(DataRepository dataRepository) throws ApplicationException;

	/**
	 * @param dataRepository
	 * @return
	 * @throws ApplicationException 
	 */
	void updateRepostioryDetails(DataRepository dataRepository) throws ApplicationException;

	/**
	 * Gets the repository status by identity.
	 *
	 * @param repositoryIdentity the repository identity
	 * @return the repository status by identity
	 */
	Object[] getRepositoryStatusByIdentity(String repositoryIdentity);
	

}
