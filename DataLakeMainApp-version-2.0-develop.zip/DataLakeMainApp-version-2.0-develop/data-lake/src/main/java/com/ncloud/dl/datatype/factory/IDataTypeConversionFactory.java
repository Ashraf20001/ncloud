package com.ncloud.dl.datatype.factory;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map.Entry;

import com.ncloud.dl.transfer.object.entity.FieldConfiguration;

/**
 * A factory for creating IDataTypeConversion objects.
 */
public interface IDataTypeConversionFactory {
	
	/**
	 * @param valMap
	 * @param fieldConfiguration
	 * @param entry
	 * @throws ParseException 
	 */
	void buildBulkRecordMap(HashMap<String, Object> valMap, FieldConfiguration fieldConfiguration, Entry<String, Object> entry) throws ParseException;

}
