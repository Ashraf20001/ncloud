package com.ncloud.dl.datatype.factory;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.ncloud.dl.constants.core.ApplicationConstants;
import com.ncloud.dl.constants.core.QueryConstants.ColumnConstants;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.exception.core.codes.ErrorCodes;
import com.ncloud.dl.transfer.object.entity.FieldConfiguration;
import com.ncloud.dl.utils.core.ApplicationUtils;

/**
 * The Class NumberDataTypeValidate.
 */
@Service
@Qualifier("numberValidator")
public class NumberDataTypeValidate implements IBulkUploadValidationBuilder {

	/**
	 * Gets the data type validation builder.
	 *
	 * @param successRecord the success record
	 * @param fieldConfiguration the field configuration
	 * @param entry the entry
	 * @param mandatory the mandatory
	 * @param userId the user id
	 * @return the data type validation builder
	 * @throws ApplicationException the application exception
	 * @throws ParseException the parse exception
	 */
	@Override
	public Boolean getDataTypeValidationBuilder(HashMap<String, Object> successRecord,
			FieldConfiguration fieldConfiguration, Entry<String, Object> entry, Boolean mandatory, Integer userId)
			throws ApplicationException, ParseException {
		buildHashMap(successRecord, fieldConfiguration, entry);
		if (Boolean.TRUE.equals(mandatory)) {
			if (ApplicationUtils.isBlank(entry.getValue().toString())) {
				return buildErrorMessageForMandatory(successRecord, fieldConfiguration);
			}else if (!ApplicationUtils.isValidDouble(entry.getValue().toString())) {
				return buildSystemErrorMessage(successRecord, fieldConfiguration);
			}
			return Boolean.FALSE;
		} else {
			if (!ApplicationUtils.isValidDouble(entry.getValue().toString())) {
				return buildSystemErrorMessage(successRecord, fieldConfiguration);
			}
		}
		return Boolean.FALSE;
	}

	/**
	 * @param fieldConfiguration
	 * @param entry
	 */
	private void buildHashMap(HashMap<String, Object> successRecord, FieldConfiguration fieldConfiguration,
			Entry<String, Object> entry) {
		if (!entry.getValue().equals(ApplicationConstants.NULL)) {
			successRecord.put(fieldConfiguration.getColumnName(), entry.getValue().toString());
		}
		successRecord.put(ColumnConstants.STATUS, Boolean.FALSE);
	}

	/**
	 * 
	 * @param successRecord
	 * @param fieldConfiguration
	 * @return
	 */
	private Boolean buildSystemErrorMessage(HashMap<String, Object> successRecord,
			FieldConfiguration fieldConfiguration) {
		String errorMsg = ErrorCodes.FIELD_DATA_TYPE.getErrorMessage();
		successRecord.put(ApplicationConstants.ERROR_MSG, errorMsg+ApplicationConstants.EMPTY_STRING+fieldConfiguration.getFieldName());
		return Boolean.TRUE;
	}

	/**
	 * 
	 * @param successRecord
	 * @param fieldConfiguration
	 * @return
	 */
	private Boolean buildErrorMessageForMandatory(HashMap<String, Object> successRecord,
			FieldConfiguration fieldConfiguration) {
		String errorMessage = fieldConfiguration.getErrMsg();
		String errorMsg = ApplicationUtils.isValidateObject(errorMessage) && ApplicationUtils.isNotBlank(errorMessage)
				? errorMessage
				: ErrorCodes.MANDATORY_FIELD.getErrorMessage();
		successRecord.put(ApplicationConstants.ERROR_MSG, errorMsg+ApplicationConstants.EMPTY_STRING+fieldConfiguration.getFieldName());
		return Boolean.TRUE;
	}

}
