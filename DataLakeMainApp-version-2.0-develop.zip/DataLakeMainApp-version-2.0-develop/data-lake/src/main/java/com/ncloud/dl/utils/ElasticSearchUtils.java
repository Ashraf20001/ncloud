package com.ncloud.dl.utils;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Properties;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.errors.TimeoutException;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ncloud.dl.config.property.EnvironmentProperties;
import com.ncloud.dl.exception.core.ApplicationException;
import org.springframework.beans.factory.annotation.Value;

import lombok.RequiredArgsConstructor;

/**
 * The Class ElasticSearchUtils.
 */
@Component
@RequiredArgsConstructor
public class ElasticSearchUtils {

	/** The environment properties. */
	private final EnvironmentProperties environmentProperties;

	/** The producer key serializer. */
	@Value("${spring.kafka.producer.key-serializer}")
	private String producerKeySerializer;
	
	/** The kafa producer bootstrap server. */
	@Value("${spring.kafka.producer.bootstrap-servers}")
	private String kafaProducerBootstrapServer;
	/**
	 * Logger
	 */
	private static final Logger log = LoggerFactory.getLogger(ElasticSearchUtils.class);

	/**
	 * {@summary creates new topic with given name for elastic sync-up}@
	 * @param index
	 * @throws ApplicationException
	 */
	public void createIndex(String index) throws ApplicationException {
		try {
			Properties properties = new Properties();
			properties.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, environmentProperties.getElasticSyncUpKafka());
			NewTopic topic = new NewTopic(index, Integer.parseInt(environmentProperties.getKafKaPartitions()), Short.parseShort(environmentProperties.getKafKaReplicationFactor()));
			AdminClient adminClient = AdminClient.create(properties);
			adminClient.createTopics(Collections.singleton(topic)).all().get();
			log.info(index + " created successfully.......................................................");
		}  catch (TimeoutException e) {
			throw new ApplicationException(e.getMessage());
		}
		catch (Exception e) {
			log.error(e.getMessage());
			throw new ApplicationException(e.getMessage());
		}
	}

	/**
	 * {@summary sync-up uploaded data into elastic search}@
	 * @param index
	 * @param document
	 * @throws ApplicationException
	 */
	public void sync(String index, String document) throws ApplicationException {
		try(AdminClient adminClient = AdminClient.create(getKafkaProperties())) {
			KafkaProducer<String, String> kafkaProducer = new KafkaProducer<>(getKafkaProperties());
			ProducerRecord<String, String> record = new ProducerRecord<>(index, document);
			kafkaProducer.send(record);
			log.info("index : " + index + " payload : " + document + "........................");
			log.info(LocalDateTime.now().toString());
		} catch (Exception e) {
			throw new ApplicationException(e.getMessage());
		}
	}
	
	/**
	 * @return properties
	 */
	public Properties getKafkaProperties() {
		Properties properties = new Properties();
		properties.put("bootstrap.servers", environmentProperties.getElasticSyncUpKafka());
		properties.put("key.serializer", producerKeySerializer);
		properties.put("value.serializer", producerKeySerializer);
		properties.put("key.converter", environmentProperties.getKafkaConverter());
		properties.put("value.converter", environmentProperties.getKafkaConverter());
		properties.put("key.converter.schemas.enable", Boolean.FALSE);
		properties.put("internal.key.converter", environmentProperties.getKafkaConverter());
		properties.put("internal.value.converter", environmentProperties.getKafkaConverter());
		properties.put("internal.key.converter.schemas.enable", Boolean.FALSE);
		properties.put("offset.storage.file.filename", "/tmp/connect.offsets");
		properties.put("offset.flush.interval", 10000);
		return properties;
	}
	
	/****************************************** KAFKA-PRODUCER CONFIGURATION **********************************************/
	
	/**
	 * @param dataLakeBulkUploadDto
	 * @throws ApplicationException 
	 */
	public void dropBulkUploadInfo(Object dataLakeBulkUploadDto) throws ApplicationException {
		try (KafkaProducer<String, String> producer = new KafkaProducer<>(getKafkaProducerConfig())) {
			ObjectMapper objectMapper = new ObjectMapper();
	        String jsonObject = objectMapper.writeValueAsString(dataLakeBulkUploadDto);
			ProducerRecord<String, String> record = new ProducerRecord<>("dl_event", jsonObject);
			producer.send(record);
			log.info("Data sent to Kafka topic successfully.");
		} catch (Exception e) {
			throw new ApplicationException(e.getLocalizedMessage());
		}
	}
	
	/**
	 * @return producerConfiguration
	 */
	private Properties getKafkaProducerConfig() {
		Properties props = new Properties();
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,kafaProducerBootstrapServer);
		props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		return props;
	}
		
}
