package com.ncloud.dl.service.impl.resttemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.ncloud.dl.config.property.EnvironmentProperties;
import com.ncloud.dl.constants.core.ApplicationConstants;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.exception.core.codes.ErrorCodes;
import com.ncloud.dl.transfer.object.dto.AccessMappingPrivilegeDto;
import com.ncloud.dl.transfer.object.dto.CompanyDetailsDto;
import com.ncloud.dl.transfer.object.dto.SchedulerRequestDto;
import com.ncloud.dl.transfer.object.dto.UserDetailsDto;
import com.ncloud.dl.transfer.object.dto.UserPrivillageDto;
import com.ncloud.dl.utils.RestTemplateService;
import com.ncloud.dl.utils.core.ApplicationUtils;
import com.ncloud.dl.utils.core.RestTemplateUtils;

import lombok.RequiredArgsConstructor;

/**
 * The Class RestTemplateServiceImpl.
 */
@Service
@Transactional
@RequiredArgsConstructor
public class RestTemplateServiceImpl {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(RestTemplateServiceImpl.class);
	
	/**
	 * RestTemplateService
	 */
	private final RestTemplateService restTemplateService;
	
	/**
	 * RestTemplate
	 */
	private final RestTemplate restTemplate;
	
	/**
	 * restTemplateUtils
	 */
	private final RestTemplateUtils restTemplateUtils;
	
	/** The environment properties. */
	private final EnvironmentProperties environmentProperties;
	
	/** The common service uri. */
	@Value("${dlmainapp.common-service-path}")
	private String commonServiceUri;

	/**
	 * @param request
	 * @return
	 * @throws ApplicationException
	 */
	public List<UserPrivillageDto> checkForPrivelege( HttpServletRequest request) throws ApplicationException {
		HttpHeaders headers = restTemplateService.configureRestTemplate(request);
		HttpEntity<String> staticEntity = new HttpEntity<>(headers);
		String url = commonServiceUri + ApplicationConstants.DATA_LAKE_USER_INFO;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url); 
		ResponseEntity<List<UserPrivillageDto>> entity = restTemplate.exchange(builder.toUriString(), HttpMethod.POST,
				staticEntity, new ParameterizedTypeReference<List<UserPrivillageDto>>() {
				});
		return entity.getBody();
	}
	
	/**
	 * Gets the user privivlege dto.
	 *
	 * @param request the request
	 * @return the user privivlege dto
	 */
	public List<AccessMappingPrivilegeDto> getUserPrivivlegeDto(HttpServletRequest request){
		HttpHeaders headers = restTemplateService.configureRestTemplate(request);
		HttpEntity<String> updateStatusEntity = new HttpEntity<>(headers);
		Map<String, Integer> params = new HashMap<>();
		params.put("pageId", 43);
		String url2 = commonServiceUri + ApplicationConstants.DATA_LAKE_PRIVILIGE_INFO;
		UriComponentsBuilder builder2 = UriComponentsBuilder.fromHttpUrl(url2);
		for (Map.Entry<String, Integer> entry : params.entrySet()) {
			builder2.queryParam(entry.getKey(), entry.getValue());
		}
		ResponseEntity<List<AccessMappingPrivilegeDto>> accessMappingPrivilegeDto = restTemplate.exchange(
				builder2.toUriString(), HttpMethod.GET, updateStatusEntity, new ParameterizedTypeReference<List<AccessMappingPrivilegeDto>>(){
				});
		return accessMappingPrivilegeDto.getBody();
	}
	
	/**
	 * Trigger scheduler.
	 *
	 * @param schedulerRequestDto the scheduler request dto
	 * @throws ApplicationException the application exception
	 */
	public void triggerScheduler(SchedulerRequestDto schedulerRequestDto) throws ApplicationException {
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.setAccept(List.of(MediaType.APPLICATION_JSON));
			String url = environmentProperties.getNotificationSchedulerTriggerUrl();
			if(ApplicationUtils.isNotBlank(url)) {
				HttpEntity<SchedulerRequestDto> httpentity = new HttpEntity<SchedulerRequestDto>(schedulerRequestDto, headers);
				ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, httpentity, String.class);
				logger.debug("Response from Scheduler service ===> {}", response);
			} else {
				logger.info("Scheduler service url is not configured!!!");
			}
		} catch (Exception e) {
			throw new ApplicationException(ErrorCodes.INVALID_SCHEDULE);
		}
		
	}
	
	/**
	 * @param associationId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<CompanyDetailsDto> getCompanyNameList(Integer associationId) {
		List<CompanyDetailsDto> companyNameList = new ArrayList<>();

		if (ApplicationUtils.isValidId(associationId)) {
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(List.of(MediaType.APPLICATION_JSON));
			HttpEntity<?> httpEntity = new HttpEntity<>(headers);

			String uri = environmentProperties.getCommonServicePath() + ApplicationConstants.COMPANY_NAME_LIST_URL ;
			String urlTemplate = UriComponentsBuilder.fromHttpUrl(uri)
					.queryParam(ApplicationConstants.ASSOCIATION_ID, associationId).toUriString();

			ResponseEntity<List<CompanyDetailsDto>> response = restTemplate.exchange(urlTemplate, HttpMethod.GET,
					httpEntity, new ParameterizedTypeReference<List<CompanyDetailsDto>>() {
					});

			companyNameList = response.getBody();
		}

		return companyNameList;
	}
	
	/**
	 * @param httpServletRequest
	 * @param userIds
	 * @return
	 */
	public List<UserDetailsDto> getUserNameByUserIdRestTemplate(HttpServletRequest httpServletRequest,
			List<Integer> userIds) {
		HttpHeaders httpHeaders = restTemplateUtils.configureRestTemplate(httpServletRequest);
		HttpEntity<List<Integer>> listOfUserIds = new HttpEntity<List<Integer>>(userIds, httpHeaders);
		String url = ApplicationConstants.DP_USER_DETAILS;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
        return restTemplate.exchange(builder.toUriString(), HttpMethod.POST, listOfUserIds,
				new ParameterizedTypeReference<List<UserDetailsDto>>() {
				}).getBody();
	}
	
	/**
	 * Updatebulk upload status.
	 *
	 * @param request the request
	 * @param userId the user id
	 * @param companyName the company name
	 * @param repositoryId the repository id
	 * @throws ApplicationException the application exception
	 */
	public void updatebulkUploadStatus( HttpServletRequest request,Integer userId,String companyName,Integer repositoryId) throws ApplicationException {
		HttpEntity<String> uploadStatus = new HttpEntity<>(restTemplateUtils.getPOSTHeaders());
		String url = environmentProperties.getNotificationStatus();
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url); 
		builder.queryParam(ApplicationConstants.USER_ID, userId);
		builder.queryParam(ApplicationConstants.COMPANY_NAMES, companyName);
		builder.queryParam(ApplicationConstants.REPOSITORY_ID, repositoryId);
		restTemplate.exchange(builder.toUriString(), HttpMethod.POST, uploadStatus, Void.class);
	}

	/**
	 * Gets the image name.
	 *
	 * @param userIdList the user id list
	 * @param httpServletRequest the http servlet request
	 * @return the image name
	 */
	@SuppressWarnings("unchecked")
	public Map<Integer, String> getImageName(List<Integer> userIdList,HttpServletRequest httpServletRequest) {	
		
		HttpHeaders httpHeaders = restTemplateUtils.configureRestTemplate(httpServletRequest);
		HttpEntity<List<Integer>> user_id = new HttpEntity<List<Integer>>(userIdList, httpHeaders);
		String url = commonServiceUri + ApplicationConstants.GET_IMAGE;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		return restTemplate.exchange(builder.toUriString(), HttpMethod.POST, user_id,
				new ParameterizedTypeReference<Map<Integer, String>>() {
				}).getBody();
	}


	

}
