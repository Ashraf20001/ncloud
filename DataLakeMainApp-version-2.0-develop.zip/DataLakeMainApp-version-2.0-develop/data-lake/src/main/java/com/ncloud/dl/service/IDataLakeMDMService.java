package com.ncloud.dl.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ncloud.dl.exception.core.ApplicationException;

/**
 * The Interface IDataLakeMDMService.
 */
public interface IDataLakeMDMService {

	/**
	 * Export master datas.
	 *
	 * @param tableEntityMap the table entity map
	 * @return the list
	 * @throws JsonProcessingException the json processing exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public List<Map<String, Object>> exportMasterDatas(List<String> tableEntityMap) throws JsonProcessingException, IOException;

	/**
	 * Import master data.
	 *
	 * @param recoveryMasterDataMap the recovery master data map
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws ApplicationException the application exception
	 */
	void importMasterData(Map<String, Object> recoveryMasterDataMap) throws IOException, ApplicationException;

}
