package com.ncloud.dl.dao.impl.repositoryscheduledetails;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.ncloud.dl.config.common.base.dao.BaseDao;
import com.ncloud.dl.constants.core.TableConstants;
import com.ncloud.dl.dao.repositoryscheduledetails.IRepositoryScheduleDetailsDao;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.entity.RepositoryScheduleDetails;

/**
 * The Class RepositoryScheduleDetailsDaoImpl.
 */
@Repository
public class RepositoryScheduleDetailsDaoImpl extends BaseDao implements IRepositoryScheduleDetailsDao {

	/**
	 * @param {@link String}
	 * @return {@link RepositoryScheduleDetails}
	 */
	@Override
	public RepositoryScheduleDetails getRepositoryScheduleDetailsByIdentity(String identity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<RepositoryScheduleDetails> criteria = builder.createQuery(RepositoryScheduleDetails.class);
		Root<RepositoryScheduleDetails> root = criteria.from(RepositoryScheduleDetails.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLTSTS), false)));
		predicates.add(builder.and(builder
				.equal(root.get("schedulerNotificationId").get(TableConstants.IDENTITY), identity)));
		return (RepositoryScheduleDetails) getSingleResult(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
	}

	/**
	 * Save repository schedule details.
	 * @param repositoryScheduleDetails
	 * @throws ApplicationException 
	 */
	@Override
	public RepositoryScheduleDetails saveRepositoryScheduleDetails(RepositoryScheduleDetails repositoryScheduleDetails) throws ApplicationException {
		save(repositoryScheduleDetails ,TableConstants.REPOSITORY_SCHEDULE_DETAILS);
		return repositoryScheduleDetails;
	}

}
