package com.ncloud.dl.dao.upload.storage;

import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.entity.FileStorage;

/**
 * The Interface IFileStorageDao.
 */
public interface IFileStorageDao {
	
	/**
	 * @param fileStorage
	 * @return
	 * @throws ApplicationException
	 */
	FileStorage saveFileStorageForRepository(FileStorage fileStorage) throws ApplicationException;

}
