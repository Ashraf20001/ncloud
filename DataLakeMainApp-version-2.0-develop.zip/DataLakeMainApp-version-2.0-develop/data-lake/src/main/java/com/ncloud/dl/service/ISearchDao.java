package com.ncloud.dl.service;

import java.util.HashMap;
import java.util.List;

import com.ncloud.dl.transfer.object.dto.RepositoryDto;
import com.ncloud.dl.transfer.object.entity.DataRepository;

/**
 * The Interface ISearchDao.
 */
public interface ISearchDao {

	/**
	 * @param repositoryId
	 * @return
	 */
	List<DataRepository> getRepositoryDetails(List<Integer> repositoryId);

	/**
	 * @param index
	 * @return
	 */
	List<RepositoryDto> getRepositoryNameByIndexName(String index);

	/**
	 * @param string
	 * @return
	 */
	List<HashMap<String, Object>> getDataUsingUniqueId(String query);

	/**
	 * @param query
	 * @return
	 */
	HashMap<String, Object> getSqlDataWithIdentity(String query);

}
