package com.ncloud.dl.dao.impl.schedulernotification;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.ncloud.dl.config.common.base.dao.BaseDao;
import com.ncloud.dl.constants.core.TableConstants;
import com.ncloud.dl.dao.schedulernotification.ISchedulerNotificationDao;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.entity.SchedulerNotification;

/**
 * The Class SchedulerNotificationDaoImpl.
 */
@Repository
public class SchedulerNotificationDaoImpl extends BaseDao implements ISchedulerNotificationDao {

	/**
	 * Save scheduler notification.
	 *
	 * @param schedulerNotification the scheduler notification
	 * @return the scheduler notification
	 * @throws ApplicationException the application exception
	 */
	@Override
	public SchedulerNotification saveSchedulerNotification(SchedulerNotification schedulerNotification) throws ApplicationException {
		save(schedulerNotification, TableConstants.SCHEDULER_NOTIFICATION);
		return schedulerNotification;
	}
	
	/**
	 * @param schedulerNotification
	 */
	@Override
	public void saveUpdateSchedulerNotification(SchedulerNotification schedulerNotification) {
		update(schedulerNotification);
	}
	
	
	/**
	 * Gets the scheduler notification by repository identity.
	 *
	 * @param repositoryIdentity the repository identity
	 * @return the scheduler notification by repository identity
	 */
	@Override
	public SchedulerNotification getSchedulerNotificationByRepositoryIdentity(String repositoryIdentity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<SchedulerNotification> criteria = builder.createQuery(SchedulerNotification.class);
		Root<SchedulerNotification> root = criteria.from(SchedulerNotification.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLTSTS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.REPO_ID).get(TableConstants.IDENTITY), repositoryIdentity)));
		return (SchedulerNotification)getSingleResult(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
	}

	/**
	 * Get Scheduler Notification by repository identity.
	 * @param schedulerIdentity
	 * @return
	 */
	@Override
	public SchedulerNotification getSchedulerNotificationbyRepositoryIdentityDetails(String schedulerIdentity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<SchedulerNotification> criteria = builder.createQuery(SchedulerNotification.class);
		Root<SchedulerNotification> root = criteria.from(SchedulerNotification.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLTSTS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.REPOSITORY_ID).get(TableConstants.IDENTITY), schedulerIdentity)));
		return (SchedulerNotification)getSingleResult(createQuery(builder, criteria, root, predicates));
	}

}
