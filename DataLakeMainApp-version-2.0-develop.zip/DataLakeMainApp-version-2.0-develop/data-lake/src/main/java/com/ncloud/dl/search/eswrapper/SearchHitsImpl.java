package com.ncloud.dl.search.eswrapper;

import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;

/**
 * The Class SearchHitsImpl.
 */
public class SearchHitsImpl implements ISearchHits {
	
	/** The search hits. */
	private final SearchHits searchHits;

	/**
	 * Instantiates a new search hits impl.
	 *
	 * @param searchHits the search hits
	 */
	public SearchHitsImpl(SearchHits searchHits) {
		this.searchHits=searchHits;
	}

	/**
	 * Gets the hits.
	 *
	 * @return the hits
	 */
	@Override
	public ISearchHit[] getHits() {
		SearchHit[] hits = searchHits.getHits();

		ISearchHit[] hitsArray = new ISearchHit[hits.length];

		for (int i = 0; i < hitsArray.length; i++) {

			hitsArray[i] = new SearchHitImpl(hits[i]);
		}

		return hitsArray;

	}

}
