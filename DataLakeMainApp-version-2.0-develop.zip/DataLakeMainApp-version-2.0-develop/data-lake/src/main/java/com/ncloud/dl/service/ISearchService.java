package com.ncloud.dl.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import com.lowagie.text.DocumentException;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.dto.CustomFilterSortingVo;
import com.ncloud.dl.transfer.object.dto.DataRepositoryDto;
import com.ncloud.dl.transfer.object.dto.FieldMapperDto;
import com.ncloud.dl.transfer.object.dto.FieldsConfiguratorDto;
import com.ncloud.dl.transfer.object.dto.SearchResponseDto;

/**
 * The Interface ISearchService.
 */
public interface ISearchService {

	/**
	 * @param repositoryIdentity
	 * @return 
	 */
	List<FieldsConfiguratorDto> getadvanceFilterForRepository(String repositoryIdentity);
	
	/**
	 * @param repositoryId
	 * @return
	 */
	List<DataRepositoryDto> getApprovedRepositoryName(List<Integer> repositoryId);

	/**
	 * @param customSortingVo
	 * @param identity
	 * @param limit 
	 * @param skip 
	 * @param isCount 
	 * @return
	 * @throws ApplicationException 
	 */
	List<FieldMapperDto> getRepositoryFiedsForTableHeader(String repositoryName) throws ApplicationException;

	
	
	
	/**
	 * @param id
	 * @param email
	 * @param repositoryname 
	 * @param repositoryName
	 * @return
	 * @throws DocumentException
	 * @throws IOException
	 * @throws ApplicationException
	 */
	String sendMail( String identity,String email, String repositoryname) throws DocumentException, IOException, ApplicationException;

	/**
	 * @param filterValue
	 * @param repoIdentity
	 * @param limit 
	 * @param skip 
	 * @param filterVo 
	 * @param isrepositorySearch 
	 * @return 
	 * @throws IOException 
	 */
	SearchResponseDto commonSearch(String filterValue, String repoIdentity, Long skip, Long limit, Integer searchType, CustomFilterSortingVo filterVo, Boolean isrepositorySearch) throws IOException;

	/**
	 * @param searchQuery
	 * @param limit 
	 * @param skip 
	 * @param repository 
	 * @return 
	 * @throws ApplicationException 
	 */
	List<SearchResponseDto> globalSearch(String searchQuery, Long skip, Long limit, String repository, Boolean isglobal) throws ApplicationException;

	/**
	 * @param repository
	 * @param query
	 * @param filterVo 
	 * @param searchType 
	 * @return
	 * @throws IOException
	 * @throws ApplicationException 
	 */
	Long getTotalRecordsCount(String repository, String query, Integer searchType, CustomFilterSortingVo filterVo) throws IOException, ApplicationException;

	/**
	 * @param uniqueIdList
	 * @param repository 
	 * @return
	 */
	List<HashMap<String, Object>> getRecordsByUniqueId(List<String> uniqueIdList, String repository);

}
