package com.ncloud.dl;

import com.ncloud.dl.utils.core.LoggedInUserContextHolder;
import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import com.ncloud.dl.config.CustomAuditorAware;

@ComponentScan("com.ncloud.dl")
@EntityScan("com.ncloud.dl")
@EnableJpaAuditing(auditorAwareRef = "auditorAware")
@SpringBootApplication
public class DataLakeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataLakeApplication.class, args);
	}
	
	@Bean
	public ModelMapper modelMapper() {
		return new ModelMapper();
	}
	
	/**
	 * @return {@link CustomAuditorAware}
	 */
	@Bean
    public AuditorAware<Integer> auditorAware(LoggedInUserContextHolder loggedInUserContextHolder) {
        return new CustomAuditorAware(loggedInUserContextHolder);
    }
	
}
