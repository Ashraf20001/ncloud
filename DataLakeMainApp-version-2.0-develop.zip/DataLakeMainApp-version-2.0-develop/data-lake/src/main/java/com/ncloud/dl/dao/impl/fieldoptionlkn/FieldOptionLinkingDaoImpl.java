package com.ncloud.dl.dao.impl.fieldoptionlkn;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.ncloud.dl.config.common.base.dao.BaseDao;
import com.ncloud.dl.constants.core.TableConstants;
import com.ncloud.dl.dao.fieldoptionlkn.IFieldOptionLinkingDao;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.entity.FieldOptionLink;

// TODO: Auto-generated Javadoc
/**
 * The Class FieldOptionLinkingDaoImpl.
 */
@Repository
public class FieldOptionLinkingDaoImpl extends BaseDao implements IFieldOptionLinkingDao{

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
		
	}

	/**
	 * Save field option lnk.
	 *
	 * @param fieldOptionLink the field option link
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void saveFieldOptionLnk(FieldOptionLink fieldOptionLink) throws ApplicationException {
		save(fieldOptionLink, TableConstants.FIELD_OPTION_LINK); 
	}
	
	/**
	 * Gets the field option list.
	 *
	 * @param fieldId the field id
	 * @return the field option list
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<FieldOptionLink> getFieldOptionList(String fieldId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<FieldOptionLink> createQuery = builder.createQuery(FieldOptionLink.class);
		Root<FieldOptionLink> root = createQuery.from(FieldOptionLink.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETE_STS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.FIELD_ID).get(TableConstants.IDENTITY),fieldId)));
		return (List<FieldOptionLink>) getResultList(createQuery(builder, createQuery, root, predicates));
	
	}
	
	/**
	 * Gets the field option names.
	 *
	 * @param fieldId the field id
	 * @return the field option names
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<String> getFieldOptionNames(String fieldId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<FieldOptionLink> createQuery = builder.createQuery(FieldOptionLink.class);
		Root<FieldOptionLink> root = createQuery.from(FieldOptionLink.class);
		createQuery.select(root.get(TableConstants.DROP_OPTION_NAME));
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETE_STS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.FIELD_ID).get(TableConstants.IDENTITY),fieldId)));
		return (List<String>) getResultList(createQuery(builder, createQuery, root, predicates));
	
	}
	
	
	/**
	 * Gets the field option linking.
	 *
	 * @param fieldIdentity the field identity
	 * @return the field option linking
	 */
	public FieldOptionLink getFieldOptionLinking(String fieldIdentity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<FieldOptionLink> createQuery = builder.createQuery(FieldOptionLink.class);
		Root<FieldOptionLink> root = createQuery.from(FieldOptionLink.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETE_STS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IDENTITY),fieldIdentity)));
		return (FieldOptionLink) getSingleResult(createQuery(builder, createQuery, root, predicates));
	
	}

	/**
	 * Update field option lnk.
	 *
	 * @param fieldOption the field option
	 */
	@Override
	public void updateFieldOptionLnk(FieldOptionLink fieldOption) {
		update(fieldOption);
		
	}

}
