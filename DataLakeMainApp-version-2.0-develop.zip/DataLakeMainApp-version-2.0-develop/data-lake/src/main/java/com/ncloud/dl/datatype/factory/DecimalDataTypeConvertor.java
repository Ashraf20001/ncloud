package com.ncloud.dl.datatype.factory;

import java.util.HashMap;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.ncloud.dl.transfer.object.entity.FieldConfiguration;

/**
 * The Class DecimalDataTypeConvertor.
 */
@Service
@Qualifier("decimalConvert")
public class DecimalDataTypeConvertor implements IDataTypeConversionFactory{

	/**
	 * Builds the bulk record map.
	 *
	 * @param valMap the val map
	 * @param fieldConfiguration the field configuration
	 * @param entry the entry
	 */
	@Override
	public void buildBulkRecordMap(HashMap<String, Object> valMap, FieldConfiguration fieldConfiguration,
			Entry<String, Object> entry) {
		
	}

}
