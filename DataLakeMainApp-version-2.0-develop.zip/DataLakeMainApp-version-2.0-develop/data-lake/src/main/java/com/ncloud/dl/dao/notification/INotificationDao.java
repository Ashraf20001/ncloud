package com.ncloud.dl.dao.notification;

import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.entity.NotificationEvent;
import com.ncloud.dl.transfer.object.entity.NotificationTemplate;
import com.ncloud.dl.transfer.object.entity.RepositoryNotification;

/**
 * The Interface INotificationDao.
 */
public interface INotificationDao {

	/**
	 * @param stockPurchase
	 * @return
	 */
	NotificationEvent getNotificationevent(String stockPurchase);

	/**
	 * @param notificationEventData
	 * @param integer 
	 * @return
	 */
	NotificationTemplate getNotificationTemplate(NotificationEvent notificationEventData, String action);

	/**
	 * @param notification
	 * @throws ApplicationException 
	 */
	void saveNotificationDetails(RepositoryNotification notification) throws ApplicationException;

}
