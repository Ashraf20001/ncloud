package com.ncloud.dl.config;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;


/**
 * The Class KafkaConfig.
 */
@Configuration
public class KafkaConfig {
	
	/** Server URI. */
	@Value("${dlmainapp.elastic-syncup-kafka}")
	private String syncUpKafka;

	/** Partitions. */
	@Value("${dlmainapp.spring-kafka-partitions}")
	private String partitions;

	/** Replication Factor. */
	@Value("${dlmainapp.spring-kafka-replication-factor}")
	private String replicationFactor;
	
	/** Serialize. */
	@Value("${spring.kafka.producer.key-serializer}")
	private String serializer;

	/** Converter. */
	@Value("${dlmainapp.spring-kafka-converter}")
	private String converter;

	/**
	 * Kafka template.
	 *
	 * @return the kafka template
	 */
	@Bean
    public KafkaTemplate<String, String> kafkaTemplate() {
        return new KafkaTemplate<String, String>(producerFactory());
    }
	
	/**
	 * Producer factory.
	 *
	 * @return the producer factory
	 */
	@Bean
	public ProducerFactory<String, String> producerFactory() {
		Map<String,Object> properties = new HashMap<String, Object>();
		properties.put("bootstrap.servers", syncUpKafka);
		properties.put("key.serializer", serializer);
		properties.put("value.serializer", serializer);
		properties.put(ProducerConfig.ACKS_CONFIG, "1");
		properties.put(ProducerConfig.BATCH_SIZE_CONFIG, 300000); // Set the batch size here
		properties.put(ProducerConfig.LINGER_MS_CONFIG, 5000);
		return new DefaultKafkaProducerFactory<>(properties);
	}
	
}
