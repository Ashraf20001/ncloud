package com.ncloud.dl.search.eswrapper;

import java.util.Map;

import org.elasticsearch.search.SearchHit;

/**
 * The Class SearchHitImpl.
 */
public class SearchHitImpl implements ISearchHit {
	
	/** The search hit. */
	private final SearchHit searchHit;

	/**
	 * Instantiates a new search hit impl.
	 *
	 * @param searchHit the search hit
	 */
	public SearchHitImpl(SearchHit searchHit) {
		this.searchHit=searchHit;
	}

	/**
	 * Gets the source as map.
	 *
	 * @return the source as map
	 */
	@Override
	public Map<String, Object> getSourceAsMap() {
		return searchHit.getSourceAsMap();
	}

}
