package com.ncloud.dl.datatype.factory;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ncloud.dl.constants.core.QueryConstants.ColumnConstants;
import com.ncloud.dl.transfer.object.entity.FieldConfiguration;

/**
 * The Class DateTypeConvertor.
 */
@Service
@Qualifier("dateConvert")
public class DateTypeConvertor implements IDataTypeConversionFactory{
	
	/**
	 * dateFormat
	 */
	@Value("${dlmainapp.date-format}")
	private String dateFormat;
	/**
	 * @param valMap
	 * @param fieldConfiguration
	 * @param entry
	 * @throws ParseException 
	 */
	@Override
	public void buildBulkRecordMap(HashMap<String, Object> valMap, FieldConfiguration fieldConfiguration,
			Entry<String, Object> entry) throws ParseException {

		valMap.put(fieldConfiguration.getColumnName(), entry.getValue());
		valMap.put(ColumnConstants.STATUS, Boolean.FALSE);
	}
	
}
