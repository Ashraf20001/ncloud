package com.ncloud.dl.search.eswrapper;

import org.elasticsearch.client.core.CountResponse;

/**
 * The Class CountResponseObject.
 */
public class CountResponseObject {
	
	/** The count response. */
	private final CountResponse countResponse;

	/**
	 * Instantiates a new count response object.
	 *
	 * @param countResponse the count response
	 */
	public CountResponseObject(CountResponse countResponse) {
		this.countResponse = countResponse;
	}
	
	/**
	 * Gets the count.
	 *
	 * @return the count
	 */
	public long getCount() {
		return this.countResponse.getCount();
	}
	
	
}
