package com.ncloud.dl.dao.fieldoptionlkn;

import java.util.List;

import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.entity.FieldOptionLink;

public interface IFieldOptionLinkingDao {

	/**
	 * @param fieldOptionLink
	 * @throws ApplicationException 
	 */
	void saveFieldOptionLnk(FieldOptionLink fieldOptionLink) throws ApplicationException;

	/**
	 * @param fieldId
	 * @return
	 */
	List<FieldOptionLink> getFieldOptionList(String fieldId);

	/**
	 * @param fieldOption
	 */
	void updateFieldOptionLnk(FieldOptionLink fieldOption);

	/**
	 * @param fieldOptionIdentity
	 * @return
	 */
	FieldOptionLink getFieldOptionLinking(String fieldOptionIdentity);

	/**
	 * @param fieldId
	 * @return
	 */
	List<String> getFieldOptionNames(String fieldId);

}
