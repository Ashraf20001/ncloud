package com.ncloud.dl.search.eswrapper;

import java.io.IOException;

import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.core.CountRequest;
import org.elasticsearch.client.core.CountResponse;


/**
 * The Class ElasticSearchClient.
 */
public class ElasticSearchClient implements IElasticSearchOperation{

	
	/** The rest high level client. */
	private final RestHighLevelClient restHighLevelClient;
	
	/** The indices client impl. */
	private final IIndicesClient indicesClientImpl;

	/** The search response object. */
	private final SearchResponseObject searchResponseObject;

	/**
	 * Instantiates a new elastic search client.
	 *
	 * @param restHighLevelClient the rest high level client
	 * @param searchResponseObject the search response object
	 * @param indicesClientImpl the indices client impl
	 */
	public ElasticSearchClient(RestHighLevelClient restHighLevelClient,
			SearchResponseObject searchResponseObject,
			IIndicesClient indicesClientImpl) {
		super();
		this.restHighLevelClient = restHighLevelClient;
		this.searchResponseObject = searchResponseObject;
		this.indicesClientImpl=indicesClientImpl;
	}

	/**
	 * Search.
	 *
	 * @param searchRequest the search request
	 * @param options the options
	 * @return the i search response
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	public ISearchResponse search(SearchRequest searchRequest, RequestOptions options) throws IOException {
		return searchResponseObject.search(searchRequest, options) ;
	}

	/**
	 * Indices.
	 *
	 * @return the i indices client
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	public IIndicesClient indices() throws IOException {
		return indicesClientImpl;
	}

	/**
	 * Count.
	 *
	 * @param countRequest the count request
	 * @param options the options
	 * @return the count response object
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	public CountResponseObject count(CountRequest countRequest, RequestOptions options) throws IOException {
		CountResponse count = restHighLevelClient.count(countRequest, options);
		return new CountResponseObject(count);
	}


}
