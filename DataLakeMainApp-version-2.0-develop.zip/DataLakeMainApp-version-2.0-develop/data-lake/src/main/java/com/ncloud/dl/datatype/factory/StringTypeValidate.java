package com.ncloud.dl.datatype.factory;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.ncloud.dl.constants.core.ApplicationConstants;
import com.ncloud.dl.constants.core.QueryConstants.ColumnConstants;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.exception.core.codes.ErrorCodes;
import com.ncloud.dl.transfer.object.entity.FieldConfiguration;
import com.ncloud.dl.utils.core.ApplicationUtils;

/**
 * The Class StringTypeValidate.
 */
@Service
@Qualifier("stringValidator")
@Primary
public class StringTypeValidate implements IBulkUploadValidationBuilder{

	/**
	 * Gets the data type validation builder.
	 *
	 * @param successRecord the success record
	 * @param fieldConfiguration the field configuration
	 * @param entry the entry
	 * @param mandatory the mandatory
	 * @param userId the user id
	 * @return the data type validation builder
	 * @throws ApplicationException the application exception
	 * @throws ParseException the parse exception
	 */
	@Override
	public Boolean getDataTypeValidationBuilder(HashMap<String, Object> successRecord, FieldConfiguration fieldConfiguration, Entry<String, Object> entry,
			Boolean mandatory, Integer userId) throws ApplicationException, ParseException {
		successRecord.put(fieldConfiguration.getColumnName(), entry.getValue());
		successRecord.put(ColumnConstants.STATUS, Boolean.FALSE);
		if (Boolean.TRUE.equals(mandatory)) {
			if (!ApplicationUtils.isValidateObject(entry.getValue().toString())
					|| ApplicationUtils.isBlank(entry.getValue().toString())) {
				String errorMessage = fieldConfiguration.getErrMsg();
				String errorMsg = ApplicationUtils.isValidateObject(errorMessage)
						&& ApplicationUtils.isNotBlank(errorMessage) ? errorMessage
								: ErrorCodes.MANDATORY_FIELD.getErrorMessage();
				successRecord.put(ApplicationConstants.ERROR_MSG, errorMsg + ApplicationConstants.EMPTY_STRING+ fieldConfiguration.getFieldName());
				return Boolean.TRUE;
			}
			return Boolean.FALSE;
		}
		return Boolean.FALSE;
	}

}
