package com.ncloud.dl.datatype.factory;

import java.util.HashMap;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.ncloud.dl.constants.core.QueryConstants.ColumnConstants;
import com.ncloud.dl.transfer.object.entity.FieldConfiguration;

/**
 * The Class BooleanDataTypeConvertor.
 */
@Service
@Qualifier("booleanConvert")
public class BooleanDataTypeConvertor implements IDataTypeConversionFactory{

	/**
	 * @param valMap
	 * @param fieldConfiguration
	 * @param entry
	 */
	@Override
	public void buildBulkRecordMap(HashMap<String, Object> valMap, FieldConfiguration fieldConfiguration,
			Entry<String, Object> entry) {
		Boolean valInt = Boolean.parseBoolean(entry.getValue().toString());
		valMap.put(fieldConfiguration.getColumnName(), valInt);
		valMap.put(ColumnConstants.STATUS, Boolean.FALSE);
	}

}
