package com.ncloud.dl.datatype.factory;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.ncloud.dl.constants.core.ApplicationConstants;
import com.ncloud.dl.utils.core.ApplicationUtils;

/**
 * The Class StringFactoryBuilder.
 */
@Service
@Qualifier("stringBuilder")
@Primary
public class StringFactoryBuilder implements IDataTypeFactoryBuilder{

	/**
	 * @param createQuery
	 * @return
	 */
	@Override
	public String getDataTypeWithColQuery(String fieldColName, String fldQuery) {
		return ApplicationUtils.isValidString(fldQuery) ? fldQuery + ApplicationConstants.DOUBLE_QUOTES+fieldColName+ApplicationConstants.DOUBLE_QUOTES + ApplicationConstants.VARCHAR 
				: ApplicationConstants.DOUBLE_QUOTES+fieldColName+ApplicationConstants.DOUBLE_QUOTES + ApplicationConstants.VARCHAR;
	}

}
