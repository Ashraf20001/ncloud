package com.ncloud.dl.service.impl.repository.upload;


import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.SQLDataException;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.apache.poi.ss.usermodel.BuiltinFormats;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataValidation;
import org.apache.poi.ss.usermodel.DataValidationConstraint;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddressList;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFDataValidationHelper;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.elasticsearch.action.admin.indices.settings.put.UpdateSettingsRequest;
import org.elasticsearch.action.support.master.AcknowledgedResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.indices.GetIndexRequest;
import org.elasticsearch.common.settings.Settings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ncloud.dl.config.property.EnvironmentProperties;
import com.ncloud.dl.constants.core.ApplicationConstants;
import com.ncloud.dl.constants.core.QueryConstants;
import com.ncloud.dl.constants.core.QueryConstants.ColumnConstants;
import com.ncloud.dl.constants.enums.UploadAccessEnum;
import com.ncloud.dl.dao.datarespository.IDataRepositoryDao;
import com.ncloud.dl.dao.errormaintenance.IErrorMaintenanceDao;
import com.ncloud.dl.dao.fieldconfiguration.IFieldConfigurationDao;
import com.ncloud.dl.dao.fieldoptionlkn.IFieldOptionLinkingDao;
import com.ncloud.dl.dao.repository.IRepositoryDao;
import com.ncloud.dl.dao.upload.IBulkUploadDao;
import com.ncloud.dl.dao.upload.storage.IFileStorageDao;
import com.ncloud.dl.datatype.factory.DataTypeFactory;
import com.ncloud.dl.datatype.factory.IBulkUploadValidationBuilder;
import com.ncloud.dl.datatype.factory.IDataTypeFactoryValidationBuilder;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.exception.core.codes.ErrorCodes;
import com.ncloud.dl.search.eswrapper.IElasticSearchOperation;
import com.ncloud.dl.service.IBulkUploadService;
import com.ncloud.dl.transfer.object.BulkImportTriggerConsumerDto;
import com.ncloud.dl.transfer.object.dto.BulkImportHistoryDto;
import com.ncloud.dl.transfer.object.dto.BulkUploadHistoryDto;
import com.ncloud.dl.transfer.object.dto.BulkUploadMapDto;
import com.ncloud.dl.transfer.object.dto.CustomSortingVo;
import com.ncloud.dl.transfer.object.dto.DataLakeBulkUploadDto;
import com.ncloud.dl.transfer.object.dto.DataLakeBulkUploadMapDto;
import com.ncloud.dl.transfer.object.dto.FieldMapperDto;
import com.ncloud.dl.transfer.object.dto.SuccessErrorRecordsDto;
import com.ncloud.dl.transfer.object.dto.UserInfo;
import com.ncloud.dl.transfer.object.entity.BulkUploadHistory;
import com.ncloud.dl.transfer.object.entity.DataRepository;
import com.ncloud.dl.transfer.object.entity.ErrorMaintenance;
import com.ncloud.dl.transfer.object.entity.FieldConfiguration;
import com.ncloud.dl.transfer.object.entity.FieldOptionLink;
import com.ncloud.dl.transfer.object.entity.FileStorage;
import com.ncloud.dl.transfer.object.enums.BulkUploadStatusEnum;
import com.ncloud.dl.transfer.object.enums.FieldDataTypeEnum;
import com.ncloud.dl.transfer.object.enums.FieldSearchTypeEnum;
import com.ncloud.dl.transfer.object.enums.FieldTypeEnum;
import com.ncloud.dl.utils.ElasticSearchUtils;
import com.ncloud.dl.utils.core.ApplicationUtils;

import lombok.RequiredArgsConstructor;

/**
 * The Class BulkUploadServiceImpl.
 */
@Service
@Transactional(rollbackOn = Exception.class)
@RequiredArgsConstructor
public class BulkUploadServiceImpl implements IBulkUploadService {

	/**
	 * fieldOptionLinkingDao
	 */
	private final IFieldOptionLinkingDao fieldOptionLinkingDao;

	/**
	 * iErrorMaintenanceDao
	 */
	private final IErrorMaintenanceDao iErrorMaintenanceDao;

	/**
	 * IDataTypeFactoryValidationBuilder
	 */
	private IDataTypeFactoryValidationBuilder iDataTypeFactoryValidationBuilder;

	/**
	 * IDataTypeFactoryBuilder
	 */
	private IBulkUploadValidationBuilder iBulkUploadValidationBuilder;

	/**
	 * DataTypeFactory
	 */
	private final DataTypeFactory dataTypeFactory;

	/**
	 * fieldConfigurationDao
	 */
	private final IFieldConfigurationDao fieldConfigurationDao;

	/**
	 * IBulkUploadDao
	 */
	private final IBulkUploadDao iBulkUploadDao;

	/**
	 * The Constant logger.
	 */
	private static final Logger logger = LoggerFactory.getLogger(BulkUploadServiceImpl.class);

	/**
	 * iDataRepositoryDao
	 */
	private final IDataRepositoryDao iDataRepositoryDao;

	/**
	 * iFileStorageDao
	 */
	private final IFileStorageDao iFileStorageDao;

	/**
	 * ElasticSearchUtils
	 */
	private final ElasticSearchUtils elasticSearchUtils;

	/** The kafka template. */
	private final KafkaTemplate<String, String> kafkaTemplate;

	/** The environment properties. */
	private final EnvironmentProperties environmentProperties;
	/**
	 * Resource directory path
	 */
	private Path dirFile;

	/**
	 * iRepositoryDao
	 */
	private final IRepositoryDao iRepositoryDao;
	
	/**
	 * IElasticSearchOperation
	 */
	private final IElasticSearchOperation elasticSearchOperation;

	/**
	 * uploadedFileName
	 */
	private String uploadedFileName;

	
	/**
	 * Bulk upload file for repository.
	 *
	 * @param repositoryIdentity the repository identity
	 * @param file the file
	 * @param userInfo the user info
	 * @param httpServletRequest the http servlet request
	 * @return the string
	 * @throws IllegalStateException the illegal state exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws ApplicationException the application exception
	 */
	@Override
	public String bulkUploadFileForRepository(String repositoryIdentity, MultipartFile file, UserInfo userInfo,
			HttpServletRequest httpServletRequest) throws IllegalStateException, IOException, ApplicationException {
		if (Boolean.FALSE.equals(ApplicationUtils.isValidateObject(userInfo))) {
			throw new ApplicationException(ErrorCodes.INVALID_USER);
		}
		DataRepository dataRepository = iRepositoryDao.getRepositoryDetails(repositoryIdentity);
		if (Boolean.FALSE.equals(ApplicationUtils.isValidateObject(dataRepository))) {
			throw new ApplicationException(ErrorCodes.INVALID_REPOSITORY);
		}
		Integer accessId = UploadAccessEnum.getUploadAccessEnumById(dataRepository.getUploadAccess()).getUserTypeId();
		if (Boolean.FALSE.equals(accessId.equals(userInfo.getUserTypeId().getUserTypeId())
				|| dataRepository.getUploadAccess().equals(UploadAccessEnum.BOTH.getUserTypeId()))) {
			throw new ApplicationException(ErrorCodes.INVALID_UPLOAD_ACCESS_FOR);
		}
		String fileCode = processFile(file);
		XSSFWorkbook workbook = new XSSFWorkbook(new FileInputStream(environmentProperties.getUploadPath() + fileCode));
		Sheet sheet = ValidateUploadFileFields(repositoryIdentity, workbook);
		if (sheet.getPhysicalNumberOfRows() <= 1) {
			throw new ApplicationException(ErrorCodes.INVALID_EXCEL_DATA);
		}
		workbook.close();
		BulkUploadHistory bulkUploadHistory = new BulkUploadHistory();
		if (ApplicationUtils.isValidateObject(dataRepository)) {
			FileStorage fileStorageSaved = buildFileStorageAndSave(fileCode, userInfo, dataRepository);
			if (ApplicationUtils.isValidObject(fileStorageSaved)) {
				bulkUploadHistory = buildBulkUploadHistoryAndSave(userInfo, fileStorageSaved, dataRepository);
			}
		}
		dropBulkUploadDetails(userInfo, dataRepository, fileCode, bulkUploadHistory);
		return bulkUploadHistory.getIdentity();
	}

	
	/**
	 * Validate upload file fields.
	 *
	 * @param repositoryIdentity the repository identity
	 * @param workbook the workbook
	 * @return the sheet
	 * @throws ApplicationException the application exception
	 */
	private Sheet ValidateUploadFileFields(String repositoryIdentity, XSSFWorkbook workbook)
			throws ApplicationException {
		Sheet sheet = workbook.getSheetAt(ApplicationConstants.ZERO);
		List<String> sheetHeader = new ArrayList<>();
		Row row = sheet.getRow(0);
		int totalcellInHeadaer = row.getLastCellNum();
		for (int cellIndex = 0; cellIndex < totalcellInHeadaer; cellIndex++) {
			Cell headerCell = row.getCell(cellIndex);
			sheetHeader.add(headerCell.toString());
		}
		List<String> fieldColumnNames = iDataRepositoryDao.getFieldRepositoryColumnName(repositoryIdentity);
		if (Boolean.FALSE.equals(fieldColumnNames.stream().allMatch(sheetHeader::contains))) {
			throw new ApplicationException(ErrorCodes.INVALID_FILE_FIELDS);
		}
		return sheet;
	}

	/**
	 * Drop bulk upload details.
	 *
	 * @param userInfo the user info
	 * @param dataRepository the data repository
	 * @param fileCode the file code
	 * @param bulkUploadHistory the bulk upload history
	 * @throws ApplicationException the application exception
	 */
	private void dropBulkUploadDetails(UserInfo userInfo, DataRepository dataRepository, String fileCode,
			BulkUploadHistory bulkUploadHistory) throws ApplicationException {
		DataLakeBulkUploadDto dataLakeBulkUploadDto = new DataLakeBulkUploadDto();
		dataLakeBulkUploadDto.setBulkUploadId(bulkUploadHistory.getId());
		dataLakeBulkUploadDto.setFilePath(fileCode);
		dataLakeBulkUploadDto.setRepositoryName(dataRepository.getRepoApiName());
		dataLakeBulkUploadDto.setUserInfo(userInfo);
		elasticSearchUtils.dropBulkUploadInfo(dataLakeBulkUploadDto);
	}

	
	/**
	 * Process file.
	 *
	 * @param file the file
	 * @return the string
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private String processFile(MultipartFile file) throws IOException {
		Path uploadPath = Paths.get(environmentProperties.getFileUploadPath());
		if (!Files.exists(uploadPath)) {
			Files.createDirectories(uploadPath);
		}
		String fileCode = null;
		fileCode = file.getOriginalFilename();
		try (InputStream inputStream = file.getInputStream()) {
			Path filePath = uploadPath.resolve(fileCode);
			Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
			logger.info("filePath!!!!!!!!!!!!!!!!!!");
		} catch (IOException ioe) {
			throw new IOException("Could not save file: ", ioe);
		}
		return fileCode;
	}

	
	/**
	 * Gets the file name for repository.
	 *
	 * @param bulkUploadId the bulk upload id
	 * @param associationId the association id
	 * @param userId the user id
	 * @return the file name for repository
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	public BulkImportTriggerConsumerDto getFileNameForRepository(Integer bulkUploadId, Integer associationId,
			Integer userId) throws IOException {
		BulkUploadHistory bulkUploadHistory = getBulkUploadHistoryById(bulkUploadId, associationId);
		updateBulkUploadHistoryStatus(userId, bulkUploadHistory, BulkUploadStatusEnum.IN_PROGRESS.getStatusId());
		BulkImportTriggerConsumerDto bulkImportTriggerConsumerDto = new BulkImportTriggerConsumerDto();
		bulkImportTriggerConsumerDto.setFilePath(bulkUploadHistory.getFileStorage().getFileName());
		bulkImportTriggerConsumerDto.setAssociationId(associationId);
		return bulkImportTriggerConsumerDto;
	}

	
	/**
	 * Gets the bulk upload history by id.
	 *
	 * @param bulkUploadId the bulk upload id
	 * @param associationId the association id
	 * @return the bulk upload history by id
	 */
	private BulkUploadHistory getBulkUploadHistoryById(Integer bulkUploadId, Integer associationId) {
		BulkUploadHistory bulkUploadHistory = iBulkUploadDao.getBulkUploadByIdAndAssocicationId(bulkUploadId,
				associationId);
		return bulkUploadHistory;
	}

	
	/**
	 * Update bulk upload history status.
	 *
	 * @param userId the user id
	 * @param bulkUploadHistory the bulk upload history
	 * @param status the status
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private void updateBulkUploadHistoryStatus(Integer userId, BulkUploadHistory bulkUploadHistory, Integer status)
			throws IOException {
		bulkUploadHistory.setUploadStatus(status);
		bulkUploadHistory.setMdyDteTme(LocalDateTime.now());
		bulkUploadHistory.setMdyUsrId(userId);
		iBulkUploadDao.updateBulkUploadHistory(bulkUploadHistory);
		Long totalSuccessCount = iBulkUploadDao
				.getTotalSuccessCountByRepositoryId(bulkUploadHistory.getDataRepository().getId());
		logger.error(ApplicationConstants.DL_ + bulkUploadHistory.getDataRepository().getRepoTableName());
		try {
			if (status.equals(BulkUploadStatusEnum.COMPLETED.getStatusId()) && totalSuccessCount >= ApplicationConstants.INDEX_MAX_RESULT_ADDITION) {  // for upgrading index max result window to added records for pagination purpose, default elasticsearch restrict to max of 10000 records
				GetIndexRequest indexRequest = new GetIndexRequest(
						ApplicationConstants.DL_ + bulkUploadHistory.getDataRepository().getRepoTableName());
				boolean indexResponse = elasticSearchOperation.indices().exists(indexRequest, RequestOptions.DEFAULT);
				if (indexResponse) {
					UpdateSettingsRequest request = new UpdateSettingsRequest(
							ApplicationConstants.DL_ + bulkUploadHistory.getDataRepository().getRepoTableName())
							.settings(Settings.builder().put(ApplicationConstants.INDEX_MAX_RESULT_WINDOW, totalSuccessCount + ApplicationConstants.MAX_PAGINATION)); // 50 for pagination
					AcknowledgedResponse response = elasticSearchOperation.indices().putSettings(request, RequestOptions.DEFAULT);
					if (response.isAcknowledged()) {
						logger.info("Successfully updated index.max_result_window to :: {}", totalSuccessCount);
					} else {
						logger.info("Failed to update index.max_result_window");
					}
				}
			}
		} catch (Exception e) {
			logger.error(e.getLocalizedMessage());
		}
	}


	
	/**
	 * Bulk upload file validate file.
	 *
	 * @param repositoryName the repository name
	 * @param dataLakeBulkUploadDto the data lake bulk upload dto
	 * @param userId the user id
	 * @param bulkUploadId the bulk upload id
	 * @throws ApplicationException the application exception
	 * @throws ParseException the parse exception
	 * @throws JsonProcessingException the json processing exception
	 */
	@Override
	public void bulkUploadFileValidateFile(String repositoryName, DataLakeBulkUploadMapDto dataLakeBulkUploadDto,
			Integer userId, Integer bulkUploadId) throws ApplicationException, ParseException, JsonProcessingException {
		logger.info("100 reocrd>>>>>>>>>>>>>>>>>>>..............." + bulkUploadId);
		List<HashMap<String, Object>> bulkHashMaps = new ArrayList<>();
		BulkUploadMapDto bulkUploadMapDto = new BulkUploadMapDto();
		List<FieldConfiguration> fieldConfiguration = fieldConfigurationDao.getFieldMappedInRepository(repositoryName);
		List<String> globalSearchFields = streamSearchableFields(fieldConfiguration);
		Integer repositoryId = fieldConfiguration.get(0).getRepoId().getId();
		String repositoryTableName = fieldConfiguration.get(0).getRepoId().getRepoTableName();
		for (HashMap<String, Object> singleMap : dataLakeBulkUploadDto.getUniqueRows()) {
			if(!singleMap.isEmpty()) {
				bulkUploadMapDto = singleAddForRepository(repositoryName, singleMap, userId, bulkUploadId, bulkHashMaps,
						fieldConfiguration, globalSearchFields);
				bulkHashMaps.add(bulkUploadMapDto.getListOfKeyValues());
			}
		}

		Object bulkUploadid = bulkHashMaps.stream().map(map -> map.get(ColumnConstants.BULK_UPLOAD_ID)).findFirst()
				.orElse(null);
		if (ApplicationUtils.isValidList(dataLakeBulkUploadDto.getDuplicateRows())) {
			List<String> keyOrder = new ArrayList<>(bulkUploadMapDto.getListOfKeyValues().keySet());
			buildHashMapObjectForExcelDuplicateRecords(dataLakeBulkUploadDto, userId, bulkUploadId, bulkHashMaps,
					repositoryId, keyOrder, bulkUploadid);
		}
		bulkHashMaps.forEach(map -> map.remove(ApplicationConstants.ERROR_FIELD_MAP));
		buildInsertQueryAndUpdateErrorMaintainance(userId, bulkUploadId, bulkHashMaps, bulkUploadMapDto,
				fieldConfiguration, repositoryId, repositoryTableName);
	}

	
	/**
	 * Stream searchable fields.
	 *
	 * @param fieldConfiguration the field configuration
	 * @return the list
	 */
	private List<String> streamSearchableFields(List<FieldConfiguration> fieldConfiguration) {
        return fieldConfiguration.stream()
		        .filter(a -> {
		            Integer searchType = a.getSearchType();
		            return searchType != null &&
		                    (searchType.equals(FieldSearchTypeEnum.GLOBAL_SEARCH.getId()) ||
		                     searchType.equals(FieldSearchTypeEnum.REPOSITORY_SEARCH.getId()) ||
		                     searchType.equals(FieldSearchTypeEnum.BOTH_SEARCH.getId()));
		        })
		        .map(FieldConfiguration::getColumnName)
		        .collect(Collectors.toList());
	}

	
	/**
	 * Builds the insert query and update error maintainance.
	 *
	 * @param userId the user id
	 * @param bulkUploadId the bulk upload id
	 * @param bulkHashMaps the bulk hash maps
	 * @param bulkUploadMapDto the bulk upload map dto
	 * @param fieldConfiguration the field configuration
	 * @param repositoryId the repository id
	 * @param repositoryTableName the repository table name
	 * @throws ApplicationException the application exception
	 */
	private void buildInsertQueryAndUpdateErrorMaintainance(Integer userId, Integer bulkUploadId,
			List<HashMap<String, Object>> bulkHashMaps, BulkUploadMapDto bulkUploadMapDto,
			List<FieldConfiguration> fieldConfiguration, Integer repositoryId, String repositoryTableName) throws ApplicationException {
		List<Object> values = new ArrayList<>();
		List<String> listColumns = bulkHashMaps.stream().flatMap(map -> map.keySet().stream()).map(String::toLowerCase).distinct()
				.collect(Collectors.toList());
		
		List<HashMap<String, Object>> reorderedDataList = bulkHashMaps.stream()
                .map(dataMap -> {
                    LinkedHashMap<String, Object> reorderedMap = new LinkedHashMap<>();
                    listColumns.forEach(key -> reorderedMap.put(key, dataMap.get(key)));
                    return reorderedMap;
                })
                .collect(Collectors.toList());
		
		values = reorderedDataList.stream().flatMap(hashMap -> hashMap.values().stream()).collect(Collectors.toList());
		String columnParams = "";
		String columns = "";
		int columnPosition = 0;
		columns = listColumns.stream().map(column -> "\"" + column + "\"").collect(Collectors.joining(","));
		if (ApplicationUtils.isValidList(values)) {
			nativeQueryExecution(bulkUploadMapDto, listColumns, values, columnParams, columns, columnPosition);
		}
		buildQueryUpdateErrorMaintenanceHistoryRecords(userId, bulkUploadId, bulkHashMaps);
	}

	
	/**
	 * Builds the hash map object for excel duplicate records.
	 *
	 * @param dataLakeBulkUploadDto the data lake bulk upload dto
	 * @param userId the user id
	 * @param bulkUploadId the bulk upload id
	 * @param bulkHashMaps the bulk hash maps
	 * @param repositoryId the repository id
	 * @param keyOrder the key order
	 * @param bulkUploadid the bulk uploadid
	 * @throws ApplicationException the application exception
	 */
	private void buildHashMapObjectForExcelDuplicateRecords(DataLakeBulkUploadMapDto dataLakeBulkUploadDto,
			Integer userId, Integer bulkUploadId, List<HashMap<String, Object>> bulkHashMaps, Integer repositoryId,
			List<String> keyOrder, Object bulkUploadid) throws ApplicationException {
		dataLakeBulkUploadDto.getDuplicateRows().forEach(map -> {
			map.put(ApplicationConstants.IDENTITY_MAP, ApplicationUtils.getNextSequence());
			map.put(ColumnConstants.STATUS, true);
			map.put(ColumnConstants.BULK_UPLOAD_ID, bulkUploadid);
			map.put(ApplicationConstants.HASH_CODE, ApplicationConstants.EMPTY_STRING);
		});

		// change duplicate map key as field name to field column name
		List<HashMap<String, Object>> modifiedList = dataLakeBulkUploadDto.getDuplicateRows().stream().map(hashMap -> {
			HashMap<String, Object> modifiedMap = new HashMap<>();
			hashMap.forEach((key, value) -> modifiedMap.put(key.replace(" ", "_").toLowerCase(), value));
			return modifiedMap;
		}).collect(Collectors.toList());

		// key order maintain as per in validate map records
		List<Map<String, Object>> orderedHashMap = modifiedList.stream()
				.map(item -> keyOrder.stream()
						.collect(Collectors.toMap(key -> key, item::get, (a, b) -> b, LinkedHashMap::new)))
				.collect(Collectors.toList());
		

		// Convert the List<Map> to List<HashMap>
		List<HashMap<String, Object>> orderedHashMapList = orderedHashMap.stream().map(HashMap::new)
				.collect(Collectors.toList());
		
		
		bulkHashMaps.addAll(orderedHashMapList);
		for(HashMap<String, Object> singleExcelDuplicateRecord : orderedHashMapList) {
			buildErrorMaintainenceForDuplicateRecords(userId, bulkUploadId, repositoryId, singleExcelDuplicateRecord);
		}
	}

	/**
	 * @param bulkUploadMapDto
	 * @param listColumns
	 * @param values
	 * @param columnParams
	 * @param columns
	 * @param columnPosition
	 * @throws SQLDataException
	 */
	private void nativeQueryExecution(BulkUploadMapDto bulkUploadMapDto, List<String> listColumns, List<Object> values,
			String columnParams, String columns, int columnPosition) throws ApplicationException {
		List<String> valueStrings = buildNativeQueryParameters(listColumns, values, columnParams, columnPosition);
		String query = iDataRepositoryDao.generateInsertQuery(bulkUploadMapDto.getRepoTableName(),
				String.join(",", valueStrings), columns);
		iDataRepositoryDao.saveSingleFieldData(values, query);
	}

	/**
	 * @param listColumns
	 * @param values
	 * @param columnParams
	 * @param columnPosition
	 * @return
	 */
	private List<String> buildNativeQueryParameters(List<String> listColumns, List<Object> values, String columnParams,
			int columnPosition) {
		List<String> valueStrings = new ArrayList<>();
		List<Object> colValStrings = new ArrayList<>();
		IntStream.range(0, values.size()).boxed().collect(Collectors.groupingBy(index -> index / listColumns.size()))
				.values().forEach(batchIndices -> {
					List<Object> batch = batchIndices.stream().map(values::get).collect(Collectors.toList());

					List<String> placeholders = batchIndices.stream().map(index -> ":" + index)
							.collect(Collectors.toList());

					List<String> batchValues = batch.stream().map(Object::toString).collect(Collectors.toList());

					colValStrings.add("(" + String.join(",", batchValues) + ")");
					valueStrings.add("(" + String.join(",", placeholders) + ")");
				});
		return valueStrings;
	}

	/**
	 * @param fieldConfiguration
	 * @throws ApplicationException
	 * @throws ParseException
	 * @throws JsonProcessingException
	 */
	public BulkUploadMapDto singleAddForRepository(String repositoryName, HashMap<String, Object> singleRow,
			Integer userId, Integer bulkUploadId, List<HashMap<String, Object>> listOfKeyValues,
			List<FieldConfiguration> fieldConfiguration, List<String> globalSearchFields)
			throws ApplicationException, ParseException, JsonProcessingException {
		List<String> errorField = new ArrayList<>();
		logger.info("Data add for repository Execution process satrts..");
		Boolean isError = null;
		Integer repoId = fieldConfiguration.get(0).getRepoId().getId();
		HashMap<String, Object> successRecord = new HashMap<>();
		List<Boolean> errorBoolean = new ArrayList<>();
		singleRow.put(ColumnConstants.STATUS, false);
		List<Object> hashCodeStr = singleRow.values().stream().collect(Collectors.toList());
		Integer hashCodeObj = hashCodeStr.hashCode();
		successRecord.put(ApplicationConstants.HASH_CODE, hashCodeObj.toString());
		String selectForDuplicateCheck = String.format(ApplicationConstants.SELECT_DUPLICATE_CHECK,
				fieldConfiguration.get(0).getRepoId().getRepoTableName(), hashCodeObj);
		List<Map<String, Object>> duplicateInsertedValue = iBulkUploadDao.getScratchDataUsingBulkUploadId(selectForDuplicateCheck);
		if (ApplicationUtils.isValidList(duplicateInsertedValue)) {
			logger.info("records already exists............");
			buildDuplicateExistingMap(singleRow, userId, bulkUploadId, fieldConfiguration, repoId,
					successRecord);
		}
		if (!ApplicationUtils.isValidList(duplicateInsertedValue)) {
			logger.info("unique records validation and build a map...........");
			validateHashMapAndInsertErrorRecords(repositoryName, singleRow, userId, bulkUploadId,
					fieldConfiguration, errorField, isError, successRecord, errorBoolean);
		}
		BulkUploadMapDto bulkUploadMapDto = new BulkUploadMapDto();
		buildHashMapAndExecuteQuery(fieldConfiguration.get(0).getRepoId().getRepoTableName(), successRecord,
				errorBoolean, globalSearchFields);
		bulkUploadMapDto.setListOfKeyValues(successRecord);
		bulkUploadMapDto.setRepoId(fieldConfiguration.get(0).getRepoId().getId());
		bulkUploadMapDto.setRepoTableName(fieldConfiguration.get(0).getRepoId().getRepoTableName());
		return bulkUploadMapDto;
	}

	/**
	 * @param singleAddRepository
	 * @param userId
	 * @param bulkUploadId
	 * @param fieldConfiguration
	 * @param repoId
	 * @param successRecord
	 * @throws ApplicationException
	 */
	private void buildDuplicateExistingMap(HashMap<String, Object> singleAddRepository, Integer userId,
			Integer bulkUploadId, List<FieldConfiguration> fieldConfiguration, Integer repoId,
			HashMap<String, Object> successRecord) throws ApplicationException {
		for (Entry<String, Object> entry : singleAddRepository.entrySet()) {
			FieldConfiguration fieldConfig = fieldConfiguration.stream()
					.filter(a -> a.getFieldName().equals(entry.getKey())).findFirst().orElse(null);
			if (ApplicationUtils.isValidateObject(fieldConfig)) {
				successRecord.put(fieldConfig.getColumnName(), entry.getValue());
			}
		}
		String hashCodeStr = successRecord.toString();
		Integer hashCodeObj = hashCodeStr.hashCode();
		successRecord.put(ApplicationConstants.HASH_CODE, hashCodeObj.toString());
		successRecord.put(ColumnConstants.IDENTITY, ApplicationUtils.getNextSequence());
		successRecord.put(ColumnConstants.STATUS, true);
		successRecord.put(ColumnConstants.BULK_UPLOAD_ID, bulkUploadId);
		buildErrorMaintainenceForDuplicateRecords(userId, bulkUploadId, repoId, successRecord);
	}

	/**
	 * 
	 * @param repositoryName
	 * @param singleAddRepository
	 * @param userId
	 * @param bulkUploadId
	 * @param fieldConfiguration
	 * @param errorField
	 * @param isError
	 * @param successRecord
	 * @param errorBoolean
	 * @throws ApplicationException
	 * @throws ParseException
	 */
	private void validateHashMapAndInsertErrorRecords(String repositoryName,
			HashMap<String, Object> singleAddRepository, Integer userId, Integer bulkUploadId,
			List<FieldConfiguration> fieldConfiguration, List<String> errorField, Boolean isError,
			HashMap<String, Object> successRecord, List<Boolean> errorBoolean)
			throws ApplicationException, ParseException {
		successRecord.put(ApplicationConstants.IDENTITY_MAP, ApplicationUtils.getNextSequence());
		for (Entry<String, Object> entry : singleAddRepository.entrySet()) {
			validateByFactorySingleAndBulkUpload(successRecord, fieldConfiguration, isError, errorBoolean, entry,
					userId, repositoryName, bulkUploadId, errorField, successRecord.get(ApplicationConstants.IDENTITY_MAP).toString());
		}
		if (ApplicationUtils.isValidList(fieldConfiguration) && errorBoolean.contains(Boolean.TRUE)) {
			buildHashMapForScratch(bulkUploadId, fieldConfiguration, successRecord);
		}
		successRecord.put(ColumnConstants.BULK_UPLOAD_ID, bulkUploadId);
		Boolean errorPresent = successRecord.keySet().stream()
				.anyMatch(key -> key.equals(ApplicationConstants.ERROR_MSG));
		if (Boolean.TRUE.equals(errorPresent)) {
			successRecord.remove(ApplicationConstants.ERROR_MSG);
		}
	}

	/**
	 * 
	 * @param userId
	 * @param bulkUploadId
	 * @param repoId
	 * @param successRecord
	 * @throws ApplicationException
	 */
	private void buildErrorMaintainenceForDuplicateRecords(Integer userId, Integer bulkUploadId, Integer repoId,
			HashMap<String, Object> successRecord) throws ApplicationException {
		ErrorMaintenance errorMaitainence = new ErrorMaintenance();
		errorMaitainence.setCrtDteTme(LocalDateTime.now());
		errorMaitainence.setCrtUsrId(userId);
		errorMaitainence.setErrorMessage("Duplicate Records");
		errorMaitainence.setFieldConfiguration(null);
		errorMaitainence.setErrorFields(null);
		errorMaitainence.setIsDltSts(Boolean.FALSE);
		errorMaitainence.setBulkUploadId(bulkUploadId);
		errorMaitainence.setUniqueId(successRecord.get(ApplicationConstants.IDENTITY_MAP).toString());
		errorMaitainence.setRepositoryId(repoId);
		errorMaitainence.setMdyDteTme(LocalDateTime.now());
		errorMaitainence.setIsDuplicate(Boolean.TRUE);
		iErrorMaintenanceDao.saveErrorMaintenanceHistory(errorMaitainence);
	}

	/**
	 * @throws ApplicationException
	 * @throws ParseException
	 * @throws JsonProcessingException
	 */
	@Override
	public String singleRecordForRepository(String repositoryName, HashMap<String, Object> singleAddRepository)
			throws ApplicationException, ParseException, JsonProcessingException {
		logger.info("single row record!!!!!!!!!!!!!");
		HashMap<String, Object> successRecord = new HashMap<>();
		String repoTableName = null;
		List<String> hashCodeStr = singleAddRepository.entrySet().stream()
				.map(entry -> entry.getValue().toString().trim()) 
				.map(String::toLowerCase) 
				.toList();
		Integer hashCodeObj = hashCodeStr.hashCode();
		for (Entry<String, Object> entry : singleAddRepository.entrySet()) {
			repoTableName = validateSingleDataRepositoryRecord(repositoryName, entry, successRecord);
		}
		String selectQuery = iDataRepositoryDao.generateSelectQuery(repoTableName, hashCodeObj);
		List<Map<String, Object>> scratchMap = iBulkUploadDao.getScratchDataUsingBulkUploadId(selectQuery);
		if(ApplicationUtils.isValidList(scratchMap)) {
			throw new ApplicationException(ErrorCodes.DUPLICATE_RECORD);
		}
		String uniqueId =  UUID.randomUUID().toString();
		successRecord.put(ColumnConstants.IDENTITY, uniqueId);
		successRecord.put(ApplicationConstants.HASH_CODE, hashCodeObj);
		singleAddRepository.put(ColumnConstants.IDENTITY, "'" + uniqueId + "'");
		buildQueryAndReturnPkId(successRecord, repoTableName);
		String documentJSON = new ObjectMapper().writeValueAsString(singleAddRepository);
		kafkaTemplate.send(ColumnConstants.IDX_PREFIX + repoTableName, documentJSON.toLowerCase());
		return "Data Added Successfully";

	}

	/**
	 * @throws ApplicationException
	 * @throws JsonProcessingException
	 */
	@Async
	private void buildHashMapAndExecuteQuery(String repositoryName, HashMap<String, Object> bulkHashMap,
			List<Boolean> errorBoolean, List<String> globalSearchFields)
			throws ApplicationException, JsonProcessingException {
		if (ApplicationUtils.isValidList(errorBoolean) && !errorBoolean.contains(Boolean.TRUE)) {
			Map<String, Object> syncValue = bulkHashMap.entrySet().stream()
					.filter(singleVal -> globalSearchFields.contains(singleVal.getKey()))
					.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
			Map<String, Object> identityKeyVal = bulkHashMap.entrySet().stream()
					.filter(f -> f.getKey().equals(ColumnConstants.IDENTITY))
					.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
			Object identityValue = identityKeyVal.get(ColumnConstants.IDENTITY);
			// Wrap the value with single quotes
			Object quotedIdentityValue = "'" + identityValue + "'";
			identityKeyVal.put(ColumnConstants.IDENTITY, quotedIdentityValue);
			syncValue.putAll(identityKeyVal);
			syncValue.put(ApplicationConstants.REPO_NAME, repositoryName);
			String documentJSON = new ObjectMapper().writeValueAsString(syncValue);
			kafkaTemplate.send(ColumnConstants.IDX_PREFIX + repositoryName, documentJSON.toLowerCase());
		}
	}

	/**
	 * @param singleMap
	 * @param repoName
	 * @throws ApplicationException
	 * @throws JsonProcessingException
	 */
	private void buildQueryAndReturnPkId(HashMap<String, Object> singleMap, String repoName)
			throws ApplicationException, JsonProcessingException {
		List<String> listOfColumns = singleMap.entrySet().stream().map(Map.Entry::getKey).collect(Collectors.toList());
		List<Object> listOfValue = singleMap.entrySet().stream().map(entry -> {
			Object value = entry.getValue();
			if (value instanceof String) {
				return ((String) value).trim();
			}
			return value;
		}).collect(Collectors.toList());
		String columnParams = "";
		String columns = "";
		int columnPosition = 0;
		columns = listOfColumns.stream().collect(Collectors.joining(","));
		List<String> valueStrings = buildNativeQueryParameters(listOfColumns, listOfValue, columnParams,
				columnPosition);
		String query = null;
		query = iDataRepositoryDao.generateInsertQuery(repoName, String.join(",", valueStrings), columns);
		iDataRepositoryDao.saveSingleFieldData(listOfValue, query);
	}

	/**
	 * @param userId
	 * @param bulkUploadId
	 * @throws ApplicationException
	 */
	private void buildQueryUpdateErrorMaintenanceHistoryRecords(Integer userId, Integer bulkUploadId,
			List<HashMap<String, Object>> bulkUploadHashMap) throws ApplicationException {
		updateCountOfBulkUpload(userId, bulkUploadId, bulkUploadHashMap);
	}

	/**
	 * @param userId
	 * @param bulkUploadId
	 * @param map
	 */
	private void updateCountOfBulkUpload(Integer userId, Integer bulkUploadId, List<HashMap<String, Object>> map) {
		long errorCount = map.stream().filter(a -> a.get(ColumnConstants.STATUS).equals(Boolean.TRUE)).count();
		BulkUploadHistory bulkUploadHistory = iBulkUploadDao.getBulkUploadByIdAndAssocicationId(bulkUploadId, 1);
		bulkUploadHistory.setMdyDteTme(LocalDateTime.now());
		bulkUploadHistory.setMdyUsrId(userId);
		bulkUploadHistory.setTotalCount(bulkUploadHistory.getTotalCount() + map.size());
		bulkUploadHistory.setFailureCount(bulkUploadHistory.getFailureCount() + (int) (errorCount));
		bulkUploadHistory.setSuccessCount(bulkUploadHistory.getSuccessCount() + (int) (map.size() - errorCount));
		iBulkUploadDao.updateBulkUploadHistory(bulkUploadHistory);
	}

	/**
	 * @param bulkUploadId
	 * @param fieldConfiguration
	 * @param successRecord
	 */
	private void buildHashMapForScratch(Integer bulkUploadId, List<FieldConfiguration> fieldConfiguration,
			HashMap<String, Object> successRecord) {
		successRecord.put(ColumnConstants.STATUS, Boolean.TRUE);
	}

	/**
	 * @param successRecord
	 * @param fieldConfiguration
	 * @param isError
	 * @param errorBoolean
	 * @param entry
	 * @return
	 * @throws ApplicationException
	 * @throws ParseException
	 */
	private void validateByFactorySingleAndBulkUpload(HashMap<String, Object> successRecord,
			List<FieldConfiguration> fieldConfiguration, Boolean isError, List<Boolean> errorBoolean,
			Entry<String, Object> entry, Integer userId, String repositoryName, Integer bulkUploadId,
			List<String> errorField, String identity) throws ApplicationException, ParseException {
		if (ApplicationUtils.isValidList(fieldConfiguration)) {
			isError = validateBulkRecordAndSaveErrorRecord(successRecord, isError, entry, fieldConfiguration, userId,
					bulkUploadId, errorField, identity);
		}
		errorBoolean.add(isError);
	}

	/**
	 * Factory for Bulk Record Validate and Save Error history
	 *
	 * @param isError
	 * @param entry
	 * @return
	 * @throws ApplicationException
	 * @throws ParseException
	 */
	private Boolean validateBulkRecordAndSaveErrorRecord(HashMap<String, Object> successRecord, Boolean isError,
			Entry<String, Object> entry, List<FieldConfiguration> fieldConfigs, Integer userId, Integer bulkUploadId,
			List<String> errorField, String identity) throws ApplicationException, ParseException {
		FieldConfiguration fieldConfig = fieldConfigs.stream().filter(a -> a.getFieldName().equals(entry.getKey()))
				.findFirst().orElse(null);
		if (ApplicationUtils.isValidObject(fieldConfig)) {
			if (ApplicationUtils.isValidateObject(fieldConfig.getDataType())) {
				iBulkUploadValidationBuilder = dataTypeFactory
						.getBulkUploadFieldType(FieldDataTypeEnum.getFieldDataTypeById(fieldConfig.getDataType()));
			} else {
				iBulkUploadValidationBuilder = dataTypeFactory
						.getBulkUploadFieldType(FieldDataTypeEnum.STRING.getValue());
			}
			isError = iBulkUploadValidationBuilder.getDataTypeValidationBuilder(successRecord, fieldConfig, entry,
					fieldConfig.getIsMandatory(), userId);
			HashMap<String, Object> singleMap = (HashMap<String, Object>) successRecord.entrySet().stream()
					.filter(a -> a.getKey().equals("errorMsg"))
					.collect(Collectors.toMap(Map.Entry<String, Object>::getKey, Map.Entry<String, Object>::getValue));
			if (Boolean.TRUE.equals(isError)) {
				errorField.add(entry.getKey().toLowerCase());
				buildAndSaveErrorMaintenance(fieldConfig, userId, singleMap.get("errorMsg").toString(), bulkUploadId,
						Boolean.FALSE, identity);
			}

		}
		return isError;
	}

	/**
	 * @param fieldConfiguration
	 * @param userId
	 * @throws ApplicationException
	 */
	public void buildAndSaveErrorMaintenance(FieldConfiguration fieldConfiguration, Integer userId, String errorMsg,
			Integer bulkUploadId, Boolean isDuplicate, String identity) throws ApplicationException {
		ErrorMaintenance errorMaitainence = new ErrorMaintenance();
		errorMaitainence.setCrtDteTme(LocalDateTime.now());
		errorMaitainence.setCrtUsrId(userId);
		errorMaitainence.setErrorMessage(errorMsg);
		errorMaitainence.setFieldConfiguration(fieldConfiguration);
		errorMaitainence.setErrorFields(fieldConfiguration.getColumnName());
		errorMaitainence.setIsDltSts(Boolean.FALSE);
		errorMaitainence.setBulkUploadId(bulkUploadId);
		errorMaitainence.setUniqueId(identity);
		errorMaitainence.setRepositoryId(fieldConfiguration.getRepoId().getId());
		errorMaitainence.setMdyDteTme(LocalDateTime.now());
		errorMaitainence.setIsDuplicate(isDuplicate);
		iErrorMaintenanceDao.saveErrorMaintenanceHistory(errorMaitainence);
	}

	/**
	 * Factory Method For Single Record Upload
	 *
	 * @param entry
	 * @throws ApplicationException
	 * @throws ParseException
	 */
	private String validateSingleDataRepositoryRecord(String repositoryName, Entry<String, Object> entry,
			HashMap<String, Object> successRecord) throws ApplicationException, ParseException {
		List<FieldConfiguration> fieldConfigs = fieldConfigurationDao
				.getFieldMappedInRepository(repositoryName);
		if (ApplicationUtils.isValidList(fieldConfigs)) {
			FieldConfiguration fieldConfig = fieldConfigs.stream().filter(a -> a.getColumnName().equals(entry.getKey()))
					.findFirst().orElse(null);
			if (ApplicationUtils.isValidObject(fieldConfig)) {
				if (fieldConfig.getFieldType()
						.equals(FieldTypeEnum.getFieldTypeIdByTypeName(ApplicationConstants.DROP_DOWN))) {
					validateFieldOptionLinking(fieldConfig, entry);
				}
				if (ApplicationUtils.isValidateObject(fieldConfig.getDataType())) {
					iDataTypeFactoryValidationBuilder = dataTypeFactory.getDataTypeValidationBuilder(
							FieldDataTypeEnum.getFieldDataTypeById(fieldConfig.getDataType()));
				} else {
					iDataTypeFactoryValidationBuilder = dataTypeFactory
							.getDataTypeValidationBuilder(FieldDataTypeEnum.STRING.getValue());
				}
				iDataTypeFactoryValidationBuilder.getDataTypeValidationBuilder(fieldConfig.getErrMsg(), entry,
						fieldConfig.getIsMandatory(), successRecord, fieldConfig);
			}
			return fieldConfigs.get(0).getRepoId().getRepoTableName();
		}
		return null;
	}

	/**
	 * @param fieldConfig
	 * @param entry
	 * @throws ApplicationException
	 */
	private void validateFieldOptionLinking(FieldConfiguration fieldConfig, Entry<String, Object> entry)
			throws ApplicationException {
		List<FieldOptionLink> fieldOptionLink = fieldOptionLinkingDao.getFieldOptionList(fieldConfig.getIdentity());
		if (ApplicationUtils.isValidList(fieldOptionLink)) {
			Boolean checkListValue = fieldOptionLink.stream()
					.anyMatch(a -> a.getDropdownOptions().equals(entry.getValue()));
			if (Boolean.FALSE.equals(checkListValue)) {
				throw new ApplicationException(ErrorCodes.INVALID_DROPDOWN);
			}
		}
	}

	/**
	 * @param userInfo
	 * @param fileStorageSaved
	 * @throws ApplicationException
	 */
	private BulkUploadHistory buildBulkUploadHistoryAndSave(UserInfo userInfo, FileStorage fileStorageSaved,
			DataRepository dataRepository) throws ApplicationException {
		BulkUploadHistory bulkUploadHistory = new BulkUploadHistory();
		bulkUploadHistory.setFileStorage(fileStorageSaved);
		bulkUploadHistory.setCrtUsrId(userInfo.getId());
		bulkUploadHistory.setFailureCount(ApplicationConstants.ZERO);
		bulkUploadHistory.setTotalCount(ApplicationConstants.ZERO);
		bulkUploadHistory.setSuccessCount(ApplicationConstants.ZERO);
		bulkUploadHistory.setCrtDteTme(LocalDateTime.now());
		bulkUploadHistory.setMdyDteTme(LocalDateTime.now());
		bulkUploadHistory.setDataRepository(dataRepository);
		bulkUploadHistory.setUploadStatus(BulkUploadStatusEnum.NEW.getStatusId());
		bulkUploadHistory.setIsDltSts(Boolean.FALSE);
		bulkUploadHistory.setAssociationId(userInfo.getAssociationId());
		bulkUploadHistory.setCompanyId(userInfo.getCompanyId());
		return iBulkUploadDao.saveBulkUploadHsitory(bulkUploadHistory);
	}

	/**
	 * @param file
	 * @param userInfo
	 * @param dataRepository
	 * @return
	 * @throws IOException
	 * @throws ApplicationException
	 */
	private FileStorage buildFileStorageAndSave(String file, UserInfo userInfo, DataRepository dataRepository)
			throws IOException, ApplicationException {
		FileStorage fileStorage = new FileStorage();
		fileStorage.setCrtDteTme(LocalDateTime.now());
		fileStorage.setCrtUsrId(userInfo.getId());
		fileStorage.setFileName(file);
		fileStorage.setIsDltSts(Boolean.FALSE);
		fileStorage.setRepositoryId(dataRepository.getId());
		fileStorage.setMdyDteTme(LocalDateTime.now());
		return iFileStorageDao.saveFileStorageForRepository(fileStorage);
	}

	/**
	 * @param repositoryIdentity
	 * @throws IOException
	 */
	@SuppressWarnings("resource")
	@Override
	public ResponseEntity<byte[]> downloadSampleFileForRepository(String repositoryIdentity) throws IOException {
		List<FieldConfiguration> fieldConfigurations = iDataRepositoryDao.getFieldRepository(repositoryIdentity);
		logger.info("Repository Name :" + fieldConfigurations.get(0).getRepoId().getRepositoryName());
		XSSFWorkbook xssfWorkBook = new XSSFWorkbook();
		XSSFSheet xssfSheet = xssfWorkBook
				.createSheet(fieldConfigurations.get(0).getRepoId().getRepositoryName() + " file");
		Row row = xssfSheet.createRow(ApplicationConstants.ZERO);
		/** Header Style */
		CellStyle headerStyle = xssfWorkBook.createCellStyle();
		/** Header Font */
		XSSFFont font = (xssfWorkBook).createFont();
		font.setFontName(ApplicationConstants.ARIAL);
		headerStyle.setFont(font);
		Integer col = 0;
		if (ApplicationUtils.isValidList(fieldConfigurations)) {
			for (int i = 0; i < fieldConfigurations.size(); i++) {
				col = buildHeaderCellTextAndStyle(fieldConfigurations, xssfWorkBook, xssfSheet, row, headerStyle, col,
						i, font);
			}
			if (ApplicationUtils.isValidList(fieldConfigurations)) {
				for (int colNum = 0; colNum < fieldConfigurations.size(); colNum++) {
					xssfSheet.autoSizeColumn(colNum);
				}
			}
			ByteArrayOutputStream fileOut = new ByteArrayOutputStream();
			String fileName = fieldConfigurations.get(0).getRepoId().getRepositoryName() + ApplicationConstants.XLSX;
			xssfWorkBook.write(fileOut);
			fileOut.close();
			byte[] fileByte = fileOut.toByteArray();
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
			headers.setContentLength(fileByte.length);
			headers.setContentDispositionFormData("attachment", fileName);
			logger.info("sample file converted to byte...................");
			return new ResponseEntity<>(fileByte, headers, HttpStatus.OK);
		}
		return new ResponseEntity<>(null);
	}

	/**
	 * @param fieldConfigurations
	 * @param xssfWorkBook
	 * @param xssfSheet
	 * @param row
	 * @param headerStyle
	 * @param col
	 * @param i
	 * @return
	 */
	private Integer buildHeaderCellTextAndStyle(List<FieldConfiguration> fieldConfigurations, XSSFWorkbook xssfWorkBook,
			XSSFSheet xssfSheet, Row row, CellStyle headerStyle, Integer col, int i, XSSFFont font) {
		Cell headerCell = null;
		if (FieldTypeEnum.DROPDOWN.getFieldTypeId().equals(fieldConfigurations.get(i).getFieldType())
				&& fieldConfigurations.get(i).getFieldName().equals(fieldConfigurations.get(i).getFieldName())) {
			List<String> optionForField = fieldOptionLinkingDao
					.getFieldOptionNames(fieldConfigurations.get(i).getIdentity());
			if (ApplicationUtils.isValidList(optionForField)) {
				String[] drop = optionForField.toArray(new String[0]);
				col = dropdownValidationAndFormt(fieldConfigurations, xssfWorkBook, xssfSheet, row, headerStyle, col, i,
						drop);
			}
		}
		else {
			headerCell = row.createCell(col++);
			headerCell.setCellValue(fieldConfigurations.get(i).getFieldName());
			headerCell.setCellStyle(headerStyle);
		}
		buildFontAndStyleForDate(fieldConfigurations, xssfWorkBook, xssfSheet, row, col, i, font);
			logger.info("Header column created........................");
		return col;
	}

	/**
	 * @param fieldConfigurations
	 * @param xssfWorkBook
	 * @param xssfSheet
	 * @param row
	 * @param col
	 * @param i
	 * @param font
	 * @return
	 */
	private Integer buildFontAndStyleForDate(List<FieldConfiguration> fieldConfigurations, XSSFWorkbook xssfWorkBook,
			XSSFSheet xssfSheet, Row row, Integer col, int i, XSSFFont font) {
		CellStyle style = xssfWorkBook.createCellStyle();
		style.setFont(font);
		style.setDataFormat((short) BuiltinFormats.getBuiltinFormat("text"));
		xssfSheet.setDefaultColumnStyle(i, style);
		return col;
	}

	/**
	 * @param xssfWorkBook
	 * @param xssfSheet
	 * @param row
	 * @param headerStyle
	 * @param col
	 * @param i
	 * @param drop
	 * @return
	 */
	private Integer dropdownValidationAndFormt(List<FieldConfiguration> fieldConfigurations, XSSFWorkbook xssfWorkBook,
			XSSFSheet xssfSheet, Row row, CellStyle headerStyle, Integer col, int i, String[] drop) {
		XSSFDataValidationHelper xssfDataValidationHelper = new XSSFDataValidationHelper(xssfSheet);
		DataValidationConstraint constraint = xssfDataValidationHelper.createExplicitListConstraint(drop);
		/** Get Last Row Index */
		Integer lastIndex = xssfWorkBook.getSpreadsheetVersion().getLastRowIndex();
		/** set cell range and set drop-down value in all rows for single column */
		CellRangeAddressList cellRangeAddressList = new CellRangeAddressList(1, lastIndex, i, i);
		XSSFDataValidationHelper validationHelper = new XSSFDataValidationHelper(xssfSheet);
		DataValidation dataValidation = validationHelper.createValidation(constraint, cellRangeAddressList);
		dataValidation.createErrorBox("Invalid Selection", "Please select a valid option.");
		/** Error Validation */
		dataValidation.setShowErrorBox(true);
		dataValidation.setShowPromptBox(true);
		/** Enable drop down arrow */
		dataValidation.setSuppressDropDownArrow(true);
		xssfSheet.addValidationData(dataValidation);
		Cell cell = row.createCell(col++);
		cell.setCellValue(fieldConfigurations.get(i).getFieldName());
		cell.setCellStyle(headerStyle);
		logger.info("Header dropdown cells created............");
		return col;
	}

	/**
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public BulkUploadHistoryDto getBulkUploadHistoryDetails(String bulkUploadIdentity) throws ApplicationException {
		BulkUploadHistory bulkUploadHistory = iDataRepositoryDao.getBulkUploadHistory(bulkUploadIdentity);
		BulkUploadHistoryDto bulkUploadHistoryDto = new BulkUploadHistoryDto();
		if (ApplicationUtils.isValidateObject(bulkUploadHistory)) {
			bulkUploadHistoryDto.setSuccessCount(bulkUploadHistory.getSuccessCount());
			bulkUploadHistoryDto.setFailureCount(bulkUploadHistory.getFailureCount());
			bulkUploadHistoryDto.setTotalCount(bulkUploadHistory.getTotalCount());
			bulkUploadHistoryDto
					.setStatus(BulkUploadStatusEnum.getBulkUploadStatusDescById(bulkUploadHistory.getUploadStatus()));
			bulkUploadHistoryDto.setBulkUploadIdentity(bulkUploadIdentity);
		} else {
			throw new ApplicationException(ErrorCodes.INVALID_BULK_UPLOAD_ID);
		}
		return bulkUploadHistoryDto;
	}

	/**
	 * @param loggedInUser
	 * @return
	 */
	@Override
	public List<BulkImportHistoryDto> getUploadHistoryDetails(String repoIdentity, UserInfo loggedInUser) {
		DataRepository dataRepository = iRepositoryDao.getRepositoryDetails(repoIdentity);
		List<BulkImportHistoryDto> bulkImportHistoryDtos = new ArrayList<>();
		if (ApplicationUtils.isValidateObject(dataRepository)) {
			List<BulkUploadHistory> bulkUploadHistory = iBulkUploadDao.getUploadHistorydetails(dataRepository.getId(),
					loggedInUser.getCompanyId(), loggedInUser.getAssociationId());
			if (ApplicationUtils.isValidList(bulkUploadHistory)) {
				for (BulkUploadHistory bulkHistory : bulkUploadHistory) {
					bulkImportHistoryDtos.add(setBulkUploadHistory(bulkHistory));
				}
			}
		}
		return bulkImportHistoryDtos;
	}

	/**
	 * @param bulkHistory
	 * @return
	 */
	private BulkImportHistoryDto setBulkUploadHistory(BulkUploadHistory bulkHistory) {
		BulkImportHistoryDto bulkImportHistoryDto = new BulkImportHistoryDto();
		bulkImportHistoryDto.setSuccessCount(bulkHistory.getSuccessCount());
		bulkImportHistoryDto.setFailureCount(bulkHistory.getFailureCount());
		bulkImportHistoryDto.setCreatedDate(bulkHistory.getCrtDteTme().toString());
		bulkImportHistoryDto.setDate(bulkHistory.getCrtDteTme().toLocalDate().toString());
		bulkImportHistoryDto.setTime(bulkHistory.getCrtDteTme().toLocalTime().toString());
		bulkImportHistoryDto.setTotalCount(bulkHistory.getTotalCount());
		bulkImportHistoryDto.setIdentity(bulkHistory.getIdentity());
		bulkImportHistoryDto.setRepoIdentity(bulkHistory.getDataRepository().getIdentity());
		bulkImportHistoryDto.setFileName(bulkHistory.getFileStorage().getFileName());
		return bulkImportHistoryDto;
	}

	/**
	 * @param uploadIdentity
	 * @param status
	 * @param skip
	 * @param limit
	 * @param customSortingVo
	 */
	@Override
	public SuccessErrorRecordsDto getSuccessErrorRecords(String uploadIdentity, Boolean status,
			List<CustomSortingVo> customSortingVo, Integer skip, Integer limit) throws ApplicationException {

		/** Preliminary Data Fetch */
		BulkUploadHistory bulkUploadHistory = fetchBulkUploadHistory(uploadIdentity);
		List<FieldConfiguration> fieldConfiguration = fetchFieldConfiguration(bulkUploadHistory);

		DataRepository dataRepository = bulkUploadHistory.getDataRepository();

		/** Define Query Selector */
		String columnSelector = null;
		List<String> columnNameList = fieldConfiguration.stream()
				.map(field -> ColumnConstants.SCRATCH + ApplicationConstants.DOUBLE_QUOTES + field.getColumnName() + ApplicationConstants.DOUBLE_QUOTES).toList();
		columnSelector = columnNameList.stream().collect(Collectors.joining(ApplicationConstants.COMMA));
		String tableColumns = columnSelector;
		columnSelector = columnSelector.concat(ColumnConstants.DEFAULT_COLUMNS);

		/** Native Query Builder */
		String tableName = fieldConfiguration.get(ApplicationConstants.ZERO).getRepoId().getRepoTableName();
		StringBuilder rawQuery = buildRawQuery(status, customSortingVo, skip, limit, bulkUploadHistory, tableName,
				dataRepository, columnSelector, Boolean.FALSE, tableColumns);

		/** DTO Wrapper */
		SuccessErrorRecordsDto successErrorRecordsDto = new SuccessErrorRecordsDto();
		List<Map<String, Object>> scratchMap = iBulkUploadDao.getScratchDataUsingBulkUploadId(rawQuery.toString());
		List<String> keyToRemove = new ArrayList<>(
				Arrays.asList(ColumnConstants.BULK_UPLOAD_ID, ColumnConstants.ID, ColumnConstants.STATUS));
		scratchMap.stream()
				.filter(scratch -> scratch.entrySet().removeIf(entry -> keyToRemove.contains(entry.getKey()))).toList();
		if (status.equals(Boolean.FALSE)) {
			List<String> keys = new ArrayList<>(Arrays.asList(ColumnConstants.ERROR, ColumnConstants.ERR_FLDS));
			scratchMap.stream().filter(scratch -> scratch.entrySet().removeIf(entry -> keys.contains(entry.getKey())))
					.toList();
		}
		successErrorRecordsDto = buildSuccessErrorRecordsDto(fieldConfiguration, scratchMap);
		return successErrorRecordsDto;
	}

	/**
	 * @param fieldConfiguration
	 * @param scratchMap
	 * @return
	 */
	private SuccessErrorRecordsDto buildSuccessErrorRecordsDto(List<FieldConfiguration> fieldConfiguration,
			List<Map<String, Object>> scratchMap) {
		LinkedHashMap<String, String> linkedHashMap = fieldConfiguration.stream()
				.collect(Collectors.toMap(FieldConfiguration::getFieldName, FieldConfiguration::getColumnName,
						(existing, replacement) -> existing, LinkedHashMap::new));
		List<FieldMapperDto> fieldMapperDto = linkedHashMap.entrySet().stream()
				.map(value -> new FieldMapperDto(value.getKey(), value.getValue())).collect(Collectors.toList());
		SuccessErrorRecordsDto successErrorRecordsDto = new SuccessErrorRecordsDto();
		successErrorRecordsDto.setSuccessErrorList(scratchMap);
		successErrorRecordsDto.setFieldMapperDto(fieldMapperDto);
		return successErrorRecordsDto;
	}

	/**
	 * @param uploadIdentity
	 * @param status
	 * @param skip
	 * @param limit
	 * @param customSortingVo
	 * @throws ApplicationException
	 */
	@Override
	public Long getSuccessErrorRecordsCount(String uploadIdentity, Boolean status,
			List<CustomSortingVo> customSortingVo, Integer skip, Integer limit) throws ApplicationException {
		BulkUploadHistory bulkUploadHistory = fetchBulkUploadHistory(uploadIdentity);
		List<FieldConfiguration> fieldConfiguration = fetchFieldConfiguration(bulkUploadHistory);
		String tableName = fieldConfiguration.get(ApplicationConstants.ZERO).getRepoId().getRepoTableName();
		logger.info("Table Name : {}....................................", tableName);
		DataRepository dataRepository = bulkUploadHistory.getDataRepository();
		StringBuilder rawQuery = buildRawQuery(status, customSortingVo, skip, limit, bulkUploadHistory, tableName,
				dataRepository, null, Boolean.TRUE, null);
		Long count = iBulkUploadDao.getScratchCountUsingUploadId(rawQuery.toString());
		return count;
	}

	/**
	 * @param bulkUploadHistory
	 * @return
	 * @throws ApplicationException
	 */
	private List<FieldConfiguration> fetchFieldConfiguration(BulkUploadHistory bulkUploadHistory)
			throws ApplicationException {
		List<FieldConfiguration> fieldConfiguration = fieldConfigurationDao
				.getFieldDetails(bulkUploadHistory.getDataRepository().getId());
		if (Boolean.FALSE.equals(ApplicationUtils.isValidList(fieldConfiguration))) {
			throw new ApplicationException(ErrorCodes.INVALID_ID);
		}
		return fieldConfiguration;
	}

	/**
	 * @param uploadIdentity
	 * @return
	 * @throws ApplicationException
	 */
	private BulkUploadHistory fetchBulkUploadHistory(String uploadIdentity) throws ApplicationException {
		BulkUploadHistory bulkUploadHistory = iBulkUploadDao.getBulkUploadDetailsByIdentity(uploadIdentity);
		if (Boolean.FALSE.equals(ApplicationUtils.isValidateObject(bulkUploadHistory))) {
			throw new ApplicationException(ErrorCodes.INVALID_IDENTITY);
		}
		return bulkUploadHistory;
	}

	/**
	 * @param status
	 * @param customSortingVo
	 * @param skip
	 * @param limit
	 * @param bulkUploadHistory
	 * @param tableName
	 * @param dataRepository
	 * @param columnSelector
	 * @param isCountFlow
	 * @return
	 */
	private StringBuilder buildRawQuery(Boolean status, List<CustomSortingVo> customSortingVo, Integer skip,
			Integer limit, BulkUploadHistory bulkUploadHistory, String tableName, DataRepository dataRepository,
			String columnSelector, Boolean isCountFlow, String tableColumns) {
		StringBuilder rawQuery = new StringBuilder();
		String query = isCountFlow ? QueryConstants.COUNT_QUERY : QueryConstants.SELECT_QUERY;

		/** Column Selector */
		if (Boolean.FALSE.equals(isCountFlow)) {
			query = query.replace(ApplicationConstants.ASTERIK, columnSelector);
			query = query.replace(ApplicationConstants.HASHTAG, tableColumns + QueryConstants.GROUP_BY_COLS);
		}
		if (Boolean.FALSE.equals(status)) {
			rawQuery.append(query.replaceAll(QueryConstants.TABLE, tableName)
					.replaceAll(QueryConstants.BULK_UPLOAD_ID, bulkUploadHistory.getId().toString())
					.replaceAll(QueryConstants.ERR_REP_ID, ApplicationConstants.WITHOUT_SPACE)
					.replaceAll(QueryConstants.STATUS, status.toString()));
		} else {
			rawQuery.append(query.replaceAll(QueryConstants.TABLE, tableName)
					.replaceAll(QueryConstants.BULK_UPLOAD_ID, bulkUploadHistory.getId().toString())
					.replaceAll(QueryConstants.REPOSITORY_ID, dataRepository.getId().toString())
					.replaceAll(QueryConstants.STATUS, status.toString()));
		}

		/** Sorting */
		if (ApplicationUtils.isValidList(customSortingVo) && !isCountFlow) {
			rawQuery.append(QueryConstants.SORTING_QUERY
					.replace(QueryConstants.COLUMN, customSortingVo.get(ApplicationConstants.ZERO).getColumnName())
					.replace(QueryConstants.CONDITION, // accessing first element because it's sorting!
							customSortingVo.get(ApplicationConstants.ZERO).getIsAsc() ? QueryConstants.ASC
									: QueryConstants.DESC));
		}

		/** Pagination */
		if (Boolean.FALSE.equals(isCountFlow)) {
			rawQuery.append(QueryConstants.PAGINATION_QUERY.replace(QueryConstants.LIMIT, limit.toString())
					.replace(QueryConstants.OFFSET, skip.toString()));
		}
		logger.info("QUERY <====> " + rawQuery + "....................................");
		return rawQuery;
	}

	/**
	 * @return
	 */
	@SuppressWarnings("resource")
	@Override
	public ResponseEntity<byte[]> downloadExcel(SuccessErrorRecordsDto successErrorRecordsDto) {
		try {
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet(ApplicationConstants.REPOSITORY_REPORT);
			Row row = sheet.createRow(ApplicationConstants.ZERO);
			CellStyle headerStyle = workbook.createCellStyle();
			headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
			XSSFFont font = (workbook).createFont();
			font.setColor(IndexedColors.BLACK.getIndex());
			font.setBold(true);
			headerStyle.setFont(font);

			XSSFCellStyle style = workbook.createCellStyle();
			Font fonts = workbook.createFont();
			fonts.setColor(IndexedColors.RED.getIndex());
			style.setDataFormat((short) BuiltinFormats.getBuiltinFormat("text"));
			style.setFont(fonts);

			CellStyle style2 = workbook.createCellStyle();
			XSSFFont font2 = (workbook).createFont();
			font2.setColor(IndexedColors.BLACK.getIndex());
			style2.setFont(font2);
			style2.setDataFormat((short) BuiltinFormats.getBuiltinFormat("text"));
			sheet.setDefaultColumnStyle(1,style2);

			int rowIndex = ApplicationConstants.ZERO;
			List<String> displayColumn = successErrorRecordsDto.getFieldMapperDto().stream()
					.map(a -> a.getDisplayName()).collect(Collectors.toList());
			displayColumn.add(ApplicationConstants.ERROR_MESSAGE);

			List<String> ColumnName = successErrorRecordsDto.getFieldMapperDto().stream().map(a -> a.getColumnName())
					.collect(Collectors.toList());
			ColumnName.add("error");
			ColumnName.add("err_flds");

			for (int i = ApplicationConstants.ZERO; i < displayColumn.size(); i++) {
				row.createCell(i).setCellValue(displayColumn.get(i));
				row.getCell(i).setCellStyle(headerStyle);
			}
			List<Map<String, Object>> orderMaintainList = new ArrayList<>();
			for (Map<String, Object> changeOrder : successErrorRecordsDto.getSuccessErrorList()) {
				Map<String, Object> orderedMap = new LinkedHashMap<>();
				for (String key : ColumnName) {
					if (changeOrder.containsKey(key)) {
						orderedMap.put(key, changeOrder.get(key));
					}
				}
				orderMaintainList.add(orderedMap);
			}
			setValueInExcelSheet(orderMaintainList, sheet, style, rowIndex, style2);

			for (int colNum = 0; colNum < displayColumn.size(); colNum++) {
				sheet.autoSizeColumn(colNum);
			}
			ByteArrayOutputStream fileOut = new ByteArrayOutputStream();
			workbook.write(fileOut);
			fileOut.close();
			byte[] fileByte = fileOut.toByteArray();
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
			headers.setContentLength(fileByte.length);
			headers.setContentDispositionFormData("attachment", "New");
			logger.info("sample file converted to byte...................");
			return new ResponseEntity<>(fileByte, headers, HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return new ResponseEntity<>(null);
	}

	/**
	 * @param orderMaintainList
	 * @param sheet
	 * @param style
	 * @param rowIndex
	 * @param style2
	 */
	private void setValueInExcelSheet(List<Map<String, Object>> orderMaintainList, XSSFSheet sheet, XSSFCellStyle style,
									  int rowIndex, CellStyle style2) {
		for (Map<String, Object> map : orderMaintainList) {
			Object errorMessageValue = null;
			if (map.containsKey(ApplicationConstants.ERROR)) {
				errorMessageValue = map.remove(ApplicationConstants.ERROR);
			}
			Map<String, Object> newMap = new LinkedHashMap<>();
			map.keySet().forEach(key -> newMap.put(key, map.get(key)));
			newMap.put(ApplicationConstants.ERROR, errorMessageValue);

			int columnIndex = ApplicationConstants.ZERO;
			XSSFRow rows = sheet.createRow(rowIndex + 1);
			for (Entry<String, Object> entry : newMap.entrySet()) {
				if (ApplicationUtils.isValidateObject(entry.getValue())) {
					XSSFCell cell = rows.createCell(columnIndex);
					String val = entry.getValue().toString();
					Object errorFields = map.get(ApplicationConstants.ERROR_FIELD);
					if (Boolean.FALSE.equals(entry.getKey().equals("error"))) {
						if (errorFields == null || errorFields.toString().contains(entry.getKey())) {
							cell.setCellStyle(style);
						}else{
							cell.setCellStyle(style2);
						}
					}
					if (entry.getKey().equals(ApplicationConstants.ERROR_FIELD)) {
						continue;
					}
					cell.setCellValue(val);
					columnIndex++;
				}
			}
			rowIndex++;
		}
	}

	/**
	 * @param bulkUploadId
	 * @param associationId
	 * @param userId
	 * @throws IOException
	 */
	@Override
	public void updateUploadStatus(Integer bulkUploadId, Integer associationId, Integer userId, Integer statusId)
			throws IOException {
		BulkUploadHistory bulkUploadHistory = getBulkUploadHistoryById(bulkUploadId, associationId);
		if (ApplicationUtils.isValidateObject(bulkUploadHistory)) {
			updateBulkUploadHistoryStatus(userId, bulkUploadHistory, statusId);
		}

	}

	/**
	 * @return
	 * @throws MalformedURLException
	 * @throws IOException
	 */
	@Override
	public Resource getFileResourceByFileName(String fileName) throws IOException {
		logger.debug("file Name .............{}", fileName);
		uploadedFileName = fileName;
		if (fileName.contains(ApplicationConstants.REPLACE_CONSTANTS)) {
			uploadedFileName = fileName.replace(ApplicationConstants.REPLACE_CONSTANTS, " ");
		}
		dirFile = null;
		logger.info("file path .............{}", environmentProperties.getUploadPath());
		Path filePathDir = Paths.get(environmentProperties.getUploadPath());
		logger.info("file upload file .............{}", uploadedFileName);
		Files.list(filePathDir).forEach(file -> {
			if (file.getFileName().toString().startsWith(uploadedFileName)) {
				dirFile = file;
				return;
            }
		});

		if (dirFile != null) {
			return new UrlResource(dirFile.toUri());
		}
		return null;
	}

}
