package com.ncloud.dl.dao.upload.storage;

import org.springframework.stereotype.Repository;

import com.ncloud.dl.config.common.base.dao.BaseDao;
import com.ncloud.dl.constants.core.TableConstants;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.entity.FileStorage;

/**
 * The Class FileStorageDaoImpl.
 */
@Repository
public class FileStorageDaoImpl extends BaseDao implements IFileStorageDao{
	
	/**
	 * @param fileStorage
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public FileStorage saveFileStorageForRepository(FileStorage fileStorage) throws ApplicationException {
		save(fileStorage, TableConstants.DL_FILE_STORAGE);
		return fileStorage;
	}

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
		
	}

}
