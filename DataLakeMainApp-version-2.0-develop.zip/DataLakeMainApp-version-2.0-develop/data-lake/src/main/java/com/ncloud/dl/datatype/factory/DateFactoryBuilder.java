package com.ncloud.dl.datatype.factory;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.ncloud.dl.constants.core.ApplicationConstants;
import com.ncloud.dl.utils.core.ApplicationUtils;

/**
 * The Class DateFactoryBuilder.
 */
@Qualifier("dateBuilder")
@Service
public class DateFactoryBuilder implements IDataTypeFactoryBuilder{

	/**
	 * Gets the data type with col query.
	 *
	 * @param fieldColName the field col name
	 * @param valQuery the val query
	 * @return the data type with col query
	 */
	@Override
	public String getDataTypeWithColQuery(String fieldColName, String valQuery) {
		return ApplicationUtils.isValidString(valQuery) ? ApplicationConstants.DOUBLE_QUOTES+fieldColName+ApplicationConstants.DOUBLE_QUOTES + ApplicationConstants.DATE + valQuery
				: ApplicationConstants.DOUBLE_QUOTES+fieldColName+ApplicationConstants.DOUBLE_QUOTES + ApplicationConstants.DATE;
	}

}
