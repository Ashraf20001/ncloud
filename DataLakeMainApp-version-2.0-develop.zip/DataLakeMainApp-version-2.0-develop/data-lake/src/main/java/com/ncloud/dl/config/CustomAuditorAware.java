package com.ncloud.dl.config;

import java.util.Optional;

import com.ncloud.dl.utils.core.LoggedInUserContextHolder;
import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;

/**
 * The Class CustomAuditorAware.
 */
@Component
@RequiredArgsConstructor
public class CustomAuditorAware implements AuditorAware<Integer> {

	/** The logged in user context holder. */
	private final LoggedInUserContextHolder loggedInUserContextHolder;
	
	/**
	 * Gets the current auditor.
	 *
	 * @return the current auditor
	 */
	@Override
	public Optional<Integer> getCurrentAuditor() {
		Integer userId = loggedInUserContextHolder.getLoggedInUser().getId();
		return Optional.ofNullable(userId);
	}
}