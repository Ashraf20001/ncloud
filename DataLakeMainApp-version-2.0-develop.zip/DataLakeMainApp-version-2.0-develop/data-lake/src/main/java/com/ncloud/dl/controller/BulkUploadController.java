package com.ncloud.dl.controller;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ncloud.dl.config.base.controller.BaseController;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.service.IBulkUploadService;
import com.ncloud.dl.transfer.object.core.ApplicationResponse;
import com.ncloud.dl.transfer.object.dto.BulkImportHistoryDto;
import com.ncloud.dl.transfer.object.dto.BulkUploadHistoryDto;
import com.ncloud.dl.transfer.object.dto.CustomSortingVo;
import com.ncloud.dl.transfer.object.dto.DataLakeBulkUploadMapDto;
import com.ncloud.dl.transfer.object.dto.SuccessErrorRecordsDto;
import com.ncloud.dl.utils.core.LoggedInUserContextHolder;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

/**
 * {Bulk Upload Page}
 * @author CBT
 *
 */
@RestController
@RequestMapping("/bulk-upload")
@RequiredArgsConstructor
public class BulkUploadController extends BaseController {
	
	/**
	 * LoggedInUserContextHolder
	 */
	private final LoggedInUserContextHolder loggedInUserContextHolder;
	
	/**
	 * iBulkUploadService
	 */
	private final IBulkUploadService iBulkUploadService;
	
	/**
	 * Uploads data to the specified repository.
	 *
	 * @param file               The file to be uploaded.
	 * @param repositoryIdentity Unique identifier for the repository.
	 * @param httpServletRequest HTTP request containing metadata.
	 * @return {@link ApplicationResponse} indicating the status of the upload operation.
	 * @throws IllegalStateException If invalid data is encountered during file upload.
	 * @throws IOException If an error occurs while processing the file.
	 * @throws ApplicationException If a custom application-related error occurs.
	 */
	@ApiOperation(value = "Upload a file to a repository", 
	              notes = "Allows bulk file upload to the specified repository.")
	@PostMapping("/upload-file")
	public ApplicationResponse bulkUploadFileForRepository(@ApiParam(value = "Upload multipart file", required = true) @RequestBody MultipartFile file,
			@ApiParam(value="Repository Identity", required = true) @RequestParam(name= "repositoryIdentity") String repositoryIdentity, HttpServletRequest httpServletRequest) throws IllegalStateException, IOException, ApplicationException {
		return getApplicationResponse(iBulkUploadService.bulkUploadFileForRepository(repositoryIdentity, file,
				loggedInUserContextHolder.getLoggedInUser(), httpServletRequest));
	}
	
	
	/**
	 * Validates the uploaded file by checking for duplicates and errors.
	 *
	 * @param repositoryName   The name of the repository where the file is stored.
	 * @param userId           The ID of the user performing the upload.
	 * @param bulkUploadId     The ID of the bulk upload transaction.
	 * @param dataLakeBulkUploadMapDto The DTO containing file details.
	 * @throws ApplicationException  If a business logic error occurs.
	 * @throws ParseException        If there is an issue parsing the file data.
	 * @throws JsonProcessingException If JSON processing fails.
	 */
	@ApiOperation(value = "Validate uploaded file", 
	              notes = "Checks for duplicates and errors in the uploaded file.")
	@PostMapping("/validate-file")
	public void bulkUploadAddForRepository(
			@ApiParam(value = "Repository Name", required = true) @RequestParam(name = "repositoryName") String repositoryName,
			@ApiParam(value = "User Id", required = true) @RequestParam(name = "userId") Integer userId,
			@ApiParam(value = "Bulk Upload Id", required = true) @RequestParam(name = "bulkUploadId") Integer bulkUploadId,
			@ApiParam(value = "DataLakeBulkUploadMapDto PayLoad Data") @RequestBody DataLakeBulkUploadMapDto dataLakeBulkUploadMapDto)
			throws ApplicationException, ParseException, JsonProcessingException {
		logger.info("data validation initiated starts successfully......................");
		iBulkUploadService.bulkUploadFileValidateFile(repositoryName, dataLakeBulkUploadMapDto,userId, bulkUploadId);
	}
	
	/**
	 * Retrieves a file resource from the storage path based on the provided file name.
	 *
	 * @param fileName The name of the file to fetch.
	 * @return The file resource.
	 * @throws IOException          If an I/O error occurs.
	 * @throws ApplicationException If a business logic error occurs.
	 */
	@ApiOperation(value = "Fetch file resource", 
	              notes = "Retrieves a file resource from storage based on the provided file name.")
	@GetMapping("/get-file-resource")
	public Resource getFilePathByUploadId(
			@ApiParam(value = "Request File Name", required = true) @RequestParam("fileName") String fileName)
			throws IOException, ApplicationException {
		return iBulkUploadService.getFileResourceByFileName(fileName);
	}
	
	/**
	 * Updates the status of a bulk upload process.
	 *
	 * @param userId        The ID of the user requesting the update.
	 * @param bulkUploadId  The ID of the bulk upload transaction.
	 * @param associationId The associated ID (optional).
	 * @param status        The new status value.
	 * @throws IOException If an I/O error occurs.
	 */
	@ApiOperation(value = "Update bulk upload status", 
	              notes = "Updates the status of a bulk upload process based on the provided parameters.")
	@PostMapping("/update-upload-status")
	public void updateUploadStatus(
			@ApiParam(value = "User ID performing the operation", required = true) @RequestParam(name = "userId") Integer userId,
			@ApiParam(value = "Bulk Upload ID", required = true) @RequestParam(name = "bulkUpload") Integer bulkUploadId,
			@ApiParam(value = "Association ID") @RequestParam(name = "associationId", required = false) Integer associationId,
			@ApiParam(value = "New status to be set for the upload", required = true) @RequestParam(name = "status") Integer status)
			throws IOException {
		iBulkUploadService.updateUploadStatus(bulkUploadId, associationId, userId, status);
	}
	
	
	/**
	 * Fetches the bulk upload history based on the repository identity.
	 *
	 * @param repositoryIdentity The unique identity of the repository.
	 * @return A list of bulk import history records.
	 */
	@ApiOperation(value = "Fetch bulk upload history", 
	              notes = "Retrieves the bulk upload history for a specific repository identity.")
	@GetMapping("/upload-history")
	public List<BulkImportHistoryDto> getUploadHistoryDetails(
			@ApiParam(value = "Repository Identity", required = true) @RequestParam(name = "repositoryIdentity") String repositoryIdentity) {
		return iBulkUploadService.getUploadHistoryDetails(repositoryIdentity, loggedInUserContextHolder.getLoggedInUser());
	}
	
	/**
     * Downloads a sample file based on the repository identity.
     *
     * @param repositoryIdentity The unique identifier of the repository.
     * @return A ResponseEntity containing the sample file as bytes.
     * @throws ApplicationException If a business logic error occurs.
     * @throws IOException          If an I/O error occurs.
     */
	@GetMapping("/download-sample-file")
	public ResponseEntity<byte[]> downloadSampleFileForRepository(
			@ApiParam(value = "Repository Identity", required = true) @RequestParam(value = "repositoryIdentity") String repositoryIdentity)
			throws ApplicationException, IOException {
		return iBulkUploadService.downloadSampleFileForRepository(repositoryIdentity);
	}
	
	/**
	 * Retrieves the total number of records for a given bulk upload transaction.
	 *
	 * @param bulkUploadIdentity The unique identifier for the bulk upload.
	 * @return The count of records.
	 * @throws ApplicationException If a business logic error occurs.
	 */
	@ApiOperation(value = "Get total records count", 
	              notes = "Retrieves the total number of records for a given bulk upload transaction.")
	@GetMapping("/total-records-count")
	public BulkUploadHistoryDto getBulkUploadHistoryCountsDetails(
			@ApiParam(value = "Bulk Upload Identity", required = true) @RequestParam String bulkUploadIdentity)
			throws ApplicationException {
		return iBulkUploadService.getBulkUploadHistoryDetails(bulkUploadIdentity);
	}	
	
	/**
	 * Retrieves a paginated list of success and error records for a bulk upload.
	 *
	 * @param uploadIdentity   The unique identifier for the upload.
	 * @param status           The status filter (success or error).
	 * @param skip             The number of records to skip (pagination).
	 * @param limit            The maximum number of records to return.
	 * @param customSortingVo  The sorting parameters.
	 * @return An ApplicationResponse containing the filtered records.
	 * @throws ApplicationException If a business logic error occurs.
	 */
	@ApiOperation(value = "Get paginated success/error records",
	              notes = "Fetches a paginated list of success and error records for a bulk upload, filtered by status.")
	@PostMapping("/success-error-records/list")
	public ApplicationResponse getSuccessErrorRecords(
			@ApiParam(value = "Upload Identity", required = true) @RequestParam(name = "uploadIdentity") String uploadIdentity,
			@ApiParam(value = "Upload Status", required = true) @RequestParam(name = "status") String status,
			@ApiParam(value = "Number of records to skip") @RequestParam(name = "skip", required = false) Integer skip,
			@ApiParam(value = "Maximum number of records to return") @RequestParam(name = "limit", required = false) Integer limit,
			@ApiParam(value = "List of CustomSortingVo Request", required = true) @RequestBody List<CustomSortingVo> customSortingVo)
			throws ApplicationException {
		SuccessErrorRecordsDto repsonse = iBulkUploadService.getSuccessErrorRecords(uploadIdentity,
				Boolean.parseBoolean(status), customSortingVo, skip, limit);
		return getApplicationResponse(repsonse);
	}
	
	/**
	 * Retrieves the count of success and error records for a bulk upload.
	 *
	 * @param uploadIdentity   The unique identifier for the upload.
	 * @param status           The status filter (true for success, false for error).
	 * @param skip             The number of records to skip (optional, for pagination).
	 * @param limit            The maximum number of records to return (optional).
	 * @param customSortingVo  The sorting parameters (optional).
	 * @return An ApplicationResponse containing the count of records.
	 * @throws ApplicationException If a business logic error occurs.
	 */
	@ApiOperation(value = "Get count of success/error records",
	              notes = "Returns the count of success and error records for a bulk upload, filtered by status.")
	@PostMapping("/success-error-records/count")
	public ApplicationResponse getSuccessErrorRecordsCount(
			@ApiParam(value = "Unique identifier for the upload", required = true) @RequestParam(name = "uploadIdentity") String uploadIdentity,
			@ApiParam(value = "Status of records", required = true) @RequestParam(name = "status") String status,
			@ApiParam(value = "Number of records to skip") @RequestParam(name = "skip", required = false) Integer skip,
			@ApiParam(value = "Maximum number of records to return") @RequestParam(name = "limit", required = false) Integer limit,
			@ApiParam(value = "Sorting for fetching records") @RequestBody List<CustomSortingVo> customSortingVo)
			throws ApplicationException {
		Long repsonse = iBulkUploadService.getSuccessErrorRecordsCount(uploadIdentity,
				Boolean.parseBoolean(status), customSortingVo, skip, limit);
		return getApplicationResponse(repsonse);
	}
	

	/**
	 * Downloads success and error records as an Excel file for a given upload identity.
	 *
	 * @param uploadIdentity The unique identifier for the bulk upload.
	 * @param status         The status filter: true for success, false for error.
	 * @param limit          The maximum number of records to include in the Excel file.
	 * @return A ResponseEntity containing the success/error records as an Excel file.
	 * @throws ApplicationException If a business logic error occurs.
	 */
	@ApiOperation(value = "Download success/error records",
	              notes = "Generates and downloads an Excel file containing success/error records based on upload identity and status.")
	@GetMapping("/success-error-records/download")
	public ResponseEntity<byte[]> getSuccessErrorRecordsDownload(
			@ApiParam(value = "Unique identifier for the upload", required = true) @RequestParam(name = "uploadIdentity") String uploadIdentity,
			@ApiParam(value = "Status of records", required = true) @RequestParam(name = "status") String status,
			@ApiParam(value = "Maximum number of records to return", required = true) @RequestParam(name = "limit") Integer limit)
			throws ApplicationException {
		List<CustomSortingVo> customSortingVo = null;
		Integer skip = 0;
		SuccessErrorRecordsDto repsonse = iBulkUploadService.getSuccessErrorRecords(uploadIdentity,
				Boolean.parseBoolean(status), customSortingVo, skip, limit);
		ResponseEntity<byte[]> successErrorList =iBulkUploadService.downloadExcel(repsonse);
		return successErrorList;
	}
	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}

	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	@Override
	protected void registerInterceptor() {
		
	}
	
}
