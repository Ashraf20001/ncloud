package com.ncloud.dl.datatype.factory;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.ncloud.dl.constants.core.ApplicationConstants;
import com.ncloud.dl.utils.core.ApplicationUtils;

/**
 * The Class NumberFactoryBuilder.
 */
@Qualifier("numberBuilder")
@Service
public class NumberFactoryBuilder implements IDataTypeFactoryBuilder{
	
	/**
	 * Gets the data type with col query.
	 *
	 * @param fieldColName the field col name
	 * @param fldQuery the fld query
	 * @return the data type with col query
	 */
	@Override
	public String getDataTypeWithColQuery(String fieldColName, String fldQuery) {
		return ApplicationUtils.isValidString(fldQuery) ? ApplicationConstants.DOUBLE_QUOTES+fieldColName+ApplicationConstants.DOUBLE_QUOTES + ApplicationConstants.VARCHAR + fldQuery
				: ApplicationConstants.DOUBLE_QUOTES+fieldColName+ApplicationConstants.DOUBLE_QUOTES + ApplicationConstants.VARCHAR;
	}

}
