package com.ncloud.dl.datatype.factory;

import java.util.HashMap;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.ncloud.dl.constants.core.QueryConstants.ColumnConstants;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.exception.core.codes.ErrorCodes;
import com.ncloud.dl.transfer.object.entity.FieldConfiguration;
import com.ncloud.dl.utils.core.ApplicationUtils;

/**
 * The Class NumberFactoryValidationBuilder.
 */
@Service
@Qualifier("numberFactoryValidationBuilder")
public class NumberFactoryValidationBuilder implements IDataTypeFactoryValidationBuilder {

	/**
	 * @param errorMsg
	 * @param entry
	 * @param mandatory
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public String getDataTypeValidationBuilder(String errorMsg, Entry<String, Object> entry, Boolean mandatory,
			HashMap<String, Object> successRecord, FieldConfiguration fieldConfig) throws ApplicationException {

		if (ApplicationUtils.isBlank(entry.getValue().toString())
				&& (mandatory.equals(Boolean.TRUE))) {
			throw new ApplicationException(ErrorCodes.MANDATORY_FIELDS);
		}
		if(Boolean.FALSE.equals(ApplicationUtils.isValidNumber(entry.getValue().toString()))){
			throw new ApplicationException(ErrorCodes.NUMBER_FIELD_INVALID);
		}
		successRecord.put(fieldConfig.getColumnName(), entry.getValue());
		successRecord.put(ColumnConstants.STATUS, Boolean.FALSE);
		return entry.getValue().toString();
	}
}
