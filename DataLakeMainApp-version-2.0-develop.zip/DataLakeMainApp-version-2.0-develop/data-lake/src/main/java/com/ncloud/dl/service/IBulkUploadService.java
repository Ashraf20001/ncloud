package com.ncloud.dl.service;

import java.io.IOException;
import java.net.MalformedURLException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.BulkImportTriggerConsumerDto;
import com.ncloud.dl.transfer.object.dto.BulkImportHistoryDto;
import com.ncloud.dl.transfer.object.dto.BulkUploadHistoryDto;
import com.ncloud.dl.transfer.object.dto.CustomSortingVo;
import com.ncloud.dl.transfer.object.dto.DataLakeBulkUploadMapDto;
import com.ncloud.dl.transfer.object.dto.SuccessErrorRecordsDto;
import com.ncloud.dl.transfer.object.dto.UserInfo;

/**
 * The Interface IBulkUploadService.
 */
public interface IBulkUploadService {

	/**
	 * @param repositoryIdentity
	 * @return
	 * @throws IOException
	 */
	ResponseEntity<byte[]> downloadSampleFileForRepository(String repositoryIdentity) throws IOException;
	
	/**
	 * @param repositoryIdentity 
	 * @param loggedInUser
	 * @return
	 */
	List<BulkImportHistoryDto> getUploadHistoryDetails(String repositoryIdentity, UserInfo loggedInUser);

	/**
	 * @param bulkUploadHistoryDto
	 * @return
	 * @throws ApplicationException 
	 */
	BulkUploadHistoryDto getBulkUploadHistoryDetails(String bulkUploadIdentity) throws ApplicationException;


	/**
	 * @param repositoryIdentity
	 * @param file
	 * @param userInfo 
	 * @param httpServletRequest 
	 * @return 
	 * @throws IOException 
	 * @throws IllegalStateException 
	 * @throws ApplicationException 
	 */
	String bulkUploadFileForRepository(String repositoryIdentity, MultipartFile file, UserInfo userInfo, HttpServletRequest httpServletRequest) throws IllegalStateException, IOException, ApplicationException;

	/**
	 * @param bulkUploadId
	 * @param userId 
	 * @param userInfo 
	 * @return
	 * @throws IOException 
	 */
	BulkImportTriggerConsumerDto getFileNameForRepository(Integer bulkUploadId, Integer associationId, Integer userId) throws IOException;
	
	/**
	 * @param uploadIdentity
	 * @param status
	 * @param customSortingVo
	 * @param skip
	 * @param limit
	 * @return
	 * @throws ApplicationException
	 */
	SuccessErrorRecordsDto getSuccessErrorRecords(String uploadIdentity, Boolean status,
			List<CustomSortingVo> customSortingVo, Integer skip, Integer limit) throws ApplicationException;

	/**
	 * @param uploadIdentity
	 * @param parseBoolean
	 * @param customSortingVo
	 * @param skip
	 * @param limit
	 * @return
	 * @throws ApplicationException 
	 */
	Long getSuccessErrorRecordsCount(String uploadIdentity, Boolean parseBoolean,
			List<CustomSortingVo> customSortingVo, Integer skip, Integer limit) throws ApplicationException;

	/**
	 * @param repsonse
	 * @return
	 */
	ResponseEntity<byte[]> downloadExcel(SuccessErrorRecordsDto repsonse);

	/**
	 * @param repositoryName
	 * @param dataLakeBulkUploadMapDto
	 * @throws ApplicationException
	 * @throws ParseException
	 * @throws JsonProcessingException 
	 */
	void bulkUploadFileValidateFile(String repositoryName, DataLakeBulkUploadMapDto dataLakeBulkUploadMapDto, Integer userInfo,
			Integer bulkUploadId) throws ApplicationException, ParseException, JsonProcessingException;

	/**
	 * @param bulkUploadId
	 * @param associationId
	 * @param userId
	 * @param status 
	 * @throws IOException 
	 */
	void updateUploadStatus(Integer bulkUploadId, Integer associationId, Integer userId, Integer status) throws IOException;

	/**
	 * @param fieldConfiguration 
	 * @param failRecord2 
	 * @param successRecord 
	 * @param repositoryIdentity
	 * @param singleAddRepositoryDto
	 * @throws ApplicationException 
	 * @throws ParseException 
	 * @throws JsonProcessingException 
	 */
	String singleRecordForRepository(String repositoryName, HashMap<String, Object> singleAddRepository)
			throws ApplicationException, ParseException, JsonProcessingException;

	/**
	 * @param uploadId
	 * @return
	 * @throws MalformedURLException 
	 * @throws IOException 
	 */
	Resource getFileResourceByFileName(String fileName) throws IOException;


}
