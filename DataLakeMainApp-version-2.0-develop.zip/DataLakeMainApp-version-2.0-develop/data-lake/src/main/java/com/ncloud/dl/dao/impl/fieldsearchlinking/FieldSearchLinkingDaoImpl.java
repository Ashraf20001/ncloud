package com.ncloud.dl.dao.impl.fieldsearchlinking;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.ncloud.dl.config.common.base.dao.BaseDao;
import com.ncloud.dl.constants.core.TableConstants;
import com.ncloud.dl.dao.fieldsearchlinking.IFieldSearchLinkingDao;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.entity.FieldConfiguration;
import com.ncloud.dl.transfer.object.entity.FieldSearchLinking;


/**
 * The Class FieldSearchLinkingDaoImpl.
 */
@Repository
public class FieldSearchLinkingDaoImpl extends BaseDao implements IFieldSearchLinkingDao{

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
		
	}

	/**
	 * fieldSearchLinking.
	 *
	 * @param fieldSearchLinking the field search linking
	 * @return the field search linking
	 * @throws ApplicationException the application exception
	 */
	@Override
	public FieldSearchLinking saveFieldSearchLinking(FieldSearchLinking fieldSearchLinking)
			throws ApplicationException {
		save(fieldSearchLinking, TableConstants.FIELD_SEARCH_LINK);
		return fieldSearchLinking;
	}

	/**
	 * Update field search linking.
	 *
	 * @param fieldSearchLinking the field search linking
	 */
	@Override
	public void updateFieldSearchLinking(FieldSearchLinking fieldSearchLinking) {
		update(fieldSearchLinking);
	}

	/**
	 * Gets the field search linking.
	 *
	 * @param fieldConfiguration the field configuration
	 * @return the field search linking
	 */
	@Override
	public FieldSearchLinking getFieldSearchLinking(FieldConfiguration fieldConfiguration) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<FieldSearchLinking> createQuery = builder.createQuery(FieldSearchLinking.class);
		Root<FieldSearchLinking> root = createQuery.from(FieldSearchLinking.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETE_STS), false)));
		predicates.add(builder.and(builder.equal(root.get("fieldId"), fieldConfiguration)));
		return (FieldSearchLinking) getSingleResult(createQuery(builder, createQuery, root, predicates));
	}

}
