package com.ncloud.dl.dao.fieldsearchlinking;

import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.entity.FieldConfiguration;
import com.ncloud.dl.transfer.object.entity.FieldSearchLinking;

public interface IFieldSearchLinkingDao {

	/**
	 * @param fieldSearchLinking
	 * @return 
	 * @throws ApplicationException 
	 */
	FieldSearchLinking saveFieldSearchLinking(FieldSearchLinking fieldSearchLinking) throws ApplicationException;

	/**
	 * @param fieldSearchLinking
	 */
	void updateFieldSearchLinking(FieldSearchLinking fieldSearchLinking);

	/**
	 * @param fieldConfiguration
	 * @return
	 */
	FieldSearchLinking getFieldSearchLinking(FieldConfiguration fieldConfiguration);

}