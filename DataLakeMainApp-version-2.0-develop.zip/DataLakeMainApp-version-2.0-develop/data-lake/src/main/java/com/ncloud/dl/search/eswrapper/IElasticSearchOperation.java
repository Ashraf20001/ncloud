package com.ncloud.dl.search.eswrapper;

import java.io.IOException;

import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.core.CountRequest;

/**
 * The Interface IElasticSearchOperation.
 */
public interface IElasticSearchOperation {

	/**
	 * Search.
	 *
	 * @param searchRequest the search request
	 * @param options the options
	 * @return the i search response
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	ISearchResponse search(SearchRequest searchRequest, RequestOptions options) throws IOException ;
	
	/**
	 * Indices.
	 *
	 * @return the i indices client
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	IIndicesClient indices() throws IOException ;

	/**
	 * Count.
	 *
	 * @param countRequest the count request
	 * @param options the options
	 * @return the count response object
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	CountResponseObject count(CountRequest countRequest, RequestOptions options) throws IOException;
				
}
