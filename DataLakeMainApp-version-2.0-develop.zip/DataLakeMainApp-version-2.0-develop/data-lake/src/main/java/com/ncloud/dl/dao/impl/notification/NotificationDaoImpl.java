package com.ncloud.dl.dao.impl.notification;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.ncloud.dl.config.common.base.dao.BaseDao;
import com.ncloud.dl.constants.core.TableConstants;
import com.ncloud.dl.dao.notification.INotificationDao;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.entity.NotificationEvent;
import com.ncloud.dl.transfer.object.entity.NotificationTemplate;
import com.ncloud.dl.transfer.object.entity.RepositoryNotification;

/**
 * The Class NotificationDaoImpl.
 */
@Repository
public class NotificationDaoImpl extends BaseDao implements INotificationDao {

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
	}


	/**
	 * Fetch Notification Event by event name.
	 * @param stockPurchase
	 * @return
	 */
	@Override
	public NotificationEvent getNotificationevent(String stockPurchase) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<NotificationEvent> criteria = builder.createQuery(NotificationEvent.class);
		Root<NotificationEvent> root = criteria.from(NotificationEvent.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.STOCK_EVENT_NAME), stockPurchase)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		return (NotificationEvent) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst()
				.orElse(null);
	}

	/**
	 * Fetch Notification template
	 * @param notificationEventData
	 * @return
	 */
	@Override
	public NotificationTemplate getNotificationTemplate(NotificationEvent notificationEventData,String action) {
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<NotificationTemplate> criteria = builder.createQuery(NotificationTemplate.class);
        Root<NotificationTemplate> root = criteria.from(NotificationTemplate.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.NOTIFICATION_EVENT), notificationEventData.getEventId())));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.NOTIFICATION_EVENT).get(TableConstants.ISDELETED),false)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.STATE), action)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETE_STS), Boolean.FALSE)));
        return (NotificationTemplate) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);		
	}

	/**
	 * Save Notification details.
	 * @param {@link RepositoryNotification}
	 */
	@Override
	public void saveNotificationDetails(RepositoryNotification notification) throws ApplicationException {
		save(notification, TableConstants.REPOSITROY_NOTIFICATION);
		
	}

}
