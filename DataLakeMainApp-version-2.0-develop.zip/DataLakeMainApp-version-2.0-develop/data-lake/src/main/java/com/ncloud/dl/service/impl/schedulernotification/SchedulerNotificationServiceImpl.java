package com.ncloud.dl.service.impl.schedulernotification;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.ncloud.dl.dao.schedulernotification.ISchedulerNotificationDao;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.exception.core.codes.ErrorCodes;
import com.ncloud.dl.service.ISchedulerNotificationService;
import com.ncloud.dl.transfer.object.dto.RepositoryScheduleDto;
import com.ncloud.dl.transfer.object.entity.SchedulerNotification;
import com.ncloud.dl.transfer.object.enums.RepositoryStatusEnum;
import com.ncloud.dl.utils.core.ApplicationUtils;

import lombok.RequiredArgsConstructor;

/**
 * The Class SchedulerNotificationServiceImpl.
 */
@Service
@Transactional(rollbackOn = Exception.class)
@RequiredArgsConstructor
public class SchedulerNotificationServiceImpl implements ISchedulerNotificationService {

	/** The scheduler notification dao. */
	private final ISchedulerNotificationDao schedulerNotificationDao;

	/**
	 * Gets the repository schedule details by repository identity.
	 *
	 * @param repositoryIdentity the repository identity
	 * @return the repository schedule details by repository identity
	 * @throws ApplicationException the application exception
	 */
	@Override
	public RepositoryScheduleDto getRepositoryScheduleDetailsByRepositoryIdentity(String repositoryIdentity)
			throws ApplicationException {
		if(!ApplicationUtils.isValidIdentity(repositoryIdentity)) {
			throw new ApplicationException(ErrorCodes.INVALID_REPOSITORY_IDENTITY);
		}
		SchedulerNotification schedulerNotification = schedulerNotificationDao.getSchedulerNotificationbyRepositoryIdentityDetails(repositoryIdentity);
		if(!ApplicationUtils.isValidateObject(schedulerNotification)) {
			throw new ApplicationException(ErrorCodes.INVALID_REPOSITORY_IDENTITY);
		}
        return new RepositoryScheduleDto(
				schedulerNotification.getRepositoryId().getRepositoryName(),
				schedulerNotification.getMessage(),
				schedulerNotification.getStatus(),
				schedulerNotification.getRepositoryId().getRepoStatus().equals(RepositoryStatusEnum.APPROVED.getStatusId())
				);
	}

}
