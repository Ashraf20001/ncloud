package com.ncloud.dl.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ncloud.dl.config.base.controller.BaseController;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.service.IRepositoryNotificationService;
import com.ncloud.dl.transfer.object.core.ApplicationResponse;
import com.ncloud.dl.utils.core.LoggedInUserContextHolder;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class RepositoryNotificationController extends BaseController {

	/**
	 * {@link IRepositoryNotificationService}
	 */
	private final IRepositoryNotificationService repositoryNotificationService;
	
	/**
	 * {@link LoggedInUserContextHolder}
	 */
	private final LoggedInUserContextHolder loggedInUserContextHolder;
	
	/**
	 * Retrieves the count of unread notifications for the logged-in user.
	 *
	 * @param httpServletRequest The HTTP request containing user session details.
	 * @return An ApplicationResponse containing the unread notification count.
	 * @throws ApplicationException If a business logic error occurs.
	 */
	@ApiOperation(value = "Get Unread Notification Count", 
	              notes = "Retrieves the count of unread notifications for the user.",
	              response = ApplicationResponse.class)
	@GetMapping("/get-notification-Count")
	public ApplicationResponse getUnReadNotificationsCount(HttpServletRequest httpServletRequest)
			throws ApplicationException {
		return getApplicationResponse(repositoryNotificationService.getUnReadNotificationsCount(httpServletRequest));
	}

	/**
	 * Marks a notification as read based on the notification identity.
	 *
	 * @param identity The unique identifier of the notification.
	 * @return An ApplicationResponse indicating the success or failure of the operation.
	 * @throws ApplicationException If a business logic error occurs.
	 */
	@ApiOperation(value = "Mark Notification as Read", 
	              notes = "Marks a specific notification as read using its unique identity.",
	              response = ApplicationResponse.class)
	@RequestMapping("/update-notification-unread")
	public ApplicationResponse getUnReadUpdateNotifications(
			@ApiParam(value = "Notification Unique Identifier", required = true) @RequestParam("identity") String identity)
			throws ApplicationException {
		return getApplicationResponse(repositoryNotificationService.markAsReadNotification(identity, loggedInUserContextHolder.getLoggedInUser()));
	}

	/**
	 * Fetches unread notifications.
	 *
	 * @param isViewAllNotifications A flag indicating whether to fetch all notifications or only unread ones.
	 * @param httpServletRequest     The HTTP request object for additional context.
	 * @return An ApplicationResponse containing the list of unread notifications.
	 * @throws ApplicationException If a business logic error occurs.
	 */
	@ApiOperation(value = "Fetch Unread Notifications",
	              notes = "Retrieves unread notifications. If 'isViewAllNotifications' is true, all notifications are fetched.",
	              response = ApplicationResponse.class)
	@GetMapping("/notification")
	public ApplicationResponse getUnReadNotifications(
			@ApiParam(value = "All notification viewed Status", required = true) @RequestParam(name = "isViewAllNotifications") String isViewAllNotifications,
			HttpServletRequest httpServletRequest) throws ApplicationException {
		Boolean parsedBoolean = Boolean.parseBoolean(isViewAllNotifications);
		return getApplicationResponse(
				repositoryNotificationService.getUnReadNotifications(parsedBoolean, httpServletRequest));
	}
	
	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}

	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	@Override
	protected void registerInterceptor() {

	}
}
