package com.ncloud.dl.impl.service;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.transaction.Transactional;

import org.apache.poi.ss.formula.functions.T;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ncloud.dl.constants.core.ApplicationConstants;
import com.ncloud.dl.dao.mdm.IDataLakeExportImportDao;
import com.ncloud.dl.datatype.factory.DLEntityTableMappingFactory;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.exception.core.codes.ErrorCodes;
import com.ncloud.dl.service.IDataLakeMDMService;
import com.ncloud.dl.transfer.object.entity.TableEntityMapping;
import com.ncloud.dl.utils.core.ApplicationUtils;

import lombok.RequiredArgsConstructor;

/**
 * Service layer to manage business logic of {Export and Import}
 * @author CBT
 *
 */
@Service
@Transactional
@RequiredArgsConstructor
public class DataLakeManageDataServiceImpl implements IDataLakeMDMService {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(DataLakeManageDataServiceImpl.class);
	
	/**
	 * Inject instance of IDataLakeExportImportDao{DAO}.
	 */
	private final IDataLakeExportImportDao iExportImportDao;
	
	/**
	 *	Inject factory-method for mapping tablename and Entity class.
	 */
	private final DLEntityTableMappingFactory entityTableMappingFactory;

	/**
	 * Export the master data by table-name from environment.
	 * 
	 * @param tableNames {@link List} of {@link String} containing table names.
	 * @return {@link List} of {@link Map}<{@link String}, {@link Object}> where
	 *         each map entry has: - Key: Table name as {@link String}. - Value:
	 *         Corresponding table master data as {@link Object}.
	 */
	@Override
	public List<Map<String, Object>> exportMasterDatas(List<String> masterDataDtoList) throws IOException {
		List<Map<String, Object>> listOfMasterData = new ArrayList<>();
		System.out.println();
		for (String tableName : masterDataDtoList.stream().distinct().collect(Collectors.toList())) {
			List<Map<String, Object>> entityDatas = iExportImportDao.getListOfMasterDatas(tableName);
			Map<String, Object> entityMap = new HashMap<>();
			entityMap.put(ApplicationConstants.DATA_LAKE_ + tableName, entityDatas);
			listOfMasterData.add(entityMap);
		}
		return listOfMasterData;
	}


	/**
	 * Exported *.json file will imported in common platform through rest template
	 * service data lake master data's will be insert or updated
	 * 
	 * @param {@link Map}<{@link String}, {@link Object}> Based on Key get Platform Master data
	 */
	@Override
	public void importMasterData(Map<String, Object> recoveryMasterDataMap) throws IOException, ApplicationException {
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> recoveryMasterMapList = (List<Map<String, Object>>) recoveryMasterDataMap
				.get(ApplicationConstants.PLATFORM_TABLES);
		if(!ApplicationUtils.isValidList(recoveryMasterMapList)) {
			throw new ApplicationException(ErrorCodes.INVALID_RECOVERY_MDM);
		}
		Boolean isOverride = Boolean
				.parseBoolean(String.valueOf(recoveryMasterDataMap.get(ApplicationConstants.IS_OVERRIDE)));
		ObjectMapper objectMapper = new ObjectMapper();
		List<TableEntityMapping> tableEntityMappings = objectMapper
				.convertValue(recoveryMasterDataMap.get("tableEntity"), new TypeReference<List<TableEntityMapping>>() {
				});
		for (Map<String, Object> recoveryPlatformData : recoveryMasterMapList) {
			//Extract the table from Map example: recovery.platform
			String keyTableName = recoveryPlatformData.entrySet().stream().map(Map.Entry::getKey)
					.map(key -> key.contains(".") ? key.substring(key.lastIndexOf(".") + 1) : key).findFirst()
					.orElse(null);
			List<String> parentTableNames = tableEntityMappings.stream().map(TableEntityMapping::getTableName)
					.map(a -> a.contains(".") ? a.substring(a.lastIndexOf(".") + 1) : a).collect(Collectors.toList());
			String tableName = recoveryPlatformData.keySet().stream()
					.map(key -> key.contains(".") ? key.substring(key.lastIndexOf(".") + 1) : key)
					.filter(key -> !parentTableNames.stream().anyMatch(key::contains)).findFirst().orElse(null);
			if (Boolean.FALSE.equals(isOverride)) {
				iExportImportDao.wipeAndInsterTableByTableName(keyTableName);
			}
			saveOrUpdatePlatformMDM(isOverride, recoveryPlatformData, tableName);
		}
	}

	/**
	 * Saves or updates tables, including those with and without joins.
	 * @param isOverride
	 * @param recoveryPlatformData
	 * @param tableName
	 * @throws JsonProcessingException
	 * @throws JsonMappingException
	 * @throws ApplicationException
	 */
	private void saveOrUpdatePlatformMDM(Boolean isOverride, Map<String, Object> recoveryPlatformData, String tableName)
			throws JsonProcessingException, JsonMappingException, ApplicationException {
		if (ApplicationUtils.isValidString(tableName)) {
			extractMasterDataAndSave(recoveryPlatformData, tableName, isOverride);
		} else {
			extractMasterTableWithJoinColumn(recoveryPlatformData,
					recoveryPlatformData.entrySet().stream().map(Map.Entry::getKey)
							.map(key -> key.contains(".") ? key.substring(key.lastIndexOf(".") + 1) : key)
							.findFirst().orElse(null),
					isOverride);
		}
	}

	/**
	 * Validate the @joinColumn and @Id columns in table for Save/Update
	 * @param insertMasterData
	 * @param tableName
	 * @param isOverride
	 * @throws JsonProcessingException
	 * @throws JsonMappingException
	 * @throws ApplicationException
	 */
	@SuppressWarnings("unchecked")
	private void extractMasterTableWithJoinColumn(Map<String, Object> insertMasterData, String tableName,
			Boolean isOverride) throws JsonProcessingException, JsonMappingException, ApplicationException {
		Class<T> entityName = entityTableMappingFactory.getEntityNameByTableName(tableName);
		String userRoleMapping = entityName.getSimpleName();
		String parentTable = insertMasterData.entrySet().stream().map(Map.Entry::getKey).findFirst().orElse(null);
		List<Object> entityDatas = (List<Object>) insertMasterData.get(parentTable);
		for (Object singleEntity : entityDatas) {
			Map<String, Object> childObject = new HashMap<>();
			List<Integer> childObjectIds = new ArrayList<>();
			Map<String, Object> castedData = (Map<String, Object>) singleEntity;
			Integer childObjectId = null;
			String joinColumnName = null;
			for (Field field : entityName.getDeclaredFields()) {
				//reflect to check Id annotation is present
				if (field.isAnnotationPresent(Id.class)) {
					Column tableFieldName = field.getAnnotation(Column.class);
					joinColumnName = tableFieldName.name();
					childObjectId = Integer.parseInt(castedData.get(joinColumnName).toString());
				}
				//reflect to check join column annotation is present
				if (field.isAnnotationPresent(JoinColumn.class)) {
					Class<T> refEntity = (Class<T>) field.getType();
					String columnName = ApplicationUtils.getPrimaryIdColumn(refEntity);
					String entityColumnNameParent = ApplicationUtils.getJoinColumnNameReflect(field);
					if (ApplicationUtils.isValidateObject(castedData.get(entityColumnNameParent))) {
						Integer joinPrimaryId = Integer.parseInt(castedData.get(entityColumnNameParent).toString());
						String childTableName = ApplicationUtils.getEntityName(refEntity);
						childObject = iExportImportDao.getMapResultByPrimaryId(childTableName, columnName,
								joinPrimaryId);
						Integer childPrimaryId = ApplicationUtils.isValidateObject(childObject)
								? Integer.parseInt(childObject.get(columnName).toString())
								: null;
						if(userRoleMapping.equals(ApplicationConstants.USER_ROLE_MAPPING)) {
							joinColumnName = columnName;
							childObjectId = joinPrimaryId;
						}
						childObjectIds.add(childPrimaryId);
						logger.info("Existing Join Column Object :: {}", childObject);
					}
				}
			}
			// check anyone of join column have invalid data
			Boolean ishaveNullChild = childObjectIds.stream().anyMatch(a -> a == null);
			if (Boolean.TRUE.equals(ishaveNullChild)) {
				continue;
			}
			saveOrUpdateMDM(tableName, isOverride, singleEntity, castedData, childObjectId, joinColumnName);
		}
	}
	
	/**
	 * Fetch the Existing data By @Id for Update, When @Param isOverride is true.
	 * OrElse
	 * Insert Data in database environment, When @Param isOverride is false.
	 * @param tableName
	 * @param isOverride
	 * @param singleEntity
	 * @param castedData
	 * @param childObjectId
	 * @param tableFieldName
	 * @throws ApplicationException
	 */
	private void saveOrUpdateMDM(String tableName, Boolean isOverride, Object singleEntity,
			Map<String, Object> castedData, Integer childObjectId, String joinColumnName) throws ApplicationException {
		Map<String, Object> existingValue;
		if (Boolean.TRUE.equals(isOverride)) {
			existingValue = iExportImportDao.getMapResultByPrimaryId(tableName, joinColumnName,
					childObjectId);
			if (ApplicationUtils.isValidateObject(existingValue)) {
				iExportImportDao.updateDynamicRecord(tableName, castedData, joinColumnName,
						existingValue.get(joinColumnName));
				logger.info("Override Existing data with updated Values:: {}", castedData);
			} else {
				iExportImportDao.saveMasterDataNativeQuery(castedData, tableName);
				logger.info("Override have insert data:: {}", castedData);
			}
		} else {
			iExportImportDao.saveMasterDataNativeQuery(castedData, tableName);
			logger.info("Insert Master Data with JoinTable ::{}", singleEntity);
		}
	}

	/**
	 * Extract DataLake Data from Map for SAVE or UPDATE
	 * For update we need validate existing master data isPresent.
	 * For save insert data without any validation.
	 * @param insertMasterData
	 * @param tableName
	 * @param isIdentity
	 * @param isOverride 
	 * @throws JsonProcessingException
	 * @throws JsonMappingException
	 * @throws ApplicationException
	 */
	@SuppressWarnings("unchecked")
	private void extractMasterDataAndSave(Map<String, Object> insertMasterData, String tableName, Boolean isOverride)
			throws JsonProcessingException, JsonMappingException, ApplicationException {
		Class<T> entityName = entityTableMappingFactory.getEntityNameByTableName(tableName);
		List<Map<String, Object>> recoveryListDatas = (List<Map<String, Object>>) insertMasterData
				.get("datalake." + tableName);
		for (Map<String, Object> recoveryEntity : recoveryListDatas) {
			if (Boolean.TRUE.equals(isOverride)) {
				Map<String, Object> existingValue = new HashMap<>();
				String idColumnName = ApplicationConstants.EMPTY_STRING;
				Field idField = Arrays.stream(entityName.getDeclaredFields())
						.filter(field -> field.isAnnotationPresent(Id.class)).findFirst().orElse(null);
				if (ApplicationUtils.isValidateObject(idField)) {
					Column primaryIdTableColName = idField.getAnnotation(Column.class);
					idColumnName = primaryIdTableColName.name();
					existingValue = iExportImportDao.getMapResultByPrimaryId(tableName, idColumnName,
							Integer.parseInt(String.valueOf(recoveryEntity.get(idColumnName))));
					logger.info("Existing Data from Corresponding table :: {}", existingValue);
				}
				if (ApplicationUtils.isValidateObject(existingValue)) {
					iExportImportDao.updateDynamicRecord(tableName, recoveryEntity, idColumnName,
							existingValue.get(idColumnName));
					logger.info("Override MDM recovery :: {}", recoveryEntity);
				} else {
					iExportImportDao.saveMasterDataNativeQuery(recoveryEntity, tableName);
					logger.info("Override-Insert MDM recovery :: {}", recoveryEntity);
				}
			} else {
				logger.info("Insert MDM recovery :: {}", recoveryEntity);
				iExportImportDao.saveMasterDataNativeQuery(recoveryEntity, tableName);
			}
		}

	}
		
}
