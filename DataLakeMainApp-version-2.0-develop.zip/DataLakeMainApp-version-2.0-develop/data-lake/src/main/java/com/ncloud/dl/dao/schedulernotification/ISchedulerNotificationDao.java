package com.ncloud.dl.dao.schedulernotification;

import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.entity.SchedulerNotification;

/**
 * The Interface ISchedulerNotificationDao.
 */
public interface ISchedulerNotificationDao {

	/**
	 * Save scheduler notification.
	 *
	 * @param schedulerNotification the scheduler notification
	 * @return the scheduler notification
	 * @throws ApplicationException the application exception
	 */
	SchedulerNotification saveSchedulerNotification(SchedulerNotification schedulerNotification) throws ApplicationException;
	
	/**
	 * Gets the scheduler notification by repository identity.
	 *
	 * @param repositoryIdentity the repository identity
	 * @return the scheduler notification by repository identity
	 */
	SchedulerNotification getSchedulerNotificationByRepositoryIdentity(String repositoryIdentity);

	/**
	 * @param schedulerNotification
	 */
	void saveUpdateSchedulerNotification(SchedulerNotification schedulerNotification);

	/**
	 * @param schedulerIdentity
	 * @return
	 */
	SchedulerNotification getSchedulerNotificationbyRepositoryIdentityDetails(String schedulerIdentity);
}
