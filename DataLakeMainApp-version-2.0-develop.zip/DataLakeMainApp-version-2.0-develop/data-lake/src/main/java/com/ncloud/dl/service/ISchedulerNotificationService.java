package com.ncloud.dl.service;

import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.dto.RepositoryScheduleDto;

/**
 * The Interface ISchedulerNotificationService.
 */
public interface ISchedulerNotificationService {

	/**
	 * Gets the repository schedule details by repository identity.
	 *
	 * @param repositoryIdentity the repository identity
	 * @return the repository schedule details by repository identity
	 * @throws ApplicationException the application exception
	 */
	RepositoryScheduleDto getRepositoryScheduleDetailsByRepositoryIdentity(String repositoryIdentity) throws ApplicationException;
}
