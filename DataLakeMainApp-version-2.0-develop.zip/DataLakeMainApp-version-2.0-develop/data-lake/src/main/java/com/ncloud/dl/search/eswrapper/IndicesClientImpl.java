package com.ncloud.dl.search.eswrapper;

import java.io.IOException;

import org.elasticsearch.action.admin.indices.settings.put.UpdateSettingsRequest;
import org.elasticsearch.action.support.master.AcknowledgedResponse;
import org.elasticsearch.client.IndicesClient;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.indices.CreateIndexRequest;
import org.elasticsearch.client.indices.CreateIndexResponse;
import org.elasticsearch.client.indices.GetIndexRequest;
import org.elasticsearch.client.indices.GetIndexResponse;


/**
 * The Class IndicesClientImpl.
 */
public class IndicesClientImpl implements IIndicesClient {
	
	
	/** The indices client. */
	private final IndicesClient indicesClient;
	
	/**
	 * Instantiates a new indices client impl.
	 *
	 * @param indicesClient the indices client
	 */
	public IndicesClientImpl(IndicesClient indicesClient) {
		this.indicesClient=indicesClient;
	}

	/**
	 * Gets the.
	 *
	 * @param getIndexRequest the get index request
	 * @param options the options
	 * @return the gets the index response
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	public GetIndexResponse get(GetIndexRequest getIndexRequest, RequestOptions options) throws IOException {
		return indicesClient.get(getIndexRequest, options);
	}

	/**
	 * Exists.
	 *
	 * @param request the request
	 * @param options the options
	 * @return true, if successful
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	public boolean exists(GetIndexRequest request, RequestOptions options) throws IOException {
		return indicesClient.exists(request, options);
	}

	/**
	 * Creates the.
	 *
	 * @param createIndexRequest the create index request
	 * @param options the options
	 * @return the creates the index response
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	public CreateIndexResponse create(CreateIndexRequest createIndexRequest, RequestOptions options)
			throws IOException {
		return indicesClient.create(createIndexRequest, options);
	}

	/**
	 * Put settings.
	 *
	 * @param updateSettingsRequest the update settings request
	 * @param options the options
	 * @return the acknowledged response
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	public AcknowledgedResponse putSettings(UpdateSettingsRequest updateSettingsRequest, RequestOptions options)
			throws IOException {
		return indicesClient.putSettings(updateSettingsRequest, options);
	}

}
