package com.ncloud.dl.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.service.IDataLakeMDMService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

/**
 * {Export Import Page}
 * 
 * @author CBT
 *
 */
@RestController
@RequestMapping("/data")
@RequiredArgsConstructor
public class DataLakeMasterDataManagementController {

	/**
	 * Automatically injects an instance of IDataLakeMDMService.
	 */
	private final IDataLakeMDMService iDataLakeService;

	/**
	 * Exports master data for the given table names.
	 *
	 * @param tableEntityList List of table names whose master data needs to be exported.
	 * @return A list of maps containing master data records.
	 * @throws IOException If an I/O error occurs.
	 */
	@ApiOperation(value = "Export Master Data",
	              notes = "Exports master data based on the provided list of table names.")
	@PostMapping("/export-master-datas")
	public List<Map<String, Object>> exportMasterDatas(
			@ApiParam(value = "List of Table Name's", required = true) @RequestBody List<String> tableEntityList)
			throws IOException {
		return iDataLakeService.exportMasterDatas(tableEntityList);
	}

	/**
	 * Imports master data into the system.
	 *
	 * @param recoveryMasterDataMap A map containing the master data to be imported.
	 * @throws ApplicationException If a business logic error occurs.
	 * @throws IOException If an I/O error occurs.
	 */
	@ApiOperation(value = "Import Master Data", 
	              notes = "Imports master data based on the provided input map.")
	@RequestMapping("/import-master-datas")
	public void importMasterDatas(
			@ApiParam(value = "Import data as Map Object", required = true) @RequestBody Map<String, Object> recoveryMasterDataMap)
			throws ApplicationException, IOException {
		iDataLakeService.importMasterData(recoveryMasterDataMap);
	}

}
