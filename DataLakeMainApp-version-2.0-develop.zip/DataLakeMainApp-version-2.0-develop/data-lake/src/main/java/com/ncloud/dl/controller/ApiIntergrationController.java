package com.ncloud.dl.controller;

import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ncloud.dl.aop.annotation.Auditable;
import com.ncloud.dl.config.base.controller.BaseController;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.service.IBulkUploadService;
import com.ncloud.dl.service.ISearchService;
import com.ncloud.dl.transfer.object.core.ApplicationResponse;
import com.ncloud.dl.transfer.object.dto.ApiIntergrationDto;
import com.ncloud.dl.transfer.object.dto.CustomFilterSortingVo;
import com.ncloud.dl.transfer.object.dto.SearchResponseDto;
import com.ncloud.dl.transfer.object.enums.FieldSearchTypeEnum;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
/**
 * {API Integration Page}
 * @author CBT
 *
 */
@RestController
@RequestMapping("/api-integration")
@RequiredArgsConstructor
@Auditable
public class ApiIntergrationController extends BaseController {

	/**
	 * Injects the value of {list.skip} from the *.properties file.
	 */
	@Value("${list.skip}")
	private String skip;
	
	/**
	 * Injects the value of {list.limit} from the *.properties file.
	 */
	@Value("${list.limit}")
	private String limit;
	
	/**
	 * iSearchService
	 */
	private final ISearchService iSearchService;
	
	/**
	 * iBulkUploadService
	 */
	private final IBulkUploadService iBulkUploadService;
	
	
	/**
     * Fetches search results from the Elasticsearch engine using the specified repository name.
     * 
     * @param skip             The number of records to skip (optional).
     * @param limit            The maximum number of records to retrieve (optional).
     * @param repositoryName   The name of the repository to search within.
     * @param apiIntergrationDto Request body containing the search query and additional data.
     * @return {@link ApplicationResponse} containing the search results.
     * @throws IOException If an error occurs during the search operation.
     */
    @ApiOperation(value = "Search within a specific repository", 
                  notes = "Fetches search results from Elasticsearch for a given repository.")
	@GetMapping("/{repositoryName}/search")
	public ApplicationResponse getRepositorySearchList(
			@ApiParam(value = "Number of records to skip") @RequestParam(name = "skip", required = false) Long skip,
			@ApiParam(value = "Maximum number of records to return") @RequestParam(name = "limit", required = false) Long limit,
			@ApiParam(value = "Name of the repository to search within", required = true) @PathVariable(name = "repositoryName") String repositoryName,
			@ApiParam(value = "Request payload containing search criteria") @RequestBody ApiIntergrationDto apiIntergrationDto)
			throws IOException {
		if (skip == null && limit == null) {
			skip = Long.parseLong(this.skip);
			limit = Long.parseLong(this.limit);
		}
		return getApplicationResponse(iSearchService.commonSearch(apiIntergrationDto.getSearchQuery(), repositoryName,
				skip, limit, FieldSearchTypeEnum.REPOSITORY_SEARCH.getId(), new CustomFilterSortingVo(), Boolean.TRUE));
	}
	
    /**
     * Performs a global search across all repositories.
     * 
     * @param apiIntergrationDto Request body containing the search query and additional data.
     * @param skip             The number of records to skip (optional).
     * @param limit            The maximum number of records to retrieve (optional).
     * @return {@link ApplicationResponse} containing a list of {@link SearchResponseDto}.
     * @throws ApplicationException If an error occurs during the search.
     */
    @ApiOperation(value = "Global search across all repositories", 
                  notes = "Searches across multiple repositories using Elasticsearch.")
	@RequestMapping("/search")
	public ApplicationResponse globalSearch(
			@ApiParam(value = "Request payload containing search criteria") @RequestBody ApiIntergrationDto apiIntergrationDto,
			@ApiParam(value = "Number of records to skip for pagination") @RequestParam(name = "skip", required = false) Long skip,
			@ApiParam(value = "Maximum number of records to return") @RequestParam(name = "limit", required = false) Long limit)
			throws ApplicationException {
		if (skip == null && limit == null) {
			skip = Long.parseLong(this.skip);
			limit = Long.parseLong(this.limit);
		}
		List<SearchResponseDto> reponse = iSearchService.globalSearch(apiIntergrationDto.getSearchQuery(), skip, limit,
				null, Boolean.TRUE);
		return getApplicationResponse(reponse);
	}
	
    /**
     * Pushes repository data into Elasticsearch under its respective repositories.
     * 
     * @param repositoryName        The name of the repository where data will be added.
     * @param singleAddRepository   The data to be added in key-value format.
     * @return A success message upon successful data insertion.
     * @throws ApplicationException If an error occurs during insertion.
     * @throws ParseException If there is an error parsing the data.
     * @throws JsonProcessingException If there is an error processing the JSON data.
     */
    @ApiOperation(value = "Add a single record to a repository", 
                  notes = "Pushes a single document into Elasticsearch under the specified repository.",
                  response = String.class)
	@PostMapping("/{repository-name}/add")
	public String singleAddForRepository(
			@ApiParam(value = "Name of the repository where data should be added", required = true) @PathVariable(name = "repository-name") String repositoryName,
			@ApiParam(value = "Data to be added in key-value format", required = true) @RequestBody HashMap<String, Object> singleAddRepository)
			throws ApplicationException, ParseException, JsonProcessingException {
		 return iBulkUploadService.singleRecordForRepository(repositoryName, singleAddRepository);
	}

	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}

	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	@Override
	protected void registerInterceptor() {
		
	}

}
