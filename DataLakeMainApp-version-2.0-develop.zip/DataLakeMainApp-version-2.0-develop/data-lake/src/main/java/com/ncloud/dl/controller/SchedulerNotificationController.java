package com.ncloud.dl.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ncloud.dl.config.base.controller.BaseController;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.service.ISchedulerNotificationService;
import com.ncloud.dl.transfer.object.dto.RepositoryScheduleDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/scheduler-notification")
@RequiredArgsConstructor
public class SchedulerNotificationController extends BaseController {

	/**
	 * {@link ISchedulerNotificationService}
	 */
	private final ISchedulerNotificationService schedulerNotificationService;
	
	/**
	 * Retrieves repository scheduler details based on the repository identity.
	 *
	 * @param repositoryIdentity The unique identifier of the repository.
	 * @return ResponseEntity containing the repository scheduler details.
	 * @throws ApplicationException If a business logic error occurs.
	 */
	@ApiOperation(value = "Get Repository Scheduler Details",
	              notes = "Fetches scheduler details for a given repository identity.",
	              response = RepositoryScheduleDto.class)
	@GetMapping("/details")
	public RepositoryScheduleDto getRepositoryScheduleDetails(
			@ApiParam(value = "Unique Identifier fot Repository", required = true) @RequestParam String repositoryIdentity)
			throws ApplicationException {
		return schedulerNotificationService.getRepositoryScheduleDetailsByRepositoryIdentity(repositoryIdentity);
	}
	
	@Override
	protected Class<?> getClassName() {
		return SchedulerNotificationController.class;
	}

	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	@Override
	protected void registerInterceptor() {
	}

}
