package com.ncloud.dl.dao.datarespository;

import java.time.LocalDateTime;
import java.util.List;

import com.ncloud.dl.config.model.FilterOrSortingVo;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.dto.RepositoryDto;
import com.ncloud.dl.transfer.object.entity.BulkUploadHistory;
import com.ncloud.dl.transfer.object.entity.Comments;
import com.ncloud.dl.transfer.object.entity.DataRepository;
import com.ncloud.dl.transfer.object.entity.FieldConfiguration;
import com.ncloud.dl.transfer.object.entity.RepositoryScheduleDetails;
import com.ncloud.dl.transfer.object.entity.SchedulerNotification;
import com.ncloud.dl.transfer.object.entity.SearchHistory;

/**
 * @author CBT
 *
 */
public interface IDataRepositoryDao {
	
	/**
	 * @param dataRepository
	 * @return
	 * @throws ApplicationException 
	 */
	DataRepository saveRepostioryDetails(DataRepository dataRepository) throws ApplicationException;
	
	/**
	 * @param dataRepository
	 * @throws ApplicationException
	 */
	void updateRepostioryDetails(DataRepository dataRepository) throws ApplicationException;

	/**
	 * @param repositoryId
	 * @return
	 */
	List<FieldConfiguration> getFieldRepository(String repositoryIdentity);

	/**
	 * @param repositoryIdentity
	 * @return
	 */
	List<Comments> getCommentsValues(String repositoryIdentity);

	
	/**
	 * @param repositoryIdentity
	 * @return
	 */
	DataRepository getUpdateStatusDataRepository(String repositoryIdentity);

	/**
	 * @param dataRepository
	 */
	void saveUpdateStatusDataRepository(DataRepository dataRepository);

	/**
	 * @param dataRepository
	 */
	void UpdateRepostioryDetails(DataRepository dataRepositorys);

	/**
	 * @param filterVo
	 * @param search 
	 * @param userRoleStatus 
	 * @return
	 * @throws ApplicationException 
	 */
	Long getRepositoryCountValue(List<FilterOrSortingVo> filterVo, String search, String userRoleStatus) throws ApplicationException;


	/**
	 * @param min
	 * @param max
	 * @param filterVo
	 * @param userRoleStatus
	 * @param search 
	 * @return
	 * @throws ApplicationException
	 */
	List<DataRepository> getDataRepositoryList(Integer min, Integer max, List<FilterOrSortingVo> filterVo,String userRoleStatus, String search) throws ApplicationException;

	
	/**
	 * @param singleAddRepository
	 * @param repoTableName
	 * @return 
	 * @throws ApplicationException 
	 */
	void saveSingleFieldData(List<Object> singleAddRepository, String repoTableName) throws ApplicationException;
	/**
	 * @param schedulerIdentity
	 * @return
	 */
	SchedulerNotification getSchedulerDetails(String schedulerIdentity);

	/**
	 * @param schedulerNotification
	 */
	void saveUpdatestatusScheduler(SchedulerNotification schedulerNotification);
	
    /**
     * @param schedulerIdentity
     * @return
     */
    SchedulerNotification getSchedulerTableDetails(String schedulerIdentity);

	/**
	 * @param min
	 * @param max
	 * @param filterVo
	 * @return
	 * @throws ApplicationException 
	 */
	List<SchedulerNotification> getSchedulerDetailsdao(Integer min, Integer max, List<FilterOrSortingVo> filterVo) throws ApplicationException;

	
	/**
	 * @return
	 * @throws ApplicationException
	 */
	Long getSchedulerCountValue() throws ApplicationException;

	/**
	 * @param repoName
	 * @param repoId
	 * @param repoVersion 
	 * @param list 
	 * @return
	 */
	List<DataRepository> getDataRepositoryByRepoNameAndId(String repoName, String repoId, String identity, Boolean isCloned, Double repoVersion, List<String> list);

	/**
	 * @param id
	 * @return
	 */
	RepositoryScheduleDetails getrepositorySchedulerDetails(String id);

	/**
	 * @param min
	 * @param max
	 * @param filterVo
	 * @param status
	 * @return
	 * @throws ApplicationException
	 */
	List<DataRepository> getDataRepositoryListForApproved(Integer min, Integer max, List<FilterOrSortingVo> filterVo,String search, Boolean isSearch)
			throws ApplicationException;

	/**
	 * @param bulkUploadHistoryDto
	 * @return
	 */
	BulkUploadHistory getBulkUploadHistory(String bulkUploadHistoryDto);

	/**
	 * @param repositoryIdentity
	 * @param list 
	 * @return
	 */
	List<FieldConfiguration> getFieldRepositorySearch(String repositoryIdentity, List<Integer> list);
	
	/**
	 * @param repoTableName
	 * @param columnParams
	 * @param columns
	 * @return
	 */
	String generateInsertQuery(String repoTableName, String columnParams, String columns);

	/**
	 * @param repositoryId
	 * @param isrepositorySearch 
	 * @return
	 */
	List<RepositoryDto> getSearchableFields(String repositoryId, List<Integer> searchTypeId, Boolean isApiIntegeration);

	/**
	 * @param repositoryName
	 * @return
	 */
	DataRepository getRepositoryInfoByRepositoryName(String repositoryName);
	
	/**
	 * @param filterVo
	 * @param search
	 * @param isApproved 
	 * @return
	 * @throws ApplicationException 
	 */
	Long getRepositoryApprovedCountValue(List<FilterOrSortingVo> filterVo, String search, Boolean isApproved) throws ApplicationException;

	/**
	 * @param repositoryId
	 * @return
	 */
	List<String> getFieldRepositoryColumnName(String repositoryId);

	/**
	 * @param searchHistory
	 * @throws ApplicationException 
	 */
	void saveBothSearchHistory(SearchHistory searchHistory) throws ApplicationException;

	/**
	 * @param companyIdList
	 * @param fromdate
	 * @param maxDateTime
	 * @return
	 */
	List<BulkUploadHistory> getBulkUploadHistoryDetails(List<Integer> companyIdList, LocalDateTime fromdate, LocalDateTime maxDateTime);
	
	
	/**
	 * @param repoName
	 * @param hashCodeObj
	 * @return
	 */
	String generateSelectQuery(String repoName, Integer hashCodeObj);


}
