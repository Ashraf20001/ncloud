package com.ncloud.dl.search.eswrapper;

import java.io.IOException;

import org.elasticsearch.client.Request;
import org.elasticsearch.client.Response;

/**
 * The Interface IRestClient.
 */
public interface IRestClient {
		
	 /**
 	 * Perform request.
 	 *
 	 * @param request the request
 	 * @return the response
 	 * @throws IOException Signals that an I/O exception has occurred.
 	 */
 	public Response performRequest(Request request) throws IOException;
	 
	 /**
 	 * Close.
 	 *
 	 * @throws IOException Signals that an I/O exception has occurred.
 	 */
 	public void close() throws IOException;
}
