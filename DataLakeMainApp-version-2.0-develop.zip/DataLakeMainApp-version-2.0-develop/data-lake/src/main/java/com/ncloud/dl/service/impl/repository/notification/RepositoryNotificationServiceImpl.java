package com.ncloud.dl.service.impl.repository.notification;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.ncloud.dl.dao.notification.repository.IRepositoryNotificationDao;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.exception.core.codes.ErrorCodes;
import com.ncloud.dl.service.IRepositoryNotificationService;
import com.ncloud.dl.service.impl.resttemplate.RestTemplateServiceImpl;
import com.ncloud.dl.transfer.object.dto.NotificationDto;
import com.ncloud.dl.transfer.object.dto.UserInfo;
import com.ncloud.dl.transfer.object.dto.UserPrivillageDto;
import com.ncloud.dl.transfer.object.entity.RepositoryNotification;
import com.ncloud.dl.transfer.object.enums.CreatorApprover;
import com.ncloud.dl.transfer.object.enums.RepositoryStatusEnum;
import com.ncloud.dl.utils.core.ApplicationUtils;

import lombok.RequiredArgsConstructor;

/**
 * The Class RepositoryNotificationServiceImpl.
 */
@Service
@Transactional(rollbackOn = Exception.class)
@RequiredArgsConstructor
public class RepositoryNotificationServiceImpl implements IRepositoryNotificationService {

	/**
	 * RepositoryNotificationDao
	 */
	private final IRepositoryNotificationDao repositoryNotificationDao;
	
	/**
	 * RestTemplateServiceImpl
	 */
	private final RestTemplateServiceImpl restTemplateServiceImpl;
	
	/**
	 * @throws ApplicationException
	 */
	@Override
	public Long getUnReadNotificationsCount(HttpServletRequest httpServletRequest) throws ApplicationException {
		List<Integer> userPrivilegeIds = getPrivilegeIdFromEnum(httpServletRequest);
		List<RepositoryNotification> repositoryNotifications = repositoryNotificationDao
				.getRepositoryNotificationBasedOnRolePrivelege(userPrivilegeIds, true);
		return (long) repositoryNotifications.size();
	}

	/**
	 * @param httpServletRequest
	 * @return
	 * @throws ApplicationException
	 */
	private List<String> getPrivilegeIdsBaseOnRole(HttpServletRequest httpServletRequest) throws ApplicationException {
		List<UserPrivillageDto> userPrivillageDto = restTemplateServiceImpl.checkForPrivelege(httpServletRequest);
		return userPrivillageDto.stream().map(UserPrivillageDto::getPrivillageName)
				.collect(Collectors.toList());
	}

	/**
	 *@param isViewAllNotifications
	 */
	@Override
	public List<NotificationDto> getUnReadNotifications(Boolean isViewAllNotifications,
			HttpServletRequest httpServletRequest) throws ApplicationException {
		List<NotificationDto> notifications = new ArrayList<>();
		List<Integer> privilegeId = getPrivilegeIdFromEnum(httpServletRequest);
		if (ApplicationUtils.isValidList(privilegeId)) {
			List<RepositoryNotification> repositoryNotifications = repositoryNotificationDao
					.getRepositoryNotificationBasedOnRolePrivelege(privilegeId, isViewAllNotifications);
			List<Integer> userIdList = repositoryNotifications.stream().map(RepositoryNotification::getCrtUsrId).distinct().toList();
			if (ApplicationUtils.isValidList(repositoryNotifications)) {
				if(ApplicationUtils.isValidList(userIdList)) {
					Map<Integer, String> userIdProfileMap = restTemplateServiceImpl.getImageName(userIdList,httpServletRequest);
					buildRepositoryNotification(notifications, repositoryNotifications, userIdProfileMap);
				}
			}
		}
		return notifications;
	}

	/**
	 * @param notifications
	 * @param repositoryNotifications
	 * @param userIdProfileMap 
	 */
	private void buildRepositoryNotification(List<NotificationDto> notifications,
			List<RepositoryNotification> repositoryNotifications, Map<Integer, String> userIdProfileMap ) {
		for (RepositoryNotification notification : repositoryNotifications) {
			NotificationDto notificationDto = new NotificationDto();
			notificationDto.setIsRead(notification.getIsRead());
			notificationDto.setIsRepoCmts(notification.getIsRepoCmts());
			notificationDto.setIdentity(notification.getIdentity());
			notificationDto.setRepositoryIdentity(notification.getRepositoryId().getIdentity());
			notificationDto.setNotificationContent(notification.getNotificationMessage());
			notificationDto.setStatus(RepositoryStatusEnum.getRepositoryStatusById(notification.getRepositoryId().getRepoStatus()));
            notificationDto.setCreatedDate(notification.getCrtDteTme());
			notificationDto.setNotificationJson(notification.getReplaceTemplateData());
			notificationDto.setLogoUrl(userIdProfileMap.get(notification.getCrtUsrId())); // to be changed
			notifications.add(notificationDto);
		}
	}

	/**
	 * @param httpServletRequest
	 * @return
	 * @throws ApplicationException
	 */
	private List<Integer> getPrivilegeIdFromEnum(HttpServletRequest httpServletRequest) throws ApplicationException {
		List<String> userPrivilegeIds = getPrivilegeIdsBaseOnRole(httpServletRequest);
		return CreatorApprover.getPrivilegeIdByPrivilegeName(userPrivilegeIds);
	}

	/**
	 * @param identity
	 *@param userInfo
	 */
	@Override
	public Boolean markAsReadNotification(String identity, UserInfo userInfo) throws ApplicationException {
		Boolean isUpdated = Boolean.FALSE;
		if (!ApplicationUtils.isValidateObject(userInfo)) {
			throw new ApplicationException(ErrorCodes.INVALID_USER);
		}
		if (ApplicationUtils.isValidString(identity)) {
			List<RepositoryNotification> repositoryNotification = repositoryNotificationDao
					.getRepositoryNotificationByIdentity(identity);
			for (RepositoryNotification notification : repositoryNotification) {
				notification.setIsRead(Boolean.TRUE);
				notification.setMdyDteTme(LocalDateTime.now());
				notification.setMdyUsrId(userInfo.getId());
				isUpdated = repositoryNotificationDao.updateRepositoryNotification(notification);
			}
		}
		return isUpdated;
	}

}
