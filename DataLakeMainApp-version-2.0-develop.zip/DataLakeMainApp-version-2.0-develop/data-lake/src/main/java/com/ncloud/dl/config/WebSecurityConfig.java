package com.ncloud.dl.config;

import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;


/**
 * The Class WebSecurityConfig.
 */
@EnableWebMvc
public class WebSecurityConfig {
	
	/**
	 * Cors config.
	 *
	 * @return the web mvc configurer
	 */
	@Bean
	public WebMvcConfigurer corsConfig() {
		return new WebMvcConfigurer() {
			@Override
			public void addCorsMappings(CorsRegistry registry) {
				String[] allowDomains = {"http://localhost:4200","http://localhost:5200"};
				registry.addMapping("/**").allowedMethods("GET","POST")
				.allowedOrigins(allowDomains).allowedHeaders("*");
			}
		};
		
	}

}
