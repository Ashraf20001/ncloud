package com.ncloud.dl.dao.fieldconfiguration;

import java.util.LinkedHashMap;
import java.util.List;

import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.entity.FieldConfiguration;

public interface IFieldConfigurationDao {

	/**
	 * @param fieldsConfiguration
	 * @return
	 * @throws ApplicationException 
	 */
	FieldConfiguration saveFieldConfiguration(FieldConfiguration fieldsConfiguration) throws ApplicationException;

	/**
	 * @param tableName 
	 * @param createScript
	 * @param tableName
	 * @throws ApplicationException
	 */
	void createTableQuery(LinkedHashMap<String, String> scriptMap, String tableName) throws ApplicationException;
	
	/**
	 * @param repositoryIdentity
	 * @return
	 */
	List<FieldConfiguration> getFieldDetails(Integer repositoryIdentity);


	/**
	 * @param fieldDetails
	 */
	void updateFieldConfiguration(FieldConfiguration fieldDetails);


	/**
	 * @param fieldIdentity
	 * @return
	 */
	FieldConfiguration getFieldConfigurationdetails(String fieldIdentity);

	/**
	 * @param repositoryIdentity
	 * @return
	 */
	List<FieldConfiguration> getFieldMappedInRepository(String repositoryIdentity);

	/**
	 * @param repositoryIdentity
	 * @return
	 */
	List<FieldConfiguration> getFieldDetailList(String repositoryIdentity);
	
}
