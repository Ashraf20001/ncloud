package com.ncloud.dl.dao.impl.errormaintenance;

import org.springframework.stereotype.Repository;

import com.ncloud.dl.config.common.base.dao.BaseDao;
import com.ncloud.dl.constants.core.TableConstants;
import com.ncloud.dl.dao.errormaintenance.IErrorMaintenanceDao;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.entity.ErrorMaintenance;

/**
 * The Class ErrorMaintenanceDaoImpl.
 */
@Repository
public class ErrorMaintenanceDaoImpl extends BaseDao implements IErrorMaintenanceDao{

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
		
	}

	/**
	 * Save Error Maintenance Data
	 * @param {@link ErrorMaintenance}
	 */
	@Override
	public void saveErrorMaintenanceHistory(ErrorMaintenance errorMaitainence) throws ApplicationException {
		save(errorMaitainence, TableConstants.ERROR_MAINTENANCE);
	}

}
