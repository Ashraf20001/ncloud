package com.ncloud.dl.datatype.factory;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.poi.util.IOUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.ncloud.dl.transfer.object.enums.FieldDataTypeEnum;

import lombok.RequiredArgsConstructor;

/**
 * A factory for creating DataType objects.
 */
@Component
@RequiredArgsConstructor
public class DataTypeFactory {
	
	/**
	 * stringBuilder
	 */
	@Qualifier("stringBuilder")
	private final IDataTypeFactoryBuilder stringFactoryBuilder;
	
	/**
	 * decimalBuilder
	 */
	@Qualifier("decimalBuilder")
	private final IDataTypeFactoryBuilder decimalFactoryBuilder;
	
	/**
	 * booleanBuilder
	 */
	@Qualifier("booleanBuilder")
	private final IDataTypeFactoryBuilder booleanFactoryBuilder;
	
	/**
	 * numberBuilder
	 */
	@Qualifier("numberBuilder")
	private final IDataTypeFactoryBuilder numberFactoryBuilder;
	
	/**
	 * dateBuilder
	 */
	@Qualifier("dateBuilder")
	private final IDataTypeFactoryBuilder dateFactoryBuilder;
	
	/**
	 * stringFactoryValidationBuilder
	 */
	@Qualifier("stringFactoryValidationBuilder")
	private final IDataTypeFactoryValidationBuilder stringFactoryValidationBuilder;
	
	/**
	 * numberFactoryValidationBuilder
	 */
	@Qualifier("numberFactoryValidationBuilder")
	private final IDataTypeFactoryValidationBuilder numberFactoryValidationBuilder;
	
	/**
	 * dateFactoryValidationBuilder
	 */
	@Qualifier("dateFactoryValidationBuilder")
	private final IDataTypeFactoryValidationBuilder dateFactoryValidationBuilder;
	
	
	/**
	 * stringTypeValidator
	 */
	@Qualifier("stringValidator")
	private final IBulkUploadValidationBuilder stringTypeValidator;
	
	/**
	 * numberTypeValidator
	 */
	@Qualifier("numberValidator")
	private final IBulkUploadValidationBuilder numberTypeValidator;
	
	/**
	 * dateFactoryValidationBuilder
	 */
	@Qualifier("dateValidator")
	private final IBulkUploadValidationBuilder dateFormatValidator;
	
	
	/**
	 * dataTypeFactoryBuilderMap
	 */
	private Map<String, IDataTypeFactoryBuilder> dataTypeFactoryBuilderMap = new HashMap<>();
	
	/**
	 * dataTypeFactoryValidationBuilder
	 */
	private Map<String, IDataTypeFactoryValidationBuilder> dataTypeFactoryValidationBuilder = new HashMap<>();
	
	/**
	 * dataTypeFactoryValidationBuilder
	 */
	private final Map<String, IBulkUploadValidationBuilder> bulkUploadValidationBuilder = new HashMap<>();

	/**
     * Factory method to get fields datatype
     */
    @PostConstruct
    private void initCalculatorMap() {
    	IOUtils.setByteArrayMaxOverride(250000000);
    	dataTypeFactoryBuilderMap.put(FieldDataTypeEnum.STRING.getValue(), stringFactoryBuilder);
    	dataTypeFactoryBuilderMap.put(FieldDataTypeEnum.NUMBER.getValue(), numberFactoryBuilder);
    	dataTypeFactoryBuilderMap.put(FieldDataTypeEnum.DATE.getValue(), stringFactoryBuilder);
    	dataTypeFactoryValidationBuilder.put(FieldDataTypeEnum.STRING.getValue(), stringFactoryValidationBuilder);
    	dataTypeFactoryValidationBuilder.put(FieldDataTypeEnum.NUMBER.getValue(), numberFactoryValidationBuilder);
    	dataTypeFactoryValidationBuilder.put(FieldDataTypeEnum.DATE.getValue(), dateFactoryValidationBuilder);	
    	bulkUploadValidationBuilder.put(FieldDataTypeEnum.STRING.getValue(), stringTypeValidator);
    	bulkUploadValidationBuilder.put(FieldDataTypeEnum.NUMBER.getValue(), numberTypeValidator);
    	bulkUploadValidationBuilder.put(FieldDataTypeEnum.DATE.getValue(), dateFormatValidator);	
    }
    
    /**
     * @param fieldDetailManagerId
     * @return
     */
    public IDataTypeFactoryBuilder getFieldDetailManagerType(String fieldDetailManagerId)
    {        
        return dataTypeFactoryBuilderMap.get(fieldDetailManagerId);
    }
    
    /**
     * @param fieldType
     * @return
     */
    public IBulkUploadValidationBuilder getBulkUploadFieldType(String fieldType) {
    	return bulkUploadValidationBuilder.get(fieldType);
    }
    
    /**
     * @param dataTypeDetails
     * @return
     */
    public IDataTypeFactoryValidationBuilder getDataTypeValidationBuilder(String dataTypeDetails) {
    	return dataTypeFactoryValidationBuilder.get(dataTypeDetails);
    }
    
    /**
     * @param dataTypeFactoryBuilderMap
     */
    public void setFieldDetailManagerMap(Map<String, IDataTypeFactoryBuilder> fieldDetailManagerMap) {
		this.dataTypeFactoryBuilderMap = fieldDetailManagerMap;
	}
    
    /**
     * @param dataTypeFactoryValidationBuilder
     */
    public void setDataTypeFactoryValidationBuilder(Map<String, IDataTypeFactoryValidationBuilder> dataTypeFactoryValidationBuilder) {
		this.dataTypeFactoryValidationBuilder = dataTypeFactoryValidationBuilder;
	}

}
