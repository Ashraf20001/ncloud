package com.ncloud.dl.controller;

import java.io.UnsupportedEncodingException;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ncloud.dl.aop.annotation.Auditable;
import com.ncloud.dl.config.base.controller.BaseController;
import com.ncloud.dl.config.model.FilterOrSortingVo;
import com.ncloud.dl.constants.core.ApplicationConstants;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.service.IRepositoryService;
import com.ncloud.dl.transfer.object.core.ApplicationResponse;
import com.ncloud.dl.transfer.object.dto.CommentsDto;
import com.ncloud.dl.transfer.object.dto.DataRepositoryDto;
import com.ncloud.dl.transfer.object.dto.FieldRepositoryDto;
import com.ncloud.dl.transfer.object.dto.RepositoryScheduleDetailsDto;
import com.ncloud.dl.transfer.object.dto.SchedulerNotificationDto;
import com.ncloud.dl.transfer.object.dto.UserInfo;
import com.ncloud.dl.utils.core.LoggedInUserContextHolder;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

/**
 * RestController to manage repository endpoint's
 * @author CBT
 *
 */
@RestController
@RequestMapping("/repository")
@RequiredArgsConstructor
@Auditable
public class RepositoryController extends BaseController {

	/**
	 * IRepositoryService
	 */
	private final IRepositoryService iRepositoryService;

	/**
	 * LoggedInUserContextHolder
	 */
	private final LoggedInUserContextHolder loggedInUserContextHolder;

	/**
	 * Saves or updates repository details.
	 * 
	 * This method takes a {@link FieldRepositoryDto} object containing repository details 
	 * and updates or saves the information. It also retrieves the logged-in user details 
	 * from the {@link LoggedInUserContextHolder} and passes them along with the request.
	 * 
	 * @param fieldRepositoryDto The DTO containing repository details to be saved or updated.
	 * @param httpServletRequest The HTTP request object containing request details.
	 * @return {@link ApplicationResponse} indicating the success or failure of the operation.
	 * @throws ApplicationException If an error occurs during the update process.
	 */
	@PostMapping("/save-repository")
	public ApplicationResponse updateRepository(
			@ApiParam(value = "FieldRepositoryDto PayLoad") @RequestBody FieldRepositoryDto fieldRepositoryDto,
			HttpServletRequest httpServletRequest) throws ApplicationException {
		Boolean response = iRepositoryService.updateRepositoryDetails(fieldRepositoryDto,
				loggedInUserContextHolder.getLoggedInUser(), httpServletRequest);
		return getApplicationResponse(response);
	}

	/**
	 * Submit or update field repository details.
	 * 
	 * @param fieldRepositoryDto Data transfer object containing repository details
	 * @param httpServletRequest HTTP request object for capturing request metadata
	 * @throws ApplicationException if an error occurs during submission
	 */
	@PostMapping("/submit-repostiory")
	public void saveOrUpdateFieldConfigurations(
			@ApiParam(value = "FieldRepositoryDto PayLoad") @RequestBody FieldRepositoryDto fieldRepositoryDto,
			HttpServletRequest httpServletRequest) throws ApplicationException {
		iRepositoryService.saveFieldRepostiory(fieldRepositoryDto, loggedInUserContextHolder.getLoggedInUser(),
				httpServletRequest); 
	}
	

	/**
	 * Approves a field repository using the repository identity provided in
	 * {@link FieldRepositoryDto}.
	 * 
	 * @param fieldRepositoryDto DTO containing repository identity and approval
	 *                           details
	 * @param httpServletRequest HTTP request object for capturing request metadata
	 * @throws ApplicationException if an error occurs during approval
	 */
	@ApiOperation(value = "Approve Repository", notes = "Approves a field repository based on the repository identity provided in the DTO.", response = Void.class)
	@PostMapping("/approve-repository")
	public void updateFieldRepositoryStatus(
			@ApiParam(value = "FieldRepositoryDto PayLoad") @RequestBody FieldRepositoryDto fieldRepositoryDto,
			HttpServletRequest httpServletRequest) throws ApplicationException {
		UserInfo userInfo = loggedInUserContextHolder.getLoggedInUser();
		iRepositoryService.approveRepository(fieldRepositoryDto, userInfo, httpServletRequest);
	}
	 
	
	/**
	 * Rejects a field repository using the provided repository identity and action.
	 * 
	 * @param repositoryIdentity Unique identifier for the repository to be rejected
	 *                           (optional)
	 * @param action             Action to be performed for rejection (optional)
	 * @param httpServletRequest HTTP request object for capturing request metadata
	 * @return {@link ApplicationResponse} containing the status of the rejection
	 *         process
	 * @throws ApplicationException if an error occurs during the rejection process
	 */
	@ApiOperation(value = "Reject Repository", notes = "Rejects a field repository based on the provided repository identity and action.", response = ApplicationResponse.class)
	@PostMapping("/reject-repository")
	public ApplicationResponse updateStatusDataRepository(
			@ApiParam(value = "Unique Identifier for Repository") @RequestParam(name = "repositoryIdentity", required = false) String repositoryIdentity,
			@ApiParam(value = "Action data") @RequestParam(name = "action", required = false) String action,
			HttpServletRequest httpServletRequest) throws ApplicationException {
		UserInfo userInfo = loggedInUserContextHolder.getLoggedInUser();
		String response = iRepositoryService.updateStatusDataRepository(repositoryIdentity,action, userInfo,httpServletRequest);
		return getApplicationResponse(response);
	}

	/**
	 * Clone repository
	 * 
	 * @param fieldRepositoryDto DTO containing the repository details to be cloned
	 * @param httpServletRequest HTTP request object for capturing request metadata
	 * @throws ApplicationException if an error occurs during the cloning process
	 */
	@ApiOperation(value = "Clone Repository", notes = "Clones an existing field repository with the provided details.", response = Void.class)
	@PostMapping("/clone-respository")
	public void cloneRepositoryDetails(@ApiParam(value = "FieldRepositoryDto PayLoad", required = true) @RequestBody FieldRepositoryDto fieldRepositoryDto,
			HttpServletRequest httpServletRequest) throws ApplicationException {
		iRepositoryService.saveFieldRepostiory(fieldRepositoryDto, loggedInUserContextHolder.getLoggedInUser(), httpServletRequest);
	}

	/**
	 * Disable repository by {repositoryIdentity}
	 * 
	 * @param repositoryIdentity Unique identifier for the repository to be disabled
	 * @param date The date on which the repository should be disabled (formatted as per {@link ApplicationConstants#FORMAT})
	 * @return {@link ApplicationResponse} indicating the status of the operation
	 * @throws ApplicationException if an error occurs while disabling the repository
	 */
	@ApiOperation(
		value = "Disable Repository", 
		notes = "Disables a repository based on the provided repository identity and date.",
		response = ApplicationResponse.class
	)
	@PutMapping("/disable-repository")
	public ApplicationResponse updateCardDisable(
			@ApiParam(value = "Unique Identifier for Repository", required = true) @RequestParam String repositoryIdentity,
			@ApiParam(value = "Localdate format", required = true) @DateTimeFormat(pattern = ApplicationConstants.FORMAT) @RequestParam LocalDate date)
			throws ApplicationException {
		return getApplicationResponse(iRepositoryService.updateCardRepository(repositoryIdentity, date,
				loggedInUserContextHolder.getLoggedInUser()));
	}

	/**
	 * Fetch repository details by repositoryIdentity.
	 * 
	 * @param repositoryIdentity Unique identifier for the repository
	 * @return {@link FieldRepositoryDto} containing repository and field details
	 */
	@ApiOperation(
		value = "Fetch Repository Details", 
		notes = "Retrieves repository details based on the provided repositoryIdentity.",
		response = FieldRepositoryDto.class
	)
	@GetMapping("/repository-details")
	public FieldRepositoryDto getRepositoryDetails(
			@ApiParam(value = "Unique Identifier for Repository", required = true) @RequestParam String repositoryIdentity) {
		return iRepositoryService.getRepositoryAndFieldDetails(repositoryIdentity);

	}

	/**
	 * Get the total count of repositories based on search criteria.
	 * 
	 * @param search         Optional search keyword to filter repositories.
	 * @param userRoleStatus Optional role-based status filter.
	 * @param filterVo       Optional list of filters for sorting and advanced filtering.
	 * @return Total count of repositories matching the criteria.
	 * @throws ApplicationException If an error occurs while fetching the count.
	 */
	@ApiOperation(
		value = "Count Repositories", 
		notes = "Returns the total count of repository records matching the given search value, user role status, and additional filters.",
		response = Long.class
	)
	@PostMapping("/repository-count")
	public Long getRepositoryListCount(
			@ApiParam(value = "Search value") @RequestParam(value = "search", required = false) String search,
			@ApiParam(value = "User Role status") @RequestParam(value = "userRoleStatus", required = false) String userRoleStatus,
			@ApiParam(value = "Filter or Sorting criteria for Repository") @RequestBody(required = false) List<FilterOrSortingVo> filterVo)
			throws ApplicationException {
		return iRepositoryService.getRepositoryListCount(filterVo,search,userRoleStatus);
	}


	/**
	 * Fetch a paginated list of repositories based on filters and search criteria.
	 * 
	 * @param min                 The minimum index for pagination (optional).
	 * @param max                 The maximum index for pagination (optional).
	 * @param filterVo            A list of filters for sorting and filtering (optional).
	 * @param userRoleStatus      The user role status filter (optional).
	 * @param search              A search keyword for filtering repositories (optional).
	 * @param httpServletRequest  The HTTP servlet request for context.
	 * @return A list of repositories matching the criteria.
	 * @throws ApplicationException If an error occurs while fetching the repository list.
	 */
	@ApiOperation(
		value = "Fetch Repository List", 
		notes = "Returns a paginated list of repositories based on provided search, filters, and role status.",
		response = DataRepositoryDto.class,
		responseContainer = "List"
	)
	@PostMapping("/repository-list")
	public List<DataRepositoryDto> getRepositoryCardList(
			@ApiParam(value = "Number of records to skip") @RequestParam(value = "min", required = false) Integer min,
			@ApiParam(value = "Maximum number of records to return") @RequestParam(value = "max", required = false) Integer max,
			@ApiParam(value = "Filter or Sorting criteria for Repository") @RequestBody(required = false) List<FilterOrSortingVo> filterVo,
			@ApiParam(value = "User Role status") @RequestParam(value = "userRoleStatus", required = false) String userRoleStatus,
			@ApiParam(value = "Search value") @RequestParam(value = "search", required = false) String search,
			HttpServletRequest httpServletRequest) throws ApplicationException {
		UserInfo userInfo = loggedInUserContextHolder.getLoggedInUser();
		return iRepositoryService.getRepositoryCardList(min, max, filterVo, userRoleStatus, userInfo,search,
				httpServletRequest);
	}

	/**
	 * Fetch comments associated with a specific repository.
	 * 
	 * @param repositoryIdentity  The unique identifier of the repository.
	 * @param httpServletRequest  The HTTP servlet request for context.
	 * @return A list of comments related to the given repository.
	 * @throws ApplicationException If an error occurs while retrieving comments.
	 */
	@ApiOperation(
		value = "Fetch Comments",
		notes = "Retrieves a list of comments associated with the specified repository identity.",
		response = CommentsDto.class,
		responseContainer = "List"
	)
	@GetMapping("/get-comments")
	public List<CommentsDto> getCommentsDetails(
			@ApiParam(value = "Unique Identifier for Repository", required = true) @RequestParam String repositoryIdentity,
			HttpServletRequest httpServletRequest) throws ApplicationException {
		return iRepositoryService.getCommentsValues(repositoryIdentity, httpServletRequest);
	}

	/**
	 * Save comments between the creator and approver for a repository.
	 * 
	 * @param commentsDto         The comment details to be saved.
	 * @param httpServletRequest  The HTTP servlet request for context.
	 * @return An application response indicating success or failure.
	 * @throws ApplicationException If an error occurs while saving the comment.
	 */
	@ApiOperation(
		value = "Save Comments",
		notes = "Stores a comment related to a repository, allowing communication between the creator and the approver.",
		response = ApplicationResponse.class
	)
	@PostMapping("/save-comments")
	public ApplicationResponse saveComments(
			@ApiParam(value = "CommentsDto Request PayLoad", required = true) @RequestBody CommentsDto commentsDto,
			HttpServletRequest httpServletRequest) throws ApplicationException {
		return getApplicationResponse(iRepositoryService.saveCommentsForRepository(commentsDto,
				loggedInUserContextHolder.getLoggedInUser(), httpServletRequest));
	}

	/**
	 * Check privilege access for a role.
	 * 
	 * This endpoint verifies the user's role-based access privileges.
	 * 
	 * @param httpServletRequest The HTTP request containing user session details.
	 * @return An application response indicating the privilege details.
	 * @throws ApplicationException If an error occurs while fetching privilege details.
	 */
	@ApiOperation(
		value = "Check Privilege Access",
		notes = "Validates the privilege access of the logged-in user based on their role.",
		response = ApplicationResponse.class
	)
	@GetMapping("/check-authority-type")
	public ApplicationResponse getUserPrivillegeDetails(HttpServletRequest httpServletRequest)
			throws ApplicationException {
		String response = iRepositoryService.getUserRoleDetails(loggedInUserContextHolder.getLoggedInUser(),
				httpServletRequest);
		return getApplicationResponse(response);
	}

	/**
	 * Fetch all scheduler list with filtering and sorting.
	 * 
	 * Retrieves a list of scheduled notifications based on the provided 
	 * filtering and sorting criteria.
	 * 
	 * @param min The minimum range value for pagination (optional).
	 * @param max The maximum range value for pagination (optional).
	 * @param filterVo A list of filter or sorting criteria (optional).
	 * @return A list of {@link SchedulerNotificationDto} containing scheduler details.
	 * @throws ApplicationException If an error occurs while fetching scheduler details.
	 */
	@ApiOperation(
		value = "Fetch Scheduler List",
		notes = "Retrieves a list of scheduled notifications based on optional filters and sorting criteria.",
		response = List.class
	)
	@PostMapping("/get-scheduler-list")
	public List<SchedulerNotificationDto> getSchedulerDetails(
			@ApiParam(value = "Minimum Number of records to skip") @RequestParam(value = "min", required = false) Integer min,
			@ApiParam(value = "Maximum number of records to return") @RequestParam(value = "max", required = false) Integer max,
			@ApiParam(value = "Filter or Sorting criteria for Repository") @RequestBody(required = false) List<FilterOrSortingVo> filterVo)
			throws ApplicationException {
		return iRepositoryService.getSchedulerDetails(min,max,filterVo);
	}
	
	/**
	 * Fetch scheduler total count of scheduler datas.
	 * @return {@link Long} value as result.
	 * @throws ApplicationException If an error occurs while fetching count.
	 */
	@ApiOperation(
			value = "Fetch Scheduler Count",
			notes = "Fetch scheduler total count based on optional filtered datas.",
			response = Long.class
		)
	@GetMapping("/scheduler-count")
	public Long getSchedulerListCount()
			throws ApplicationException {
		return iRepositoryService.getSchedulerListCount();
	}
	
	/**
	 * Rename repository name by {@link FieldRepositoryDto}
	 * 
	 * @param fieldRepositoryDto Given detail will processed and save.
	 * @return {@link ApplicationResponse} Content will be renamed repsository name.
	 * @throws ApplicationException If an error occurs while fetching scheduler
	 *                              details.
	 */
	@ApiOperation(value = "Renam Repository", 
			notes = "Rename Repository based on details given on FieldRepositoryDto.", 
			response = ApplicationResponse.class)
	@PutMapping("/update-repositoryname")
	public ApplicationResponse renameRepository(
			@ApiParam(value = "FieldRepositoryDto PayLoad", required = true) @RequestBody FieldRepositoryDto fieldRepositoryDto)
			throws ApplicationException {
		 String repositoryName = iRepositoryService.updateRepositoryName(fieldRepositoryDto,loggedInUserContextHolder.getLoggedInUser());
		 return getApplicationResponse(repositoryName);
	}
	 
	/**
	 * Update scheduler details.
	 * 
	 * Updates the scheduler details based on the provided request body containing 
	 * scheduling information.
	 * 
	 * @param repositoryScheduleDetailsDto The DTO containing scheduler update details.
	 * @return {@link ApplicationResponse} containing the update status message.
	 * @throws ApplicationException If an error occurs while updating scheduler details.
	 */
	@ApiOperation(
		value = "Update Scheduler Details",
		notes = "Updates the scheduler details based on the provided request body.",
		response = ApplicationResponse.class
	)
	@PostMapping("/update-scheduler")
	public ApplicationResponse updateSchedulerDetails(
			@ApiParam(value = "RepositorySchedulerDetailsDto Request PayLoad", required = true) @RequestBody RepositoryScheduleDetailsDto repositoryScheduleDetailsDto)
			throws ApplicationException {
		String response = iRepositoryService.updateSchedulerDetails(repositoryScheduleDetailsDto,
				loggedInUserContextHolder.getLoggedInUser());
		return getApplicationResponse(response);
	}
	
	/**
	 * Fetch scheduler details by scheduler identity.
	 * 
	 * Retrieves the scheduler details based on the provided scheduler identity.
	 * If no identity is provided, it may return default or filtered results.
	 * 
	 * @param schedulerIdentity The unique identifier for the scheduler (optional).
	 * @return {@link RepositoryScheduleDetailsDto} containing scheduler details.
	 * @throws ApplicationException If an error occurs while fetching scheduler details.
	 */
	@ApiOperation(
		value = "Fetch Scheduler Details",
		notes = "Retrieves scheduler details based on the provided scheduler identity.",
		response = RepositoryScheduleDetailsDto.class
	)
	@GetMapping("/get-scheduler-details")
	public RepositoryScheduleDetailsDto getSchedulerDetails(
			@ApiParam(value = "Unique Identifier fot Scheduler") @RequestParam(required = false, name = "schedulerIdentity") String schedulerIdentity)
			throws ApplicationException {
		return iRepositoryService.editschedulerDetails(schedulerIdentity);
	}


	/**
	 * Delete scheduler details by scheduler identity.
	 * 
	 * Marks the scheduler identified by the given scheduler identity for deletion.
	 * If no identity is provided, appropriate handling should be implemented.
	 * 
	 * @param schedulerIdentity The unique identifier of the scheduler to be deleted (optional).
	 * @return {@link ApplicationResponse} containing the status of the deletion request.
	 * @throws ApplicationException If an error occurs during the deletion process.
	 */
	@ApiOperation(
		value = "Delete Scheduler",
		notes = "Deletes a scheduler identified by the provided scheduler identity.",
		response = ApplicationResponse.class
	)
	@PutMapping("/scheduler-delete")
	public ApplicationResponse updateSchedulerDelete(
			@ApiParam(value = "Unique Identifier fot Scheduler") @RequestParam(required = false, name = "schedulerIdentity") String schedulerIdentity)
			throws ApplicationException {
		String response = iRepositoryService.schedulerDelete(schedulerIdentity, loggedInUserContextHolder.getLoggedInUser());
		return getApplicationResponse(response);
	}
	
	/**
	 * Fetches the list of approved repositories based on filtering criteria.
	 * 
	 * Retrieves a paginated list of repositories that have been approved, with 
	 * optional search, sorting, and filtering parameters.
	 * 
	 * @param min         The minimum index for pagination (optional).
	 * @param max         The maximum index for pagination (optional).
	 * @param isApproved  A flag indicating whether the repository is approved (required).
	 * @param search      A search query for filtering repositories (optional).
	 * @param filterVo    A list of filter and sorting criteria (optional).
	 * @return A list of {@link DataRepositoryDto} objects matching the criteria.
	 * @throws ApplicationException If an error occurs while retrieving the data.
	 */
	@ApiOperation(
		value = "Get Approved Repository List",
		notes = "Retrieves a paginated list of approved repositories based on filtering and sorting criteria.",
		response = DataRepositoryDto.class,
		responseContainer = "List"
	)
	@PostMapping("/repository-approved-list")
	public List<DataRepositoryDto> getRepositoryCardListforApproved(
			@ApiParam(value = "Minimum number of records to skip") @RequestParam(value = "min", required = false) Integer min,
			@ApiParam(value = "IsApproved Status") @RequestParam(name = "isApproved") String isApproved,
			@ApiParam(value = "Maximum number of records to return") @RequestParam(value = "max", required = false) Integer max,
			@ApiParam(value = "Search value") @RequestParam(value = "search", required = false) String search,
			@ApiParam(value = "Filter or Sorting criteria for Repository") @RequestBody(required = false) List<FilterOrSortingVo> filterVo)
			throws ApplicationException {
		UserInfo userInfo = loggedInUserContextHolder.getLoggedInUser();
		Boolean parsedBoolean = Boolean.parseBoolean(isApproved);
		return iRepositoryService.getRepositoryCardListforApproved(min, max, filterVo, search, userInfo, parsedBoolean);
	}
	
	/**
	 * Fetches the count of approved repositories based on filtering criteria.
	 * 
	 * This endpoint returns the total number of repositories that have been approved, 
	 * based on optional search and filter parameters.
	 * 
	 * @param isApproved  A flag indicating whether the repository is approved (required).
	 * @param search      A search query for filtering repositories (optional).
	 * @param filterVo    A list of filter and sorting criteria (optional).
	 * @return The total count of approved repositories matching the criteria.
	 * @throws ApplicationException If an error occurs while retrieving the data.
	 */
	@ApiOperation(
		value = "Get Approved Repository Count",
		notes = "Returns the total count of approved repositories based on search and filter criteria.",
		response = Long.class
	)
	@PostMapping("/repository-approved-count")
	public Long getRepositoryApprovedListCount(
			@ApiParam(value = "IsApproved Status") @RequestParam(name = "isApproved") String isApproved,
			@ApiParam(value = "Search Value") @RequestParam(value = "search", required = false) String search,
			@ApiParam(value = "Filter or Sorting criteria PayLoad") @RequestBody(required = false) List<FilterOrSortingVo> filterVo)
			throws ApplicationException {
		Boolean parsedBoolean = Boolean.parseBoolean(isApproved);
		return iRepositoryService.getRepositoryApprovedListCount(filterVo, search, parsedBoolean);
	}
	
	/**
	 * Fetches the status of a repository based on its unique identifier.
	 * 
	 * This endpoint retrieves the current status details of a repository.
	 * 
	 * @param repositoryIdentity The unique identifier of the repository.
	 * @return The status details of the repository wrapped in an {@link ApplicationResponse}.
	 */
	@ApiOperation(
		value = "Get Repository Status",
		notes = "Retrieves the status of a repository using its unique identity.",
		response = ApplicationResponse.class
	)
	@GetMapping("/repository-status")
	public ApplicationResponse getRepositoryStatus(
			@ApiParam(value = "Unique Identifier fot Repository") @RequestParam(name = "identity") String repositoryIdentity) {
		return getApplicationResponse(iRepositoryService.getRepositoryStatusByIdentity(repositoryIdentity));
	}
	
	/**
	 * Validates company upload list records by association ID and a given date.
	 * 
	 * This API checks the status of uploaded company records for a specific association ID
	 * and date.
	 * 
	 * @param associationId The unique identifier of the association.
	 * @param fromDate The date from which records should be validated (Format: yyyy-MM-dd).
	 * @return A list of validation messages or errors related to the company upload.
	 * @throws ApplicationException If any error occurs during validation.
	 * @throws UnsupportedEncodingException If an encoding issue occurs.
	 */
	@ApiOperation(
		value = "Validate Company Upload List",
		notes = "Validates uploaded company records based on association ID and date.",
		response = List.class
	)
	@GetMapping("/validate-company-upload-list")
	public List<String> getCompanyUploadNameList(
			@ApiParam(value = "Association Id", required = true) @RequestParam(value = "associationId") Integer associationId,
			@ApiParam(value = "Start Date", required = true) @RequestParam(value = "fromDate") String fromDate)
			throws ApplicationException, UnsupportedEncodingException {
		return iRepositoryService.getCompanyUploadStatus(associationId,fromDate);
	}
	
	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}


	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}


	@Override
	protected void registerInterceptor() {
		
	}
}
