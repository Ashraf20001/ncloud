package com.ncloud.dl.datatype.factory;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.ncloud.dl.constants.core.ApplicationConstants;
import com.ncloud.dl.utils.core.ApplicationUtils;

/**
 * The Class BooleanFactoryBuilder.
 */
@Qualifier("booleanBuilder")
@Service
public class BooleanFactoryBuilder implements IDataTypeFactoryBuilder{

	/**
	 * Gets the data type with col query.
	 *
	 * @param createQuery the create query
	 * @param fldQuery the fld query
	 * @return the data type with col query
	 */
	@Override
	public String getDataTypeWithColQuery(String createQuery, String fldQuery) {
		return ApplicationUtils.isValidString(fldQuery) ? createQuery + ApplicationConstants.BOOLEAN + fldQuery: createQuery + ApplicationConstants.BOOLEAN;
	}

}
