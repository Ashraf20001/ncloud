package com.ncloud.dl.dao.impl.datarespository;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.PersistenceException;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.hibernate.query.NativeQuery;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.ncloud.dl.config.common.base.dao.BaseDao;
import com.ncloud.dl.config.model.FilterOrSortingVo;
import com.ncloud.dl.constants.core.ApplicationConstants;
import com.ncloud.dl.constants.core.TableConstants;
import com.ncloud.dl.dao.datarespository.IDataRepositoryDao;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.dto.RepositoryDto;
import com.ncloud.dl.transfer.object.entity.BulkUploadHistory;
import com.ncloud.dl.transfer.object.entity.Comments;
import com.ncloud.dl.transfer.object.entity.DataRepository;
import com.ncloud.dl.transfer.object.entity.FieldConfiguration;
import com.ncloud.dl.transfer.object.entity.RepositoryScheduleDetails;
import com.ncloud.dl.transfer.object.entity.SchedulerNotification;
import com.ncloud.dl.transfer.object.entity.SearchHistory;
import com.ncloud.dl.transfer.object.enums.BulkUploadStatusEnum;
import com.ncloud.dl.transfer.object.enums.RepositoryStatusEnum;
import com.ncloud.dl.utils.BuildQueryUtils;
import com.ncloud.dl.utils.core.ApplicationUtils;

import lombok.RequiredArgsConstructor;

/**
 * The Class DataRepositoryDaoImpl.
 */
@Repository
@RequiredArgsConstructor
public class DataRepositoryDaoImpl extends BaseDao implements IDataRepositoryDao {
	
	/** The build query utils. */
	private final BuildQueryUtils buildQueryUtils;

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
	}
	
	/** The Constant loggers. */
	private static final Logger loggers= LoggerFactory.getLogger(DataRepositoryDaoImpl.class);
	/**
	 * @param repositoryId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<FieldConfiguration> getFieldRepository(String repositoryId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<FieldConfiguration> createQuery = builder.createQuery(FieldConfiguration.class);
		Root<FieldConfiguration> root = createQuery.from(FieldConfiguration.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLTSTS), false)));
		predicates.add(builder
				.and(builder.equal(root.get(TableConstants.REPO_ID).get(TableConstants.IDENTITY), repositoryId)));
		createQuery.orderBy(builder.asc(root.get(TableConstants.FIELD_ORDER)));
		return (List<FieldConfiguration>) getResultList(createQuery(builder, createQuery, root, predicates));
	}

	
	/**
	 * @param repositoryId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<String> getFieldRepositoryColumnName(String repositoryIdentity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<FieldConfiguration> createQuery = builder.createQuery(FieldConfiguration.class);
		Root<FieldConfiguration> root = createQuery.from(FieldConfiguration.class);
		createQuery.select(root.get(TableConstants.FIELD_NAME));
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLTSTS), false)));
		predicates.add(builder
				.and(builder.equal(root.get(TableConstants.REPO_ID).get(TableConstants.IDENTITY), repositoryIdentity)));
		createQuery.orderBy(builder.asc(root.get(TableConstants.FIELD_ORDER)));
		return (List<String>) getResultList(createQuery(builder, createQuery, root, predicates));
	}

	/**
	 * @param repositoryId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<RepositoryDto> getSearchableFields(String repositoryName, List<Integer> searchTypeId ,Boolean isApiIntegeration) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<RepositoryDto> createQuery = builder.createQuery(RepositoryDto.class);
		Root<FieldConfiguration> root = createQuery.from(FieldConfiguration.class);
		createQuery.multiselect(root.get(TableConstants.COLUMN_NAME), root.get(TableConstants.REPO_ID).get(TableConstants.REPOSITORY_NAME), root.get(TableConstants.REPO_ID).get(TableConstants.REPOSITORY_TABLE_NAME));
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLTSTS), Boolean.FALSE)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.REPO_ID).get(TableConstants.IS_DELETE_STS), false)));
		predicates.add(builder.and(root.get(TableConstants.SEARCH_TYPE).in(searchTypeId)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.REPO_ID).get(TableConstants.REPO_STATUS),
				RepositoryStatusEnum.APPROVED.getStatusId())));
		predicates
				.add(builder.and(builder.equal(root.get(TableConstants.REPO_ID).get(TableConstants.IS_DLTSTS), false)));
		if (ApplicationUtils.isValidString(repositoryName)) {
			predicates.add(builder.and(isApiIntegeration.equals(Boolean.FALSE)
					? builder.equal(root.get(TableConstants.REPO_ID).get(TableConstants.REPO_NAME), repositoryName)
					: builder.equal(root.get(TableConstants.REPO_ID).get(TableConstants.REPOSITORY_API_NAME),
							repositoryName)));
		}
		predicates.add(builder.and(
				builder.equal(root.get(TableConstants.REPO_ID).get(TableConstants.IS_ACTIVE), true)));
		predicates.add(builder.and(builder.isNull(root.get(TableConstants.REPO_ID).get(TableConstants.EFFECTIVE_DATE))));
		createQuery.orderBy(builder.asc(root.get(TableConstants.FIELD_ORDER)));
		return (List<RepositoryDto>) getResultList(createQuery(builder, createQuery, root, predicates));
	}

	/**
	 * @param repoName
	 * @param repoId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<DataRepository> getDataRepositoryByRepoNameAndId(String repoName, String repoId, String identity, Boolean isCloned, Double repoVersion, List<String> list) {
		CriteriaBuilder criteriaBuilder = getCriteriaBuilder();
		CriteriaQuery<DataRepository> criteriaQuery = criteriaBuilder.createQuery(DataRepository.class);
		Root<DataRepository> root = criteriaQuery.from(DataRepository.class);
		criteriaQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		Predicate orPredicate = criteriaBuilder.disjunction();
		orPredicate.getExpressions()
				.add(criteriaBuilder.and(criteriaBuilder.equal(criteriaBuilder.lower(root.get(TableConstants.REPO_NAME)), repoName.toLowerCase())));
		orPredicate.getExpressions()
				.add(criteriaBuilder.and(criteriaBuilder.equal(criteriaBuilder.lower(root.get(TableConstants.REPOSITORY_ID)), repoId.toLowerCase())));
		predicates.add(orPredicate);
		if((ApplicationUtils.isValidateObject(identity) && (ApplicationUtils.isValidBoolean(isCloned) ? isCloned : true)) || repoVersion > 1.0) {
			predicates.add(criteriaBuilder.and(criteriaBuilder.not(root.get(TableConstants.IDENTITY).in(list))));
		}
		predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get(TableConstants.IS_DLTSTS), Boolean.FALSE)));
		return (List<DataRepository>) getResultList(createQuery(criteriaBuilder, criteriaQuery, root, predicates));
	}

	/**
	 * @param dataRepository
	 * @throws ApplicationException
	 */
	@Override
	public void updateRepostioryDetails(DataRepository dataRepository) throws ApplicationException {
		update(dataRepository);
	}

	/**
	 * @param dataRepository
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public DataRepository saveRepostioryDetails(DataRepository dataRepository) throws ApplicationException {
		save(dataRepository, TableConstants.DATA_REPOSITORY);
		return dataRepository;
	}

	/**
	 * @param repositoryIdentity
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Comments> getCommentsValues(String repositoryIdentity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Comments> createQuery = builder.createQuery(Comments.class);
		Root<Comments> root = createQuery.from(Comments.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.REPOSITORY_ID).get(TableConstants.IDENTITY),
				repositoryIdentity)));
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.IS_DELETE_STS))));
		createQuery.orderBy(builder.asc(root.get(TableConstants.CREATED_DATE)));
		return (List<Comments>) getResultList(createQuery(builder, createQuery, root, predicates));
	}

	/**
	 * @param repositoryIdentity
	 * @return
	 */
	@Override
	public DataRepository getUpdateStatusDataRepository(String repositoryIdentity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<DataRepository> createQuery = builder.createQuery(DataRepository.class);
		Root<DataRepository> root = createQuery.from(DataRepository.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get("isDltSts"), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IDENTITY), repositoryIdentity)));
		return (DataRepository) getSingleResult(createQuery(builder, createQuery, root, predicates));
	}

	/**
	 * @param dataRepository
	 */
	@Override
	public void saveUpdateStatusDataRepository(DataRepository dataRepository) {
		update(dataRepository);
	}

	/**
	 * @param dataRepositorys
	 */
	@Override
	public void UpdateRepostioryDetails(DataRepository dataRepositorys) {
		update(dataRepositorys);

	}

	/**
	 * @param filterVo
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Long getRepositoryCountValue(List<FilterOrSortingVo> filterVo,String search,String userRoleStatus) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<DataRepository> root = criteria.from(DataRepository.class);
		criteria.select(builder.count(root));
		List<Predicate> predicates = new ArrayList<>();
		if(ApplicationUtils.isValidString(search)) {
			predicates = buildQueryUtils.validateQueryAndBuild(search, builder, root, predicates);
		}
        if(ApplicationUtils.isValidList(filterVo)) {
        	filterVo=filterVo.stream().filter(filter->filter.getFilterOrSortingType().equalsIgnoreCase(ApplicationConstants.FILTER))
        						.collect(Collectors.toList());
        	List<Predicate> getfilterPredicates = getFilterPrdicets(filterVo, root, builder, criteria);
        	predicates.addAll(getfilterPredicates);
        }
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLTSTS), false)));
		return (Long) getSingleResult(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * @param min
	 * @param max
	 * @param filterVo
	 * @param userRoleStatus
	 * @return
	 * @throws ApplicationException
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<DataRepository> getDataRepositoryList(Integer min, Integer max, List<FilterOrSortingVo> filterVo,
			String userRoleStatus, String search) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<DataRepository> criteria = builder.createQuery(DataRepository.class);
		Root<DataRepository> root = criteria.from(DataRepository.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		if (ApplicationUtils.isValidString(search)) {
			predicates = buildQueryUtils.validateQueryAndBuild(search, builder, root, predicates);
		}
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLTSTS), false)));
		List<Predicate> filtersPredicates = getFilterPrdicets(filterVo, root, builder, criteria);
		predicates.addAll(filtersPredicates);
		if (Boolean.FALSE.equals(ApplicationUtils.isValidList(filterVo))) {
			criteria.orderBy(builder.desc(root.get(TableConstants.MODI_DATE)));
		}
		return ApplicationUtils.isValidId(max)
				? (List<DataRepository>) getResultList(
						createQuery(builder, criteria, root, predicates).setFirstResult(min).setMaxResults(max))
				: (List<DataRepository>) getResultList(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * @param singleAddRepositoryDto
	 * @param repoTableName
	 * @return
	 * @return
	 * @return
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public void saveSingleFieldData(List<Object> singleAddRepository, String repoTableName)
			throws ApplicationException {
		try {
			executeQuery(singleAddRepository, repoTableName);
		} catch (ApplicationException e) {
			e.printStackTrace();
			loggers.error(e.getMessage());
		}
	}

	/**
	 * @param values
	 * @param query
	 * @return
	 * @throws ApplicationException
	 */
	private void executeQuery(List<Object> values, String query) throws ApplicationException {
		NativeQuery<?> nq = (NativeQuery<?>) getQuery(query);
		for (int i = 0; i < values.size(); i++) {
			nq.setParameter("" + i, values.get(i));
		}
		System.out.println(nq.getQueryString());
		try {
			nq.executeUpdate();
		} catch (PersistenceException pe) {
			throw new ApplicationException("Incorrect Query");
		}
	}
	
	/**
	 * Gets the result list.
	 *
	 * @return the result list
	 */
	public List<?> getResultList() {
        return Collections.emptyList();
    }

	/**
	 * @param repoTableName
	 * @param columnParams
	 * @param columns
	 * @return
	 */
	@Override
	public String generateInsertQuery(String repoTableName, String columnParams, String columns) {
		StringBuffer sb = new StringBuffer();
		sb.append(ApplicationConstants.INSERT);
		sb.append(ApplicationConstants.SPACES);
		sb.append(ApplicationConstants.INTO);
		sb.append(ApplicationConstants.SPACES);
		sb.append(ApplicationConstants.DOUBLE_QUOTES);
		sb.append(repoTableName);
		sb.append(ApplicationConstants.DOUBLE_QUOTES);
		sb.append(ApplicationConstants.SPACES);
		sb.append(ApplicationConstants.OPEN_BRACES);
		sb.append(ApplicationConstants.SPACES);
		sb.append(columns);
		sb.append(ApplicationConstants.SPACES);
		sb.append(ApplicationConstants.CLOSE_BRACES);
		sb.append(ApplicationConstants.SPACES);
		sb.append(ApplicationConstants.VALUES);
		sb.append(ApplicationConstants.SPACES);
		sb.append(ApplicationConstants.SPACES);
		sb.append(columnParams);
		sb.append(ApplicationConstants.SEMICOLON);

		return sb.toString();
	}
	
	/**
	 * @param repoName
	 * @param hashCodeObj
	 * @return
	 */
	@Override
	public String generateSelectQuery(String repoName, Integer hashCodeObj) {
		
		StringBuilder builder = new StringBuilder();
		builder.append(ApplicationConstants.SELECT_QUERY);
		builder.append(ApplicationConstants.SPACES);
		builder.append(ApplicationConstants.DOUBLE_QUOTES);
		builder.append(repoName);
		builder.append(ApplicationConstants.DOUBLE_QUOTES);
		builder.append(ApplicationConstants.WHERE);
		builder.append(ApplicationConstants.SPACES);
		builder.append(ApplicationConstants.HASH_CODE);
		builder.append(ApplicationConstants.SPACES);
		builder.append(ApplicationConstants.EQUAL_STRING);
		builder.append(ApplicationConstants.SPACES);
		builder.append(ApplicationConstants.SINGLE_QUOTES);
		builder.append(hashCodeObj);
		builder.append(ApplicationConstants.SINGLE_QUOTES);
		builder.append(ApplicationConstants.SEMICOLON);
		
		return builder.toString();
	}

	/**
	 * @param min
	 * @param max
	 * @return
	 * @throws ApplicationException
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<SchedulerNotification> getSchedulerDetailsdao(Integer min, Integer max,List<FilterOrSortingVo> filterVo) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<SchedulerNotification> createQuery = builder.createQuery(SchedulerNotification.class);
		Root<SchedulerNotification> root = createQuery.from(SchedulerNotification.class);
		createQuery.select(root);
		List<Predicate> predicates = getFilterPrdicets(filterVo, root, builder, createQuery);
		predicates.add(builder.equal(root.get(TableConstants.IS_DLTSTS), false));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.REPOSITORYID).get(TableConstants.REPO_STATUS),
				RepositoryStatusEnum.APPROVED.getStatusId())));
		if(!ApplicationUtils.isValidList(filterVo)) {
		 createQuery.orderBy(builder.desc(root.get(TableConstants.MODI_DATE)));
		}
		return (List<SchedulerNotification>) getResultList(createQuery(builder, createQuery, root, predicates).setFirstResult(min).setMaxResults(max));
	}

	/**
	 *
	 */
	@Override
	public Long getSchedulerCountValue() throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<SchedulerNotification> root = criteria.from(SchedulerNotification.class);
		criteria.select(builder.count(root));
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLTSTS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.REPOSITORYID).get(TableConstants.REPO_STATUS),
				RepositoryStatusEnum.APPROVED.getStatusId())));
		return (Long) getSingleResult(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * @param id
	 * @return
	 */
	@Override
	public RepositoryScheduleDetails getrepositorySchedulerDetails(String id) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<RepositoryScheduleDetails> createQuery = builder.createQuery(RepositoryScheduleDetails.class);
		Root<RepositoryScheduleDetails> root = createQuery.from(RepositoryScheduleDetails.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.SCHEDULER_NOTI_ID).get(TableConstants.IDENTITY),id)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLTSTS), false)));
		return (RepositoryScheduleDetails) getSingleResult(createQuery(builder, createQuery, root, predicates));

	}

	/**
	 * @param schedulerIdentity
	 * @return
	 */
	@Override
	public SchedulerNotification getSchedulerTableDetails(String schedulerIdentity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<SchedulerNotification> createQuery = builder.createQuery(SchedulerNotification.class);
		Root<SchedulerNotification> root = createQuery.from(SchedulerNotification.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETE_STS), false)));
		predicates.add(builder
		.and(builder.equal(root.get(TableConstants.REPOSITORY_ID).get(TableConstants.IDENTITY), schedulerIdentity)));
		return (SchedulerNotification) getSingleResult(createQuery(builder, createQuery, root, predicates));
	}

	/**
	 * @param schedulerIdentity
	 * @return
	 */
	@Override
	public SchedulerNotification getSchedulerDetails(String schedulerIdentity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<SchedulerNotification> createQuery = builder.createQuery(SchedulerNotification.class);
		Root<SchedulerNotification> root = createQuery.from(SchedulerNotification.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLTSTS), false)));
		predicates.add(builder
		.and(builder.equal(root.get(TableConstants.REPOSITORY_ID).get(TableConstants.IDENTITY), schedulerIdentity)));
		return (SchedulerNotification) getSingleResult(createQuery(builder, createQuery, root, predicates));
	}

	/**
	 * @param schedulerNotification
	 */
	@Override
	public void saveUpdatestatusScheduler(SchedulerNotification schedulerNotification) {
		update(schedulerNotification);

	}

	/**
	 * Gets the data repository list for approved.
	 *
	 * @param min the min
	 * @param max the max
	 * @param filterVo the filter vo
	 * @param search the search
	 * @param isApproved the is approved
	 * @return the data repository list for approved
	 * @throws ApplicationException the application exception
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<DataRepository> getDataRepositoryListForApproved(Integer min, Integer max, List<FilterOrSortingVo> filterVo,String search, Boolean isApproved) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<DataRepository> criteria = builder.createQuery(DataRepository.class);
		Root<DataRepository> root = criteria.from(DataRepository.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		if (ApplicationUtils.isValidString(search)) {
			predicates = buildQueryUtils.validateQueryAndBuild(search, builder, root, predicates);
		}
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLTSTS), false)));
		if (isApproved) {
			predicates.add(builder.and(
					builder.equal(root.get(TableConstants.REPO_STATUS), RepositoryStatusEnum.APPROVED.getStatusId())));
			predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_ACTIVE), true)));
		} else {
			predicates.add(builder.or(
					builder.equal(root.get(TableConstants.REPO_STATUS), RepositoryStatusEnum.DISABLED.getStatusId()),
					builder.equal(root.get(TableConstants.REPO_STATUS), RepositoryStatusEnum.APPROVED.getStatusId())));
		}
		criteria.orderBy(builder.desc(root.get(TableConstants.MODI_DATE)));
		List<Predicate> filtersPredicates = getFilterPrdicets(filterVo, root, builder, criteria);
		predicates.addAll(filtersPredicates);
		return ApplicationUtils.isValidId(max)
				? (List<DataRepository>) getResultList(
						createQuery(builder, criteria, root, predicates).setFirstResult(min).setMaxResults(max))
				: (List<DataRepository>) getResultList(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * @param bulkUploadHistoryDto
	 * @return
	 */
	@Override
	public BulkUploadHistory getBulkUploadHistory(String bulkUploadIdentity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<BulkUploadHistory> createQuery = builder.createQuery(BulkUploadHistory.class);
		Root<BulkUploadHistory> root = createQuery.from(BulkUploadHistory.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETE_STS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IDENTITY),bulkUploadIdentity)));
		return (BulkUploadHistory) getSingleResult(createQuery(builder, createQuery, root, predicates));
	}

	/**
	 * Gets the field repository search.
	 *
	 * @param repositoryName the repository name
	 * @param searchTypeIds the search type ids
	 * @return the field repository search
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<FieldConfiguration> getFieldRepositorySearch(String repositoryName, List<Integer> searchTypeIds) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<FieldConfiguration> createQuery = builder.createQuery(FieldConfiguration.class);
		Root<FieldConfiguration> root = createQuery.from(FieldConfiguration.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLTSTS), false)));
		predicates.add(builder.and(root.get(TableConstants.SEARCH_TYPE).in(searchTypeIds)));
		predicates.add(builder
				.and(builder.equal(root.get(TableConstants.REPO_ID).get(TableConstants.REPO_NAME), repositoryName)));
		predicates.add(builder
				.and(builder.equal(root.get(TableConstants.REPO_ID).get(TableConstants.IS_ACTIVE), true)));
		predicates.add(builder
				.and(builder.equal(root.get(TableConstants.REPO_ID).get(TableConstants.IS_DLTSTS), false)));
		return (List<FieldConfiguration>) getResultList(createQuery(builder, createQuery, root, predicates));
	}
	
	/**
	 * @param repositoryId
	 * @return
	 */
	@Override
	public DataRepository getRepositoryInfoByRepositoryName(String repositoryName) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<DataRepository> createQuery = builder.createQuery(DataRepository.class);
		Root<DataRepository> root = createQuery.from(DataRepository.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLTSTS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.REPOSITORY_NAME), repositoryName)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_ACTIVE), true)));
		return (DataRepository) getResultList(createQuery(builder, createQuery, root, predicates)).stream().findFirst().orElse(null);
	}

	/**
	 * @param filterVo
	 * @param search
	 * @return
	 * @throws ApplicationException 
	 */
	@Override
	public Long getRepositoryApprovedCountValue(List<FilterOrSortingVo> filterVo, String search, Boolean isApproved) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<DataRepository> root = criteria.from(DataRepository.class);
		criteria.select(builder.count(root));
		List<Predicate> predicates = new ArrayList<>();
		if(ApplicationUtils.isValidString(search)) {
			predicates = buildQueryUtils.validateQueryAndBuild(search, builder, root, predicates);
		}
		if (isApproved) {
			predicates.add(builder.and(
					builder.equal(root.get(TableConstants.REPO_STATUS), RepositoryStatusEnum.APPROVED.getStatusId())));
			predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_ACTIVE), true)));
		} else {
			predicates.add(builder.or(
					builder.equal(root.get(TableConstants.REPO_STATUS), RepositoryStatusEnum.DISABLED.getStatusId()),
					builder.equal(root.get(TableConstants.REPO_STATUS), RepositoryStatusEnum.APPROVED.getStatusId())));
		}
		if(ApplicationUtils.isValidList(filterVo)) {
			filterVo=filterVo.stream().filter(filter->filter.getFilterOrSortingType().equalsIgnoreCase(ApplicationConstants.FILTER))
					.collect(Collectors.toList());
			List<Predicate> getfilterPredicates = getFilterPrdicets(filterVo, root, builder, criteria);
			predicates.addAll(getfilterPredicates);
		}
		
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLTSTS), false)));
		return (Long) getSingleResult(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Save both search history.
	 *
	 * @param searchHistory the search history
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void saveBothSearchHistory(SearchHistory searchHistory) throws ApplicationException {
		save(searchHistory, TableConstants.SEARCH_HISTORY);
		
	}

	/**
	 * @param companyIdList
	 * @param minDateTime
	 * @param maxDateTime
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<BulkUploadHistory> getBulkUploadHistoryDetails(List<Integer> companyIdList , LocalDateTime fromDate, LocalDateTime toDate) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<BulkUploadHistory> createQuery = builder.createQuery(BulkUploadHistory.class);
		Root<BulkUploadHistory> root = createQuery.from(BulkUploadHistory.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLTSTS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.UPLOAD_STATUS), BulkUploadStatusEnum.COMPLETED.getStatusId())));
		predicates.add(builder.and(root.get(TableConstants.COMPANY_ID).in(companyIdList)));
		Predicate amountBetweenPredicate = builder.and(
			    builder.between(root.get(TableConstants.MODI_DATE), fromDate, toDate));
		predicates.add(amountBetweenPredicate);
		createQuery.where(predicates.toArray(new Predicate[0]));
		return (List<BulkUploadHistory>) getResultList(createQuery(builder, createQuery, root, predicates));
	}
}
