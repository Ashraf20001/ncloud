package com.ncloud.dl.search.eswrapper;

import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.ParseException;
import org.apache.http.util.EntityUtils;

import lombok.NoArgsConstructor;

/**
 * The Class EntityUtilsImpl.
 */
@NoArgsConstructor
public class EntityUtilsImpl {
	
	 /**
 	 * To string.
 	 *
 	 * @param entity the entity
 	 * @return the string
 	 * @throws IOException Signals that an I/O exception has occurred.
 	 * @throws ParseException the parse exception
 	 */
 	public String toString(final HttpEntity entity) throws IOException, ParseException {
		 return EntityUtils.toString(entity);
	 }
	
}
