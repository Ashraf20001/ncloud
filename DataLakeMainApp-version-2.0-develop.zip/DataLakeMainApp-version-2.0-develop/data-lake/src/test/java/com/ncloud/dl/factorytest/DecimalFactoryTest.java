package com.ncloud.dl.factorytest;

import static org.mockito.ArgumentMatchers.anyString;

import java.util.Map;
import java.util.Map.Entry;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.ncloud.dl.DataLakeApplication;
import com.ncloud.dl.datatype.factory.DecimalFactoryBuilder;
import com.ncloud.dl.exception.core.ApplicationException;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DataLakeApplication.class)
public class DecimalFactoryTest {
	
	@InjectMocks
	private DecimalFactoryBuilder decimalFactoryBuilder;
	
	@Test
	public void singleAddForRepository_ErrorFlow() throws ApplicationException {
		try {
			decimalFactoryBuilder.getDataTypeWithColQuery("23.0",null);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void singleAddForRepository_HappyFlow() throws ApplicationException {
		try {
			decimalFactoryBuilder.getDataTypeWithColQuery("23.0","23.0");
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
