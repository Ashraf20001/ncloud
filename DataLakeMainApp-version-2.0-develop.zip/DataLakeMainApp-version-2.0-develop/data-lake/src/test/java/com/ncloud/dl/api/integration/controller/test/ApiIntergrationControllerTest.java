package com.ncloud.dl.api.integration.controller.test;

import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.ncloud.dl.DataLakeApplication;
import com.ncloud.dl.controller.ApiIntergrationController;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.service.IBulkUploadService;
import com.ncloud.dl.service.ISearchService;
import com.ncloud.dl.transfer.object.dto.ApiIntergrationDto;
import com.ncloud.dl.transfer.object.dto.CustomFilterSortingVo;
import com.ncloud.dl.transfer.object.dto.SearchResponseDto;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DataLakeApplication.class)
public class ApiIntergrationControllerTest  {
	
	@InjectMocks
	private ApiIntergrationController apiIntergrationController;
	
	@Mock
	private ISearchService iSearchServiceMock;
	
	@Mock
	private IBulkUploadService iBulkUploadServiceMock;
	
	@Test
	public void getRepositorySearchList_happyFlow() {
		try {
			when(iSearchServiceMock.commonSearch("test", "test", 0L, 10L, 2, new CustomFilterSortingVo(), Boolean.TRUE)).thenReturn(null);
			apiIntergrationController.getRepositorySearchList(10L, 10L, "test", getApiIntergrationDto());
		} catch (Exception e) {
			e.printStackTrace();
			Assertions.fail();
		}
	}
	
	@Test
	public void getRepositorySearchList_happyFlow2() {
		try {
			 ApiIntergrationController apiIntergrationController = new ApiIntergrationController(iSearchServiceMock, iBulkUploadServiceMock);
			 
			 Field skipField = ApiIntergrationController.class.getDeclaredField("skip");
			 Field limitField = ApiIntergrationController.class.getDeclaredField("limit");
			 
			 skipField.setAccessible(true);
		     limitField.setAccessible(true);
		     skipField.set(apiIntergrationController, "0");
		     limitField.set(apiIntergrationController, "10000");
			when(iSearchServiceMock.commonSearch("test", "test", null, null, 2, new CustomFilterSortingVo(), Boolean.TRUE)).thenReturn(null);
			apiIntergrationController.getRepositorySearchList(null, null, "test", getApiIntergrationDto());
		} catch (Exception e) {
			e.printStackTrace();
			Assertions.fail();
		}
	}
	
	@Test
	public void globalSearch_happyFlow() {
		
		try {
			when(iSearchServiceMock.globalSearch("test", 10L, 10L, "test", Boolean.TRUE)).thenReturn(getSearchResponseDtos());
			apiIntergrationController.globalSearch(getApiIntergrationDto(), 0L, 10L);
		} catch(Exception e) {
			e.printStackTrace();
			Assertions.fail();
		}
	}
	
	@Test
	public void globalSearch_happyFlow2() {
		
		try {
			ApiIntergrationController apiIntergrationController = new ApiIntergrationController(iSearchServiceMock, iBulkUploadServiceMock);
			
			Field skipField = ApiIntergrationController.class.getDeclaredField("skip");
			Field limitField = ApiIntergrationController.class.getDeclaredField("limit");
			
			skipField.setAccessible(true);
			limitField.setAccessible(true);
			skipField.set(apiIntergrationController, "0");
			limitField.set(apiIntergrationController, "10000");
			when(iSearchServiceMock.globalSearch("test", 10L, 10L, "test", Boolean.TRUE)).thenReturn(getSearchResponseDtos());
			apiIntergrationController.globalSearch(getApiIntergrationDto(), null, null);
		} catch(Exception e) {
			e.printStackTrace();
			Assertions.fail();
		}
	}
	
	
	@Test
	public void singleAddForRepository_happyFlow() {
		HashMap<String, Object> singleAddRepository = new HashMap<String,Object>();
		try {
			when(iBulkUploadServiceMock.singleRecordForRepository("test", singleAddRepository)).thenReturn("test");
			apiIntergrationController.singleAddForRepository("test", singleAddRepository);
		} catch(Exception e) {
			e.printStackTrace();
			Assertions.fail();
		}
	}
	
	@Test
	public void getVo_happyFlow() {
		try {
			apiIntergrationController.getVo("test");
		} catch (ApplicationException e) {
			e.printStackTrace();
			Assertions.fail();
		}
	}
	
	public SearchResponseDto getSearchResponseDto() {
		SearchResponseDto data = new SearchResponseDto();
		data.setIndex("23");
		data.setMatchedObject(new Object());
		return data;
	}

	public ApiIntergrationDto getApiIntergrationDto() {
		ApiIntergrationDto data = new ApiIntergrationDto();
		data.setSearchQuery("test");
		return data;
	}
	
	public List<SearchResponseDto> getSearchResponseDtos() {
		List<SearchResponseDto> datas = new ArrayList<>();
		SearchResponseDto data = new SearchResponseDto();
		data.setIndex("23");
		data.setMatchedObject(new Object());
		datas.add(data);
		return datas;
	}
	
}
