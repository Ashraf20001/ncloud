package com.ncloud.dl.bulk.upload.controller.test;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.multipart.MultipartFile;

import com.ncloud.dl.DataLakeApplication;
import com.ncloud.dl.controller.BulkUploadController;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.service.IBulkUploadService;
import com.ncloud.dl.transfer.object.BulkImportTriggerConsumerDto;
import com.ncloud.dl.transfer.object.dto.BulkImportHistoryDto;
import com.ncloud.dl.transfer.object.dto.BulkUploadHistoryDto;
import com.ncloud.dl.transfer.object.dto.FieldMapperDto;
import com.ncloud.dl.transfer.object.dto.SuccessErrorRecordsDto;
import com.ncloud.dl.transfer.object.dto.UserInfo;
import com.ncloud.dl.utils.core.LoggedInUserContextHolder;
@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DataLakeApplication.class)
public class BulkUploadControllerTest {
	
	@InjectMocks
	private BulkUploadController bulkUploadController;
	
	@Mock
	private LoggedInUserContextHolder loggedInUserContextHolder;
	
	@Mock
	private IBulkUploadService iBulkUploadServiceMock;
	
	@Mock
	private LoggedInUserContextHolder loggedInUserContextHolderMock;
	
	
	@Test
	public void DownloadSampleFile_HappyFlow() {
		try {
			when(iBulkUploadServiceMock.downloadSampleFileForRepository(any())).thenReturn(getByteArrayValue());
			bulkUploadController.downloadSampleFileForRepository("123");
		} catch(Exception e) {
			
		}
	}
	
	@Test
	public void uploadSampleFile_HappyFlow() {
		MultipartFile multipartFileMock = getMockAWSMultipartFile();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(getUserInfo());
			when(iBulkUploadServiceMock.bulkUploadFileForRepository("123", multipartFileMock, getUserInfo(), null))
					.thenReturn("1234");
			bulkUploadController.bulkUploadFileForRepository(multipartFileMock, "1234", null);
		} catch (Exception e) {
			e.printStackTrace();
			Assertions.fail();
		}
	}
	
	
	@Test
	public void getBulkUploadHistoryCounts_HappyFlow() {
		try {
			when(iBulkUploadServiceMock.getBulkUploadHistoryDetails(any())).thenReturn(getBulkUploadHistoryDto());
			bulkUploadController.getBulkUploadHistoryCountsDetails("kumar");
		}catch(Exception e) {
			Assertions.fail();
		}
	}

	@Test
	public void getUploadHistoryDetails_HappyFlow() {
		try {
			when(loggedInUserContextHolderMock.getLoggedInUser()).thenReturn(getUserInfo());
			when(iBulkUploadServiceMock.getUploadHistoryDetails("123", getUserInfo())).thenReturn((getBulkUploadDto()));
			bulkUploadController.getUploadHistoryDetails("123");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
		
	@Test
	public void getSuccessErrorRecords_happyFlow() {
		try {
			when(iBulkUploadServiceMock.getSuccessErrorRecords(any(), any(), any(), any(), any())).thenReturn(getMapList());
			bulkUploadController.getSuccessErrorRecords(any(), any(), any(), any(), any());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void bulkUploadAddForRepository_happyFlow() {
		try {
			doNothing().when(iBulkUploadServiceMock).bulkUploadFileValidateFile(any(), any(), any(), any());
			bulkUploadController.bulkUploadAddForRepository(any(), any(), any(), any());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getFilePathByUploadId_HappyFlow() {
		try {
			bulkUploadController.getFilePathByUploadId("123");
		} catch(Exception e) {
			
		}
	}

	@Test
	public void updateUploadStatus_happyFlow() {
		try {
			doNothing().when(iBulkUploadServiceMock).updateUploadStatus(any(), any(), any(), any());
			bulkUploadController.updateUploadStatus(1, 2, 2, 2);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getSuccessErrorRecordsDownload_happyFlow() {
		try {
			when(iBulkUploadServiceMock.getSuccessErrorRecords(any(), any(), any(), any(), any())).thenReturn(getMapList());
			when(iBulkUploadServiceMock.downloadExcel(getMapList())).thenReturn(getByteArrayValue());
			bulkUploadController.getSuccessErrorRecordsDownload("123", "true", 100);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getSuccessErrorRecordsCount_happyFlow() {
		try {
			when(iBulkUploadServiceMock.getSuccessErrorRecordsCount(any(), any(), any(), any(), any())).thenReturn(1L);
			bulkUploadController.getSuccessErrorRecordsCount(any(), any(), any(), any(), any());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getVo_happyFLow() {
		try {
			bulkUploadController.getVo("test");
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
	}
	
	/************************  MOCKS **************************************/
	
	private BulkUploadHistoryDto getBulkUploadHistoryDto() {
		BulkUploadHistoryDto bulkUploadHistoryDto = new BulkUploadHistoryDto();
		bulkUploadHistoryDto.setTotalCount(300);
		bulkUploadHistoryDto.setSuccessCount(200);
		bulkUploadHistoryDto.setFailureCount(50);
		return bulkUploadHistoryDto;
		
	}	
	
	private HashMap<String, Object> getHashmapValue() {
		Map<String , Object> val = new HashMap<>();
		val.put("FieldsName", "datalake");
		return (HashMap<String, Object>) val;
	}
	
	public SuccessErrorRecordsDto getSuccessErrorRecords(){
		SuccessErrorRecordsDto successErrorRecordsDto = new SuccessErrorRecordsDto();
		successErrorRecordsDto.setFieldMapperDto(null);
		successErrorRecordsDto.setFieldMapperDto(null);
		return successErrorRecordsDto;
	}
	
	private List<BulkImportHistoryDto> getBulkUploadDto() {
		List<BulkImportHistoryDto> bulkImportHistoryDtos = new ArrayList<>();
		bulkImportHistoryDtos.add(getBulkUploadDetails());
		return bulkImportHistoryDtos;
	}

	private BulkImportHistoryDto getBulkUploadDetails() {
		BulkImportHistoryDto bulkImportHistoryDto = new BulkImportHistoryDto();
		bulkImportHistoryDto.setFailureCount(10);
		bulkImportHistoryDto.setFileName("Bulkpload");
		bulkImportHistoryDto.setSuccessCount(100);
		return bulkImportHistoryDto;
	}
	
	public SuccessErrorRecordsDto getMapList(){
		SuccessErrorRecordsDto successErrorRecordsDto = new SuccessErrorRecordsDto();
		List<Map<String, Object>> list = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("key", new Object());
		list.add(map);
		successErrorRecordsDto.setSuccessErrorList(list);
		successErrorRecordsDto.setFieldMapperDto(getFieldMapper());
		return successErrorRecordsDto;
	}
	
	private BulkImportTriggerConsumerDto getBulkImportTriggerConsumerDto() {
		BulkImportTriggerConsumerDto bulkImportTriggerConsumerDto = new BulkImportTriggerConsumerDto();
		bulkImportTriggerConsumerDto.setAssociationId(1);
		bulkImportTriggerConsumerDto.setBulkImportIdentity("4323");
		return bulkImportTriggerConsumerDto;
	}

	private List<FieldMapperDto> getFieldMapper() {
		List<FieldMapperDto> value  = new ArrayList<>();
		FieldMapperDto val = new FieldMapperDto();
		val.setColumnName("Arun");
		val.setDisplayName("arun");
		return value;
	}
	
	private ResponseEntity<byte[]> getByteArrayValue() {
		 ResponseEntity<byte[]> r=new ResponseEntity<>(HttpStatus.ACCEPTED);
		return r;
	}
	
	private UserInfo getUserInfo() {
		UserInfo userInfo = new UserInfo();
		userInfo.setUsername("mockData");
		userInfo.setId(1);
		return userInfo;
	}
	
	private MockMultipartFile getMockAWSMultipartFile() {
		MockMultipartFile file = new MockMultipartFile(
	        "file", 
	        "hello.txt", 
	        MediaType.TEXT_PLAIN_VALUE, 
	        "Hello, World!".getBytes()
	      );
		return file;
	}
	

}
