package com.ncloud.dl.repository.notification.service.impl.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.ncloud.dl.DataLakeApplication;
import com.ncloud.dl.dao.notification.repository.IRepositoryNotificationDao;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.exception.core.codes.ErrorCodes;
import com.ncloud.dl.service.impl.repository.notification.RepositoryNotificationServiceImpl;
import com.ncloud.dl.service.impl.resttemplate.RestTemplateServiceImpl;
import com.ncloud.dl.test.mockdata.MockData;
import com.ncloud.dl.transfer.object.dto.UserPrivillageDto;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DataLakeApplication.class)
public class RepositoryNotificationServiceImplTest {
	
	@InjectMocks
	private RepositoryNotificationServiceImpl repositoryNotificationServiceImplMock;
	
	@Mock
	private IRepositoryNotificationDao repositoryNotificationDao;
	
	@Mock
	private RestTemplateServiceImpl restTemplateServiceImpl;
	
	
	@Test
	public void getUnreadNotificationList_HappyFlow() {
		List<Integer> integerList = new ArrayList<>();
		integerList.add(1);
		try {
			when(repositoryNotificationDao.getRepositoryNotificationBasedOnRolePrivelege(any(), any()))
					.thenReturn(MockData.getRepositoryNotificationsListMock());
			when(restTemplateServiceImpl.checkForPrivelege(null)).thenReturn(getUserPrivillageDtos());
			repositoryNotificationServiceImplMock.getUnReadNotifications(true, null);
		} catch (Exception e) {
			Assertions.fail();
		}
	}
	
	private List<UserPrivillageDto> getUserPrivillageDtos(){
		List<UserPrivillageDto> userPrivillageDtos = new ArrayList<>();
		UserPrivillageDto userPrivillageDto = new UserPrivillageDto();
		userPrivillageDto.setPrivillageId(1);
		userPrivillageDto.setPrivillageName("an");
		userPrivillageDtos.add(userPrivillageDto);
		return userPrivillageDtos;
	}
	
	@Test
	public void getUnreadNotificationCount_HappyFlow() {
		List<Integer> integerList = new ArrayList<>();
		integerList.add(1);
		try {
			when(repositoryNotificationDao.getRepositoryNotificationBasedOnRolePrivelege(integerList, true))
					.thenReturn(MockData.getRepositoryNotificationsListMock());
			when(restTemplateServiceImpl.checkForPrivelege(null)).thenReturn(getUserPrivillageDtos());
			repositoryNotificationServiceImplMock.getUnReadNotificationsCount(null);
		} catch (Exception e) {
			Assertions.fail();
		}
	}
	
	@Test
	public void getUnReadUpdateNotifications_HappyFlow() {
		String identity = "yughbnhjncqwcwquiwqcs";
		try {
			when(repositoryNotificationDao.getRepositoryNotificationByIdentity(identity))
			.thenReturn(MockData.getRepositoryNotificationsListMock());
			when(repositoryNotificationDao.updateRepositoryNotification(MockData.getRepositoryNotificationsMock())).thenReturn(true);
			repositoryNotificationServiceImplMock.markAsReadNotification(identity,MockData.getUserInfoMockDto());
		}catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	public void getUnReadUpdateNotifications_ErrorFlow() {
		String identity = "yughbnhjncqwcwquiwqcs";
		try {
			ApplicationException ap = new ApplicationException(ErrorCodes.INVALID_USER);
			ApplicationException exception = assertThrows(ApplicationException.class, () -> {
				repositoryNotificationServiceImplMock.markAsReadNotification(null,null);
            });
            assertEquals(ap.toString(),exception.toString());
		} catch(Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
}
