package com.ncloud.dl.factorytest;

import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;

import com.ncloud.dl.DataLakeApplication;
import com.ncloud.dl.datatype.factory.DateFactoryValidationBuilder;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.test.mockdata.MockData;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DataLakeApplication.class)
public class DateFactoryValidationTest {
	
	@InjectMocks
	private DateFactoryValidationBuilder datValidationBuilder;
	
	@Test
	public void singleAddForRepository_ErrorFlow() throws ApplicationException {
		try {
			assertThrows(ApplicationException.class, ()->{
				datValidationBuilder.getDataTypeValidationBuilder("ErrorMsg", Map.entry("", ""), true, null,  MockData.getFieldConfig());
			});
		}catch (Exception e) {
			e.printStackTrace();
			Assertions.fail();
		}
	}
	
	@Test
	public void singleAddForRepository_ErrorFlow2() throws ApplicationException {
		try {
			ReflectionTestUtils.setField(datValidationBuilder, "dateFormat", "dd-MM-yyyy");
			assertThrows(ApplicationException.class,()->{
				datValidationBuilder.getDataTypeValidationBuilder("ErrorMsg", MockData.getHashmapEntryValue(), false, null, MockData.getFieldConfig());
			});
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void singleAddForRepository_HappyFlow() throws ApplicationException {
		try {
			ReflectionTestUtils.setField(datValidationBuilder, "dateFormat", "dd-MM-yyyy");		
			datValidationBuilder.getDataTypeValidationBuilder("ErrorMsg", MockData.getHashmapEntryValueForDate(), false, new HashMap<String,Object>(), MockData.getFieldConfig());
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
