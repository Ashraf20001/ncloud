package com.ncloud.dl.bulk.upload.service.impl.test;

import static com.ncloud.dl.test.mockdata.MockData.getBulkUploadHistory;
import static com.ncloud.dl.test.mockdata.MockData.getHashmapValue2;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ncloud.dl.DataLakeApplication;
import com.ncloud.dl.config.property.EnvironmentProperties;
import com.ncloud.dl.dao.datarespository.IDataRepositoryDao;
import com.ncloud.dl.dao.errormaintenance.IErrorMaintenanceDao;
import com.ncloud.dl.dao.fieldconfiguration.IFieldConfigurationDao;
import com.ncloud.dl.dao.fieldoptionlkn.IFieldOptionLinkingDao;
import com.ncloud.dl.dao.repository.IRepositoryDao;
import com.ncloud.dl.dao.upload.IBulkUploadDao;
import com.ncloud.dl.dao.upload.storage.IFileStorageDao;
import com.ncloud.dl.datatype.factory.DataConversionFactory;
import com.ncloud.dl.datatype.factory.DataTypeFactory;
import com.ncloud.dl.datatype.factory.IBulkUploadValidationBuilder;
import com.ncloud.dl.datatype.factory.IDataTypeConversionFactory;
import com.ncloud.dl.datatype.factory.IDataTypeFactoryValidationBuilder;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.service.impl.repository.upload.BulkUploadServiceImpl;
import com.ncloud.dl.test.mockdata.MockData;
import com.ncloud.dl.transfer.object.dto.UserInfo;
import com.ncloud.dl.transfer.object.entity.DataRepository;
import com.ncloud.dl.transfer.object.enums.FieldDataTypeEnum;
import com.ncloud.dl.utils.ElasticSearchUtils;


@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DataLakeApplication.class)
class BulkUploadServiceImplTest {
	
	@InjectMocks
	private BulkUploadServiceImpl bulkUploadServiceImplMock;
	
	@Mock
	private IFieldOptionLinkingDao fieldOptionLinkingDaoMock;
	
	@Mock
	private IDataRepositoryDao iDataRepositoryDaoMock;
	
	@Mock
	private IFileStorageDao iFileStorageDaoMock;
	
	@Mock
	private IBulkUploadDao iBulkUploadDaoMock;
	
	@Mock
	private IRepositoryDao iRepositoryDaoMock;
	
	@Mock
	KafkaTemplate<String, Object> kafkaTemplate;
	
	@Mock
	private IFieldConfigurationDao fieldConfigurationDaoMock;
	
	@Mock
	private DataTypeFactory dataFactoryMock;
	
	@Mock
	private IBulkUploadValidationBuilder iBulkUploadValidationBuilder;
	
	@Mock
	private DataConversionFactory dataConversionFactoryMock;
	
	@Mock
	private IDataTypeFactoryValidationBuilder iDataTypeFactoryValidationBuilder;

	@Mock
	private EnvironmentProperties environmentPropertiesMock;

	@Mock
	private	ElasticSearchUtils elasticSearchUtilsMock;

	@Mock
	private IErrorMaintenanceDao iErrorMaintenanceDaoMock;
	
	@TempDir
    Path tempDir;

	@Autowired
	private EnvironmentProperties environmentProperties;

	private static final HttpServletRequest HttpServletRequest = null;

	@Autowired
	private ElasticSearchUtils elasticSearchUtils;

	@Test
	void downloadSampleFile_HappyFlow() {
		List<String> val = new ArrayList<>();
		val.add("text1");
		val.add("text2");
		try {
			when(iDataRepositoryDaoMock.getFieldRepository("repo")).thenReturn(MockData.getDataRepositories());
			when(fieldOptionLinkingDaoMock.getFieldOptionNames(any())).thenReturn(val);
			ResponseEntity<byte[]> response = bulkUploadServiceImplMock.downloadSampleFileForRepository("repo");
		} catch (Exception e) {
			e.printStackTrace();
			Assertions.fail();
		}
	}
	@Test
	void bulkUploadFileForRepository_HappyFLow() {
		try {
			String repoIdentity = "repo", identity = getBulkUploadHistory().getIdentity(), output;
			UserInfo userInfo = MockData.getUserInfo();
			DataRepository dataRepository = MockData.getDataRepository();
			when(iRepositoryDaoMock.getRepositoryDetails(repoIdentity)).thenReturn(dataRepository);
			when(iFileStorageDaoMock.saveFileStorageForRepository(any())).thenReturn(MockData.getFileStorage());
			when(iBulkUploadDaoMock.saveBulkUploadHsitory(any())).thenReturn(getBulkUploadHistory());
			when(environmentPropertiesMock.getFileUploadPath()).thenReturn(environmentProperties.getUploadPath());
			when(environmentPropertiesMock.getUploadPath()).thenReturn(environmentProperties.getUploadPath());
			when(iDataRepositoryDaoMock.getFieldRepositoryColumnName(any())).thenReturn(new ArrayList<>());
			doNothing().when(elasticSearchUtilsMock).dropBulkUploadInfo(any());
			doNothing().when(iErrorMaintenanceDaoMock).saveErrorMaintenanceHistory(any());

			output = bulkUploadServiceImplMock.bulkUploadFileForRepository(repoIdentity, MockData.getMockXSSFWorkBookMultipartFile(), userInfo, HttpServletRequest);
			assertEquals(identity, output);
		} catch(Exception e) {
			e.printStackTrace();
			Assertions.fail();
		}
	}
		
		@Test
		void bulkUploadFile_FailFLow() {
			try {
				when(iRepositoryDaoMock.getRepositoryDetails("repo")).thenReturn(MockData.getDataRepository());
				when(iFileStorageDaoMock.saveFileStorageForRepository(any())).thenReturn(MockData.getFileStorage());
				when(iBulkUploadDaoMock.saveBulkUploadHsitory(any())).thenReturn(getBulkUploadHistory());
				bulkUploadServiceImplMock.bulkUploadFileForRepository("123", MockData.getMockAWSMultipartFile(), null,HttpServletRequest);
				Assertions.fail();
			} catch(Exception e) {
				assertNotNull(e);
			}
		}
		
		@Test
		void getFileNameForRepository_HappyFLow() {
			try {
				when(iBulkUploadDaoMock.getBulkUploadByIdAndAssocicationId(any(), any()))
						.thenReturn(getBulkUploadHistory());
				when(iBulkUploadDaoMock.getTotalSuccessCountByRepositoryId(1)).thenReturn((long)100);
				bulkUploadServiceImplMock.getFileNameForRepository(123, 1, 1);
			} catch (Exception e) {
				Assertions.fail();
			}
		}
		
		@Test
		void bulkUploadFileValidateFile_HappyFLow() {
			try {
				Map<String, IDataTypeConversionFactory> dataTypeConversionFactory = new HashMap<>();
			    IDataTypeConversionFactory stringDataTypeConvertor = getValue();
				dataTypeConversionFactory.put(FieldDataTypeEnum.STRING.getValue(), stringDataTypeConvertor);
				IDataTypeConversionFactory decimalDataTypeConvertor = getValue();
				dataTypeConversionFactory.put(FieldDataTypeEnum.DECIMAL.getValue(), decimalDataTypeConvertor);
				IDataTypeConversionFactory booleanDataTypeConvertor = getValue();
				dataTypeConversionFactory.put(FieldDataTypeEnum.BOOLEAN.getValue(), booleanDataTypeConvertor);
				IDataTypeConversionFactory numberDataTypeConvertor = getValue();
				dataTypeConversionFactory.put(FieldDataTypeEnum.NUMBER.getValue(), numberDataTypeConvertor);
				IDataTypeConversionFactory dateDataTypeConvertor = getValue();
				dataTypeConversionFactory.put(FieldDataTypeEnum.DATE.getValue(), dateDataTypeConvertor);
				when(fieldConfigurationDaoMock.getFieldMappedInRepository(any())).thenReturn(MockData.getDataRepositories2());
				when(fieldOptionLinkingDaoMock.getFieldOptionList(any())).thenReturn(MockData.getFieldOptionLinking3());
				when(dataFactoryMock.getDataTypeValidationBuilder(any())).thenReturn(iDataTypeFactoryValidationBuilder);
				when(iBulkUploadValidationBuilder.getDataTypeValidationBuilder(null, MockData.getFieldConfiguration(), null, null, null)).thenReturn(true);
				when(dataConversionFactoryMock.getFieldDataType("")).thenReturn(stringDataTypeConvertor);
				doNothing().when(iDataRepositoryDaoMock).saveSingleFieldData(any(), any());
				when(iBulkUploadDaoMock.getScratchDataUsingBulkUploadId(any())).thenReturn(MockData.getScratchDetails());
				when(iBulkUploadDaoMock.getBulkUploadByIdAndAssocicationId(1,1)).thenReturn(MockData.getBulkUploadCounts());
				when(iBulkUploadDaoMock.getListForFieldsErrorMaintenance(any(),any(),any())).thenReturn(MockData.getErrorMaintenance());
				doNothing().when(iErrorMaintenanceDaoMock).saveErrorMaintenanceHistory(any());

				bulkUploadServiceImplMock.bulkUploadFileValidateFile("123",MockData.getDataLakeBulkUploadMapDto(),12,1);
			} catch(Exception e) {
				e.printStackTrace();
				
			}
		}


		@Test
		void singleAddForRepository_ErrorFlows() {
			try {
				 Map<String, IDataTypeConversionFactory> dataTypeConversionFactory = new HashMap<>();
				    IDataTypeConversionFactory stringDataTypeConvertor = getValue();
					dataTypeConversionFactory.put(FieldDataTypeEnum.STRING.getValue(), stringDataTypeConvertor);
					IDataTypeConversionFactory decimalDataTypeConvertor = getValue();
					dataTypeConversionFactory.put(FieldDataTypeEnum.DECIMAL.getValue(), decimalDataTypeConvertor);
					IDataTypeConversionFactory booleanDataTypeConvertor = getValue();
					dataTypeConversionFactory.put(FieldDataTypeEnum.BOOLEAN.getValue(), booleanDataTypeConvertor);
					IDataTypeConversionFactory numberDataTypeConvertor = getValue();
					dataTypeConversionFactory.put(FieldDataTypeEnum.NUMBER.getValue(), numberDataTypeConvertor);
					IDataTypeConversionFactory dateDataTypeConvertor = getValue();
					dataTypeConversionFactory.put(FieldDataTypeEnum.DATE.getValue(), dateDataTypeConvertor);
					when(fieldConfigurationDaoMock.getFieldMappedInRepository(any())).thenReturn(MockData.getfieldConfiguration());
					when(fieldOptionLinkingDaoMock.getFieldOptionList(any())).thenReturn(MockData.getFieldOptionLinking3());
					when(iBulkUploadValidationBuilder.getDataTypeValidationBuilder(any(),any(),any(),any(), any())).thenReturn(true);
					when(dataFactoryMock.getDataTypeValidationBuilder(any())).thenReturn(iDataTypeFactoryValidationBuilder);
					when(dataConversionFactoryMock.getFieldDataType("")).thenReturn(stringDataTypeConvertor);
					doNothing().when(iDataRepositoryDaoMock).saveSingleFieldData(any(), any());
					when(iBulkUploadDaoMock.getScratchDataUsingBulkUploadId("123")).thenReturn(MockData.getScratchDetails());
					when(iBulkUploadDaoMock.getBulkUploadByIdAndAssocicationId(1,1)).thenReturn(MockData.getBulkUploadCounts());
					when(iBulkUploadDaoMock.getListForFieldsErrorMaintenance(any(), any(), any())).thenReturn(MockData.getErrorMaintenance());
					bulkUploadServiceImplMock.singleAddForRepository("repositoryName", getHashmapValue2(),1,1,MockData.getListOfHashmapValue(),MockData.getfieldConfiguration(),MockData.getListofstring());
			}catch(Exception ex) {
				assertNotNull(ex);
			}
		}

		@Test
		void singleAddForRepository_HappyFlow1() {
			try {
				when(fieldConfigurationDaoMock.getFieldMappedInRepository(any())).thenReturn(MockData.getDataRepositories());
				when(fieldOptionLinkingDaoMock.getFieldOptionList(any())).thenReturn(MockData.getFieldOptionLinking1());
				when(dataFactoryMock.getDataTypeValidationBuilder(any())).thenReturn(iDataTypeFactoryValidationBuilder);
				doNothing().when(iDataRepositoryDaoMock).saveSingleFieldData(any(), any());
				doNothing().when(iErrorMaintenanceDaoMock).saveErrorMaintenanceHistory(any());
				bulkUploadServiceImplMock.singleAddForRepository("repositoryName",getHashmapValue2(),1,1,MockData.getListOfHashmapValue(),MockData.getfieldConfiguration(),MockData.getListofstring());
			}catch(Exception ex) {
				assertNotNull(ex);
			}
		}
		
		@Test
		void singleAddForRepository_HappyFlow2() {
			try {
			    Map<String, IDataTypeConversionFactory> dataTypeConversionFactory = new HashMap<>();
			    IDataTypeConversionFactory stringDataTypeConvertor = getValue();
				dataTypeConversionFactory.put(FieldDataTypeEnum.STRING.getValue(), stringDataTypeConvertor);
				IDataTypeConversionFactory decimalDataTypeConvertor = getValue();
				dataTypeConversionFactory.put(FieldDataTypeEnum.DECIMAL.getValue(), decimalDataTypeConvertor);
				IDataTypeConversionFactory booleanDataTypeConvertor = getValue();
				dataTypeConversionFactory.put(FieldDataTypeEnum.BOOLEAN.getValue(), booleanDataTypeConvertor);
				IDataTypeConversionFactory numberDataTypeConvertor = getValue();
				dataTypeConversionFactory.put(FieldDataTypeEnum.NUMBER.getValue(), numberDataTypeConvertor);
				IDataTypeConversionFactory dateDataTypeConvertor = getValue();
				dataTypeConversionFactory.put(FieldDataTypeEnum.DATE.getValue(), dateDataTypeConvertor);
				when(fieldConfigurationDaoMock.getFieldMappedInRepository(any())).thenReturn(MockData.getDataRepositories2());
				when(fieldOptionLinkingDaoMock.getFieldOptionList(any())).thenReturn(MockData.getFieldOptionLinking3());
				when(iBulkUploadValidationBuilder.getDataTypeValidationBuilder(any(),any(),any(),any(), any())).thenReturn(true);
				when(dataFactoryMock.getDataTypeValidationBuilder(any())).thenReturn(iDataTypeFactoryValidationBuilder);
				when(dataConversionFactoryMock.getFieldDataType("")).thenReturn(stringDataTypeConvertor);
				doNothing().when(iDataRepositoryDaoMock).saveSingleFieldData(any(), any());
				when(iBulkUploadDaoMock.getScratchDataUsingBulkUploadId(any())).thenReturn(MockData.getScratchDetails());
				when(iBulkUploadDaoMock.getBulkUploadByIdAndAssocicationId(1,1)).thenReturn(MockData.getBulkUploadCounts());
				when(iBulkUploadDaoMock.getListForFieldsErrorMaintenance(any(),any(),any())).thenReturn(MockData.getErrorMaintenance());
				doNothing().when(iErrorMaintenanceDaoMock).saveErrorMaintenanceHistory(any());

				bulkUploadServiceImplMock.singleAddForRepository("repositoryName",getHashmapValue2(),1,1,MockData.getListOfHashmapValue(),MockData.getfieldConfiguration(),MockData.getListofstring());
			}catch(Exception ex) {
				ex.printStackTrace();
			}
		}

		private IDataTypeConversionFactory getValue() {
			return null;
		}

		@Test
		void singleAddForRepository_ErrorFlow() {
			try {
				when(fieldConfigurationDaoMock.getFieldMappedInRepository(any())).thenReturn(MockData.getDataRepositories1());
				when(fieldOptionLinkingDaoMock.getFieldOptionList(any())).thenReturn(MockData.getFieldOptionLinking());
				doNothing().when(iDataRepositoryDaoMock).saveSingleFieldData(any(),any());
				when(fieldOptionLinkingDaoMock.getFieldOptionList(any())).thenReturn(MockData.getFieldOptionLinking());
				when(dataFactoryMock.getDataTypeValidationBuilder(any())).thenReturn(iDataTypeFactoryValidationBuilder);
				bulkUploadServiceImplMock.singleAddForRepository("repositoryName",getHashmapValue2(),1,1,MockData.getListOfHashmapValue(),MockData.getfieldConfiguration(),MockData.getListofstring());
			}catch(Exception ex) {
				
				ex.printStackTrace();
			}
		}
		
		@Test
		void singleAddForRepository_ErrorFlow1() {
			try {
				when(fieldConfigurationDaoMock.getFieldMappedInRepository(any())).thenReturn(MockData.getDataRepositories1());
				when(fieldOptionLinkingDaoMock.getFieldOptionList(any())).thenReturn(MockData.getFieldOptionLinking1());
				when(dataFactoryMock.getDataTypeValidationBuilder(any())).thenReturn(iDataTypeFactoryValidationBuilder);
				bulkUploadServiceImplMock.singleAddForRepository("repositoryName",getHashmapValue2(),1,1,MockData.getListOfHashmapValue(),MockData.getfieldConfiguration(),MockData.getListofstring());
			}catch(Exception ex) {
				assertNotNull(ex);
			}
		}

		@Test
		void singleAddForRepository_ErrorFlow2() {
			try {
				when(fieldConfigurationDaoMock.getFieldMappedInRepository(any())).thenReturn(MockData.getDataRepositories1());
				when(fieldOptionLinkingDaoMock.getFieldOptionList(any())).thenReturn(MockData.getFieldOptionLinking1());
				when(dataFactoryMock.getDataTypeValidationBuilder(any())).thenReturn(iDataTypeFactoryValidationBuilder);


				bulkUploadServiceImplMock.singleAddForRepository("repositoryName",getHashmapValue2(),1,1,MockData.getListOfHashmapValue(),MockData.getfieldConfiguration4(),MockData.getListofstring());
			}catch(Exception ex) {
				assertNotNull(ex);
			}
		}

	
	@Test
	void getBulkUploadCountsDetails_HappyFlow() {
		try {
			when(iDataRepositoryDaoMock.getBulkUploadHistory(any())).thenReturn(MockData.getBulkUploadCounts());
			bulkUploadServiceImplMock.getBulkUploadHistoryDetails("kumar");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
		
	@Test
	void getUploadHistoryDetails_HappyFlow() {
		try {
			when(iRepositoryDaoMock.getRepositoryDetails("123")).thenReturn(MockData.getDataRepository());
			when(iBulkUploadDaoMock.getUploadHistorydetails(any(), any(),any())).thenReturn(MockData.getBulkUploadDetails());
			bulkUploadServiceImplMock.getUploadHistoryDetails("123",MockData.getUserInfo());
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	@Test
	void getSuccessErrorRecords_happyFlow_1() {
		try {
			when(iBulkUploadDaoMock.getBulkUploadDetailsByIdentity("1234")).thenReturn(MockData.getBulkUploadHistorys());
			when(iBulkUploadDaoMock.getScratchDataUsingBulkUploadId(any())).thenReturn(MockData.getScratchDetails());
			when(fieldConfigurationDaoMock.getFieldDetails(any())).thenReturn(MockData.getDataRepositories());
			bulkUploadServiceImplMock.getSuccessErrorRecords("1234", false, any(), 1, 1);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	void getBulkUploadCountsDetails_ErrorFlow() {
		try {
			when(iDataRepositoryDaoMock.getBulkUploadHistory(any())).thenReturn(null);
			assertThrows(ApplicationException.class, ()->{
				bulkUploadServiceImplMock.getBulkUploadHistoryDetails(null);
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

		
	@Test
	void getSuccessErrorRecords_errorFlow_1() {
		try {
			when(iBulkUploadDaoMock.getBulkUploadDetailsByIdentity("1234")).thenReturn(null);
			bulkUploadServiceImplMock.getSuccessErrorRecords("1234", true, any(), 1, 1);
		} catch (Exception e) {
			assertNotNull(e);
		}
	}

	@Test
	void getSuccessErrorRecords_errorFlow_2() {
		try {
			when(iBulkUploadDaoMock.getBulkUploadDetailsByIdentity("1234")).thenReturn(MockData.getBulkUploadHistorys());
			when(fieldConfigurationDaoMock.getFieldDetails(any())).thenReturn(null);
			bulkUploadServiceImplMock.getSuccessErrorRecords("1234", true, any(), 1, 1);
		} catch (Exception e) {
			assertNotNull(e);
		}
	}


	@Test
	void getSuccessErrorRecordsCount_happyFlow_1() {
		try {
			when(iBulkUploadDaoMock.getBulkUploadDetailsByIdentity("1234")).thenReturn(MockData.getBulkUploadHistorys());
			when(fieldConfigurationDaoMock.getFieldDetails(any())).thenReturn(MockData.getDataRepositories());
			when(iBulkUploadDaoMock.getScratchCountUsingUploadId("123")).thenReturn((long) 123);
			bulkUploadServiceImplMock.getSuccessErrorRecordsCount("1234", false, MockData.getCustomSortingVos(), 1, 1);
		} catch (Exception e) {
			Assertions.fail();
		}
	}
	
	@Test
	void downloadFile_HappyFlow() {
		List<String> val = new ArrayList<>();
		val.add("text1");
		val.add("text2");
		try {
			ResponseEntity<byte[]> response = bulkUploadServiceImplMock.downloadExcel(MockData.getExcelDto());
		} catch (Exception e) {
			e.printStackTrace();
			Assertions.fail();
		}
	}


        @Test
	void singleRecordForRepository_Happy_Flow(){
        try {
			String repositoryName = "repo name", output, selectQuery = "query";
			HashMap<String, Object> singleAddRepository = MockData.getHashmapValue1();
			KafkaTemplate<String, Object> kafkaTemplate = mock(KafkaTemplate.class);

			when(fieldConfigurationDaoMock.getFieldMappedInRepository(any())).thenReturn(MockData.getfieldConfiguration());
			when(iDataRepositoryDaoMock.generateSelectQuery(any(),any())).thenReturn(selectQuery);
			when(dataFactoryMock.getDataTypeValidationBuilder(any())).thenReturn(iDataTypeFactoryValidationBuilder);

			when(kafkaTemplate.send(any(ProducerRecord.class))).thenReturn(null);
			doNothing().when(iErrorMaintenanceDaoMock).saveErrorMaintenanceHistory(any());

            output = bulkUploadServiceImplMock.singleRecordForRepository(repositoryName, singleAddRepository);

			assertNotNull(output);

        } catch (ApplicationException | JsonProcessingException | ParseException e) {
            throw new RuntimeException(e);
        }
    }

	@Test
	void getFileResourceByFileName_Happy_Flow(){
		try {

			String fileName = "file.txt";
			when(environmentPropertiesMock.getUploadPath()).thenReturn(tempDir.toString());
	        Path filePath = Files.createFile(tempDir.resolve(fileName));

	       bulkUploadServiceImplMock.getFileResourceByFileName(fileName);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Test
	void buildAndSaveErrorMaintenance(){
		try{
			doNothing().when(iErrorMaintenanceDaoMock).saveErrorMaintenanceHistory(any());
			bulkUploadServiceImplMock.buildAndSaveErrorMaintenance(MockData.getFieldConfiguration2(), 1, MockData.getErrorMaintenance().get(0).getErrorMessage(), 1, true, MockData.getErrorMaintenance().get(0).getIdentity());
		} catch (Exception e){

		}
	}
}
