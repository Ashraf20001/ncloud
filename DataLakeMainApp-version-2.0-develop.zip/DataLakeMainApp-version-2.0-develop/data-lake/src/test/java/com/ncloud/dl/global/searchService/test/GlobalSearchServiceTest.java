package com.ncloud.dl.global.searchService.test;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;

import org.apache.http.HttpEntity;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.client.Request;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.core.CountRequest;
import org.elasticsearch.client.indices.CreateIndexRequest;
import org.elasticsearch.client.indices.GetIndexRequest;
import org.elasticsearch.client.indices.GetIndexResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.ncloud.dl.DataLakeApplication;
import com.ncloud.dl.config.property.EnvironmentProperties;
import com.ncloud.dl.constants.core.ApplicationConstants;
import com.ncloud.dl.constants.core.QueryConstants.ColumnConstants;
import com.ncloud.dl.dao.datarespository.IDataRepositoryDao;
import com.ncloud.dl.dao.fieldconfiguration.IFieldConfigurationDao;
import com.ncloud.dl.dao.fieldoptionlkn.IFieldOptionLinkingDao;
import com.ncloud.dl.dao.impl.search.SearchDaoImpl;
import com.ncloud.dl.dao.upload.IBulkUploadDao;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.search.eswrapper.CountResponseObject;
import com.ncloud.dl.search.eswrapper.ElasticSearchClient;
import com.ncloud.dl.search.eswrapper.EntityUtilsImpl;
import com.ncloud.dl.search.eswrapper.IIndicesClient;
import com.ncloud.dl.search.eswrapper.IRestClient;
import com.ncloud.dl.search.eswrapper.ISearchHit;
import com.ncloud.dl.search.eswrapper.ISearchHits;
import com.ncloud.dl.search.eswrapper.ISearchResponse;
import com.ncloud.dl.service.impl.repository.search.SearchServiceImpl;
import com.ncloud.dl.test.mockdata.MockData;
import com.ncloud.dl.transfer.object.entity.SearchHistory;
import com.ncloud.dl.transfer.object.enums.FieldSearchTypeEnum;

import freemarker.template.Configuration;
import freemarker.template.Template;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DataLakeApplication.class)
public class GlobalSearchServiceTest {
	
	@InjectMocks
	private SearchServiceImpl searchServiceImpl;
	
	@Mock
	private IFieldConfigurationDao fieldConfigurationDao;
	
	@Mock
	private SearchDaoImpl searchDao;
	
	@Mock
	private IBulkUploadDao iBulkUploadDao;
	
	@Mock
	private IDataRepositoryDao dataRepositoryDao;
	
	@Mock
	private IFieldOptionLinkingDao fieldOptionLinkingDao;

	@Mock
	private ElasticSearchClient elasticSearchClientMock;

	@Autowired
	private EnvironmentProperties environmentProperties;

	@Mock
	private EnvironmentProperties environmentPropertiesMock;
	
	@Mock
	private Configuration configMock;

	@Mock
	private JavaMailSender mailSenderMock;
	
	@Mock
	private IRestClient iRestClientMock;
	
	@Mock
	private EntityUtilsImpl entityUtils;

	private static final HttpServletRequest HttpServletRequest = null;
	
	
	@Test
	public void getApprovedRepositoryName_HappyFlow() {
		try {
			when(searchDao.getRepositoryDetails(any())).thenReturn(MockData.getDataRepositoryList());
			searchServiceImpl.getApprovedRepositoryName(any());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getRepositoryFiedsForTableHeader_HappyFlow() {
		try {
			when(fieldConfigurationDao.getFieldDetailList("1233")).thenReturn(MockData.getFieldConfiuration());
			searchServiceImpl.getRepositoryFiedsForTableHeader("1233");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getRepositoryList_ErrorFlow() {
		try {
			when(fieldConfigurationDao.getFieldDetailList("1233")).thenReturn(MockData.getFieldConfiuration());
			assertThrows(ApplicationException.class, ()->{
				searchServiceImpl.getRepositoryFiedsForTableHeader(null);
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getRepositoryListCount_HappyFlow() {
		try {
			when(fieldConfigurationDao.getFieldDetailList("1233")).thenReturn(MockData.getFieldConfiuration());
			searchServiceImpl.getRepositoryFiedsForTableHeader("1233");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getRepositoryListCount_ErrorFlow() {
		try {
			when(fieldConfigurationDao.getFieldDetailList("1233")).thenReturn(MockData.getFieldConfiuration());
			assertThrows(ApplicationException.class, ()->{
				searchServiceImpl.getRepositoryFiedsForTableHeader(null);
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getadvanceFilterForRepository_HappyFlow() {
		try {
			when(dataRepositoryDao.getFieldRepositorySearch(any(), any())).thenReturn(MockData.getFieldConfigurationList());
			when(fieldOptionLinkingDao.getFieldOptionList(any())).thenReturn(MockData.getFieldOptionList());
			when(searchDao.getRepositoryDetails(any())).thenReturn(MockData.getDataRepositoryList());
			searchServiceImpl.getadvanceFilterForRepository("123");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getRepositorySearchList_HappyFlow() {
		try {
			String indexName = "dl_repo";
			when(dataRepositoryDao.getSearchableFields(any(), any(), any())).thenReturn(MockData.getRepositoryDto());
			when(environmentPropertiesMock.getElasticSearchHost()).thenReturn(environmentProperties.getElasticSearchHost());
			when(environmentPropertiesMock.getElasticSearchPort()).thenReturn(environmentProperties.getElasticSearchPort());
			when(environmentPropertiesMock.getElasticSearchSchema()).thenReturn(environmentProperties.getElasticSearchSchema());
			when(environmentPropertiesMock.getElasticSearchUsername()).thenReturn(environmentProperties.getElasticSearchUsername());
			when(environmentPropertiesMock.getElasticSearchPassword()).thenReturn(environmentProperties.getElasticSearchPassword());
			
			IIndicesClient indicesClientMock = mock(IIndicesClient.class);
			
			when(elasticSearchClientMock.indices()).thenReturn(indicesClientMock);
			elasticSearchClientMock.indices().create(any(CreateIndexRequest.class), any(RequestOptions.class));
			
			when(indicesClientMock.exists(any(GetIndexRequest.class), any(RequestOptions.class))).thenReturn(true);

			ISearchResponse searchResponseMock = mock(ISearchResponse.class);
			ISearchHits searchHitsMock= mock(ISearchHits.class);
			ISearchHit searchHitMock = mock(ISearchHit.class);
					
			when(elasticSearchClientMock.search(any(SearchRequest.class),any(RequestOptions.class))).thenReturn(searchResponseMock);
			when(searchResponseMock.getHits()).thenReturn(searchHitsMock);
			
			ISearchHit[] searchHitMockList=new ISearchHit[5];
			for (int i=0 ; i<searchHitMockList.length;i++) {
				searchHitMockList[i]=searchHitMock;
			}
			
			when(searchHitsMock.getHits()).thenReturn(searchHitMockList);
			for (ISearchHit iSearchHit : searchHitMockList) {
				when(iSearchHit.getSourceAsMap()).thenReturn(getSourceAsMap());
			}
			
			when(searchDao.getDataUsingUniqueId(any(String.class))).thenReturn(MockData.getListOfHashmapValue());


			searchServiceImpl.commonSearch("123", "23",(long)0,(long)10,1,MockData.getfilterObject(),true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void globalSearch_HappyFlow() {
		try {
			String indexName = "dl_repo";
			when(dataRepositoryDao.getSearchableFields(any(), any(), any())).thenReturn(MockData.getRepositoryDto());
			when(environmentPropertiesMock.getElasticSearchHost()).thenReturn(environmentProperties.getElasticSearchHost());
			when(environmentPropertiesMock.getElasticSearchPort()).thenReturn(environmentProperties.getElasticSearchPort());
			when(environmentPropertiesMock.getElasticSearchSchema()).thenReturn(environmentProperties.getElasticSearchSchema());
			when(environmentPropertiesMock.getElasticSearchUsername()).thenReturn(environmentProperties.getElasticSearchUsername());
			when(environmentPropertiesMock.getElasticSearchPassword()).thenReturn(environmentProperties.getElasticSearchPassword());

			
			IIndicesClient indicesClientMock = mock(IIndicesClient.class);
			GetIndexResponse getIndexResponseClassMock = mock(GetIndexResponse.class);
			Response responseMock = mock(Response.class);
			HttpEntity httpEntityMock = mock(HttpEntity.class);
			
			when(elasticSearchClientMock.indices()).thenReturn(indicesClientMock);
			when(indicesClientMock.get(any(GetIndexRequest.class), any(RequestOptions.class))).thenReturn(getIndexResponseClassMock);
			
			when(getIndexResponseClassMock.getIndices()).thenReturn(getStringArray());
			when(iRestClientMock.performRequest(any(Request.class))).thenReturn(responseMock);
			
			when(responseMock.getEntity()).thenReturn(httpEntityMock);
			when(entityUtils.toString(httpEntityMock)).thenReturn(getJsonResponse());
			searchServiceImpl.globalSearch("search", 0L,0L, "dl_repo", true);
		} catch (Exception e) {
			e.printStackTrace();
		} catch (Error error){
			error.printStackTrace();
		}
	}

	@Test
	public void sendMail_HappyFlow() {
		try {
			String repoName="Repo";
			String identity = "1233";
			String email="test123@gmail.com";

			Template templateMock = mock(Template.class);
			MimeMessage mimeMessageMock = mock(MimeMessage.class);

			when(fieldConfigurationDao.getFieldDetailList(anyString())).thenReturn(MockData.getFieldConfiuration());
			when(searchDao.getSqlDataWithIdentity(anyString())).thenReturn(MockData.getHashmapValue1());
			when(configMock.getTemplate(ApplicationConstants.MAIL__TEMPLATE_FILE)).thenReturn(templateMock);
			doNothing().when(templateMock).process(anyString(), any());
			when(mailSenderMock.createMimeMessage()).thenReturn(mimeMessageMock);
			searchServiceImpl.sendMail(identity, email, repoName);
		} catch (Exception e) {
			e.printStackTrace();
			Assertions.fail(e.toString());
		}
	}


	@Test
	public void getRecordsByUniqueId_HappyFlow() {
		try {
			when(searchDao.getDataUsingUniqueId(anyString())).thenReturn(MockData.getListOfHashmapValue());
			searchServiceImpl.getRecordsByUniqueId(MockData.getListofstring(), anyString());
		} catch (Exception e) {
			e.printStackTrace();
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void getTotalRecordsCount_HappyFlow() {
		try {

			String indexName = "dl_repo";
			String repoName = "table";
			String repoTableName="repo";
			Integer searchTypeId = FieldSearchTypeEnum.REPOSITORY_SEARCH.getId();

			when(dataRepositoryDao.getRepositoryInfoByRepositoryName(repoName)).thenReturn(MockData.getDataRepository2());
			when(dataRepositoryDao.getSearchableFields(repoName,
					Arrays.asList(searchTypeId, FieldSearchTypeEnum.BOTH_SEARCH.getId()),Boolean.FALSE)).thenReturn(MockData.getRepositoryDto1());

			IIndicesClient indicesClientMock = mock(IIndicesClient.class);
			CountResponseObject countResponseObjectMock = mock(CountResponseObject.class);
			
			when(elasticSearchClientMock.indices()).thenReturn(indicesClientMock);
			elasticSearchClientMock.indices().create(any(CreateIndexRequest.class), any(RequestOptions.class));
			
			when(indicesClientMock.exists(any(GetIndexRequest.class), any(RequestOptions.class))).thenReturn(true);


			when(elasticSearchClientMock.count(any(CountRequest.class), any(RequestOptions.class))).thenReturn(countResponseObjectMock);
			when(countResponseObjectMock.getCount()).thenReturn(10l);
			doNothing().when(dataRepositoryDao).saveBothSearchHistory(any(SearchHistory.class));

			searchServiceImpl.getTotalRecordsCount(repoName, repoName, searchTypeId, MockData.getfilterObject());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private Map<String,Object> getSourceAsMap(){
		HashMap<String, Object> hashMap = new HashMap<String, Object>();
		hashMap.put(ColumnConstants.IDENTITY,"yfiweuweoeioa" );
		return hashMap;
	}
	
	private String[] getStringArray() {
			String[] strArray= new String[] {"dl_repo","dl_repo2"};
			return strArray;
	}
	
	private String getJsonResponse() {
		StringBuilder json= new StringBuilder();
		json.append("{");
		json.append("\"responses\":[{\"response1\":{"
				+ "\"aserer\":\"truuy\""
				+ "},"
				+ "\"hits\":{"
				+ "\"hits\":["
				+ "{ \"_index\":\"repo\","
				+"\"_source\":{"
				+ "\"es\":\"wrapper\""
				+"}"
				+ "}"
				+ "]"
				+ "}"
				+ "},"
				+ "{\"response2\":{"
				+ "\"swerwr\":\"truiiuy\""
				+ "},"
				+ "\"hits\":{"
				+"\"hits\":["
				+ "{ \"_index\":\"repo\","
				+"\"_source\":{"
				+ "\"es\":\"wrapper\""
				+"}"
				+ "}"
				+ "]"
				+ "}"
				+ "}]");
		
		json.append("}");
		return json.toString();
	}
}
