package com.ncloud.dl.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataLakeApplicationTests {

	@Test
	void contextLoads() {
	}

}
