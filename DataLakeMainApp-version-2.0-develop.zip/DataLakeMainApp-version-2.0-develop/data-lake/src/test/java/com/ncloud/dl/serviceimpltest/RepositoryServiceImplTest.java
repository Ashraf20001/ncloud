package com.ncloud.dl.serviceimpltest;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.client.RestTemplate;

import com.ncloud.dl.DataLakeApplication;
import com.ncloud.dl.config.model.FilterOrSortingVo;
import com.ncloud.dl.dao.datarespository.IDataRepositoryDao;
import com.ncloud.dl.dao.fieldconfiguration.IFieldConfigurationDao;
import com.ncloud.dl.dao.fieldoptionlkn.IFieldOptionLinkingDao;
import com.ncloud.dl.dao.fieldsearchlinking.IFieldSearchLinkingDao;
import com.ncloud.dl.dao.notification.INotificationDao;
import com.ncloud.dl.dao.repository.IRepositoryDao;
import com.ncloud.dl.dao.repositoryscheduledetails.IRepositoryScheduleDetailsDao;
import com.ncloud.dl.dao.schedulernotification.ISchedulerNotificationDao;
import com.ncloud.dl.datatype.factory.DataTypeFactory;
import com.ncloud.dl.datatype.factory.IDataTypeFactoryBuilder;
import com.ncloud.dl.datatype.factory.IDataTypeFactoryValidationBuilder;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.service.IRepositoryNotificationService;
import com.ncloud.dl.service.impl.repository.RepositoryServiceImpl;
import com.ncloud.dl.service.impl.resttemplate.RestTemplateServiceImpl;
import com.ncloud.dl.test.mockdata.MockData;
import com.ncloud.dl.transfer.object.dto.AccessMappingPrivilegeDto;
import com.ncloud.dl.transfer.object.dto.CommentsDto;
import com.ncloud.dl.transfer.object.dto.DataRepositoryDto;
import com.ncloud.dl.transfer.object.dto.FieldOptionLinkingDto;
import com.ncloud.dl.transfer.object.dto.FieldRepositoryDto;
import com.ncloud.dl.transfer.object.dto.FieldsConfiguratorDto;
import com.ncloud.dl.transfer.object.dto.RepositoryScheduleDetailsDto;
import com.ncloud.dl.transfer.object.dto.UserPrivillageDto;
import com.ncloud.dl.transfer.object.entity.DataRepository;
import com.ncloud.dl.transfer.object.entity.FieldOptionLink;
import com.ncloud.dl.transfer.object.entity.NotificationEvent;
import com.ncloud.dl.transfer.object.entity.NotificationTemplate;
import com.ncloud.dl.transfer.object.entity.RepositoryScheduleDetails;
import com.ncloud.dl.utils.ElasticSearchUtils;
import com.ncloud.dl.utils.core.RestTemplateUtils;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DataLakeApplication.class)
public class RepositoryServiceImplTest {

	private static final HttpServletRequest HttpServletRequest = null;

	@InjectMocks
	private RepositoryServiceImpl repositoryServiceImpl;
	
	@Mock
	private IDataRepositoryDao dataRepositoryDao;
	
	@Mock
	private IFieldOptionLinkingDao fieldOptionLinkingDaoMock;
	
	@Mock
	private IRepositoryDao repositoryDaoMock;
	
	@Mock
	private RestTemplateUtils restTemplateUtils;
	
	@Mock
	private IFieldConfigurationDao fieldConfigurationDao;
	
	@Mock
	private DataTypeFactory dataFactoryMock;
	
	@Mock
	private IDataTypeFactoryBuilder iDataTypeFactoryBuilderMock;
	
	@Mock
	private RestTemplate restTemplate;
	
	@Mock
	private ElasticSearchUtils elasticSearchUtils;
	
	@Mock
	private IDataTypeFactoryValidationBuilder iDataTypeFactoryValidationBuilder;
	

	@Mock
	private IFieldSearchLinkingDao fieldSearchLinkingDao;

	@Mock
	private IFieldOptionLinkingDao fieldOptionLinkingDao;
	
	@Mock
	private RestTemplateServiceImpl restTemplateServiceImpl;
	
	@Mock
	private INotificationDao iNotificationDao;
	
	@Mock
	private ISchedulerNotificationDao iSchedulerNotificationDao; 
	
	@Mock
	private IRepositoryScheduleDetailsDao iScheduleDetailsDao;
	
	@Mock
	private IRepositoryNotificationService repositoryNotificationService;
	
	@Mock
	private SimpMessagingTemplate messagingTemplate;
	
	@Mock
	private KafkaTemplate<String, String> kafkaTemplate;
	
	@Test
	public void saveFieldDataRepository_HappyFlow() {
		try {
			when(dataRepositoryDao.saveRepostioryDetails(any())).thenReturn(getDataRepositoryDetails());
			when(fieldConfigurationDao.saveFieldConfiguration(any())).thenReturn(MockData.getFieldConfigurationData());
			when(fieldSearchLinkingDao.saveFieldSearchLinking(any())).thenReturn(MockData.getFieldSearchLinking());
			when(restTemplateServiceImpl.checkForPrivelege(any())).thenReturn(getPrivelegeDetails1());
			doNothing().when(fieldOptionLinkingDao).saveFieldOptionLnk(any());
			when(fieldConfigurationDao.getFieldConfigurationdetails(any())).thenReturn(MockData.getFieldConfigurationData());
			when(fieldOptionLinkingDao.getFieldOptionLinking(any())).thenReturn(getFieldOptionLinkingDto());
			when(iNotificationDao.getNotificationevent(any())).thenReturn(getNotificationEvent());
			when(fieldOptionLinkingDao.getFieldOptionList(any())).thenReturn(MockData.getFieldOptionLinking());
			when(repositoryNotificationService.markAsReadNotification("12",MockData.getUserInfoMockDto())).thenReturn(true);
			when(repositoryDaoMock.getRepositoryDetails(any())).thenReturn(MockData.getDataRepository());
			when(iNotificationDao.getNotificationTemplate(any(),any())).thenReturn(getNotificationTemplate());
			repositoryServiceImpl.saveFieldRepostiory(MockData.getFieldRepositoryDto(), MockData.getUserInfoMockDto(),HttpServletRequest);
		} catch(Exception e) {
			Assertions.fail(); 
		}
	}
	
	
	@Test
	public void saveFieldDataRepository_Error() {
		try {
			when(dataRepositoryDao.saveRepostioryDetails(any())).thenReturn(getDataRepositoryDetails());
			when(fieldConfigurationDao.saveFieldConfiguration(any())).thenReturn(MockData.getFieldConfigurationData());
			when(fieldSearchLinkingDao.saveFieldSearchLinking(any())).thenReturn(MockData.getFieldSearchLinking());
			when(restTemplateServiceImpl.checkForPrivelege(any())).thenReturn(getPrivelegeDetails1());
			doNothing().when(fieldOptionLinkingDao).saveFieldOptionLnk(any());
			when(fieldConfigurationDao.getFieldConfigurationdetails(any())).thenReturn(MockData.getFieldConfigurationData());
			when(fieldOptionLinkingDaoMock.getFieldOptionLinking(any())).thenReturn(getFieldOptionLinkingDto());
			when(iNotificationDao.getNotificationevent(any())).thenReturn(getNotificationEvent());
			when(fieldOptionLinkingDao.getFieldOptionList(any())).thenReturn(MockData.getFieldOptionLinking());
			when(repositoryNotificationService.markAsReadNotification("12", MockData.getUserInfoMockDto())).thenReturn(true);
			when(repositoryDaoMock.getRepositoryDetails(any())).thenReturn(MockData.getDataRepository());
			when(iNotificationDao.getNotificationTemplate(any(),any())).thenReturn(getNotificationTemplate());
			assertThrows(ApplicationException.class, ()->{
				repositoryServiceImpl.saveFieldRepostiory(getFieldRepositoryListDtoError(),MockData.getUserInfoMockDto(),HttpServletRequest);
			});
			
		} catch(Exception e) {
			e.printStackTrace(); 
			Assertions.fail(); 
		}
	}
	@Test
	public void saveFieldDataRepository_Error1() {
		try {
			when(dataRepositoryDao.saveRepostioryDetails(any())).thenReturn(getDataRepositoryDetails());
			when(fieldConfigurationDao.saveFieldConfiguration(any())).thenReturn(MockData.getFieldConfigurationData());
			when(fieldSearchLinkingDao.saveFieldSearchLinking(any())).thenReturn(MockData.getFieldSearchLinking());
			when(restTemplateServiceImpl.checkForPrivelege(any())).thenReturn(null);
			when(fieldOptionLinkingDaoMock.getFieldOptionLinking(any())).thenReturn(getFieldOptionLinkingDto());
			doNothing().when(fieldOptionLinkingDao).saveFieldOptionLnk(any());
			when(fieldConfigurationDao.getFieldConfigurationdetails(any())).thenReturn(MockData.getFieldConfigurationData());
			when(iNotificationDao.getNotificationevent(any())).thenReturn(getNotificationEvent());
			when(fieldOptionLinkingDao.getFieldOptionList(any())).thenReturn(MockData.getFieldOptionLinking());
			when(repositoryNotificationService.markAsReadNotification("12", MockData.getUserInfoMockDto())).thenReturn(true);
			when(repositoryDaoMock.getRepositoryDetails(any())).thenReturn(MockData.getDataRepository());
			when(iNotificationDao.getNotificationTemplate(any(),any())).thenReturn(getNotificationTemplate());
			assertThrows(ApplicationException.class,()->{
				repositoryServiceImpl.saveFieldRepostiory(getFieldRepositoryListDto2(), MockData.getUserInfoMockDto(),HttpServletRequest);
			});
		} catch(Exception e) {
			assertNotNull(e);
			Assertions.fail(); 
		}
	}
	
	@Test
	public void saveFieldDataRepository_Error2() {
		try {
			when(dataRepositoryDao.saveRepostioryDetails(any())).thenReturn(getDataRepositoryDetails());
			when(fieldConfigurationDao.saveFieldConfiguration(any())).thenReturn(MockData.getFieldConfigurationData());
			when(fieldSearchLinkingDao.saveFieldSearchLinking(any())).thenReturn(MockData.getFieldSearchLinking());
			when(restTemplateServiceImpl.checkForPrivelege(any())).thenReturn(getPrivelegeDetails1());
			doNothing().when(fieldOptionLinkingDao).saveFieldOptionLnk(any());
			when(fieldConfigurationDao.getFieldConfigurationdetails(any())).thenReturn(MockData.getFieldConfigurationData());
			when(fieldOptionLinkingDaoMock.getFieldOptionLinking(any())).thenReturn(getFieldOptionLinkingDto());
			when(iNotificationDao.getNotificationevent(any())).thenReturn(getNotificationEvent());
			when(fieldOptionLinkingDao.getFieldOptionList(any())).thenReturn(MockData.getFieldOptionLinking());
			when(repositoryNotificationService.markAsReadNotification("12", MockData.getUserInfoMockDto())).thenReturn(true);
			when(repositoryDaoMock.getRepositoryDetails(any())).thenReturn(MockData.getDataRepository());
			when(iNotificationDao.getNotificationTemplate(any(),any())).thenReturn(getNotificationTemplate());
			assertThrows(ApplicationException.class,()->{
				repositoryServiceImpl.saveFieldRepostiory(getFieldRepositoryListDto1(), MockData.getUserInfoMockDto(),HttpServletRequest);
			});
		} catch(Exception e) {
			e.printStackTrace(); 
			Assertions.fail(); 
		}
	}

	@Test
	public void saveFieldDataRepository_Error3() {
		try {
			when(dataRepositoryDao.saveRepostioryDetails(any())).thenReturn(getDataRepositoryDetails());
			when(fieldConfigurationDao.saveFieldConfiguration(any())).thenReturn(MockData.getFieldConfigurationData());
			when(fieldSearchLinkingDao.saveFieldSearchLinking(any())).thenReturn(MockData.getFieldSearchLinking());
			when(restTemplateServiceImpl.checkForPrivelege(any())).thenReturn(getPrivelegeDetailsError());
			doNothing().when(fieldOptionLinkingDao).saveFieldOptionLnk(any());
			when(fieldConfigurationDao.getFieldConfigurationdetails(any())).thenReturn(MockData.getFieldConfigurationData());
			when(fieldOptionLinkingDaoMock.getFieldOptionLinking(any())).thenReturn(getFieldOptionLinkingDto());
			when(iNotificationDao.getNotificationevent(any())).thenReturn(getNotificationEvent());
			when(fieldOptionLinkingDao.getFieldOptionList(any())).thenReturn(MockData.getFieldOptionLinking());
			when(repositoryNotificationService.markAsReadNotification("12", MockData.getUserInfoMockDto())).thenReturn(true);
			when(repositoryDaoMock.getRepositoryDetails(any())).thenReturn(MockData.getDataRepository());
			when(iNotificationDao.getNotificationTemplate(any(),any())).thenReturn(getNotificationTemplate());
			assertThrows(ApplicationException.class,()->{
				repositoryServiceImpl.saveFieldRepostiory(getFieldRepositoryListDto1(), MockData.getUserInfoMockDto(),HttpServletRequest);
			});
		} catch(Exception e) {
			Assertions.fail(); 
			e.printStackTrace(); 
		}
	}
	@Test
	public void saveFieldDataRepository_Error4() {
		try {
			when(dataRepositoryDao.saveRepostioryDetails(any())).thenReturn(getDataRepositoryDetails());
			when(fieldConfigurationDao.saveFieldConfiguration(any())).thenReturn(MockData.getFieldConfigurationData());
			when(fieldSearchLinkingDao.saveFieldSearchLinking(any())).thenReturn(MockData.getFieldSearchLinking());
			when(restTemplateServiceImpl.checkForPrivelege(any())).thenReturn(null);
			doNothing().when(fieldOptionLinkingDao).saveFieldOptionLnk(any());
			when(fieldConfigurationDao.getFieldConfigurationdetails(any())).thenReturn(MockData.getFieldConfigurationData());
			when(fieldOptionLinkingDaoMock.getFieldOptionLinking(any())).thenReturn(getFieldOptionLinkingDto());
			when(iNotificationDao.getNotificationevent(any())).thenReturn(getNotificationEvent());
			when(fieldOptionLinkingDao.getFieldOptionList(any())).thenReturn(MockData.getFieldOptionLinking());
			when(repositoryNotificationService.markAsReadNotification("12", MockData.getUserInfoMockDto())).thenReturn(true);
			when(repositoryDaoMock.getRepositoryDetails(any())).thenReturn(MockData.getDataRepository());
			when(iNotificationDao.getNotificationTemplate(any(),any())).thenReturn(getNotificationTemplate());
			assertThrows(ApplicationException.class,()->{
				repositoryServiceImpl.saveFieldRepostiory(getFieldRepositoryListDto1(), MockData.getUserInfoMockDto(),HttpServletRequest);
			});
		} catch(Exception e) {
			Assertions.fail(); 
			e.printStackTrace(); 
		}
	}
	@Test
	public void saveFieldDataRepository_ErrorFlow1() {
		try {
			when(dataRepositoryDao.saveRepostioryDetails(any())).thenReturn(getDataRepositoryDetails());
			when(fieldConfigurationDao.saveFieldConfiguration(any())).thenReturn(MockData.getFieldConfigurationData());
			when(fieldSearchLinkingDao.saveFieldSearchLinking(any())).thenReturn(MockData.getFieldSearchLinking());
			when(restTemplateServiceImpl.checkForPrivelege(any())).thenReturn(getPrivelegeDetails1());
			doNothing().when(fieldOptionLinkingDao).saveFieldOptionLnk(any());
			when(fieldOptionLinkingDao.getFieldOptionList(any())).thenReturn(MockData.getFieldOptionLinking());
			when(repositoryNotificationService.markAsReadNotification("12", MockData.getUserInfoMockDto())).thenReturn(true);
			when(iNotificationDao.getNotificationevent(any())).thenReturn(getNotificationEvent());
			when(repositoryDaoMock.getRepositoryDetails(any())).thenReturn(MockData.getDataRepository());
			when(iNotificationDao.getNotificationTemplate(any(),any())).thenReturn(getNotificationTemplate());
			repositoryServiceImpl.saveFieldRepostiory(MockData.getFieldRepositoryListDtos(), MockData.getUserInfoMockDto(),HttpServletRequest);
		} catch(Exception e) {
			assertNotNull(e);
			Assertions.fail(); 
		}
	}

	@Test
	public void saveCommentsForRepository_HappyFlow() {
		try {
			when(repositoryDaoMock.getRepositoryDetails(any())).thenReturn(MockData.getDataRepository());
			doNothing().when(repositoryDaoMock).saveComments(any());
			when(restTemplateServiceImpl.checkForPrivelege(any())).thenReturn(getPrivelegeDetails1());
			when(iNotificationDao.getNotificationevent(any())).thenReturn(getNotificationEvent());
			when(iNotificationDao.getNotificationTemplate(any(),any())).thenReturn(getNotificationTemplate());
			doNothing().when(messagingTemplate).convertAndSend("test",true);
			repositoryServiceImpl.saveCommentsForRepository(getcommentsdto(), MockData.getUserInfoMockDto(),HttpServletRequest);
		} catch(Exception e) {
			e.printStackTrace();
			Assertions.fail(); 
		}
	}
	
	@Test
	public void saveCommentsForRepository_ErrorFlow() {
		try {
			when(repositoryDaoMock.getRepositoryDetails(null)).thenReturn(null);
			doNothing().when(repositoryDaoMock).saveComments(any());
			when(restTemplateServiceImpl.checkForPrivelege(any())).thenReturn(null);
			when(iNotificationDao.getNotificationevent(any())).thenReturn(getNotificationEvent());
			when(iNotificationDao.getNotificationTemplate(any(),any())).thenReturn(getNotificationTemplate());
			assertThrows(ApplicationException.class, ()->{
				repositoryServiceImpl.saveCommentsForRepository(getcommentsdtoError(), MockData.getUserInfoMockDto(),HttpServletRequest);
			});
		} catch(Exception e) {
			e.printStackTrace();
			assertNotNull(e);
		}
	}
	
	@Test
	public void saveCommentsForRepository_ErrorFlow1() {
		try {
			when(repositoryDaoMock.getRepositoryDetails(null)).thenReturn(MockData.getDataRepository());
			doNothing().when(repositoryDaoMock).saveComments(any());
			when(restTemplateServiceImpl.checkForPrivelege(any())).thenReturn(null);
			when(iNotificationDao.getNotificationevent(any())).thenReturn(getNotificationEvent());
			when(iNotificationDao.getNotificationTemplate(any(),any())).thenReturn(getNotificationTemplate());
			assertThrows(ApplicationException.class, ()->{
				repositoryServiceImpl.saveCommentsForRepository(getcommentsdtoError(), null,HttpServletRequest);
			});
		} catch(Exception e) {
			e.printStackTrace();
			assertNotNull(e);
		}
	}
	
	@Test
	public void getRepositoryAndFieldDetails_HappyFlow() {
		try {
			when(repositoryDaoMock.getRepositoryDetails(any())).thenReturn(MockData.getDataRepository());
			when(fieldConfigurationDao.getFieldDetails(any())).thenReturn(MockData.getDataRepositories());
			when(fieldOptionLinkingDao.getFieldOptionList(any())).thenReturn(MockData.getFieldOptionLinking());
			when(fieldSearchLinkingDao.getFieldSearchLinking(any())).thenReturn(MockData.getFieldSearchLinking());
			repositoryServiceImpl.getRepositoryAndFieldDetails("1");
		} catch(Exception e) {
			Assertions.fail(); 
		}
	}
	
	@Test
	public void updateRepositoryDetails_HappyFlow() {
		try {
			when(repositoryDaoMock.getRepositoryDetails("123")).thenReturn(MockData.getDataRepository());
			when(dataRepositoryDao.getDataRepositoryByRepoNameAndId(MockData.getFieldRepository1().getRepositoryName(),
					MockData.getFieldRepository1().getRepositoryId(), MockData.getFieldRepository1().getRepositoryIdentity(), true, MockData.getFieldRepository1().getRepositoryVersion(),
					List.of(MockData.getFieldRepository1().getRepositoryIdentity()))).thenReturn(MockData.getDataRepositoryList1());
			
			doNothing().when(dataRepositoryDao).UpdateRepostioryDetails(MockData.getDataRepository());
			when(fieldConfigurationDao.getFieldConfigurationdetails(any())).thenReturn(MockData.getFieldConfigurationData());
			when(fieldOptionLinkingDao.getFieldOptionLinking(any())).thenReturn(MockData.getFieldOptionLinkingDetails());
			doNothing().when(fieldConfigurationDao).updateFieldConfiguration(MockData.getFieldConfigurationData());
			when(dataRepositoryDao.saveRepostioryDetails(any())).thenReturn(MockData.getDataRepository());
			when(fieldConfigurationDao.saveFieldConfiguration(any())).thenReturn(MockData.getFieldConfigurationData());
			when(fieldSearchLinkingDao.saveFieldSearchLinking(any())).thenReturn(MockData.getFieldSearchLinking());
			when(iNotificationDao.getNotificationevent(any())).thenReturn(getNotificationEvent());
			when(iNotificationDao.getNotificationTemplate(any(),any())).thenReturn(getNotificationTemplate());
			when(restTemplateServiceImpl.checkForPrivelege(any())).thenReturn(getPrivelegeDetails1());
			doNothing().when(fieldOptionLinkingDao).saveFieldOptionLnk(any());
			repositoryServiceImpl.updateRepositoryDetails(MockData.getFieldRepository1(),MockData.getUserInfoMockDto(),HttpServletRequest);
		} catch(Exception e) {
			Assertions.fail(); 
		}
	}
	
	@Test
	public void updateRepositoryDetails_HappyFlow1() {
		try {
			when(repositoryDaoMock.getRepositoryDetails(any())).thenReturn(getDataRepositoryHappy());
			doNothing().when(dataRepositoryDao).UpdateRepostioryDetails(MockData.getDataRepository());
			when(fieldConfigurationDao.getFieldConfigurationdetails(any())).thenReturn(MockData.getFieldConfigurationData());
			when(fieldOptionLinkingDao.getFieldOptionLinking(any())).thenReturn(MockData.getFieldOptionLinkingDetails());
			doNothing().when(fieldConfigurationDao).updateFieldConfiguration(MockData.getFieldConfigurationData());
			when(dataRepositoryDao.saveRepostioryDetails(any())).thenReturn(MockData.getDataRepository());
			when(fieldConfigurationDao.saveFieldConfiguration(any())).thenReturn(MockData.getFieldConfigurationData());
			when(fieldSearchLinkingDao.saveFieldSearchLinking(any())).thenReturn(MockData.getFieldSearchLinking());
			when(iNotificationDao.getNotificationevent(any())).thenReturn(getNotificationEvent());
			when(iNotificationDao.getNotificationTemplate(any(),any())).thenReturn(getNotificationTemplate());
			when(restTemplateServiceImpl.checkForPrivelege(any())).thenReturn(getPrivelegeDetails1());
			doNothing().when(fieldOptionLinkingDao).saveFieldOptionLnk(any());
			repositoryServiceImpl.updateRepositoryDetails(MockData.getFieldRepositoryListDto(),MockData.getUserInfoMockDto(),HttpServletRequest);
		} catch(Exception e) {
			Assertions.fail(); 
			e.printStackTrace();
		}
	}
	

	@Test
	public void updateRepositoryDetails_Error() {
		try {
			when(repositoryDaoMock.getRepositoryDetails(any())).thenReturn(MockData.getDataRepository());
			doNothing().when(dataRepositoryDao).UpdateRepostioryDetails(MockData.getDataRepository());
			when(fieldConfigurationDao.getFieldConfigurationdetails(any())).thenReturn(MockData.getFieldConfigurationData());
			when(fieldOptionLinkingDao.getFieldOptionLinking(any())).thenReturn(MockData.getFieldOptionLinkingDetails());
			doNothing().when(fieldConfigurationDao).updateFieldConfiguration(MockData.getFieldConfigurationData());
			when(dataRepositoryDao.saveRepostioryDetails(any())).thenReturn(MockData.getDataRepository());
			when(fieldConfigurationDao.saveFieldConfiguration(any())).thenReturn(MockData.getFieldConfigurationData());
			when(fieldSearchLinkingDao.saveFieldSearchLinking(any())).thenReturn(MockData.getFieldSearchLinking());
			when(iNotificationDao.getNotificationevent(any())).thenReturn(getNotificationEvent());
			when(iNotificationDao.getNotificationTemplate(any(),any())).thenReturn(getNotificationTemplate());
			when(restTemplateServiceImpl.checkForPrivelege(any())).thenReturn(getPrivelegeDetails1());
			doNothing().when(fieldOptionLinkingDao).saveFieldOptionLnk(any());
			repositoryServiceImpl.updateRepositoryDetails(MockData.getFieldRepository(),MockData.getUserInfoMockDto(),HttpServletRequest);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void updateRepositoryDetails_ErrorFlow1() {
		try {
			when(repositoryDaoMock.getRepositoryDetails(any())).thenReturn(MockData.getDataRepository());
			doNothing().when(dataRepositoryDao).UpdateRepostioryDetails(MockData.getDataRepository());
			when(fieldConfigurationDao.getFieldConfigurationdetails(any())).thenReturn(MockData.getFieldConfigurationData());
			when(fieldOptionLinkingDao.getFieldOptionLinking(any())).thenReturn(MockData.getFieldOptionLinkingDetails());
			doNothing().when(fieldConfigurationDao).updateFieldConfiguration(MockData.getFieldConfigurationData());
			when(dataRepositoryDao.saveRepostioryDetails(any())).thenReturn(MockData.getDataRepository());
			when(fieldConfigurationDao.saveFieldConfiguration(any())).thenReturn(MockData.getFieldConfigurationData());
			when(fieldSearchLinkingDao.saveFieldSearchLinking(any())).thenReturn(MockData.getFieldSearchLinking());
			when(iNotificationDao.getNotificationevent(any())).thenReturn(getNotificationEvent());
			when(iNotificationDao.getNotificationTemplate(any(),any())).thenReturn(getNotificationTemplate());
			when(restTemplateServiceImpl.checkForPrivelege(any())).thenReturn(getPrivelegeDetails1());
			doNothing().when(fieldOptionLinkingDao).saveFieldOptionLnk(any());
			repositoryServiceImpl.updateRepositoryDetails(MockData.getFieldRepository(),MockData.getUserInfoMockDto(),HttpServletRequest);
		} catch(Exception e) {
			assertNotNull(e); 
			Assertions.fail();
		}
	}
	

	@Test
	public void updateRepositoryDetails_ErrorFlow2() {
		try {
			when(repositoryDaoMock.getRepositoryDetails("123")).thenReturn(MockData.getDataRepository());
			when(repositoryDaoMock.getRepositoryDetails(any())).thenReturn(null);		
			doNothing().when(dataRepositoryDao).UpdateRepostioryDetails(MockData.getDataRepository());
			when(fieldConfigurationDao.getFieldConfigurationdetails(any())).thenReturn(MockData.getFieldConfigurationData());
			when(fieldOptionLinkingDao.getFieldOptionLinking(any())).thenReturn(MockData.getFieldOptionLinkingDetails());
			doNothing().when(fieldConfigurationDao).updateFieldConfiguration(MockData.getFieldConfigurationData());
			when(dataRepositoryDao.saveRepostioryDetails(any())).thenReturn(MockData.getDataRepository());
			when(fieldConfigurationDao.saveFieldConfiguration(any())).thenReturn(MockData.getFieldConfigurationData());
			when(fieldSearchLinkingDao.saveFieldSearchLinking(any())).thenReturn(MockData.getFieldSearchLinking());
			when(iNotificationDao.getNotificationevent(any())).thenReturn(getNotificationEvent());
			when(iNotificationDao.getNotificationTemplate(any(),any())).thenReturn(getNotificationTemplate());
			when(restTemplateServiceImpl.checkForPrivelege(any())).thenReturn(getPrivelegeDetails1());
			doNothing().when(fieldOptionLinkingDao).saveFieldOptionLnk(any());
			assertThrows(ApplicationException.class, ()->{
				repositoryServiceImpl.updateRepositoryDetails(MockData.getFieldRepository1(),MockData.getUserInfoMockDto(),HttpServletRequest);
			});
		} catch(Exception e) {
			Assertions.fail();
			 assertNotNull(e);
		}
	}
	


	
	
	@Test
	public void updateSchedulerDetailsWeekType_HappyFlow() {
		try {
			when(iSchedulerNotificationDao.getSchedulerNotificationbyRepositoryIdentityDetails(any()))
					.thenReturn(MockData.getSchedulerNotification());
			doNothing().when(iSchedulerNotificationDao).saveUpdateSchedulerNotification(MockData.getSchedulerNotification());
			when(iScheduleDetailsDao.saveRepositoryScheduleDetails(any()))
					.thenReturn(getRepositoryScheduleDetails());
			when(iScheduleDetailsDao.getRepositoryScheduleDetailsByIdentity("123")).thenReturn(getRepositoryScheduleDetails());
			repositoryServiceImpl.updateSchedulerDetails(MockData.getSchedulerDetails(), MockData.getUserInfoMockDto());
		} catch (Exception e) {
			e.printStackTrace();
			Assertions.fail();
		}
	}
	
	
	@Test
	public void updateSchedulerDetailsDayType_HappyFlow() {
		try {
			when(iSchedulerNotificationDao.getSchedulerNotificationbyRepositoryIdentityDetails(any()))
					.thenReturn(MockData.getSchedulerNotification());
			doNothing().when(iSchedulerNotificationDao).saveUpdateSchedulerNotification(MockData.getSchedulerNotification());
			when(iScheduleDetailsDao.saveRepositoryScheduleDetails(any()))
					.thenReturn(getRepositoryScheduleDetails());
			repositoryServiceImpl.updateSchedulerDetails(MockData.getSchedulerDetailsDay(), MockData.getUserInfoMockDto());
		} catch (Exception e) {
			e.printStackTrace();
			Assertions.fail();
		}
	}
	
	@Test
	public void updateSchedulerDetailsDayType_ErrorFlow() {
		try {
			when(iSchedulerNotificationDao.getSchedulerNotificationbyRepositoryIdentityDetails(any()))
					.thenReturn(MockData.getSchedulerNotification());
			doNothing().when(iSchedulerNotificationDao).saveUpdateSchedulerNotification(MockData.getSchedulerNotification());
			when(iScheduleDetailsDao.saveRepositoryScheduleDetails(any()))
					.thenReturn(getRepositoryScheduleDetails());
			assertThrows(ApplicationException.class, ()->{
				repositoryServiceImpl.updateSchedulerDetails(getSchedulerDetailsDayError(), MockData.getUserInfoMockDto());
			});
		} catch (Exception e) {
			Assertions.fail();
			assertNotNull(e);
			
		}
	}
	
	@Test
	public void updateSchedulerDetailsYearType_HappyFlow() {
		try {
			when(iSchedulerNotificationDao.getSchedulerNotificationbyRepositoryIdentityDetails(any()))
					.thenReturn(MockData.getSchedulerNotification());
			doNothing().when(iSchedulerNotificationDao).saveUpdateSchedulerNotification(MockData.getSchedulerNotification());
			when(iScheduleDetailsDao.saveRepositoryScheduleDetails(any()))
					.thenReturn(getRepositoryScheduleDetails());
			repositoryServiceImpl.updateSchedulerDetails(MockData.getSchedulerDetailsYear(), MockData.getUserInfoMockDto());
		} catch (Exception e) {
			e.printStackTrace();
			Assertions.fail();
		}
	}
	
	@Test
	public void updateSchedulerDetailsYearType_ErrorFlow() {
		try {
			when(iSchedulerNotificationDao.getSchedulerNotificationbyRepositoryIdentityDetails(any()))
					.thenReturn(MockData.getSchedulerNotification());
			doNothing().when(iSchedulerNotificationDao).saveUpdateSchedulerNotification(MockData.getSchedulerNotification());
			when(iScheduleDetailsDao.saveRepositoryScheduleDetails(any()))
					.thenReturn(getRepositoryScheduleDetails());
			repositoryServiceImpl.updateSchedulerDetails(MockData.getSchedulerDetailsYearError(),MockData.getUserInfoMockDto());
		} catch (Exception e) {
			e.printStackTrace();
			Assertions.fail();
		}
	}
	
	@Test
	public void updateSchedulerDetailsYearType_FailureFlow() {
		try {
			when(iSchedulerNotificationDao.getSchedulerNotificationbyRepositoryIdentityDetails(any()))
					.thenReturn(MockData.getSchedulerNotification());
			doNothing().when(iSchedulerNotificationDao).saveUpdateSchedulerNotification(MockData.getSchedulerNotification());
			when(iScheduleDetailsDao.saveRepositoryScheduleDetails(any()))
					.thenReturn(getRepositoryScheduleDetails());
			when(iScheduleDetailsDao.getRepositoryScheduleDetailsByIdentity("123")).thenReturn(getRepositoryScheduleDetails());
			assertThrows(ApplicationException.class, ()->
			{
				repositoryServiceImpl.updateSchedulerDetails(MockData.getSchedulerDetailsYearFailure(), MockData.getUserInfoMockDto());
			});
		} catch (Exception e) {
			Assertions.fail();
			assertNotNull(e);
			
		}
	}

	@Test
	public void updateSchedulerDetailsMonthType_HappyFlow() {
		try {
			when(iSchedulerNotificationDao.getSchedulerNotificationbyRepositoryIdentityDetails(any()))
					.thenReturn(MockData.getSchedulerNotification());
			doNothing().when(iSchedulerNotificationDao).saveUpdateSchedulerNotification(MockData.getSchedulerNotification());
			when(iScheduleDetailsDao.saveRepositoryScheduleDetails(any()))
					.thenReturn(getRepositoryScheduleDetails());
			repositoryServiceImpl.updateSchedulerDetails(MockData.getSchedulerDetailsDayMonth(), MockData.getUserInfoMockDto());
		} catch (Exception e) {
			e.printStackTrace();
			Assertions.fail();
		}
	}
	
	@Test
	public void updateSchedulerDetailsMonthType_ErrorFlow() {
		try {
			when(iSchedulerNotificationDao.getSchedulerNotificationbyRepositoryIdentityDetails(any()))
					.thenReturn(MockData.getSchedulerNotification());
			doNothing().when(iSchedulerNotificationDao).saveUpdateSchedulerNotification(MockData.getSchedulerNotification());
			when(iScheduleDetailsDao.saveRepositoryScheduleDetails(any()))
					.thenReturn(getRepositoryScheduleDetails());
			repositoryServiceImpl.updateSchedulerDetails(MockData.getSchedulerDetailsDayMonthError(), MockData.getUserInfoMockDto());
		} catch (Exception e) {
			e.printStackTrace();
			Assertions.fail();
		}
	}
	
	@Test
	public void updateSchedulerDetailsError_ErrorFlow() {
		try {
			when(iSchedulerNotificationDao.getSchedulerNotificationbyRepositoryIdentityDetails(any()))
					.thenReturn(MockData.getSchedulerNotification());
			doNothing().when(iSchedulerNotificationDao).saveUpdateSchedulerNotification(MockData.getSchedulerNotification());
			when(iScheduleDetailsDao.saveRepositoryScheduleDetails(any()))
					.thenReturn(getRepositoryScheduleDetails());
			assertThrows(ApplicationException.class,()->{
				repositoryServiceImpl.updateSchedulerDetails(getSchedulerDetailsDayMonthErrorflow(),MockData.getUserInfoMockDto());
			});
		} catch (Exception e) {
			Assertions.fail();
			assertNotNull(e);
			
		}
	}
	
	@Test
	public void updateSchedulerDetailsMonthType_FailureFlow() {
		try {
			when(iSchedulerNotificationDao.getSchedulerNotificationbyRepositoryIdentityDetails(any()))
					.thenReturn(MockData.getSchedulerNotification());
			doNothing().when(iSchedulerNotificationDao).saveUpdateSchedulerNotification(MockData.getSchedulerNotification());
			when(iScheduleDetailsDao.saveRepositoryScheduleDetails(any()))
					.thenReturn(getRepositoryScheduleDetails());
			assertThrows(ApplicationException.class, ()->{
				repositoryServiceImpl.updateSchedulerDetails(getSchedulerDetailsDayFailure(), MockData.getUserInfoMockDto());
			});
		} catch (Exception e) {
			Assertions.fail();
			assertNotNull(e);
		}
	}
	
	@Test
	public void updateSchedulerDetails_FailureFlow() {
		try {
			when(iSchedulerNotificationDao.getSchedulerNotificationbyRepositoryIdentityDetails(any()))
					.thenReturn(null);
			doNothing().when(iSchedulerNotificationDao).saveUpdateSchedulerNotification(MockData.getSchedulerNotification());
			when(iScheduleDetailsDao.saveRepositoryScheduleDetails(any()))
					.thenReturn(getRepositoryScheduleDetails());
			assertThrows(ApplicationException.class, ()->{
				repositoryServiceImpl.updateSchedulerDetails(getSchedulerDetailsDayFailures(), MockData.getUserInfoMockDto());
			});
		} catch (Exception e) {
			Assertions.fail();
			assertNotNull(e);
		}
	}

	@Test
	public void saveFieldDataRepository_FailureFlow() {
		try {
			when(dataRepositoryDao.saveRepostioryDetails(any())).thenReturn(MockData.getDataRepository());
			when(fieldConfigurationDao.saveFieldConfiguration(any())).thenReturn(MockData.getFieldConfigurationData());
			when(fieldSearchLinkingDao.saveFieldSearchLinking(any())).thenReturn(MockData.getFieldSearchLinking());
			doNothing().when(fieldOptionLinkingDao).saveFieldOptionLnk(any());
			javax.servlet.http.HttpServletRequest servletMock = mock(HttpServletRequest.class);
			assertThrows(ApplicationException.class, ()->{
				repositoryServiceImpl.saveFieldRepostiory(MockData.getRepositoryDetailsForFieldRepository(), null, servletMock);
			});
		} catch (Exception e) {
			Assertions.fail();
			assertNotNull(e);
		}
	}

	@Test
	public void getCommentsValues_HappyFlow() {
		try {
			when(dataRepositoryDao.getCommentsValues(any())).thenReturn(MockData.getcommentsList());
			when(restTemplateUtils.configureRestTemplate(HttpServletRequest)).thenReturn(MockData.getvalue());
			when(restTemplateServiceImpl.getUserNameByUserIdRestTemplate(any(), any())).thenReturn(MockData.getUserDetailsDto());
			repositoryServiceImpl.getCommentsValues("prabu", HttpServletRequest);
		} catch (Exception e) {
			Assertions.fail();
		}
	}
	
	@Test
	public void getCommentsValues_ErrorFlow() {
		try {
			when(dataRepositoryDao.getCommentsValues(any())).thenReturn(MockData.getcommentsList1());
			when(restTemplateUtils.configureRestTemplate(HttpServletRequest)).thenReturn(MockData.getvalue());
			when(restTemplateServiceImpl.getUserNameByUserIdRestTemplate(any(), any())).thenReturn(MockData.getUserDetailsDto());
			repositoryServiceImpl.getCommentsValues("prabu", HttpServletRequest);
		} catch (Exception e) {
			Assertions.fail();
		}
	}

	@Test
	public void updateRepoStatus_HappyFlow() {
		try {
			when(dataRepositoryDao.getUpdateStatusDataRepository(any())).thenReturn(getDataRepositoryDetails());
			doNothing().when(dataRepositoryDao).saveUpdateStatusDataRepository(any());
			when(restTemplateServiceImpl.checkForPrivelege(HttpServletRequest)).thenReturn(getPrivelegeDetails1());
			repositoryServiceImpl.updateStatusDataRepository("prabu", "Approve", MockData.getUserInfoMockDto(), HttpServletRequest);
		} catch (Exception e) {
			Assertions.fail();
		}
	} 
	

	@Test
	public void updateRepositoryRename_HappyFlow() {
		try {
			when(dataRepositoryDao.getUpdateStatusDataRepository(any())).thenReturn(MockData.getDataRepository());
            doNothing().when(dataRepositoryDao).saveUpdateStatusDataRepository(any());
			repositoryServiceImpl.updateRepositoryName(MockData.getRepositoryDetailsForFieldRepository(),MockData.getUserInfoMockDto());
		} catch(Exception e) {
			Assertions.fail();
		} 
	} 
	
	@Test
	public void updateRepositoryName_ErrorFlow() {
		try {
			when(dataRepositoryDao.getUpdateStatusDataRepository(any())).thenReturn(MockData.getDataRepository());
            doNothing().when(dataRepositoryDao).saveUpdateStatusDataRepository(any());
			repositoryServiceImpl.updateRepositoryName(MockData.getRepositoryDetailsForFieldRepository(),MockData.getUserInfoMockDto());
		} catch(Exception e) {
			e.printStackTrace();   
			assertNotNull(e);  
		} 
	}
	
	@Test
	public void updateRepoStatus_ErrorFlow() {
		try {
			when(dataRepositoryDao.getUpdateStatusDataRepository(any())).thenReturn(null);
			doNothing().when(dataRepositoryDao).saveUpdateStatusDataRepository(any());
			assertThrows(ApplicationException.class, ()->{
				repositoryServiceImpl.updateStatusDataRepository("prabu", null, null, null);
			});
		} catch (Exception e) {
			Assertions.fail();
			assertNotNull(e);
		}
	}
	
	@Test
	public void getRepositoryListCount_HappyFlow() {
		try {
			when(dataRepositoryDao.getRepositoryCountValue(any(),any(),any())).thenReturn((long) 123);
			repositoryServiceImpl.getRepositoryListCount(any(),any(),any());
		} catch (Exception e) {
			Assertions.fail();
		}
	}
	

	@Test
	public void getSchedulerListCount_HappyFlow() {
		try {
			when(dataRepositoryDao.getSchedulerCountValue()).thenReturn((long) 123);
			repositoryServiceImpl.getSchedulerListCount();
		} catch (Exception e) {
			Assertions.fail();
		}
	}
	
	
	@Test
	public void getUserRoleDetails_HappyFlow() {
		try {
			when(restTemplateServiceImpl.getUserPrivivlegeDto(any())).thenReturn(getPrivelegeDetails());
			repositoryServiceImpl.getUserRoleDetails(MockData.getUserInfoMockDto(),HttpServletRequest);
		} catch (Exception e) {
			Assertions.fail(); 
			assertNotNull(e);
			e.printStackTrace();
		}
	}
	@Test
	public void getRepositoryCardList_HappyFlow() {
		try {
			when(dataRepositoryDao.getDataRepositoryList(any(),any(),any(),any(),any())).thenReturn(MockData.getDataRepositoryList());
			repositoryServiceImpl.getRepositoryCardList(0, 10, getFilterVo(),"123",MockData.getUserInfoMockDto(),"APPROVER",HttpServletRequest);
		} catch (Exception e) {
			Assertions.fail();
		}
	}
	
	@Test
	public void getSchedulerDetails_HappyFlow() {
		try {
			when(dataRepositoryDao.getSchedulerDetailsdao(any(),any(),any())).thenReturn(MockData.getSchedulertDto());
			repositoryServiceImpl.getSchedulerDetails(any(),any(),any());
		} catch (Exception e) {
			Assertions.fail();
		}
	}
	
	@Test
	public void getRepositoryApprovedList_HappyFlow() {
		try {
			when(dataRepositoryDao.getDataRepositoryListForApproved(any(), any(), any(), any(), any())).thenReturn(MockData.getDataRepositoryList());
			repositoryServiceImpl.getRepositoryCardListforApproved(0,10,getFilterVo(),"new",MockData.getUserInfoMockDto(),true);
		} catch (Exception e) {
			Assertions.fail();
		}
	}
	
			
		
	@Test
	public void cardRepoDisable_HappyFlow() {
		try {
			when(dataRepositoryDao.getUpdateStatusDataRepository(any())).thenReturn(MockData.getDataRepository());
			doNothing().when(dataRepositoryDao).saveUpdateStatusDataRepository(any());
			repositoryServiceImpl.updateCardRepository("prabu", LocalDate.now(), MockData.getUserInfoMockDto());
		} catch (Exception e) {
			Assertions.fail();
		}
	}
	
	@Test
	public void cardRepositoryDisable_ErrorFlow() {
		try {
			when(dataRepositoryDao.getUpdateStatusDataRepository(any())).thenReturn(null);
			doNothing().when(dataRepositoryDao).saveUpdateStatusDataRepository(any());
			assertThrows(ApplicationException.class, ()->{
				repositoryServiceImpl.updateCardRepository(null, null, MockData.getUserInfoMockDto());
			});
		} catch (Exception e) {
			e.printStackTrace();
			assertNotNull(e);
		}

	}
	
	@Test
	public void schedulerDeleteDetail_HappyFlow() {
		try {
			when(dataRepositoryDao.getSchedulerDetails(any())).thenReturn(MockData.getSchedulerNotification());
			doNothing().when(dataRepositoryDao).saveUpdatestatusScheduler(any());
			repositoryServiceImpl.schedulerDelete("prabu", MockData.getUserInfoMockDto());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	@Test
	public void schedulerDelete_ErrorFlow() {
		try {
			when(dataRepositoryDao.getSchedulerDetails(any())).thenReturn(null);
			doNothing().when(dataRepositoryDao).saveUpdatestatusScheduler(any());
			assertThrows(ApplicationException.class, ()->{
				repositoryServiceImpl.schedulerDelete(null, MockData.getUserInfoMockDto());
			});
		} catch (Exception e) {
			e.printStackTrace();
			assertNotNull(e);
		}
	}		

	@Test
	public void editSchedulerDetails_HappyFlow() {
		try {
			when(dataRepositoryDao.getSchedulerTableDetails(any())).thenReturn(MockData.getSchedulerNotification());
            when(dataRepositoryDao.getrepositorySchedulerDetails(any())).thenReturn(getRepositoryScheduler());
			repositoryServiceImpl.editschedulerDetails(any());
		} catch(Exception e) {
			Assertions.fail();
		}
	} 
	
	@Test
	public void getRepositoryApprovedListCount_HappyFlow() {
		try {
			when(dataRepositoryDao.getRepositoryApprovedCountValue(any(),any(),any())).thenReturn((long)10);
			repositoryServiceImpl.getRepositoryApprovedListCount(getFilterVo(),"123",true);
		} catch(Exception e) {
			Assertions.fail();
		}
	} 
	
	@Test
	public void getRepositoryStatusByIdentity_HappyFlow() {
		try {
			when(repositoryDaoMock.getRepositoryStatusByIdentity(any())).thenReturn(getfilterObject());
			repositoryServiceImpl.getRepositoryStatusByIdentity("123");
		} catch(Exception e) {
			Assertions.fail();
		}
	}
	
	@Test
	public void approveRepository_happyFlow() {
		LinkedHashMap<String,String> map = new LinkedHashMap<String,String>();
		try{
			when(restTemplateServiceImpl.checkForPrivelege(HttpServletRequest)).thenReturn(getPrivelegeDetails1());
			when(repositoryDaoMock.getRepositoryDetails("123")).thenReturn(MockData.getDataRepository());
			when(repositoryNotificationService.markAsReadNotification("test", MockData.getUserInfoMockDto())).thenReturn(Boolean.TRUE);
			doNothing().when(repositoryDaoMock).updateRepostioryDetails(MockData.getDataRepository());
			when(dataRepositoryDao.getDataRepositoryByRepoNameAndId("test", "test", "test", Boolean.TRUE, 5D, MockData.getDeletedList())).thenReturn(MockData.getDataRepositoryList());
			when(dataRepositoryDao.saveRepostioryDetails(MockData.getDataRepository())).thenReturn(MockData.getDataRepository());
			when(fieldConfigurationDao.getFieldConfigurationdetails("test")).thenReturn(MockData.getFieldConfigurationData());
			when(fieldConfigurationDao.saveFieldConfiguration(MockData.getFieldConfigurationData())).thenReturn(MockData.getFieldConfigurationData());
			doNothing().when(fieldConfigurationDao).updateFieldConfiguration(MockData.getFieldConfigurationData());
			when(fieldOptionLinkingDao.getFieldOptionLinking("test")).thenReturn(MockData.getFieldOptionLinkingDetails());
			doNothing().when(fieldOptionLinkingDao).updateFieldOptionLnk(MockData.getFieldOptionLinkingDetails());
			doNothing().when(fieldOptionLinkingDao).saveFieldOptionLnk(MockData.getFieldOptionLinkingDetails());
			when(fieldOptionLinkingDao.getFieldOptionLinking("test")).thenReturn(MockData.getFieldOptionLinkingDetails());
			doNothing().when(fieldOptionLinkingDao).updateFieldOptionLnk(MockData.getFieldOptionLinkingDetails());
			when(iNotificationDao.getNotificationevent("test")).thenReturn(getNotificationEvent());
			when(iNotificationDao.getNotificationTemplate(getNotificationEvent(), "test")).thenReturn(getNotificationTemplate());
			doNothing().when(iNotificationDao).saveNotificationDetails(MockData.getRepositoryNotification());
			doNothing().when(messagingTemplate).convertAndSend("test", true);
			when(repositoryDaoMock.getRepositoryDetails("test")).thenReturn(MockData.getDataRepository());
			doNothing().when(repositoryDaoMock).updateRepostioryDetails(MockData.getDataRepository());
			when(dataRepositoryDao.getFieldRepository("123")).thenReturn(MockData.getDataRepositories());
			when(iSchedulerNotificationDao.saveSchedulerNotification(MockData.getSchedulerNotification())).thenReturn(MockData.getSchedulerNotification());
			when(iScheduleDetailsDao.saveRepositoryScheduleDetails(getRepositoryScheduleDetails())).thenReturn(getRepositoryScheduleDetails());
			when(dataFactoryMock.getFieldDetailManagerType("test")).thenReturn(iDataTypeFactoryBuilderMock);
			when(iDataTypeFactoryBuilderMock.getDataTypeWithColQuery("test", "test")).thenReturn("test");		
			doNothing().when(fieldConfigurationDao).createTableQuery(map, "test");
			when(fieldConfigurationDao.getFieldConfigurationdetails(any())).thenReturn(MockData.getFieldConfigurationData());
			repositoryServiceImpl.approveRepository(MockData.getFieldRepository1(), MockData.getUserInfoMockDto(), HttpServletRequest);
			
		} catch(Exception e) {
			e.printStackTrace();
			Assertions.fail();
		}
	}



	private Object[] getfilterObject() {
		Object[] value = new Object[] {1,2};
		return value;
	}


	//**********************************MOCK DATA*********************************************
	
	private RepositoryScheduleDetails getRepositoryScheduler() {
		RepositoryScheduleDetails repositoryScheduleDetails = new RepositoryScheduleDetails();
		repositoryScheduleDetails.setEndDate("2023-05-21");
		repositoryScheduleDetails.setStartDatewithtime("2023-03-21 00:00:00");
		return repositoryScheduleDetails;
	}

	
	
	private HashMap<String, String> getHashmapValue() {
		Map<String , String> val = new HashMap<>();
		val.put("FieldsName", "datalake");
		return (HashMap<String, String>) val;
	}
	
	private List<FilterOrSortingVo> getFilterVo() {
		List<FilterOrSortingVo> filter = new ArrayList<>();
		filter.add(getSingleFilterVo());
		return filter;
	}

	private FilterOrSortingVo getSingleFilterVo() {
		FilterOrSortingVo filter = new FilterOrSortingVo();
		filter.setAscending(false);
		filter.setColumnName("ABC");
		filter.setCondition("Equal");
		filter.setFilterOrSortingType("ASC");
		return filter;
	}

	
	private HashMap<String, String> getHashmapValue1() {
		Map<String , String> val = new HashMap<>();
		val.put("FieldsName", "12-03-2023");
		return (HashMap<String, String>) val;
	}
	
	private HashMap<String, String> getHashmapValue2() {
		Map<String , String> val = new HashMap<>();
		val.put("FieldsName", "12");
		return (HashMap<String, String>) val;
	}


	
	private NotificationTemplate getNotificationTemplate() {
		NotificationTemplate value = new NotificationTemplate();
		value.setContent("NEW_REPOSITORY Created by USER_NAME");
		value.setNotificationEvent(getNotificationEvent());
		value.setNotificationName("Repository");
		return value;
	}
	
	private List<AccessMappingPrivilegeDto> getPrivelegeDetails() {
		List<AccessMappingPrivilegeDto> value = new ArrayList<>();
		AccessMappingPrivilegeDto userPrivelage = new AccessMappingPrivilegeDto();
		userPrivelage.setPageId(2);
		userPrivelage.setPrivilegeId(2);
		userPrivelage.setPrivilegeName("Submit Repository");
		userPrivelage.setIsEnabled(true);
		value.add(userPrivelage);
		return value;
	} 
	
	private List<UserPrivillageDto> getPrivelegeDetails1() {
		List<UserPrivillageDto> value = new ArrayList<>();
		UserPrivillageDto userPrivelage = new UserPrivillageDto();
		userPrivelage.setPrivillageId(2);
		userPrivelage.setPrivillageName("Approve Repository");
		value.add(userPrivelage);
		return value;
	} 
	
	private List<UserPrivillageDto> getPrivelegeDetailsError() {
		List<UserPrivillageDto> value = new ArrayList<>();
		UserPrivillageDto userPrivelage = new UserPrivillageDto();
		userPrivelage.setPrivillageId(2);
		userPrivelage.setPrivillageName("csdjncwj");
		value.add(userPrivelage);
		return value;
	} 
	private List<FieldOptionLink> getOptionList(){
		List<FieldOptionLink> value = new ArrayList<>();
		value.add(getFieldOptionLinkingDto());
		return value;
	}

	private FieldOptionLink getFieldOptionLinkingDto() {
		FieldOptionLink fieldOptionLinkingDto = new FieldOptionLink();
		fieldOptionLinkingDto.setDropdownOptions("identity123");
		fieldOptionLinkingDto.setIdentity("FieldOption");
		fieldOptionLinkingDto.setIsDltSts(false);
		return fieldOptionLinkingDto;
	}
	
	private NotificationEvent getNotificationEvent() {
		NotificationEvent value = new NotificationEvent();
		value.setEventName("RepositoryCreated");
		value.setEventId(2);
		value.setIsDeleted(Boolean.FALSE);
		return value;
	}
	
	private DataRepository getDataRepositoryHappy() {
		DataRepository dataRepository = new DataRepository();
		dataRepository.setCrtDteTme(LocalDateTime.now());
		dataRepository.setRepoTableName("table");
		dataRepository.setRepoApiName("api");
		dataRepository.setRepositoryName("name");
		dataRepository.setIdentity("repo");
		dataRepository.setRepoStatus(1);
		dataRepository.setRepoVersion(1.0);
		dataRepository.setIdentity("123");
		dataRepository.setFieldCount(10);
		return dataRepository;
	}
	private DataRepository getDataRepositorydetails() {
		DataRepository dataRepository = new DataRepository();
		dataRepository.setCrtDteTme(LocalDateTime.now());
		dataRepository.setRepoTableName("table");
		dataRepository.setRepoApiName("api");
		dataRepository.setRepositoryName("name");
		dataRepository.setIdentity("repo");
		dataRepository.setRepoVersion(1.0);
		dataRepository.setRepoStatus(1);
		return dataRepository;
	}
	
	private RepositoryScheduleDetails getRepositoryScheduleDetails() {
		RepositoryScheduleDetails repositoryScheduleDetails = new RepositoryScheduleDetails();
		repositoryScheduleDetails.setEndDate("12/03/2023");
		repositoryScheduleDetails.setRepeatCount(2);
		repositoryScheduleDetails.setIdentity("123");
		repositoryScheduleDetails.setRepeatOn("FIRST");
		repositoryScheduleDetails.setRepeatOnday("MON");
		repositoryScheduleDetails.setRepeatFormat("WEEK");
		return repositoryScheduleDetails;
	}
	
	private RepositoryScheduleDetailsDto getSchedulerDetailsDayMonthErrorflow() {
		RepositoryScheduleDetailsDto repositoryScheduleDetailsDto = new RepositoryScheduleDetailsDto();
		repositoryScheduleDetailsDto.setEndDate("12.03.2023");
		repositoryScheduleDetailsDto.setRepeatOn("FIRST");
		repositoryScheduleDetailsDto.setRepeatOnDay("MON");
		repositoryScheduleDetailsDto.setRepeatOnMonth("JAN");
		repositoryScheduleDetailsDto.setStartdate("12/02/1221");
		repositoryScheduleDetailsDto.setSelectedDays("MON");
		return repositoryScheduleDetailsDto;
	}
	private RepositoryScheduleDetailsDto getSchedulerDetailsDayError() {
		RepositoryScheduleDetailsDto repositoryScheduleDetailsDto = new RepositoryScheduleDetailsDto();
		repositoryScheduleDetailsDto.setEndDate("12.03.2023");
		repositoryScheduleDetailsDto.setRepeatFormat("DAY");
		repositoryScheduleDetailsDto.setRepeatOn("FIRST");
		repositoryScheduleDetailsDto.setRepeatOnDay("MON");
		repositoryScheduleDetailsDto.setRepeatOnMonth("JAN");
		repositoryScheduleDetailsDto.setSelectedDays("MON");
		return repositoryScheduleDetailsDto;
	}
	private RepositoryScheduleDetailsDto getSchedulerDetailsDayFailure() {
		RepositoryScheduleDetailsDto repositoryScheduleDetailsDto = new RepositoryScheduleDetailsDto();
		repositoryScheduleDetailsDto.setEndDate("12.03.2023");
		repositoryScheduleDetailsDto.setRepeatFormat("MONTH");
		repositoryScheduleDetailsDto.setRepeatOnMonth("JAN");
		repositoryScheduleDetailsDto.setSelectedDays("MON");
		return repositoryScheduleDetailsDto;
	}
	
	private RepositoryScheduleDetailsDto getSchedulerDetailsDayFailures() {
		RepositoryScheduleDetailsDto repositoryScheduleDetailsDto = new RepositoryScheduleDetailsDto();
		repositoryScheduleDetailsDto.setEndDate("12.03.2023");
		repositoryScheduleDetailsDto.setRepeatOnMonth("JAN");
		repositoryScheduleDetailsDto.setSelectedDays("MON");
		return repositoryScheduleDetailsDto;
	}

	private RepositoryScheduleDetailsDto getSchedulerDetailsError() {
		RepositoryScheduleDetailsDto repositoryScheduleDetailsDto = new RepositoryScheduleDetailsDto();
		repositoryScheduleDetailsDto.setEndDate("12.03.2023");
		repositoryScheduleDetailsDto.setRepeatFormat("WEEK");
		repositoryScheduleDetailsDto.setRepeatOn("FIRST");
		repositoryScheduleDetailsDto.setRepeatOnDay("MON");
		repositoryScheduleDetailsDto.setRepeatOnMonth("JAN");
		repositoryScheduleDetailsDto.setSelectedDay(2);
		return repositoryScheduleDetailsDto;
	}
	

	
	private DataRepository getDataRepositoryDetails() {
		DataRepository dataRepository = new DataRepository();
		dataRepository.setCrtDteTme(LocalDateTime.now());
		dataRepository.setRepoTableName("table");
		dataRepository.setRepoApiName("api");
		dataRepository.setRepositoryName("name");
		dataRepository.setIdentity("repo");
		dataRepository.setRepoStatus(1);
		return dataRepository;
	}
	
	private DataRepository getDataRepositoryDetails1() {
		DataRepository dataRepository = new DataRepository();
		dataRepository.setCrtDteTme(LocalDateTime.now());
		dataRepository.setRepoTableName("table");
		dataRepository.setRepoApiName("api");
		dataRepository.setRepositoryName("name");
		dataRepository.setIdentity("repo");
		dataRepository.setRepoStatus(2);
		return dataRepository;
	}
	
	
	
	private FieldRepositoryDto getFieldRepositoryListDto1() {
		FieldRepositoryDto fieldRepositoryDto = new FieldRepositoryDto();
		fieldRepositoryDto.setRepositoryName("RepoName");
		fieldRepositoryDto.setRepositoryId("REPO_1");
		fieldRepositoryDto.setRepositoryIdentity("123");
		fieldRepositoryDto.setRepositoryDesc("Desc");
		fieldRepositoryDto.setRepositoryStatus("Approved");
		fieldRepositoryDto.setIsCloned(true);
		fieldRepositoryDto.setAction("Approve");
		fieldRepositoryDto.setFieldsConfiguratorDto(getListFieldsConfiguratorDto1());
		return fieldRepositoryDto;
	}
	private FieldRepositoryDto getFieldRepositoryListDtoError() {
		FieldRepositoryDto fieldRepositoryDto = new FieldRepositoryDto();
		fieldRepositoryDto.setRepositoryName("RepoName");
		fieldRepositoryDto.setRepositoryId("REPO_1");
		fieldRepositoryDto.setRepositoryIdentity("123");
		fieldRepositoryDto.setRepositoryDesc("Desc");
		fieldRepositoryDto.setRepositoryStatus("Approved");
		fieldRepositoryDto.setIsCloned(true);
		fieldRepositoryDto.setAction("sffd");
		fieldRepositoryDto.setFieldsConfiguratorDto(null);
		return fieldRepositoryDto;
	}
	
	private FieldRepositoryDto getFieldRepositoryListDto2() {
		FieldRepositoryDto fieldRepositoryDto = new FieldRepositoryDto();
		fieldRepositoryDto.setRepositoryName("RepoName");
		fieldRepositoryDto.setRepositoryId("REPO_1");
		fieldRepositoryDto.setRepositoryIdentity("123");
		fieldRepositoryDto.setRepositoryDesc("Desc");
		fieldRepositoryDto.setRepositoryStatus("Approved");
		fieldRepositoryDto.setIsCloned(false);
		fieldRepositoryDto.setAction("sffd");
		fieldRepositoryDto.setFieldsConfiguratorDto(getListFieldsConfiguratorDto3());
		return fieldRepositoryDto;
	}
	


	private List<FieldsConfiguratorDto> getListFieldsConfiguratorDto1() {
		List<FieldsConfiguratorDto> fieldsConfiguratorDtos = new ArrayList<>();
		FieldsConfiguratorDto fieldsConfiguratorDto = new FieldsConfiguratorDto();
		fieldsConfiguratorDto.setDataType("String");
		fieldsConfiguratorDto.setErrorMessage("Error");
		fieldsConfiguratorDto.setFieldName("Fields");
		fieldsConfiguratorDto.setPosistion(1);
		fieldsConfiguratorDto.setFieldIdentity("1111");
		fieldsConfiguratorDto.setIsMandatory(true);
		List<FieldOptionLinkingDto> listOfString = new ArrayList<>();
		FieldOptionLinkingDto value = new FieldOptionLinkingDto();
		value.setFieldOptionIdentity("122");
		value.setFieldOptionName("datalake");
		listOfString.add(value);
		fieldsConfiguratorDto.setListofFieldOptions(listOfString);
		value.setFieldOptionIdentity("dwe");
		value.setFieldOptionName("dataLake");
		listOfString.add(value);
		fieldsConfiguratorDto.setListofFieldOptions(listOfString);
		FieldOptionLinkingDto fieldOptionLinkingDto = new FieldOptionLinkingDto();
		fieldOptionLinkingDto.setFieldOptionName("FieldOption");
		listOfString.add(fieldOptionLinkingDto);
		fieldsConfiguratorDto.setListofFieldOptions(listOfString);
		fieldsConfiguratorDtos.add(fieldsConfiguratorDto);
		return fieldsConfiguratorDtos;
	}
	
	private List<FieldsConfiguratorDto> getListFieldsConfiguratorDto3() {
		List<FieldsConfiguratorDto> fieldsConfiguratorDtos = new ArrayList<>();
		FieldsConfiguratorDto fieldsConfiguratorDto = new FieldsConfiguratorDto();
		fieldsConfiguratorDto.setDataType("String");
		fieldsConfiguratorDto.setErrorMessage("Error");
		fieldsConfiguratorDto.setFieldName("Fields");
		fieldsConfiguratorDto.setPosistion(1);
		fieldsConfiguratorDto.setFieldIdentity("1111");
		fieldsConfiguratorDto.setIsMandatory(true);
		List<FieldOptionLinkingDto> listOfString = new ArrayList<>();
		FieldOptionLinkingDto value = new FieldOptionLinkingDto();
		value.setFieldOptionIdentity("122");
		value.setFieldOptionName("datalake");
		listOfString.add(value);
		fieldsConfiguratorDto.setListofFieldOptions(listOfString);
		value.setFieldOptionIdentity("dwe");
		value.setFieldOptionName("dataLake");
		listOfString.add(value);
		fieldsConfiguratorDto.setListofFieldOptions(listOfString);
		FieldOptionLinkingDto fieldOptionLinkingDto = new FieldOptionLinkingDto();
		fieldOptionLinkingDto.setFieldOptionName("FieldOption");
		listOfString.add(fieldOptionLinkingDto);
		fieldsConfiguratorDto.setListofFieldOptions(listOfString);
		fieldsConfiguratorDtos.add(fieldsConfiguratorDto);
		fieldsConfiguratorDtos.add(fieldsConfiguratorDto);
		return fieldsConfiguratorDtos;
	}
	
	
	
	private CommentsDto getcommentsdto() {
		CommentsDto value = new CommentsDto();
		value.setMessage("datalake");
		value.setRepoIdentity("repo");
		value.setIdentity("123");
		value.setAction("Request to modify");
		return value;
	}
	
	private CommentsDto getcommentsdtoError() {
		CommentsDto value = new CommentsDto();
		value.setMessage("datalake");
		value.setRepoIdentity(null);
		value.setIdentity(null);
		return value;
	}

	private List<FieldsConfiguratorDto> getListFieldsConfiguratorDtoFlfIdenytity() {
		List<FieldsConfiguratorDto> fieldsConfiguratorDtos = new ArrayList<>();
		FieldsConfiguratorDto fieldsConfiguratorDto = new FieldsConfiguratorDto();
		fieldsConfiguratorDto.setDataType("String");
		fieldsConfiguratorDto.setErrorMessage("Error");
		fieldsConfiguratorDto.setFieldName("Fields");
		fieldsConfiguratorDto.setFieldIdentity("123");
		fieldsConfiguratorDto.setPosistion(1);
		fieldsConfiguratorDto.setIsMandatory(true);
		
		List<FieldOptionLinkingDto> listOfString = new ArrayList<>();
		FieldOptionLinkingDto fieldOptionLinkingDto = new FieldOptionLinkingDto();
		fieldOptionLinkingDto.setFieldOptionName("name"); 
		fieldOptionLinkingDto.setFieldOptionIdentity("FieldOption");
		listOfString.add(fieldOptionLinkingDto);
		fieldsConfiguratorDto.setListofFieldOptions(listOfString);
		fieldsConfiguratorDtos.add(fieldsConfiguratorDto);
		return fieldsConfiguratorDtos;
	}
	
	private List<DataRepositoryDto> getRepositoryListDto() {
		List<DataRepositoryDto> value = new ArrayList<>();
		DataRepositoryDto datarepository = new DataRepositoryDto();
		datarepository.setAssociationId(1);
		datarepository.setNumberOfFields(12);
		value.add(datarepository);
		return value; 
	}
	
	private FieldRepositoryDto getFieldRepositoryDtoForUpdate() {
		FieldRepositoryDto fieldRepositoryDto = new FieldRepositoryDto();
		fieldRepositoryDto.setRepositoryName("RepoName");
		fieldRepositoryDto.setRepositoryId("REPO_1");
		fieldRepositoryDto.setRepositoryDesc("Desc");
		fieldRepositoryDto.setRepositoryStatus("Drafted");
		fieldRepositoryDto.setIsCloned(false);
		fieldRepositoryDto.setFieldsConfiguratorDto(getListFieldsConfiguratorDtoFlfIdenytity());
		return fieldRepositoryDto;
	}
	
	private List<FieldsConfiguratorDto> getListFieldsConfiguratorDtoIdentity() {
		List<FieldsConfiguratorDto> fieldsConfiguratorDtos = new ArrayList<>();
		FieldsConfiguratorDto fieldsConfiguratorDto = new FieldsConfiguratorDto();
		fieldsConfiguratorDto.setDataType("String");
		fieldsConfiguratorDto.setErrorMessage("Error");
		fieldsConfiguratorDto.setFieldName("Fields");
		fieldsConfiguratorDto.setFieldIdentity("123");
		fieldsConfiguratorDto.setPosistion(1);
		fieldsConfiguratorDto.setIsMandatory(true);
		
		List<FieldOptionLinkingDto> listOfString = new ArrayList<>();
		FieldOptionLinkingDto fieldOptionLinkingDto = new FieldOptionLinkingDto();
		fieldOptionLinkingDto.setFieldOptionName("12345_name");
		listOfString.add(fieldOptionLinkingDto);
		fieldsConfiguratorDto.setListofFieldOptions(listOfString);
		fieldsConfiguratorDtos.add(fieldsConfiguratorDto);
		return fieldsConfiguratorDtos;
		
	}
	private List<String> getListFieldsConfiguratorDtoIdent() {
		List<String> fieldsConfiguratorDtos = new ArrayList<>();
		fieldsConfiguratorDtos.add("iruejifimeife");
		return fieldsConfiguratorDtos;
	}

		
}

