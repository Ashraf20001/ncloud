package com.ncloud.dl.global.searchcontroller.test;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.ncloud.dl.DataLakeApplication;
import com.ncloud.dl.controller.SearchController;
import com.ncloud.dl.service.impl.repository.search.SearchServiceImpl;
import com.ncloud.dl.transfer.object.dto.DataRepositoryDto;
import com.ncloud.dl.transfer.object.dto.FieldMapperDto;
import com.ncloud.dl.transfer.object.dto.FieldsConfiguratorDto;
import com.ncloud.dl.transfer.object.dto.SearchResponseDto;
import com.ncloud.dl.utils.core.LoggedInUserContextHolder;
@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DataLakeApplication.class)
public class GlobalSearchControllerTest {
	
	@InjectMocks
	private SearchController searchController;

	@Mock
	private LoggedInUserContextHolder loggedInUserContextHolder;
	
	@Mock
	private SearchServiceImpl searchService;
	
	@Test
	public void ApprovedRepositoryName_HappyFlow() {
		try {
			when(searchService.getApprovedRepositoryName(any())).thenReturn(getDataRepositoryDto());
			searchController.getApprovedRepositoryName(any());
		}catch(Exception e) {
			Assertions.fail();
		}
	}
	
	@Test
	public void getRepositoryList_HappyFlow() {
		try {
			when(searchService.commonSearch("new", "Repository",(long) 0,(long) 10, 1, null, null)).thenReturn(getSearchDto());
			searchController.getRepositorySearchList(null, null, null, null, null, null);
		}catch(Exception e) {
			Assertions.fail();
		}
	}
		
	@Test
	public void advanceFilterForRepository_HappyFlow() {
		try {
			when(searchService.getadvanceFilterForRepository(any())).thenReturn(getFieldConfiguration());
			searchController.advanceFilterForRepository(any());
		} catch (Exception e) {
			Assertions.fail();
		}
	}
	
	@Test
	public void getRepositorySearchList_HappyFlow() {
		try {
			when(searchService.getRepositoryFiedsForTableHeader("123")).thenReturn(getfieldMapperDto());
			searchController.getRepositoryFields("123");
		} catch (Exception e) {
			Assertions.fail();
		}
	}
	
	@Test
	public void getTotalRecordsCount_HappyFlow() {
		try {
			when(searchService.getTotalRecordsCount("123", null, null, null)).thenReturn((long)10);
			searchController.getTotalRecordsCount("123","", null, null);
		} catch (Exception e) {
			Assertions.fail();
		}
	}

	@Test
	public void getRepositoryFields_HappyFlow() {
		try {
			when(searchService.getRepositoryFiedsForTableHeader("1233"))
					.thenReturn(getfieldMapperDto());
			searchController.getRepositoryFields("1233");
		} catch (Exception e) {
			e.printStackTrace();
			Assertions.fail();
		}
	}
	
	
	@Test
	public void globalSearch_HappyFlow() {
		try {
			when(searchService.globalSearch(any(), any(), any(),any(), any())).thenReturn(getSearchResponseDto());
			searchController.globalSearch("", (long)0, (long)10, "new");
		} catch (Exception e) {
			e.printStackTrace();
			Assertions.fail();
		}
	}
	
	@Test
	public void AdvancedFilterList_HappyFlow() {
		try {
			when(searchService.getadvanceFilterForRepository(any())).thenReturn(getFilterValueDto());
			searchController.advanceFilterForRepository(any());
		}catch(Exception e) {
			Assertions.fail();
		}
	}
	
	@Test
	public void MailService_HappyFlow() {
		try {
		}catch(Exception e) {
			Assertions.fail();
		}
	}
	
	//*************MOCK DATA****************

	private List<DataRepositoryDto> getDataRepositoryDto() {
		List<DataRepositoryDto> data = new ArrayList<>();
		data.add(dataRepository());
		return data;
	}
	
	private SearchResponseDto getSearchDto() {
		SearchResponseDto searchResponseDto = new SearchResponseDto();
		searchResponseDto.setIndex("1");
		searchResponseDto.setMatchedObject(null);
		return searchResponseDto;
	}
	
	private List<FieldsConfiguratorDto> getFilterValueDto() {
		List<FieldsConfiguratorDto>  fields = new ArrayList<>();
		FieldsConfiguratorDto value = new FieldsConfiguratorDto();
		value.setColumnName("repo_name");
		value.setDataType("string");
		value.setErrorMessage("Invalid Data");
		value.setFieldIdentity("123");
		value.setFieldName("Repository");
		value.setFieldType("Integer");
		value.setIsMandatory(true);
		fields.add(value);
		return fields;
	}
	
	private List<SearchResponseDto> getSearchResponseDto() {
		List<SearchResponseDto> searchlist = new ArrayList<>();
		SearchResponseDto searchresponse = new SearchResponseDto();
		searchresponse.setIndex("1");
		searchresponse.setMatchedObject(null);
		searchlist.add(searchresponse);
		return searchlist;
	}
	
	private HashMap<String, Object> getHashMapDetails() {
		Map<String , Object> val = new HashMap<>();
		val.put("wrong", "12-03-2023");
		val.put("err_flds", "wrong");
		return (HashMap<String, Object>) val;
	}
	
	
	private List<FieldMapperDto> getfieldMapperDto() {
		List<FieldMapperDto> fieldMapperDtos = new ArrayList<>();
		FieldMapperDto val = new FieldMapperDto();
		val.setColumnName("repo");
		val.setDisplayName("Repository");
		fieldMapperDtos.add(val);
		return fieldMapperDtos;
	}
	
	private DataRepositoryDto dataRepository() {
		DataRepositoryDto dataRepositoryDto = new DataRepositoryDto();
		dataRepositoryDto.setIdentity("42432");
		dataRepositoryDto.setRepositoryName("Repository");
		dataRepositoryDto.setId(1);
		return dataRepositoryDto;
	}
	
	private List<FieldsConfiguratorDto> getFieldConfiguration() {
		List<FieldsConfiguratorDto> field = new ArrayList<>();
		field.add(getFieldDetails());
		return field;
	}

	private FieldsConfiguratorDto getFieldDetails() {
		FieldsConfiguratorDto value = new FieldsConfiguratorDto();
		value.setColumnName("Demo");
		value.setDataType("String");
		value.setErrorMessage("Invalid");
		return value;
	}
}
