package com.ncloud.dl.factorytest;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.ncloud.dl.DataLakeApplication;
import com.ncloud.dl.datatype.factory.StringFactoryValidationBuilder;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.test.mockdata.MockData;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DataLakeApplication.class)
public class StringFactoryValidationTest {
	
	@InjectMocks
	private StringFactoryValidationBuilder stringFactoryValidationBuilder;
	
	@Test
	public void singleAddForRepositoryString_ErrorFlow() throws ApplicationException {
		try {
			assertThrows(ApplicationException.class, ()->{
				stringFactoryValidationBuilder.getDataTypeValidationBuilder("ErrorMsg",Map.entry("",""), true,  new HashMap<String,Object>(),MockData.getFieldConfiguration());
			});
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void singleAddForRepositoryString_HappyFlowFlow() throws ApplicationException {
		try {
			stringFactoryValidationBuilder.getDataTypeValidationBuilder("ErrorMsg", MockData.getHashmapEntryValue(), false, new HashMap<String,Object>(), MockData.getFieldConfig());
		}catch (Exception e) {
			e.printStackTrace();
		}
	}


}
