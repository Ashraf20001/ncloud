package com.ncloud.dl.repository.notification.controller.test;


import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.ncloud.dl.DataLakeApplication;
import com.ncloud.dl.controller.RepositoryNotificationController;
import com.ncloud.dl.service.impl.repository.notification.RepositoryNotificationServiceImpl;
import com.ncloud.dl.transfer.object.dto.NotificationDto;
import com.ncloud.dl.transfer.object.dto.UserInfo;
import com.ncloud.dl.utils.core.LoggedInUserContextHolder;
@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DataLakeApplication.class)
public class RepositoryNotificationControllerTest {
	
	@InjectMocks
	private RepositoryNotificationController repositoryNotificationController;
	
	@Mock
	private RepositoryNotificationServiceImpl respoNotificationServiceImpl;
	
	@Mock
	private LoggedInUserContextHolder loggedInUserContextHolderMock;
	
	@Test
	public void getNotificationCount_HappyFlow() {
		try {
			when(respoNotificationServiceImpl.getUnReadNotificationsCount(null)).thenReturn(2L);
			repositoryNotificationController.getUnReadNotificationsCount(null);
		} catch(Exception e) {
			Assertions.fail();
		}
	}
	
	@Test
	public void getNotificationList_HappyFlow() {
		try {
			when(respoNotificationServiceImpl.getUnReadNotifications(true, null)).thenReturn(getNotificationList());
			repositoryNotificationController.getUnReadNotifications("true", null);
		} catch(Exception e) {
			Assertions.fail();
		}
	}
	
	@Test
	public void getUnReadUpdateNotifications_HappyFlow() {
		try {
			when(loggedInUserContextHolderMock.getLoggedInUser()).thenReturn(getUserInfo());
			when(respoNotificationServiceImpl.markAsReadNotification("",getUserInfo())).thenReturn(true);
			repositoryNotificationController.getUnReadUpdateNotifications("123");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getNotificationList_FailureFlow() {
		try {
			when(respoNotificationServiceImpl.getUnReadNotifications(true, null)).thenReturn(getNotificationList());
			repositoryNotificationController.getUnReadNotifications(null, null);
		} catch(Exception e) {
			assertNotNull(e);
		}
	}
	
	@Test
	public void getVo_happyFlow() {
		try {
			repositoryNotificationController.getVo("test");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	//****************************MOCK DATA******************************************
	
	private List<NotificationDto> getNotificationList(){
		List<NotificationDto> notificationDtos = new ArrayList<>();
		NotificationDto notificationDto = new NotificationDto();
		notificationDto.setCreatedDate(LocalDateTime.now());
		notificationDto.setNotificationContent("content");
		notificationDtos.add(notificationDto);
		return notificationDtos;
	}
	
	private UserInfo getUserInfo() {
		UserInfo userInfo = new UserInfo();
		userInfo.setUsername("mockData");
		userInfo.setId(1);
		return userInfo;
	}

}
