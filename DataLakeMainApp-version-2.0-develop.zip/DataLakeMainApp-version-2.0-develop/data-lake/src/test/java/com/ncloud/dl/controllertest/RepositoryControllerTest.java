

package com.ncloud.dl.controllertest;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.ncloud.dl.DataLakeApplication;
import com.ncloud.dl.config.model.FilterOrSortingVo;
import com.ncloud.dl.controller.RepositoryController;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.service.IRepositoryService;
import com.ncloud.dl.transfer.object.dto.CommentsDto;
import com.ncloud.dl.transfer.object.dto.DataRepositoryDto;
import com.ncloud.dl.transfer.object.dto.FieldRepositoryDto;
import com.ncloud.dl.transfer.object.dto.RepositoryScheduleDetailsDto;
import com.ncloud.dl.transfer.object.dto.SchedulerNotificationDto;
import com.ncloud.dl.transfer.object.dto.UserInfo;
import com.ncloud.dl.transfer.object.entity.DataRepository;
import com.ncloud.dl.utils.core.LoggedInUserContextHolder;
@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DataLakeApplication.class)
public class RepositoryControllerTest {

	private static final HttpServletRequest HttpServletRequest = null;

	@InjectMocks
	private RepositoryController repositoryController;

	@Mock
	private IRepositoryService repositoryServiceImpl;

	@Mock
	private LoggedInUserContextHolder loggedInUserContextHolderMock;
	
	
	
	@Test
	public void updateFieldRepositoryStatus_HappyFlow() {
		try {
			when(loggedInUserContextHolderMock.getLoggedInUser()).thenReturn(getUserInfo());
			doNothing().when(repositoryServiceImpl).approveRepository(getFieldRepositoryDto(),getUserInfo(),HttpServletRequest);
			repositoryController.updateFieldRepositoryStatus(getFieldRepositoryDto(),HttpServletRequest);
		} catch (Exception e) {
			Assertions.fail();
		}
	}
	
	
	@Test
	public void saveDataRepostiory_HappyFLow() {
		try {
			when(loggedInUserContextHolderMock.getLoggedInUser()).thenReturn(getUserInfo());
			repositoryController.saveOrUpdateFieldConfigurations(getFieldRepositoryDto(),HttpServletRequest);  
		} catch (Exception e) {
			e.printStackTrace();
			Assertions.fail();
		}
	}
 
	@Test
	public void getDataRepository_HappyFlow() {
		try {
			when(repositoryServiceImpl.getCommentsValues("prabu",HttpServletRequest)).thenReturn(getCommentDto());
			repositoryController.getCommentsDetails("prabu",HttpServletRequest);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void updateRepoStatus_HappyFlow() {
		try {
			when(loggedInUserContextHolderMock.getLoggedInUser()).thenReturn(getUserInfo());
			when(repositoryServiceImpl.updateStatusDataRepository(any(), any(), any(), any())).thenReturn("prabu");
			repositoryController.updateStatusDataRepository("prabu", "Rejected", HttpServletRequest);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	
	@Test 
	public void cloneRepositoryDetails_HappyFlow() {
		try {
			repositoryController.cloneRepositoryDetails(getFieldRepositoryDto(), HttpServletRequest);
		} catch (Exception e) {
			e.printStackTrace();
			Assertions.fail();
		}
	}
	
	@Test
	public void RenameRepository_HappyFlow() {
		try {
	     when(loggedInUserContextHolderMock.getLoggedInUser()).thenReturn(getUserInfo());	
		 when(repositoryServiceImpl.updateRepositoryName(any(),any())).thenReturn("checking");
			repositoryController.renameRepository(getFieldRepoDto());
		} catch (Exception e) {
			Assertions.fail();
		}
	}
		
		
	@Test
	public void cardDisbleUpdate_HappyFlow() {
		try {
			when(loggedInUserContextHolderMock.getLoggedInUser()).thenReturn(getUserInfo());
			when(repositoryServiceImpl.updateCardRepository(any(),any(),any())).thenReturn("prabu");
			repositoryController.updateCardDisable("prabhu", LocalDate.now()); 
		} catch (Exception e) {
			e.printStackTrace();
			Assertions.fail(e.toString());
		} 
	}
	 
	@Test
	public void getRepositoryDetails_HappyFLow() {
		 try{
			 when(loggedInUserContextHolderMock.getLoggedInUser()).thenReturn(getUserInfo());
			 when(repositoryServiceImpl.getRepositoryAndFieldDetails(any())).thenReturn(getFieldRepositoryDto());
		 	repositoryController.getRepositoryDetails("12");
		 } catch (Exception e) {
			 Assertions.fail(e.toString());
		 }
	} 
	
	@Test
	public void getRepositoryCount_HappyFLow() {
		 try{
			 when(loggedInUserContextHolderMock.getLoggedInUser()).thenReturn(getUserInfo());
			 when(repositoryServiceImpl.getRepositoryListCount(any(),any(),any())).thenReturn((long) 1);
		 	repositoryController.getRepositoryListCount(any(),any(),any());
		 } catch (Exception e) {
			 Assertions.fail(e.toString());
		 }
	} 
	
	@Test
	public void getRepositoryList_HappyFLow() {
		 try{
			 when(loggedInUserContextHolderMock.getLoggedInUser()).thenReturn(getUserInfo());
			 when(repositoryServiceImpl.getRepositoryCardList(0,10,getFilterVo(),"12", getUserInfo(), "APPROVER", HttpServletRequest)).thenReturn(getRepositoryListDto());
		 	repositoryController.getRepositoryCardList(0,10,getFilterVo(),"APPROVER","12", HttpServletRequest);
		 } catch (Exception e) {
			 Assertions.fail(e.toString());
		 }
	} 
	
	@Test 
	public void getRepositoryApprovedList_HappyFLow() {
		 try{
			 when(loggedInUserContextHolderMock.getLoggedInUser()).thenReturn(getUserInfo());
			 when(repositoryServiceImpl.getRepositoryCardListforApproved(any(),any(),any(),any(),any(), any())).thenReturn(getRepositoryListDto());
		 	repositoryController.getRepositoryCardListforApproved(0,"APPROVER", 10,"",getFilterVo());
		 } catch (Exception e) {
			 e.printStackTrace();
			 Assertions.fail();
		 }
	} 

	@Test 
	public void updateSchedulerDelete_HappyFLow() {
		try {
			when(repositoryServiceImpl.schedulerDelete(any(),any())).thenReturn("123");
		 	repositoryController.updateSchedulerDelete("123");
		}catch (Exception e) {
			 Assertions.fail(e.toString());
		 }
	}
	

	@Test
	public void updateRepository_HappyFLow() {
		 try{
			 when(loggedInUserContextHolderMock.getLoggedInUser()).thenReturn(getUserInfo());
			 when(repositoryServiceImpl.updateRepositoryDetails(any(),any(),any(HttpServletRequest.class))).thenReturn(true);
		 	repositoryController.updateRepository(getFieldRepositoryDto(),HttpServletRequest);
		 } catch (Exception e) {
			 e.printStackTrace();
			 Assertions.fail(e.toString());
		 }
	} 
	

	@Test
	public void updateSchedulerDetails_HappyFLow() {
		 try{
			 when(loggedInUserContextHolderMock.getLoggedInUser()).thenReturn(getUserInfo());
			 when(repositoryServiceImpl.updateSchedulerDetails(any(),any())).thenReturn("123");
		 	repositoryController.updateSchedulerDetails(getSchedularDetails());
		 } catch (Exception e) {
			 Assertions.fail(e.toString());
		 }
	} 
	
	@Test
	public void saveComments_HappyFLow() {
		 try{
			 when(loggedInUserContextHolderMock.getLoggedInUser()).thenReturn(getUserInfo());
			when(repositoryServiceImpl.saveCommentsForRepository(getcommentsdto(),getUserInfo(),HttpServletRequest)).thenReturn("123");
		 	repositoryController.saveComments(getcommentsdto(),HttpServletRequest);
		 } catch (Exception e) {
			 Assertions.fail(e.toString());
		 }
	} 
	@Test
	public void getScheduler_HappyFLow() {
		 try{
			when(repositoryServiceImpl.getSchedulerDetails(any(), any(), any())).thenReturn(getSchedulertDto());
		 	repositoryController.getSchedulerDetails(any(), any(), any());
		 } catch (Exception e) {
			 Assertions.fail(e.toString());
		 }
	} 
	
	@Test
	public void getSchedulerCount_HappyFLow() {
		 try{
			 when(loggedInUserContextHolderMock.getLoggedInUser()).thenReturn(getUserInfo());
			 when(repositoryServiceImpl.getSchedulerListCount()).thenReturn((long) 1);
		 	repositoryController.getSchedulerListCount();
		 } catch (Exception e) {
			 Assertions.fail(e.toString());
		 }
	} 
	
	@Test
	public void getUserPrivillegeDetails_HappyFlow() throws ApplicationException {
		try {
			when(repositoryServiceImpl.getUserRoleDetails(getUserInfo(), HttpServletRequest)).thenReturn("123");
			repositoryController.getUserPrivillegeDetails(HttpServletRequest);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	

	@Test
	public void getSchedulerDetails_HappyFlow() {
		try {
			when(repositoryServiceImpl.editschedulerDetails("prabu")).thenReturn(getRepositoryScheduleDetailsDto());
			repositoryController.getSchedulerDetails("prabu");
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	public void getRepositoryApprovedListCount_HappyFlow() {
		try {
			when(repositoryServiceImpl.getRepositoryApprovedListCount(getFilterVo(), "", true)).thenReturn((long) 1000);
			repositoryController.getRepositoryApprovedListCount("","APPROVER", getFilterVo());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	public void getRepositoryStatus_HappyFlow() {
		try {
			when(repositoryServiceImpl.getRepositoryStatusByIdentity("123")).thenReturn(getHashMapValue());
			repositoryController.getRepositoryStatus("123");
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	public void getCompanyUploadNameList_happyFlow() {
		List<String> list = new ArrayList<>();
		list.add("test");
		try {
			when(repositoryServiceImpl.getCompanyUploadStatus(5, "test")).thenReturn(list);
			repositoryController.getCompanyUploadNameList(5, "test");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getVo_happyFlow() {
		try {
			repositoryController.getVo("test");
		} catch(Exception e) {
			e.printStackTrace();
			Assertions.fail();
		}
	}
	
	
	
	//*********************************MOCK DATA*******************************************
	
	private RepositoryScheduleDetailsDto getRepositoryScheduleDetailsDto() {
		RepositoryScheduleDetailsDto repositoryScheduleDetailsDto = new 
				RepositoryScheduleDetailsDto();
		repositoryScheduleDetailsDto.setEndDate("2023-09-21");
		repositoryScheduleDetailsDto.setNotificationMessage("checking");
		repositoryScheduleDetailsDto.setRemainderPeriod(1);
		repositoryScheduleDetailsDto.setRepositoryName("vfvrfveb");
		repositoryScheduleDetailsDto.setStartdate("2022-03-11");
		return repositoryScheduleDetailsDto;
	}
	
	private Map<String, Object> getHashMapValue() {
		 Map<String, Object> value = new HashMap<>();
		 value.put("1", "prem");
		return value;
	}
	
	private List<DataRepositoryDto> getRepositoryListDto() {
		List<DataRepositoryDto> value = new ArrayList<>();
		DataRepositoryDto datarepository = new DataRepositoryDto();
		datarepository.setAssociationId(1);
		datarepository.setNumberOfFields(12);
		value.add(datarepository);
		return value;
	}

	private UserInfo getUserInfo() {
		UserInfo userInfo = new UserInfo();
		userInfo.setUsername("mockData");
		userInfo.setId(1);
		return userInfo;
	}
	
	private RepositoryScheduleDetailsDto getSchedularDetails() {
		RepositoryScheduleDetailsDto reDetailsDto = new RepositoryScheduleDetailsDto();
		reDetailsDto.setEndDate("12.03");
		reDetailsDto.setNotificationMessage("Repository");
		reDetailsDto.setRepeatCount(10);
		return reDetailsDto;
	}

	private FieldRepositoryDto getFieldRepositoryDto() {
		FieldRepositoryDto fieldRepositoryDto = new FieldRepositoryDto();
		fieldRepositoryDto.setFieldsConfiguratorDto(null);
		fieldRepositoryDto.setRepositoryDesc("Desc");
		fieldRepositoryDto.setRepositoryStatus("Drafted");
		return fieldRepositoryDto;
	}
	
	private FieldRepositoryDto getFieldRepoDto() {
		FieldRepositoryDto fieldRepositoryDto = new FieldRepositoryDto();
		fieldRepositoryDto.setRepositoryName("checking");
		fieldRepositoryDto.setRepositoryStatus("1");
		return fieldRepositoryDto;
	}
	
	private CommentsDto getcommentsdto() {
		CommentsDto value = new CommentsDto();
		value.setMessage("datalake");
		value.setRepoIdentity("123");
		return value;
	}
	

	private List<CommentsDto> getCommentDto() {
		List<CommentsDto> val = new ArrayList<>();
		CommentsDto commentsDto = new CommentsDto();
		commentsDto.setMessage("sfsdgfg");
		commentsDto.setIdentity("Mani");
		commentsDto.setRepoIdentity("rewt"); 
		val.add(commentsDto);
		return val;
	}

	private List<SchedulerNotificationDto> getSchedulertDto() {
		List<SchedulerNotificationDto> val = new ArrayList<>();
		SchedulerNotificationDto SchedulesDto = new SchedulerNotificationDto();
		SchedulesDto.setMessage("sfsdgfg");
		SchedulesDto.setRemainder(20);
		SchedulesDto.setNotificationName("abcd");
		SchedulesDto.setStatus(true);
		SchedulesDto.setTriggeredStatus("approved");
		val.add(SchedulesDto);
		return val;
	}
	
	private DataRepository getDataRepository() {
		DataRepository dataRepository = new DataRepository();
		dataRepository.setAssociationId(1);
		dataRepository.setRepoVersion(1.1);
		dataRepository.setCrtDteTme(LocalDateTime.now());
		dataRepository.setCrtUsrId(1);
		dataRepository.setEffectiveFrom(LocalDateTime.now());
		dataRepository.setEffectiveTo(LocalDate.now());
		dataRepository.setFieldCount(12);
		dataRepository.setId(1);
		dataRepository.setIdentity("123");
		dataRepository.setIsActive(true);
		dataRepository.setIsDltSts(Boolean.FALSE);
		dataRepository.setMdyDteTme(LocalDateTime.now());
		dataRepository.setMdyUsrId(12);
		dataRepository.setRepoApiName("/user/api");
		dataRepository.setRepoDescription("Repository");
		dataRepository.setRepositoryId("1");
		dataRepository.setRepositoryName("Repository");
		dataRepository.setRepoStatus(1);
		dataRepository.setRepoTableName("Repo_Table");
		return dataRepository;
	}
	
	private List<FilterOrSortingVo> getFilterVo() {
		List<FilterOrSortingVo> filter = new ArrayList<>();
		filter.add(getSingleFilterVo());
		return filter;
	}

	private FilterOrSortingVo getSingleFilterVo() {
		FilterOrSortingVo filter = new FilterOrSortingVo();
		filter.setAscending(false);
		filter.setColumnName("ABC");
		filter.setCondition("Equal");
		filter.setFilterOrSortingType("ASC");
		return filter;
	}

}
