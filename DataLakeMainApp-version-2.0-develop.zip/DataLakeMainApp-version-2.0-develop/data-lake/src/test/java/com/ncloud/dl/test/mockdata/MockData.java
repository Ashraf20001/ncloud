package com.ncloud.dl.test.mockdata;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import com.ncloud.dl.transfer.object.BulkImportTriggerConsumerDto;
import com.ncloud.dl.transfer.object.dto.CustomFilterSortingVo;
import com.ncloud.dl.transfer.object.dto.CustomSortingVo;
import com.ncloud.dl.transfer.object.dto.DataLakeBulkUploadMapDto;
import com.ncloud.dl.transfer.object.dto.FieldMapperDto;
import com.ncloud.dl.transfer.object.dto.FieldOptionLinkingDto;
import com.ncloud.dl.transfer.object.dto.FieldRepositoryDto;
import com.ncloud.dl.transfer.object.dto.FieldsConfiguratorDto;
import com.ncloud.dl.transfer.object.dto.PlatformDetailsDto;
import com.ncloud.dl.transfer.object.dto.RepositoryDto;
import com.ncloud.dl.transfer.object.dto.RepositoryScheduleDetailsDto;
import com.ncloud.dl.transfer.object.dto.SuccessErrorRecordsDto;
import com.ncloud.dl.transfer.object.dto.UserDetailsDto;
import com.ncloud.dl.transfer.object.dto.UserInfo;
import com.ncloud.dl.transfer.object.dto.UserRoleDto;
import com.ncloud.dl.transfer.object.entity.BulkUploadHistory;
import com.ncloud.dl.transfer.object.entity.Comments;
import com.ncloud.dl.transfer.object.entity.DataRepository;
import com.ncloud.dl.transfer.object.entity.ErrorMaintenance;
import com.ncloud.dl.transfer.object.entity.FieldConfiguration;
import com.ncloud.dl.transfer.object.entity.FieldOptionLink;
import com.ncloud.dl.transfer.object.entity.FieldSearchLinking;
import com.ncloud.dl.transfer.object.entity.FileStorage;
import com.ncloud.dl.transfer.object.entity.RepositoryNotification;
import com.ncloud.dl.transfer.object.entity.SchedulerNotification;
import com.ncloud.dl.transfer.object.entity.UserType;

public class MockData {

	public static CustomFilterSortingVo getfilterObject() {
		CustomFilterSortingVo customFilterSortingVo = new CustomFilterSortingVo();
		customFilterSortingVo.setFilterMap(getFilterMap());
		customFilterSortingVo.setSortingMap(getCustomsorting());
		return customFilterSortingVo;
	}

    private static HashMap<String, String> getFilterMap() {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("key","val");
        return hashMap;
    }

    public static List<RepositoryDto> getRepositoryDto() {
		List<RepositoryDto> value = new ArrayList<>();
		value.add(getRepository());
		return value;
	}

	public static RepositoryDto getRepository() {
		RepositoryDto repositoryDto = new RepositoryDto();
		repositoryDto.setFieldName("Repository");
		repositoryDto.setRepoTableName("repo");
		return repositoryDto;
	}
	
	public static RepositoryDto getRepository1() {
		RepositoryDto repositoryDto = new RepositoryDto();
		repositoryDto.setFieldName("Repository");
		repositoryDto.setRepoTableName("repo");
		repositoryDto.setRepositoryName("table");
		return repositoryDto;
	}
	
	public static List<RepositoryDto> getRepositoryDto1(){
		List<RepositoryDto> value = new ArrayList<>();
		value.add(getRepository1());
		return value;
	}
	public static List<DataRepository> getDataRepositoryList() {
	      List<DataRepository> dataRepositories = new ArrayList<>();
	      dataRepositories.add(getRepositoryDetails());
		return dataRepositories;
	}
	
	public static List<DataRepository> getDataRepositoryList1() {
	      List<DataRepository> dataRepositories = new ArrayList<>();
	      dataRepositories.add(getRepositoryDetails1());
		return dataRepositories;
	}
	
	public static DataRepository getDataRepository() {
        DataRepository dataRepository = new DataRepository();
        dataRepository.setCrtDteTme(LocalDateTime.now());
        dataRepository.setRepoTableName("table");
        dataRepository.setRepoApiName("api");
        dataRepository.setRepositoryName("name");
        dataRepository.setIdentity("123");
        dataRepository.setId(123);
        dataRepository.setIsDltSts(false);
        dataRepository.setUploadAccess(1);
        dataRepository.setRepoStatus(1);
        dataRepository.setRepoVersion(1.0);
        dataRepository.setFieldCount(2);
        return dataRepository;
    }

	public static List<CustomSortingVo> getCustomsortingList() {
		List<CustomSortingVo> val = new ArrayList<>();
		val.add(getCustomsorting());
		return val;
	}

	public static CustomSortingVo getCustomsorting() {
		CustomSortingVo customSortingVo = new CustomSortingVo();
		customSortingVo.setRepositoryPrimaryId(getIntegerList());
		customSortingVo.setColumnName("Repo");
		customSortingVo.setIsAsc(false);
		return customSortingVo;
	}

	public static List<Integer> getIntegerList() {
		List<Integer> val = new ArrayList<>();
		val.add(1);
		val.add(2);
		return val;
	}
	public static DataRepository getRepositoryDetails() {
		DataRepository dataRepository = new DataRepository();
		dataRepository.setAssociationId(1);
		dataRepository.setCrtDteTme(LocalDateTime.now());
		dataRepository.setCrtUsrId(1);
		dataRepository.setEffectiveFrom(LocalDateTime.now());
		dataRepository.setEffectiveTo(LocalDate.now());
		dataRepository.setFieldCount(10);
		dataRepository.setId(1);
		dataRepository.setIdentity("1233");
		dataRepository.setIsActive(true);
		dataRepository.setIsDltSts(Boolean.FALSE);
		dataRepository.setMdyDteTme(LocalDateTime.now());
		dataRepository.setMdyUsrId(12);
		dataRepository.setRepoApiName("/api/user");
		dataRepository.setRepoDescription("Repository");
		dataRepository.setRepositoryId("repo1");
		dataRepository.setRepositoryName("Repo");
		dataRepository.setRepoStatus(1);
		dataRepository.setRepoTableName("Repo_table");
		dataRepository.setRepoVersion(1.1);
		return dataRepository;
	}	
	
	public static DataRepository getRepositoryDetails1() {
		DataRepository dataRepository = new DataRepository();
		dataRepository.setAssociationId(1);
		dataRepository.setCrtDteTme(LocalDateTime.now());
		dataRepository.setCrtUsrId(1);
		dataRepository.setEffectiveFrom(LocalDateTime.now());
		dataRepository.setEffectiveTo(LocalDate.now());
		dataRepository.setFieldCount(10);
		dataRepository.setId(1);
		dataRepository.setIdentity("123");
		dataRepository.setIsActive(true);
		dataRepository.setIsDltSts(Boolean.FALSE);
		dataRepository.setMdyDteTme(LocalDateTime.now());
		dataRepository.setMdyUsrId(12);
		dataRepository.setRepoApiName("/api/user");
		dataRepository.setRepoDescription("Repository");
		dataRepository.setRepositoryId("repo1");
		dataRepository.setRepositoryName("RepoName");
		dataRepository.setRepoStatus(1);
		dataRepository.setRepoTableName("reponame_repo_scratch");
		dataRepository.setRepoVersion(1.1);
		return dataRepository;
	}
	
	
	public static FieldRepositoryDto getRepositoryDetailsForFieldRepository() {
		FieldRepositoryDto fieldRepositoryDto = new FieldRepositoryDto();
		fieldRepositoryDto.setRepositoryName("RepoName");
		fieldRepositoryDto.setRepositoryIdentity("prabu");
		fieldRepositoryDto.setRepositoryStatus("1");
		return fieldRepositoryDto;
	}
	
	public static List<Integer> getNumberList() {
		List<Integer> val = new ArrayList<>();
		val.add(2);
		val.add(1);
		return val;
	}

	public static List<Map<String, Object>> getMapList() {
		List<Map<String, Object>> value = new ArrayList();
		value.add(getHashmapValue1());
		value.add(getHashmapValue2());
		return value;
	}
	
	public static HashMap<String, Object> getHashmapValue1() {
		Map<String , Object> val = new HashMap<>();
		val.put("FieldsName", "12-03-2023");
		return (HashMap<String, Object>) val;
	}

	
	public static HashMap<String, Object> getHashmapValue2() {
		Map<String , Object> val = new HashMap<>();
		val.put("FieldsName", "12");
		return (HashMap<String, Object>) val;
	}

	
	public static List<FieldConfiguration> getFieldConfiuration() {
		List<FieldConfiguration> fieldConfigurations = new ArrayList<>();
		fieldConfigurations.add(getFieldValue());
		return fieldConfigurations;
	}

	public static FieldConfiguration getFieldValue() {
		FieldConfiguration fieldsConfiguration = new FieldConfiguration();
		fieldsConfiguration.setFieldName("FieldsName");
		fieldsConfiguration.setColumnName("Repository");
		fieldsConfiguration.setIdentity("123");
		fieldsConfiguration.setDataType(3);
		fieldsConfiguration.setErrMsg("Went wrong");
		fieldsConfiguration.setIsMandatory(true);
		fieldsConfiguration.setFieldType(2);
		fieldsConfiguration.setRepoId(getRepositoryDetails());
		fieldsConfiguration.setIdentity("123");
		fieldsConfiguration.setIsDltSts(Boolean.FALSE);
		return fieldsConfiguration;
	}
	
	public static List<FieldOptionLink> getFieldOptionList() {
		List<FieldOptionLink> fieldOptionLinks = new ArrayList<>();
		fieldOptionLinks.add(getfieldOption());
		return fieldOptionLinks;
	}

	public static FieldOptionLink getfieldOption() {
		FieldOptionLink fieldOptionLink = new FieldOptionLink();
		fieldOptionLink.setDropdownOptions("123");
		fieldOptionLink.setFieldId(getFieldConfiguration());
		fieldOptionLink.setIdentity("123");
		return fieldOptionLink;
	}

	public static List<FieldConfiguration> getFieldConfigurationList() {
		List<FieldConfiguration> fieldConfigurations = new ArrayList<>();
		fieldConfigurations.add(getFieldConfiguration());
		return fieldConfigurations;
	}



    public static List<String> getListofstring() {
        List<String> value  = new ArrayList<>();
        value.add("new");
        return value;
    }

    
    public static DataLakeBulkUploadMapDto getDataLakeBulkUploadMapDto() {
        DataLakeBulkUploadMapDto dataLake = new DataLakeBulkUploadMapDto();
        dataLake.setBulkUploadId(1);
        dataLake.setDuplicateRows(getListOfHashmapValue());
        dataLake.setFilePath("/download");
        dataLake.setRepositoryName("New Repository");
        dataLake.setUniqueRows(getListOfHashmapValue());
        return dataLake;
    }

    public static List<Map<String, Object>> getScratchDetails() {
        List<Map<String, Object>> value = new ArrayList();
        value.add(getHashmapValue1());
        value.add(getHashmapValue());
        return value;
    }



    public static List<ErrorMaintenance> getErrorMaintenance() {
        List<ErrorMaintenance> errorMaintenances= new ArrayList<>();
        ErrorMaintenance val = new ErrorMaintenance();
        val.setErrorMessage("Wrong");
        errorMaintenances.add(val);
        return errorMaintenances;
    }

    public static List<FieldConfiguration> getDataRepositories1(){
        List<FieldConfiguration> dataRepositories = new ArrayList<>();
        dataRepositories.add(getFieldConfigurationError());
        return dataRepositories;
    }

    public static List<FieldConfiguration> getDataRepositories2(){
        List<FieldConfiguration> dataRepositories = new ArrayList<>();
        dataRepositories.add(getFieldConfiguration3());
        return dataRepositories;
    }


    public static FieldConfiguration getFieldConfiguration3() {
        FieldConfiguration fieldsConfiguration = new FieldConfiguration();
        fieldsConfiguration.setFieldName("FieldsName");
        fieldsConfiguration.setIdentity("123");
        fieldsConfiguration.setDataType(4);
        fieldsConfiguration.setErrMsg("Went wrong");
        fieldsConfiguration.setIsMandatory(true);
        fieldsConfiguration.setFieldType(2);
        fieldsConfiguration.setRepoId(getDataRepository());
        fieldsConfiguration.setColumnName("fieldsname");
        return fieldsConfiguration;
    }

    public static List<FieldOptionLink> getFieldOptionLinking3(){
        List<FieldOptionLink> fieldOptionLink = new ArrayList<>();
        FieldOptionLink value = new FieldOptionLink();
        value.setFieldId(getFieldConfiguration());
        value.setDropdownOptions("12");
        value.setCrtUsrId(12);
        fieldOptionLink.add(value);
        return fieldOptionLink;
    }

    public static FieldConfiguration getFieldConfigurationError() {
        FieldConfiguration fieldsConfiguration = new FieldConfiguration();
        fieldsConfiguration.setFieldName("FieldsName");
        fieldsConfiguration.setIdentity("123");
        fieldsConfiguration.setErrMsg("Went wrong");
        fieldsConfiguration.setIsMandatory(true);
        fieldsConfiguration.setFieldType(2);
        fieldsConfiguration.setRepoId(getDataRepository());
        fieldsConfiguration.setIdentity("123");
        return fieldsConfiguration;
    }
    public static List<FieldOptionLink> getFieldOptionLinking(){
        List<FieldOptionLink> fieldOptionLink = new ArrayList<>();
        FieldOptionLink value = new FieldOptionLink();
        value.setFieldId(getFieldConfiguration());
        value.setDropdownOptions("datalake");
        value.setCrtUsrId(12);
        fieldOptionLink.add(value);
        return fieldOptionLink;
    }

    public static List<FieldOptionLink> getFieldOptionLinking1(){
        List<FieldOptionLink> fieldOptionLink = new ArrayList<>();
        FieldOptionLink value = new FieldOptionLink();
        value.setFieldId(getFieldConfiguration());
        value.setDropdownOptions("12-03-2023");
        value.setCrtUsrId(12);
        fieldOptionLink.add(value);
        return fieldOptionLink;
    }


    public static List<HashMap<String, Object>> getListOfHashmapValue(){
        List<HashMap<String, Object>> value = new ArrayList<>();
        value.add(getHashmapValue());
        return  value;
    }

    public static HashMap<String, Object> getHashmapValue() {
        Map<String , Object> val = new HashMap<>();
        val.put("FieldsName", "datalake");
        return (HashMap<String, Object>) val;
    }

    public static FileStorage getFileStorage() {
        FileStorage fileStorage = new FileStorage();
        fileStorage.setCrtDteTme(LocalDateTime.now());
        fileStorage.setIdentity("123");
        fileStorage.setFileName("Repository");
        return fileStorage;
    }

    public static BulkUploadHistory getBulkUploadCounts() {
        BulkUploadHistory bulkUploadHistory = new BulkUploadHistory();
        bulkUploadHistory.setSuccessCount(400);
        bulkUploadHistory.setFailureCount(200);
        bulkUploadHistory.setTotalCount(600);
        return bulkUploadHistory;
    }

    public static SuccessErrorRecordsDto getExcelDto() {
        SuccessErrorRecordsDto val = new SuccessErrorRecordsDto();
        val.setFieldMapperDto(getfieldMapperDto());
        val.setSuccessErrorList(getScratchDetails1());
        return val;
    }

    public static List<Map<String, Object>> getScratchDetails1() {
        List<Map<String, Object>> value = new ArrayList<>();
        value.add(getHashmap());
        return value;
    }

    public static HashMap<String, Object> getHashmap() {
        Map<String , Object> val = new HashMap<>();
        val.put("wrong", "12-03-2023");
        val.put("err_flds", "wrong");
        return (HashMap<String, Object>) val;
    }

    public static List<FieldMapperDto> getfieldMapperDto() {
        List<FieldMapperDto> fieldMapperDtos = new ArrayList<>();
        FieldMapperDto val = new FieldMapperDto();
        val.setColumnName("repo");
        val.setDisplayName("Repository");
        fieldMapperDtos.add(val);
        return fieldMapperDtos;
    }

    public static List<FieldConfiguration> getfieldConfiguration(){
        List<FieldConfiguration> dataRepositories = new ArrayList<>();
        dataRepositories.add(getFieldConfig());
        return dataRepositories;
    }
    
	public static FieldConfiguration getFieldConfiguration() {
		FieldConfiguration fieldConfiguration = new FieldConfiguration();
		fieldConfiguration.setColumnName("DATALAKE");
		fieldConfiguration.setCrtDteTme(LocalDateTime.now());
		fieldConfiguration.setCrtUsrId(1);
		fieldConfiguration.setDataType(3);
		fieldConfiguration.setErrMsg("Something Wrong");
		fieldConfiguration.setFieldName("NAME");
		fieldConfiguration.setFieldOrder(2);
		fieldConfiguration.setIdentity("123");
		fieldConfiguration.setIsDltSts(Boolean.FALSE);
		fieldConfiguration.setIsMandatory(true);
		fieldConfiguration.setSearchType(1);
		fieldConfiguration.setFieldType(1);
        fieldConfiguration.setRepoId(getDataRepository());
		return fieldConfiguration;
	}
    
    public static List<FieldConfiguration> getfieldConfiguration4(){
        List<FieldConfiguration> dataRepositories = new ArrayList<>();
        dataRepositories.add(getFieldConfig2());
        return dataRepositories;
    }


    public static FieldConfiguration getFieldConfig() {
        FieldConfiguration fieldsConfiguration = new FieldConfiguration();
        fieldsConfiguration.setFieldName("FieName");
        fieldsConfiguration.setIdentity("123");
        fieldsConfiguration.setErrMsg("Went wrong");
        fieldsConfiguration.setIsMandatory(true);
        fieldsConfiguration.setFieldType(2);
        fieldsConfiguration.setRepoId(getDataRepository());
        fieldsConfiguration.setColumnName("FieldsName");
        return fieldsConfiguration;
    }
    
	public static  FieldConfiguration getFieldConfiguration2() {
		FieldConfiguration fieldsConfiguration = new FieldConfiguration();
		fieldsConfiguration.setFieldName("FieldsName");
		fieldsConfiguration.setIdentity("123");
		fieldsConfiguration.setDataType(5);
		fieldsConfiguration.setErrMsg("Went wrong");
		fieldsConfiguration.setIsMandatory(true);
		fieldsConfiguration.setFieldType(2);
		fieldsConfiguration.setRepoId(getDataRepository());
		fieldsConfiguration.setColumnName("column2");
		return fieldsConfiguration;
	}

    public static FieldConfiguration getFieldConfig2() {
        FieldConfiguration fieldsConfiguration = new FieldConfiguration();
        fieldsConfiguration.setFieldName("FieldsName");
        fieldsConfiguration.setIdentity("123");
        fieldsConfiguration.setErrMsg("Went wrong");
        fieldsConfiguration.setIsMandatory(true);
        fieldsConfiguration.setFieldType(2);
        fieldsConfiguration.setRepoId(getDataRepository());
        fieldsConfiguration.setColumnName("FieldsName");
        return fieldsConfiguration;
    }

    public static BulkImportTriggerConsumerDto getBulkImportTriggerConsumerDto() {
        BulkImportTriggerConsumerDto bulkImportTriggerConsumerDto = new BulkImportTriggerConsumerDto();
        bulkImportTriggerConsumerDto.setAssociationId(1);
        bulkImportTriggerConsumerDto.setBulkImportIdentity("4323");
        return bulkImportTriggerConsumerDto;
    }

    public static UserInfo getUserInfo() {
        UserInfo userInfo = new UserInfo();
        userInfo.setUsername("mockData");
        userInfo.setId(1);
        userInfo.setAssociationId(1);
        userInfo.setUserTypeId(getUserTypeRole());
        return userInfo;
    }

    public static UserType getUserTypeRole() {
        UserType user = new UserType();
        user.setUserTypeName("ASSOCIATION");
        user.setUserTypeId(1);
        return user;
    }

    public static BulkUploadHistory getBulkUploadHistory(){
        BulkUploadHistory bulkUploadHistory = new BulkUploadHistory();
        bulkUploadHistory.setId(1);
        bulkUploadHistory.setDataRepository(getDataRepository());
        bulkUploadHistory.setIsDltSts(false);
        bulkUploadHistory.setFileStorage(getFileStorage());
        bulkUploadHistory.setIdentity("identity");
        return bulkUploadHistory;
    }

    public static List<CustomSortingVo> getCustomSortingVos(){
        List<CustomSortingVo> cuList = new ArrayList<>();
        CustomSortingVo customSortingVo = new CustomSortingVo();
        customSortingVo.setColumnName("id");
        customSortingVo.setIsAsc(false);
        cuList.add(customSortingVo);
        return cuList;
    }

    public static List<BulkUploadHistory> getBulkUploadDetails() {
        List<BulkUploadHistory> bulkUploadHistories = new ArrayList<>();
        bulkUploadHistories.add(getBulkUploadHistorys());
        return bulkUploadHistories;
    }

    public static BulkUploadHistory getBulkUploadHistorys() {
        BulkUploadHistory bulkUploadHistory = new BulkUploadHistory();
        bulkUploadHistory.setCrtDteTme(LocalDateTime.now());
        bulkUploadHistory.setFailureCount(100);
        bulkUploadHistory.setSuccessCount(120);
        bulkUploadHistory.setTotalCount(220);
        bulkUploadHistory.setFileStorage(getfilestorage());
        bulkUploadHistory.setDataRepository(getDataRepository());
        bulkUploadHistory.setIdentity("12333");
        bulkUploadHistory.setId(12);
        return bulkUploadHistory;
    }

    public static FileStorage getfilestorage() {
        FileStorage file = new FileStorage();
        file.setFileName("BulkUpload");
        return file;
    }

    public static MultipartFile getMockXSSFWorkBookMultipartFile() {
        MockMultipartFile resource = null;
        String filename = "sample_bulk_upload.xlsx";
        try {
            XSSFWorkbook workbook = new XSSFWorkbook();
            XSSFSheet sheet = workbook.createSheet("Sheet1");

            XSSFRow headerRow = sheet.createRow(0);
            XSSFCell tempObjectCell = headerRow.createCell(0);
            tempObjectCell.setCellValue("temp object");

            XSSFCell columnNameCell = headerRow.createCell(1);
            columnNameCell.setCellValue("column name");

             XSSFRow dataRow = sheet.createRow(1);
             XSSFCell tempObjectDataCell = dataRow.createCell(0);
             tempObjectDataCell.setCellValue("Data for temp object");
             XSSFCell columnNameDataCell = dataRow.createCell(1);
             columnNameDataCell.setCellValue("Data for column name");

            // convert to multipartfile
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);

            byte[] content = outputStream.toByteArray();
            resource =  new MockMultipartFile(filename, filename, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", content);

            workbook.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return resource;
    }

    public static MockMultipartFile getMockAWSMultipartFile() {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "TMB Bank.xls",
                MediaType.TEXT_PLAIN_VALUE,
                "Hello, World!".getBytes()
        );
        return file;
    }


    public static UserInfo getUserInfoMockDto() {
        UserInfo userInfo = new UserInfo();
        userInfo.setAllocationUserType(1);
        userInfo.setAssociationId(1);
        userInfo.setCompanyId(1);
        userInfo.setCompanyName("Vendor");
        userInfo.setEmail("dpcbtmail@gmail.com");
        userInfo.setFirstTimeLogin(false);
        userInfo.setId(1);
        userInfo.setIdentity("sdfghjkhujnuchijnskcsc");
        userInfo.setPlatformDetailsDto(getPlatformDetailsDtoMock());
        userInfo.setPlatformIdentity("erdtfcvygbhjnk45667tygh");
        userInfo.setRoles(getUserRoleDtoMock());
        userInfo.setUsername("Master");
        userInfo.setUserTypeId(null);
        return userInfo;
    }

    public static List<UserRoleDto> getUserRoleDtoMock() {
        UserRoleDto userRoleDto = new UserRoleDto();
        ArrayList<UserRoleDto> userRoleDtoList = new ArrayList<>();

        userRoleDto.setAllocationUserType(1);
        userRoleDto.setRoleId(1);
        userRoleDto.setRoleName("Master");
        userRoleDtoList.add(userRoleDto);
        return userRoleDtoList;
    }

    public static PlatformDetailsDto getPlatformDetailsDtoMock() {
        PlatformDetailsDto platformDetailsDto = new PlatformDetailsDto();
        platformDetailsDto.setPlatformId(3);
        platformDetailsDto.setPlatformIdentity("1234567uhgvfr4rf");
        platformDetailsDto.setPlatformName("Data Repository");
        return platformDetailsDto;
    }

    public static RepositoryNotification getRepositoryNotificationsMock() {
        RepositoryNotification notification = new RepositoryNotification();
        notification.setCrtDteTme(LocalDateTime.now());
        notification.setIsDltSts(false);
        notification.setNotificationMessage("content");
        notification.setRepositoryId(getDataRepositoryMock());
        return notification;
    }
    public static List<RepositoryNotification> getRepositoryNotificationsListMock(){
        List<RepositoryNotification> repositoryNotifications = new ArrayList<>();
        RepositoryNotification notification = new RepositoryNotification();
        notification.setCrtDteTme(LocalDateTime.now());
        notification.setIsDltSts(false);
        notification.setNotificationMessage("content");
        notification.setId(1);
        notification.setIsRead(false);
        notification.setCrtUsrId(12);
        notification.setIdentity("cascqwdsx2ewqsdazx");
        notification.setIsRepoCmts(false);
        notification.setLastActed(1);
        notification.setNotificationMessage("Repossitory As Submitted");
        notification.setReplaceTemplateData("submitted");
        notification.setRepositoryId(getDataRepositoryMock());
        repositoryNotifications.add(notification);
        return repositoryNotifications;
    }

    public static DataRepository getDataRepositoryMock() {
        DataRepository dataRepository = new DataRepository();
        dataRepository.setCrtDteTme(LocalDateTime.now());
        dataRepository.setRepoTableName("table");
        dataRepository.setRepoApiName("api");
        dataRepository.setRepositoryName("name");
        dataRepository.setIdentity("repo");
        return dataRepository;
    }
    
    public static DataRepository getDataRepository2() {
    	DataRepository dataRepository = new DataRepository();
        dataRepository.setCrtDteTme(LocalDateTime.now());
        dataRepository.setRepoTableName("repo");
        dataRepository.setRepoApiName("api");
        dataRepository.setRepositoryName("name");
        dataRepository.setIdentity("repo");
        dataRepository.setRepoStatus(3);;
        return dataRepository;
    }

    public static SchedulerNotification getSchedulerNotificationMock() {
        SchedulerNotification schedulerNotification = new SchedulerNotification();
        schedulerNotification.setId(1);
        schedulerNotification.setIdentity("dtfgyh21wsax");
        schedulerNotification.setMessage("Schdular Triggered");
        schedulerNotification.setNotificationName("Approved");
        schedulerNotification.setRemainder(12);
        schedulerNotification.setRepositoryId(getDataRepository2());
        schedulerNotification.setStatus(false);
        schedulerNotification.setTriggeredStatus("Status");
        return schedulerNotification;
    }
    
	public static List<FieldsConfiguratorDto> getListFieldsConfiguratorDto() {
		List<FieldsConfiguratorDto> fieldsConfiguratorDtos = new ArrayList<>();
		FieldsConfiguratorDto fieldsConfiguratorDto = new FieldsConfiguratorDto();
		fieldsConfiguratorDto.setDataType("String");
		fieldsConfiguratorDto.setErrorMessage("Error");
		fieldsConfiguratorDto.setFieldName("Fields");
		fieldsConfiguratorDto.setPosistion(2);
		fieldsConfiguratorDto.setIsMandatory(true);
		List<FieldOptionLinkingDto> listOfString = new ArrayList<>();
		FieldOptionLinkingDto value = new FieldOptionLinkingDto();
		FieldOptionLinkingDto value2 = new FieldOptionLinkingDto();
		value.setFieldOptionIdentity("122");
		value.setFieldOptionName("dataocean");
		listOfString.add(value);
		value2.setFieldOptionIdentity("dwe");
		value2.setFieldOptionName("dataLake1");
		listOfString.add(value2);
		fieldsConfiguratorDto.setListofFieldOptions(listOfString);
		fieldsConfiguratorDto.setDeletedOptions(getDeletedList());
		fieldsConfiguratorDtos.add(fieldsConfiguratorDto);
		return fieldsConfiguratorDtos;
	}
	
	
	public static List<FieldsConfiguratorDto> getListFieldsConfiguratorDto2() {
		List<FieldsConfiguratorDto> fieldsConfiguratorDtos = new ArrayList<>();
		FieldsConfiguratorDto fieldsConfiguratorDto = new FieldsConfiguratorDto();
		fieldsConfiguratorDto.setDataType("String");
		fieldsConfiguratorDto.setErrorMessage("Error");
		fieldsConfiguratorDto.setFieldName("Fields");
		fieldsConfiguratorDto.setPosistion(2);
		fieldsConfiguratorDto.setIsMandatory(true);
		List<FieldOptionLinkingDto> listOfString = new ArrayList<>();
		FieldOptionLinkingDto value = new FieldOptionLinkingDto();
		FieldOptionLinkingDto value2 = new FieldOptionLinkingDto();
		value.setFieldOptionName("dataocean");
		listOfString.add(value);
		value2.setFieldOptionName("dataLake1");
		listOfString.add(value2);
		fieldsConfiguratorDto.setListofFieldOptions(listOfString);
		fieldsConfiguratorDto.setDeletedOptions(getDeletedList());
		fieldsConfiguratorDtos.add(fieldsConfiguratorDto);
		return fieldsConfiguratorDtos;
	}
	
	
	
	
	public static FieldRepositoryDto getFieldRepositoryListDtos() {
		FieldRepositoryDto fieldRepositoryDto = new FieldRepositoryDto();
		fieldRepositoryDto.setRepositoryName("RepoName");
		fieldRepositoryDto.setRepositoryId("REPO_1");
		fieldRepositoryDto.setRepositoryIdentity("123");
		fieldRepositoryDto.setRepositoryDesc("Desc");
		fieldRepositoryDto.setRepositoryStatus("Approved");
		fieldRepositoryDto.setIsCloned(false);
		fieldRepositoryDto.setAction("Approve");
		fieldRepositoryDto.setFieldsConfiguratorDto(getListFieldsConfiguratorDto());
		return fieldRepositoryDto;
	}
	
	public static List<String> getDeletedList() {
		List<String> val = new ArrayList<>();
		val.add("new");
		val.add("java");
		val.add("Error");
		return val;
	}
	
	public static FieldRepositoryDto getFieldRepositoryDto() {
		FieldRepositoryDto fieldRepositoryDto = new FieldRepositoryDto();
		fieldRepositoryDto.setRepositoryName("RepoName");
		fieldRepositoryDto.setRepositoryId("REPO_1");
		fieldRepositoryDto.setRepositoryDesc("Desc");
		fieldRepositoryDto.setRepositoryStatus("Drafted");
		fieldRepositoryDto.setIsCloned(true);
		fieldRepositoryDto.setRepositoryIdentity("123");
		fieldRepositoryDto.setFieldsConfiguratorDto(getListFieldsConfiguratorDto());
		return fieldRepositoryDto;
	}
	
	public static FieldRepositoryDto getFieldRepository() {
		FieldRepositoryDto fieldRepositoryDto = new FieldRepositoryDto();
		fieldRepositoryDto.setRepositoryName("RepoName");
		fieldRepositoryDto.setRepositoryId("REPO_1");
		fieldRepositoryDto.setRepositoryDesc("Desc");
		fieldRepositoryDto.setRepositoryStatus("Approved");
		fieldRepositoryDto.setIsCloned(true);
		fieldRepositoryDto.setFieldsConfiguratorDto(getListFieldsConfiguratorDto());
		fieldRepositoryDto.setDeletedFields(getDeletedList());
		return fieldRepositoryDto;
	}
	
	
	
	public static FieldRepositoryDto getFieldRepository1() {
		FieldRepositoryDto fieldRepositoryDto = new FieldRepositoryDto();
		fieldRepositoryDto.setRepositoryName("RepoName");
		fieldRepositoryDto.setRepositoryId("REPO_1");
		fieldRepositoryDto.setRepositoryDesc("Desc");
		fieldRepositoryDto.setRepositoryStatus("Approved");
		fieldRepositoryDto.setIsCloned(true);
		fieldRepositoryDto.setUploadAccess("Association");
		fieldRepositoryDto.setRepositoryIdentity("123");
		fieldRepositoryDto.setFieldsConfiguratorDto(getListFieldsConfiguratorDto());
		fieldRepositoryDto.setDeletedFields(getDeletedList());
		return fieldRepositoryDto;
	}
	
	public static FieldRepositoryDto getFieldRepositoryListDto() {
		FieldRepositoryDto fieldRepositoryDto = new FieldRepositoryDto();
		fieldRepositoryDto.setRepositoryName("RepoName");
		fieldRepositoryDto.setRepositoryId("REPO_1");
		fieldRepositoryDto.setRepositoryIdentity("123");
		fieldRepositoryDto.setRepositoryDesc("Desc");
		fieldRepositoryDto.setRepositoryStatus("Approved");
		fieldRepositoryDto.setIsCloned(true);
		fieldRepositoryDto.setUploadAccess("Association");
		fieldRepositoryDto.setAction("Approve");
		fieldRepositoryDto.setDeletedFields(getDeletedList());
		fieldRepositoryDto.setFieldsConfiguratorDto(getListFieldsConfiguratorDto2());
		return fieldRepositoryDto;
	}
	
	public static RepositoryScheduleDetailsDto getSchedulerDetailsDayMonth() {
		RepositoryScheduleDetailsDto repositoryScheduleDetailsDto = new RepositoryScheduleDetailsDto();
		repositoryScheduleDetailsDto.setEndDate("12.03.2023");
		repositoryScheduleDetailsDto.setRepeatFormat("MONTH");
		repositoryScheduleDetailsDto.setRepeatOn("FIRST");
		repositoryScheduleDetailsDto.setRepeatOnDay("MON");
		repositoryScheduleDetailsDto.setRepeatOnMonth("JAN");
		repositoryScheduleDetailsDto.setSelectedDay(2);
		repositoryScheduleDetailsDto.setStartdate("12/02/1221");
		repositoryScheduleDetailsDto.setSelectedDays("MON");
		repositoryScheduleDetailsDto.setRemainderPeriod(1);
		return repositoryScheduleDetailsDto;
	}
	
	public static RepositoryScheduleDetailsDto getSchedulerDetailsYear() {
		RepositoryScheduleDetailsDto repositoryScheduleDetailsDto = new RepositoryScheduleDetailsDto();
		repositoryScheduleDetailsDto.setEndDate("12.03.2023");
		repositoryScheduleDetailsDto.setRepeatFormat("YEAR");
		repositoryScheduleDetailsDto.setRepeatOn("FIRST");
		repositoryScheduleDetailsDto.setRepeatOnDay("MON");
		repositoryScheduleDetailsDto.setRepeatOnMonth("JAN");
		repositoryScheduleDetailsDto.setSelectedDay(2);
		repositoryScheduleDetailsDto.setStartdate("12/02/1221");
		repositoryScheduleDetailsDto.setSelectedDays("MON");
		repositoryScheduleDetailsDto.setSelectedOnMonth("JAN");
		repositoryScheduleDetailsDto.setRemainderPeriod(1);
		return repositoryScheduleDetailsDto;
	}
	
	public static RepositoryScheduleDetailsDto getSchedulerDetails() {
		RepositoryScheduleDetailsDto repositoryScheduleDetailsDto = new RepositoryScheduleDetailsDto();
		repositoryScheduleDetailsDto.setEndDate("12.03.2023");
		repositoryScheduleDetailsDto.setRepeatFormat("WEEK");
		repositoryScheduleDetailsDto.setRepeatOn("FIRST");
		repositoryScheduleDetailsDto.setRepeatOnDay("MON");
		repositoryScheduleDetailsDto.setRepeatOnMonth("JAN");
		repositoryScheduleDetailsDto.setSelectedDay(2);
		repositoryScheduleDetailsDto.setStartdate("12/02/1221");
		repositoryScheduleDetailsDto.setSelectedDays("MON");
		repositoryScheduleDetailsDto.setRemainderPeriod(1);
		return repositoryScheduleDetailsDto;
	}
	
	public static RepositoryScheduleDetailsDto getSchedulerDetailsYearError() {
		RepositoryScheduleDetailsDto repositoryScheduleDetailsDto = new RepositoryScheduleDetailsDto();
		repositoryScheduleDetailsDto.setEndDate("12.03.2023");
		repositoryScheduleDetailsDto.setRepeatFormat("YEAR");
		repositoryScheduleDetailsDto.setRepeatOn("FIRST");
		repositoryScheduleDetailsDto.setRepeatOnDay("MON");
		repositoryScheduleDetailsDto.setRepeatOnMonth("JAN");
		repositoryScheduleDetailsDto.setStartdate("12/02/1221");
		repositoryScheduleDetailsDto.setRemainderPeriod(1);
		return repositoryScheduleDetailsDto;
	}
	
	public static RepositoryScheduleDetailsDto getSchedulerDetailsDayMonthError() {
		RepositoryScheduleDetailsDto repositoryScheduleDetailsDto = new RepositoryScheduleDetailsDto();
		repositoryScheduleDetailsDto.setEndDate("12.03.2023");
		repositoryScheduleDetailsDto.setRepeatFormat("MONTH");
		repositoryScheduleDetailsDto.setRepeatOn("FIRST");
		repositoryScheduleDetailsDto.setRepeatOnDay("MON");
		repositoryScheduleDetailsDto.setRepeatOnMonth("JAN");
		repositoryScheduleDetailsDto.setStartdate("12/02/1221");
		repositoryScheduleDetailsDto.setSelectedDays("MON");
		repositoryScheduleDetailsDto.setRemainderPeriod(1);
		return repositoryScheduleDetailsDto;
	}
	
	public static RepositoryScheduleDetailsDto getSchedulerDetailsDay() {
		RepositoryScheduleDetailsDto repositoryScheduleDetailsDto = new RepositoryScheduleDetailsDto();
		repositoryScheduleDetailsDto.setEndDate("12.03.2023");
		repositoryScheduleDetailsDto.setRepeatFormat("DAY");
		repositoryScheduleDetailsDto.setRepeatOn("FIRST");
		repositoryScheduleDetailsDto.setRepeatOnDay("MON");
		repositoryScheduleDetailsDto.setRepeatOnMonth("JAN");
		repositoryScheduleDetailsDto.setSelectedDay(2);
		repositoryScheduleDetailsDto.setStartdate("12/02/1221");
		repositoryScheduleDetailsDto.setSelectedDays("MON");
		repositoryScheduleDetailsDto.setRemainderPeriod(1);
		return repositoryScheduleDetailsDto;
	}
	
	public static RepositoryNotification getRepositoryNotification() {
		RepositoryNotification notification = new RepositoryNotification();
		notification.setNotificationMessage("test");
		notification.setReplaceTemplateData("test");
		notification.setCrtDteTme(LocalDateTime.now());
		notification.setIsDltSts(Boolean.FALSE);
		notification.setIsRead(Boolean.FALSE);
		notification.setLastActed(5);
		notification.setCrtUsrId(5);
		notification.setIsRepoCmts( true);
		notification.setToNotify(5);
		notification.setRepositoryId(getDataRepository());
		notification.setMdyUsrId(5);
		notification.setMdyDteTme(LocalDateTime.now());
		
		return notification;
	}
	
	public static List<SchedulerNotification> getSchedulertDto() {
		List<SchedulerNotification> val = new ArrayList<>();
		SchedulerNotification SchedulesDto = new SchedulerNotification();
		SchedulesDto.setMessage("sfsdgfg");
		SchedulesDto.setRemainder(20);
		SchedulesDto.setNotificationName("abcd");
		SchedulesDto.setStatus(true);
		SchedulesDto.setTriggeredStatus("approved");
		SchedulesDto.setRepositoryId(getDataRepository());
		val.add(SchedulesDto);
		return val;
	}
	
	 public static SchedulerNotification getSchedulerNotification() {
		SchedulerNotification schedulerNotification = new SchedulerNotification();
		schedulerNotification.setMessage("Repository");
		schedulerNotification.setNotificationName("New Repository Created");
		schedulerNotification.setRemainder(1);
		schedulerNotification.setRepositoryId(getDataRepository());
		schedulerNotification.setStatus(true);
		schedulerNotification.setTriggeredStatus("success");
		schedulerNotification.setIdentity("123");
		return schedulerNotification;
	}
	
	 public static SchedulerNotification getSchedulerNotification1() {
			SchedulerNotification schedulerNotification = new SchedulerNotification();
			schedulerNotification.setIdentity("prabu");
			schedulerNotification.setId(1);
			schedulerNotification.setMessage("sdfsdwe");
			schedulerNotification.setNotificationName("notification");
			schedulerNotification.setIsDltSts(Boolean.FALSE);
			schedulerNotification.setTriggeredStatus("fsdcew");
			schedulerNotification.setRemainder(1);
			schedulerNotification.setRepositoryId(getDataRepository());
			return schedulerNotification;
		}
	 
	 public static List<FieldConfiguration> getDataRepositories(){
			List<FieldConfiguration> dataRepositories = new ArrayList<>();
			dataRepositories.add(getFieldConfiguration());
			dataRepositories.add(getFieldConfiguration1());
			dataRepositories.add(getFieldConfiguration2());
			dataRepositories.add(getFieldConfiguration3());
			return dataRepositories;
		}
	 
		public static FieldConfiguration getFieldConfiguration1() {
			FieldConfiguration fieldsConfiguration = new FieldConfiguration();
			fieldsConfiguration.setFieldName("FieldsName");
			fieldsConfiguration.setIdentity("123");
			fieldsConfiguration.setDataType(2);
			fieldsConfiguration.setErrMsg("Went wrong");
			fieldsConfiguration.setIsMandatory(true);
			fieldsConfiguration.setFieldType(2);
			fieldsConfiguration.setRepoId(getDataRepository());
			fieldsConfiguration.setColumnName("column1");
			return fieldsConfiguration;
		}
		
		public static List<Comments> getcommentsList(){
			List<Comments> val = new ArrayList<>();
			Comments value = new Comments();
			value.setComments("afewaf");
			value.setCrtDteTme(LocalDateTime.now());	
			value.setCrtUsrId(123);
			value.setId(1);	
			value.setRepositoryId(getDataRepository());
			value.setIsDltSts(false);
			value.setMdyDteTme(LocalDateTime.now());
			value.setMdyUsrId(123);
			val.add(value);
			return val;
	}
		
		public static List<Comments> getcommentsList1(){
			List<Comments> val = new ArrayList<>();
			Comments value = new Comments();
			value.setComments("afewaf");
			value.setCrtDteTme(LocalDateTime.now());	
			value.setId(1);	
			value.setCrtUsrId(123);
			value.setIsDltSts(false);
			value.setRepositoryId(getDataRepository1());
			value.setMdyDteTme(LocalDateTime.now());
			value.setMdyUsrId(123);
			val.add(value);
			return val;
		}
		
		public static FieldConfiguration getFieldConfigurationData() {
			FieldConfiguration fieldsConfiguration = new FieldConfiguration();
			fieldsConfiguration.setFieldName("FieldsName");
			fieldsConfiguration.setIdentity("123");
			fieldsConfiguration.setDataType(3);
			fieldsConfiguration.setErrMsg("Went wrong");
			fieldsConfiguration.setIsMandatory(true);
			fieldsConfiguration.setFieldType(2);
			fieldsConfiguration.setRepoId(getDataRepository());
			fieldsConfiguration.setIdentity("123");
			return fieldsConfiguration;
		}
		
		public static FieldOptionLink getFieldOptionLinkingDetails() {
			FieldOptionLink value = new FieldOptionLink();
			value.setFieldId(getFieldConfigurationData());
			value.setDropdownOptions("datalake");
			value.setCrtUsrId(12);
			return value;
		}
		
		public static DataRepository getDataRepository1() {
			DataRepository dataRepository = new DataRepository();
			dataRepository.setCrtDteTme(LocalDateTime.now());
			dataRepository.setRepoTableName("table");
			dataRepository.setRepoApiName("api");
			dataRepository.setIdentity("repo");
			dataRepository.setRepoVersion(1.1);
			return dataRepository;
		}
		
		public static FieldSearchLinking getFieldSearchLinking() {
			FieldSearchLinking fieldSearchLinking = new FieldSearchLinking();
			fieldSearchLinking.setFieldId(getFieldConfiguration());
			fieldSearchLinking.setCrtDteTme(LocalDateTime.now());
			return fieldSearchLinking;
		}
		
		public static RepositoryScheduleDetailsDto getSchedulerDetailsYearFailure() {
			RepositoryScheduleDetailsDto repositoryScheduleDetailsDto = new RepositoryScheduleDetailsDto();
			repositoryScheduleDetailsDto.setEndDate("12.03.2023");
			repositoryScheduleDetailsDto.setRepeatFormat("YEAR");
			repositoryScheduleDetailsDto.setSelectedDay(2);
			repositoryScheduleDetailsDto.setSelectedDays("MON");
			repositoryScheduleDetailsDto.setSelectedOnMonth("JAN");
			repositoryScheduleDetailsDto.setRemainderPeriod(1);
			return repositoryScheduleDetailsDto;
		}
		
		public static String getHTMLString() {
			StringBuffer stringBuffer = new StringBuffer();
			String htmlString="<html><body><p style='text-align: center; margin-bottom : 39.2px'><strong>REPOSITORY NAME : </strong>Repo</p><table style='border-collapse: collapse; margin: 0px auto;text-align: center;'><tr><td style='padding: 8px; font-style: sans-serif; color:#688F99; background-color:#e7edee; text-align:center; font-family: Inter, sans-serif !important; border: 1px solid #000; min-width: 200px;'>FieldsName</td><td style='padding: 8px; font-style:  sans-serif; font-weight: 300;  text-align:center; font-family: Inter, sans-serif !important; border: 1px solid #000;min-width: 200px;'>null</td></tr></table></body></html>";
			stringBuffer.append(htmlString);
			return stringBuffer.toString();
		}
		
		public static Entry<String, Object> getHashmapEntryValue() {
			Entry<String, Object> val = Map.entry("columName", "123");
			return val;
		}
		
		public static Entry<String, Object> getHashmapEntryValueForDate() {
			Entry<String, Object> val = Map.entry("columName", "03-03-1924");
			return val;
		}

		public static HttpHeaders getvalue() {
			HttpHeaders val = new HttpHeaders();
			val.set("Repository", "name");
			return val;
		}
		
		public static List<UserDetailsDto> getUserDetailsDto() {
			List<UserDetailsDto> user = new ArrayList<>();
			user.add(getUserDetails());
			return user;
		}
		
		
		public static UserDetailsDto getUserDetails() {
			UserDetailsDto value = new UserDetailsDto();
			value.setId(1);
			value.setUsername("Repository");
			return value;
		}
		
		
}
