package com.ncloud.dl.search.controller.test;

import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.ncloud.dl.DataLakeApplication;
import com.ncloud.dl.controller.SearchController;
import com.ncloud.dl.service.ISearchService;
import com.ncloud.dl.transfer.object.dto.CustomFilterSortingVo;
import com.ncloud.dl.transfer.object.dto.CustomSortingVo;
import com.ncloud.dl.transfer.object.dto.DataRepositoryDto;
import com.ncloud.dl.transfer.object.dto.FieldMapperDto;
import com.ncloud.dl.transfer.object.dto.FieldOptionLinkingDto;
import com.ncloud.dl.transfer.object.dto.FieldsConfiguratorDto;
import com.ncloud.dl.transfer.object.dto.SearchResponseDto;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DataLakeApplication.class)
public class SearchControllerTest{
	
	
	@InjectMocks
	private SearchController searchController;
	
	@Mock
	private ISearchService iSearchServiceMock;
	
	@Test
	public void advanceFilterForRepository_happyFlow() {
		try {
			when(iSearchServiceMock.getadvanceFilterForRepository("test")).thenReturn(getConfiguratorDtos());
			searchController.advanceFilterForRepository("test");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getApprovedRepositoryName_happyFlow() {
		List<Integer> ids = new ArrayList<>();
		ids.add(4);
		ids.add(60);
		try {
			when(iSearchServiceMock.getApprovedRepositoryName(ids)).thenReturn(getDataRepositoryDtos());
			searchController.getApprovedRepositoryName(ids);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void mailService_happyFlow() {
		try {
			when(iSearchServiceMock.sendMail("test", "test", "test")).thenReturn("test");
			searchController.mailService("test", "test", "test");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getRepositoryFields_happyFlow() {
		try {
			when(iSearchServiceMock.getRepositoryFiedsForTableHeader("test")).thenReturn(getFieldMapperDtos());
			searchController.getRepositoryFields("test");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getRepositorySearchList_happyFlow() {
		try {
			when(iSearchServiceMock.commonSearch("test", "test", 0L, 10L, 5,getCustomFilterSortingVo() , Boolean.FALSE)).thenReturn(getSearchResponseDto());
			searchController.getRepositorySearchList("test", 0L, 10L, 5, "test", getCustomFilterSortingVo());
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getTotalRecordsCount_happyFlow() {
		try {
			when(iSearchServiceMock.getTotalRecordsCount("test", "test", 5, getCustomFilterSortingVo())).thenReturn(5L);
			searchController.getTotalRecordsCount("test", "test", 5, getCustomFilterSortingVo());
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void globalSearch_happyFlow() {
		try {
			when(iSearchServiceMock.globalSearch("test", 0L, 10L, "test", Boolean.FALSE)).thenReturn(getSearchResponseDtos());
			searchController.globalSearch("test", 0L, 10L, "test");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getVo_happyFlow() {
		try {
			searchController.getVo("test");
		} catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	
	private CustomFilterSortingVo getCustomFilterSortingVo() {
		CustomFilterSortingVo data = new CustomFilterSortingVo();
		HashMap<String, String> map = new HashMap<String,String>();
		data.setFilterMap(map);
		data.setSortingMap(getCustomsorting());
		
		return data;
	}
	
	
	private CustomSortingVo getCustomsorting() {
		CustomSortingVo customSortingVo = new CustomSortingVo();
		customSortingVo.setRepositoryPrimaryId(getIntegerList());
		customSortingVo.setColumnName("Repo");
		customSortingVo.setIsAsc(false);
		return customSortingVo;
	}
	
	private List<Integer> getIntegerList() {
		List<Integer> val = new ArrayList<>();
		val.add(1);
		val.add(2);
		return val;
	}
	
	
	private List<FieldMapperDto> getFieldMapperDtos(){
		List<FieldMapperDto> datas = new ArrayList<>();
		datas.add(getFieldMapperDto());
		return datas;
	}
	
	private FieldMapperDto getFieldMapperDto() {
		FieldMapperDto data = new FieldMapperDto();
		data.setColumnName("test");
		data.setDisplayName("test");
		return data;
	}
	
	private SearchResponseDto getSearchResponseDto() {
		SearchResponseDto data = new SearchResponseDto();
		data.setIndex("test");
		data.setMatchedObject(new Object());
		return data;
	}
	
	private List<SearchResponseDto> getSearchResponseDtos() {
		List<SearchResponseDto> datas = new ArrayList<>();
		datas.add(getSearchResponseDto());
		return datas;
	}
	
	
	
	
	
	
	
	private List<DataRepositoryDto> getDataRepositoryDtos(){
		List<DataRepositoryDto> datas = new ArrayList<>();
		datas.add(getDataRepositoryDto());
		return datas;
	}
	
	private DataRepositoryDto getDataRepositoryDto() {
		DataRepositoryDto data = new DataRepositoryDto();
		data.setAssociationId(5);
		data.setEffectiveFrom(LocalDateTime.now());
		data.setEffectiveTo(LocalDate.now());
		data.setId(5);
		data.setIdentity("asdfghjkl");
		data.setIsActive(Boolean.TRUE);
		data.setNumberOfFields(5);
		data.setRepositoryApiName("test");
		data.setRepositoryDescription("test");
		data.setRepositoryId("test");
		data.setRepositoryName("test");
		data.setRepositoryStatus("test");
		data.setRepositoryTableName("test");
		data.setRepositoryVersion(4D);
		data.setUploadAccess(5);
		return data;
	}
	
	
	
	
	private List<FieldsConfiguratorDto> getConfiguratorDtos(){
		List<FieldsConfiguratorDto> datas = new ArrayList<>();
		datas.add(getFieldsConfiguratorDto());
		return datas;
	}
	
	private FieldsConfiguratorDto getFieldsConfiguratorDto() {
		List<String> arrayLists = new ArrayList<>();
		arrayLists.add("test");
		FieldsConfiguratorDto data = new FieldsConfiguratorDto();
		data.setColumnName("test");
		data.setDataType("test");
		data.setDeletedOptions(arrayLists);
		data.setErrorMessage("test");
		data.setFieldIdentity("test");
		data.setFieldName("test");
		data.setFieldType("test");
		data.setIsMandatory(Boolean.TRUE);
		data.setListofFieldOptions(getFieldOptionLinkingDtos());
		data.setPosistion(5);
		data.setSearchType("test");
		return data;
	}
	
	private List<FieldOptionLinkingDto> getFieldOptionLinkingDtos() {
		List<FieldOptionLinkingDto> datas = new ArrayList<>();
		datas.add(getFieldOptionLinkingDto());
		return datas;
	}
	
	private FieldOptionLinkingDto getFieldOptionLinkingDto() {
		FieldOptionLinkingDto data = new FieldOptionLinkingDto();
		data.setFieldOptionIdentity("test");
		data.setFieldOptionName("test");
		return data;
	}
}
