package com.ncloud.dl.schedulernotification.controller.test;

import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.ncloud.dl.DataLakeApplication;
import com.ncloud.dl.controller.SchedulerNotificationController;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.service.ISchedulerNotificationService;
import com.ncloud.dl.transfer.object.dto.RepositoryScheduleDto;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DataLakeApplication.class)
public class SchedulerNotificationControllerTest{

	@InjectMocks
	private SchedulerNotificationController schedulerNotificationController;
	
	@Mock
	private ISchedulerNotificationService schedulerNotificationServiceMock;
	
	
	@Test
	public void getRepositoryScheduleDetails_happyFlow() {
		try {
			when(schedulerNotificationServiceMock.getRepositoryScheduleDetailsByRepositoryIdentity("test")).thenReturn(getRepositoryScheduleDto());
			schedulerNotificationController.getRepositoryScheduleDetails("test");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getVo_happyFlow() {
		try {
			schedulerNotificationController.getVo("test");
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
	}

	private RepositoryScheduleDto getRepositoryScheduleDto() {
		RepositoryScheduleDto data = new RepositoryScheduleDto();
		data.setNotificationMessage("test");
		data.setRepositoryName("test");
		return data;
	}
}
