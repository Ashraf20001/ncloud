package com.ncloud.dl.schedulernotification.serviceImpl.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.ncloud.dl.DataLakeApplication;
import com.ncloud.dl.dao.schedulernotification.ISchedulerNotificationDao;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.exception.core.codes.ErrorCodes;
import com.ncloud.dl.service.impl.schedulernotification.SchedulerNotificationServiceImpl;
import com.ncloud.dl.test.mockdata.MockData;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DataLakeApplication.class)
public class SchedulerNotificationServiceImplTest{

	@InjectMocks
	private SchedulerNotificationServiceImpl schedulerNotificationServiceImplMock;
	
	@Mock
	private ISchedulerNotificationDao schedulerNotificationDaoMock;
	
	
	@Test
	public void getRepositoryScheduleDetailsByRepositoryIdentity_HappyFlow() {
		String repositoryIdentity = "wdsaxasc21wqsd3edwsx1312";
		try {
			when(schedulerNotificationDaoMock.getSchedulerNotificationbyRepositoryIdentityDetails(repositoryIdentity)).thenReturn(MockData.getSchedulerNotificationMock());
			schedulerNotificationServiceImplMock.getRepositoryScheduleDetailsByRepositoryIdentity(repositoryIdentity);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getRepositoryScheduleDetailsByRepositoryIdentity_ErrorFlow() {
		try {
			ApplicationException ap = new ApplicationException(ErrorCodes.INVALID_REPOSITORY_IDENTITY);
			ApplicationException exception = assertThrows(ApplicationException.class, () -> {
				schedulerNotificationServiceImplMock.getRepositoryScheduleDetailsByRepositoryIdentity(null);
            });
            assertEquals(ap.toString(),exception.toString());
		} catch(Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	
}
