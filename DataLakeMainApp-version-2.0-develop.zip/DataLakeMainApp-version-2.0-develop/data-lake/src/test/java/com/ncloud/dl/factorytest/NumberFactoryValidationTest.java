package com.ncloud.dl.factorytest;

import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.ncloud.dl.DataLakeApplication;
import com.ncloud.dl.datatype.factory.NumberFactoryValidationBuilder;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.test.mockdata.MockData;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DataLakeApplication.class)
public class NumberFactoryValidationTest {
	
	@InjectMocks
	private NumberFactoryValidationBuilder numberFactoryBuilder;
	
	@Test
	public void singleAddForRepositoryString_ErrorFlow1() throws ApplicationException {
		try {
			assertThrows(ApplicationException.class, ()->{
				numberFactoryBuilder.getDataTypeValidationBuilder("ErrorMsg", Map.entry("", ""), true, new HashMap<String,Object>(), MockData.getFieldValue());
			});
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void singleAddForRepositoryString_ErrorFlow2() throws ApplicationException {
		try {
			assertThrows(ApplicationException.class, ()->{
				numberFactoryBuilder.getDataTypeValidationBuilder("ErrorMsg", Map.entry("", ""), false, new HashMap<String,Object>(), MockData.getFieldValue());
			});
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void singleAddForRepositoryString_HappyFlowFlow() throws ApplicationException {
		try {
			numberFactoryBuilder.getDataTypeValidationBuilder("ErrorMsg", MockData.getHashmapEntryValue(), false, new HashMap<String,Object>(), MockData.getFieldValue());
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
