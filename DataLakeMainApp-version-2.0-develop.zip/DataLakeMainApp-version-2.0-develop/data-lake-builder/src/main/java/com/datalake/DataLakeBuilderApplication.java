package com.ncloud.dl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataLakeBuilderApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataLakeBuilderApplication.class, args);
	}

}
	