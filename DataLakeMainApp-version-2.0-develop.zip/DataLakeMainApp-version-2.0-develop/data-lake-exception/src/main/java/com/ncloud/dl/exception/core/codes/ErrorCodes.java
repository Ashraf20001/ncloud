/*
 * @author codeboard
 */
package com.ncloud.dl.exception.core.codes;

/**
 * The Class ErrorCodes.
 */
public class ErrorCodes {

	/** The Constant INVALID_COLUMN_NAME. */
	public static final ErrorId INVALID_COLUMN_NAME = new ErrorId("E0003", "Invalid column name to filter");
	
	/** The Constant INVALID_METHOD_NAME. */
	public static final ErrorId INVALID_METHOD_NAME = new ErrorId("E0004", "Invalid Method name");
	
	/** The Constant BAD_CREDINTIAL. */
	public static final ErrorId BAD_CREDINTIAL = new ErrorId("E0011", "Invalid Username & Password");
	
	/** The Constant INTERNAL_ERROR. */
	public static final ErrorId INTERNAL_ERROR = new ErrorId("E0000", "Something went wrong. Please try again");
	
	/** The Constant INVALID_IDENTITY. */
	public static final ErrorId INVALID_IDENTITY = new ErrorId("E5019", "Invalid identity");
	
	/** The Constant INVALID_ID. */
	public static final ErrorId INVALID_ID = new ErrorId("E7132", "Invalid Id");
	
	/** The Constant INVALID_USER. */
	public static final ErrorId INVALID_USER = new ErrorId("E5067", "User Not Found");

	/**
	 * DATA TYPE VALIDATION
	 */
	public static final ErrorId MANDATORY_FIELDS = new ErrorId("E7136", "Mandatory Fields Are Yet To Fill");
	
	/** The Constant ERR_DATE_TYPE. */
	public static final ErrorId ERR_DATE_TYPE = new ErrorId("E7133", "Invalid Date");
	
	/** The Constant NUMBER_FIELD_INVALID. */
	public static final ErrorId NUMBER_FIELD_INVALID = new ErrorId("E7128", "Invalid Number Type");

	/**
	 * BULK UPLOAD VALIDATION
	 */
	public static final ErrorId INVALID_BULK_UPLOAD_ID = new ErrorId("E7134", "Invalid Bulk Upload Id");
	
	/** The Constant INVALID_EXCEL_DATA. */
	public static final ErrorId INVALID_EXCEL_DATA = new ErrorId("E7138", "File should not be empty");

	/**
	 * MANAGE REPOSITORY VALIDATION
	 */
    public static final ErrorId REPOSITORY_VALIDATION= new ErrorId("E7140", "The repository name already exists.");
	
	/** The Constant REPOSITORY_ID_VALIDATION. */
	public static final ErrorId REPOSITORY_ID_VALIDATION= new ErrorId("E7135", "Please enter a unique Repository ID.");
	
	/** The Constant INVALID_UPLOAD_ACESSS. */
	public static final ErrorId INVALID_UPLOAD_ACESSS = new ErrorId("E7141", "Invalid Upload Access");
	
	/** The Constant INVALID_REPOSITORY. */
	public static final ErrorId INVALID_REPOSITORY = new ErrorId("E7142", "Invalid Repository");
	
	/** The Constant INVALID_UPLOAD_ACCESS_FOR. */
	public static final ErrorId INVALID_UPLOAD_ACCESS_FOR = new ErrorId("E7148", "Access denied. You do not have permission to upload files.");
	
	/** The Constant INVALID_STATUS. */
	public static final ErrorId INVALID_STATUS = new ErrorId("E7139", "Invalid Repository Status");
	
	/** The Constant INVALID_REPOSITORY_IDENTITY. */
	public static final ErrorId INVALID_REPOSITORY_IDENTITY = new ErrorId("E7144", "Invalid Repository Identity");
	
	/** The Constant FIELD_VALIDATION. */
	public static final ErrorId FIELD_VALIDATION = new ErrorId("E7145", "Please Add Fields To Save Repository");
	
	/** The Constant INVALID_DROPDOWN. */
	public static final ErrorId INVALID_DROPDOWN = new ErrorId("E7157", "Invalid Dropdown Options");
	
	/** The Constant INVALID_SEARCH. */
	public static final ErrorId INVALID_SEARCH = new ErrorId("E7147", "Invalid Search Query");
	
	/** The Constant INVALID_FILE_FIELDS. */
	public static final ErrorId INVALID_FILE_FIELDS = new ErrorId("E7180", "File Template is incorrect");
	
	/** The Constant ACCESS_DENIED. */
	public static final ErrorId ACCESS_DENIED = new ErrorId("E7152", "Access Denied For The Requested Action");
	
	/** The Constant INVALID_EMAIL_ID. */
	public static final ErrorId INVALID_EMAIL_ID = new ErrorId("E7153", "Invalid Email ID");
	
	/** The Constant INVALID_SCHEDULER_DATA. */
	public static final ErrorId INVALID_SCHEDULER_DATA = new ErrorId("E7154", "Invalid Data To Schedule Notification");
	
	/** The Constant INVALID_DATA. */
	public static final ErrorId INVALID_DATA = new ErrorId("E7161", "Invalid Data");
	
	/** The Constant MANDATORY_FIELD. */
	public static final ErrorId MANDATORY_FIELD = new ErrorId("E7156", "Mandatory Field Yet to Fill in ");
	
	/** The Constant FIELD_DATA_TYPE. */
	public static final ErrorId FIELD_DATA_TYPE = new ErrorId("E7158", "Invalid Number Format in ");
	
	/** The Constant INVALID_DATE_FORMAT. */
	public static final ErrorId INVALID_DATE_FORMAT = new ErrorId("E7159", "Invalid Date Format in ");
	
	/** The Constant DUPLICATE_RECORD. */
	public static final ErrorId DUPLICATE_RECORD = new ErrorId("E7160", "Duplicate Record");
	
	/** The Constant INVALID_SCHEDULE. */
	public static final ErrorId INVALID_SCHEDULE = new ErrorId("E0001", "Based on configured schedule, event will never trigger");
	
	/** The Constant DUPLICATE_DROPDOWN. */
	public static final ErrorId DUPLICATE_DROPDOWN = new ErrorId("E1112", "Dropdown value must be unique OPTIONVALUE Please add a different value.");
    
    /** The Constant INVALID_REMAINDER_PERIOD. */
    public static final ErrorId INVALID_REMAINDER_PERIOD = new ErrorId("E7162", "Please set value from 1");
    
    /** The Constant INVALID_RECOVERY_MDM. */
    public static final ErrorId INVALID_RECOVERY_MDM = new ErrorId("E7163", "MDM data not found for Recovery platform");

	/**
	 * Instantiates a new error codes.
	 */
	private ErrorCodes() {
	}

}
