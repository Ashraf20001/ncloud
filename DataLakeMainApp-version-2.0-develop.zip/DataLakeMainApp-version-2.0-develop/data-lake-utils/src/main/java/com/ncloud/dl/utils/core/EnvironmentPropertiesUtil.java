package com.ncloud.dl.utils.core;

import org.springframework.context.annotation.Configuration;

import com.ncloud.dl.constants.serverproperties.PropertyValueProvider;

import lombok.RequiredArgsConstructor;


/**
 * The Class EnvironmentPropertiesUtil.
 */
@Configuration
@RequiredArgsConstructor
public class EnvironmentPropertiesUtil {
		
	
	/** The property value provider. */
	private final PropertyValueProvider propertyValueProvider;
	
		
	/**
	 * Gets the time zone.
	 *
	 * @return the time zone
	 */
	public String getTimeZone() {
		return propertyValueProvider.getTimeZone();
	}
	
	/**
	 * Gets the date format.
	 *
	 * @return the date format
	 */
	public String getDateFormat() {
		return propertyValueProvider.getDateFormat();
	}
	
	/**
	 * Gets the currency format.
	 *
	 * @return the currency format
	 */
	public String getCurrencyFormat() {
		return propertyValueProvider.getCurrencyFormat();
	}
	
	/**
	 * Gets the country code.
	 *
	 * @return the country code
	 */
	public String getCountryCode() {
		return propertyValueProvider.getCountryCode();
	}

}