package com.ncloud.dl.utils;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.ncloud.dl.*")
public class DataLakeUtilsApplication {

	public static void main(String[] args) {
		
	}

}
