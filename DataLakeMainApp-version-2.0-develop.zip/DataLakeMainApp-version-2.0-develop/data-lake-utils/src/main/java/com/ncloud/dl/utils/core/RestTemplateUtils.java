package com.ncloud.dl.utils.core;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import com.ncloud.dl.constants.core.ApplicationConstants;

/**
 * The Class RestTemplateUtils.
 */
@Component
public class RestTemplateUtils {

	/**
	 * @return HttpHeaders
	 */
	public HttpHeaders getPOSTHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON + ";charset=UTF-8");
		headers.setAccept(List.of(MediaType.APPLICATION_JSON));
		return headers;
	}

	/**
	 * @return HttpHeaders
	 */
	public HttpHeaders getGETHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON + ";charset=UTF-8");
		headers.setAccept(List.of(MediaType.APPLICATION_JSON));
		return headers;
	}

	/**
	 * @param request
	 * @return
	 */
	public HttpHeaders configureRestTemplate(HttpServletRequest request) {
		HttpHeaders httpHeaders = null;
		String authorizationHeader = request.getHeader(ApplicationConstants.AUTHORIZATION);
		String authToken = authorizationHeader.replace(ApplicationConstants.BEARER, ApplicationConstants.EMPTY_STRING)
				.trim();
		if(HttpMethod.GET.toString().equals(request.getMethod())) {
			httpHeaders = getGETHeaders();
		}else {
			httpHeaders = getPOSTHeaders();
		}
		httpHeaders.setBearerAuth(authToken);
		return httpHeaders;
	}
}
