package com.ncloud.dl.utils.core;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ncloud.dl.utils.core.ApplicationFormatUtils;

import lombok.RequiredArgsConstructor;

/**
 * The Class ApplicationFormatUtils.
 */
@Service
@RequiredArgsConstructor
public class ApplicationFormatUtils {
    
    /** The Constant logger. */
    private static final Logger logger = LoggerFactory.getLogger(ApplicationFormatUtils.class);

	/** The environmental properties. */
	private final EnvironmentPropertiesUtil environmentalProperties;
	
    /**
     * Convert date into output format.
     *
     * @param dateString the date string
     * @return the string
     */
    public String convertDateIntoOutputFormat(String dateString){

        DateFormat sdf = new SimpleDateFormat(environmentalProperties.getDateFormat());
        Date date = null;
        try {
            date = sdf.parse(dateString);
        } catch (ParseException e) {
            logger.error(String.valueOf(e)); 
             e.printStackTrace();      
        }
        return new SimpleDateFormat(environmentalProperties.getDateFormat()).format(date);
    }
    
    

    /**
     * Convert country code with format.
     *
     * @param amount the amount
     * @return the string
     */
    public String convertCountryCodeWithFormat(Double amount){
        DecimalFormat formatter = new DecimalFormat(environmentalProperties.getCurrencyFormat());
        return environmentalProperties.getCountryCode()+ " " + formatter.format(amount);
    }
    
    /**
     * Convertvalue with format.
     *
     * @param amount the amount
     * @return the string
     */
    public String convertvalueWithFormat(Double amount){
        DecimalFormat formatter = new DecimalFormat(environmentalProperties.getCurrencyFormat());
        return  formatter.format(amount);
    }
}
