package com.ncloud.dl.aop.interceptor;

import java.time.LocalDateTime;

import com.ncloud.dl.constants.core.ApplicationConstants;
import com.ncloud.dl.exception.core.ApplicationException;
import com.ncloud.dl.transfer.object.core.ApplicationResponse;
import com.ncloud.dl.transfer.object.entity.DlAuditEntity;
import com.ncloud.dl.utils.core.ApplicationUtils;
import com.ncloud.dl.utils.core.LoggedInUserContextHolder;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.ContentCachingRequestWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;

/**
 * The Class GeneralAuditInterceptorAop.
 */
@Aspect
@Component
@RequiredArgsConstructor
public class GeneralAuditInterceptorAop {

    /** The Constant LOGGER. */
    private static final Logger LOGGER = LoggerFactory.getLogger(GeneralAuditInterceptorAop.class);

    /**
     * LoggedInUserContextHolder
     */
    private final LoggedInUserContextHolder loggedInUserContextHolder;

    /**
     * kafka
     */
    private final KafkaTemplate<String, String> kafkaTemplate;

    /**
     * ObjectMapper
     */
    private final ObjectMapper objectMapper;

    /**
     * Audit.
     *
     * @param joinPoint the join point
     * @return the object
     * @throws Throwable the throwable
     */
    @Around("com.ncloud.dl.aop.interceptor.CommonAopAspects.auditAnnotation()")
    public Object audit(ProceedingJoinPoint joinPoint) throws Throwable {
        Integer userId= ApplicationUtils.isValidateObject(loggedInUserContextHolder.getLoggedInUser())? loggedInUserContextHolder.getLoggedInUser().getId() : null;
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        ContentCachingRequestWrapper wrapper = new ContentCachingRequestWrapper(attributes.getRequest());
        String requestURI = wrapper.getRequestURI();
        Object result = null;
        if(ApplicationUtils.isValidId(userId)) {
        	try {
    			result=joinPoint.proceed();
    			auditDataThroughKafka(joinPoint,result,requestURI,userId);
    		}catch(Exception e) {
    			result=e;
    			auditDataThroughKafka(joinPoint,result,requestURI,userId);
    			throw e;
    		}
        }else {
        	result=joinPoint.proceed();
        }
        return result;
    }

    /**
     * Audit data through kafka.
     *
     * @param joinPoint the join point
     * @param result the result
     * @param requestURI the request URI
     * @param userId the user id
     * @throws JsonProcessingException the json processing exception
     */
    private void auditDataThroughKafka(ProceedingJoinPoint joinPoint,Object result, String requestURI,
                                       Integer userId) throws JsonProcessingException {
        DlAuditEntity auditEntity=null;
        if(ApplicationUtils.isValidObject(result)) {
        	if(result instanceof ApplicationResponse) {
                ApplicationResponse obj=(ApplicationResponse)result;
                LOGGER.info("======> AOP Method {} executed and returned {} ",joinPoint.getSignature(),obj.getContent().toString());
                auditEntity=setAuditEntityData(obj.getContent(), requestURI, userId);
            }
            else if (result instanceof ApplicationException) {
                ApplicationException obj=(ApplicationException)result;
                LOGGER.info("======> AOP Method {} executed and returned {} ",joinPoint.getSignature(),obj.getLocalizedMessage());
                auditEntity=setAuditEntityData(obj.getLocalizedMessage(), requestURI,userId);
            }
            else if(result instanceof Exception) {
                Exception obj=(Exception) result;
                LOGGER.info("======> AOP Method {} executed and returned {} ",joinPoint.getSignature(),obj.getLocalizedMessage());
                auditEntity=setAuditEntityData(obj.getLocalizedMessage(), requestURI,userId);
            }
            else {
                LOGGER.info("======> AOP Method {} executed and returned {} ",joinPoint.getSignature(),result.toString());
                auditEntity=setAuditEntityData(result.toString(), requestURI, userId);
            }
            String auditedValueString = objectMapper.writeValueAsString(auditEntity);
            kafkaTemplate.send(ApplicationConstants.KAFKA_TOPIC, auditedValueString);
        }
    }

    /**
     * Sets the audit entity data.
     *
     * @param result the result
     * @param requestURI the request URI
     * @param userId the user id
     * @return the dl audit entity
     */
    private DlAuditEntity setAuditEntityData(Object result, String requestURI,
                                             Integer userId) {
        return new DlAuditEntity()
                .setAuditDate(LocalDateTime.now())
                .setRequestUrl(requestURI)
                .setResponse(result.toString())
                .setUserId(userId.toString());
    }
}
