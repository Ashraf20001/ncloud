package com.ncloud.dl.aop.dao;

import com.ncloud.dl.transfer.object.entity.DlAuditEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

/**
 * The Interface AuditMongoRepository.
 */
@Repository
public interface AuditMongoRepository extends MongoRepository<DlAuditEntity,String>{
}

