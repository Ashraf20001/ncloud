package com.ncloud.dl.aop;

import org.springframework.boot.autoconfigure.SpringBootApplication;


/**
 * The Class DataLakeAopApplication.
 */
@SpringBootApplication
public class DataLakeAopApplication {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {

	}
	

}
