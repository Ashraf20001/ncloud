package com.ncloud.dl.aop.consumer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ncloud.dl.aop.dao.AuditMongoRepository;
import com.ncloud.dl.constants.core.ApplicationConstants;
import com.ncloud.dl.transfer.object.entity.DlAuditEntity;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

/**
 * The Class AuditConsumer.
 */
@Component
@RequiredArgsConstructor
public class AuditConsumer {

    /** The object mapper. */
    private final ObjectMapper objectMapper;

    /** The mongo repository. */
    private final AuditMongoRepository mongoRepository;

    /** The Constant LOGGER. */
    private static final Logger LOGGER = LoggerFactory.getLogger(AuditConsumer.class);

    /**
     * Gets the kafka audit details.
     *
     * @param obj the obj
     * @param acknowledgment the acknowledgment
     * @throws JsonMappingException the json mapping exception
     * @throws JsonProcessingException the json processing exception
     */
    @KafkaListener(topics = ApplicationConstants.KAFKA_TOPIC)
    public void getKafkaAuditDetails(String obj, Acknowledgment acknowledgment) throws JsonMappingException, JsonProcessingException {
        LOGGER.info("====> Drop of audit consumer received");
        acknowledgment.acknowledge();
        try {
            DlAuditEntity auditData = objectMapper.readValue(obj, DlAuditEntity.class);
            mongoRepository.save(auditData);
        } catch (Exception e) {
            LOGGER.error(e.getLocalizedMessage());
        }
    }
}