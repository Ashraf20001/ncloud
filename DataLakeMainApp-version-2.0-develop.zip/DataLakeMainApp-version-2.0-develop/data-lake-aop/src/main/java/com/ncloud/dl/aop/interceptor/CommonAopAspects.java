package com.ncloud.dl.aop.interceptor;

import org.aspectj.lang.annotation.Pointcut;

/**
 * The Class CommonAopAspects.
 */
public class CommonAopAspects {
	
	/**
	 * Service log.
	 */
	@Pointcut("(execution(* com.ncloud.dl.*.*.*(..)) && !(within(com.ncloud.dl..*dao*..*) || within(com.ncloud.dl..*daoImpl*..*)))")
	public void serviceLog() {}

	/**
	 * Audit annotation.
	 */
	@Pointcut("@within(com.ncloud.dl.aop.annotation.Auditable)")
	public void auditAnnotation() {}

}
