package com.digitalpaper.daoImp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.digitalpaper.config.common.base.dao.BaseDao;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.ReportsDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.PreviewReportDto;
import com.digitalpaper.transfer.object.dto.purchaseOrderStatusCountDto;
import com.digitalpaper.transfer.object.entity.Customer;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.entity.PurchaseOrderEntity;
import com.digitalpaper.transfer.object.entity.ReportColumnMapping;
import com.digitalpaper.transfer.object.entity.Reports;
import com.digitalpaper.transfer.object.enums.PaperStatusEnum;
import com.digitalpaper.transfer.object.enums.PaymentStatusEnum;
import com.digitalpaper.utils.core.ApplicationUtils;

/**
 * The Class ReportsDaoImpl.
 */
@Repository
public class ReportsDaoImpl extends BaseDao implements ReportsDao {

	/**
	 * Gets the report all data.
	 *
	 * @param userId the user id
	 * @return the report all data
	 * @throws ApplicationException the application exception
	 */
	@Override
	public List<Reports> getReportAllData(Integer userId) throws ApplicationException {

		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Reports> criteria = builder.createQuery(Reports.class);
		Root<Reports> root = criteria.from(Reports.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.CREATED_BY), userId)));
		criteria.orderBy(builder.desc(root.get(TableConstants.MODIFIED_DATE)));
		return (List<Reports>) getResultList(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {

	}

	/**
	 * Gets the mapping column.
	 *
	 * @param reportsId the reports id
	 * @return the mapping column
	 * @throws ApplicationException the application exception
	 */
	@Override
	public List<ReportColumnMapping> getMappingColumn(Integer reportsId) throws ApplicationException {

		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<ReportColumnMapping> criteria = builder.createQuery(ReportColumnMapping.class);
		Root<ReportColumnMapping> root = criteria.from(ReportColumnMapping.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.REPORT_ID), reportsId)));
		return (List<ReportColumnMapping>) getResultList(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Save report.
	 *
	 * @param report the report
	 * @return the integer
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Integer saveReport(Reports report) throws ApplicationException {

		return save(report, TableConstants.REPORT);
	}

	/**
	 * Gets the report data based on identity.
	 *
	 * @param identity the identity
	 * @return the report data based on identity
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Reports getreportDataBasedOnIdentity(String identity) throws ApplicationException {

		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Reports> criteria = builder.createQuery(Reports.class);
		Root<Reports> root = criteria.from(Reports.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IDENTITY), identity)));
		return (Reports) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst()
				.orElse(null);
	}

	/**
	 * Updat report.
	 *
	 * @param data the data
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void updatReport(Reports data) throws ApplicationException {

		update(data);

	}

	/**
	 * Save report mapping column.
	 *
	 * @param reportMappingColum the report mapping colum
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void saveReportMappingColumn(ReportColumnMapping reportMappingColum) throws ApplicationException {
		try {
			save(reportMappingColum, TableConstants.REPORT_COLUMN_MAPPING);
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Update report mapping column.
	 *
	 * @param reportMappingColum the report mapping colum
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void updateReportMappingColumn(ReportColumnMapping reportMappingColum) throws ApplicationException {

		update(reportMappingColum);
	}

	/**
	 * Gets the total count in purchase order.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @param companyId the company id
	 * @return the total count in purchase order
	 */
	@Override
	public purchaseOrderStatusCountDto getTotalCountInPurchaseOrder(LocalDateTime fromDate, LocalDateTime toDate,Integer companyId) {

		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<purchaseOrderStatusCountDto> criteria = builder.createQuery(purchaseOrderStatusCountDto.class);

		Root<PurchaseOrderEntity> root = criteria.from(PurchaseOrderEntity.class);

		Expression<Long> totalTransactionExpression = builder.count(root);

		Expression<Long> submitExpression = builder.sumAsLong(
				builder.<Integer>selectCase().when(builder.equal(root.get(TableConstants.ORDER_STATUS), 2), 1));

		Expression<Long> faildExpression = builder.sumAsLong(
				builder.<Integer>selectCase().when(builder.equal(root.get(TableConstants.ORDER_STATUS), 1), 1));

		Expression<Long> successExpression = builder.sumAsLong(
				builder.<Integer>selectCase().when(builder.equal(root.get(TableConstants.ORDER_STATUS), 3), 1));

		criteria.multiselect(totalTransactionExpression, faildExpression, successExpression, submitExpression);

		List<Predicate> predicates = new ArrayList<>();

		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));

		predicates.add(builder.and(builder.greaterThanOrEqualTo(root.get(TableConstants.DP_PURCHASE_DATE), fromDate)));
		predicates.add(builder.and(builder.lessThanOrEqualTo(root.get(TableConstants.DP_PURCHASE_DATE), toDate)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.COMPANY_ID), companyId)));
		
		return (purchaseOrderStatusCountDto) getSingleResult(createQuery(builder, criteria, root, predicates));

	}

	/**
	 * Gets the total count in digital paper.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @param companyId the company id
	 * @return the total count in digital paper
	 * @throws ApplicationException the application exception
	 */
	@Override
	public purchaseOrderStatusCountDto getTotalCountInDigitalPaper(LocalDateTime fromDate, LocalDateTime toDate, Integer companyId)
			throws ApplicationException {

		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<purchaseOrderStatusCountDto> criteria = builder.createQuery(purchaseOrderStatusCountDto.class);

		Root<PaperDetails> root = criteria.from(PaperDetails.class);

		Expression<Long> totalTransactionExpression = builder.count(root);

		Expression<Long> activeExpression = builder
				.sumAsLong(builder.<Integer>selectCase().when(builder.equal(root.get(TableConstants.PD_STATUS), 1), 1));

		Expression<Long> expiredExpression = builder
				.sumAsLong(builder.<Integer>selectCase().when(builder.equal(root.get(TableConstants.PD_STATUS), 2), 1));

		Expression<Long> revokeExpression = builder
				.sumAsLong(builder.<Integer>selectCase().when(builder.equal(root.get(TableConstants.PD_STATUS), 3), 1));

		criteria.multiselect(totalTransactionExpression, expiredExpression, activeExpression, revokeExpression);

		List<Predicate> predicates = new ArrayList<>();

		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));

		predicates.add(builder.and(builder.greaterThanOrEqualTo(root.get(TableConstants.CREATED_DATE), fromDate)));
		predicates.add(builder.and(builder.lessThanOrEqualTo(root.get(TableConstants.CREATED_DATE), toDate)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.COMPANY_ID), companyId)));
		
		return (purchaseOrderStatusCountDto) getSingleResult(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Gets the selected column count.
	 *
	 * @param reportsId the reports id
	 * @return the selected column count
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Long getSelectedColumnCount(Integer reportsId) throws ApplicationException {

		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<ReportColumnMapping> root = criteria.from(ReportColumnMapping.class);
		criteria.select(builder.count(root));
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.REPORT_ID), reportsId)));
		return (Long) getSingleResult(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Gets the preview data in purchase order.
	 *
	 * @param previewData the preview data
	 * @param companyId the company id
	 * @param min the min
	 * @param max the max
	 * @return the preview data in purchase order
	 * @throws ApplicationException the application exception
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<PurchaseOrderEntity> getPreviewDataInPurchaseOrder(PreviewReportDto previewData, Integer companyId,Integer min,Integer max)
			throws ApplicationException {

		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<PurchaseOrderEntity> criteria = builder.createQuery(PurchaseOrderEntity.class);
		Root<PurchaseOrderEntity> root = criteria.from(PurchaseOrderEntity.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));

		predicates.add(builder.and(builder.greaterThanOrEqualTo(root.get(TableConstants.DP_PURCHASE_DATE),
				previewData.getReportData().getFromDate())));
		predicates.add(builder.and(builder.lessThanOrEqualTo(root.get(TableConstants.DP_PURCHASE_DATE),
				previewData.getReportData().getToDate())));

		List<Integer> statusList = new ArrayList<>();
		for (String status : previewData.getReportData().getStatus()) {

			Integer statusId = PaymentStatusEnum.getPaymentStatusEnum(status.trim()).getId();
			if (ApplicationUtils.isValidId(statusId)) {
				statusList.add(statusId);
			}
		}
		predicates.add(builder.and(root.get(TableConstants.ORDER_STATUS).in(statusList)));
		List<FilterOrSortingVo> filterVo = previewData.getFilterVo().stream()
											.filter(filterVos->!filterVos.getColumnName().equals(TableConstants.PD_INSURED_NAME) 
															&& !filterVos.getColumnName().equals(TableConstants.DP_PAYMENT_METHOD))
											.toList();
		if (ApplicationUtils.isValidList(filterVo)) {
			predicates.addAll(getFilterPrdicets(filterVo, root, builder, criteria));
		}
		if(ApplicationUtils.isValidId(max)) {
			return (List<PurchaseOrderEntity>) getResultList(getBasePredicateResult(builder, criteria, root,null, predicates).setFirstResult(min).setMaxResults(max));

		}
		return (List<PurchaseOrderEntity>) getResultList(getBasePredicateResult(builder, criteria, root,null, predicates));
	}

	/**
	 * Gets the customer data.
	 *
	 * @param insuredName the insured name
	 * @return the customer data
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Customer getcustomerData(String insuredName) throws ApplicationException {

		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Customer> criteria = builder.createQuery(Customer.class);
		Root<Customer> root = criteria.from(Customer.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.USER_NAME), insuredName)));

		return (Customer) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst()
				.orElse(null);
	}

	/**
	 * Gets the insured company list.
	 *
	 * @return the insured company list
	 * @throws ApplicationException the application exception
	 */
	@Override
	public List<Customer> getInsuredCompanyList() throws ApplicationException {

		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Customer> criteria = builder.createQuery(Customer.class);
		Root<Customer> root = criteria.from(Customer.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));

		return (List<Customer>) getResultList(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Gets the preview in paper details.
	 *
	 * @param previewData the preview data
	 * @param companyId the company id
	 * @param min the min
	 * @param max the max
	 * @return the preview in paper details
	 * @throws ApplicationException the application exception
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<PaperDetails> getPreviewInPaperDetails(PreviewReportDto previewData, Integer companyId,Integer min,Integer max)
			throws ApplicationException {

		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
		Root<PaperDetails> root = criteria.from(PaperDetails.class);

		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));

		predicates.add(builder.and(builder.greaterThanOrEqualTo(root.get(TableConstants.CREATED_DATE),
				previewData.getReportData().getFromDate())));
		predicates.add(builder.and(builder.lessThanOrEqualTo(root.get(TableConstants.CREATED_DATE),
				previewData.getReportData().getToDate())));

		List<Integer> statusList = new ArrayList<>();
		for (String status : previewData.getReportData().getStatus()) {

			Integer statusId = PaperStatusEnum.getPaperStatusIdByName(status.trim()).getId();
			if (ApplicationUtils.isValidId(statusId)) {
				statusList.add(statusId);
			}
		}
		predicates.add(builder.and(root.get(TableConstants.PD_STATUS).in(statusList)));
		if (ApplicationUtils.isValidList(previewData.getFilterVo())) {
			predicates.addAll(getFilterPrdicets(previewData.getFilterVo(), root, builder, criteria));
		}
		if(ApplicationUtils.isValidId(max)) {
			return (List<PaperDetails>) getResultList(getBasePredicateResult(builder, criteria, root, null, predicates).setFirstResult(min).setMaxResults(max));
		}

		return (List<PaperDetails>) getResultList(getBasePredicateResult(builder, criteria, root, null, predicates));
	}

	/**
	 * Gets the reports data based on user id.
	 *
	 * @param userId the user id
	 * @return the reports data based on user id
	 * @throws ApplicationException the application exception
	 */
	@Override
	public List<Reports> getreportsDataBasedOnUserId(Integer userId) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Reports> criteria = builder.createQuery(Reports.class);
		Root<Reports> root = criteria.from(Reports.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		criteria.orderBy(builder.desc(root.get(TableConstants.MODIFIED_DATE)));
		return (List<Reports>) getResultList(getBasePredicateResult(builder, criteria, root,null, predicates));
	}

	/**
	 * Gets the report column.
	 *
	 * @param columnName the column name
	 * @param reportsId the reports id
	 * @return the report column
	 * @throws ApplicationException the application exception
	 */
	@Override
	public ReportColumnMapping getreportColumn(String columnName, Integer reportsId) throws ApplicationException {
		
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<ReportColumnMapping> criteria = builder.createQuery(ReportColumnMapping.class);
		Root<ReportColumnMapping> root = criteria.from(ReportColumnMapping.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.REPORT_ID), reportsId)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.COLUMN_NAME), columnName)));
		return (ReportColumnMapping) getSingleResult(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Gets the preview in paper details count.
	 *
	 * @param previewData the preview data
	 * @param insuredCompanyId the insured company id
	 * @return the preview in paper details count
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Long getPreviewInPaperDetailsCount(PreviewReportDto previewData, Integer insuredCompanyId)
			throws ApplicationException {

		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<PaperDetails> root = criteria.from(PaperDetails.class);

		criteria.select(builder.count(root));
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));

		predicates.add(builder.and(builder.greaterThanOrEqualTo(root.get(TableConstants.CREATED_DATE),
				previewData.getReportData().getFromDate())));
		predicates.add(builder.and(builder.lessThanOrEqualTo(root.get(TableConstants.CREATED_DATE),
				previewData.getReportData().getToDate())));

		List<Integer> statusList = new ArrayList<>();
		for (String status : previewData.getReportData().getStatus()) {

			Integer statusId = PaperStatusEnum.getPaperStatusIdByName(status.trim()).getId();
			if (ApplicationUtils.isValidId(statusId)) {
				statusList.add(statusId);
			}
		}
		predicates.add(builder.and(root.get(TableConstants.PD_STATUS).in(statusList)));
		if (ApplicationUtils.isValidList(previewData.getFilterVo())) {
			predicates.addAll(getFilterPrdicets(previewData.getFilterVo(), root, builder, criteria));
		}

		return (Long) getSingleResult(getBasePredicateResult(builder, criteria, root,null, predicates));

	}

	/**
	 * Gets the preview data in purchase order count.
	 *
	 * @param previewData the preview data
	 * @param insuredCompanyId the insured company id
	 * @return the preview data in purchase order count
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Long getPreviewDataInPurchaseOrderCount(PreviewReportDto previewData, Integer insuredCompanyId)
			throws ApplicationException {

		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<PurchaseOrderEntity> root = criteria.from(PurchaseOrderEntity.class);
		criteria.select(builder.count(root));
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));

		predicates.add(builder.and(builder.greaterThanOrEqualTo(root.get(TableConstants.DP_PURCHASE_DATE),
				previewData.getReportData().getFromDate())));
		predicates.add(builder.and(builder.lessThanOrEqualTo(root.get(TableConstants.DP_PURCHASE_DATE),
				previewData.getReportData().getToDate())));

		List<Integer> statusList = new ArrayList<>();
		for (String status : previewData.getReportData().getStatus()) {

			Integer statusId = PaymentStatusEnum.getPaymentStatusEnum(status.trim()).getId();
			if (ApplicationUtils.isValidId(statusId)) {
				statusList.add(statusId);
			}
		}
		predicates.add(builder.and(root.get(TableConstants.ORDER_STATUS).in(statusList)));
		List<FilterOrSortingVo> filterVo = previewData.getFilterVo().stream()
				.filter(filterVos -> !filterVos.getColumnName().equals(TableConstants.PD_INSURED_NAME)).toList();
		if (ApplicationUtils.isValidList(filterVo)) {
			predicates.addAll(getFilterPrdicets(filterVo, root, builder, criteria));
		}

		return (Long) getSingleResult(getBasePredicateResult(builder, criteria, root,null, predicates));

	}	

}
