package com.digitalpaper.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.digitalpaper.exception.core.ApplicationException;
import com.fasterxml.jackson.core.JsonProcessingException;

/**
 * The Interface IDigitalManageDataService.
 */
public interface IDigitalManageDataService {
		
	/**
	 * Export master datas.
	 *
	 * @param tableEntityMap the table entity map
	 * @return the list
	 * @throws JsonProcessingException the json processing exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public List<Map<String, Object>> exportMasterDatas(List<String> tableEntityMap) throws JsonProcessingException, IOException;

	/**
	 * Import master data.
	 *
	 * @param recoveryMasterDataMap the recovery master data map
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws ApplicationException the application exception
	 */
	void importMasterData(Map<String, Object> recoveryMasterDataMap) throws IOException, ApplicationException;

}
