package com.digitalpaper.service;

import java.util.List;

import com.digitalpaper.transfer.object.dto.CustomerNotificationDto;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;

/**
 * The Interface ICustomerNotificationService.
 */
public interface ICustomerNotificationService {

	/**
	 * Gets the custom notification count.
	 *
	 * @return the custom notification count
	 */
	List<CustomerNotificationDto> getCustomNotificationCount();

	/**
	 * Update notification by identity.
	 *
	 * @param identity the identity
	 * @return true, if successful
	 */
	boolean updateNotificationByIdentity(String identity);

	/**
	 * Gets the paper based onid.
	 *
	 * @param paperId the paper id
	 * @return the paper based onid
	 */
	PaperDetailsDto getpaperBasedOnid(String paperId);

}
