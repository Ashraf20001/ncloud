package com.digitalpaper.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.AuthorityStockDto;
import com.digitalpaper.transfer.object.dto.CompanyTransactionDto;
import com.digitalpaper.transfer.object.dto.DownloadListVo;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;

/**
 * The Interface IAuthorityPaperDetailsService.
 */
public interface IAuthorityPaperDetailsService {

	/**
	 * @param filterVo
	 * @return
	 * @throws ApplicationException
	 */
	Long getStockCount(List<FilterOrSortingVo> filterVo,List<Integer> companyIds, String searchValue) throws ApplicationException;

	/**
	 * @param skip
	 * @param limit
	 * @param filterVo
	 * @param isCard 
	 * @return
	 * @throws ApplicationException
	 */
	List<AuthorityStockDto> getStockData(Integer skip, Integer limit,String searchValue, List<FilterOrSortingVo> filterVo,
			List<Integer> companyIds, Boolean isInsurance, String isCard)
			throws ApplicationException;

	/**
	 * @param companyTransactionDto
	 * @return
	 * @throws ApplicationException
	 */
	Long getPaperDetailsByCompanyCount(CompanyTransactionDto companyTransactionDto, String searchValue) throws ApplicationException;

	/**
	 * @param companyTransactionDto
	 * @return
	 * @throws ApplicationException
	 */
	List<PaperDetailsDto> getPaperDetailsByCompanyList(CompanyTransactionDto companyTransactionDto, String searchValue) throws ApplicationException;
    
	/**
	 * Download paper in excel.
	 *
	 * @param downloadVo the download vo
	 * @param searchValue the search value
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	ResponseEntity<ByteArrayResource> downloadPaperInExcel(DownloadListVo downloadVo, String searchValue) throws ApplicationException;

	/**
	 * Gets the columns in drop down paper details.
	 *
	 * @return the columns in drop down paper details
	 * @throws ApplicationException the application exception
	 */
	public List<String> getColumnsInDropDownPaperDetails() throws ApplicationException;

	/**
	 * Download view paper.
	 *
	 * @param searchValue the search value
	 * @param downloadVo the download vo
	 * @param request the request
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	ResponseEntity<ByteArrayResource> downloadViewPaper(String searchValue , DownloadListVo downloadVo, HttpServletRequest request) throws ApplicationException ;
	
	/**
	 * Gets the stock table count.
	 *
	 * @return the stock table count
	 */
	Long getStockTableCount();
}
