package com.digitalpaper.dao;

import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.entity.StockTransactionHistory;

/**
 * The Interface StockTransactionHistoryDao.
 */
public interface StockTransactionHistoryDao {
	
	/**
	 * Save stock transaction history.
	 *
	 * @param stockTransactionHistory the stock transaction history
	 * @return the integer
	 * @throws ApplicationException the application exception
	 */
	Integer saveStockTransactionHistory(StockTransactionHistory stockTransactionHistory) throws ApplicationException;

}
