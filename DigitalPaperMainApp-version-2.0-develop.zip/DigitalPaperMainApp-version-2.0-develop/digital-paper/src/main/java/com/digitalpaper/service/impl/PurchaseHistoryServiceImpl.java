package com.digitalpaper.service.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.digitalpaper.config.DigitalPaperCache;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.IPurchaseOrderEntityDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.service.IPurchaseHistoryService;
import com.digitalpaper.transfer.object.dto.CompanyAndCountDto;
import com.digitalpaper.transfer.object.dto.NotificationCount;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.entity.UserType;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;
import com.digitalpaper.utils.core.ApplicationUtils;

/**
 * The Class PurchaseHistoryServiceImpl.
 */
@Service
@Transactional
public class PurchaseHistoryServiceImpl implements IPurchaseHistoryService {

	/**
	 * IPurchaseHistoryDao
	 */
	@Autowired
	private IPurchaseOrderEntityDao iPurchaseOrderEntityDao;
	
	/** The logged in user context holder. */
	@Autowired
	private LoggedInUserContextHolder loggedInUserContextHolder;
	
	/**
	 * DigitalPaperCache
	 */
	@Autowired
	private DigitalPaperCache digitalPaperCache;
	
	/**                             
	 * @return                      
	 * @throws ApplicationException 
	 */                             
	@Override
	public Long getPurchaseOrderEntityCount(List<FilterOrSortingVo> filterVo, String searchValue) throws ApplicationException {
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		UserType userTypeId = loggedInUser.getUserTypeId();
		if (!userTypeId.getUserTypeName().equals(ApplicationConstants.ASSOCIATION)) {
			throw new ApplicationException(ErrorCodes.UN_AUTHORIZED);
		}
		HashMap<Integer, String> companyNameMaping = digitalPaperCache.getCompanyList();
		List<CompanyAndCountDto> countOfOrderData = iPurchaseOrderEntityDao.getCompanyAndCountList(null,companyNameMaping,0, 0, filterVo, Boolean.TRUE,searchValue);
		List<CompanyAndCountDto> purchaseCountDate  = new ArrayList<>();
		if (ApplicationUtils.isValidString(searchValue)) {
			purchaseCountDate = countOfOrderData.stream().filter(x -> {
			        String pendingCountString = Objects.toString(x.getPendingCount(), "");
			        String totalCountString = Objects.toString(x.getTotalCount(), "");
			        return x.getComapanyName().toLowerCase().contains(searchValue.toLowerCase()) ||
			               pendingCountString.contains(searchValue) ||
			               totalCountString.contains(searchValue);
			    }).collect(Collectors.toList());
		}else {
			purchaseCountDate.addAll(countOfOrderData) ;
		}
		
		Long totalCountOfCompanyFromTransaction = (long) purchaseCountDate.size();
		return totalCountOfCompanyFromTransaction;
	}

	/**
	 * @param skip
	 * @param limit
	 * @param filterVo
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public List<CompanyAndCountDto> getPurchaseOrderData(Integer skip, int limit, List<FilterOrSortingVo> filterVo, String searchValue)
			throws ApplicationException {
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		UserType userTypeId = loggedInUser.getUserTypeId();

		if (!userTypeId.getUserTypeName().equals(ApplicationConstants.ASSOCIATION)) {
			throw new ApplicationException(ErrorCodes.UN_AUTHORIZED);
		}
		List<CompanyAndCountDto> companyAndCountDtoList = new ArrayList<>();	
		HashMap<Integer, String> companyNameMaping = digitalPaperCache.getCompanyList();
		List<CompanyAndCountDto> companyAndCountList = iPurchaseOrderEntityDao.getCompanyAndCountList(null,companyNameMaping,skip,limit,filterVo,Boolean.FALSE, searchValue);
		
		companyAndCountDtoList = companyAndCountList.stream().filter(count -> count.getPendingCount() == null).peek(count ->count.setPendingCount(0l)).toList();
		companyAndCountDtoList = companyAndCountList.stream()
				.peek(value -> value.setComapanyName(companyNameMaping.get(value.getCompanyId())))
				.collect(Collectors.toList());
		
		companyAndCountDtoList = checkFilterAndsetDto(companyAndCountDtoList, searchValue,skip,limit);
		
		if (ApplicationUtils.isValidList(filterVo)) {
			Optional<FilterOrSortingVo> filteredList = filterVo.stream()
					.filter(vo -> vo.getColumnName().equalsIgnoreCase(ApplicationConstants.SORT_COMPANY)).findFirst();
			if (filteredList.isPresent()) {
				FilterOrSortingVo sort = filteredList.get();
				Comparator<CompanyAndCountDto> caseInsensitiveComparator = Comparator
						.comparing(dto -> dto.getComapanyName(), String.CASE_INSENSITIVE_ORDER);
				if (sort.isAscending()) {
					companyAndCountDtoList = companyAndCountDtoList.stream().sorted(caseInsensitiveComparator)
							.collect(Collectors.toList());
				} else {
					companyAndCountDtoList = companyAndCountDtoList.stream()
							.sorted(caseInsensitiveComparator.reversed()).collect(Collectors.toList());
				}
			}
		}
		Map<Integer, String> compIdNameMap = companyAndCountDtoList.stream().collect(Collectors.toMap(id->id.getCompanyId(), name->name.getComapanyName()));
		List<NotificationCount> notificationCount = iPurchaseOrderEntityDao.getNotificationCount(compIdNameMap);
		Map<Integer, Long> idAndNotifiMap = setCompIdAndNotificationCount(notificationCount);
		setNotification(companyAndCountDtoList, idAndNotifiMap);
		convertEntityToDto(skip, companyAndCountDtoList, searchValue);
		
		return companyAndCountDtoList;
	}
	
	
	/**
	 * Check filter andset dto.
	 *
	 * @param companyAndCountDtoList the company and count dto list
	 * @param searchValue the search value
	 * @param skip the skip
	 * @param limit the limit
	 * @return the list
	 */
	private List<CompanyAndCountDto> checkFilterAndsetDto(List<CompanyAndCountDto> companyAndCountDtoList, String searchValue, Integer skip, int limit) {
		
		List<CompanyAndCountDto> companyAndCountDto = new ArrayList<>();
		if (ApplicationUtils.isValidString(searchValue)) {
			companyAndCountDtoList =	companyAndCountDtoList.stream().filter(x->x.getComapanyName().toLowerCase().contains(searchValue.toLowerCase()) || x.getPendingCount().toString().contains(searchValue) 
					|| x.getTotalCount().toString().contains(searchValue) ).collect(Collectors.toList());
			
			companyAndCountDto = companyAndCountDtoList.stream().skip(skip).limit(limit).collect(Collectors.toList());
			return companyAndCountDto;
			
		}
		
		return companyAndCountDtoList;
	}

	/**
	 * Gets the purchase order data in download.
	 *
	 * @param companyIds the company ids
	 * @param filterVo the filter vo
	 * @param searchValue the search value
	 * @return the purchase order data in download
	 * @throws ApplicationException the application exception
	 */
	@Override
	public List<CompanyAndCountDto> getpurchaseOrderDataInDownload(List<Integer> companyIds,List<FilterOrSortingVo> filterVo,
			String searchValue) throws ApplicationException{
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		UserType userTypeId = loggedInUser.getUserTypeId();

		if (!userTypeId.getUserTypeName().equals(ApplicationConstants.ASSOCIATION)) {
			throw new ApplicationException(ErrorCodes.UN_AUTHORIZED);
		}
		List<CompanyAndCountDto> companyAndCountDtoList = new ArrayList<>();
	
		HashMap<Integer, String> companyNameMaping = digitalPaperCache.getCompanyList();
		List<CompanyAndCountDto> companyAndCountList = iPurchaseOrderEntityDao.getCompanyAndCountList(companyIds,companyNameMaping,0,10,filterVo,true, "");
		companyAndCountDtoList = companyAndCountList.stream().filter(count -> count.getPendingCount() == null).peek(count ->count.setPendingCount(0l)).toList();
		companyAndCountDtoList = companyAndCountList.stream()
				.peek(value -> value.setComapanyName(companyNameMaping.get(value.getCompanyId())))
				.collect(Collectors.toList());
		
		Map<Integer, String> compIdNameMap = companyAndCountDtoList.stream().collect(Collectors.toMap(id->id.getCompanyId(), name->name.getComapanyName()));
		List<NotificationCount> notificationCount = iPurchaseOrderEntityDao.getNotificationCount(compIdNameMap);
		Map<Integer, Long> idAndNotifiMap = setCompIdAndNotificationCount(notificationCount);
		setNotification(companyAndCountDtoList, idAndNotifiMap);
		if(!ApplicationUtils.isValidList(companyIds)) {		
			convertEntityToDto(0, companyAndCountDtoList, searchValue);
		}
		
		if (ApplicationUtils.isValidString(searchValue)) {
			companyAndCountDtoList =	companyAndCountDtoList.stream().filter(x->x.getComapanyName().toLowerCase().contains(searchValue.toLowerCase()) || x.getPendingCount().toString().contains(searchValue) 
					|| x.getTotalCount().toString().contains(searchValue) ).collect(Collectors.toList());
			
		}
		return companyAndCountDtoList;
	}

	/**
	 * @param skip
	 * @param companyAndCountDtoList
	 * @throws ApplicationException
	 */
	private void convertEntityToDto(Integer skip, List<CompanyAndCountDto> companyAndCountDtoList, String searchValue)
			throws ApplicationException {
		if (skip == ApplicationConstants.ZERO && !ApplicationUtils.isValidateObject(searchValue)) {
			CompanyAndCountDto companyAndCountDto = new CompanyAndCountDto();
			Object[] allCompaniesCount = iPurchaseOrderEntityDao.getAllCompaniesCount();
			companyAndCountDto.setTotalCount((long) allCompaniesCount[0]);
			boolean validateObject = ApplicationUtils.isValidateObject(allCompaniesCount[1]);
			companyAndCountDto.setPendingCount(validateObject?(long) allCompaniesCount[1]:0l);
			companyAndCountDto.setComapanyName(ApplicationConstants.ALL_COMPANY_NAME);
			companyAndCountDto.setCompanyId(0);
			companyAndCountDtoList.add(0, companyAndCountDto);
		}
	}

	/**
	 * @param companyAndCountDtoList
	 * @param idAndNotifiMap
	 */
	private void setNotification(List<CompanyAndCountDto> companyAndCountDtoList, Map<Integer, Long> idAndNotifiMap) {
		for (CompanyAndCountDto notification : companyAndCountDtoList) {
			if (idAndNotifiMap.get(notification.getCompanyId()) != null) {
				notification.setNotification(idAndNotifiMap.get(notification.getCompanyId()));
			}
		}
	}

	/**
	 * @param notificationCount
	 * @return
	 */
	private Map<Integer, Long> setCompIdAndNotificationCount(List<NotificationCount> notificationCount) {
		Map<Integer, Long> idAndNotifiMap = new HashMap<Integer,Long>();
		for(NotificationCount val : notificationCount) {
			idAndNotifiMap.put(val.getCompanyId(), val.getNotificationCount());
		}
		return idAndNotifiMap;
	}
	
	/**
	 * Gets the download data to excel.
	 *
	 * @param dto the dto
	 * @param selectedColumnList the selected column list
	 * @return the download data to excel
	 */
	@Override
	public ArrayList<HashMap<String, Object>> getDownloadDataToExcel(List<CompanyAndCountDto> dto,List<String> selectedColumnList) {

		ArrayList<HashMap<String, Object>> list = new ArrayList<>();
		
		for (int i = 0; i <= dto.size() - 1; i++) {
			
			CompanyAndCountDto companyCount = dto.get(i);
			HashMap<String, Object> map = new LinkedHashMap<>();
			
			if(ApplicationUtils.isValidateObject(selectedColumnList)) {
				for (String field : selectedColumnList) {
					
					switch (field.trim()) {
						
					case TableConstants.INSURED_COMPANY:
						map.put(TableConstants.INSURED_COMPANY, companyCount.getComapanyName());
						break;
						
					case TableConstants.TOTAL_TRANSACTION:
						map.put(TableConstants.TOTAL_TRANSACTION, companyCount.getTotalCount());
						break;
						
					case TableConstants.PENDING_TRANSACTION:
						map.put(TableConstants.PENDING_TRANSACTION, companyCount.getPendingCount());
						break;
					}
				}
			}
			list.add(map);
		}
		
		return list;
	}
}
