package com.digitalpaper.service.impl;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Base64;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.digitalpaper.config.property.EnvironmentProperties;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.dao.IDigItalPaperExternalApiDao;
import com.digitalpaper.dao.IPaperDetailsDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.restemplate.service.IDigitalPaperSevice;
import com.digitalpaper.restemplate.service.IRestTemplateService;
import com.digitalpaper.service.IDigItalPaperExternalApiService;
import com.digitalpaper.transfer.object.dto.DigitalPaperDto;
import com.digitalpaper.transfer.object.dto.ExternalApiDigitalPaperDto;
import com.digitalpaper.transfer.object.dto.FieldGroup;
import com.digitalpaper.transfer.object.entity.FileStorage;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.enums.PaperStatusEnum;
import com.digitalpaper.utils.core.ApplicationUtils;

/**
 * The Class DigItalPaperExternalApiServiceImpl.
 */
@Service
@Transactional
public class DigItalPaperExternalApiServiceImpl implements IDigItalPaperExternalApiService {

	/** The i rest template service. */
	@Autowired
	private IRestTemplateService iRestTemplateService;

	/** The digital paper service. */
	@Autowired
	private IDigitalPaperSevice digitalPaperService;

	/** The dig ital paper external api dao. */
	@Autowired
	private IDigItalPaperExternalApiDao digItalPaperExternalApiDao;

	/** The i paper details dao. */
	@Autowired
	IPaperDetailsDao iPaperDetailsDao;

	/** The environment properties. */
	@Autowired
	EnvironmentProperties environmentProperties;

	/**
	 * Save external api dto.
	 *
	 * @param dto the dto
	 * @param request the request
	 * @return the string
	 * @throws ApplicationException the application exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	public String saveExternalApiDto(DigitalPaperDto dto, HttpServletRequest request)
			throws ApplicationException, IOException {
		String response = "";
		String encodeUploadType = new String(
				java.util.Base64.getEncoder().encode(ApplicationConstants.NORMAL.getBytes()));

		FieldGroup fieldGroup = iRestTemplateService.convertDtoToFieldGroup(dto, request);
		response = digitalPaperService.saveDigitalPaper(fieldGroup, request, null, encodeUploadType);
		return response;
	}

	/**
	 * Gets the external api dto.
	 *
	 * @param pdDigitalPaperId the pd digital paper id
	 * @param request the request
	 * @return the external api dto
	 * @throws ApplicationException the application exception
	 */
	@Override
	public ExternalApiDigitalPaperDto getExternalApiDto(String pdDigitalPaperId, HttpServletRequest request)
			throws ApplicationException {
		PaperDetails paperDetails = digItalPaperExternalApiDao.getExternalApiDto(pdDigitalPaperId);
		if (!ApplicationUtils.isValidateObject(paperDetails)) {
			throw new ApplicationException(ErrorCodes.INVALID_PURCHASE_ID);
		}
		return convertPaperDetailsToDigitalPaperDto(paperDetails);
	}

	/**
	 * Convert paper details to digital paper dto.
	 *
	 * @param paperDetails the paper details
	 * @return the external api digital paper dto
	 */
	private ExternalApiDigitalPaperDto convertPaperDetailsToDigitalPaperDto(PaperDetails paperDetails) {
		String imageString = "";

		ExternalApiDigitalPaperDto digitalPaperDto = new ExternalApiDigitalPaperDto();

		digitalPaperDto.setPdDigitalPaperId(paperDetails.getPdDigitalPaperId());
		digitalPaperDto.setPdEmailId(paperDetails.getPdEmailId());
		digitalPaperDto.setPdInsuredName(paperDetails.getPdInsuredName());
		digitalPaperDto.setPdPhoneNumber(paperDetails.getPdPhoneNumber());
		digitalPaperDto.setPdPolicyNumber(paperDetails.getPdPhoneNumber());
		digitalPaperDto.setPdEffectiveFrom(paperDetails.getPdEffectiveFrom().toString());
		digitalPaperDto.setPdExpireDate(paperDetails.getPdExpireDate().toString());
		digitalPaperDto.setVdChassis(paperDetails.getVdChassis());
		digitalPaperDto.setVdLicensedToCarry(paperDetails.getVdLicensedToCarry());
		digitalPaperDto.setVdMake(paperDetails.getVdMake());
		digitalPaperDto.setVdModel(paperDetails.getVdModel());
		digitalPaperDto.setVdRegistrationNumber(paperDetails.getVdRegistrationNumber());
		digitalPaperDto.setVdUsage(paperDetails.getVdUsage());
		digitalPaperDto.setStatus(PaperStatusEnum.getPaperStatusById(paperDetails.getStatus()).name());
		imageString = pdfFileToStringConvertion(paperDetails, imageString);
		digitalPaperDto.setDigitalPaperUrl(imageString);

		return digitalPaperDto;
	}

	/**
	 * Pdf file to string convertion.
	 *
	 * @param paperDetails the paper details
	 * @param imageString the image string
	 * @return the string
	 */
	private String pdfFileToStringConvertion(PaperDetails paperDetails, String imageString) {
		FileStorage file = iPaperDetailsDao.getPaperImageById(paperDetails.getPaperId(), ApplicationConstants.UPD_TYPE,
				ApplicationConstants.RP_TYPE);
		if (ApplicationUtils.isValidateObject(file)) {
			String fileDownloadUrl = environmentProperties.getOgTemplateUrl();

			try {
				BufferedImage bImage = ImageIO.read(new File(fileDownloadUrl + file.getUrl()));
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				ImageIO.write(bImage, "png", bos);
				imageString = Base64.getEncoder().encodeToString(bos.toByteArray());
			} catch (Exception e) {
				imageString = "";
				e.printStackTrace();
			}
		}
		return imageString;
	}

}
