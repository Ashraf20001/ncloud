package com.digitalpaper.daoImp;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.digitalpaper.config.common.base.dao.BaseDao;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.ICustomerNotificationDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.entity.CustomerNotification;

/**
 * The Class CustomerNotificationDaoImpl.
 */
@Repository
public class CustomerNotificationDaoImpl extends BaseDao implements ICustomerNotificationDao {

	/**
	 * Gets the custom notification count.
	 *
	 * @param customerId the customer id
	 * @return the custom notification count
	 */
	@Override
	public List<CustomerNotification> getCustomNotificationCount(Integer customerId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<CustomerNotification> criteria = builder.createQuery(CustomerNotification.class);
		Root<CustomerNotification> root = criteria.from(CustomerNotification.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_READ), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.TO_NOTIFY), customerId)));
		List<CustomerNotification> result = (List<CustomerNotification>) getResultList(
				createQuery(builder, criteria, root, predicates));
		return result;
	}

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {

	}

	/**
	 * Save custom notification.
	 *
	 * @param customerNotification the customer notification
	 * @return the integer
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Integer saveCustomNotification(CustomerNotification customerNotification) throws ApplicationException {
		Integer saveId=0;
		 saveId = save(customerNotification, TableConstants.CUSTOMER_NOTIFICATION);

		return saveId;
	}

	/**
	 * Gets the notification by identity.
	 *
	 * @param identity the identity
	 * @return the notification by identity
	 */
	@Override
	public CustomerNotification getNotificationByIdentity(String identity) {
		CustomerNotification result=null;
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<CustomerNotification> criteria = builder.createQuery(CustomerNotification.class);
		Root<CustomerNotification> root = criteria.from(CustomerNotification.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IDENTITY), identity)));
		result = (CustomerNotification) getSingleResult(
				createQuery(builder, criteria, root, predicates));
		return result;
	}

	/**
	 * Update notification by identity.
	 *
	 * @param customerNotification the customer notification
	 */
	@Override
	public void updateNotificationByIdentity(CustomerNotification customerNotification) {
		update(customerNotification);
	}

}
