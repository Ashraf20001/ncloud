package com.digitalpaper.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.digitalpaper.aop.annotation.Auditable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitalpaper.config.base.controller.BaseController;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.service.AllocationPoolService;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.PoolDto;
import com.digitalpaper.transfer.object.dto.StockDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;


/**
 * The Class AllocationPoolController.
 */
@RestController
@RequestMapping("/allocation-pool")
@Auditable
public class AllocationPoolController extends BaseController {
	
	/** AllocationPoolService. */
	@Autowired
	private AllocationPoolService allocationPoolService;

	
	
	/**
	 * Pool action.
	 *
	 * @param poolDto the pool dto
	 * @param request the request
	 * @return ApplicationResponse
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Allocation pool changes",notes = "Change allocation pool counts based on pool action",response = ApplicationResponse.class)
	@PostMapping("/pool-action")
	public ApplicationResponse poolAction(@ApiParam(value = "PoolDto payload",required = true)  @RequestBody PoolDto poolDto, HttpServletRequest request) throws ApplicationException {
		StockDto updatePoolCountByPoolAction = allocationPoolService.updatePoolCountByPoolAction(poolDto, request);
		return getApplicationResponse(updatePoolCountByPoolAction);
	}
	
	/**
	 * Gets the stock pool from identity.
	 *
	 * @param identity the identity
	 * @return ApplicationResponse
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Allocation pool data",notes = "Get allocation stock pool based on pool identity",response = ApplicationResponse.class)
	@PostMapping("/get-stock-pool")
	public ApplicationResponse getStockPoolFromIdentity(@ApiParam(value="Stock pool identity",required = true)  @RequestParam(value="id") String identity) throws ApplicationException {
		StockDto stockPoolFromIdentity = allocationPoolService.getStockPoolFromIdentity(identity);
		return getApplicationResponse(stockPoolFromIdentity);
	}
	
	/**
	 * Gets the all stock pool.
	 *
	 * @param filterOrSortingVo the filter or sorting vo
	 * @param identity the identity
	 * @param response the response
	 * @param min the min
	 * @param max the max
	 * @param searchValue the search value
	 * @return the all stock pool
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Allocation pools fetch",notes = "Get allocation stock pools based on pool identity",response = ApplicationResponse.class)
	@PostMapping("/get-all-stockpool")
	public ApplicationResponse getAllStockPool( @ApiParam(value = "Filter Vo payload",required = true) @RequestBody List<FilterOrSortingVo> filterOrSortingVo, @ApiParam(value="Allocation pool identity") @RequestParam(name="id", required = false) String identity, HttpServletRequest response,
		@ApiParam(value="Skip data count")	@RequestParam(name="min", required = false) Integer min,
		@ApiParam(value = "Limit data count")	@RequestParam(name="max", required = false) Integer max, @ApiParam(value="Search value data")   @RequestParam(name="searchValue", required = false) String searchValue) throws ApplicationException{
	 List<StockDto> listOfStockPool =	allocationPoolService.getAllStockPool(identity,response,filterOrSortingVo, min, max, searchValue);
		return getApplicationResponse(listOfStockPool);
	}
	
	/**
	 * Change stock pool status.
	 *
	 * @param status the status
	 * @param identity the identity
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Allocation pool status change",notes = "Change stock pool status based on pool identity")
	@PostMapping("/change-stockpool-status")
	public void changeStockPoolStatus( @ApiParam(value="Changing status",required=true)  @RequestParam(name="status") boolean status,@ApiParam(value="Stock pool identity",required=true) @RequestParam(value="id") String identity) throws ApplicationException{
		allocationPoolService.changeStockPoolStatus(status,identity);
	}
	
	/**
	 * Gets the stock pool count.
	 *
	 * @param response the response
	 * @return the stock pool count
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Allocation pools count",notes = "Get allocation stock pools count",response = ApplicationResponse.class)
	@GetMapping("/get-stockpool-count")
	public ApplicationResponse getStockPoolCount(HttpServletRequest response) throws ApplicationException{
		Integer count = allocationPoolService.getStockPoolCount(response);
		 return getApplicationResponse(count);
	}
	
	/**
	 * Gets the allocation type.
	 *
	 * @param request the request
	 * @return the allocation type
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Allocation type data",notes="Get allocation type datas",response = ApplicationResponse.class)
	@GetMapping("/get-allocation-type")
	public ApplicationResponse getAllocationType(HttpServletRequest request) throws ApplicationException{
		String response = allocationPoolService.getAllocationType(request);
		 return getApplicationResponse(response);
	}

	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return AllocationPoolController.class;
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {
	}

}
