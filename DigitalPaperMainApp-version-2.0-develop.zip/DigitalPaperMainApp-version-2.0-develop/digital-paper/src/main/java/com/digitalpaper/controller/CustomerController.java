package com.digitalpaper.controller;

import java.io.IOException;
import java.util.List;

import javax.mail.MessagingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitalpaper.aop.annotation.Auditable;
import com.digitalpaper.config.base.controller.BaseController;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.service.CustomerService;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.ChangePasswordDto;
import com.digitalpaper.transfer.object.dto.CompanyTransactionDto;
import com.digitalpaper.transfer.object.dto.CustomerDto;
import com.digitalpaper.transfer.object.dto.ResetPasswordDto;
import com.digitalpaper.utils.core.ApplicationUtils;

import freemarker.core.ParseException;
import freemarker.template.MalformedTemplateNameException;
import freemarker.template.TemplateException;
import freemarker.template.TemplateNotFoundException;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class CustomerController.
 */
@RestController
@Auditable
public class CustomerController extends BaseController {

	/** CustomerService. */
	@Autowired
	private CustomerService customerService;
	
	/** Logger. */
	private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);


	/**
	 * Gets the customer list.
	 *
	 * @param min the min
	 * @param max the max
	 * @param searchvalue the searchvalue
	 * @param filter the filter
	 * @return the customer list
	 * @throws ApplicationException the application exception
	 * @throws NoSuchFieldException the no such field exception
	 * @throws SecurityException the security exception
	 * @throws IllegalArgumentException the illegal argument exception
	 * @throws IllegalAccessException the illegal access exception
	 */
	@ApiOperation(value="Customer details",notes="Get customer list",response = ApplicationResponse.class)
	@PostMapping("/get-customerList")
	public ApplicationResponse getcustomerList( @ApiParam(value="Skip data count",required = true) @RequestParam(name = "min") Integer min,
			@ApiParam(value="Limit data count",required = true) @RequestParam(name = "max") Integer max,
			@ApiParam(value="Search data",required = true) @RequestParam(name = "searchValue") String searchvalue,
			@ApiParam(value="Filter vo payload") @RequestBody(required = false) List<FilterOrSortingVo> filter) throws ApplicationException, 
			NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		
		List<CustomerDto> customerList = customerService.getCustomerList(min, max, filter, searchvalue);
		ApplicationResponse applicationResponse = getApplicationResponse(customerList);
		
		return applicationResponse;
	}

	/**
	 * Gets the customer count.
	 *
	 * @param searchvalue the searchvalue
	 * @param filterOrSortingVo the filter or sorting vo
	 * @return the customer count
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Customer details count",notes="Get customer details count",response = ApplicationResponse.class)
	@PostMapping("/get-customer-cout")
	public ApplicationResponse getCustomerCount( @ApiParam(value="Search data",required = true) @RequestParam(name = "searchValue") String searchvalue, 
			@ApiParam(value="Filter vo payload",required = true) @RequestBody List<FilterOrSortingVo> filterOrSortingVo) throws ApplicationException {
		Long count = customerService.getCoustomerCount(filterOrSortingVo, searchvalue);
		return getApplicationResponse(count);
		
	}
	
	/**
	 * Download customer data.
	 *
	 * @param searchvalue the searchvalue
	 * @param downloadVo the download vo
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 * @throws NoSuchFieldException the no such field exception
	 * @throws SecurityException the security exception
	 * @throws IllegalArgumentException the illegal argument exception
	 * @throws IllegalAccessException the illegal access exception
	 */
	@ApiOperation(value="Customer details download",notes="Get customer details as excel download",response = ResponseEntity.class)
	@PostMapping("/custome-excel-download")
	public  ResponseEntity<ByteArrayResource> downloadCustomerData( @ApiParam(value="Search data",required = true) @RequestParam(name = "searchValue") String searchvalue,
			@ApiParam(value="Company Transaction dto payload",required = true) @RequestBody CompanyTransactionDto downloadVo) throws ApplicationException,
			NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException{

		Long count = customerService.getCoustomerCount(downloadVo.getFilter(),"");
		int maxValue=count.intValue();   
		List<CustomerDto> customerList = customerService.getCustomerList(0, maxValue, downloadVo.getFilter(),searchvalue);
		if (Boolean.FALSE.equals(ApplicationUtils.isValidateObject(customerList))) {
			return null;
		}
				
		return customerService.customerExcelDownload(customerList,downloadVo.getSelectedColumn());
	}
	
	/**
	 * Update customer.
	 *
	 * @param data the data
	 * @return the application response
	 * @throws ApplicationException the application exception
	 * @throws TemplateNotFoundException the template not found exception
	 * @throws MalformedTemplateNameException the malformed template name exception
	 * @throws ParseException the parse exception
	 * @throws MessagingException the messaging exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws TemplateException the template exception
	 */
	@ApiOperation(value="Update Customer",notes="Update customer details",response = ApplicationResponse.class)
	@PostMapping("/update-customerData")
	public ApplicationResponse updateCustomer(@ApiParam(value="Customer dto payload",required = true)  @RequestBody CustomerDto data) throws ApplicationException, TemplateNotFoundException, MalformedTemplateNameException, ParseException, MessagingException, IOException, TemplateException {
		
		String responce = customerService.updatCustomerDetails(data);
		ApplicationResponse applicationResponse = getApplicationResponse(responce);
		
		return applicationResponse;
	}
	
	/**
	 * Gets the customer by username.
	 *
	 * @param username the username
	 * @return the customer by username
	 */
	@ApiOperation(value="Get Customer",notes="Get customer detail for the user name",response = ResponseEntity.class)
	@GetMapping("/get-customer/{username}")
	public ResponseEntity<CustomerDto> getCustomerByUsername(@ApiParam(value="User name of customer",required=true) @PathVariable(name="username") String username){
		CustomerDto customerDto = customerService.getCustomerByUsername(username);
		return new ResponseEntity<>(customerDto,HttpStatus.OK);
	}


	/**
	 * Gets the customer data.
	 *
	 * @return the customer data
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Get login customer user",notes="Get login customer details",response = ApplicationResponse.class)
	@GetMapping("/get-login-customer")
	public ApplicationResponse getCustomerData() throws ApplicationException {

		CustomerDto data = new CustomerDto();
		data = customerService.getLoginCustomerDetails();
		return getApplicationResponse(data);

	}


	/**
	 * Update login customer.
	 *
	 * @param data the data
	 * @return the application response
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Update login customer user",notes="Update login customer details",response = ApplicationResponse.class)
	@PostMapping("/Update-login-customer")
	public ApplicationResponse updateLoginCustomer( @ApiParam(value="Customer dto payload",required = true) @RequestBody CustomerDto data ) throws ApplicationException {

		String updateLoginCustomer=null;
		updateLoginCustomer= customerService.updateLoginCustomer(data);
		return getApplicationResponse(updateLoginCustomer);
	}
	
	/**
	 * Reset first time password.
	 *
	 * @param resetPasswordDto the reset password dto
	 * @return the application response
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Customer reset password",notes="Reset customer password details",response = ApplicationResponse.class)
	@PutMapping("/resetpassword")
	public ApplicationResponse resetFirstTimePassword(@ApiParam(value="ResetPassword dto payload",required = true) @RequestBody ResetPasswordDto resetPasswordDto) throws ApplicationException {
		
			customerService.resetCustomerPassword(resetPasswordDto);
			return getApplicationResponse("Reset password is success");
			
	}

	
	/**
	 * Forget password.
	 *
	 * @param emailId the email id
	 * @return the application response
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Customer forget password",notes="Reset customer password details using forget password",response = ApplicationResponse.class)
	@PostMapping("/forgetPassword")
	public ApplicationResponse forgetPassword(@ApiParam(value="Customer email id",required = true) @RequestParam(name="emailId") String emailId) throws ApplicationException {
		logger.info("forget Password Method Started");
		String validateEmail = customerService.validateEmail(emailId);
		return getApplicationResponse(validateEmail);
		
	}
	
	/**
	 * Update password.
	 *
	 * @param resetPasswordDto the reset password dto
	 * @return the application response
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Update customer password",notes = "Update customer password details",response = ApplicationResponse.class)
	@PostMapping("/updatePassword")
	public ApplicationResponse updatePassword(@ApiParam(value="Reset Password dto payload",required = true)  @RequestBody ResetPasswordDto resetPasswordDto) throws ApplicationException {
		logger.info("update Password Method Started");
		String updateCustomerPassword = customerService.updateCustomerPassword(resetPasswordDto);
		return getApplicationResponse(updateCustomerPassword);
		
	}
	
	/**
	 * Change password.
	 *
	 * @param changePassword the change password
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Change customer password",notes = "Change customer password details")
	@PostMapping("/change-password")
	public void changePassword( @ApiParam(value="Change password dto payload",required=true) @RequestBody(required = true) ChangePasswordDto changePassword) throws ApplicationException {
		customerService.changePassword(changePassword);
	}
	
	/**
	 * Save user profile url.
	 *
	 * @param customerId the customer id
	 * @param profileUrl the profile url
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Customer profile image",notes = "Save the url details of customer profile")
	@GetMapping("/save-customerProfileUrl")
	public void saveUserProfileUrl(@ApiParam(value="Customer id",required=true)  @RequestParam(name="customerId") Integer customerId,
		@ApiParam(value="Url details",required = true)	@RequestParam(name="url") String profileUrl) throws ApplicationException {
		customerService.saveUserProfileUrl(customerId, profileUrl);
	}
	
	
	/**
	 * Gets the profile picture.
	 *
	 * @param identity the identity
	 * @return the profile picture
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Customer profile fetch",notes = "Get the url details of customer profile",response = ApplicationResponse.class)
	@GetMapping("/get-profilepic")
	public ApplicationResponse getProfilePicture( @ApiParam(value = "Customer Identity",required = true)  @RequestParam(name="user_identity") String identity) throws ApplicationException {
		String userProfile= customerService.getProfilePicture(identity);
		return getApplicationResponse(userProfile);
	}

	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return CustomerController.class;
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {
	}


}
