package com.digitalpaper.service.impl;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.digitalpaper.config.property.EnvironmentProperties;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.controller.CustomerNotificationController;
import com.digitalpaper.dao.ICustomerNotificationDao;
import com.digitalpaper.dao.IDigitalPaperDao;
import com.digitalpaper.dao.IPaperDetailsDao;
import com.digitalpaper.service.ICustomerNotificationService;
import com.digitalpaper.transfer.object.dto.CustomerNotificationDto;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.entity.CustomerNotification;
import com.digitalpaper.transfer.object.entity.FileStorage;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;
import com.digitalpaper.utils.core.ApplicationUtils;

/**
 * The Class CustomerNotificationServiceImpl.
 */
@Service
@Transactional
public class CustomerNotificationServiceImpl implements ICustomerNotificationService {
	
	/** The Constant Customlogger. */
	private static final Logger Customlogger = LoggerFactory.getLogger(CustomerNotificationController.class);
    
    /** The mapper. */
    @Autowired
    private ModelMapper mapper;
	
	/** The customer notification dao. */
	@Autowired 
	private ICustomerNotificationDao customerNotificationDao;
	
	/** The digital paper dao. */
	@Autowired
	private IDigitalPaperDao digitalPaperDao;

	/** The messaging template. */
	@Autowired
	SimpMessagingTemplate messagingTemplate;
	
	/** The i paper details dao. */
	@Autowired
	private IPaperDetailsDao iPaperDetailsDao;
	
	/** The environment properties. */
	@Autowired
    private EnvironmentProperties environmentProperties;
	
	/** The logged in user context holder. */
	@Autowired 
	LoggedInUserContextHolder loggedInUserContextHolder;
	
	/**
	 * Gets the custom notification count.
	 *
	 * @return the custom notification count
	 */
	@Override
	public List<CustomerNotificationDto> getCustomNotificationCount() {
		Customlogger.info("Starting of CustomerNotificationServiceImpl getCustomNotificationCount()");
		Integer customerId=0;
		List<CustomerNotificationDto> customerNotificationdtoList=null;
	    customerId=loggedInUserContextHolder.getLoggedInUser().getId();		
		List<CustomerNotification> customerNotificationList= customerNotificationDao.getCustomNotificationCount(customerId);
	    customerNotificationdtoList= customerNotificationList.stream().map(customerNotification->convertCustomerNotificationEntityToDTO(customerNotification)).toList();
	    
		return customerNotificationdtoList;
	}
	
	/**
	 * Convert customer notification entity to DTO.
	 *
	 * @param customerNotification the customer notification
	 * @return the customer notification dto
	 */
	private CustomerNotificationDto convertCustomerNotificationEntityToDTO(CustomerNotification customerNotification) {
		CustomerNotificationDto customerNotificationDto = new CustomerNotificationDto();
		customerNotificationDto.setActedBy(customerNotification.getActedBy());
		customerNotificationDto.setCreatedBy(customerNotification.getCreatedBy());
		customerNotificationDto.setCreatedDate(ApplicationUtils.isValidateObject(customerNotification.getCreatedDate())?customerNotification.getCreatedDate().toString():null);
		customerNotificationDto.setIdentity(customerNotification.getIdentity());
		customerNotificationDto.setIsDeleted(customerNotification.getIsDeleted());
		customerNotificationDto.setModifiedBy(customerNotification.getModifiedBy());
		customerNotificationDto.setNotificationId(customerNotification.getNotificationId());
		customerNotificationDto.setNotificationMsg(customerNotification.getNotificationMsg());
		customerNotificationDto.setRead(customerNotification.isRead());
		customerNotificationDto.setToNotify(customerNotification.getToNotify());
		return customerNotificationDto;
	}
	
	
	/**
	 * Update notification by identity.
	 *
	 * @param identity the identity
	 * @return true, if successful
	 */
	@Override
	public boolean updateNotificationByIdentity(String identity) {
		CustomerNotification customerNotification =customerNotificationDao.getNotificationByIdentity(identity);
		if(ApplicationUtils.isValidateObject(customerNotification)) {
			customerNotification.setRead(true);
			customerNotificationDao.updateNotificationByIdentity(customerNotification);
			return true;
		}
		return false;
	}

	/**
	 * Gets the paper based onid.
	 *
	 * @param paperId the paper id
	 * @return the paper based onid
	 */
	@Override
	public PaperDetailsDto getpaperBasedOnid(String paperId) {
		UserInfo userDetails = loggedInUserContextHolder.getLoggedInUser();
		Integer customerId= userDetails.getId();
		
		PaperDetailsDto dto =  new PaperDetailsDto();		
		PaperDetails data = digitalPaperDao.getPaperticulerPaperBasedOnId(customerId, paperId);
		
		if(ApplicationUtils.isValidateObject(data)) {
			
			dto.setPdDigiltaPaperId(data.getPdDigitalPaperId());
			dto.setPdEffectiveFrom(data.getPdEffectiveFrom().toString());
			dto.setPdEmailId(data.getPdEmailId());
			dto.setPdExpireDate(data.getPdExpireDate().toString());
			dto.setPdInsuredName(data.getPdInsuredName());
			dto.setPdPhoneNumber(data.getPdPhoneNumber());
			dto.setPdPolicyNumber(data.getPdPolicyNumber());
			dto.setVdChassis(data.getVdChassis());
			dto.setVdLicensedToCarry(data.getVdLicensedToCarry());
			dto.setVdMake(data.getVdMake());
			dto.setVdModel(data.getVdModel());
			dto.setVdRegistrationNumber(data.getVdRegistrationNumber());
			dto.setVdUsage(data.getVdUsage());
			dto.setStatus(String.valueOf(data.getStatus()));
			dto.setIdentity(data.getIdentity());

			FileStorage paperImageById = iPaperDetailsDao.getPaperImageById(data.getPaperId(), ApplicationConstants.UPD_TYPE, ApplicationConstants.RP_TYPE);

			if (ApplicationUtils.isValidateObject(paperImageById)) {
				String url = environmentProperties.getDigitalPaperFilePath() + paperImageById.getUrl();
				dto.setFileURL(url);
			}
			
		}
		
		return dto;
	}
	
	}
	

