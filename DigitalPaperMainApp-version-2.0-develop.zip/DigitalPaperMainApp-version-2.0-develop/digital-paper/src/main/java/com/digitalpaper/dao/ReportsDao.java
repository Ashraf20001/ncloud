package com.digitalpaper.dao;

import java.time.LocalDateTime;
import java.util.List;

import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.PreviewReportDto;
import com.digitalpaper.transfer.object.dto.purchaseOrderStatusCountDto;
import com.digitalpaper.transfer.object.entity.Customer;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.entity.PurchaseOrderEntity;
import com.digitalpaper.transfer.object.entity.ReportColumnMapping;
import com.digitalpaper.transfer.object.entity.Reports;

/**
 * The Interface ReportsDao.
 */
public interface ReportsDao {

	/**
	 * Gets the report all data.
	 *
	 * @param userId the user id
	 * @return the report all data
	 * @throws ApplicationException the application exception
	 */
	List<Reports> getReportAllData(Integer userId) throws ApplicationException;

	/**
	 * Gets the mapping column.
	 *
	 * @param reportsId the reports id
	 * @return the mapping column
	 * @throws ApplicationException the application exception
	 */
	List<ReportColumnMapping> getMappingColumn(Integer reportsId) throws ApplicationException;

	/**
	 * Save report.
	 *
	 * @param report the report
	 * @return the integer
	 * @throws ApplicationException the application exception
	 */
	Integer saveReport(Reports report) throws ApplicationException;

	/**
	 * Gets the report data based on identity.
	 *
	 * @param identity the identity
	 * @return the report data based on identity
	 * @throws ApplicationException the application exception
	 */
	Reports getreportDataBasedOnIdentity(String identity) throws ApplicationException;

	/**
	 * Updat report.
	 *
	 * @param data the data
	 * @throws ApplicationException the application exception
	 */
	void updatReport(Reports data) throws ApplicationException;

	/**
	 * Save report mapping column.
	 *
	 * @param reportMappingColum the report mapping colum
	 * @throws ApplicationException the application exception
	 */
	void saveReportMappingColumn(ReportColumnMapping reportMappingColum) throws ApplicationException;

	/**
	 * Update report mapping column.
	 *
	 * @param reportMappingColum the report mapping colum
	 * @throws ApplicationException the application exception
	 */
	void updateReportMappingColumn(ReportColumnMapping reportMappingColum) throws ApplicationException;

	/**
	 * Gets the total count in purchase order.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @param companyId the company id
	 * @return the total count in purchase order
	 * @throws ApplicationException the application exception
	 */
	purchaseOrderStatusCountDto getTotalCountInPurchaseOrder( LocalDateTime fromDate, LocalDateTime toDate, Integer companyId) throws ApplicationException;

	/**
	 * Gets the total count in digital paper.
	 *
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @param companyId the company id
	 * @return the total count in digital paper
	 * @throws ApplicationException the application exception
	 */
	purchaseOrderStatusCountDto getTotalCountInDigitalPaper(LocalDateTime fromDate, LocalDateTime toDate, Integer companyId) throws ApplicationException;

	/**
	 * Gets the selected column count.
	 *
	 * @param reportsId the reports id
	 * @return the selected column count
	 * @throws ApplicationException the application exception
	 */
	Long getSelectedColumnCount(Integer reportsId) throws ApplicationException;

	/**
	 * Gets the preview data in purchase order.
	 *
	 * @param report the report
	 * @param companyId the company id
	 * @param min the min
	 * @param max the max
	 * @return the preview data in purchase order
	 * @throws ApplicationException the application exception
	 */
	List<PurchaseOrderEntity> getPreviewDataInPurchaseOrder(PreviewReportDto report,Integer companyId,Integer min,Integer max) throws ApplicationException;

	/**
	 * Gets the customer data.
	 *
	 * @param insuredName the insured name
	 * @return the customer data
	 * @throws ApplicationException the application exception
	 */
	Customer getcustomerData(String insuredName) throws ApplicationException;

	/**
	 * Gets the insured company list.
	 *
	 * @return the insured company list
	 * @throws ApplicationException the application exception
	 */
	List<Customer> getInsuredCompanyList() throws ApplicationException;

	/**
	 * Gets the preview in paper details.
	 *
	 * @param previewData the preview data
	 * @param companyId the company id
	 * @param min the min
	 * @param max the max
	 * @return the preview in paper details
	 * @throws ApplicationException the application exception
	 */
	List<PaperDetails> getPreviewInPaperDetails(PreviewReportDto previewData, Integer companyId,Integer min,Integer max) throws ApplicationException;

	/**
	 * Gets the reports data based on user id.
	 *
	 * @param userId the user id
	 * @return the reports data based on user id
	 * @throws ApplicationException the application exception
	 */
	List<Reports> getreportsDataBasedOnUserId(Integer userId) throws ApplicationException;

	/**
	 * Gets the report column.
	 *
	 * @param columnName the column name
	 * @param reportsId the reports id
	 * @return the report column
	 * @throws ApplicationException the application exception
	 */
	ReportColumnMapping getreportColumn(String columnName, Integer reportsId) throws ApplicationException;

	/**
	 * Gets the preview in paper details count.
	 *
	 * @param previewData the preview data
	 * @param insuredCompanyId the insured company id
	 * @return the preview in paper details count
	 * @throws ApplicationException the application exception
	 */
	Long getPreviewInPaperDetailsCount(PreviewReportDto previewData, Integer insuredCompanyId)throws ApplicationException;

	/**
	 * Gets the preview data in purchase order count.
	 *
	 * @param previewData the preview data
	 * @param insuredCompanyId the insured company id
	 * @return the preview data in purchase order count
	 * @throws ApplicationException the application exception
	 */
	Long getPreviewDataInPurchaseOrderCount(PreviewReportDto previewData, Integer insuredCompanyId)  throws ApplicationException;


}
