package com.digitalpaper.file.handler.service.impl;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.commons.text.WordUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.digitalpaper.config.DigitalPaperCache;
import com.digitalpaper.config.property.EnvironmentProperties;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.dao.IPaperDetailsDao;
import com.digitalpaper.file.handler.service.IEmailService;
import com.digitalpaper.restemplate.service.IRestTemplateService;
import com.digitalpaper.transfer.object.dto.CompanyDto;
import com.digitalpaper.transfer.object.dto.MailRequestDto;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;
import com.digitalpaper.transfer.object.dto.StockDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.entity.FileStorage;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;
import com.digitalpaper.utils.EmailProducer;
import com.digitalpaper.utils.core.ApplicationUtils;
import com.fasterxml.jackson.core.JsonProcessingException;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;

/**
 * The Class EmailServiceImpl.
 */
@Service
@Transactional
public class EmailServiceImpl implements IEmailService {

	/** The sender. */
	@Autowired
	private JavaMailSender sender;

	/** The email producer. */
	@Autowired
	private EmailProducer emailProducer;

	/** The config. */
	@Autowired
	private Configuration config;

	/** The environment properties. */
	@Autowired
	private EnvironmentProperties environmentProperties;

	/** The i paper details dao. */
	@Autowired
	private IPaperDetailsDao iPaperDetailsDao;

	/** The logged in user context holder. */
	@Autowired
	private LoggedInUserContextHolder loggedInUserContextHolder;
	
	/** The rest template service. */
	@Autowired
	private IRestTemplateService restTemplateService;

	/** The Constant Sender_Template. */
	public static final String Sender_Template = "mail send to : ";
	
	/** The Constant Sender_Subject. */
	public static final String Sender_Subject = "Digital Paper : ";
	
	/** The Constant Error_Send_Template. */
	public static final String Error_Send_Template = "Mail Sending failure : ";
	
	/** The Constant MINIMUM_PAPER_REMAINDER_SUBJECT. */
	public static final String MINIMUM_PAPER_REMAINDER_SUBJECT="Gentle Reminder: ";

	/** The Constant Template_Folder_Path. */
	public static final String Template_Folder_Path = "/Tempplate";
	


	/**
	 * Send email throw kafka.
	 *
	 * @param request the request
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws TemplateException the template exception
	 */
	@Override
	public void sendEmailThrowKafka(MailRequestDto request) throws IOException, TemplateException {

		MimeMessage message = sender.createMimeMessage();
		try {
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());

			config.setClassForTemplateLoading(this.getClass(), Template_Folder_Path);
			Template template = config.getTemplate(request.getTemplateName());
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(template, request.getModel());
			
			if(ApplicationUtils.isValidateObject(request.getFileURL())){
			helper.addAttachment(request.getAttachmentName(),request.getFileURL());
			}
			
			helper.setTo(request.getTo());
			helper.setText(html, true);
			helper.setSubject(request.getSubject());
			helper.setFrom(environmentProperties.getFromEMail());
			sender.send(message);

		} catch (MessagingException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Sets the email part.
	 *
	 * @param paperDetailsDto the paper details dto
	 * @return the string
	 */
	@Override
	public String setEmailPart(List<PaperDetailsDto> paperDetailsDto) {

		String status = null;
		UserInfo userDetails = loggedInUserContextHolder.getLoggedInUser();
		String companyName = userDetails.getCompanyName();
		
		HashMap<Integer, String> companyList = DigitalPaperCache.getCompanyList();

		sendMailForDigitalPapers(paperDetailsDto, companyName, companyList);
		return null;
	}

	/**
	 * Send mail for digital papers.
	 *
	 * @param paperDetailsDto the paper details dto
	 * @param companyName the company name
	 * @param companyList the company list
	 */
	public void sendMailForDigitalPapers(List<PaperDetailsDto> paperDetailsDto, String companyName,
			HashMap<Integer, String> companyList) {
		for (PaperDetailsDto paperDetails : paperDetailsDto) {
			
			if(!ApplicationUtils.isValidString(companyName)) {
				companyName = companyList.get(paperDetails.getCompanyId());
			}

			MailRequestDto request = new MailRequestDto();
			request.setTo(paperDetails.getPdEmailId());
			request.setName(paperDetails.getPdInsuredName());
			request.setSubject(Sender_Subject + paperDetails.getPdDigiltaPaperId());
			request.setFrom(environmentProperties.getFromEMail());

			FileStorage file = iPaperDetailsDao.getPaperImageById(paperDetails.getDigitalPaperId(),
					ApplicationConstants.UPD_TYPE, ApplicationConstants.RP_TYPE);
			if (ApplicationUtils.isValidateObject(file)) {

				String url = environmentProperties.getFileUploadPath() + "/OG_IMAGE/" + file.getUrl();

				File img = new File(url);
				request.setFileURL(img);

				Map<String, Object> model = new HashMap<>();
				model.put("Name", WordUtils.capitalize(paperDetails.getPdInsuredName()));
				model.put("paperNumber", paperDetails.getPdDigiltaPaperId());
				model.put("CompanyName", WordUtils.capitalize(companyName));
				model.put("policyNo", paperDetails.getPdPolicyNumber());
				model.put("registrationNo", paperDetails.getVdRegistrationNumber());
				model.put("link", environmentProperties.getCustomerPortalUrl());

				request.setModel(model);
				request.setAttachmentName(ApplicationConstants.ATTACHMENT_TEMPLATE);
				request.setTemplateName(ApplicationConstants.DIGITAL_EMAIL_TEMPLATE);	
				
					try {
						emailProducer.sendEmail(request);
					} catch (JsonProcessingException e) {
						e.printStackTrace();
					}
			}
		}
	}

	/**
	 * Sets the email for existing customer.
	 *
	 * @param paperDetails the paper details
	 * @return the string
	 * @throws JsonProcessingException the json processing exception
	 */
	@Override
	public String setEmailForExistingCustomer(PaperDetails paperDetails) throws JsonProcessingException {

		String status = null;
		UserInfo userDetails = loggedInUserContextHolder.getLoggedInUser();
		String companyName = userDetails.getCompanyName();

		MailRequestDto request = new MailRequestDto();
		request.setTo(paperDetails.getPdEmailId());
		request.setName(paperDetails.getPdInsuredName());
		request.setSubject(Sender_Subject + paperDetails.getPdDigitalPaperId());
		request.setFrom(environmentProperties.getSendEmailName());

		FileStorage file = iPaperDetailsDao.getPaperImageById(paperDetails.getPaperId(), ApplicationConstants.UPD_TYPE,
				ApplicationConstants.RP_TYPE);
		if (ApplicationUtils.isValidateObject(file)) {

			String url = environmentProperties.getFileUploadPath() + "/OG_IMAGE/" + file.getUrl();

			File img = new File(url);
			request.setFileURL(img);
			
			Map<String, Object> model = new HashMap<>();
			model.put("Name", WordUtils.capitalize(paperDetails.getPdInsuredName()));
			model.put("paperNumber", paperDetails.getPdDigitalPaperId());
			model.put("CompanyName", WordUtils.capitalize(companyName));
			model.put("policyNo", paperDetails.getPdPolicyNumber());
			model.put("registrationNo", paperDetails.getVdRegistrationNumber());
			model.put("link", environmentProperties.getCustomerPortalUrl());
			
			request.setModel(model);
			request.setAttachmentName(ApplicationConstants.ATTACHMENT_TEMPLATE);
			request.setTemplateName(ApplicationConstants.DIGITAL_EMAIL_TEMPLATE);
			emailProducer.sendEmail(request);
			
		}
		return null;
	}

	/**
	 * Sets the email for existing customer from bulk upload.
	 *
	 * @param paperDetails the paper details
	 * @param userDetails the user details
	 * @return the string
	 * @throws JsonProcessingException the json processing exception
	 */
	@Override
	public String setEmailForExistingCustomerFromBulkUpload(PaperDetails paperDetails, UserInfo userDetails) throws JsonProcessingException {
		String companyName = userDetails.getCompanyName();

		MailRequestDto request = new MailRequestDto();
		request.setTo(paperDetails.getPdEmailId());
		request.setName(paperDetails.getPdInsuredName());
		request.setSubject(Sender_Subject + paperDetails.getPdDigitalPaperId());
		request.setFrom(environmentProperties.getSendEmailName());

		FileStorage file = iPaperDetailsDao.getPaperImageById(paperDetails.getPaperId(), ApplicationConstants.UPD_TYPE,
				ApplicationConstants.RP_TYPE);
		if (ApplicationUtils.isValidateObject(file)) {

			String url = environmentProperties.getFileUploadPath() + "/OG_IMAGE/" + file.getUrl();

			File img = new File(url);
			request.setFileURL(img);
			
			Map<String, Object> model = new HashMap<>();
			model.put("Name", WordUtils.capitalize(paperDetails.getPdInsuredName()));
			model.put("paperNumber", paperDetails.getPdDigitalPaperId());
			model.put("CompanyName", WordUtils.capitalize(companyName));
			model.put("policyNo", paperDetails.getPdPolicyNumber());
			model.put("registrationNo", paperDetails.getVdRegistrationNumber());
			model.put("link", environmentProperties.getCustomerPortalUrl());
			
			request.setModel(model);
			request.setAttachmentName(ApplicationConstants.ATTACHMENT_TEMPLATE);
			request.setTemplateName(ApplicationConstants.DIGITAL_EMAIL_TEMPLATE);
		    emailProducer.sendEmail(request);
			
		}
		return null;
	}

	/**
	 * Stock remainder mail.
	 *
	 * @param request the request
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws TemplateException the template exception
	 */
	@Override
	public void stockRemainderMail(StockDto request) throws IOException, TemplateException {
		CompanyDto companyData = restTemplateService.getCompanyDto(request.getCompanyId());

		MimeMessage message = sender.createMimeMessage();

		try {
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());

			config.setClassForTemplateLoading(this.getClass(), Template_Folder_Path);
			Template template = config.getTemplate(ApplicationConstants.STOCK_REMINDER_TEMPLATE);
			Map<String, Object> model = new HashMap<>();
			model.put("CompanyName", companyData.getName());
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(template, model);
			helper.setTo(companyData.getEmail());
			helper.setText(html, true);
			helper.setSubject(MINIMUM_PAPER_REMAINDER_SUBJECT + companyData.getName() + " Quantity");
			helper.setFrom(environmentProperties.getFromEMail());
			sender.send(message);
		} catch (MessagingException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Send email in customer portal.
	 *
	 * @param paperDetails the paper details
	 * @param imageFile the image file
	 */
	@Override
	public void sendEmailInCustomerPortal(PaperDetails paperDetails, File imageFile) {
		MimeMessage message = sender.createMimeMessage();
		
		try {
			MimeMessageHelper helper = new MimeMessageHelper(message, true);

			helper.addAttachment("Digital Paper.png", imageFile);
			helper.setTo(paperDetails.getPdEmailId());
			helper.setSubject("Digital Paper");
			helper.setFrom(environmentProperties.getFromEMail());
			helper.setText("");
			sender.send(message);

		} catch (MessagingException e) {
			e.printStackTrace();
		}


		
	}


}
