package com.digitalpaper.utils;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import javax.imageio.ImageIO;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.aspose.pdf.Document;
import com.aspose.pdf.devices.JpegDevice;
import com.aspose.pdf.devices.Resolution;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.dao.IPaperDetailsDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.entity.FileStorage;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.utils.core.ApplicationUtils;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.itextpdf.html2pdf.HtmlConverter;

/**
 * @author Viswanathan
 *
 */
@Component
public class PaperGenerationUtils {

	/**
	 * filePath  dp_template-path
	 */
	@Value("${dpmainapp.file-upload-path}")
	private String filePath;
	
	/** The dp template folder. */
	@Value("${dpmainapp.dp-template-path}")
	private String dp_template_folder;

	/**
	 * downloadURL
	 */
	@Value("${dpmainapp.qr-download-url}")
	private String downloadURL;

	/**
	 * IPaperDetailsDao
	 */
	@Autowired
	private IPaperDetailsDao iPaperDetailsDao;
	
	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(PaperGenerationUtils.class);

	/**
	 * @param paperDetails
	 * @throws IOException
	 * @throws ApplicationException 
	 */
	@org.springframework.transaction.annotation.Transactional(rollbackFor = ApplicationException.class)
	public Boolean generateDigitalPaper(PaperDetails paperDetails, UserInfo userDetails) throws ApplicationException {
		try {
			String qrCode = null;
			Path uploadPath = Paths.get(filePath);
			if (!Files.exists(uploadPath)) {
				Files.createDirectories(uploadPath);
			}
			qrCode = generateQRCode(paperDetails.getIdentity(), paperDetails.getPdDigitalPaperId());
			if (Boolean.FALSE.equals(ApplicationUtils.isValidString(qrCode))) {
				logger.info("QR generation failed");
				throw new ApplicationException(ErrorCodes.PAPER_GENERATION_FAILED);
			}
			String paperSequenceId = paperDetails.getPdDigitalPaperId();
			createFolderIfNotExists("PDF");
			String pdfFileName = filePath + File.separator + "PDF" + File.separator + "DP_FS_PDF_" + paperSequenceId
					+ ApplicationConstants.UNDERSCORE + System.currentTimeMillis() + ApplicationConstants.PDF;
			String finalTemplate = refineHTML(paperDetails, qrCode,userDetails);
			OutputStream fileOutputStream = null;
			fileOutputStream = new FileOutputStream(pdfFileName);

			HtmlConverter.convertToPdf(finalTemplate, fileOutputStream);
			convertPdfIntoImage(pdfFileName, paperSequenceId, paperDetails.getPaperId());
			return Boolean.TRUE;
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.toString());
			logger.info("Digital paper generation failed");
			throw new ApplicationException(ErrorCodes.PAPER_GENERATION_FAILED);
		}
		
	}

	/**
	 * @param paperDetails
	 * @param qrCode
	 * @return
	 * @throws IOException 
	 */
	private String refineHTML(PaperDetails paperDetails, String qrCode, UserInfo userDetails) throws IOException {
		
		String folderPath = dp_template_folder;
		String fileName = ApplicationConstants.FILE_NAME+1+".txt";
		
		String configuredHtml= null;
		String filePath = folderPath + File.separator + fileName;
		
		 Path path = Paths.get(filePath);
		 String fileContent = Files.readString(path);
		 configuredHtml = fileContent;
		Map<String, String> replacements = setReplacementMap(paperDetails, qrCode,userDetails);

		String finalTemplate = replacePlaceHoldersInRawTemplate(configuredHtml, replacements);
		return finalTemplate;
	}

	/**
	 * @param folder
	 * @throws IOException
	 */
	private void createFolderIfNotExists(String folder) throws IOException {
		Path path = Paths.get(filePath + File.separator + folder);
		if (!Files.exists(path)) {
			Files.createDirectories(path);
		}
	}

	/**
	 * @param paperId
	 * @param paperImage
	 */
	private void buildObjectAndSaveFile(Integer paperId, String paperImage) {
		FileStorage storage = new FileStorage();
		storage.setUploadType(ApplicationConstants.UPD_TYPE);
		storage.setReportType(ApplicationConstants.RP_TYPE);
		storage.setReferenceId(paperId);
		storage.setStorageType("LOCAL");
		storage.setUrl(paperImage);
		storage.setCreatedDate(LocalDateTime.now().toString());
		storage.setDeleted(false);
		try {
			iPaperDetailsDao.savePaperImage(storage);
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param paperDetails
	 * @return
	 */
	private static Map<String, String> setReplacementMap(PaperDetails paperDetails, String qrCode, UserInfo loggedInUser) {
		Map<String, String> replacements = new HashMap<>();
		replacements.put("@DigitalPaperNo", paperDetails.getPdDigitalPaperId());
		replacements.put("@InuredName", paperDetails.getPdInsuredName());
		DateTimeFormatter.ofPattern("dd/MM/yyyy").format(paperDetails.getPdEffectiveFrom());
		replacements.put("@EffectiveFrom",
				DateTimeFormatter.ofPattern("dd/MM/yyyy").format(paperDetails.getPdEffectiveFrom()));
		replacements.put("@PolicyNumber", paperDetails.getPdPolicyNumber());
		replacements.put("@EffectiveTo",
				DateTimeFormatter.ofPattern("dd/MM/yyyy").format(paperDetails.getPdExpireDate()));
		replacements.put("@RegistrationNo", paperDetails.getVdRegistrationNumber());
		replacements.put("@ChassisNo", paperDetails.getVdChassis());
		replacements.put("@LicensedToCarry", paperDetails.getVdLicensedToCarry());
		replacements.put("@Make", paperDetails.getVdMake());
		replacements.put("@Model", paperDetails.getVdModel());
		replacements.put("@Usage", paperDetails.getVdUsage());
		replacements.put("@Insurer", loggedInUser.getCompanyName());
		replacements.put("@UserName", loggedInUser.getUsername());
		replacements.put(
				"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQxlvpcbDjgdhZeGmuf0fEOhofZJt8AYp8YPA&amp;usqp=CAU",
				qrCode);
		return replacements;
	}

	/**
	 * @param inputString
	 * @param replacements
	 * @return
	 */
	public static String replacePlaceHoldersInRawTemplate(String inputString, Map<String, String> replacements) {
		for (Map.Entry<String, String> entry : replacements.entrySet()) {
			String dynamicText = entry.getKey();
			String replacementText = entry.getValue();
			inputString = inputString.replace(dynamicText, replacementText);
		}
		return inputString;
	}

	/**
	 * @param paperId
	 * @return
	 * @throws IOException
	 */
	public String generateQRCode(String paperIdentity, String paperNumber) throws IOException {
		String qrCodeText = downloadURL + paperIdentity;
		createFolderIfNotExists("QR");
		String fileName = filePath + File.separator + "QR" + File.separator + "DP_QR_" + paperNumber
				+ ApplicationConstants.UNDERSCORE + System.currentTimeMillis() + ApplicationConstants.PNG;
		int size = 800;
		String fileType = "png";
		File qrFile = new File(fileName);
		try {
			createQRImage(qrFile, qrCodeText, size, fileType);
		} catch (WriterException | IOException e) {
			e.printStackTrace();
		}
		return fileName;
	}

	/**
	 * @param qrFile
	 * @param qrCodeText
	 * @param size
	 * @param fileType
	 * @throws WriterException
	 * @throws IOException
	 */
	private static void createQRImage(File qrFile, String qrCodeText, int size, String fileType)
			throws WriterException, IOException {
		Hashtable<EncodeHintType, ErrorCorrectionLevel> hintMap = new Hashtable<>();
		hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
		QRCodeWriter qrCodeWriter = new QRCodeWriter();
		com.google.zxing.common.BitMatrix byteMatrix = qrCodeWriter.encode(qrCodeText, BarcodeFormat.QR_CODE, size,
				size, hintMap);
		int matrixWidth = byteMatrix.getWidth();
		BufferedImage image = new BufferedImage(matrixWidth, matrixWidth, BufferedImage.TYPE_INT_RGB);
		image.createGraphics();
		Graphics2D graphics = (Graphics2D) image.getGraphics();
		graphics.setColor(Color.WHITE);
		graphics.fillRect(0, 0, matrixWidth, matrixWidth);
		graphics.setColor(Color.BLACK);
		for (int i = ApplicationConstants.ZERO; i < matrixWidth; i++) {
			for (int j = ApplicationConstants.ZERO; j < matrixWidth; j++) {
				if (byteMatrix.get(i, j)) {
					graphics.fillRect(i, j, ApplicationConstants.ONE, ApplicationConstants.ONE);
				}
			}
		}
		ImageIO.write(image, fileType, qrFile);
	}

	/**
	 * @param fileName
	 * @throws IOException
	 */
	public Boolean revokeDigitalPaper(String fileName) throws IOException {
		String path = filePath + "/OG_IMAGE/" + fileName;
		File originalFile = new File(path);
		BufferedImage originalImage = ImageIO.read(originalFile);
		BufferedImage watermarkedImage = new BufferedImage(originalImage.getWidth(), originalImage.getHeight(),
				BufferedImage.TYPE_INT_RGB);

		Graphics2D graphics2D = watermarkedImage.createGraphics();
		graphics2D.drawImage(originalImage, 0, 0, null);
		String watermarkText = "REVOKED";
		Font watermarkFont = new Font("Arial", Font.BOLD, 170);
		Color watermarkColor = new Color(255, 0, 0);
		graphics2D.setFont(watermarkFont);
		graphics2D.setColor(watermarkColor);

		FontMetrics fontMetrics = graphics2D.getFontMetrics(watermarkFont);
		int watermarkWidth = fontMetrics.stringWidth(watermarkText);
		int watermarkHeight = fontMetrics.getHeight();
		int imageWidth = watermarkedImage.getWidth();
		int imageHeight = watermarkedImage.getHeight();
		int x = ((imageWidth - watermarkWidth) / 2) + 80;
		int y = ((imageHeight + watermarkHeight) / 2) + 350;

		double angle = Math.toRadians(-30);
		graphics2D.rotate(angle, x, y);
		graphics2D.drawString(watermarkText, x, y);
		graphics2D.rotate(-angle, x, y);

		File output = new File(path);
		ImageIO.write(watermarkedImage, "png", output);
		graphics2D.dispose();
		System.err.println("paper revoked");
		return Boolean.TRUE;
	}

	/**
	 * @param pdfFileName
	 * @param paperSequenceId
	 * @param paperId
	 * @throws IOException
	 */
	public void convertPdfIntoImage(String pdfFileName, String paperSequenceId, Integer paperId) throws IOException {
		File originalFile = new File(pdfFileName);
		try (PDDocument document = PDDocument.load(originalFile)) {
            PDFRenderer pdfRenderer = new PDFRenderer(document);
            BufferedImage originalImage = pdfRenderer.renderImageWithDPI(0, 300); // Render the first page of the PDF at 300 DPI
            int cropTop = 130;
            int cropBottom = originalImage.getHeight() - 1300;
            Rectangle cropRegion = new Rectangle(cropTop, cropTop, originalImage.getWidth() - 500, cropBottom - cropTop);
            BufferedImage croppedImage = originalImage.getSubimage(cropRegion.x, cropRegion.y, cropRegion.width, cropRegion.height);
            createFolderIfNotExists("OG_IMAGE");
            String generatedFileName = "OG_" + paperSequenceId + ApplicationConstants.UNDERSCORE
					+ System.currentTimeMillis() + ApplicationConstants.PNG;
			String paperImage = filePath + File.separator + "OG_IMAGE" + File.separator + generatedFileName;
			File outputfile = new File(paperImage);
            ImageIO.write(croppedImage, "png", outputfile);
            buildObjectAndSaveFile(paperId, generatedFileName);
	}catch(Exception e) {
		e.printStackTrace();
	}
	}

}


