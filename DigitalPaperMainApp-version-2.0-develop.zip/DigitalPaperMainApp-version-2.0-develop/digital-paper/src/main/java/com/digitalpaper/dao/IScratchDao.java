package com.digitalpaper.dao;

import java.util.List;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.entity.Scratch;

/**
 * The Interface IScratchDao.
 */
public interface IScratchDao {
	
	/**
	 * 
	 * @param max
	 * @param entityColumnList
	 * @param isError
	 * @param filterOrSortingVo
	 * @return
	 */
	public List<Object[]> getScratchEntityByBulkId(Integer max, List<String> entityColumnList,Boolean isError, List<FilterOrSortingVo> filterOrSortingVo,Integer skip,Integer limit) throws ApplicationException;
	/**
	 * 
	 * @param id
	 * @return
	 */
	public Long getTotalScratchCountByBulkId(Integer id);
	/**
	 * 
	 * @param id
	 * @param isError
	 * @return
	 */
	public Long getScratchCountByBulkId(Integer id,Boolean isError);
	/**
	 * 
	 * @param scratchIdentity
	 * @return
	 */
	public Scratch getScratchDataByIdentity(String scratchIdentity);
	/**
	 * 
	 * @param scratchData
	 */
	void deleteScratchData(Scratch scratchData);
	
	/**
	 * Gets the total scratch list by by bulk id.
	 *
	 * @param bulkUploadId the bulk upload id
	 * @return the total scratch list by by bulk id
	 */
	public List<Scratch> getTotalScratchListByByBulkId(Integer bulkUploadId);
}
