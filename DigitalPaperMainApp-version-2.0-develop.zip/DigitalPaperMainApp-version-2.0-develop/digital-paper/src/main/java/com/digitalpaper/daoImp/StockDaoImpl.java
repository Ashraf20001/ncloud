package com.digitalpaper.daoImp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.digitalpaper.config.DigitalPaperCache;
import com.digitalpaper.config.common.base.dao.BaseDao;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.IStockDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.AuthorityStockDto;
import com.digitalpaper.transfer.object.dto.StockCountDto;
import com.digitalpaper.transfer.object.entity.PaymentDetails;
import com.digitalpaper.transfer.object.entity.PurchaseOrderEntity;
import com.digitalpaper.transfer.object.entity.Stock;
import com.digitalpaper.transfer.object.entity.StockFileMapping;
import com.digitalpaper.transfer.object.entity.StockPool;
import com.digitalpaper.utils.core.ApplicationUtils;

/**
 * The Class StockDaoImpl.
 */
@Repository
@Transactional
public class StockDaoImpl extends BaseDao implements IStockDao{

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(StockDaoImpl.class);
	
	/**
	 * Gets the stock data.
	 *
	 * @param companyId the company id
	 * @return the stock data
	 */
	@Override
	public Stock getStockData(Integer companyId) {
		
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<Stock> criteria = builder.createQuery(Stock.class);
        Root<Stock> root = criteria.from(Stock.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.COMPANY_ID), companyId)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        return (Stock) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);

		
	}

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
		
	}

	
	/**
	 * Gets the purchase details.
	 *
	 * @return the purchase details
	 */
	@Override
	public List<PurchaseOrderEntity> getPurchaseDetails() {
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<PurchaseOrderEntity> criteria = builder.createQuery(PurchaseOrderEntity.class);
        Root<PurchaseOrderEntity> root = criteria.from(PurchaseOrderEntity.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        return ( List<PurchaseOrderEntity>) getResultList(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Purchase ordersave.
	 *
	 * @param purchaseOrder the purchase order
	 * @return the integer
	 */
	@Override
	public Integer purchaseOrdersave(PurchaseOrderEntity purchaseOrder) {
		try {
			return save(purchaseOrder,TableConstants.PURCHASE_ORDER);
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	/**
	 * Save file data for order.
	 *
	 * @param stockFileMapping the stock file mapping
	 * @return the integer
	 */
	@Override
	public Integer saveFileDataForOrder(StockFileMapping stockFileMapping) {
		try {
			 return save(stockFileMapping,TableConstants.STOCK_FILE_MAPPING);
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
		return null;
		
	}

	/**
	 * Payment details save.
	 *
	 * @param paymentDetails the payment details
	 * @return the integer
	 */
	@Override
	public Integer paymentDetailsSave(PaymentDetails paymentDetails) {
		try {
			return save(paymentDetails,TableConstants.PAYMENT_DETAILS);
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Stock save.
	 *
	 * @param stockData the stock data
	 * @return the integer
	 */
	@Override
	public Integer stockSave(Stock stockData) {
		try {
			return save(stockData,TableConstants.STOCK);
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Gets the purchase order data by order id.
	 *
	 * @param orderId the order id
	 * @return the purchase order data by order id
	 */
	@Override
	public PurchaseOrderEntity getpurchaseOrderDataByOrderId(Integer orderId) {
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<PurchaseOrderEntity> criteria = builder.createQuery(PurchaseOrderEntity.class);
        Root<PurchaseOrderEntity> root = criteria.from(PurchaseOrderEntity.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ORDER_ID), orderId)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        return (PurchaseOrderEntity) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);
	}

	/**
	 * Purchase order update.
	 *
	 * @param purchaseOrder2 the purchase order 2
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void purchaseOrderUpdate(PurchaseOrderEntity purchaseOrder2) throws ApplicationException {
		update(purchaseOrder2);
		
		
	}

	/**
	 * Gets the payment details based on order id.
	 *
	 * @param orderId the order id
	 * @return the payment details based on order id
	 */
	@Override
	public PaymentDetails getPaymentDetailsBasedOnOrderId(Integer orderId) {
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<PaymentDetails> criteria = builder.createQuery(PaymentDetails.class);
        Root<PaymentDetails> root = criteria.from(PaymentDetails.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ORDER_ID).get(TableConstants.ORDER_ID), orderId)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        return (PaymentDetails) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);
	}

	/**
	 * Update payment details.
	 *
	 * @param paymentDetails2 the payment details 2
	 */
	@Override
	public void updatePaymentDetails(PaymentDetails paymentDetails2) {
		update(paymentDetails2);
		
	}

	/**
	 * Gets the purchase order by order id.
	 *
	 * @param orderId the order id
	 * @return the purchase order by order id
	 */
	@Override
	public PurchaseOrderEntity getpurchaseOrderByOrderId(Integer orderId) {
	CriteriaBuilder builder = getCriteriaBuilder();
    CriteriaQuery<PurchaseOrderEntity> criteria = builder.createQuery(PurchaseOrderEntity.class);
    Root<PurchaseOrderEntity> root = criteria.from(PurchaseOrderEntity.class);
    criteria.select(root);
    List<Predicate> predicates = new ArrayList<>();
    predicates.add(builder.and(builder.equal(root.get(TableConstants.ORDER_ID), orderId)));
    predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
    return (PurchaseOrderEntity) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);
	}

	/**
	 * Update stock.
	 *
	 * @param stockData the stock data
	 */
	@Override
	public void updateStock(Stock stockData) {
		
		update(stockData);
	}

	/**
	 * Gets the stock pool data.
	 *
	 * @param poolId the pool id
	 * @return the stock pool data
	 */
	@Override
	public StockPool getStockPoolData(Integer poolId) {
		CriteriaBuilder builder = getCriteriaBuilder();
	    CriteriaQuery<StockPool> criteria = builder.createQuery(StockPool.class);
	    Root<StockPool> root = criteria.from(StockPool.class);
	    criteria.select(root);
	    List<Predicate> predicates = new ArrayList<>();
	    predicates.add(builder.and(builder.equal(root.get(TableConstants.STOCK_POOL_ID), poolId)));
	    predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
	    return (StockPool) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);
	}
	
	/**
	 * Save allocation user type in stock pool.
	 *
	 * @param stockPool the stock pool
	 */
	@Override
	public void saveAllocationUserTypeInStockPool(StockPool stockPool) {
		try {
			save(stockPool,TableConstants.STOCK_POOL);
		} catch (ApplicationException e) {
			logger.info(e.getMessage());
		}
	}

	/**
	 * @param companyNameMaping
	 * @param skip
	 * @param limit
	 * @param filterVo
	 * @param isCount
	 * @return
	 * @throws ApplicationException
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<AuthorityStockDto> getStockAndCountList(Map<Integer, String> companyNameMaping, Integer skip,
		Integer limit, List<Integer> companyIds,List<FilterOrSortingVo> filterVo, Boolean isCount, String searchValue) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<AuthorityStockDto> criteria = builder.createQuery(AuthorityStockDto.class);
		Root<Stock> root = criteria.from(Stock.class);
		
		Expression<String> companyIdExpression = (builder.<String>selectCase()
				.when(builder.greaterThan(root.get(TableConstants.COMPANY_ID), 0), ""));
		Expression<Integer> availableCount = (builder.diff(root.get(TableConstants.STOCK_COUNT),
				root.get(TableConstants.USED_COUNT)));
		
		criteria.multiselect(root.get(TableConstants.COMPANY_ID), companyIdExpression,
				root.get(TableConstants.STOCK_COUNT), availableCount, root.get(TableConstants.USED_COUNT));
		
		List<Predicate> predicates = new ArrayList<>();
		
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		predicates.add(builder.and(builder.greaterThanOrEqualTo(root.get(TableConstants.USED_COUNT), 1)));
		Expression<String> parentExpression = root.get(TableConstants.COMPANY_ID);
		Predicate parentPredicate = parentExpression.in(companyNameMaping.keySet());
		predicates.add(builder.and(parentPredicate));
		
		if(ApplicationUtils.isValidList(companyIds)) {		
			predicates.add(root.get(TableConstants.COMPANY_ID).in(companyIds));
		}
		
		if (ApplicationUtils.isValidList(filterVo)) {
			List<FilterOrSortingVo> companyFilter = filterVo.stream()
					.filter(value -> value.getColumnName().equals(ApplicationConstants.FILTER_COLUMN_NAME)
							&& ApplicationUtils.isValidString(value.getValue()) )
					.collect(Collectors.toList());
			if (ApplicationUtils.isValidateObject(companyFilter)) {
				for (FilterOrSortingVo filter : companyFilter) {
					if (filter.getCondition().equals(ApplicationConstants.IN)) {
						String companyNameExpression = filter.getValue();
						Integer filterCompanyId = null;
						List<Integer> listOfCompanyIds = new ArrayList<>();
						for (Map.Entry<Integer, String> entry : companyNameMaping.entrySet()) {
							if (entry.getValue().toLowerCase().contains(companyNameExpression.toLowerCase())) {
								filterCompanyId = entry.getKey();
								listOfCompanyIds.add(filterCompanyId);
							}
						}
						predicates.add(builder.and(root.get(TableConstants.COMPANY_ID).in(listOfCompanyIds)));
					}
				}
			}
			for (FilterOrSortingVo filterSort : filterVo) {
				if (filterSort.getColumnName().equals(TableConstants.STOCK_COUNT)) {
					if (!(filterSort.getValue() == null) || !(filterSort.getValue2() == null)) {
						List<FilterOrSortingVo> filteredList = filterVo.stream()
								.filter(vo -> vo.getColumnName().equals(TableConstants.STOCK_COUNT))
								.collect(Collectors.toList());
						List<Predicate> filterPredicates = getFilterPrdicets(filteredList, root, builder, criteria);
						predicates.addAll(filterPredicates);
					}

				} else if (filterSort.getColumnName().equals(TableConstants.USED_COUNT)) {
					if (!(filterSort.getValue() == null) || !(filterSort.getValue2() == null)) {
						List<FilterOrSortingVo> filteredList = filterVo.stream()
								.filter(vo -> vo.getColumnName().equals(TableConstants.USED_COUNT))
								.collect(Collectors.toList());
						List<Predicate> filterPredicates = getFilterPrdicets(filteredList, root, builder, criteria);
						predicates.addAll(filterPredicates);
					}
				}
				getSortingPredicates(filterVo, builder, criteria, root, availableCount, predicates, filterSort);
			}
		} 
		else {
			List<Predicate> filterPredicates = getFilterPrdicets(filterVo, root, builder, criteria);
			predicates.addAll(filterPredicates);
		}
		List<AuthorityStockDto> result = new ArrayList<>();
		if (isCount.equals(Boolean.FALSE) && !ApplicationUtils.isValidString(searchValue) && !ApplicationUtils.isValidList(filterVo)) {
			result = (List<AuthorityStockDto>) getResultList(
					createQuery(builder, criteria, root, predicates).setFirstResult(skip).setMaxResults(limit));
		} else {
			result = (List<AuthorityStockDto>) getResultList(createQuery(builder, criteria, root, predicates));
		}
		return result;
	}

	/**
	 * @param filterVo
	 * @param builder
	 * @param criteria
	 * @param root
	 * @param availableCount
	 * @param predicates
	 * @param filterSort
	 * @throws ApplicationException
	 */
	private void getSortingPredicates(List<FilterOrSortingVo> filterVo, CriteriaBuilder builder,
			CriteriaQuery<AuthorityStockDto> criteria, Root<Stock> root, Expression<Integer> availableCount,
			List<Predicate> predicates, FilterOrSortingVo filterSort) throws ApplicationException {
		if (filterSort.getFilterOrSortingType().equals(ApplicationConstants.SORTING)) {
			if (filterSort.getColumnName().equals(ApplicationConstants.INSURED_COMPANY)
					|| filterSort.getColumnName().equals(ApplicationConstants.AVAILABLE_STOCK)) {
				String columnName = filterSort.getColumnName();
				boolean direction = filterSort.isAscending();
				if (columnName.equals(ApplicationConstants.INSURED_COMPANY)) {
					if (direction == true) {
						criteria.orderBy(builder.asc(root.get(TableConstants.COMPANY_ID)));
					} else {
						criteria.orderBy(builder.desc(root.get(TableConstants.COMPANY_ID)));
					}
				} else if (columnName.equals(ApplicationConstants.AVAILABLE_STOCK)) {
					if (direction == true) {
						criteria.orderBy(builder.asc(availableCount));
					} else {
						criteria.orderBy(builder.desc(availableCount));
					}
				}
			} else {
				List<Predicate> filterPredicates = getFilterPrdicets(filterVo, root, builder, criteria);
				predicates.addAll(filterPredicates);
			}
		}
	}

	/**
	 * @return
	 */
	@Override
	public Long getTotalStockCount(List<Integer> companyIdFromStockTable) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<Stock> root = criteria.from(Stock.class);
		Expression<Long> totalStockCount = builder.sum(root.get(TableConstants.STOCK_COUNT));
		criteria.multiselect(totalStockCount);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		Expression<String> parentExpression = root.get(TableConstants.COMPANY_ID);
		Predicate parentPredicate = parentExpression.in(companyIdFromStockTable);
		predicates.add(builder.and(parentPredicate));
		Long result = (Long) getResultList(createQuery(builder, criteria, root, predicates)).stream()
				.findFirst().orElse(null);
		return result;
	}

	/**
	 * Gets the stock count for allocation stock.
	 *
	 * @param companyId the company id
	 * @return the stock count for allocation stock
	 */
	@Override
	public StockCountDto getStockCountForAllocationStock(Integer companyId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<StockCountDto> criteria = builder.createQuery(StockCountDto.class);
		Root<Stock> root = criteria.from(Stock.class);
		Expression<Integer> availableCount = (builder.diff(root.get(TableConstants.STOCK_COUNT),
				root.get(TableConstants.USED_COUNT)));
		criteria.multiselect(root.get(TableConstants.STOCK_COUNT), availableCount);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.COMPANY_ID), companyId)));
		StockCountDto result = (StockCountDto) getSingleResult(createQuery(builder, criteria, root, predicates));
		return result;
	}

	/**
	 * Gets the stock pool by company id and allocation type.
	 *
	 * @param companyId the company id
	 * @param allocationUserType the allocation user type
	 * @return the stock pool by company id and allocation type
	 */
	@Override
	public StockPool getStockPoolByCompanyIdAndAllocationType(Integer companyId, Integer allocationUserType) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<StockPool> criteria = builder.createQuery(StockPool.class);
		Root<StockPool> root = criteria.from(StockPool.class);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.COMPANY_ID), companyId)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.USER_TYPE_ID), allocationUserType)));
		StockPool result = (StockPool) getSingleResult(createQuery(builder, criteria, root, predicates));
		return result;
	}

	/**
	 * Gets the particular payment details.
	 *
	 * @param purchaseId the purchase id
	 * @return the particular payment details
	 * @throws ApplicationException the application exception
	 */
	@Override
	public PaymentDetails getParticularPaymentDetails(Integer purchaseId) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<PaymentDetails> criteria = builder.createQuery(PaymentDetails.class);
		Root<PaymentDetails> root = criteria.from(PaymentDetails.class);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.AP_IS_DELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ORDER_ID), purchaseId)));
		PaymentDetails result = (PaymentDetails) getSingleResult(createQuery(builder, criteria, root, predicates));
		return result;
	}
	
	
	/**
	 * Gets the company stock count.
	 *
	 * @param skip the skip
	 * @param limit the limit
	 * @param companyIdsFromStockTable the company ids from stock table
	 * @param filterVo the filter vo
	 * @param isCount the is count
	 * @return the company stock count
	 * @throws ApplicationException the application exception
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<Object[]> getCompanyStockCount(Integer skip,Integer limit,List<Integer> companyIdsFromStockTable, List<FilterOrSortingVo> filterVo, Boolean isCount) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Object> criteria = builder.createQuery(Object.class);
		Root<Stock> root = criteria.from(Stock.class);

		criteria.multiselect(root.get(TableConstants.COMPANY_ID),root.get(TableConstants.STOCK_COUNT));

		List<Predicate> predicates = new ArrayList<>();

		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		Expression<String> parentExpression = root.get(TableConstants.COMPANY_ID);
		Predicate parentPredicate = parentExpression.in(companyIdsFromStockTable);
		predicates.add(builder.and(parentPredicate));

		if (ApplicationUtils.isValidList(filterVo)) {
					
			for (FilterOrSortingVo filterSort : filterVo) {
				if (filterSort.getColumnName().equals(TableConstants.STOCK_COUNT) && filterSort.getFilterOrSortingType().
																					equalsIgnoreCase(ApplicationConstants.FILTER)) {
					if (!(filterSort.getValue() == null) || !(filterSort.getValue2() == null)) {
						List<FilterOrSortingVo> filteredList = filterVo.stream()
								.filter(vo -> vo.getColumnName().equals(TableConstants.STOCK_COUNT))
								.collect(Collectors.toList());
						List<Predicate> filterPredicates = getFilterPrdicets(filteredList, root, builder, criteria);
						predicates.addAll(filterPredicates);
					}

				}

			}
		}

		List<Object[]> result = (List<Object[]>) getResultList(createQuery(builder, criteria, root, predicates));
		
		return result;
	}

		/**
		 * Gets the used counts of companies.
		 *
		 * @param skip the skip
		 * @param limit the limit
		 * @param companyIds the company ids
		 * @param companyNameMaping the company name maping
		 * @param filterVo the filter vo
		 * @param isCount the is count
		 * @param searchValue the search value
		 * @return the used counts of companies
		 * @throws ApplicationException the application exception
		 */
		@SuppressWarnings("unchecked")
		@Override
		public List<Object[]> getUsedCountsOfCompanies(Integer skip, Integer limit,
				List<Integer> companyIds,Map<Integer, String> companyNameMaping, List<FilterOrSortingVo> filterVo, Boolean isCount,String searchValue) throws ApplicationException {
			HashMap<String, String> systemPropertyValues = DigitalPaperCache.getSystemPropertyVAlue();
			String allocationType = systemPropertyValues.get(ApplicationConstants.ALLOCATION_TYPE);
			if (allocationType.equalsIgnoreCase(ApplicationConstants.ALLOCATION_TYPE_1)) {
				CriteriaBuilder builder = getCriteriaBuilder();
				CriteriaQuery<Object> criteriaQuery = builder.createQuery(Object.class);
				Root<StockPool> root = criteriaQuery.from(StockPool.class);
				Expression<Long> usedCountSumExpression = builder.sum(root.get(TableConstants.USED_COUNT));				
							
				
				criteriaQuery.multiselect(root.get(TableConstants.COMPANY_ID),
						usedCountSumExpression);
				List<Predicate> predicates = new ArrayList<>();

				predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
				predicates.add(builder.and(builder.greaterThan(root.get(TableConstants.USED_COUNT),0)));
				Expression<String> companyIdListExpression = root.get(TableConstants.COMPANY_ID);
				criteriaQuery.groupBy(companyIdListExpression);
				
				List<FilterOrSortingVo> companyFilter = ApplicationUtils.isValidList(filterVo)?
						filterVo.stream()
						.filter(value -> value.getColumnName().equals(ApplicationConstants.FILTER_COLUMN_NAME)
								&& ApplicationUtils.isValidString(value.getValue()))
						.collect(Collectors.toList()):null;
				
				if(!ApplicationUtils.isValidList(companyFilter)) {
					if (ApplicationUtils.isValidList(companyIds)) {
						criteriaQuery.having(companyIdListExpression.in(companyIds));
					}
					else {
						criteriaQuery.having(companyIdListExpression.in(companyNameMaping.keySet()));
					}
				}

				if (ApplicationUtils.isValidList(filterVo)) {
										
					if (ApplicationUtils.isValidateObject(companyFilter)) {
						for (FilterOrSortingVo filter : companyFilter) {
							if (filter.getCondition().equals(ApplicationConstants.IN)) {
								String companyNameExpression = filter.getValue();
								List<Integer> listOfCompanyIds = new ArrayList<>();
								
								Set<Entry<Integer, String>> entrySet = companyNameMaping.entrySet();
								listOfCompanyIds= entrySet.stream().filter(entry->entry.getValue().contains(companyNameExpression))
							    		.map(el->el.getKey())
										.collect(Collectors.toList());
								
								criteriaQuery.having(companyIdListExpression.in(listOfCompanyIds));
							}
						}
					}

					for (FilterOrSortingVo filterSort : filterVo) {
						if (filterSort.getColumnName().equals(TableConstants.USED_COUNT)) {
							if (!(filterSort.getValue() == null) || !(filterSort.getValue2() == null)) {
								List<FilterOrSortingVo> filteredList = filterVo.stream()
										.filter(vo -> vo.getColumnName().equals(TableConstants.USED_COUNT))
										.collect(Collectors.toList());
								List<Predicate> filterPredicates = getFilterPrdicets(filteredList, root, builder,
										criteriaQuery);
								predicates.addAll(filterPredicates);
							}

						}

					}
				}

				List<Object[]> result = (List<Object[]>) getResultList(createQuery(builder, criteriaQuery, root, predicates));
				
				return result;

			} else if (allocationType.equalsIgnoreCase(ApplicationConstants.ALLOCATION_TYPE_2)) {

				CriteriaBuilder builder = getCriteriaBuilder();
				CriteriaQuery<Object> criteriaQuery = builder.createQuery(Object.class);
				Root<Stock> root = criteriaQuery.from(Stock.class);
				
				
				criteriaQuery.multiselect(root.get(TableConstants.COMPANY_ID),root.get(TableConstants.USED_COUNT));
				List<Predicate> predicates = new ArrayList<>();

				predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
				predicates.add(builder.and(builder.greaterThan(root.get(TableConstants.USED_COUNT),0)));
				Expression<String> parentExpression = root.get(TableConstants.COMPANY_ID);
				Predicate parentPredicate;
				if (ApplicationUtils.isValidList(companyIds)) {
					parentPredicate= parentExpression.in(companyIds);
				}
				else {
					parentPredicate= parentExpression.in(companyNameMaping.keySet());
				}
				predicates.add(builder.and(parentPredicate));

				if (ApplicationUtils.isValidList(filterVo)) {
					
					
					List<FilterOrSortingVo> companyFilter = filterVo.stream()
							.filter(value -> value.getColumnName().equals(ApplicationConstants.FILTER_COLUMN_NAME)
									&& ApplicationUtils.isValidString(value.getValue()))
							.collect(Collectors.toList());
					if (ApplicationUtils.isValidateObject(companyFilter)) {
						for (FilterOrSortingVo filter : companyFilter) {
							if (filter.getCondition().equals(ApplicationConstants.IN)) {
								String companyNameExpression = filter.getValue();
								List<Integer> listOfCompanyIds = new ArrayList<>();
								Set<Entry<Integer, String>> entrySet = companyNameMaping.entrySet();
								listOfCompanyIds= entrySet.stream().filter(entry->entry.getValue().contains(companyNameExpression))
							    		.map(el->el.getKey())
										.collect(Collectors.toList());
																
								predicates.add(builder.and(root.get(TableConstants.COMPANY_ID).in(listOfCompanyIds)));
							}
						}
					}
					
					
					
					
					

					for (FilterOrSortingVo filterSort : filterVo) {
						if (filterSort.getColumnName().equals(TableConstants.USED_COUNT)) {
							if (!(filterSort.getValue() == null) || !(filterSort.getValue2() == null)) {
								List<FilterOrSortingVo> filteredList = filterVo.stream()
										.filter(vo -> vo.getColumnName().equals(TableConstants.USED_COUNT))
										.collect(Collectors.toList());
								List<Predicate> filterPredicates = getFilterPrdicets(filteredList, root, builder,
										criteriaQuery);
								predicates.addAll(filterPredicates);
							}

						}

					}
				}

				List<Object[]> result = (List<Object[]>) getResultList(createQuery(builder, criteriaQuery, root, predicates));
				
				return result;
			}
			return null;
		}

		/**
		 * Gets the total paper issued count.
		 *
		 * @param companyNameMapping the company name mapping
		 * @return the total paper issued count
		 */
		@Override
		public List<Object[]> getTotalPaperIssuedCount(Map<Integer,String> companyNameMapping) {
			HashMap<String, String> systemPropertyValues = DigitalPaperCache.getSystemPropertyVAlue();
			String allocationType = systemPropertyValues.get(ApplicationConstants.ALLOCATION_TYPE);
			if(allocationType.equalsIgnoreCase(ApplicationConstants.ALLOCATION_TYPE_1)) {
				CriteriaBuilder builder = getCriteriaBuilder();
				CriteriaQuery<Object> criteriaQuery = builder.createQuery(Object.class);
				Root<StockPool> root = criteriaQuery.from(StockPool.class);
				Expression<Long> sumExpression = builder.sum(root.get(TableConstants.USED_COUNT));
				
				criteriaQuery.multiselect(root.get(TableConstants.COMPANY_ID),sumExpression);
				List<Predicate> predicates = new ArrayList<Predicate>();
				predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
				predicates.add(builder.and(builder.greaterThan(root.get(TableConstants.USED_COUNT), 0)));
				
				criteriaQuery.groupBy(root.get(TableConstants.COMPANY_ID));
				criteriaQuery.having(root.get(TableConstants.COMPANY_ID).in(companyNameMapping.keySet()));
				
				List<Object[]> result = (List<Object[]>) getResultList(createQuery(builder, criteriaQuery, root, predicates));
				return result;		
				
			}
			else if(allocationType.equalsIgnoreCase(ApplicationConstants.ALLOCATION_TYPE_2)) {
				CriteriaBuilder builder = getCriteriaBuilder();
				CriteriaQuery<Object> criteriaQuery = builder.createQuery(Object.class);
				Root<Stock> root = criteriaQuery.from(Stock.class);
				Expression<Integer> usedCountExpression =root.get(TableConstants.USED_COUNT);
				criteriaQuery.multiselect(root.get(TableConstants.COMPANY_ID),usedCountExpression);
				List<Predicate> predicates = new ArrayList<Predicate>();
				predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
				predicates.add(builder.and(builder.greaterThan(root.get(TableConstants.USED_COUNT), 0)));
				
				predicates.add(root.get(TableConstants.COMPANY_ID).in(companyNameMapping.keySet()));
				
				List<Object[]> result = (List<Object[]>) getResultList(createQuery(builder, criteriaQuery, root, predicates));
				return result;		
			}
			return null;
		}

}
 