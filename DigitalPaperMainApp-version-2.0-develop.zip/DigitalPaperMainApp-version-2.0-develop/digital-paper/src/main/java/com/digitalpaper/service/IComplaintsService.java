package com.digitalpaper.service;

import java.util.List;

import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.ComplaintsDto;

/**
 * The Interface IComplaintsService.
 */
public interface IComplaintsService {

	/**
	 * Save complaints details.
	 *
	 * @param complaintsList the complaints list
	 * @return the string
	 * @throws ApplicationException the application exception
	 */
	String saveComplaintsDetails(ComplaintsDto complaintsList) throws ApplicationException;

	/**
	 * Gets the complaints details.
	 *
	 * @return the complaints details
	 * @throws ApplicationException the application exception
	 */
	List<ComplaintsDto> getComplaintsDetails() throws ApplicationException;

}
