package com.digitalpaper.controller;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.digitalpaper.dao.ISequenceDao;
import com.digitalpaper.exception.core.ApplicationException;

@Component
@Transactional
public class SequenceGenerator {
	
	@Autowired
    private ISequenceDao iSequenceDao;
	
	private static final Logger logger = LoggerFactory.getLogger(SequenceGenerator.class);
	
	public synchronized String generateSequence(SequenceEnum sequenceFor) throws ApplicationException {
		logger.info("strating of SequenceGenerator generateSequence()");
		String sequencestr="";
		String prefix = sequenceFor.prefix;
		int length = sequenceFor.length;
		String entity = sequenceFor.entity;
		Object obj;
		
		try {
			
			obj = Class.forName(entity).newInstance();
			int sequenceId=iSequenceDao.saveSequence(obj);
			sequencestr=sequenceString(length,prefix,sequenceId);
			
		} catch (InstantiationException e) {
			logger.error("error in SequenceGenerator generateSequence()");
		} catch (IllegalAccessException e) {
			logger.error("error in SequenceGenerator generateSequence()");
		} catch (ClassNotFoundException e) {
			logger.error("error in SequenceGenerator generateSequence()");
		}
		
		return sequencestr;
	}
	
	private String sequenceString(int length, String prefix,int sequenceId) {
		logger.info("starting of SequenceGenerator sequenceString() ");
		
		if(length == 0) {
			return sequenceId + "";
		}
		
		int zero_prefix = length - prefix.length();
		
		String sequenceStr = String.format("%0"+zero_prefix+"d", sequenceId);
		
		sequenceStr=prefix+sequenceStr;
		
		return sequenceStr;
	}

}
