package com.digitalpaper.service.impl;

import java.io.ByteArrayOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.digitalpaper.config.DigitalPaperCache;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.config.property.EnvironmentProperties;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.IAuthorityPaperDetailsDao;
import com.digitalpaper.dao.IStockDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.restemplate.service.IRestTemplateService;
import com.digitalpaper.service.IAuthorityPaperDetailsService;
import com.digitalpaper.transfer.object.dto.AuthorityStockDto;
import com.digitalpaper.transfer.object.dto.CompanyDto;
import com.digitalpaper.transfer.object.dto.CompanyTransactionDto;
import com.digitalpaper.transfer.object.dto.DownloadListVo;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.entity.UserType;
import com.digitalpaper.transfer.object.enums.PaperDetailsStatusEnum;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;
import com.digitalpaper.utils.core.ApplicationUtils;

/**
 * The Class AuthorityPaperDetailsServiceImpl.
 */
@Service
@Transactional
public class AuthorityPaperDetailsServiceImpl implements IAuthorityPaperDetailsService {

	/**
	 * IStockDao
	 */
	@Autowired
	private IStockDao iStockDao;
	
	/**
	 * LoggedInUserContextHolder
	 */
	@Autowired
	private LoggedInUserContextHolder loggedInUserContextHolder;
	
	/**
	 * IRestTemplateService
	 */
	@Autowired
	private IRestTemplateService iRestTemplateService;
	
	/** The i authority paper details dao. */
	@Autowired
	private IAuthorityPaperDetailsDao iAuthorityPaperDetailsDao;
	
	/**
	 * EnvironmentProperties
	 */
	@Autowired
	private EnvironmentProperties environmentProperties;
	
	/**
	 * DigitalPaperCache
	 */
	@Autowired
	private DigitalPaperCache digitalPaperCache;
	
		
	/**
	 * @param filterVo
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Long getStockCount(List<FilterOrSortingVo> filterVo,List<Integer> companyIds, String searchValue ) throws ApplicationException {
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		UserType userTypeId = loggedInUser.getUserTypeId();
		if (!userTypeId.getUserTypeName().equals(ApplicationConstants.ASSOCIATION)) {
			throw new ApplicationException(ErrorCodes.UN_AUTHORIZED);
		}
		List<AuthorityStockDto> stockAndCountList = getStockData(0, 0, searchValue,filterVo,companyIds, Boolean.TRUE,null);
		Long stockCount = (long) stockAndCountList.size();
		return stockCount;
	}
	
	/**
	 * @param skip
	 * @param limit
	 * @param filterVo
	 * @param companyIds 
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public List<AuthorityStockDto> getStockData(Integer skip, Integer limit, String searchValue, List<FilterOrSortingVo> filterVo, 
			List<Integer> companyIds, Boolean isCompanyId,String isCard)
			throws ApplicationException {
		
		Boolean isCardOrNot=ApplicationUtils.isValidString(isCard)?Boolean.parseBoolean(isCard):null;
		
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		UserType userTypeId = loggedInUser.getUserTypeId();
		if (!userTypeId.getUserTypeName().equals(ApplicationConstants.ASSOCIATION)) {
			throw new ApplicationException(ErrorCodes.UN_AUTHORIZED);
		}
		List<AuthorityStockDto> authorityStockDtoList;
		HashMap<Integer, String> companyNameMaping = digitalPaperCache.getCompanyList();
		List<AuthorityStockDto> stockAndCountList = new ArrayList<AuthorityStockDto>();
		if(ApplicationUtils.isValidList(companyIds) || isCompanyId) {
			List<Object[]> usedCountsOfCompanies = iStockDao.getUsedCountsOfCompanies(skip, limit, companyIds, companyNameMaping, filterVo, Boolean.TRUE,searchValue);
			stockAndCountList=usedCountsOfCompanies.stream().map(usedCounts->
				new AuthorityStockDto((Integer)usedCounts[0],null,null,null,(int)(long)usedCounts[1])).collect(Collectors.toList());	
			List<Integer> companyIdsFromStockDao=stockAndCountList.stream().map(el->el.getCompanyId()).collect(Collectors.toList());
			List<Object[]> stockCountDetailsList = iStockDao.getCompanyStockCount(skip,limit,companyIdsFromStockDao, filterVo, Boolean.TRUE);
			stockAndCountList=filterUsedCountsListByStockCountList(stockCountDetailsList,stockAndCountList);
			List<Integer> stockCountsOfCompanies = stockCountDetailsList.stream().map(el -> (Integer) el[1])
					.collect(Collectors.toList());
			stockAndCountList=setStockCountToDtoList(stockAndCountList, stockCountsOfCompanies);
		}
		else {
			List<Object[]> usedCountsOfCompanies =iStockDao.getUsedCountsOfCompanies(skip, limit, companyIds, companyNameMaping, filterVo, Boolean.FALSE,searchValue);
			stockAndCountList=usedCountsOfCompanies.stream().map(usedCounts->
			new AuthorityStockDto((Integer)usedCounts[0],null,null,null,(int)(long)usedCounts[1])).collect(Collectors.toList());
			List<Integer> companyIdsFromStockDao=stockAndCountList.stream().map(el->el.getCompanyId()).collect(Collectors.toList());
			List<Object[]> stockCountDetailsList = iStockDao.getCompanyStockCount(skip,limit,companyIdsFromStockDao, filterVo, Boolean.FALSE);
			stockAndCountList=filterUsedCountsListByStockCountList(stockCountDetailsList,stockAndCountList);
			List<Integer> stockCountsOfCompanies = stockCountDetailsList.stream().map(el -> (Integer) el[1])
					.collect(Collectors.toList());

			stockAndCountList=setStockCountToDtoList(stockAndCountList, stockCountsOfCompanies);
		}
		authorityStockDtoList = stockAndCountList.stream()
				.peek(value -> value.setInsuredComapny(companyNameMaping.get(value.getCompanyId())))
				.collect(Collectors.toList());
		
		List<AuthorityStockDto> stockCountDtoList = availableStockCountSetMethod(authorityStockDtoList);
		
		
		stockCountDtoList = avalilableStockFilterAndOtherSortFilter(filterVo, stockCountDtoList, searchValue, skip,limit, isCompanyId);

		if (ApplicationUtils.isValidObject(isCardOrNot) && isCardOrNot.equals(Boolean.TRUE)	) {
			List<Object[]> paperIssuedDetailsList= iStockDao.getTotalPaperIssuedCount(companyNameMaping);
			List<Integer> companyIdsFromPaperIssuedList = paperIssuedDetailsList.stream().map(element->(Integer)element[0]).collect(Collectors.toList());
			Integer totalPaperIssuedSum = paperIssuedDetailsList.stream()
								  .mapToInt(el->(int)(long)el[1]).sum();
			
			Integer totalStockCount = ApplicationUtils.isValidateObject(companyIdsFromPaperIssuedList)
					? iStockDao.getTotalStockCount(companyIdsFromPaperIssuedList).intValue()
					: 0;
			
			setValuesEntityToDto(stockCountDtoList, totalPaperIssuedSum,totalStockCount);
		}
		
		
		
		return stockCountDtoList;
	}

	/**
	 * Filter used counts list by stock count list.
	 *
	 * @param stockCountDetailsList the stock count details list
	 * @param stockAndCountList the stock and count list
	 * @return the list
	 */
	private List<AuthorityStockDto> filterUsedCountsListByStockCountList(List<Object[]> stockCountDetailsList,
			List<AuthorityStockDto> stockAndCountList) {
		List<Integer> companyIdsFromStockCounts = stockCountDetailsList.stream().map(el -> (Integer) el[0])
				.collect(Collectors.toList());
		stockAndCountList = stockAndCountList.stream()
				.filter(stockAndCount -> companyIdsFromStockCounts.contains(stockAndCount.getCompanyId()))
				.collect(Collectors.toList());
		return stockAndCountList;
	}


	/**
	 * Available stock count set method.
	 *
	 * @param authorityStockDtoList the authority stock dto list
	 * @return the list
	 */
	private List<AuthorityStockDto> availableStockCountSetMethod(List<AuthorityStockDto> authorityStockDtoList) {
		List<AuthorityStockDto> availableStockCountList = authorityStockDtoList.stream()
		.map(el->new AuthorityStockDto(el.getCompanyId(), el.getInsuredComapny(), el.getStockCount(),
				el.getStockCount()-el.getPaperIssued(), el.getPaperIssued())).collect(Collectors.toList());
		return availableStockCountList;
	}

	/**
	 * Sets the stock count to dto list.
	 *
	 * @param stockAndCountList the stock and count list
	 * @param stockCountOfCompanies the stock count of companies
	 * @return the list
	 */
	private List<AuthorityStockDto> setStockCountToDtoList(List<AuthorityStockDto> stockAndCountList, List<Integer> stockCountOfCompanies) {
		
		List<AuthorityStockDto> stockCountAddedDtoList = new ArrayList<AuthorityStockDto>();
		for (int i=0; i<stockCountOfCompanies.size() && i<stockAndCountList.size();i++) {
			Integer stockCount = stockCountOfCompanies.get(i);
			AuthorityStockDto authorityStockDto = stockAndCountList.get(i);
			authorityStockDto.setStockCount(stockCount);				
			stockCountAddedDtoList.add(authorityStockDto);
		}
		return stockCountAddedDtoList;
	}

	/**
	 * @param filterVo
	 * @param authorityStockDtoList
	 * @param stockAndCountList
	 * @return
	 * @throws NumberFormatException
	 */
	private List<AuthorityStockDto> avalilableStockFilterAndOtherSortFilter(List<FilterOrSortingVo> filterVo,
			List<AuthorityStockDto> authorityStockDtoList,
			String searchValue, Integer skip, Integer limit, Boolean isCompanyId) throws NumberFormatException {
		if (ApplicationUtils.isValidString(searchValue) || ApplicationUtils.isValidList(filterVo)) {
			if (ApplicationUtils.isValidList(filterVo)) {
				Optional<FilterOrSortingVo> filteredList = filterVo.stream()
						.filter(vo -> vo.getColumnName().equals(ApplicationConstants.AVAILABLE_STOCK)).findFirst();
				if (filteredList.isPresent()) {
					FilterOrSortingVo availableStockFilter = filteredList.get();
					if (availableStockFilter.getFilterOrSortingType().equals(ApplicationConstants.FILTER)) {
						if (!(availableStockFilter.getValue() == null) && !(availableStockFilter.getValue2() == null)) {
							int value1 = Integer.parseInt(availableStockFilter.getValue());
							int value2 = Integer.parseInt(availableStockFilter.getValue2());
							authorityStockDtoList = authorityStockDtoList.stream().filter(
									obj -> obj.getAvailableStock() >= value1 && obj.getAvailableStock() <= value2)
									.collect(Collectors.toList());
						
						} else if (!(availableStockFilter.getValue() == null)
								&& (availableStockFilter.getValue2() == null)) {
							int value1 = Integer.parseInt(availableStockFilter.getValue());
							authorityStockDtoList = authorityStockDtoList.stream()
									.filter(obj -> obj.getAvailableStock() >= value1).collect(Collectors.toList());
						} else if ((availableStockFilter.getValue() == null)
								&& !(availableStockFilter.getValue2() == null)) {
							int value2 = Integer.parseInt(availableStockFilter.getValue2());
							authorityStockDtoList = authorityStockDtoList.stream()
									.filter(obj -> obj.getAvailableStock() <= value2).collect(Collectors.toList());
						}
					}
				}
				Optional<FilterOrSortingVo> companySortFilter = filterVo.stream()
						.filter(vo -> vo.getColumnName().equalsIgnoreCase(ApplicationConstants.SORT_COMPANY) 
								&& vo.getFilterOrSortingType().equalsIgnoreCase(ApplicationConstants.SORTING))
						.findFirst();
				if (companySortFilter.isPresent()) {
					FilterOrSortingVo sort = companySortFilter.get();
					Comparator<AuthorityStockDto> caseInsensitiveComparator = Comparator
							.comparing(dto -> dto.getInsuredComapny(), String.CASE_INSENSITIVE_ORDER);
					if (sort.isAscending()) {
						authorityStockDtoList = authorityStockDtoList.stream().sorted(caseInsensitiveComparator)
								.collect(Collectors.toList());
					} else {
						authorityStockDtoList = authorityStockDtoList.stream()
								.sorted(caseInsensitiveComparator.reversed()).collect(Collectors.toList());
					}
				}

				Optional<FilterOrSortingVo> availableStockCountSortFilter = filterVo.stream()
						.filter(vo -> vo.getColumnName().equalsIgnoreCase(ApplicationConstants.AVAILABLE_STOCK)
								&& vo.getFilterOrSortingType().equalsIgnoreCase(ApplicationConstants.SORTING))
						.findFirst();

				if (availableStockCountSortFilter.isPresent()) {
					FilterOrSortingVo availableStockCountSort = availableStockCountSortFilter.get();
					Comparator<AuthorityStockDto> availableStockComparator = Comparator
							.comparing(dto -> dto.getAvailableStock());
					if (availableStockCountSort.isAscending()) {

						authorityStockDtoList=authorityStockDtoList.stream().sorted(availableStockComparator).collect(Collectors.toList());
					} else {
						authorityStockDtoList=authorityStockDtoList.stream().sorted(availableStockComparator.reversed())
								.collect(Collectors.toList());
					}
				}
				
				Optional<FilterOrSortingVo> stockCountSortFilter = filterVo.stream()
						.filter(vo -> vo.getColumnName().equalsIgnoreCase(TableConstants.STOCK_COUNT)
								&& vo.getFilterOrSortingType().equalsIgnoreCase(ApplicationConstants.SORTING))
						.findFirst();
				if (stockCountSortFilter.isPresent()) {
					FilterOrSortingVo stockCountSortFilterObject = stockCountSortFilter.get();
					Comparator<AuthorityStockDto> stockCountComparator = Comparator
							.comparing(dto -> dto.getStockCount());
					if (stockCountSortFilterObject.isAscending()) {

						authorityStockDtoList=authorityStockDtoList.stream().sorted(stockCountComparator).collect(Collectors.toList());
					} else {
						authorityStockDtoList=authorityStockDtoList.stream().sorted(stockCountComparator.reversed())
								.collect(Collectors.toList());
					}
				}
				
			}
			if (ApplicationUtils.isValidString(searchValue)) {
				authorityStockDtoList = authorityStockDtoList.stream()
						.filter(x -> x.getInsuredComapny().toLowerCase().contains(searchValue.toLowerCase())
								|| x.getAvailableStock().toString().contains(searchValue)
								|| x.getStockCount().toString().contains(searchValue)
						 || x.getPaperIssued().toString().contains(searchValue))
						.collect(Collectors.toList());
				
			}
		}
		List<AuthorityStockDto> authorityStockDtoListDub = new ArrayList<>();
		if (isCompanyId.equals(Boolean.FALSE) && authorityStockDtoList.size()>limit) {
			authorityStockDtoListDub = authorityStockDtoList.stream().skip(skip).limit(limit)
					.collect(Collectors.toList());
			return authorityStockDtoListDub;
		} 

		return authorityStockDtoList;
	}

	/**̥
	 * @param authorityStockDtoList
	 * @param totalStockCount
	 * @param totalPaperIssuedCount 
	 */
	private void setValuesEntityToDto(List<AuthorityStockDto> authorityStockDtoList, Integer totalPaperIssuedCount, Integer totalStockCount) {
		AuthorityStockDto authorityStockDto = new AuthorityStockDto();
		authorityStockDto.setInsuredComapny((ApplicationConstants.ALL_COMPANY_NAME));
		authorityStockDto.setStockCount((ApplicationUtils.isValidId(totalStockCount)?totalStockCount: 0));
		authorityStockDto.setAvailableStock((ApplicationUtils.isValidId(totalPaperIssuedCount) && ApplicationUtils.isValidId(totalStockCount)
												?totalStockCount-totalPaperIssuedCount: 0));
		authorityStockDto.setPaperIssued((ApplicationUtils.isValidId(totalPaperIssuedCount)?totalPaperIssuedCount: 0));
		authorityStockDtoList.add(0, authorityStockDto); 
	}
	

	/**
	 * @param companyTransactionDto
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Long getPaperDetailsByCompanyCount(CompanyTransactionDto companyTransactionDto, String searchValue) throws ApplicationException {
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		UserType userTypeId = loggedInUser.getUserTypeId();
		if (!userTypeId.getUserTypeName().equals(ApplicationConstants.ASSOCIATION)) {
			throw new ApplicationException(ErrorCodes.UN_AUTHORIZED);
		}
		Long paperDetailsCount = null;
		HashMap<Integer, String> companyNameMaping = digitalPaperCache.getCompanyList();

		List<Integer> matchingKey = new ArrayList<>();
		if(ApplicationUtils.isValidString(searchValue)) {
			matchingKey = companyNameMaping.entrySet()
	                .stream()
	                .filter(entry -> entry.getValue().toLowerCase().contains(searchValue.toLowerCase()))
	                .map(Map.Entry::getKey)
	                .collect(Collectors.toList());
		}
		if (ApplicationUtils.isValidateObject(companyTransactionDto)) {
			valueListStringConversion(companyTransactionDto.getFilter());
				paperDetailsCount = iAuthorityPaperDetailsDao.getPaperDetailsCountByCompany(companyTransactionDto, searchValue,matchingKey );
		} else {
			throw new ApplicationException(ErrorCodes.INVALID_DATA);
		}

		return paperDetailsCount;
	}

	/**
	 * @param companyTransactionDto
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public List<PaperDetailsDto> getPaperDetailsByCompanyList(CompanyTransactionDto companyTransactionDto, String searchValue) throws ApplicationException {
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		UserType userTypeId = loggedInUser.getUserTypeId();
		if (!userTypeId.getUserTypeName().equals(ApplicationConstants.ASSOCIATION)) {
			throw new ApplicationException(ErrorCodes.UN_AUTHORIZED);
		}
		valueListStringConversion(companyTransactionDto.getFilter());

		HashMap<Integer, String> companyNameMaping = digitalPaperCache.getCompanyList();

		List<Integer> matchingKey = new ArrayList<>();
		if(ApplicationUtils.isValidString(searchValue)) {
			matchingKey = companyNameMaping.entrySet()
	                .stream()
	                .filter(entry -> entry.getValue().toLowerCase().contains(searchValue.toLowerCase()))
	                .map(Map.Entry::getKey)
	                .collect(Collectors.toList());
		}
		
		List<PaperDetails> paperDetails = iAuthorityPaperDetailsDao.getPaperDetailsByCompanyList(companyTransactionDto, searchValue, matchingKey);
		List<PaperDetailsDto> paperDetailsDtoList = new ArrayList<>();
		for (PaperDetails details : paperDetails) {
			PaperDetailsDto paperDetailsDto = new PaperDetailsDto();
			paperDetailsDto.setPdDigiltaPaperId(details.getPdDigitalPaperId());
			paperDetailsDto.setPdPolicyNumber(details.getPdPolicyNumber());
			paperDetailsDto.setPdInsuredName(details.getPdInsuredName());
			paperDetailsDto.setVdRegistrationNumber(details.getVdRegistrationNumber());
			paperDetailsDto.setPdEffectiveFrom(details.getPdEffectiveFrom().toString());
			paperDetailsDto.setPdExpireDate(details.getPdExpireDate().toString());
			paperDetailsDto.setStatus(PaperDetailsStatusEnum.getIdByName(details.getStatus()));
			paperDetailsDto.setCompanyName(companyNameMaping.get(details.getCompanyId()));
			paperDetailsDto.setCompanyId(details.getCompanyId());
			paperDetailsDto.setIdentity(details.getIdentity());
			paperDetailsDtoList.add(paperDetailsDto);
		}
		return paperDetailsDtoList;
	}
	
	/**
	 * Download paper in excel.
	 *
	 * @param downloadVo the download vo
	 * @param searchValue the search value
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	@Override
	public ResponseEntity<ByteArrayResource> downloadPaperInExcel(DownloadListVo  downloadVo, String searchValue)  throws ApplicationException {
		
		List<String> columnList = new ArrayList<>();
		if(ApplicationUtils.isValidList(downloadVo.getColumnList())) {
			
			columnList.addAll(downloadVo.getColumnList());
		}
		
		else
		{
			throw new ApplicationException(ErrorCodes.INVALID_COLUMN_NAME);
		}
		
		
		List<FilterOrSortingVo> filter = new ArrayList<>();
		if(ApplicationUtils.isValidateObject(downloadVo.getFilterVo())) {
			filter.addAll(downloadVo.getFilterVo());
		
		}
		
		Long stockCount = getStockCount(filter,null, searchValue);
		Integer skip = 0;
		Integer limit = Integer.valueOf(stockCount.intValue());
		List<Integer> companyIds = downloadVo.getCompanyId();
		List<AuthorityStockDto> stockData = getStockData(skip,limit,searchValue,filter,companyIds, Boolean.TRUE,null);
		
		ArrayList<HashMap<String, Object>> excelDataList = new ArrayList<HashMap<String,Object>>();
		
		
		
		for (AuthorityStockDto stock : stockData) {
			LinkedHashMap<String, Object> dataMap = new LinkedHashMap<String, Object>();
			for (String column : columnList) {
				switch (column.trim()) {

				case TableConstants.TAB_INSURED_COMAPNY:
					dataMap.put(column, stock.getInsuredComapny());
					break;

				case TableConstants.TAB_STOCK_COUNT:
					dataMap.put(column, stock.getStockCount());
					break;

				case TableConstants.TAB_AVAILABLE_STOCK:
					dataMap.put(column, stock.getAvailableStock());
					break;

				case TableConstants.TAB_PAPERS_ISSUED:
					dataMap.put(column, stock.getPaperIssued());
					break;

				}

			}
			excelDataList.add(dataMap);
		}
		
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		HttpHeaders header = new HttpHeaders();
		
		try {
			List<String> keyList = new ArrayList<>();
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet(ApplicationConstants.REPORT_LOSS);
			XSSFRow hederRow = sheet.createRow((int) ApplicationConstants.ZERO);

			XSSFFont headerFont = workbook.createFont();
			headerFont.setBold(true);

			XSSFCellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);
			
			int rowIndex = ApplicationConstants.ZERO; 

		
		
			for (HashMap<String, Object> map : excelDataList) { // Iterated only for Extracting Header Columns
				Set<String> keys = map.keySet();
				keyList = keys.stream().collect(Collectors.toList());
				for (int i = ApplicationConstants.ZERO; i < keyList.size(); i++) {
					
					XSSFCell headerCell = hederRow.createCell(i);
					 String headerText =Character.toUpperCase(keyList.get(i).charAt(0)) + keyList.get(i).substring(1); // Capitalize the first letter
					 
					headerCell.setCellValue(headerText);
					headerCell.setCellStyle(headerCellStyle);
					
				}
			}

			for (HashMap<String, Object> map : excelDataList) {
				int columnIndex = ApplicationConstants.ZERO;
				XSSFRow row = sheet.createRow(rowIndex + 1);
				for (Entry<String, Object> entry : map.entrySet()) {
					row.createCell(columnIndex).setCellValue((entry.getValue() != null) ? entry.getValue().toString()
							: ApplicationConstants.WITHOUT_SPACE);
					columnIndex++;
				}
				rowIndex++;
			}

			if (ApplicationUtils.isValidList(keyList)) {
				for (int index = ApplicationConstants.ZERO; index < keyList.size(); index++) {
					sheet.autoSizeColumn(index);
				}
			}

			header.setContentType(new MediaType("application", "force-download"));
			header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=AuthorityPaperDetails.pdf");

			workbook.write(stream);
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>(new ByteArrayResource(stream.toByteArray()), header, HttpStatus.CREATED);
	}
	
	/**
	 * Gets the columns in drop down paper details.
	 *
	 * @return the columns in drop down paper details
	 * @throws ApplicationException the application exception
	 */
	public List<String> getColumnsInDropDownPaperDetails() throws ApplicationException {

		ArrayList<String> List = new ArrayList<>();
		List.add(TableConstants.TAB_INSURED_COMAPNY);
		List.add(TableConstants.TAB_STOCK_COUNT);
		List.add(TableConstants.TAB_AVAILABLE_STOCK);
		List.add(TableConstants.TAB_PAPERS_ISSUED);

		return List;

	}
	
	/**
	 * Download view paper.
	 *
	 * @param searchValue the search value
	 * @param downloadVo the download vo
	 * @param request the request
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	public ResponseEntity<ByteArrayResource> downloadViewPaper(String searchValue, DownloadListVo downloadVo, HttpServletRequest request)
			throws ApplicationException {

		List<String> columnList = new ArrayList<String>();
		if (ApplicationUtils.isValidList(downloadVo.getColumnList())) {
			columnList.addAll(downloadVo.getColumnList());
		} else {
			throw new ApplicationException(ErrorCodes.INVALID_COLUMN_NAME);
		}

		List<FilterOrSortingVo> filter = new ArrayList<FilterOrSortingVo>();
		if (ApplicationUtils.isValidateObject(downloadVo.getFilterVo())) {
			filter.addAll(downloadVo.getFilterVo());
		}

		List<FilterOrSortingVo> filterList = new ArrayList<FilterOrSortingVo>();
		List<CompanyDto> restCompanyDetailsList = iRestTemplateService.getCompanyList(filterList);
		
		Map<Integer, String> companyIdNameMap = restCompanyDetailsList.stream()
                .collect(Collectors.toMap(CompanyDto::getCompanyId, CompanyDto::getName));
		
		List<String> entityColumnList = getEntityList(columnList);

		ArrayList<HashMap<String, Object>> excelDataList = new ArrayList<HashMap<String, Object>>();

		List<Integer> companyIdList = new ArrayList<Integer>();
		if (ApplicationUtils.isValidList(downloadVo.getColumnList())) {
			companyIdList.addAll(downloadVo.getCompanyId());
		} else {
			throw new ApplicationException(ErrorCodes.INVALID_COMPANY_ID);
		}

		List<Integer> matchingKey = new ArrayList<>();
		HashMap<Integer, String> companyNameMaping = digitalPaperCache.getCompanyList();
		
		if(ApplicationUtils.isValidString(searchValue)) {
			matchingKey = companyNameMaping.entrySet()
	                .stream()
	                .filter(entry -> entry.getValue().toLowerCase().contains(searchValue.toLowerCase()))
	                .map(Map.Entry::getKey)
	                .collect(Collectors.toList());
		}
		
		valueListStringConversion(downloadVo.getFilterVo());
		List<Object[]> getPaperDetailsData = iAuthorityPaperDetailsDao.getPaperDetailsList(entityColumnList,
				companyIdList,downloadVo.getFilterVo(), searchValue, matchingKey);

		if (ApplicationUtils.isValidateObject(getPaperDetailsData)) {
			for (Object[] paperDetails : getPaperDetailsData) {
				HashMap<String, Object> excelDataMap = new LinkedHashMap<String, Object>();
				int index = 0;
				for (String list : columnList) {
					if (index < paperDetails.length) {

						if(list.equalsIgnoreCase(ApplicationConstants.COMPANYNAME)) {
							String companyName = companyIdNameMap.get((Integer)paperDetails[index]);
							excelDataMap.put(list, companyName);
						}
						else if (list.equalsIgnoreCase(TableConstants.STATUS_REPORT)) {
							String idByName = PaperDetailsStatusEnum.getIdByName((Integer) paperDetails[index]);
							excelDataMap.put(list, idByName);
						}

						else {
							excelDataMap.put(list, paperDetails[index]);
						}
					}
					index++;
				}
				excelDataList.add(excelDataMap);
			}
		}

		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		HttpHeaders header = new HttpHeaders();

		try {
			List<String> keyList = new ArrayList<>();
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet(ApplicationConstants.REPORT_LOSS);
			XSSFRow hederRow = sheet.createRow((int) ApplicationConstants.ZERO);

			XSSFFont headerFont = workbook.createFont();
			headerFont.setBold(true);

			XSSFCellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			int rowIndex = ApplicationConstants.ZERO;

			for (HashMap<String, Object> map : excelDataList) { // Iterated only for Extracting Header Columns
				Set<String> keys = map.keySet();
				keyList = keys.stream().collect(Collectors.toList());
				for (int i = ApplicationConstants.ZERO; i < keyList.size(); i++) {

					XSSFCell headerCell = hederRow.createCell(i);
					String headerText = Character.toUpperCase(keyList.get(i).charAt(0)) + keyList.get(i).substring(1); // Capitalize
																														// the
																														// first
																														// letter

					headerCell.setCellValue(headerText);
					headerCell.setCellStyle(headerCellStyle);
				}
			}

			for (HashMap<String, Object> map : excelDataList) {
				int columnIndex = ApplicationConstants.ZERO;
				XSSFRow row = sheet.createRow((int) rowIndex + 1);
				for (Entry<String, Object> entry : map.entrySet()) {
					XSSFCell cell = row.createCell(columnIndex);

					if( entry.getKey().equalsIgnoreCase(TableConstants.TAB_EFFECTIVE_FROM) || entry.getKey().equalsIgnoreCase(TableConstants.TAB_EFFECTIVE_TO)) {
						String object =map.get(entry.getKey()).toString();
						DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
						Date date = dateFormat.parse(object);
						DateFormat formatter = new SimpleDateFormat(environmentProperties.getDateFormat());
						String dateStr = formatter.format(date);
						cell.setCellValue(dateStr);
					}

					else {

						cell.setCellValue((entry.getValue() != null) ? entry.getValue().toString()
								: ApplicationConstants.WITHOUT_SPACE);

					}
					columnIndex++;
				}
				rowIndex++;
				}
				

			header.setContentType(new MediaType("application", "force-download"));
			header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=AuthorityPaperDetails.pdf");

			workbook.write(stream);
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>(new ByteArrayResource(stream.toByteArray()), header, HttpStatus.CREATED);
	}
			
			
			
	
	/**
	 * Gets the entity list.
	 *
	 * @param columnList the column list
	 * @return the entity list
	 */
	private List<String> getEntityList(List<String> columnList){
		
		List<String> entityColumnList = new ArrayList<String>();
		
		LinkedHashMap<String, String> fieldsEntityColumnMap = new LinkedHashMap<String,String>();
		fieldsEntityColumnMap.put(TableConstants.TAB_DIGITAL_NUMBER,TableConstants.PD_DIGITAL_PAPER_ID);
		fieldsEntityColumnMap.put(TableConstants.TAB_POLICY_NUMBER,TableConstants.POLICY_NUMBER);
		fieldsEntityColumnMap.put(TableConstants.TAB_INSURED_NAME, TableConstants.PD_INSURED_NAME);
		fieldsEntityColumnMap.put(TableConstants.COMPANYNAME, TableConstants.COMPANY_ID);
		fieldsEntityColumnMap.put(TableConstants.PHONE_NO,TableConstants.PD_PHONE_NUMBER);
		fieldsEntityColumnMap.put(TableConstants.TAB_EFFECTIVE_FROM,TableConstants.EFFECTIVE_START_DATE);
		fieldsEntityColumnMap.put(TableConstants.TAB_EFFECTIVE_TO,TableConstants.EXPIRY_DATE);
		fieldsEntityColumnMap.put(TableConstants.TAB_REGISTRATION_NO,TableConstants.REGISTRATION_NUMBER);
		fieldsEntityColumnMap.put(TableConstants.CHASSIS_NUMBER, TableConstants.CHASIS_NUMBER);
		fieldsEntityColumnMap.put(TableConstants.LICENSE_TO_CARRY, TableConstants.PD_LICENCE_TO_CARRY);
		fieldsEntityColumnMap.put(TableConstants.STATUS_REPORT, TableConstants.STATUS);
		
		entityColumnList=columnList.stream().map(el->fieldsEntityColumnMap.get(el)).collect(Collectors.toList());

		return entityColumnList;
		
		
	}
	
							

	/**
	 * Gets the entity column list.
	 *
	 * @return the entity column list
	 */
	private List<String> getEntityColumnList() {
		List<String> entityColumnList= new ArrayList<>();
		entityColumnList.add(TableConstants.PD_DIGITAL_PAPER_ID);
		entityColumnList.add(TableConstants.PD_INSURED_NAME);
		entityColumnList.add(TableConstants.POLICY_NUMBER);
		entityColumnList.add(TableConstants.PD_PHONE_NUMBER);
		entityColumnList.add(TableConstants.PD_EMAIL_ID);
		entityColumnList.add(TableConstants.EFFECTIVE_START_DATE);
		entityColumnList.add(TableConstants.EXPIRY_DATE);
		entityColumnList.add(TableConstants.REGISTRATION_NUMBER);
		entityColumnList.add(TableConstants.CHASIS_NUMBER);
		entityColumnList.add(TableConstants.PD_LICENCE_TO_CARRY);
		entityColumnList.add(TableConstants.PD_MAKE);
		entityColumnList.add(TableConstants.PD_MODEL);
		entityColumnList.add(TableConstants.PD_USAGE);
		entityColumnList.add(TableConstants.SCRATCH_ID);

		return entityColumnList;	
		
	}

	/**
	 * @param filterVo
	 */
	private void valueListStringConversion(List<FilterOrSortingVo> filterVo) {
		if (ApplicationUtils.isValidList(filterVo)) {
			for (FilterOrSortingVo filterObject : filterVo) {
				List<String> valueList = filterObject.getValueList();
				if (ApplicationUtils.isValidList(valueList)) {
					List<String> integerListData = new ArrayList<String>();
					for (String value : valueList) {
						if (filterObject.getColumnName().equals(ApplicationConstants.PD_STATUS)) {
							Integer val = PaperDetailsStatusEnum.getNameById(value);
							integerListData.add(val.toString());
						}
					}
					valueList = integerListData;
				}
				filterObject.setValueList(valueList);
			}
		}
	}

	/**
	 * Gets the stock table count.
	 *
	 * @return the stock table count
	 */
	@Override
	public Long getStockTableCount() {
		Long stockCount = 0l;
		try {
			 stockCount = iAuthorityPaperDetailsDao.getStockTableCount();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return stockCount;
	}
	}

