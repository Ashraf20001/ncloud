package com.digitalpaper.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitalpaper.config.base.controller.BaseController;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.restemplate.service.IDigitalPaperSevice;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.FieldGroup;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class DigitalPaperController.
 */
@RestController
public class DigitalPaperController extends BaseController {

	
	/** digitalPaperService. */
	@Autowired
	private IDigitalPaperSevice digitalPaperService;

	/**
	 * Save digital paper.
	 *
	 * @param fieldGroup the field group
	 * @param request the request
	 * @param uploadType the upload type
	 * @param actionType the action type
	 * @return the application response
	 * @throws ApplicationException the application exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@ApiOperation(value="Digital paper save",notes="Digital paper creation operation",response = ApplicationResponse.class)
	@PostMapping("/save")
	public ApplicationResponse saveDigitalPaper(@ApiParam(value="Digital paper field group",required = true) @RequestBody FieldGroup fieldGroup, HttpServletRequest request,
		    @ApiParam(value="Upload type",required = true) 	@RequestParam String uploadType, @ApiParam(value="Action type of paper creation")  @RequestParam String actionType) throws ApplicationException, IOException {
		String response = digitalPaperService.saveDigitalPaper(fieldGroup, request,uploadType,actionType);
		return getApplicationResponse(response);
	}
	
	
	/**
	 * Gets the paper details.
	 *
	 * @param registerNo the register no
	 * @return the paper details
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Digital paper fetch",notes="Get Digital paper based on registration number",response=ApplicationResponse.class)
	@GetMapping("/get-paper-details")
	public ApplicationResponse getpaperDetails(@ApiParam(value="Digital paper registration number",required = true)  @RequestParam(name = "registerNo") String registerNo)
			throws ApplicationException {
		PaperDetailsDto paperDetailsDto = new PaperDetailsDto();
		paperDetailsDto = digitalPaperService.getpaperDetails(registerNo);
		
		return getApplicationResponse(paperDetailsDto);
	}
	
	/**
	 * Gets the login digital paper list.
	 *
	 * @return the login digital paper list
	 */
	@ApiOperation(value="Digital papers of customer",notes="Get login customer digital paper details",response=ApplicationResponse.class)
	@GetMapping("/get-login-digital-paperDetals")
	public ApplicationResponse getLoginDigitalPaperList() {
		
		List<PaperDetailsDto> data = new ArrayList<PaperDetailsDto>();
		try {
			data = digitalPaperService.getListOfLoginDigitalPaperDetails();
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
		
		return getApplicationResponse(data);
	}
	
	/**
	 * Send email for digital paper in customer.
	 *
	 * @param paperIdentity the paper identity
	 * @param policyNumber the policy number
	 * @return the application response
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Customer email",notes="Send email to the customer based on paper identity and policy number",response=ApplicationResponse.class)
	@GetMapping("/send-email")
	public ApplicationResponse sendEmailForDigitalPaperInCustomer( @ApiParam(value="Paper identity",required=true) @RequestParam(name="paperIdentity") String paperIdentity, @ApiParam(value = "Policy Number",required = true) @RequestParam(name="policyNo") String policyNumber) throws ApplicationException {
		
		return getApplicationResponse(digitalPaperService.sendDataToEmail(paperIdentity,policyNumber));
	}

	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return DigitalPaperController.class;
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {
	}

}
