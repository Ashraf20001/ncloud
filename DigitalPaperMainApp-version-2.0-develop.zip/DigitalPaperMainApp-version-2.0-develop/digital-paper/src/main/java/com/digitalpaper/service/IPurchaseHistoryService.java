package com.digitalpaper.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.CompanyAndCountDto;

/**
 * The Interface IPurchaseHistoryService.
 */
public interface IPurchaseHistoryService {
	
	/**
	 * @return
	 * @throws ApplicationException
	 */
	Long getPurchaseOrderEntityCount(List<FilterOrSortingVo> filterVo, String searchValue)throws ApplicationException;


	/**
	 * @param skip
	 * @param limit
	 * @param filterVo
	 * @return
	 * @throws ApplicationException
	 */
	List<CompanyAndCountDto> getPurchaseOrderData(Integer skip, int limit, List<FilterOrSortingVo> filterVo, String searchValue)
			throws ApplicationException;

	/**
	 * Gets the download data to excel.
	 *
	 * @param dto the dto
	 * @param list the list
	 * @return the download data to excel
	 */
	ArrayList<HashMap<String, Object>> getDownloadDataToExcel(List<CompanyAndCountDto> dto, List<String> list);

	/**
	 * Gets the purchase order data in download.
	 *
	 * @param companyIds the company ids
	 * @param filterVo the filter vo
	 * @param searchValue the search value
	 * @return the purchase order data in download
	 * @throws ApplicationException the application exception
	 */
	List<CompanyAndCountDto> getpurchaseOrderDataInDownload(List<Integer> companyIds, List<FilterOrSortingVo> filterVo, String searchValue)
			throws ApplicationException;



}
