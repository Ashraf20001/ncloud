package com.digitalpaper.daoImp;


import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.digitalpaper.config.common.base.dao.BaseDao;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.StockTransactionHistoryDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.entity.StockTransactionHistory;

/**
 * The Class StockTransactionHistoryDaoImpl.
 */
@Service
@Transactional
public class StockTransactionHistoryDaoImpl extends BaseDao implements StockTransactionHistoryDao {

	/**
	 * Save stock transaction history.
	 *
	 * @param stockTransactionHistory the stock transaction history
	 * @return the integer
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Integer saveStockTransactionHistory(StockTransactionHistory stockTransactionHistory)
			throws ApplicationException {
		Integer save = 0;
		try {
			save = save(stockTransactionHistory, TableConstants.STOCK_TRANS_HIST);
		} catch (ApplicationException e) {
			throw e;
		}
		return save;
	}

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
	}

}

