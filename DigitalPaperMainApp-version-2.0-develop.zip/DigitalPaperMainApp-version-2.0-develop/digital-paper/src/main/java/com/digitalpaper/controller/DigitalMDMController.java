package com.digitalpaper.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.service.IDigitalManageDataService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;


/**
 * The Class DigitalMDMController.
 */
@RestController
@RequestMapping("/data")
public class DigitalMDMController {

	/** The digital manage data service. */
	@Autowired
	private IDigitalManageDataService digitalManageDataService;

	/**
	 * Export master datas.
	 *
	 * @param tableEntityList the table entity list
	 * @return the list
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@ApiOperation(value = "Master datas export",notes="Export master datas for the table list",response = List.class)
	@PostMapping("/export-master-datas")
	public List<Map<String, Object>> exportMasterDatas(@ApiParam(value = "table list",required = true) @RequestBody List<String> tableEntityList) throws IOException {
		return digitalManageDataService.exportMasterDatas(tableEntityList);
	}

	/**
	 * Import master datas.
	 *
	 * @param recoveryMasterDataMap the recovery master data map
	 * @throws ApplicationException the application exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@ApiOperation(value = "Master datas import",notes="Import master datas for the tables")
	@RequestMapping("/import-master-datas")
	public void importMasterDatas(@ApiParam(value="Master data map")   @RequestBody(required = false) Map<String, Object> recoveryMasterDataMap)
			throws ApplicationException, IOException {
		digitalManageDataService.importMasterData(recoveryMasterDataMap);
	}

}
