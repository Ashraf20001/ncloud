package com.digitalpaper.service;

import java.io.IOException;
import java.util.List;

import javax.mail.MessagingException;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.ChangePasswordDto;
import com.digitalpaper.transfer.object.dto.CustomerDto;
import com.digitalpaper.transfer.object.dto.CustomerWithPassword;
import com.digitalpaper.transfer.object.dto.ResetPasswordDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.entity.PaperDetails;

import freemarker.core.ParseException;
import freemarker.template.MalformedTemplateNameException;
import freemarker.template.TemplateException;
import freemarker.template.TemplateNotFoundException;

/**
 * The Interface CustomerService.
 */
public interface CustomerService {

	/**
	 * Gets the customer list.
	 *
	 * @param min the min
	 * @param max the max
	 * @param filter the filter
	 * @param searchValue the search value
	 * @return the customer list
	 * @throws ApplicationException the application exception
	 * @throws NoSuchFieldException the no such field exception
	 * @throws SecurityException the security exception
	 * @throws IllegalArgumentException the illegal argument exception
	 * @throws IllegalAccessException the illegal access exception
	 */
	public List<CustomerDto> getCustomerList(Integer min, Integer max, List<FilterOrSortingVo> filter, String searchValue) throws ApplicationException, 
	
		NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException;

	/**
	 * Save customer.
	 *
	 * @param paperDetails the paper details
	 * @return the customer with password
	 * @throws ApplicationException the application exception
	 */
	public CustomerWithPassword saveCustomer(PaperDetails paperDetails) throws ApplicationException;

	/**
	 * Gets the customer by username.
	 *
	 * @param username the username
	 * @return the customer by username
	 */
	public CustomerDto getCustomerByUsername(String username);

	/**
	 * Gets the login customer details.
	 *
	 * @return the login customer details
	 * @throws ApplicationException the application exception
	 */
	public CustomerDto getLoginCustomerDetails() throws ApplicationException;

	/**
	 * Update login customer.
	 *
	 * @param data the data
	 * @return the string
	 * @throws ApplicationException the application exception
	 */
	public String updateLoginCustomer(CustomerDto data) throws ApplicationException;
	
	/**
	 * Reset customer password.
	 *
	 * @param resetPasswordDto the reset password dto
	 * @throws ApplicationException the application exception
	 */
	public void resetCustomerPassword(ResetPasswordDto resetPasswordDto) throws ApplicationException;
	
	/**
	 * Validate email.
	 *
	 * @param emailId the email id
	 * @return the string
	 * @throws ApplicationException the application exception
	 */
	public String validateEmail(String emailId) throws ApplicationException;
	
	/**
	 * Update customer password.
	 *
	 * @param resetPasswordDto the reset password dto
	 * @return the string
	 * @throws ApplicationException the application exception
	 */
	public String updateCustomerPassword(ResetPasswordDto resetPasswordDto) throws ApplicationException;

	/**
	 * Change password.
	 *
	 * @param changePassword the change password
	 * @throws ApplicationException the application exception
	 */
	public void changePassword(ChangePasswordDto changePassword) throws ApplicationException;

	/**
	 * Gets the coustomer count.
	 *
	 * @param filter the filter
	 * @param searchvalue the searchvalue
	 * @return the coustomer count
	 * @throws ApplicationException the application exception
	 */
	public Long getCoustomerCount(List<FilterOrSortingVo> filter, String searchvalue) throws ApplicationException;

	/**
	 * Updat customer details.
	 *
	 * @param data the data
	 * @return the string
	 * @throws ApplicationException the application exception
	 * @throws TemplateNotFoundException the template not found exception
	 * @throws MalformedTemplateNameException the malformed template name exception
	 * @throws ParseException the parse exception
	 * @throws MessagingException the messaging exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws TemplateException the template exception
	 */
	public String updatCustomerDetails(CustomerDto data) throws ApplicationException, TemplateNotFoundException, MalformedTemplateNameException, ParseException, MessagingException, IOException, TemplateException;

	/**
	 * Customer excel download.
	 *
	 * @param customerList the customer list
	 * @param downloadColumn the download column
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	public ResponseEntity<ByteArrayResource> customerExcelDownload(List<CustomerDto> customerList,List<String> downloadColumn) throws ApplicationException;

	/**
	 * Save user profile url.
	 *
	 * @param customerId the customer id
	 * @param profileUrl the profile url
	 * @throws ApplicationException the application exception
	 */
	public void saveUserProfileUrl(Integer customerId, String profileUrl) throws ApplicationException;

	/**
	 * Gets the profile picture.
	 *
	 * @param identity the identity
	 * @return the profile picture
	 * @throws ApplicationException the application exception
	 */
	public String getProfilePicture(String identity) throws ApplicationException;
	
	/**
	 * Save customer from bulk upload.
	 *
	 * @param paperDetails the paper details
	 * @param userDetails the user details
	 * @return the customer with password
	 * @throws ApplicationException the application exception
	 */
	public CustomerWithPassword saveCustomerFromBulkUpload(PaperDetails paperDetails, UserInfo userDetails) throws ApplicationException;
}
