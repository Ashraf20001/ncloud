package com.digitalpaper.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.service.IPurchaseHistoryService;
import com.digitalpaper.service.IStockService;
import com.digitalpaper.transfer.object.dto.CompanyAndCountDto;
import com.digitalpaper.transfer.object.dto.DownloadListVo;
import com.digitalpaper.utils.core.ApplicationUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class PurchaseHistoryController.
 */
@RestController
public class PurchaseHistoryController {
	
	/** The stock service. */
	@Autowired
	IStockService stockService;
	
	/** IPurchaseHistoryService. */
	@Autowired
	private IPurchaseHistoryService iPurchaseHistoryService;
	
	/**
	 * Gets the purchase order count.
	 *
	 * @param searchValue the search value
	 * @param filterVo the filter vo
	 * @return the purchase order count
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Purchase history count",notes="Count the total number of orders purchased history",response=Long.class)
	@PostMapping("/getPurchaseOrderEntityCount")
	public Long getPurchaseOrderCount(@ApiParam(value="Search data",required = true) @RequestParam(name = "searchValue") String searchValue,  @ApiParam(value="Filter data payload") @RequestBody(required = false) List<FilterOrSortingVo> filterVo) throws ApplicationException {
		return iPurchaseHistoryService.getPurchaseOrderEntityCount(filterVo, searchValue);
	}

	/**
	 * Gets the purchase order data.
	 *
	 * @param skip the skip
	 * @param limit the limit
	 * @param searchValue the search value
	 * @param filterVo the filter vo
	 * @return the purchase order data
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Purchase history list",notes="Get the list of purchase order history",response=List.class)
	@PostMapping("/purchaseHistory")
	public List<CompanyAndCountDto> getPurchaseOrderData(@ApiParam(value="Skip data count",required=true) @RequestParam(name = "skip") Integer skip,
			@ApiParam(value="Limit data count",required=true) @RequestParam(name = "limit") int limit,
			@ApiParam(value="Search data",required=true) @RequestParam(name = "searchValue") String searchValue,
			@ApiParam(value="Filter data payload") @RequestBody(required = false) List<FilterOrSortingVo> filterVo)
			throws ApplicationException {
		return iPurchaseHistoryService.getPurchaseOrderData(skip, limit, filterVo,searchValue);
	}
	
	/**
	 * Download method.
	 *
	 * @param searchValue the search value
	 * @param downloadList the download list
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Purchase history download",notes="Download the list of purchase history",response=ResponseEntity.class)
	@PostMapping("/purchase-history-download")
	public ResponseEntity<org.springframework.core.io.InputStreamResource> DownloadMethod(
			@ApiParam(value="Search data",required=true) @RequestParam(name = "searchValue") String searchValue, 
			@ApiParam(value="DownloadListVo payload data",required=true) @RequestBody DownloadListVo downloadList)
			throws ApplicationException {
		
		List<CompanyAndCountDto> dto = iPurchaseHistoryService.getpurchaseOrderDataInDownload(downloadList.getCompanyId(), downloadList.getFilterVo(), searchValue);
		
		ArrayList<HashMap<String, Object>> data = new ArrayList<HashMap<String, Object>>();
		if(ApplicationUtils.isValidateObject(dto)){
			 data  = iPurchaseHistoryService.getDownloadDataToExcel(dto,downloadList.getColumnList());
		}

		if(Boolean.FALSE.equals(ApplicationUtils.isValidateObject(data))) {
	      	  return null;
	        }
		
		return stockService.excelDownload(data);
	}
}
