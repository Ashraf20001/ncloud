package com.digitalpaper.dao;

import java.util.List;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.entity.BulkRevokeErrorTable;

/**
 * The Interface IBulkRevokeDao.
 */
public interface IBulkRevokeDao {


	/**
	 * @param bulkUploadId 
	 * @param filterVo
	 * @return
	 * @throws ApplicationException
	 */
	Long getRevokeScratchCount(Integer bulkUploadId, List<FilterOrSortingVo> filterVo) throws ApplicationException;
	
	/**
	 * @param skip
	 * @param limit
	 * @param filterVo
	 * @param errorSuccess
	 * @return
	 * @throws ApplicationException
	 */
	List<Object[]> getErrorSuccessData(Integer skip, Integer limit,Integer bulkUploadId, List<FilterOrSortingVo> filterVo,
			Boolean errorSuccess) throws ApplicationException;

	/**
	 * @param identity
	 * @return
	 * @throws ApplicationException
	 */
	BulkRevokeErrorTable getBulkRevokeForDelete(String identity) throws ApplicationException;

	/**
	 * @param delete
	 * @return
	 * @throws ApplicationException
	 */
	BulkRevokeErrorTable updateBulkRevoke(BulkRevokeErrorTable delete) throws ApplicationException;

	/**
	 * @param bulkUploadId 
	 * @param filterVo
	 * @param errorSuccessCount
	 * @return
	 * @throws ApplicationException
	 */
	Long getErrorSuccesCount(Integer bulkUploadId, List<FilterOrSortingVo> filterVo, Boolean errorSuccessCount) throws ApplicationException;





}