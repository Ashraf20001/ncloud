
package com.digitalpaper.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;

import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.PurchaseOrderDto;
import com.digitalpaper.transfer.object.dto.SaveStockDataVo;
import com.digitalpaper.transfer.object.dto.StockDto;
import com.digitalpaper.transfer.object.entity.Stock;

/**
 * The Interface IStockService.
 */
public interface IStockService {

	/**
	 * Gets the stock data.
	 *
	 * @return the stock data
	 */
	StockDto getStockData();


	/**
	 * Excel download.
	 *
	 * @param data the data
	 * @return the response entity
	 */
	ResponseEntity<InputStreamResource> excelDownload(ArrayList<HashMap<String, Object>> data);

	/**
	 * Gets the purchase details.
	 *
	 * @param selectedColumnList the selected column list
	 * @return the purchase details
	 */
	ArrayList<HashMap<String, Object>> getpurchaseDetails(String[] selectedColumnList);

	/**
	 * Save or update.
	 *
	 * @param data the data
	 * @return the integer
	 * @throws ApplicationException the application exception
	 */
	Integer saveOrUpdate(SaveStockDataVo data) throws ApplicationException;

	/**
	 * Gets the drop down list.
	 *
	 * @return the drop down list
	 * @throws ApplicationException the application exception
	 */
	List<String> getDropDownList()throws ApplicationException;

	/**
	 * Map offline payment.
	 *
	 * @param storageIdList the storage id list
	 */
	void mapOfflinePayment(Map<String, List<Integer>> storageIdList);
	
	/**
	 * Save company id.
	 *
	 * @param companyId the company id
	 * @param userId the user id
	 * @return the stock
	 */
	Stock saveCompanyId(Integer companyId,Integer userId);

	/**
	 * Save allocation ids.
	 *
	 * @param integerList the integer list
	 * @param companyId the company id
	 * @param userId the user id
	 * @param isPoolBasedAllocation the is pool based allocation
	 */
	void saveAllocationIds(List<Integer> integerList, Integer companyId, Integer userId, Boolean isPoolBasedAllocation);


	/**
	 * Gets the stock details based on login user.
	 *
	 * @param request the request
	 * @return the stock details based on login user
	 */
	StockDto getStockDetailsBasedOnLoginUser(HttpServletRequest request);


	/**
	 * Gets the purchase order details.
	 *
	 * @param id the id
	 * @return the purchase order details
	 * @throws ApplicationException the application exception
	 */
	PurchaseOrderDto getPurchaseOrderDetails(Integer id) throws ApplicationException;

}
