package com.digitalpaper.dao;

import java.util.List;

import com.digitalpaper.transfer.object.entity.PaperDetails;

/**
 * The Interface IDigitalPaperDao.
 */
public interface IDigitalPaperDao {

	/**
	 * Check for duplicate policy number.
	 *
	 * @param pdPolicyNumber the pd policy number
	 * @param id the id
	 * @return the paper details
	 */
	PaperDetails checkForDuplicatePolicyNumber(String pdPolicyNumber, Integer id);

	/**
	 * Check duplicate registration number or chassis number.
	 *
	 * @param vdRegistrationNumber the vd registration number
	 * @param vdChassisNumber the vd chassis number
	 * @param status the status
	 * @return the list
	 */
	List<PaperDetails> checkDuplicateRegistrationNumberOrChassisNumber(String vdRegistrationNumber, String vdChassisNumber,Integer status);

	/**
	 * Save digital paper details.
	 *
	 * @param paperDetailsEntity the paper details entity
	 * @return the integer
	 */
	Integer saveDigitalPaperDetails(PaperDetails paperDetailsEntity);

	/**
	 * Gets the paper details.
	 *
	 * @param registerNo the register no
	 * @return the paper details
	 */
	PaperDetails getPaperDetails(String registerNo);

	/**
	 * Gets the digital paper details.
	 *
	 * @param companyId the company id
	 * @param userId the user id
	 * @return the digital paper details
	 */
	List<PaperDetails> getDigitalPaperDetails(Integer companyId, Integer userId);

	/**
	 * Gets the digital paper data.
	 *
	 * @param paperIdentity the paper identity
	 * @param pdPolicyNumber the pd policy number
	 * @return the digital paper data
	 */
	PaperDetails getDigitalPaperData( String paperIdentity, String pdPolicyNumber);

	/**
	 * Update digital paer.
	 *
	 * @param paperDetailsEntity the paper details entity
	 */
	void updateDigitalPaer(PaperDetails paperDetailsEntity);
	
	/**
	 * Gets the digital paper data list by email id.
	 *
	 * @param emailId the email id
	 * @param companyId the company id
	 * @return the digital paper data list by email id
	 */
	List<PaperDetails> getDigitalPaperDataListByEmailId(String emailId, Integer companyId);

	/**
	 * Gets the digital paper details by customer.
	 *
	 * @param customerId the customer id
	 * @return the digital paper details by customer
	 */
	List<PaperDetails> getDigitalPaperDetailsByCustomer(Integer customerId);

	/**
	 * Check for duplicate chassis number.
	 *
	 * @param vdChassisNumber the vd chassis number
	 * @param status the status
	 * @return the paper details
	 */
	PaperDetails checkForDuplicateChassisNumber(String vdChassisNumber, Integer status);

	/**
	 * Gets the paperticuler paper based on id.
	 *
	 * @param customerId the customer id
	 * @param paperId the paper id
	 * @return the paperticuler paper based on id
	 */
	PaperDetails getPaperticulerPaperBasedOnId(Integer customerId, String paperId);


}
