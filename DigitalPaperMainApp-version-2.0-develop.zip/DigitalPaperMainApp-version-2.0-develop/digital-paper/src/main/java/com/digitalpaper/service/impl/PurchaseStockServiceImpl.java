package com.digitalpaper.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.digitalpaper.config.DigitalPaperCache;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.config.property.EnvironmentProperties;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.IStockDao;
import com.digitalpaper.dao.IStockNotificationDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.purchasestock.dao.PurchaseStockDao;
import com.digitalpaper.service.IStockNotificationSevice;
import com.digitalpaper.service.PurchaseStockService;
import com.digitalpaper.transfer.object.dto.AssociationDashboardCountDto;
import com.digitalpaper.transfer.object.dto.CompanyTransactionDto;
import com.digitalpaper.transfer.object.dto.PaymentDetailsDto;
import com.digitalpaper.transfer.object.dto.PurchaseOrderDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.dto.ViewHistoryDto;
import com.digitalpaper.transfer.object.entity.PaymentDetails;
import com.digitalpaper.transfer.object.entity.PurchaseOrderEntity;
import com.digitalpaper.transfer.object.entity.Stock;
import com.digitalpaper.transfer.object.entity.StockFileMapping;
import com.digitalpaper.transfer.object.entity.StockNotification;
import com.digitalpaper.transfer.object.entity.UserType;
import com.digitalpaper.transfer.object.enums.PaymentModeEnum;
import com.digitalpaper.transfer.object.enums.PaymentStatusEnum;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;
import com.digitalpaper.utils.core.ApplicationDateUtils;
import com.digitalpaper.utils.core.ApplicationFormatUtils;
import com.digitalpaper.utils.core.ApplicationUtils;

/**
 * The Class PurchaseStockServiceImpl.
 */
@Service
@Transactional
public class PurchaseStockServiceImpl implements PurchaseStockService{
	
	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ApplicationDateUtils.class);
	/**
	 * PurchaseStockDao
	 */
	@Autowired
	private PurchaseStockDao purchaseStockDao;


	/**
	 * LoggedInUserContextHolder
	 */
	@Autowired
	private LoggedInUserContextHolder loggedInUserContextHolder;

	/**
	 * ModelMapper
	 */
	@Autowired
	private ModelMapper modelMapper;

	/**
	 * IStockNotificationSevice
	 */
	@Autowired
	private IStockNotificationSevice notificationSevice;
	
	/**
	 * IStockNotificationDao
	 */
	@Autowired
	private IStockNotificationDao iStockNotificationDao;
	
	/**
	 * IStockDao
	 */
	@Autowired
	private IStockDao stockDao;
	
	/**
	 * EnvironmentProperties
	 */
	@Autowired
	private EnvironmentProperties environmentProperties;
	/**
	 * DigitalPaperCache
	 */
	@Autowired
	private DigitalPaperCache digitalPaperCache;

	/** The application format utils. */
	@Autowired
	private ApplicationFormatUtils applicationFormatUtils;

	/**
	 *
	 * @param min
	 * @param max
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public List<PurchaseOrderDto> getPurchaseList(int min, int max,String searchValue,List<FilterOrSortingVo> filter) throws ApplicationException {

		List<PurchaseOrderDto> purchaseOrderListDto= new ArrayList<>();

		UserInfo userDetails = loggedInUserContextHolder.getLoggedInUser();
		Integer companyId=userDetails.getCompanyId();
		valueListStringConversion(filter);

		List<Object[]> purchaseOrderFilterList = purchaseStockDao.getPurchaseOrderList(companyId, min, max,searchValue,filter);
		if(ApplicationUtils.isValidList(purchaseOrderFilterList)) {
			purchaseOrderListDto=convertObjectArrayToPurchaseOrderDto(purchaseOrderFilterList);
		}
		return purchaseOrderListDto;
	}


	/**
	 * Convert object array to purchase order dto.
	 *
	 * @param purchaseOrderFilterList the purchase order filter list
	 * @return the list
	 */
	private List<PurchaseOrderDto> convertObjectArrayToPurchaseOrderDto(List<Object[]> purchaseOrderFilterList) {
		List<PurchaseOrderDto> purchaseOrderDtos = new ArrayList<PurchaseOrderDto>();
		for(Object[] object:purchaseOrderFilterList) {
			PurchaseOrderDto purchaseOrderDto = new PurchaseOrderDto();
			String paymentMethod=PaymentModeEnum.getPaymentModeById((Integer) object[6]).getPaymentMode();
			object[6]=paymentMethod;
			String paymentStatus=PaymentStatusEnum.getPaymentStatusEnumById((Integer) object[7]).getPaymentStatus();
			object[7]=paymentStatus;
			purchaseOrderDto = Optional.of(object).map(o -> new PurchaseOrderDto(o))
            .orElseGet(null);
			 purchaseOrderDtos.add(purchaseOrderDto);
		}
		return purchaseOrderDtos;
	}


	

	/**
	 *@return string
	 *@method approveOrRejectPurchaseDetails
	 *@throws ApplicationExcetion
	 */
	@Override
	public String approveOrRejectPurchaseDetails(PaymentDetailsDto paymentDetailsDto) throws ApplicationException {
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		UserType userTypeId = loggedInUser.getUserTypeId();
		if (!userTypeId.getUserTypeName().equals(ApplicationConstants.ASSOCIATION)) {
			throw new ApplicationException(ErrorCodes.UN_AUTHORIZED);
		}
		PurchaseOrderEntity purchaseOrder = purchaseStockDao
				.getPurchaseOrderFromPurchaseId(paymentDetailsDto.getPurchaseId());
		if (PaymentStatusEnum.getPaymentStatusEnumById(purchaseOrder.getOrderStatus()).getPaymentStatus().equals(PaymentStatusEnum.SUCCESS.getPaymentStatus())) {
			throw new ApplicationException(ErrorCodes.PURCHASE_ALREADY_DONE);
		}
		PaymentDetails paymentDetails = purchaseStockDao.getPaymentDetailsByOrderId(purchaseOrder.getOrderId());
		PaymentStatusEnum paymentStatusEnum = null;
		if(ApplicationUtils.isValidString(paymentDetailsDto.getActionButton())) {
			paymentStatusEnum = PaymentStatusEnum.getPaymentStatusEnum(paymentDetailsDto.getActionButton());
		}
		paymentDetails.setPaymentStatus(paymentStatusEnum.getId());
		paymentDetails.setModifiedBy(loggedInUser.getId());
		paymentDetails.setModifiedDate(LocalDateTime.now());

		purchaseOrder.setOrderStatus(paymentStatusEnum.getId());
		purchaseOrder.setModifiedBy(loggedInUser.getId());
		purchaseOrder.setModifiedDate(LocalDateTime.now());

		purchaseStockDao.updatePaymentDetails(paymentDetails);
		purchaseStockDao.updatePurchaseOrder(purchaseOrder);

		PurchaseOrderDto purchaseOrderDto = modelMapper.map(purchaseOrder, PurchaseOrderDto.class);
		notificationSevice.saveNotification(paymentDetailsDto.getActionButton(), purchaseOrderDto);

		if(paymentDetailsDto.getActionButton().equalsIgnoreCase(ApplicationConstants.SUCCESS)) { 
			Stock stock = stockDao.getStockData(purchaseOrder.getCompanyId());
			if (Boolean.FALSE.equals(ApplicationUtils.isValidateObject(stock))) {
				throw new ApplicationException(ErrorCodes.INVALID_STOCK);
			}
			stock.setModifiedBy(loggedInUser.getId());
			stock.setModifiedDate(LocalDateTime.now());
			stock.setStockCount(stock.getStockCount() + purchaseOrder.getStockCount());
			stockDao.updateStock(stock);
			return ApplicationConstants.STOCK_SAVED_SUCCESS;
		}
		if(paymentDetailsDto.getActionButton().equals(ApplicationConstants.FAILED)) {
			return ApplicationConstants.STOCK_REQUEST_SUCCESS;
		}
		else if(paymentDetailsDto.getActionButton().equalsIgnoreCase(ApplicationConstants.REJECTED)) {
			return ApplicationConstants.STOCK_REQUEST_SUCCESS;
		}
		return ApplicationConstants.STOCK_SAVED_SUCCESS;
	}
  

	/**
	 *@param filterSortingVo
	 *@param min
	 *@param max
	 *@throws ApplicationException
	 *@return PaymentDetails
	 */
	@Override
	public List<ViewHistoryDto> getTransactionDetails(CompanyTransactionDto companyTransactionList, String searchvalue)
			throws ApplicationException {
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		UserType userTypeId = loggedInUser.getUserTypeId();
		if (!userTypeId.getUserTypeName().equals(ApplicationConstants.ASSOCIATION)) {
			throw new ApplicationException(ErrorCodes.UN_AUTHORIZED);
		}
		List<ViewHistoryDto> viewHistoryDtoList= new ArrayList<ViewHistoryDto>();
		if(ApplicationUtils.isValidObject(companyTransactionList)) {
			
			HashMap<Integer, String> companyListMap = digitalPaperCache.getCompanyList();
			List<Integer> matchingKey = companyListMap.entrySet()
	                .stream()
	                .filter(entry -> entry.getValue().toLowerCase().contains(searchvalue.toLowerCase()))
	                .map(Map.Entry::getKey)
	                .collect(Collectors.toList());
			
			valueListStringConversion(companyTransactionList.getFilter());
	
			List<PaymentDetails> paymentDetailsByFilter = purchaseStockDao.getPaymentDetailsByFilter(companyTransactionList, searchvalue, matchingKey);
			viewHistoryDtoList = convertPaymentDetailsEntitytoViewHistoryDto(companyListMap, paymentDetailsByFilter);
			
			if (companyTransactionList.getIsNotification() == Boolean.TRUE) {
				for (Integer companyId : companyTransactionList.getCompanyId()) {
					List<StockNotification> notification = iStockNotificationDao.getNotificationPurchHistory(companyId);
					for (StockNotification isRead : notification) {
						isRead.setRead(true);
						iStockNotificationDao.updateNotification(isRead);
					}
				}

			}
			
		}
		else {
			throw new ApplicationException(ErrorCodes.INVALID_DATA);
		}
		return viewHistoryDtoList;
	}

 
	/**
	 * Value list string conversion.
	 *
	 * @param filterVoList the filter vo list
	 */
	private void valueListStringConversion(List<FilterOrSortingVo> filterVoList) {
		if(ApplicationUtils.isValidList(filterVoList)) {
				for(FilterOrSortingVo filterObject: filterVoList) {
				List<String> valueList = filterObject.getValueList();
				if(ApplicationUtils.isValidList(valueList)) {
					List<String> integerListData=new ArrayList<String>();
					for(String value:valueList) {
						if(filterObject.getColumnName().equals(ApplicationConstants.PAYMENT_METHOD_COLUMN) || filterObject.getColumnName().equals("paymentMode")) {
							Integer ordinal = PaymentModeEnum.getPaymentModeByValue(value).ordinal()+1;
							integerListData.add(ordinal.toString());
						}
						else {
							Integer ordinal = PaymentStatusEnum.getPaymentStatusEnum(value).ordinal()+1;
							integerListData.add(ordinal.toString());
						}
					}
					valueList=integerListData;
				}
				filterObject.setValueList(valueList);
			}
		}
	}

	/**
	 * Gets the purchase order count.
	 *
	 * @param filterOrSortingVo the filter or sorting vo
	 * @param searchValue the search value
	 * @return the purchase order count
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Long getPurchaseOrderCount(List<FilterOrSortingVo> filterOrSortingVo,String searchValue) throws ApplicationException {
		UserInfo userDetails = loggedInUserContextHolder.getLoggedInUser();
		Integer companyId=userDetails.getCompanyId();
		valueListStringConversion(filterOrSortingVo);
		Long purchaseOrderList=purchaseStockDao.getPurchaseOrderCount(companyId,filterOrSortingVo, searchValue);
		return purchaseOrderList;
	}

	/**
	 * Convert payment details entityto view history dto.
	 *
	 * @param companyMapping the company mapping
	 * @param paymentDetailsList the payment details list
	 * @return the list
	 */
	private List<ViewHistoryDto> convertPaymentDetailsEntitytoViewHistoryDto(Map<Integer, String> companyMapping,
			List<PaymentDetails> paymentDetailsList) {
		List<ViewHistoryDto> viewHistoryList = new ArrayList<ViewHistoryDto>();
		for(PaymentDetails paymentDetails:paymentDetailsList) {
			ViewHistoryDto viewHistory= new ViewHistoryDto();
			StockFileMapping stockFileMappingByOrderId = null;
			try {
				 stockFileMappingByOrderId = purchaseStockDao.getStockFileMappingByOrderId(paymentDetails.getOrderId().getOrderId());
			} catch (Exception e) {
				logger.error("Error while getting company logo ".concat(e.getMessage()) );
			}
			viewHistory.setOrderStatus(paymentDetails.getOrderId().getOrderStatus());
			viewHistory.setCompanyName(companyMapping.get(paymentDetails.getOrderId().getCompanyId()));
			viewHistory.setStockCount(paymentDetails.getOrderId().getStockCount());
			viewHistory.setPurchaseDate(paymentDetails.getPaymentDate().toString());
			viewHistory.setPaymentStatus(PaymentStatusEnum.getPaymentStatusEnumById(paymentDetails.getPaymentStatus()).name());
			viewHistory.setPurchaseAmount(paymentDetails.getPaidAmount());
			viewHistory.setPaymentMethod(PaymentModeEnum.getPaymentModeById(paymentDetails.getPaymentMode()).name());
			viewHistory.setTransactionId(paymentDetails.getTransactionId());
			viewHistory.setPurchaseId(paymentDetails.getOrderId().getPurchaseId());
			viewHistory.setOrderId(paymentDetails.getOrderId().getOrderId());
			viewHistory.setFileMappingId(ApplicationUtils.isValidateObject(stockFileMappingByOrderId)?stockFileMappingByOrderId.getStorageId():null);
			viewHistoryList.add(viewHistory);
		}
		return viewHistoryList;
	}


	/**
	 * Gets the all purchase order count.
	 *
	 * @param companyTransactionDto the company transaction dto
	 * @param searchValue the search value
	 * @return the all purchase order count
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Long getAllPurchaseOrderCount(CompanyTransactionDto companyTransactionDto, String searchValue) throws ApplicationException {
		Long purchaseOrderListCount=null;
		if(ApplicationUtils.isValidObject(companyTransactionDto)) {
			if(ApplicationUtils.isValidList(companyTransactionDto.getCompanyId())) {
				valueListStringConversion(companyTransactionDto.getFilter());
				purchaseOrderListCount=purchaseStockDao.getPaymentDetailsCount(companyTransactionDto,searchValue);
			}
			else {
				throw new ApplicationException(ErrorCodes.INVALID_SELECTION);
			}
		}
		else {
			throw new ApplicationException(ErrorCodes.INVALID_DATA);
		}

		return purchaseOrderListCount;
	}

	/**
	 * Download data converting.
	 *
	 * @param dto the dto
	 * @param selectedColumnList the selected column list
	 * @return the array list
	 */
	@Override
	public ArrayList<HashMap<String, Object>> downloadDataConverting(List<ViewHistoryDto> dto,
			List<String> selectedColumnList) {


			ArrayList<HashMap<String, Object>> list = new ArrayList<>();

			for (int i = 0; i <= dto.size() - 1; i++) {

				ViewHistoryDto companyCount = dto.get(i);
				HashMap<String, Object> map = new LinkedHashMap<>();
				if(ApplicationUtils.isValidateObject(selectedColumnList)) {

					for (String field : selectedColumnList) {

						switch (field.trim()) {

						case TableConstants.PURCHASE_ID:
							map.put(TableConstants.PURCHASE_ID, companyCount.getPurchaseId());
							break;

						case TableConstants.COMPANYNAME:
							map.put(TableConstants.COMPANYNAME, companyCount.getCompanyName());
							break;

						case TableConstants.TRANSACTION_ID:
							map.put(TableConstants.TRANSACTION_ID, companyCount.getTransactionId());
							break;

						case TableConstants.PAYMENT_DATE:
							map.put(TableConstants.PAYMENT_DATE, companyCount.getPurchaseDate());
							break;

						case TableConstants.PAYMENT_TYPE:
							map.put(TableConstants.PAYMENT_TYPE, companyCount.getPaymentMethod());
							break;

						case TableConstants.AMOUNT:
							map.put(TableConstants.AMOUNT, companyCount.getPurchaseAmount());
							break;

						case TableConstants.PAYMENT_STATUS:
							map.put(TableConstants.PAYMENT_STATUS, companyCount.getPaymentStatus());
							break;
						}
					}
				}
				list.add(map);
		}
		return list;
	}


	/**
	 * Gets the stock file id.
	 *
	 * @param id the id
	 * @return the stock file id
	 */
	@Override
	public Integer getStockFileId(Integer id) {
		Integer storageId=null;
		StockFileMapping stockFileMappingByOrderId = purchaseStockDao.getStockFileMappingByOrderId(id);
		if(ApplicationUtils.isValidateObject(stockFileMappingByOrderId)) {
			 storageId = stockFileMappingByOrderId.getStorageId();
		}
		
		 return storageId;
	}


	/**
	 * Common download.
	 *
	 * @param data the data
	 * @param columnList the column list
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	@Override
	public ResponseEntity<InputStreamResource> commonDownload(List<PurchaseOrderDto> data, List<String> columnList)
			throws ApplicationException {


		ArrayList<LinkedHashMap<String, Object>> DataList = new ArrayList<LinkedHashMap<String, Object>>();
		
		for (PurchaseOrderDto value : data) {
			LinkedHashMap<String, Object> map = new LinkedHashMap<>();
			
			if (ApplicationUtils.isValidateObject(columnList)) {
				
				for (String columnName : columnList) {
					switch (columnName.trim()) {
					
					case TableConstants.PURCHASR_ID:
						map.put(TableConstants.PURCHASR_ID, value.getPurchaseId());
						break;
						
					case TableConstants.TRANSACTION_ID:
						map.put(TableConstants.TRANSACTION_ID, value.getTransactionId());
						break;
						
					case TableConstants.DATEOF_PURCHASE:
						map.put(TableConstants.DATEOF_PURCHASE, value.getPurchaseDate());
						break;
						
					case TableConstants.PAPERS_COUNT:
						map.put(TableConstants.PAPERS_COUNT,
								(ApplicationUtils.isValidId(value.getStockCount())?applicationFormatUtils.convertValueIntoNumberFormat(Double.parseDouble(String.valueOf(value.getStockCount()))):0));
						break;

					case TableConstants.PURCHASE_AMT:
						map.put(TableConstants.PURCHASE_AMT, value.getCurrencyType() + " "+
								(ApplicationUtils.isValidateObject(value.getPurchaseAmount())?applicationFormatUtils.convertvalueWithFormat(value.getPurchaseAmount()):0));
						break;
						
					case TableConstants.PAYMENT_METHOD:
						map.put(TableConstants.PAYMENT_METHOD,value.getPaymentMethod());
						break;
						
					case TableConstants.PAYMENT_STATUS:
						map.put(TableConstants.PAYMENT_STATUS,value.getPaymentStatus());
						break;
					}
				}
			}
			DataList.add(map);
		}
		
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		HttpHeaders header = new HttpHeaders();
		
		try {
			
			List<String> keyList = new ArrayList<>();
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet(ApplicationConstants.REPORTS);
			XSSFRow hederRow = sheet.createRow((int) ApplicationConstants.ZERO);
			
			XSSFFont headerFont = workbook.createFont();
			headerFont.setBold(true);
			
			XSSFCellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);
			
			int rowIndex = ApplicationConstants.ZERO;

			for (LinkedHashMap<String, Object> map : DataList) { // Iterated only for Extracting Header Columns
				Set<String> keys = map.keySet();
				keyList = keys.stream().collect(Collectors.toList());
				for (int i = ApplicationConstants.ZERO; i < keyList.size(); i++) {
					XSSFCell headerCell = hederRow.createCell(i);
					 String headerText =Character.toUpperCase(keyList.get(i).charAt(0)) + keyList.get(i).substring(1); // Capitalize the first letter
					 
					headerCell.setCellValue(headerText);
					headerCell.setCellStyle(headerCellStyle);
					
				}
			}
			
			for (HashMap<String, Object> map : DataList) {
				int columnIndex = ApplicationConstants.ZERO;
				XSSFRow row = sheet.createRow((int) rowIndex + 1);
				for (Entry<String, Object> entry : map.entrySet()) {
					XSSFCell cell = row.createCell(columnIndex);

					if( entry.getKey().equalsIgnoreCase(TableConstants.DATEOF_PURCHASE)) {
						String object =map.get(entry.getKey()).toString();
						DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
						Date date = dateFormat.parse(object);
						DateFormat formatter = new SimpleDateFormat(environmentProperties.getDateFormat());
						String dateStr = formatter.format(date);
						cell.setCellValue(dateStr);
					}

					else {

						cell.setCellValue((entry.getValue() != null) ? entry.getValue().toString()
								: ApplicationConstants.WITHOUT_SPACE);

					}
					columnIndex++;
				}
				rowIndex++;
			}
			
			if (ApplicationUtils.isValidList(keyList)) {
				for (int index = ApplicationConstants.ZERO; index < keyList.size(); index++) {
					sheet.autoSizeColumn(index);
				}
			}
			
			header.setContentType(new MediaType(ApplicationConstants.APPLICATION,ApplicationConstants.FORCE_DOWNLOAD));
			header.set(HttpHeaders.CONTENT_DISPOSITION, ApplicationConstants.PDF_FORMATE);

			workbook.write(stream);
			ByteArrayOutputStream fileOut = new ByteArrayOutputStream();
			String fileName = "Bulk-upload-sample.xlsx";
			workbook.write(fileOut);
			fileOut.close();
			workbook.close();
			
			ByteArrayInputStream in = new ByteArrayInputStream(fileOut.toByteArray());
			InputStreamResource file = new InputStreamResource(in);
			
			return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName)
					.contentType(MediaType.parseMediaType("application/vnd.ms-excel")).body(file);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * Gets the authority dashboard count.
	 *
	 * @param associationId the association id
	 * @return the authority dashboard count
	 */
	public List<AssociationDashboardCountDto> getAuthorityDashboardCount(Integer associationId) {
		List<AssociationDashboardCountDto> associationDashboardCountDto =purchaseStockDao.getAuthorityDashboardCount(associationId);
		return associationDashboardCountDto;
	}

}
