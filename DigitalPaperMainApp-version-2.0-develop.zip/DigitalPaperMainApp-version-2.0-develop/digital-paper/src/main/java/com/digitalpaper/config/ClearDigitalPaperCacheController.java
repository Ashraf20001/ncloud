package com.digitalpaper.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * The Class ClearDigitalPaperCacheController.
 */
@RestController
public class ClearDigitalPaperCacheController {
	
	/** The Constant Logger. */
	public static final Logger Logger= LoggerFactory.getLogger(ClearDigitalPaperCacheController.class);

	/**
	 * Clearcache.
	 *
	 * @return the boolean
	 */
	@GetMapping("/clear-cache")
	public Boolean Clearcache() {
		DigitalPaperCache.setRoleApiMap(null);
		Logger.info("Role Api Cleared successfully................");
		return Boolean.TRUE;
	} 
	
	/**
	 * Clearcache in systemproperty value.
	 *
	 * @return the boolean
	 */
	@GetMapping("/clear-cache-system-property")
	public Boolean ClearcacheInSystempropertyValue() {
		DigitalPaperCache.setSystemPropertyVAlue(null);
		Logger.info("System Property Cleared successfully................");
		return Boolean.TRUE;
	} 
	
	/**
	 * Clearcache in company list.
	 *
	 * @return the boolean
	 */
	@GetMapping("/clear-cache-companyList")
	public Boolean ClearcacheInCompanyList() {
		DigitalPaperCache.setCompanyList(null);
		Logger.info("Company List Cleared successfully................");
		return Boolean.TRUE;
	} 
	
	/**
	 * Clear make cache.
	 *
	 * @return the boolean
	 */
	@GetMapping("/clear-make-model-usage-cache")
	public Boolean ClearMakeCache() {
		DigitalPaperCache.setMakes(null);
		Logger.info("Make Cleared successfully................");
		DigitalPaperCache.setModels(null);
		Logger.info("Model Cleared successfully................");
		DigitalPaperCache.setUsage(null);
		Logger.info("Usage Cleared successfully................");
		
		return Boolean.TRUE;
	}
	
	
	
}
