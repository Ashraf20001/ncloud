package com.digitalpaper.websocket.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

import com.digitalpaper.config.property.EnvironmentProperties;

/**
 * The Class websocketConfiguration.
 */
@Configuration
@EnableWebSocketMessageBroker
public class websocketConfiguration implements WebSocketMessageBrokerConfigurer{


	/**
	 * front-end URL
	 */
	@Autowired
	private EnvironmentProperties environmentProperties;	
	
	 /**
	 *@param config
	 */
	@Override
	  public void configureMessageBroker(MessageBrokerRegistry config)
	  {
	    config.enableSimpleBroker("/topic");
	    config.setApplicationDestinationPrefixes("/app");
	  }

	 /**
	 *@param registry
	 */
	@Override
	  public void registerStompEndpoints(StompEndpointRegistry
	   registry) {
	    registry.addEndpoint("/ws").setAllowedOrigins(environmentProperties.getUrl()).withSockJS();
	  }
}
