package com.digitalpaper.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitalpaper.aop.annotation.Auditable;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.service.IAuthorityPaperDetailsService;
import com.digitalpaper.transfer.object.dto.AuthorityStockDto;
import com.digitalpaper.transfer.object.dto.CompanyTransactionDto;
import com.digitalpaper.transfer.object.dto.DownloadListVo;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class AuthorityPaperDetailsController.
 */
@RestController
@Auditable
public class AuthorityPaperDetailsController {

	/** The i authority paper details service. */
	@Autowired
	private IAuthorityPaperDetailsService iAuthorityPaperDetailsService;
	
	/**
	 * Gets the stock count.
	 *
	 * @param searchValue the search value
	 * @param filterVo the filter vo
	 * @return the stock count
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Stock count",notes="Get number of stocks for comapany or authority",response = Long.class)
	@PostMapping("/authority/get-stock-count")
	public Long getStockCount(@ApiParam(value="Search data",required = true)  @RequestParam(name = "searchValue") String searchValue,@ApiParam(value = "Filter vo payload")  @RequestBody(required = false) List<FilterOrSortingVo> filterVo) throws ApplicationException {
		return iAuthorityPaperDetailsService.getStockCount(filterVo,null,searchValue);
		
	}
	
	/**
	 * Gets the stock data.
	 *
	 * @param skip the skip
	 * @param limit the limit
	 * @param searchValue the search value
	 * @param isCard the is card
	 * @param filterVo the filter vo
	 * @return the stock data
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Stock data",notes="Get stock list for authority",response = List.class)
	@PostMapping("/get-stock-data")
	public List<AuthorityStockDto> getStockData(@ApiParam(value="Skip data count",required = true) @RequestParam(name = "skip") Integer skip,
		@ApiParam(value = "Limit data count",required = true)	@RequestParam(name = "limit") Integer limit, 
		@ApiParam(value="Search data",required = true) @RequestParam(name = "searchValue") String searchValue,
		@ApiParam(value = "is Card",required = true)	@RequestParam(name="isCard") String isCard,
		@ApiParam(value = "Filter vo payload")	@RequestBody(required = false) List<FilterOrSortingVo> filterVo) throws ApplicationException {
			
		return iAuthorityPaperDetailsService.getStockData(skip,limit,searchValue,filterVo,null, Boolean.FALSE,isCard);

	}
	
	/**
	 * Gets the paper details by company count.
	 *
	 * @param searchValue the search value
	 * @param companyTransactionDto the company transaction dto
	 * @return the paper details by company count
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Paper details count",notes="Get paper details count for the company",response = Long.class)
	@PostMapping("/get-paperdetailscount-bycompany")
	public Long getPaperDetailsByCompanyCount(@ApiParam(value="Search data",required = true) @RequestParam(name = "searchValue") String searchValue,  @ApiParam("Company transaction payload") @RequestBody(required = false) CompanyTransactionDto companyTransactionDto)
			throws ApplicationException {
		return iAuthorityPaperDetailsService.getPaperDetailsByCompanyCount(companyTransactionDto, searchValue);

	}
	
	/**
	 * Gets the paper details by company list.
	 *
	 * @param searchValue the search value
	 * @param companyTransactionDto the company transaction dto
	 * @return the paper details by company list
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Paper details list",notes="Get paper details list for the company",response = List.class)
	@PostMapping("/get-paperdetailslist-bycompany")
	public List<PaperDetailsDto> getPaperDetailsByCompanyList(@ApiParam(value="Search data",required = true) @RequestParam(name = "searchValue") String searchValue, @ApiParam("Company transaction payload") @RequestBody(required = false) CompanyTransactionDto companyTransactionDto) throws ApplicationException {
		return iAuthorityPaperDetailsService.getPaperDetailsByCompanyList(companyTransactionDto, searchValue);
		
	}
	
	/**
	 * Download paper details.
	 *
	 * @param searchValue the search value
	 * @param downloadVo the download vo
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Paper details download",notes="Download authority paper details list",response = List.class)
	@PostMapping("/get-paperdetails-download")
	public ResponseEntity<ByteArrayResource> downloadPaperDetails( @ApiParam(value="Search data",required = true)  @RequestParam(name = "searchValue") String searchValue, @ApiParam(value="Download list payload",required=true) @RequestBody (required = true) DownloadListVo downloadVo) throws ApplicationException
	{
		return  iAuthorityPaperDetailsService.downloadPaperInExcel(downloadVo, searchValue);
	}
	
	/**
	 * Drop down for paper details.
	 *
	 * @return the list
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Paper details dropdown",notes = "Get columns for dropdown in paper details",response = List.class)
	@GetMapping("/get-dropdown-paperdetails")
	public List<String> dropDownForPaperDetails() throws ApplicationException
	{
		return iAuthorityPaperDetailsService. getColumnsInDropDownPaperDetails();
		
	}
	
	/**
	 * Download view paper.
	 *
	 * @param searchValue the search value
	 * @param downloadVo the download vo
	 * @param request the request
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "View paper details download",notes="Download view paper details list",response = ResponseEntity.class)
	@PostMapping("/download-view-paper")
	public  ResponseEntity<ByteArrayResource>downloadViewPaper(@ApiParam(value = "Search data",required = true)  @RequestParam(name = "searchValue") String searchValue,@ApiParam(value = "Downloadlist vo payload",required = true) @RequestBody (required = true) DownloadListVo downloadVo, HttpServletRequest request) throws ApplicationException 
	{
		return iAuthorityPaperDetailsService.downloadViewPaper(searchValue,downloadVo,request);
		
	}
	
}
