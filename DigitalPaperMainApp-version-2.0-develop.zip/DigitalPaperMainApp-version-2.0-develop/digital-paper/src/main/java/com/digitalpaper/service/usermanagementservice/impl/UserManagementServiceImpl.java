package com.digitalpaper.service.usermanagementservice.impl;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.service.usermanagementservice.UserManagementService;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.UserManagementSaveOrUpdateDto;
import com.digitalpaper.utils.core.RestTemplateUtils;

/**
 * The Class UserManagementServiceImpl.
 */
@Service
public class UserManagementServiceImpl implements UserManagementService {
	
	/**
	 * commonServicePath
	 */
	@Value("${dpmainapp.common-service-path}")
    private String commonServicePath;

	/**
	 * RestTemplateUtils
	 */
	@Autowired
	private RestTemplateUtils restTemplateUtils;

	/**
	 * RestTemplate
	 */
	@Autowired
    private RestTemplate restTemplate;

	/**
	 *@param pageIdentity
	 *@param platformIdentity
	 *@param request
	 *
	 */
	@Override
	public ApplicationResponse getUserPageInfo(String pageIdentity, String platformIdentity, HttpServletRequest request)
			throws ApplicationException {
		HttpHeaders httpHeaders = restTemplateUtils.configureRestTemplate(request);
		HttpEntity<String> entity = new HttpEntity<String>(httpHeaders);
		String url = commonServicePath + "/get-user-management-page-info";
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		builder.queryParam("page_id", pageIdentity);
		builder.queryParam("platform_id", platformIdentity);
		return restTemplate.exchange(builder.toUriString(), HttpMethod.GET, entity, ApplicationResponse.class)
				.getBody();
	}

	/**
	 * @param min
	 * @param max
	 * @param platformIdentity
	 * @param request
	 * @return
	 */
	@Override
	public ApplicationResponse getRoleDetailsForCardView(Integer min, Integer max, String platformIdentity,
			HttpServletRequest request) {
		HttpHeaders httpHeaders = restTemplateUtils.configureRestTemplate(request);
		HttpEntity<String> entity = new HttpEntity<String>(httpHeaders);
		String url = commonServicePath + "/get-role-card";
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		builder.queryParam("min", min);
		builder.queryParam("max", max);
		builder.queryParam("platform_identity", platformIdentity);
		return restTemplate.exchange(builder.toUriString(), HttpMethod.GET, entity, ApplicationResponse.class)
				.getBody();
	}

	/**
	 * @param min
	 * @param max
	 * @param request
	 * @return
	 */
	@Override
	public ApplicationResponse getUserDetailsForListView(Integer min, Integer max, HttpServletRequest request) {
		HttpHeaders httpHeaders = restTemplateUtils.configureRestTemplate(request);
		String url = commonServicePath + "/get-user-management-list";
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		builder.queryParam("min", min);
		builder.queryParam("max", max);
		HttpEntity<String> staticEntity = new HttpEntity<String>(httpHeaders);
		ResponseEntity<ApplicationResponse> entity = restTemplate.exchange(builder.toUriString(),
				HttpMethod.GET, staticEntity, ApplicationResponse.class);
		return entity.getBody();
	}

	/**
	 * @param userManagementListDto
	 * @param platformIdentity
	 * @param request
	 * @return
	 */
	@Override
	public ApplicationResponse addEditUser(UserManagementSaveOrUpdateDto userManagementListDto, String platformIdentity,
			HttpServletRequest request) {
		HttpHeaders httpHeaders = restTemplateUtils.configureRestTemplate(request);
		String url = commonServicePath + "/user-management/saveOrUpdate";
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		builder.queryParam("platform_id", platformIdentity);
		HttpEntity<UserManagementSaveOrUpdateDto> staticEntity = new HttpEntity<UserManagementSaveOrUpdateDto>(userManagementListDto, httpHeaders);
		ResponseEntity<ApplicationResponse> entity = restTemplate.exchange(builder.toUriString(),
				HttpMethod.POST, staticEntity, ApplicationResponse.class);
		return entity.getBody();
	}

}
