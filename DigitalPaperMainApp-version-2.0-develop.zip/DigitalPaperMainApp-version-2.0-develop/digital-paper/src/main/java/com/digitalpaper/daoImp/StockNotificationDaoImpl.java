package com.digitalpaper.daoImp;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.digitalpaper.config.common.base.dao.BaseDao;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.IStockNotificationDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.entity.NotificationEvent;
import com.digitalpaper.transfer.object.entity.NotificationTemplate;
import com.digitalpaper.transfer.object.entity.StockNotification;


/**
 * The Class StockNotificationDaoImpl.
 */
@Repository
public class StockNotificationDaoImpl extends BaseDao implements IStockNotificationDao {

	/**
	 *@param stockId
	 */
	@Override
	public StockNotification getPreviousNotification(Integer stockId) {
		
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<StockNotification> criteria = builder.createQuery(StockNotification.class);
        Root<StockNotification> root = criteria.from(StockNotification.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.STOCKID), stockId)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        return (StockNotification) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);		
	}
	
	/**
	 * Gets the notificationevent.
	 *
	 * @param eventName the event name
	 * @return the notificationevent
	 */
	@Override
	public NotificationEvent getNotificationevent(String eventName) {
		
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<NotificationEvent> criteria = builder.createQuery(NotificationEvent.class);
        Root<NotificationEvent> root = criteria.from(NotificationEvent.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.STOCK_EVENT_NAME), eventName)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        return (NotificationEvent) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);		
	}
	
	/**
	 * Gets the notification template.
	 *
	 * @param eventId the event id
	 * @param action the action
	 * @return the notification template
	 */
	@Override
	public NotificationTemplate getNotificationTemplate(Integer eventId,String action) {
		
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<NotificationTemplate> criteria = builder.createQuery(NotificationTemplate.class);
        Root<NotificationTemplate> root = criteria.from(NotificationTemplate.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.EVENTID), eventId)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ACTION), action)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        return (NotificationTemplate) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);		
	}

	/**
	 * Update notification.
	 *
	 * @param notificationEntity the notification entity
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void updateNotification(StockNotification notificationEntity)throws ApplicationException {
		update(notificationEntity);
	}

	/**
	 * Save notification.
	 *
	 * @param notificationEntity the notification entity
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void saveNotification(StockNotification notificationEntity) throws ApplicationException {
		try {
			save(notificationEntity, TableConstants.STOCK_NOTIFICATION);
		} catch (ApplicationException e) {
			throw e;
		}
	}

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
		
	}

	/**
	 * Gets the notification data.
	 *
	 * @param companyId the company id
	 * @param skip the skip
	 * @param limit the limit
	 * @return the notification data
	 */
	@Override
	public List<StockNotification> getNotificationData(Integer companyId,Integer skip, Integer limit) {
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<StockNotification> criteria = builder.createQuery(StockNotification.class);
        Root<StockNotification> root = criteria.from(StockNotification.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.TO_NOTIFY), companyId)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_READ), Boolean.FALSE)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        criteria.orderBy(builder.desc(root.get(TableConstants.CREATED_DATE)));
        
       if(limit==ApplicationConstants.ZERO) {
    	  return (List<StockNotification>) getResultList(createQuery(builder, criteria, root, predicates));
       }
        return (List<StockNotification>) getResultList(createQuery(builder, criteria, root, predicates).setFirstResult(skip).setMaxResults(limit));	
	}

	/**
	 * Gets the notification by authority.
	 *
	 * @param associationId the association id
	 * @param skip the skip
	 * @param limit the limit
	 * @return the notification by authority
	 */
	@Override
	public List<StockNotification> getNotificationByAuthority(Integer associationId,Integer skip,Integer limit) {
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<StockNotification> criteria = builder.createQuery(StockNotification.class);
        Root<StockNotification> root = criteria.from(StockNotification.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.TO_NOTIFY), associationId)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_READ), Boolean.FALSE)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_ASSOCIATION), Boolean.TRUE)));
        criteria.orderBy(builder.desc(root.get(TableConstants.CREATED_DATE)));  
        if(limit==ApplicationConstants.ZERO) {
      	  return (List<StockNotification>) getResultList(createQuery(builder, criteria, root, predicates));
         }
        return (List<StockNotification>) getResultList(createQuery(builder, criteria, root, predicates).setFirstResult(skip).setMaxResults(limit));	
	}

	/**
	 * Gets the notification count based one company id.
	 *
	 * @param companyId the company id
	 * @return the notification count based one company id
	 */
	@Override
	public Long getNotificationCountBasedOneCompanyId(Integer companyId) {
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
        Root<StockNotification> root = criteria.from(StockNotification.class);
        criteria.select(builder.count(root));
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.TO_NOTIFY), companyId)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_READ), Boolean.FALSE)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_ASSOCIATION), Boolean.FALSE)));
        return (Long) getSingleResult(createQuery(builder, criteria, root, predicates));	
	}

	/**
	 * Gets the notification count.
	 *
	 * @param associationId the association id
	 * @return the notification count
	 */
	@Override
	public Long getNotificationCount(Integer associationId) {
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
        Root<StockNotification> root = criteria.from(StockNotification.class);
        criteria.select(builder.count(root));
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.TO_NOTIFY), associationId)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_READ), Boolean.FALSE)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        return (Long) getSingleResult(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Gets the notification based on id.
	 *
	 * @param notificationId the notification id
	 * @return the notification based on id
	 */
	@Override
	public StockNotification getNotificationBasedOnId(Integer notificationId) {
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<StockNotification> criteria = builder.createQuery(StockNotification.class);
        Root<StockNotification> root = criteria.from(StockNotification.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.NOTIFICATION_ID), notificationId)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        return (StockNotification) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);	
	}

	/**
	 * Gets the notification purch history.
	 *
	 * @param companyId the company id
	 * @return the notification purch history
	 */
	@Override
	public List<StockNotification> getNotificationPurchHistory(Integer companyId) {
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<StockNotification> criteria = builder.createQuery(StockNotification.class);
        Root<StockNotification> root = criteria.from(StockNotification.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ACTEDBY), companyId)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_READ), Boolean.FALSE)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        return (List<StockNotification>) getResultList(createQuery(builder, criteria, root, predicates));	
	}

}
