package com.digitalpaper.purchasestock.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.digitalpaper.config.common.base.dao.BaseDao;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.purchasestock.dao.AllocationPoolDao;
import com.digitalpaper.transfer.object.entity.Stock;
import com.digitalpaper.transfer.object.entity.StockPool;
import com.digitalpaper.utils.core.ApplicationUtils;

/**
 * The Class AllocationPoolDaoImpl.
 */
@Repository
public class AllocationPoolDaoImpl extends BaseDao implements AllocationPoolDao {

	
	
	
	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {	
	}

	/**
	 * Gets the stock by company id.
	 *
	 * @param companyId the company id
	 * @return the stock by company id
	 */
	@Override
	public Stock getStockByCompanyId(Integer companyId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Stock> criteria = builder.createQuery(Stock.class);
		Root<Stock> root = criteria.from(Stock.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.COMPANY_ID), companyId)));
		return (Stock) getSingleResult(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Gets the stock pool by id.
	 *
	 * @param poolIdentity the pool identity
	 * @param companyId the company id
	 * @param isTrue the is true
	 * @return the stock pool by id
	 */
	@Override
	public StockPool getStockPoolById(Integer poolIdentity, Integer companyId, Boolean isTrue) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<StockPool> criteria = builder.createQuery(StockPool.class);
		Root<StockPool> root = criteria.from(StockPool.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		if (isTrue.equals(Boolean.TRUE)) {
			predicates.add(builder.and(builder.equal(root.get(TableConstants.STOCK_POOL_ID), poolIdentity)));
		} else if (isTrue.equals(Boolean.FALSE)) {
			predicates.add(builder.and(builder.equal(root.get(TableConstants.USER_TYPE_ID), poolIdentity)));
		}
		predicates.add(builder.and(builder.equal(root.get(TableConstants.COMPANY_ID), companyId)));
		return (StockPool) getSingleResult(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Update stock.
	 *
	 * @param stock the stock
	 */
	@Override
	public void updateStock(Stock stock) {
		update(stock);
	}

	/**
	 * Update stock pool.
	 *
	 * @param stockPool the stock pool
	 */
	@Override
	public void updateStockPool(StockPool stockPool) {
		update(stockPool);
		
	}

	/**
	 * Gets the stock pool from identity.
	 *
	 * @param identity the identity
	 * @return the stock pool from identity
	 */
	@Override
	public StockPool getStockPoolFromIdentity(String identity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<StockPool> criteria = builder.createQuery(StockPool.class);
		Root<StockPool> root = criteria.from(StockPool.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IDENTITY), identity)));
		return (StockPool) getSingleResult(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Gets the all stock pool list.
	 *
	 * @param listOfIds the list of ids
	 * @param companyId the company id
	 * @param filterPaginationVo the filter pagination vo
	 * @param min the min
	 * @param max the max
	 * @return the all stock pool list
	 * @throws ApplicationException the application exception
	 */
	@Override
	public List<StockPool> getAllStockPoolList(List<Integer> listOfIds, Integer companyId,
			List<FilterOrSortingVo> filterPaginationVo, Integer min, Integer max) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<StockPool> criteria = builder.createQuery(StockPool.class);
		Root<StockPool> root = criteria.from(StockPool.class);
		criteria.select(root);
		List<Predicate> filterPredicates = getFilterPrdicets(filterPaginationVo, root, builder, criteria);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.addAll(filterPredicates);
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		if (ApplicationUtils.isValidList(listOfIds)) {
			predicates.add(builder.and(root.get(TableConstants.USER_TYPE_ID).in(listOfIds) ));
		}
		predicates.add(builder.and(builder.equal(root.get(TableConstants.COMPANY_ID), companyId)));
		return (List<StockPool>) getResultList(createQuery(builder, criteria, root, predicates).setFirstResult(min).setMaxResults(max));
	}

	



}
