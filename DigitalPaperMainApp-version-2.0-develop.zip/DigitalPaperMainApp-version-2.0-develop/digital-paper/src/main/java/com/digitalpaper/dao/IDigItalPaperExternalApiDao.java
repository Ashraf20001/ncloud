package com.digitalpaper.dao;

import com.digitalpaper.transfer.object.entity.PaperDetails;

/**
 * The Interface IDigItalPaperExternalApiDao.
 */
public interface IDigItalPaperExternalApiDao {

	/**
	 * Gets the external api dto.
	 *
	 * @param pdDigitalPaperId the pd digital paper id
	 * @return the external api dto
	 */
	PaperDetails getExternalApiDto(String pdDigitalPaperId);

}
