package com.digitalpaper.config;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;

import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;

/**
 * The Class CustomAuditAware.
 */
@Component
public class CustomAuditAware implements AuditorAware<Integer>{
	
	/** The logged in user context holder. */
	@Autowired
	private LoggedInUserContextHolder loggedInUserContextHolder;
	
	/**
	 * Gets the current auditor.
	 *
	 * @return the current auditor
	 */
	@Override
	public Optional<Integer> getCurrentAuditor() {
		Integer id = loggedInUserContextHolder.getLoggedInUser()
		.getId();
		
		return Optional.ofNullable(id);
	}
}
