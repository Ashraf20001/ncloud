package com.digitalpaper.daoImp;

import java.time.LocalDateTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.digitalpaper.config.common.base.dao.BaseDao;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.DashBoardDao;
import com.digitalpaper.transfer.object.constants.BasePredicateEntityColumnMap;
import com.digitalpaper.transfer.object.dto.AuthorityBarChartDto;
import com.digitalpaper.transfer.object.dto.DashBoardInputDto;
import com.digitalpaper.transfer.object.dto.DoughNutDto;
import com.digitalpaper.transfer.object.dto.MonthCountDto;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.entity.PaymentDetails;
import com.digitalpaper.transfer.object.entity.Stock;
import com.digitalpaper.transfer.object.entity.StockTransactionHistory;
import com.digitalpaper.utils.core.ApplicationUtils;

/**
 * The Class DashBoardDaoImpl.
 */
@Repository
public class DashBoardDaoImpl extends BaseDao implements DashBoardDao {

	/**
	 *@param isAssociation
	 *@param forExpiryDetails
	 *@param companyId
	 *@return
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<PaperDetails> getRecentAndExpiredPaperDetails(boolean isAssociation, boolean forExpiryDetails,
			Integer companyId, Integer allocationTypeId,DashBoardInputDto dashboardInputDto) {
		
		LocalDateTime fromDate = dashboardInputDto.getFromDate();
		LocalDateTime toDate = dashboardInputDto.getToDate();
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<PaperDetails> createQuery = builder.createQuery(PaperDetails.class);
		Root<PaperDetails> root = createQuery.from(PaperDetails.class);
		createQuery.select(root);
		
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		if(!isAssociation) {
			if(forExpiryDetails) {
				predicates.add(builder.and(builder.greaterThan(root.get(TableConstants.EXPIRY_DATE), LocalDateTime.now())));
				predicates.add(builder.and(builder.equal(root.get(TableConstants.STATUS),1)));
				predicates.add(builder.and(builder.between(root.get(TableConstants.EXPIRY_DATE), fromDate, toDate)));
				createQuery.orderBy(builder.asc(root.get(TableConstants.EXPIRY_DATE)));
			}
			else {
				
				predicates.add(builder.and(builder.equal(root.get(TableConstants.STATUS),1)));
				predicates.add(builder.and(builder.between(root.get(TableConstants.CREATED_DATE), fromDate, toDate)));
				createQuery.orderBy(builder.desc(root.get(TableConstants.MODIFIED_DATE)));
			}
			if (allocationTypeId!= null) {
				predicates.add(builder.and(builder.equal(root.get(TableConstants.ALLOCATION_TYPE_ID), allocationTypeId)));
			}
			
		}
		
		if(isAssociation) {
			predicates.add(builder.and(builder.between(root.get(TableConstants.CREATED_DATE), fromDate, toDate)));
			predicates.add(builder.and(builder.equal(root.get(TableConstants.STATUS),1)));
			createQuery.orderBy(builder.desc(root.get(TableConstants.CREATED_DATE)));
		}
		
		return(List<PaperDetails>) getResultList(getBasePredicateResult(builder, createQuery, root,null, predicates).setFirstResult(0).setMaxResults(TableConstants.MAX_DATA_LIMIT));
	}
	
	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
	}

	/**
	 * Gets the expiry digital paper count in next month.
	 *
	 * @param startingDateTime the starting date time
	 * @param endingDateTime the ending date time
	 * @param companyId the company id
	 * @return the expiry digital paper count in next month
	 */
	@Override
	public Long getExpiryDigitalPaperCountInNextMonth(LocalDateTime startingDateTime, LocalDateTime endingDateTime, Integer companyId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<PaperDetails> root = criteria.from(PaperDetails.class);
		criteria.select(builder.count(root));
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.COMPANY_ID), companyId)));
		predicates.add(builder.and(builder.between(root.get(TableConstants.EXPIRY_DATE), startingDateTime, endingDateTime)));
		return (Long) getSingleResult(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Gets the paper generated count in cuurent month.
	 *
	 * @param currentMonthStartingDateTime the current month starting date time
	 * @param currentMonthsndingDateTime the current monthsnding date time
	 * @param companyId the company id
	 * @return the paper generated count in cuurent month
	 */
	@Override
	public Long getPaperGeneratedCountInCuurentMonth(LocalDateTime currentMonthStartingDateTime,
			LocalDateTime currentMonthsndingDateTime, Integer companyId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<PaperDetails> root = criteria.from(PaperDetails.class);
		criteria.select(builder.count(root));
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		predicates.add(builder.and(builder.between(root.get(TableConstants.CREATED_DATE), currentMonthStartingDateTime, currentMonthsndingDateTime)));
		return (Long) getSingleResult(getBasePredicateResult(builder, criteria, root,null,predicates));
	}

	/**
	 * Gets the paper generate count based on month and company.
	 *
	 * @param companyId the company id
	 * @param startofLastSixMonth the startof last six month
	 * @param endOfLastSixMonth the end of last six month
	 * @return the paper generate count based on month and company
	 */
	@Override
	public List<MonthCountDto> getPaperGenerateCountBasedOnMonthAndCompany(Integer companyId, LocalDateTime startofLastSixMonth, 
							LocalDateTime endOfLastSixMonth) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<MonthCountDto> criteria = builder.createQuery(MonthCountDto.class);
		Root<PaperDetails> root = criteria.from(PaperDetails.class);
		List<Predicate> predicates = new ArrayList<>();
		
		 Expression<Month> monthExpression = builder.function("MONTH", Month.class, root.get(TableConstants.CREATED_DATE));
	     Expression<Long> countExpression = builder.count(root.get(TableConstants.PD_DIGITAL_PAPER_ID));

	     criteria.multiselect(monthExpression, countExpression);
	     criteria.groupBy(monthExpression);
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		predicates.add(builder.and(builder.between(root.get(TableConstants.CREATED_DATE), startofLastSixMonth, endOfLastSixMonth)));
		return (List<MonthCountDto>) getResultList(getBasePredicateResult(builder, criteria, root,null, predicates));
	}


	/**
	 *@return
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<PaymentDetails> getAllCompaniesRecentTransaction(DashBoardInputDto dashboardInputDto) {
		CriteriaBuilder builder = getCriteriaBuilder();
		LocalDateTime fromDate = dashboardInputDto.getFromDate();
		LocalDateTime toDate = dashboardInputDto.getToDate();
		CriteriaQuery<PaymentDetails> createQuery = builder.createQuery(PaymentDetails.class);
		Root<PaymentDetails> root = createQuery.from(PaymentDetails.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		predicates.add(builder.and(builder.between(root.get(TableConstants.PAYMENTDATE), fromDate, toDate)));
		createQuery.orderBy(builder.desc(root.get(TableConstants.PAYMENTDATE)));
		return (List<PaymentDetails>) getResultList(createQuery(builder, createQuery, root, predicates).setFirstResult(0).setMaxResults(TableConstants.MAX_DATA_LIMIT));
	}

	/**
	 *@param fromDate
	 *@param toDate
	 *@return
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getTopPurchaseCompanies(LocalDateTime fromDate, LocalDateTime toDate) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Object[]> createQuery = builder.createQuery(Object[].class);
		Root<PaymentDetails> root = createQuery.from(PaymentDetails.class);
		Expression<Long> stockCountExpression = builder.sumAsLong(root.get(TableConstants.ORDER_ID).get(TableConstants.STOCK_COUNT));
		createQuery.multiselect(root.get(TableConstants.ORDER_ID).get(TableConstants.COMPANY_ID),stockCountExpression);	
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.DP_PAYMENT_STATUS),3)));
	
		predicates.add(builder.and(builder.between(root.get(TableConstants.PAYMENTDATE), fromDate, toDate)));	
		createQuery.groupBy(root.get(TableConstants.ORDER_ID).get(TableConstants.COMPANY_ID));
		createQuery.orderBy(builder.desc(stockCountExpression));
		return (List<Object[]>) getResultList(createQuery(builder, createQuery, root, predicates).setFirstResult(0).setMaxResults(TableConstants.MAX_DATA_LIMIT));
	}
	
	/**
	 *@return
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Integer> getPaymentCompanyIds() {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Integer> createQuery = builder.createQuery(Integer.class);
		Root<PaymentDetails> root = createQuery.from(PaymentDetails.class);
		createQuery.select(root.get(TableConstants.ORDER_ID).get(TableConstants.COMPANY_ID));	
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		createQuery.groupBy(root.get(TableConstants.ORDER_ID).get(TableConstants.COMPANY_ID));
		return (List<Integer>) getResultList(createQuery(builder, createQuery, root, predicates));
	}

	/**
	 * Gets the paper details company ids.
	 *
	 * @return the paper details company ids
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Integer> getPaperDetailsCompanyIds() {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Integer> createQuery = builder.createQuery(Integer.class);
		Root<PaperDetails> root = createQuery.from(PaperDetails.class);
		createQuery.select(root.get(TableConstants.COMPANY_ID));	
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		createQuery.groupBy(root.get(TableConstants.COMPANY_ID));
		return (List<Integer>) getResultList(createQuery(builder, createQuery, root, predicates));
	}

	/**
	 * @param dashBoardInputDto
	 * @param companyId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<MonthCountDto> getCertificateIssuedCountByMonth(DashBoardInputDto dashBoardInputDto, Integer companyId,Integer allocationUserTypeId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<MonthCountDto> criteria = builder.createQuery(MonthCountDto.class);
		Root<PaperDetails> root = criteria.from(PaperDetails.class);
		List<Predicate> predicates = new ArrayList<>();

		Expression<Month> monthExpression = builder.function("MONTH", Month.class,
				root.get(TableConstants.CREATED_DATE));
		Expression<Long> countExpression = builder.count(
				builder.<Integer>selectCase().when(builder.equal(root.get(TableConstants.COMPANY_ID), companyId), 1));
		criteria.multiselect(monthExpression, countExpression);
		criteria.groupBy(monthExpression);
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		if (ApplicationUtils.isValidObject(dashBoardInputDto)) {
			predicates.add(builder.and(builder.greaterThanOrEqualTo(root.get(TableConstants.CREATED_DATE),
					dashBoardInputDto.getFromDate())));
			predicates.add(builder.and(
					builder.lessThanOrEqualTo(root.get(TableConstants.CREATED_DATE), dashBoardInputDto.getToDate())));
		}
		predicates.add(builder
				.and(builder.equal(root.get(TableConstants.ALLOCATION_TYPE_ID), allocationUserTypeId)));
		return (List<MonthCountDto>) getResultList(createQuery(builder, criteria, root, predicates));
	}

	/**s
	 * @param companyNameMaping
	 * @param dashBoardInputDtoForAuthority
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<AuthorityBarChartDto> getauthorityBarChartata(List<Integer> companyNameMaping,
			DashBoardInputDto dashBoardInputDtoForAuthority) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<AuthorityBarChartDto> criteria = builder.createQuery(AuthorityBarChartDto.class);
		Root<Stock> root = criteria.from(Stock.class);
		Expression<String> companyIdExpression = (builder.<String>selectCase()
				.when(builder.greaterThan(root.get(TableConstants.COMPANY_ID), 0), ""));
		Expression<String> ShortName = (builder.<String>selectCase()
				.when(builder.greaterThan(root.get(TableConstants.COMPANY_ID), 0), ""));
		
		criteria.multiselect(root.get(TableConstants.COMPANY_ID), companyIdExpression, ShortName, root.get(TableConstants.STOCK_COUNT), root.get(TableConstants.USED_COUNT));
		List<Predicate> predicates = new ArrayList<>();
		if(ApplicationUtils.isValidObject(dashBoardInputDtoForAuthority)) {
	        predicates.add(builder.and(builder.greaterThanOrEqualTo(root.get(TableConstants.MODIFIED_DATE),dashBoardInputDtoForAuthority.getFromDate())));
			predicates.add(builder.and(builder.lessThanOrEqualTo(root.get(TableConstants.MODIFIED_DATE),dashBoardInputDtoForAuthority.getToDate())));
		}
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		Expression<String> parentExpression = root.get(TableConstants.COMPANY_ID);
		Predicate parentPredicate = parentExpression.in(companyNameMaping);
		predicates.add(builder.and(parentPredicate));
		List<AuthorityBarChartDto> result = (List<AuthorityBarChartDto>) getResultList(
				createQuery(builder, criteria, root, predicates).setFirstResult(0)
						.setMaxResults(TableConstants.MAX_DATA_LIMIT_BAR_CHART));
		return result;
	}
	
	/**
	 * Gets the status count.
	 *
	 * @param companyId the company id
	 * @param isAssociation the is association
	 * @param boardInputDto the board input dto
	 * @param allocationUserType the allocation user type
	 * @return the status count
	 */
	@SuppressWarnings("unchecked")
    @Override
    public DoughNutDto getStatusCount(Integer companyId,boolean isAssociation,DashBoardInputDto boardInputDto,Integer allocationUserType) 
    {
        
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<DoughNutDto> criteria =builder.createQuery(DoughNutDto.class);
        Root<PaperDetails> root = criteria.from(PaperDetails.class);
         Expression<Long> activeExpression = builder.count(builder.<Long>selectCase().when(builder.equal(root.get(TableConstants.STATUS), 1), 1L));
         Expression<Long> expiredExpression = builder.count(builder.<Long>selectCase().when(builder.equal(root.get(TableConstants.STATUS), 2), 1L));
         Expression<Long> revokedExpression = builder.count(builder.<Long>selectCase().when(builder.equal(root.get(TableConstants.STATUS), 3), 1L));

            
        criteria.multiselect(activeExpression, 
                expiredExpression,revokedExpression);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
        predicates.add(builder.and(builder.between(root.get(TableConstants.MODIFIED_DATE) ,boardInputDto.getFromDate(), boardInputDto.getToDate())));

         if(!isAssociation)
         {
             
           if(ApplicationUtils.isValidId(allocationUserType)) {
        	   predicates.add(builder.and(builder.equal(root.get(TableConstants.ALLOCATION_TYPE_ID),allocationUserType)));
           }
         }
         
         

        return (DoughNutDto) getSingleResult(getBasePredicateResult(builder, criteria, root,null, predicates));
    }

	/**
	 * Gets the all companies bar chart.
	 *
	 * @param dashBoardInputDto the dash board input dto
	 * @param companyId the company id
	 * @return the all companies bar chart
	 */
	@Override
	public List<MonthCountDto> getAllCompaniesBarChart(DashBoardInputDto dashBoardInputDto, Integer companyId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<MonthCountDto> criteria = builder.createQuery(MonthCountDto.class);
		Root<PaymentDetails> root = criteria.from(PaymentDetails.class);
		List<Predicate> predicates = new ArrayList<>(); 

		Expression<Month> monthExpression = builder.function("MONTH", Month.class,
				root.get(TableConstants.PAYMENTDATE));
		Expression<Long> countExpression = builder
				.sum(root.get(TableConstants.ORDER_ID).get(TableConstants.STOCK_COUNT));

		criteria.multiselect(monthExpression, countExpression);
		criteria.groupBy(monthExpression);
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.DP_PAYMENT_STATUS), 3)));
		
		if(ApplicationUtils.isValidObject(dashBoardInputDto)) {
	        predicates.add(builder.and(builder.greaterThanOrEqualTo(root.get(TableConstants.PAYMENTDATE),dashBoardInputDto.getFromDate())));
			predicates.add(builder.and(builder.lessThanOrEqualTo(root.get(TableConstants.PAYMENTDATE),dashBoardInputDto.getToDate())));
		}
		Class<PaymentDetails> entityType = root.getModel().getJavaType();
		String joinTableColumn = BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(entityType);
		
		return (List<MonthCountDto>) getResultList(getBasePredicateResult(builder, criteria, root, joinTableColumn, predicates));
	}

	/**
	 * Gets the all companies certificate issued count by month.
	 *
	 * @param dashBoardInputDto the dash board input dto
	 * @param companyId the company id
	 * @return the all companies certificate issued count by month
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<MonthCountDto> getAllCompaniesCertificateIssuedCountByMonth(DashBoardInputDto dashBoardInputDto,
			Integer companyId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<MonthCountDto> criteria = builder.createQuery(MonthCountDto.class);
		Root<PaperDetails> root = criteria.from(PaperDetails.class);
		List<Predicate> predicates = new ArrayList<>();

		Expression<Month> monthExpression = builder.function("MONTH", Month.class,
				root.get(TableConstants.CREATED_DATE));
		Expression<Long> countExpression = builder.count(
				builder.<Integer>selectCase().when(builder.equal(root.get(TableConstants.COMPANY_ID), companyId), 1));
		criteria.multiselect(monthExpression, countExpression);
		criteria.groupBy(monthExpression);
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		if (ApplicationUtils.isValidObject(dashBoardInputDto)) {
			predicates.add(builder.and(builder.greaterThanOrEqualTo(root.get(TableConstants.CREATED_DATE),
					dashBoardInputDto.getFromDate())));
			predicates.add(builder.and(
					builder.lessThanOrEqualTo(root.get(TableConstants.CREATED_DATE), dashBoardInputDto.getToDate())));
		}
		return (List<MonthCountDto>) getResultList(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Gets the stock allocated by allocation user type.
	 *
	 * @param dashBoardInputDto the dash board input dto
	 * @param companyId the company id
	 * @param allocationUserTypeId the allocation user type id
	 * @return the stock allocated by allocation user type
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<MonthCountDto> getStockAllocatedByAllocationUserType(DashBoardInputDto dashBoardInputDto,
			Integer companyId, Integer allocationUserTypeId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<MonthCountDto> criteria = builder.createQuery(MonthCountDto.class);
		Root<StockTransactionHistory> root = criteria.from(StockTransactionHistory.class);
		List<Predicate> predicates = new ArrayList<>(); 

		Expression<Month> monthExpression = builder.function("MONTH", Month.class,
				root.get(TableConstants.CREATED_DATE));
		
		Expression<Integer> creditStockExpression = root.get(TableConstants.CREDITED_STOCK);
		Expression<Integer> debitStockExpression = root.get(TableConstants.DEBITED_STOCK);

		// Define the expression for the total count
		Expression<Integer> totalCountExpression = builder
				.sum(builder.diff(creditStockExpression, debitStockExpression));
		Predicate poolIdNotNullCondition = builder.isNull(root.get(TableConstants.STOCK_POOL_ID));
		
		criteria.multiselect(monthExpression, totalCountExpression).where(poolIdNotNullCondition);
		criteria.groupBy(monthExpression);

		predicates.add(builder.and(builder.equal(root.get(TableConstants.STOCK_POOL_ID).get(TableConstants.USER_TYPE_ID), allocationUserTypeId)));
		if (ApplicationUtils.isValidObject(dashBoardInputDto)) {
			predicates.add(builder.and(builder.greaterThanOrEqualTo(root.get(TableConstants.CREATED_DATE),
					dashBoardInputDto.getFromDate())));
			predicates.add(builder.and(
					builder.lessThanOrEqualTo(root.get(TableConstants.CREATED_DATE), dashBoardInputDto.getToDate())));
		}
		Class<StockTransactionHistory> entityType = root.getModel().getJavaType();
		String joinTableColumn = BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(entityType);
		return (List<MonthCountDto>) getResultList(getBasePredicateResult(builder, criteria, root, joinTableColumn, predicates));
	}

}
