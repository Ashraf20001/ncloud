package com.digitalpaper.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitalpaper.aop.annotation.Auditable;
import com.digitalpaper.config.base.controller.BaseController;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.service.IStockNotificationSevice;
import com.digitalpaper.service.IStockService;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.PurchaseOrderDto;
import com.digitalpaper.transfer.object.dto.SaveStockDataVo;
import com.digitalpaper.transfer.object.dto.StockDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.enums.PaymentStatusEnum;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;
import com.digitalpaper.utils.core.ApplicationUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class StockController.
 */
@RestController
@Auditable
public class StockController extends BaseController {

	/** The stock service. */
	@Autowired
	IStockService stockService;

	/** The logged in user context holder. */
	@Autowired
	private LoggedInUserContextHolder loggedInUserContextHolder;

	/** The notification service. */
	@Autowired
	IStockNotificationSevice notificationService;

	/**
	 * Gets the stock details.
	 *
	 * @return the stock details
	 */
	@ApiOperation(value="Total company stock", notes="Get total stock of the company",response = StockDto.class)
	@GetMapping("/get-total-stock")
	public StockDto getStockDetails() {
		return stockService.getStockData();
	}

	/**
	 * Gets the dropdown data.
	 *
	 * @return the dropdown data
	 */
	@ApiOperation(value = "Stock dropdown data",notes = "Get dropdown list for stock details",response = ApplicationResponse.class)
	@GetMapping("/get-dropdownList")
	public ApplicationResponse getDropdownData() {

		try {
			return getApplicationResponse(stockService.getDropDownList());
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Gets the platform values.
	 *
	 * @param selectedColumnList the selected column list
	 * @return the platform values
	 */
	@ApiOperation(value = "Download stock",notes = "Download list of stock details",response = ResponseEntity.class)
	@PostMapping("/excel-download")
	public ResponseEntity<InputStreamResource> getPlatformValues( @ApiParam(value = "Column name list payload data",required = true) @RequestBody String[] selectedColumnList) {
		ArrayList<HashMap<String, Object>> data = stockService.getpurchaseDetails(selectedColumnList);

		if (Boolean.FALSE.equals(ApplicationUtils.isValidateObject(data))) {
			return null;
		}

		return stockService.excelDownload(data);
	}

	/**
	 * Stock save.
	 *
	 * @param data the data
	 * @return the application response
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Create stock",notes = "Create a stock detail",response = ApplicationResponse.class)
	@PostMapping("/stock-save")
	public ApplicationResponse stockSave(@ApiParam(value = "SaveStockDataVo payload data",required = true) @RequestBody SaveStockDataVo data) throws ApplicationException {

		if (!data.isUploadFileName() && ApplicationConstants.OFFLINE_PAYMENT.contains(data.getPaymentMethod())) {
			throw new ApplicationException(ErrorCodes.INVALID_FILE_SELECTION);
		}

		Integer purchaseResponce = stockService.saveOrUpdate(data);

		PurchaseOrderDto purchaseVo = new PurchaseOrderDto();

		purchaseVo.setOrderId(purchaseResponce);
		PaymentStatusEnum paymentStatusEnum = PaymentStatusEnum.getPaymentStatusEnum(ApplicationConstants.SUBMITTED);
		purchaseVo.setPaymentStatus(paymentStatusEnum.name());
		purchaseVo.setPurchaseAmount((ApplicationUtils.isValidString(data.getTotalCostValue()))?Double.parseDouble(data.getTotalCostValue()):null);

		UserInfo userDetails = loggedInUserContextHolder.getLoggedInUser();
		Integer companyId = userDetails.getCompanyId();

		purchaseVo.setCompanyId(companyId);
		purchaseVo.setStockCount(Integer.parseInt(data.getNumberOfPapers()));
		notificationService.saveNotification(ApplicationConstants.SUBMITTED, purchaseVo);

		return getApplicationResponse(purchaseResponce);
	}

	/**
	 * Save allocation ids.
	 *
	 * @param companyId the company id
	 * @param userId the user id
	 * @param isPoolBasedAllocation the is pool based allocation
	 * @param integerList the integer list
	 */
	@ApiOperation(value = "Create stock and stock pool",notes = "Create a stock and list of stock pools for company")
	@PostMapping("/saveAllocationUserId")
	public void saveAllocationIds(
			@ApiParam(value = "Company id",required = true)   @RequestParam(name = "companyId") Integer companyId,
			@ApiParam(value = "User id",required = true)   @RequestParam(name = "userId") Integer userId,
			@ApiParam(value="Pool based allocation or not",required = true)    @RequestParam(name = "isPoolBasedAllocation") Boolean isPoolBasedAllocation,
			@ApiParam(value = "Integer list data payload",required = true)    @RequestBody List<Integer> integerList) {
		stockService.saveAllocationIds(integerList, companyId, userId, isPoolBasedAllocation);
	}

	/**
	 * Map offline payment.
	 *
	 * @param storageIdList the storage id list
	 */
	@ApiOperation(value = "Stock file mapping",notes = "Map the documents for offline payment to the stock id")
	@PostMapping("/map-files-offline-payment")
	public void mapOfflinePayment(@ApiParam(value = "Storage id  and stock id map data payload",required = true)   @RequestBody Map<String, List<Integer>> storageIdList) {
		stockService.mapOfflinePayment(storageIdList);
	}
	
	/**
	 * Gets the stock details based on login user.
	 *
	 * @param request the request
	 * @return the stock details based on login user
	 */
	@ApiOperation(value = "Stock count",notes = "Get stock detail based on login user",response=ApplicationResponse.class)
	@GetMapping("/get-stock-count")
	public ApplicationResponse getStockDetailsBasedOnLoginUser(HttpServletRequest request) {
		StockDto stockDto = stockService.getStockDetailsBasedOnLoginUser(request);
		return getApplicationResponse(stockDto);
	}

	/**
	 * Gets the stck file id.
	 *
	 * @param id the id
	 * @return the stck file id
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Payment Details",notes = "Get payment detail using purchase order id",response=ApplicationResponse.class)
	@GetMapping("/get-purchaseOrder")
	public ApplicationResponse getStckFileId( @ApiParam(value="Purchase id",required = true) @RequestParam (value = "id") Integer id) throws ApplicationException {
		
		PurchaseOrderDto responce =stockService.getPurchaseOrderDetails(id);
		return getApplicationResponse(responce);
	}
	
	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {
	}

}
