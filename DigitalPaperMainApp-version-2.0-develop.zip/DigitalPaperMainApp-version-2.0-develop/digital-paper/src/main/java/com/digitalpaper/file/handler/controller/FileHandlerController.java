package com.digitalpaper.file.handler.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.digitalpaper.file.handler.service.FileHandlerService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class FileHandlerController.
 */
@RestController
public class FileHandlerController {
	
	/** The file handler. */
	@Autowired
	private FileHandlerService fileHandler;
	
	/**
	 * Download file.
	 *
	 * @param fileName the file name
	 * @return the response entity
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@ApiOperation(value="File download",notes="Endpoint serves for downloading the file",response=ResponseEntity.class)
	@GetMapping("/downloadFile/{fileCode}")
	public ResponseEntity<Resource> downloadFile(@ApiParam(value = "File name",required = true) @PathVariable("fileCode") String fileName) throws IOException{
		
    	Resource resource = null;
    	try {
    		resource = fileHandler.getFileDataByURL(fileName);
    	} catch (IOException e) {
    		return ResponseEntity.internalServerError().build();
    	}
       
    	if (resource == null) {
    		return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
    	}
       
    	String contentType = "application/octet-stream";
    	String headerValue = "attachment; filename=\"" + resource.getFilename() + "\"";
     
    	return ResponseEntity.ok()
            .contentType(MediaType.parseMediaType(contentType))
            .header(HttpHeaders.CONTENT_DISPOSITION, headerValue)
            .body(resource); 
		
	}


}
