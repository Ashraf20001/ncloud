package com.digitalpaper.service.impl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.ReportsDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.service.ReportsService;
import com.digitalpaper.transfer.object.dto.PreviewReportDto;
import com.digitalpaper.transfer.object.dto.ReportsDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.dto.purchaseOrderStatusCountDto;
import com.digitalpaper.transfer.object.entity.Customer;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.entity.PurchaseOrderEntity;
import com.digitalpaper.transfer.object.entity.ReportColumnMapping;
import com.digitalpaper.transfer.object.entity.Reports;
import com.digitalpaper.transfer.object.enums.PaperStatusEnum;
import com.digitalpaper.transfer.object.enums.PaymentModeEnum;
import com.digitalpaper.transfer.object.enums.PaymentStatusEnum;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;
import com.digitalpaper.utils.core.ApplicationUtils;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.opencsv.CSVWriter;

/**
 * The Class ReportsServiceImpl.
 */
@Service
@Transactional
public class ReportsServiceImpl implements ReportsService {

	/** The report dao. */
	@Autowired
	private ReportsDao reportDao;

	/** The logged in user context holder. */
	@Autowired
	private LoggedInUserContextHolder loggedInUserContextHolder;

	/**
	 * Gets the report details in card.
	 *
	 * @return the report details in card
	 * @throws ApplicationException the application exception
	 */
	@Override
	public List<ReportsDto> getReportDetailsInCard() throws ApplicationException {

		UserInfo userDetails = loggedInUserContextHolder.getLoggedInUser();
		Integer userId = userDetails.getId();
		Integer companyId = userDetails.getCompanyId();

		List<ReportsDto> data = new ArrayList<ReportsDto>();
		List<Reports> reportData = new ArrayList<>();
		if (ApplicationUtils.isValidId(companyId)) {
			reportData = reportDao.getreportsDataBasedOnUserId(companyId);
		} else {

			reportData = reportDao.getReportAllData(userId);
		}
		if (ApplicationUtils.isValidateObject(reportData)) {

			for (Reports value : reportData) {
				data.add(convertEntityToDtoWithoutColumnInReports(value));
			}
		}
		return data;
	}

	/**
	 * @param value
	 * @return
	 * @throws ApplicationException
	 */
	private ReportsDto convertEntityToDtoWithoutColumnInReports(Reports value) throws ApplicationException {

		ReportsDto data = new ReportsDto();

		data.setFileType(value.getFileType());
		data.setIdentity(value.getIdentity());
		data.setInsuredName(value.getInsuredName());
		data.setPeriod(value.getPeriod());
		data.setReportType(value.getReportType());
		data.setReportName(value.getReportName());
		data.setInsuredCompanyId(value.getCompanyId());
		data.setToDate(value.getToDate());
		data.setFromDate(value.getFromDate());

		Long columnCount = reportDao.getSelectedColumnCount(value.getReportsId());
		data.setSelectedColumnCount(columnCount);

		if (ApplicationUtils.isValidateObject(value.getStatus().trim())) {
			String[] elements = value.getStatus().split(",");
			List<String> selectedStatus = Arrays.asList(elements);
			ArrayList<String> status = new ArrayList<String>(selectedStatus);
			data.setStatus(status);
		}

		List<ReportColumnMapping> mappingData = reportDao.getMappingColumn(value.getReportsId());

		List<String> columnList = new ArrayList<String>();
		if (ApplicationUtils.isValidateObject(mappingData)) {

			for (ReportColumnMapping columnName : mappingData) {

				columnList.add(columnName.getColumnName());
			}
		}

		data.setSelectedColumn(columnList);

		if (value.getPeriod() != null) {

			LocalDateTime monthBefore = null;

			data.setToDate(LocalDateTime.now());

			if (value.getPeriod().equalsIgnoreCase("3 Month")) {
				monthBefore = LocalDateTime.now().minusMonths(3);

			} else if (value.getPeriod().equalsIgnoreCase("6 Month")) {
				monthBefore = LocalDateTime.now().minusMonths(6);

			} else {
				monthBefore = LocalDateTime.now().minusYears(1);
			}
			data.setFromDate(monthBefore);

		}

		int hour = 22; // Hour (0-23)
		int minute = 30; // Minute (0-59)
		int second = 0; // Second (0-59)
		int nanoSecond = 0;
		LocalDateTime date = data.getToDate().withHour(hour).withMinute(minute).withSecond(second).withNano(nanoSecond);

		data.setToDate(date);

		hour = 01; // Hour (0-23)
		minute = 00; // Minute (0-59)
		second = 0; // Second (0-59)
		nanoSecond = 0;
		date = data.getFromDate().withHour(hour).withMinute(minute).withSecond(second).withNano(nanoSecond);

		data.setFromDate(date);

		if (value.getReportType().equals(0)) { // 1 meanse purchase order

			purchaseOrderStatusCountDto purchaseOrder = reportDao.getTotalCountInPurchaseOrder(data.getFromDate(),
					data.getToDate(),data.getInsuredCompanyId());
			
			if (ApplicationUtils.isValidateObject(purchaseOrder)) {

				data.setPurchaseOrderTotalCount(
						ApplicationUtils.isValidLong(purchaseOrder.getTotalCount()) ? purchaseOrder.getTotalCount()
								: 0);
				data.setPurchaseOrderPendingCount(
						ApplicationUtils.isValidLong(purchaseOrder.getSumitedCount()) ? purchaseOrder.getSumitedCount()
								: 0);
				data.setPurchaseOrderSuccessCount(
						ApplicationUtils.isValidLong(purchaseOrder.getSuccessCount()) ? purchaseOrder.getSuccessCount()
								: 0);
			}
		} else { // Digital Paper
			purchaseOrderStatusCountDto digitalPaper = reportDao.getTotalCountInDigitalPaper(data.getFromDate(),
					data.getToDate(),data.getInsuredCompanyId());

			if (ApplicationUtils.isValidateObject(digitalPaper)) {
				data.setPaperDetailsTotalCount(
						ApplicationUtils.isValidLong(digitalPaper.getTotalCount()) ? digitalPaper.getTotalCount() : 0);
				data.setPaperDetailsActiveCount(
						ApplicationUtils.isValidLong(digitalPaper.getSuccessCount()) ? digitalPaper.getSuccessCount()
								: 0);
				data.setPaperDetailsExpiredCount(
						ApplicationUtils.isValidLong(digitalPaper.getFaildCount()) ? digitalPaper.getFaildCount() : 0);
			}

		}

		return data;
	}

	/**
	 * Convert entity to dto in reports.
	 *
	 * @param value the value
	 * @return the reports dto
	 * @throws ApplicationException the application exception
	 */
	private ReportsDto convertEntityToDtoInReports(Reports value) throws ApplicationException {

		ReportsDto data = new ReportsDto();

		data.setFileType(value.getFileType());
		data.setFromDate(value.getFromDate());
		data.setIdentity(value.getIdentity());
		data.setInsuredName(value.getInsuredName());
		data.setPeriod(value.getPeriod());
		data.setReportType(value.getReportType());
		data.setReportName(value.getReportName());
		data.setInsuredCompanyId(value.getCompanyId());

		if (ApplicationUtils.isValidateObject(value.getStatus().trim())) {
			String[] elements = value.getStatus().split(",");
			List<String> selectedStatus = Arrays.asList(elements);
			ArrayList<String> status = new ArrayList<String>(selectedStatus);
			data.setStatus(status);
		}

		data.setToDate(value.getToDate());

		List<ReportColumnMapping> mappingData = reportDao.getMappingColumn(value.getReportsId());

		List<String> columnList = new ArrayList<String>();
		if (ApplicationUtils.isValidateObject(mappingData)) {

			for (ReportColumnMapping columnName : mappingData) {

				columnList.add(columnName.getColumnName());
			}
		}

		data.setSelectedColumn(columnList);
		return data;
	}

	/**
	 * Save report card data.
	 *
	 * @param reportData the report data
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void saveReportCardData(ReportsDto reportData) throws ApplicationException {

		UserInfo userDetails = loggedInUserContextHolder.getLoggedInUser();
		Integer userId = userDetails.getId();

		Reports report = new Reports();

		if (ApplicationUtils.isValidateObject(reportData)) {

			report.setCreatedBy(userId);
			report.setCreatedDate(LocalDateTime.now());
			report.setFileType(reportData.getFileType());
			report.setFromDate(reportData.getFromDate());
			report.setInsuredName(reportData.getInsuredName());
			report.setModifiedBy(userId);
			report.setModifiedDate(LocalDateTime.now());
			report.setPeriod(reportData.getPeriod());
			report.setReportType(reportData.getReportType());
			report.setReportName(reportData.getReportName());
			report.setCompanyId(reportData.getInsuredCompanyId());

			if (ApplicationUtils.isValidateObject(reportData.getStatus())) {
				String status = String.join(",",reportData.getStatus());
				report.setStatus(status.toString().trim());
			}

			report.setToDate(reportData.getToDate());

			Integer reportId = reportDao.saveReport(report);

			if (ApplicationUtils.isValidId(reportId)) {

				int i = 0;
				for (String columnName : reportData.getSelectedColumn()) {
					ReportColumnMapping reportMappingColum = new ReportColumnMapping();
					i = i + 1;
					reportMappingColum.setColumnName(columnName);
					reportMappingColum.setCreatedBy(userId);
					reportMappingColum.setCreatedDate(LocalDateTime.now());
					reportMappingColum.setModifiedBy(userId);
					reportMappingColum.setModifiedDate(LocalDateTime.now());
					reportMappingColum.setOrder(i);
					reportMappingColum.setReportId(report);

					reportDao.saveReportMappingColumn(reportMappingColum);

				}

			}
		}
	}

	/**
	 * Gets the report data based one identity.
	 *
	 * @param identity the identity
	 * @return the report data based one identity
	 * @throws ApplicationException the application exception
	 */
	@Override
	public ReportsDto getReportDataBasedOneIdentity(String identity) throws ApplicationException {

		ReportsDto reportDto = new ReportsDto();
		Reports data = new Reports();
		if (ApplicationUtils.isValidIdentity(identity)) {
			data = reportDao.getreportDataBasedOnIdentity(identity);

			if (ApplicationUtils.isValidateObject(data)) {
				reportDto = convertEntityToDtoInReports(data);

			}
		}
		return reportDto;
	}

	/**
	 * Update values.
	 *
	 * @param list the list
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void UpdateValues(ReportsDto list) throws ApplicationException {

		UserInfo userDetails = loggedInUserContextHolder.getLoggedInUser();
		Integer userId = userDetails.getId();

		Reports data = new Reports();
		if (ApplicationUtils.isValidateObject(list)) {
			data = reportDao.getreportDataBasedOnIdentity(list.getIdentity());

			if (ApplicationUtils.isValidateObject(data)) {
				data.setFileType(list.getFileType());
				data.setFromDate(list.getFromDate());
				data.setInsuredName(list.getInsuredName());
				data.setModifiedBy(userId);
				data.setModifiedDate(LocalDateTime.now());
				data.setPeriod(list.getPeriod());
				data.setReportType(list.getReportType());
				data.setReportName(list.getReportName());
				data.setCompanyId(list.getInsuredCompanyId());

				if (ApplicationUtils.isValidateObject(list.getStatus())) {
					String status = String.join(",",list.getStatus());
					data.setStatus(status.toString().trim());
				}

				data.setToDate(list.getToDate());

				reportDao.updatReport(data);

				int i = 0;
				for (String columnName : list.getSelectedColumn()) {
					i = i + 1;
					ReportColumnMapping reportMappingColum = reportDao.getreportColumn(columnName, data.getReportsId());

					if (!ApplicationUtils.isValidateObject(reportMappingColum)) {

						ReportColumnMapping reportMappingData = new ReportColumnMapping();
						reportMappingData.setColumnName(columnName);
						reportMappingData.setCreatedBy(userId);
						reportMappingData.setCreatedDate(LocalDateTime.now());
						reportMappingData.setModifiedBy(userId);
						reportMappingData.setModifiedDate(LocalDateTime.now());
						reportMappingData.setOrder(i);
						reportMappingData.setReportId(data);

						reportDao.saveReportMappingColumn(reportMappingData);

					}
				}

			}
		}
	}

	/**
	 * Download excel report.
	 *
	 * @param data the data
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	@Override
	public ResponseEntity<ByteArrayResource> downloadExcelReport(PreviewReportDto data) throws ApplicationException {

		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		HttpHeaders header = new HttpHeaders();

		try {

			List<String> keyList = new ArrayList<>();
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet(ApplicationConstants.REPORTS);
			XSSFRow hederRow = sheet.createRow((int) ApplicationConstants.ZERO);

			XSSFFont headerFont = workbook.createFont();
			headerFont.setBold(true);

			XSSFCellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			int rowIndex = ApplicationConstants.ZERO;

			for (HashMap<String, Object> map : data.getDataList()) { // Iterated only for Extracting Header Columns
				Set<String> keys = map.keySet();
				keyList = keys.stream().collect(Collectors.toList());
				for (int i = ApplicationConstants.ZERO; i < keyList.size(); i++) {

					XSSFCell headerCell = hederRow.createCell(i);
					 String headerText =Character.toUpperCase(keyList.get(i).charAt(0)) + keyList.get(i).substring(1); // Capitalize the first letter
					 
					headerCell.setCellValue(headerText);
					headerCell.setCellStyle(headerCellStyle);
				}
			}

			for (HashMap<String, Object> map : data.getDataList()) {
				int columnIndex = ApplicationConstants.ZERO;
				XSSFRow row = sheet.createRow((int) rowIndex + 1);
				for (Entry<String, Object> entry : map.entrySet()) {
					row.createCell(columnIndex).setCellValue((entry.getValue() != null) ? entry.getValue().toString()
							: ApplicationConstants.WITHOUT_SPACE);
					columnIndex++;
				}
				rowIndex++;
			}

			if (ApplicationUtils.isValidList(keyList)) {
				for (int index = ApplicationConstants.ZERO; index < keyList.size(); index++) {
					sheet.autoSizeColumn(index);
				}
			}

			header.setContentType(new MediaType("application", "force-download"));
			header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ProductTemplate.pdf");

			workbook.write(stream);
			workbook.close();
			return new ResponseEntity<>(new ByteArrayResource(stream.toByteArray()), header, HttpStatus.CREATED);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return new ResponseEntity<>(new ByteArrayResource(stream.toByteArray()), header, HttpStatus.CREATED);
	}

	/**
	 * Gets the review report data.
	 *
	 * @param previewData the preview data
	 * @param min the min
	 * @param max the max
	 * @return the review report data
	 * @throws ApplicationException the application exception
	 */
	@Override
	public PreviewReportDto getReviewReportData(PreviewReportDto previewData,Integer min,Integer max) throws ApplicationException {
		Integer sortMax=null;
		PreviewReportDto preview = new PreviewReportDto();
		List<PurchaseOrderEntity> purchaseOrder;
		List<PaperDetails> paperDetails;
		if (ApplicationUtils.isValidateObject(previewData)) {

			if (previewData.getReportData().getPeriod() != null) {

				LocalDateTime monthBefore = null;

				previewData.getReportData().setToDate(LocalDateTime.now());

				if (previewData.getReportData().getPeriod().equalsIgnoreCase("3 Month")) {
					monthBefore = LocalDateTime.now().minusMonths(3);

				} else if (previewData.getReportData().getPeriod().equalsIgnoreCase("6 Month")) {
					monthBefore = LocalDateTime.now().minusMonths(6);

				} else {
					monthBefore = LocalDateTime.now().minusYears(1);
				}
				previewData.getReportData().setFromDate(monthBefore);

			}

			if (ApplicationUtils.isValidateObject(previewData.getReportData().getInsuredCompanyId())) {
				if (previewData.getReportData().getReportType().equals(0)) { // 0 meanse purchase order

					FilterOrSortingVo orderStatusFilter = ApplicationUtils.isValidList(previewData.getFilterVo())?
							previewData.getFilterVo().stream().filter(
									filter -> filter.getColumnName().equalsIgnoreCase(TableConstants.DP_PAYMENT_METHOD))
									.findFirst().orElse(null) : null;
					
					if(ApplicationUtils.isValidateObject(orderStatusFilter)) {
						sortMax=max;
						max=null;
					}
					
					purchaseOrder = reportDao.getPreviewDataInPurchaseOrder(previewData,
							previewData.getReportData().getInsuredCompanyId(),min,max);

					if (ApplicationUtils.isValidateObject(purchaseOrder)) {
						ArrayList<LinkedHashMap<String, Object>> finalPurchaseOrderDataMap = convertEntityToDtoInPurchaseOrder(
								purchaseOrder, previewData.getReportData());

						if (ApplicationUtils.isValidateObject(orderStatusFilter)) {
							finalPurchaseOrderDataMap=finalsortMapBasedOnOrderStatus(orderStatusFilter, finalPurchaseOrderDataMap,min,sortMax);
							preview.setDataList(finalPurchaseOrderDataMap);
						}

						else {
							preview.setDataList(finalPurchaseOrderDataMap);
						}

					}
				} else {

					paperDetails = reportDao.getPreviewInPaperDetails(previewData,
							previewData.getReportData().getInsuredCompanyId(),min,max);
					if (ApplicationUtils.isValidateObject(paperDetails)) {
						preview.setDataList(
								convertEntityToDtoInPaperDetails(paperDetails, previewData.getReportData()));
					}
				}
			}

		}
		return preview;
	}

	/**
	 * Finalsort map based on order status.
	 *
	 * @param orderStatusFilter the order status filter
	 * @param finalPurchaseOrderDataMap the final purchase order data map
	 * @param min the min
	 * @param sortMax the sort max
	 * @return the array list
	 */
	private ArrayList<LinkedHashMap<String, Object>> finalsortMapBasedOnOrderStatus(FilterOrSortingVo orderStatusFilter,
			ArrayList<LinkedHashMap<String, Object>> finalPurchaseOrderDataMap, Integer min, Integer sortMax) {
			
			
					ArrayList<LinkedHashMap<String, Object>> sortedListMap = new ArrayList<LinkedHashMap<String, Object>>();
					if(orderStatusFilter.isAscending()) {
						Collections.sort(finalPurchaseOrderDataMap,new Comparator<LinkedHashMap<String, Object>>() {

							@Override
							public int compare(LinkedHashMap<String, Object> o1, LinkedHashMap<String, Object> o2) {
								String status1=(String) o1.get(TableConstants.PAPMENT_METHOD);
								String status2=(String) o2.get(TableConstants.PAPMENT_METHOD);
								if(ApplicationUtils.isValidString(status1) && ApplicationUtils.isValidString(status2)) {
									return status1.compareTo(status2);
								}
								
								return 0 ;
							}
						});
					} else {
						Collections.sort(finalPurchaseOrderDataMap,new Comparator<LinkedHashMap<String, Object>>() {

							@Override
							public int compare(LinkedHashMap<String, Object> o1, LinkedHashMap<String, Object> o2) {
								String status1=(String) o1.get(TableConstants.PAPMENT_METHOD);
								String status2=(String) o2.get(TableConstants.PAPMENT_METHOD);
								if(ApplicationUtils.isValidString(status1) && ApplicationUtils.isValidString(status2)) {
									return status2.compareTo(status1);
								}
								
								return 0 ;
							}
						});
					}
					
					sortedListMap=(ArrayList<LinkedHashMap<String, Object>>) finalPurchaseOrderDataMap.stream().skip(min).limit(sortMax).collect(Collectors.toList());
					return sortedListMap;
	}

	/**
	 * Convert entity to dto in paper details.
	 *
	 * @param paperDetails the paper details
	 * @param selectedColumn the selected column
	 * @return the array list
	 */
	private ArrayList<LinkedHashMap<String, Object>> convertEntityToDtoInPaperDetails(List<PaperDetails> paperDetails,
			ReportsDto selectedColumn) {

		ArrayList<LinkedHashMap<String, Object>> DataList = new ArrayList<LinkedHashMap<String, Object>>();

		for (PaperDetails entityData : paperDetails) {
			LinkedHashMap<String, Object> map = new LinkedHashMap<>();
			
			map.put(TableConstants.DIGITAL_PAPER_NUMBER, entityData.getPdDigitalPaperId());
			map.put(TableConstants.POLICY_NO, entityData.getPdPolicyNumber());
			
			map.put(TableConstants.INSURED_NAME, entityData.getPdInsuredName());
			map.put(TableConstants.REGISTRATION_NO, entityData.getVdRegistrationNumber());
			
			DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			String formatDateTime = entityData.getPdEffectiveFrom().format(format);
			map.put(TableConstants.EFFECTIVE_FROM, formatDateTime);
			
			DateTimeFormatter effectiveFormate = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			String effectiveDate = entityData.getPdExpireDate().format(effectiveFormate);
			map.put(TableConstants.EFFECTIVE_TO, effectiveDate);
			
			map.put(TableConstants.MAKE, entityData.getVdMake());
			map.put(TableConstants.MODEL, entityData.getVdModel());
			
			map.put(TableConstants.STATUS_REPORT,
					PaperStatusEnum.getPaperStatusById(entityData.getStatus()).getPaperStatus());			

			if (ApplicationUtils.isValidateObject(selectedColumn)) {
				for (String field : selectedColumn.getSelectedColumn()) {
					switch (field.trim()) {

					case TableConstants.CHASSIS_NUMBER:
						map.put(TableConstants.CHASSIS_NUMBER, entityData.getVdChassis());
						break;

					case TableConstants.USAGE_TYPE:
						map.put(TableConstants.USAGE_TYPE, entityData.getVdUsage());
						break;

					case TableConstants.LICENSE_TO_CARRY:
						map.put(TableConstants.LICENSE_TO_CARRY, entityData.getVdLicensedToCarry());
						break;

					case TableConstants.PHONE_NO:
						map.put(TableConstants.PHONE_NO, entityData.getPdPhoneNumber());
						break;

					case TableConstants.EMAIL_ID:
						map.put(TableConstants.EMAIL_ID, entityData.getPdEmailId());
						break;
					}
				}
			}
			DataList.add(map);
		}
		return DataList;
	}

	/**
	 * Convert entity to dto in purchase order.
	 *
	 * @param purchaseOrder the purchase order
	 * @param selectedColumn the selected column
	 * @return the array list
	 */
	private ArrayList<LinkedHashMap<String, Object>> convertEntityToDtoInPurchaseOrder(
			List<PurchaseOrderEntity> purchaseOrder, ReportsDto selectedColumn) {

		ArrayList<LinkedHashMap<String, Object>> DataList = new ArrayList<LinkedHashMap<String, Object>>();

		for (PurchaseOrderEntity entityData : purchaseOrder) {

			LinkedHashMap<String, Object> map = new LinkedHashMap<>();
			
			map.put(TableConstants.PURCHASR_ID, entityData.getPurchaseId());
			map.put(TableConstants.INSURED_NAME, selectedColumn.getInsuredName());
			
			DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			String purchaseDate = entityData.getPurchaseDate().format(format);
			map.put(TableConstants.PURCHASE_DATE, purchaseDate);
			
			map.put(TableConstants.STOCKCOUNT, entityData.getStockCount());
			
			map.put(TableConstants.ORDER_STS, PaymentStatusEnum
					.getPaymentStatusEnumById(entityData.getOrderStatus()).getPaymentStatus());
			
			map.put(TableConstants.ORDER_AMT,entityData.getOrderAmt() );
			
			map.put(TableConstants.PAPMENT_METHOD,
					PaymentModeEnum.getPaymentModeById(entityData.getPaymentMethod()).getPaymentMode());
			
			
			DataList.add(map);
		}
		return DataList;
	}

	/**
	 * Gets the digital paper column.
	 *
	 * @return the digital paper column
	 * @throws ApplicationException the application exception
	 */
	public List<String> getDigitalPaperColumn() throws ApplicationException {

		List<String> list = new ArrayList<String>();

		list.add(TableConstants.CHASSIS_NUMBER);
		list.add(TableConstants.USAGE_TYPE);
		list.add(TableConstants.LICENSE_TO_CARRY);
		list.add(TableConstants.PHONE_NO);
		list.add(TableConstants.EMAIL_ID);

		return list;
	}

	/**
	 * Gets the report purchase order column list.
	 *
	 * @return the report purchase order column list
	 * @throws ApplicationException the application exception
	 */
	@Override
	public List<String> getReportPurchaseOrderColumnList() throws ApplicationException {
		List<String> list = new ArrayList<String>();

		list.add(TableConstants.STOCKCOUNT);
		list.add(TableConstants.PURCHASE_DATE);
		list.add(TableConstants.PURCHASR_ID);
		list.add(TableConstants.ORDER_AMT);
		list.add(TableConstants.ORDER_STS);
		list.add(TableConstants.INSURED_NAME);
		list.add(TableConstants.PAPMENT_METHOD);

		return list;
	}

	/**
	 * Gets the insured company name.
	 *
	 * @return the insured company name
	 * @throws ApplicationException the application exception
	 */
	@Override
	public List<String> getInsuredCompanyName() throws ApplicationException {

		List<Customer> customerData = new ArrayList<Customer>();

		customerData = reportDao.getInsuredCompanyList();

		List<String> data = new ArrayList<String>();

		for (Customer value : customerData) {
			data.add(value.getUsername());
		}

		return data;
	}

	/**
	 * Write reports to csv.
	 *
	 * @param responseData the response data
	 * @param response the response
	 * @return the response entity
	 */
	@Override
	public ResponseEntity<ByteArrayResource> writeReportsToCsv(PreviewReportDto responseData,
			HttpServletResponse response) {

		HttpHeaders header = new HttpHeaders();
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		OutputStreamWriter streamWriter = new OutputStreamWriter(stream);

		try {

			CSVWriter writer = new CSVWriter(streamWriter, CSVWriter.DEFAULT_SEPARATOR, CSVWriter.NO_QUOTE_CHARACTER);
			List<String> keyList = new ArrayList<>();
			HashMap<String, Object> firstObject = responseData.getDataList().get(0); // Iterated only for Extracting
																						// Header Columns
			ArrayList<String> headerColumnList = new ArrayList<>();
			keyList = firstObject.keySet().stream().collect(Collectors.toList());

			for (String columnName : keyList) {
				headerColumnList.add(columnName);
			}
			String[] headerRowData = headerColumnList.toArray(new String[0]);
			writer.writeNext(headerRowData);

			for (HashMap<String, Object> map : responseData.getDataList()) { // Iterated to Extract Row Data
				ArrayList<String> rowList = new ArrayList<>();
				for (Entry<String, Object> entry : map.entrySet()) {
					String text = (entry.getValue() == null) ? "" : entry.getValue().toString().replace(",", "");
					rowList.add(text);
				}
				String[] rowData = rowList.toArray(new String[0]);
				writer.writeNext(rowData);
			}
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			baos.writeTo(stream);
			stream.write(baos.toByteArray());
			writer.close();
			return new ResponseEntity<>(new ByteArrayResource(stream.toByteArray()), header, HttpStatus.CREATED);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>(new ByteArrayResource(stream.toByteArray()), header, HttpStatus.CREATED);
	}

	/**
	 * Download report as pdf.
	 *
	 * @param data the data
	 * @return the response entity
	 */
	@Override
	public ResponseEntity<ByteArrayResource> downloadReportAsPdf(PreviewReportDto data) {

		ByteArrayOutputStream pdfStream = new ByteArrayOutputStream();
		HttpHeaders header = new HttpHeaders();

		try {

			List<String> keyList = new ArrayList<>();
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet(ApplicationConstants.REPORTS);
			XSSFRow hederRow = sheet.createRow((int) ApplicationConstants.ZERO);
			
			Document pdfData = new Document();
			PdfWriter.getInstance(pdfData, pdfStream);
			PdfPCell table_cell = new PdfPCell();
			PdfPTable pdfTableData = null;
			
			pdfData.open();
			LinkedHashMap<String, Object> customMap = new LinkedHashMap<>();

			int rowIndex = ApplicationConstants.ZERO;
			for (HashMap<String, Object> map : data.getDataList()) { // Iterated only for Extracting Header Columns
				Set<String> keys = map.keySet();
				keyList = keys.stream().collect(Collectors.toList());
				pdfTableData = new PdfPTable(keyList.size());
				for (int i = ApplicationConstants.ZERO; i < keyList.size(); i++) {	
					hederRow.createCell(i).setCellValue(keyList.get(i));
					
					table_cell = new PdfPCell(new Phrase(hederRow.getCell(i).getStringCellValue()));
					pdfTableData.addCell(table_cell);
				}
			}

			for (HashMap<String, Object> map : data.getDataList()) {
				int columnIndex = ApplicationConstants.ZERO;
				XSSFRow row = sheet.createRow((int) rowIndex + 1);
				for (Entry<String, Object> entry : map.entrySet()) {
					row.createCell(columnIndex).setCellValue((entry.getValue() != null) ? entry.getValue().toString()
							: ApplicationConstants.WITHOUT_SPACE);
					table_cell = new PdfPCell(new Phrase(row.getCell(columnIndex).getStringCellValue()));
					pdfTableData.addCell(table_cell);
					columnIndex++;
				}
				rowIndex++;
			}

			pdfTableData.setWidthPercentage(100);
			pdfTableData.setHorizontalAlignment(Element.ALIGN_LEFT);
			header.setContentType(new MediaType("application", "force-download"));
			header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ProductTemplate.pdf");
			pdfData.add(pdfTableData);
			pdfData.close();
			workbook.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>(new ByteArrayResource(pdfStream.toByteArray()), header, HttpStatus.CREATED);
	}

	/**
	 * getPreviewDataCount
	 */
	@Override
	public Long getPreviewDataCount(PreviewReportDto previewData) throws ApplicationException {

		Long previewDataCount = null;
		if (ApplicationUtils.isValidateObject(previewData)) {

			if (previewData.getReportData().getPeriod() != null) {
				LocalDateTime monthBefore = null;
				previewData.getReportData().setToDate(LocalDateTime.now());
				if (previewData.getReportData().getPeriod().equalsIgnoreCase("3 Month")) {
					monthBefore = LocalDateTime.now().minusMonths(3);
				} else if (previewData.getReportData().getPeriod().equalsIgnoreCase("6 Month")) {
					monthBefore = LocalDateTime.now().minusMonths(6);
				} else {
					monthBefore = LocalDateTime.now().minusYears(1);
				}
				previewData.getReportData().setFromDate(monthBefore);
			}

			if (ApplicationUtils.isValidateObject(previewData.getReportData().getInsuredCompanyId())) {
				if (previewData.getReportData().getReportType().equals(0)) { // 0 meanse purchase order

					previewDataCount = reportDao.getPreviewDataInPurchaseOrderCount(previewData,previewData.getReportData().getInsuredCompanyId());
				} else {
					previewDataCount = reportDao.getPreviewInPaperDetailsCount(previewData,previewData.getReportData().getInsuredCompanyId());
				}
			}

		}
		return previewDataCount;

	}

}
