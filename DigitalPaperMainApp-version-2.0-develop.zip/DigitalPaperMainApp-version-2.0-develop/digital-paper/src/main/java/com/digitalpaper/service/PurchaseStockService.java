package com.digitalpaper.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.AssociationDashboardCountDto;
import com.digitalpaper.transfer.object.dto.CompanyTransactionDto;
import com.digitalpaper.transfer.object.dto.PaymentDetailsDto;
import com.digitalpaper.transfer.object.dto.PurchaseOrderDto;
import com.digitalpaper.transfer.object.dto.ViewHistoryDto;

/**
 * The Interface PurchaseStockService.
 */
public interface PurchaseStockService {
		
		/**
		 * Gets the purchase list.
		 *
		 * @param min the min
		 * @param max the max
		 * @param searchValue the search value
		 * @param filterSort the filter sort
		 * @return the purchase list
		 * @throws ApplicationException the application exception
		 */
		public List<PurchaseOrderDto> getPurchaseList(int min,int max,String searchValue, List <FilterOrSortingVo> filterSort) throws ApplicationException;
		
		 /**
 		 * Gets the purchase order count.
 		 *
 		 * @param filterVo the filter vo
 		 * @param searchValue the search value
 		 * @return the purchase order count
 		 * @throws ApplicationException the application exception
 		 */
 		public Long getPurchaseOrderCount(List<FilterOrSortingVo> filterVo,String searchValue) throws ApplicationException;

		/**
		 * Approve or reject purchase details.
		 *
		 * @param paymentDetailsDto the payment details dto
		 * @return the string
		 * @throws ApplicationException the application exception
		 */
		public String approveOrRejectPurchaseDetails(PaymentDetailsDto paymentDetailsDto) throws ApplicationException;

		/**
		 * Gets the transaction details.
		 *
		 * @param companyTransactionList the company transaction list
		 * @param searchvalue the searchvalue
		 * @return the transaction details
		 * @throws ApplicationException the application exception
		 */
		public List<ViewHistoryDto> getTransactionDetails(CompanyTransactionDto companyTransactionList,String searchvalue) throws ApplicationException;

		/**
		 * 
		 * @return
		 * @throws ApplicationException 
		 */
		public Long getAllPurchaseOrderCount(CompanyTransactionDto companyTransactionDto, String searchValue) throws ApplicationException;

		/**
		 * Download data converting.
		 *
		 * @param transactionDetails the transaction details
		 * @param selectedColumn the selected column
		 * @return the array list
		 */
		public ArrayList<HashMap<String, Object>> downloadDataConverting(List<ViewHistoryDto> transactionDetails,
				List<String> selectedColumn);

		/**
		 * Gets the stock file id.
		 *
		 * @param id the id
		 * @return the stock file id
		 */
		public Integer getStockFileId(Integer id);

		/**
		 * Common download.
		 *
		 * @param data the data
		 * @param columnList the column list
		 * @return the response entity
		 * @throws ApplicationException the application exception
		 */
		public ResponseEntity<InputStreamResource> commonDownload(List<PurchaseOrderDto> data, List<String> columnList) throws ApplicationException;

		/**
		 * Gets the authority dashboard count.
		 *
		 * @param associatioId the associatio id
		 * @return the authority dashboard count
		 */
		public List<AssociationDashboardCountDto> getAuthorityDashboardCount(Integer associatioId);


}
