package com.digitalpaper.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.digitalpaper.config.base.controller.BaseController;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.file.handler.service.IEmailService;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.MailRequestDto;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;
import com.fasterxml.jackson.databind.ObjectMapper;

import freemarker.template.TemplateException;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class EmailController.
 */
@RestController
public class EmailController extends BaseController {

	/** The service. */
	@Autowired
	private IEmailService service;
	
	/** The object mapper. */
	@Autowired
	private ObjectMapper objectMapper;

	
	/**
	 * Send multiple email.
	 *
	 * @param paperDetailsDto the paper details dto
	 * @return the application response
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws TemplateException the template exception
	 */
	@ApiOperation(value="Email",notes="Email Sending operation",response = ApplicationException.class)
	@PostMapping("/email-send")
	public ApplicationResponse sendMultipleEmail(@ApiParam(value="Paper details dto payload",required=true) @RequestBody List<PaperDetailsDto> paperDetailsDto)
			throws IOException, TemplateException {

		service.setEmailPart(paperDetailsDto);
		return getApplicationResponse("email send successfully");
	}
	
	/**
	 * Notification consumer.
	 *
	 * @param request the request
	 * @param acknowledgement the acknowledgement
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws TemplateException the template exception
	 */
	@KafkaListener(topics = "email-topic",groupId = "myGroup")
	public void NotificationConsumer(@RequestBody String request,Acknowledgment acknowledgement)
			throws IOException, TemplateException {
		acknowledgement.acknowledge();
		MailRequestDto mailRequest = objectMapper.readValue(request,MailRequestDto.class);
		service.sendEmailThrowKafka(mailRequest);
	}

	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {

	}
}
