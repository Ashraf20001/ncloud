package com.digitalpaper.utils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;

import com.digitalpaper.config.DigitalPaperCache;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.constants.core.SessionScopeClass;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.restemplate.service.IRestTemplateService;
import com.digitalpaper.security.jwt.JwtUtils;
import com.digitalpaper.transfer.object.dto.MakeModelUsageDto;
import com.digitalpaper.transfer.object.dto.PlatformDetailsDto;
import com.digitalpaper.transfer.object.dto.RoleListDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.entity.UserType;
import com.digitalpaper.transfer.object.enums.DataFilterEnum;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;
import com.digitalpaper.utils.core.ApplicationUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import io.jsonwebtoken.Claims;

/**
 * The Class HttpInterceptor.
 */
@Component
public class HttpInterceptor implements HandlerInterceptor {

	/**
	 * JwtUtils
	 */
	@Autowired
	private JwtUtils jwtUtils;

	/**
	 * LoggedInUserContextHolder
	 */
	@Autowired
	private LoggedInUserContextHolder loggedInUserContextHolder;

	/** The restemplate service. */
	@Autowired
	IRestTemplateService restemplateService;
	
	/** The session scope class. */
	@Autowired
	private SessionScopeClass sessionScopeClass;

	/**
	 * @param request
	 * @param response
	 * @param handler
	 */
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception,ApplicationException {
		String jwtToken="";
		try {
			jwtToken= parseJwt(request);
			if (jwtToken != null && jwtUtils.validateJwtToken(jwtToken)) {
				Claims userDetailsMap = jwtUtils.getUserDetailsFromJwtToken(jwtToken);
				UserInfo userInfo = buildUserInfo(userDetailsMap);
				setBasePredicateVariableValue(userInfo);
				
				loggedInUserContextHolder.setLoggedInUser(userInfo);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

        checkIsRoleHasPrivilege(request);
		getSystemPropertyVAlue(request);
		getAllCompanyData(request);
		getMakeModelAndUsageDropdownToCache(request);

		return HandlerInterceptor.super.preHandle(request, response, handler);
	}

	/**
	 * Sets the base predicate variable value.
	 *
	 * @param userInfo the new base predicate variable value
	 */
	private void setBasePredicateVariableValue(UserInfo userInfo) {
		if(ApplicationUtils.isValidateObject(userInfo.getUserTypeId())) {
			String userType = DataFilterEnum.getUserType(userInfo.getUserTypeId().getUserTypeName());
			if(ApplicationUtils.isValidString(userType)   &&  userType.equalsIgnoreCase(ApplicationConstants.INSURANCE_COMPANY_CAP)) {
				sessionScopeClass.setPredicateMap(userType,userInfo.getCompanyId());
			}else {
				sessionScopeClass.removePredicate();
			}
		}
	}

	/**
	 * Gets the make model and usage dropdown to cache.
	 *
	 * @param request the request
	 * @return the make model and usage dropdown to cache
	 */
	private void getMakeModelAndUsageDropdownToCache(HttpServletRequest request) {
		List<String> makes = DigitalPaperCache.getMakes();	
		List<String> models = DigitalPaperCache.getModels();
		List<String> usage = DigitalPaperCache.getUsage();
		if(!ApplicationUtils.isValidList(makes) || 
				!ApplicationUtils.isValidList(models) 
				|| !ApplicationUtils.isValidList(usage)) {
			
			 MakeModelUsageDto allMakeModelUsageDropdowns = restemplateService.getAllMakeModelUsageDropdowns(request);
			DigitalPaperCache.setMakes(allMakeModelUsageDropdowns.getMake());
			DigitalPaperCache.setModels(allMakeModelUsageDropdowns.getModel());
			DigitalPaperCache.setUsage(allMakeModelUsageDropdowns.getUsage());
		}
		
	}

	/**
	 * Gets the all company data.
	 *
	 * @param request the request
	 * @return the all company data
	 * @throws ApplicationException the application exception
	 */
	private void getAllCompanyData(HttpServletRequest request) throws ApplicationException {

		HashMap<Integer, String> companyList = DigitalPaperCache.getCompanyList();
		if (!ApplicationUtils.isValidateObject(companyList)) {

			companyList = restemplateService.getAllCompany(request);
			DigitalPaperCache.setCompanyList(companyList);
		}
	}

	/**
	 * Gets the system property V alue.
	 *
	 * @param request the request
	 * @return the system property V alue
	 * @throws ApplicationException the application exception
	 */
	private void getSystemPropertyVAlue(HttpServletRequest request) throws ApplicationException {

		HashMap<String, String> systemPropertyValue = DigitalPaperCache.getSystemPropertyVAlue();
		if (!ApplicationUtils.isValidateObject(systemPropertyValue)) {

			systemPropertyValue = restemplateService.getSystemPropertyValue(request);
			DigitalPaperCache.setSystemPropertyVAlue(systemPropertyValue);
		}
	}

	/**
	 * Check is role has privilege.
	 *
	 * @param request the request
	 * @throws ApplicationException the application exception
	 */
	private void checkIsRoleHasPrivilege(HttpServletRequest request) throws ApplicationException {
		boolean flag = false;
		Map<Integer, String> roleApiMap = DigitalPaperCache.getRoleApiMap();
		if (!ApplicationUtils.isValidateObject(roleApiMap)) {
			roleApiMap = restemplateService.allApiPrivilege(request);
			DigitalPaperCache.setRoleApiMap(roleApiMap);
		}
		
		if(!ApplicationUtils.isValidObject(loggedInUserContextHolder.getLoggedInUser())) {
			return;
		}

		if (ApplicationUtils.isValidList(loggedInUserContextHolder.getLoggedInUser().getRoles())) {
			List<Integer> roleIds = loggedInUserContextHolder.getLoggedInUser().getRoles().stream()
					.map(s -> s.getRoleId()).toList();
			for (Integer roleid : roleIds) {
				if (!flag) {
					flag = checkApiIsValid(request, roleid);
				}

			}
			if (!flag) {

				throw new ApplicationException(ErrorCodes.UN_AUTHORIZED);

			}
		}
		
	}

	/**
	 * Check api is valid.
	 *
	 * @param request the request
	 * @param roleid the roleid
	 * @return true, if successful
	 * @throws ApplicationException the application exception
	 */
	private boolean checkApiIsValid(HttpServletRequest request, Integer roleid) throws ApplicationException {
		boolean flag = true;
		String api = request.getRequestURI();
		String apiList = DigitalPaperCache.getRoleApiMap().get(roleid);

		if (ApplicationUtils.isValidString(apiList)) {
			if (!ApplicationConstants.CLEAR_CACHE_URLS.contains(api) && !ApplicationConstants.SWAGGER_API_URLS.contains(api) && !api.contains(ApplicationConstants.SWAGGER)) {
				flag = Arrays.asList(apiList.split(",")).stream().anyMatch(api::contains);
			}
		}
		return flag;

	}

	/**
	 * @param userDetailsMap
	 * @return
	 */
	private UserInfo buildUserInfo(Claims userDetailsMap) {
		UserInfo userInfo = new UserInfo();
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.ID))) {
			userInfo.setId(Integer.parseInt(userDetailsMap.get(ApplicationConstants.ID).toString()));
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.USER_NAME))) {
			userInfo.setUsername(userDetailsMap.get(ApplicationConstants.USER_NAME).toString());
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.EMAIL))) {
			userInfo.setEmail(userDetailsMap.get(ApplicationConstants.EMAIL).toString());
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.PLATFORM_IDENTITY))) {
			userInfo.setPlatformIdentity(userDetailsMap.get(ApplicationConstants.PLATFORM_IDENTITY).toString());
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.ASSOCIATION_ID))) {
			userInfo.setAssociationId(
					Integer.parseInt(userDetailsMap.get(ApplicationConstants.ASSOCIATION_ID).toString()));
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.USER_TYPE))) {
			ModelMapper modelMapper = new ModelMapper();
			UserType userType = modelMapper.map(userDetailsMap.get(ApplicationConstants.USER_TYPE), UserType.class);
			userInfo.setUserTypeId(userType);
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.IDENTITY))) {
			userInfo.setIdentity(userDetailsMap.get(ApplicationConstants.IDENTITY).toString());
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.PLATFORM_DETAILS))) {
			ModelMapper modelMapper = new ModelMapper();
			PlatformDetailsDto platformDetails = modelMapper
					.map(userDetailsMap.get(ApplicationConstants.PLATFORM_DETAILS), PlatformDetailsDto.class);
			userInfo.setPlatformDetailsDto(platformDetails);
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.COMPANY_ID))) {
			userInfo.setCompanyId(Integer.parseInt(userDetailsMap.get(ApplicationConstants.COMPANY_ID).toString()));
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.ALLOCATION_USER_TYPE))) {
			userInfo.setAllocationUserType(
					Integer.parseInt(userDetailsMap.get(ApplicationConstants.ALLOCATION_USER_TYPE).toString()));
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.COMPANY_NAME))) {
			userInfo.setCompanyName(userDetailsMap.get(ApplicationConstants.COMPANY_NAME).toString());
		}
		if (ApplicationUtils.isValidateObject(userDetailsMap.get(ApplicationConstants.ROLES))) {
			String object = (String) userDetailsMap.get(ApplicationConstants.ROLES);
			String string = "{" + '"' + "userRoleList" + '"' + ":" + object + "}";
			RoleListDto readValue = null;
			try {
				readValue = new com.fasterxml.jackson.databind.ObjectMapper().readValue(string, RoleListDto.class);
			} catch (JsonMappingException e) {
				e.printStackTrace();
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
			userInfo.setRoles(readValue.getUserRoleList());
		}
		return userInfo;
	}

	/**
	 * @param request
	 * @return
	 */
	private String parseJwt(HttpServletRequest request) {
		String headerAuth = request.getHeader(ApplicationConstants.AUTHORIZATION);
		if (StringUtils.hasText(headerAuth) && headerAuth.startsWith(ApplicationConstants.BEARER)) {
			return headerAuth.substring(7, headerAuth.length());
		}
		return null;
	}
}
