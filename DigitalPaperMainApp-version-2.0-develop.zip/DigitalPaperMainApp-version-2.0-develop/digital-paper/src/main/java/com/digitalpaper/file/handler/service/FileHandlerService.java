package com.digitalpaper.file.handler.service;

import java.io.IOException;

import org.springframework.core.io.Resource;

/**
 * The Interface FileHandlerService.
 */
public interface FileHandlerService {
	
	/**
	 * Gets the file data by URL.
	 *
	 * @param fileName the file name
	 * @return the file data by URL
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public Resource getFileDataByURL(String fileName) throws IOException;

}
