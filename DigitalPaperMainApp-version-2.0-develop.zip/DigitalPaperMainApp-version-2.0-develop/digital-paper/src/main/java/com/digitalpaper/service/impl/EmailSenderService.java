package com.digitalpaper.service.impl;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.digitalpaper.transfer.object.dto.MailResponse;
import com.digitalpaper.transfer.object.dto.ResetPasswordRequest;
import freemarker.template.Configuration;
import freemarker.template.Template;

/**
 * The Class EmailSenderService.
 */
@Service
public class EmailSenderService {

	/** The java mail sender. */
	@Autowired
	private JavaMailSender javaMailSender;
	
	/** The config. */
	@Autowired
	private Configuration config;
	
	/** The Constant Template_Folder_Path. */
	public static final String Template_Folder_Path = "/Tempplate";
	
	/**
	 * @param request
	 * @return
	 */
	public MailResponse sendResetEmail(ResetPasswordRequest request) {
		MailResponse response = new MailResponse();
		MimeMessage message = javaMailSender.createMimeMessage();
		Map<String, Object> model = new HashMap<>();
		model.put("url", request.getTemplate());
		model.put("name",request.getName());
		try {
			
			// media type
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			
			config.setClassForTemplateLoading(this.getClass(), Template_Folder_Path);
			Template template = config.getTemplate("forgetPassword_template.ftl");
			
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(template,model);
			
				helper.setTo(request.getTo());
				helper.setText(html, true);
				helper.setSubject(request.getSubject());
				javaMailSender.send(message);
		
			response.setMessage("mail send successfully");
			response.setStatus(Boolean.TRUE);
			

		} catch (Exception e) {
			response.setMessage("Mail Sending failure : "+ e.getMessage());
			response.setStatus(Boolean.FALSE);
		}

		return response;
	}
}
