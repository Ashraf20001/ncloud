package com.digitalpaper.restemplate.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.config.property.EnvironmentProperties;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.BulkImportFieldValidationDto;
import com.digitalpaper.transfer.object.dto.BulkImportHistoryDto;
import com.digitalpaper.transfer.object.dto.CompanyDto;
import com.digitalpaper.transfer.object.dto.DigitalPaperDto;
import com.digitalpaper.transfer.object.dto.FieldGroup;
import com.digitalpaper.transfer.object.dto.MakeModelUsageDto;
import com.digitalpaper.transfer.object.dto.UserRoleCardDto;
import com.digitalpaper.utils.core.RestTemplateUtils;
/**
 * @author CBT
 *
 */
@Service
@Transactional
public class RestTemplateServiceImpl implements IRestTemplateService {

	/**
	 * RestTemplateUtils
	 */
	@Autowired
	private RestTemplateUtils restTemplateUtils;

	/**
	 * RestTemplate
	 */
	@Autowired
	private RestTemplate restTemplate;
	
	/** The environment properties. */
	@Autowired
	private EnvironmentProperties environmentProperties;

	/**
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Long getCompanyListCount(List<FilterOrSortingVo> filterOrSortingVos) throws ApplicationException {

		HttpHeaders headers = restTemplateUtils.getPOSTHeaders();
		HttpEntity<List<FilterOrSortingVo>> entity = new HttpEntity<>(filterOrSortingVos,headers);
		String url = environmentProperties.getGateWayPath() +  ApplicationConstants.COMPANY_COUNT;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		builder.queryParam("searchValue", "");
		return restTemplate.exchange(builder.toUriString(), HttpMethod.POST, entity, Long.class).getBody();
	}

	/**
	 * @param min
	 * @param max
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public List<CompanyDto> getCompanyList(List<FilterOrSortingVo> filterOrSortingVos) throws ApplicationException {
		Integer min = 0;
		Long maxCount = getCompanyListCount(filterOrSortingVos);
		HttpHeaders headers = restTemplateUtils.getGETHeaders();
		HttpEntity<List<FilterOrSortingVo>> staticEntity = new HttpEntity<>(filterOrSortingVos,headers);
		String url = environmentProperties.getGateWayPath() + ApplicationConstants.COMPANY_LIST;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		builder.queryParam("min", min);
		builder.queryParam("max", maxCount);
		builder.queryParam("searchValue", "");
		ResponseEntity<List<CompanyDto>> entity = restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
				staticEntity, new ParameterizedTypeReference<List<CompanyDto>>() {});
		return entity.getBody();
	}
	
	/**
	 *@param propertyName
	 *@param request
	 */
	@Override
	public String getAllocationType(String propertyName, Integer associationId, HttpServletRequest request) {
		HttpHeaders headers = restTemplateUtils.configureRestTemplate(request);
		HttpEntity<String> staticEntity = new HttpEntity<String>(headers);
		String url = environmentProperties.getGateWayPath() +  ApplicationConstants.ALLOCATION_TYPE_URL;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		builder.queryParam("propertyName", propertyName);
		ResponseEntity<String> entity = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, staticEntity,
				new ParameterizedTypeReference<String>() {
				});
		return entity.getBody();
	}

	/**
	 * @param identity
	 * @return
	 * @throws ApplicationException
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<String> getMetaDataList(String identity,HttpServletRequest request) throws ApplicationException {
		HttpHeaders headers = restTemplateUtils.configureRestTemplate(request);
		HttpEntity<String> staticEntity = new HttpEntity<String>(headers);
		String url = environmentProperties.getGateWayPath() +  ApplicationConstants.FIELD_DATA_LIST;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		builder.queryParam("pageIdentity", identity);
		ResponseEntity<List<String>> entity = restTemplate.exchange(builder.toUriString(), HttpMethod.POST, staticEntity,
				new ParameterizedTypeReference<List<String>>() {
				});
		return entity.getBody();
	}
	
	/**
	 * Send bulk import history dto to update.
	 *
	 * @param validationDto the validation dto
	 * @return the bulk import history dto
	 */
	public BulkImportHistoryDto sendBulkImportHistoryDtoToUpdate(BulkImportFieldValidationDto validationDto) {
		 HttpHeaders httpHeaders = restTemplateUtils.getPOSTHeaders();
			HttpEntity<BulkImportHistoryDto> entity = new HttpEntity<>(validationDto.getBulkImportHistoryDto(),httpHeaders);
			String url = environmentProperties.getCommonServicePath() + ApplicationConstants.UPDATE_BULK_HISTORY_PATH;
			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
			ResponseEntity<BulkImportHistoryDto> exchange = restTemplate.exchange(builder.toUriString(), HttpMethod.POST, entity, BulkImportHistoryDto.class);
			BulkImportHistoryDto body = exchange.getBody();
			return body;
		
	}
	
	/**
	 * Gets the customer profile url.
	 *
	 * @param referenceId the reference id
	 * @param rpType the rp type
	 * @return the customer profile url
	 */
	public ApplicationResponse getCustomerProfileUrl(Integer referenceId,String rpType) {
			HttpHeaders httpHeaders = restTemplateUtils.getGETHeaders();
			HttpEntity<Object> httpEntity = new HttpEntity<>(httpHeaders);
			String url= environmentProperties.getCommonServicePath()+ApplicationConstants.CUSTOMER_PROFILE_URL;
			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
			builder.queryParam("referenceId", referenceId);
			builder.queryParam("rpType",rpType);
			 ResponseEntity<ApplicationResponse> exchange = restTemplate.exchange(builder.toUriString(),HttpMethod.GET, httpEntity, ApplicationResponse.class);
			ApplicationResponse body = exchange.getBody();
			return body;
	}

	/**
	 * Convert dto to field group.
	 *
	 * @param dto the dto
	 * @param request the request
	 * @return the field group
	 */
	@Override
	public FieldGroup convertDtoToFieldGroup(DigitalPaperDto dto, HttpServletRequest request) {
		 HttpHeaders httpHeaders = restTemplateUtils.getPOSTHeaders();
			HttpEntity<DigitalPaperDto> entity = new HttpEntity<>(dto,httpHeaders);
			String url = environmentProperties.getCommonServicePath() + ApplicationConstants.DIGITALPAPER_DTO_TO_FIELDGROUP;
			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
			ResponseEntity<FieldGroup> exchange = restTemplate.exchange(builder.toUriString(), HttpMethod.POST, entity, FieldGroup.class);
			FieldGroup body = exchange.getBody();
			return body;
	}
	

	/**
	 * Gets the system property value.
	 *
	 * @param request the request
	 * @return the system property value
	 * @throws ApplicationException the application exception
	 */
	@Override
	public HashMap<String, String> getSystemPropertyValue( HttpServletRequest request)
			throws ApplicationException {
		HttpHeaders httpHeaders = restTemplateUtils.getPOSTHeaders();
		HttpEntity<HashMap<String, String>> staticEntity = new HttpEntity<HashMap<String, String>>(httpHeaders);
		String url = environmentProperties.getCommonServicePath() + ApplicationConstants.GET_SYSTEM_PROPERTY_URL;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		ResponseEntity<HashMap<String, String>> entity = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, staticEntity,
				new ParameterizedTypeReference<HashMap<String, String>>() {
				});
		return entity.getBody();
	}

	/**
	 * Gets the all company.
	 *
	 * @param request the request
	 * @return the all company
	 * @throws ApplicationException the application exception
	 */
	@Override
	public HashMap<Integer, String> getAllCompany( HttpServletRequest request)
			throws ApplicationException {
		HttpHeaders httpHeaders = restTemplateUtils.getPOSTHeaders();
		HttpEntity<HashMap<Integer, String>> staticEntity = new HttpEntity<HashMap<Integer, String>>(httpHeaders);
		String url = environmentProperties.getCommonServicePath() + ApplicationConstants.GET_ALL_COMPANY;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		ResponseEntity<HashMap<Integer, String>> entity = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, staticEntity,
				new ParameterizedTypeReference<HashMap<Integer, String>>() {
				});
		return entity.getBody();
	}
	
	/**
	 * All api privilege.
	 *
	 * @param request the request
	 * @return the map
	 */
	@Override
	public Map<Integer, String> allApiPrivilege(HttpServletRequest request) {
		HttpHeaders httpHeaders = restTemplateUtils.getGETHeaders();
		HttpEntity<?> entity = new HttpEntity<>(httpHeaders);
		String url = environmentProperties.getCommonServicePath() + ApplicationConstants.ALL_API_PRIVILEGE;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		ResponseEntity<Map<Integer, String>> exchange = restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
				entity, new ParameterizedTypeReference<Map<Integer, String>>() {
				});
		Map<Integer, String> body = exchange.getBody();
		return body;
	}

	
	/**
	 * Gets the role details for card view.
	 *
	 * @param CompanyId the company id
	 * @param request the request
	 * @return the role details for card view
	 */
	@Override
	public List<UserRoleCardDto> getRoleDetailsForCardView(Integer CompanyId,HttpServletRequest request) {
		HttpHeaders httpHeaders = restTemplateUtils.configureRestTemplate(request);
		HttpEntity<String> entity = new HttpEntity<String>(httpHeaders);
		String url = environmentProperties.getCommonServicePath() + "/get-role-list";
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		builder.queryParam("companyId", CompanyId);
		return restTemplate.exchange(builder.toUriString(), HttpMethod.GET, entity, new ParameterizedTypeReference<List<UserRoleCardDto>>() {
		}).getBody();
	}
	
	/**
	 * Gets the company dto.
	 *
	 * @param companyId the company id
	 * @return the company dto
	 */
	@Override
	public CompanyDto getCompanyDto(Integer companyId) {
		String url=environmentProperties.getCommonServicePath()+ApplicationConstants.SINGLE_COMPANY_OBJECT_DTO;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		builder.queryParam("companyId", companyId);
		return restTemplate.getForEntity(builder.toUriString(),CompanyDto.class).getBody();		
	}

	/**
	 * Gets the all make model usage dropdowns.
	 *
	 * @param request the request
	 * @return the all make model usage dropdowns
	 */
	@Override
	public MakeModelUsageDto getAllMakeModelUsageDropdowns(HttpServletRequest request) {
		HttpHeaders httpHeaders = restTemplateUtils.getGETHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(httpHeaders);
		String url=environmentProperties.getCommonServicePath()+ApplicationConstants.MAKE_MODEL_USAGE_LIST_URL;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		return restTemplate.exchange(builder.toUriString(), HttpMethod.GET,entity,MakeModelUsageDto.class).getBody();
	}
	
	/**
	 * Gets the all users specific to A company.
	 *
	 * @param request the request
	 * @return the all users specific to A company
	 */
	@Override
	public ApplicationResponse getAllUsersSpecificToACompany(HttpServletRequest request) {
		HttpHeaders httpHeaders = restTemplateUtils.configureRestTemplate(request);
		HttpEntity<String> entity = new HttpEntity<String>(httpHeaders);
		String url = environmentProperties.getCommonServicePath() + "/get-user-management-list";
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		builder.queryParam("min", ApplicationConstants.ZERO);
		builder.queryParam("max", ApplicationConstants.ZERO);
		return restTemplate.exchange(builder.toUriString(), HttpMethod.POST, entity,ApplicationResponse.class).getBody();
	}
	
	
}
