package com.digitalpaper.service;



import javax.servlet.http.HttpServletRequest;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;

import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.BulkImportFieldValidationDto;
import com.digitalpaper.transfer.object.dto.UserInfo;


/**
 * The Interface PaperDetailsBulkUploadService.
 */
public interface PaperDetailsBulkUploadService {

	/**
	 * Gets the excel sheet reading.
	 *
	 * @param validationDto the validation dto
	 * @param request the request
	 * @return the excel sheet reading
	 */
	void getExcelSheetReading(BulkImportFieldValidationDto validationDto, HttpServletRequest request);

	/**
 * Bulk upload sample excel download.
 *
 * @param pageIdentity the page identity
 * @param request the request
 * @return the response entity
 * @throws ApplicationException the application exception
 */
ResponseEntity<InputStreamResource> bulkUploadSampleExcelDownload(String pageIdentity, HttpServletRequest request)
			throws ApplicationException;

	/**
	 * Validate stock count availability.
	 *
	 * @param userinfo the userinfo
	 * @return the boolean
	 * @throws ApplicationException the application exception
	 */
	Boolean validateStockCountAvailability(UserInfo userinfo) throws ApplicationException;

}
