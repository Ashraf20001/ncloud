package com.digitalpaper.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.digitalpaper.aop.annotation.Auditable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.digitalpaper.config.base.controller.BaseController;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.service.DashBoardService;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.AuthorityBarChartDto;
import com.digitalpaper.transfer.object.dto.BarChartDto;
import com.digitalpaper.transfer.object.dto.DashBoardInputDto;
import com.digitalpaper.transfer.object.dto.DashBoardOutputDto;
import com.digitalpaper.transfer.object.dto.DoughNutDto;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;
import com.digitalpaper.transfer.object.dto.TopCompanyPurchaseDto;
import com.digitalpaper.transfer.object.dto.ViewHistoryDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class DashBoardController.
 */
@RestController
@RequestMapping("/dashboard")
@Auditable
public class DashBoardController extends BaseController {
	
	/** DashBoardService. */
	@Autowired
	private DashBoardService dashBoardService;
	
	/**
	 * Gets the recent digital papers.
	 *
	 * @param dashBoardInputDto the dash board input dto
	 * @return the recent digital papers
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Recent digital papers",notes="Get recent digital paper list for dashboard",response = ApplicationResponse.class)
	@PostMapping("/get-recent-digital-papers")
	public ApplicationResponse getRecentDigitalPapers(@ApiParam(value = "Dashboard input dto payload",required = true) @RequestBody DashBoardInputDto dashBoardInputDto) throws ApplicationException {
		List<PaperDetailsDto> companyRecentDigitalPapers = dashBoardService.getCompanyRecentDigitalPapers(dashBoardInputDto);
		ApplicationResponse applicationResponse = getApplicationResponse(companyRecentDigitalPapers);
		return applicationResponse;
	}
	
	/**
	 * Gets the upcoming expiry digital papers.
	 *
	 * @param dashBoardInputDto the dash board input dto
	 * @return the upcoming expiry digital papers
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Expiry digital papers",notes="Get expiry digital paper list for dashboard",response = ApplicationResponse.class)
	@PostMapping("/get-expiry-digital-papers")
	public ApplicationResponse getUpcomingExpiryDigitalPapers( @ApiParam(value = "Dashboard input dto payload",required = true) @RequestBody DashBoardInputDto dashBoardInputDto) throws ApplicationException {
		List<PaperDetailsDto> companyExpiryDigitalPapers = dashBoardService.getCompanyExpiryDigitalPapers(dashBoardInputDto);
		ApplicationResponse applicationResponse = getApplicationResponse(companyExpiryDigitalPapers);
		return applicationResponse;
	}
	
	/**
	 * Gets the all recent digital papers.
	 *
	 * @param dashBoardInputDto the dash board input dto
	 * @return the all recent digital papers
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="All recent digital papers",notes="Get all recent digital papers for authority dashboard",response = ApplicationResponse.class)
	@PostMapping("/get-all-recent-digital-papers")
	public ApplicationResponse getAllRecentDigitalPapers(@ApiParam(value="DashboardInput dto payload",required = true) @RequestBody DashBoardInputDto dashBoardInputDto) throws ApplicationException {
		List<PaperDetailsDto> allCompanyRecentDigitalPapers = dashBoardService.getAllCompaniesRecentDigitalPapers(dashBoardInputDto);
		ApplicationResponse applicationResponse = getApplicationResponse(allCompanyRecentDigitalPapers);
		return applicationResponse;
	}

	/**
	 * Gets the all recent transactions.
	 *
	 * @param dashBoardInputDto the dash board input dto
	 * @return the all recent transactions
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="All recent transactions",notes="Get all recent transactions details for authority dashboard",response=ApplicationResponse.class)
	@PostMapping("/get-all-recent-transactions")
	public ApplicationResponse getAllRecentTransactions( @ApiParam(value="DashboardInput dto payload",required = true) @RequestBody DashBoardInputDto dashBoardInputDto) throws ApplicationException {
		List<ViewHistoryDto> allRecentTransactions = dashBoardService.getAllCompaniesRecentTransaction(dashBoardInputDto);
		ApplicationResponse applicationResponse = getApplicationResponse(allRecentTransactions);
		return applicationResponse;
	}
	
	/**
	 * Gets the top companies purchases.
	 *
	 * @param dashBoardInputDto the dash board input dto
	 * @return the top companies purchases
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Top company purchases",notes="Get top company purchase list",response=ApplicationResponse.class)
	@PostMapping("/get-companies-top-purchases")
	public ApplicationResponse getTopCompaniesPurchases(@ApiParam(value="DashboardInput dto payload",required = true) @RequestBody DashBoardInputDto dashBoardInputDto) throws ApplicationException {
		List<TopCompanyPurchaseDto> topPurchaseData = dashBoardService.getTopPurchaseData(dashBoardInputDto);
		return getApplicationResponse(topPurchaseData);
		 
	}
	
	/**
	 * Gets the all companies id.
	 *
	 * @return the all companies id
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Company Ids",notes="Get all companies id list",response=ApplicationResponse.class)
	@GetMapping("/get-all-companyIds")
	public ApplicationResponse getAllCompaniesId() throws ApplicationException{
		List<Integer> allCompanyIds = dashBoardService.getAllCompanyIds();
		return getApplicationResponse(allCompanyIds);
	}
	
	/**
	 * Gets the paper comapny ids.
	 *
	 * @return the paper comapny ids
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Paper company ids",notes="Get all digital paper company id list",response=ApplicationResponse.class)
	@GetMapping("/get-paper-companyIds")
	public ApplicationResponse getPaperComapnyIds() throws ApplicationException{
		List<Integer> allPaperCompanyIds = dashBoardService.getAllPaperCompanyIds();
		return getApplicationResponse(allPaperCompanyIds);
	}
	
	
	/**
	 * Gets the bar chart data for ins company.
	 *
	 * @param dashBoardInputDto the dash board input dto
	 * @param request the request
	 * @return the bar chart data for ins company
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Insurance company ids",notes="Get stock allocated and certificate issued details of the company",response=ApplicationResponse.class)
	@PostMapping("/inscompany-barchart")
	public ApplicationResponse getBarChartDataForInsCompany(@ApiParam(value="DashboardInput dto payload") @RequestBody(required = false) DashBoardInputDto dashBoardInputDto,HttpServletRequest request) throws ApplicationException {
		List<BarChartDto> barChartDto = dashBoardService.getBarChartDataForInsCompany(dashBoardInputDto,request);
		return getApplicationResponse(barChartDto);
		
	}

	/**
	 * Gets the prediction data.
	 *
	 * @return the prediction data
	 */
	@ApiOperation(value = "Paper generation prediction",notes="Get the prediction details of paper generation for six months",response = ApplicationResponse.class)
	@GetMapping("/get-prediction-data")
	public ApplicationResponse getPredictionData() {
		DashBoardOutputDto outPutDto = dashBoardService.getPredictionData();
		return getApplicationResponse(outPutDto);
	}

	/**
	 * Gets the bar chart for authority.
	 *
	 * @param dashBoardInputDtoForAuthority the dash board input dto for authority
	 * @return the bar chart for authority
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Association bar chart",notes="Get the stock details for authority as bar chart",response = ApplicationResponse.class)
	@PostMapping("/association-barchart")
	public ApplicationResponse getBarChartForAuthority(@ApiParam(value="DashboardInput dto payload")  @RequestBody(required = false) DashBoardInputDto dashBoardInputDtoForAuthority) throws ApplicationException {
		List<AuthorityBarChartDto> authorityBarChartDto = dashBoardService.getBarChartForAuthority(dashBoardInputDtoForAuthority);
		return getApplicationResponse(authorityBarChartDto);
	}

	
	 /**
 	 * Gets the insurance pie chart data.
 	 *
 	 * @param dashboardInputDto the dashboard input dto
 	 * @return the insurance pie chart data
 	 * @throws ApplicationException the application exception
 	 */
	@ApiOperation(value = "Insurance doughnut chart",notes="Get the paper details status count as doughnut chart",response = DoughNutDto.class)
 	@PostMapping("/doughnut-insurance-count")
     public DoughNutDto getInsurancePieChartData( @ApiParam(value="DashboardInput dto payload",required = true)  @RequestBody DashBoardInputDto dashboardInputDto ) throws ApplicationException {   
        DoughNutDto data = dashBoardService.getInsuranceDoughNutChartData(dashboardInputDto);
            return data;
     }
    
    
    /**
     * Gets the association pie chart data.
     *
     * @param dashboardInputDto the dashboard input dto
     * @return the association pie chart data
     * @throws ApplicationException the application exception
     */
	@ApiOperation(value = "Authority doughnut chart",notes="Get the paper details status count as doughnut chart",response = DoughNutDto.class)
    @PostMapping("/doughnut-association-count")
     public DoughNutDto getAssociationPieChartData( @ApiParam(value="DashboardInput dto payload",required = true) @RequestBody DashBoardInputDto dashboardInputDto ) throws ApplicationException {
        DoughNutDto data = dashBoardService.getAssociationDoughNutChartData(dashboardInputDto);
            return data;
        }
    
    /**
     * Gets the class name.
     *
     * @return the class name
     */
    @Override
	protected Class<?> getClassName() {
		return this.getClass();
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {	
	}
	
	
}
