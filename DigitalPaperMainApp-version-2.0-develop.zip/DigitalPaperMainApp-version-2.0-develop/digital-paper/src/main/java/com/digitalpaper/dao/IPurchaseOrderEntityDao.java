package com.digitalpaper.dao;

import java.util.List;
import java.util.Map;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.CompanyAndCountDto;
import com.digitalpaper.transfer.object.dto.NotificationCount;

/**
 * The Interface IPurchaseOrderEntityDao.
 */
public interface IPurchaseOrderEntityDao {

	/**
	 * @returns
	 * @throws ApplicationException
	 */
	Long getTotalCountOfCompanyFromTransaction() throws ApplicationException;

	/**
	 * @param companyIds 
	 * @param companyNameMaping
	 * @param limit
	 * @param skip
	 * @param filterVo 
	 * @return
	 * @throws ApplicationException
	 */
	List<CompanyAndCountDto> getCompanyAndCountList(List<Integer> companyIds, Map<Integer, String> companyNameMaping, Integer skip, int limit,
			List<FilterOrSortingVo> filterVo, Boolean isCount, String searchValue) throws ApplicationException;

	/**
	 * @param compIdNameMap
	 * @return
	 * @throws ApplicationException
	 */
	List<NotificationCount> getNotificationCount(Map<Integer, String> compIdNameMap) throws ApplicationException;

	/**
	 * Gets the all companies count.
	 *
	 * @return the all companies count
	 * @throws ApplicationException the application exception
	 */
	Object[] getAllCompaniesCount() throws ApplicationException;

	/**
	 * Gets the purchase history count.
	 *
	 * @return the purchase history count
	 */
	Long getPurchaseHistoryCount();

}
