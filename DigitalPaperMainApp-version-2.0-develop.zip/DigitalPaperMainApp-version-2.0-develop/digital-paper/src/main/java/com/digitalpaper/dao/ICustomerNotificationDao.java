package com.digitalpaper.dao;

import java.util.List;

import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.entity.CustomerNotification;

/**
 * The Interface ICustomerNotificationDao.
 */
public interface ICustomerNotificationDao {

	/**
	 * Gets the custom notification count.
	 *
	 * @param customerId the customer id
	 * @return the custom notification count
	 */
	List<CustomerNotification> getCustomNotificationCount(Integer customerId);

	/**
	 * Save custom notification.
	 *
	 * @param customerNotification the customer notification
	 * @return the integer
	 * @throws ApplicationException the application exception
	 */
	Integer saveCustomNotification(CustomerNotification customerNotification) throws ApplicationException;

	/**
	 * Gets the notification by identity.
	 *
	 * @param identity the identity
	 * @return the notification by identity
	 */
	CustomerNotification getNotificationByIdentity(String identity);

	/**
	 * Update notification by identity.
	 *
	 * @param customerNotification the customer notification
	 */
	void updateNotificationByIdentity(CustomerNotification customerNotification);

}
