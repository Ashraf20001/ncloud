package com.digitalpaper.service.impl;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.digitalpaper.adapter.service.AdapterService;
import com.digitalpaper.config.DigitalPaperCache;
import com.digitalpaper.config.property.EnvironmentProperties;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.controller.SequenceEnum;
import com.digitalpaper.controller.SequenceGenerator;
import com.digitalpaper.dao.CustomerDao;
import com.digitalpaper.dao.IDigitalPaperDao;
import com.digitalpaper.dao.IPaperDetailsDao;
import com.digitalpaper.dao.IStockDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.exception.core.codes.ErrorId;
import com.digitalpaper.exception.core.codes.ErrorId.ErrorHint;
import com.digitalpaper.file.handler.service.IEmailService;
import com.digitalpaper.restemplate.service.IDigitalPaperSevice;
import com.digitalpaper.service.CustomerService;
import com.digitalpaper.transfer.object.dto.CustomerWithPassword;
import com.digitalpaper.transfer.object.dto.DigitalPaperDto;
import com.digitalpaper.transfer.object.dto.FieldGroup;
import com.digitalpaper.transfer.object.dto.FieldValue;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.entity.Customer;
import com.digitalpaper.transfer.object.entity.FileStorage;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.enums.PaperDetailsStatusEnum;
import com.digitalpaper.transfer.object.enums.PaperStatusEnum;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;
import com.digitalpaper.utils.CommonUtils;
import com.digitalpaper.utils.PaperGenerationUtils;
import com.digitalpaper.utils.core.ApplicationUtils;

/**
 * The Class DigitalPaperSeviceImpl.
 */
@Service
@Transactional
public class DigitalPaperSeviceImpl implements IDigitalPaperSevice {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(DigitalPaperSeviceImpl.class);

	/** The stock dao. */
	@Autowired
	public IStockDao stockDao;
	
	/** The digital paper cache. */
	@Autowired
	private DigitalPaperCache  digitalPaperCache;

	/** The environment properties. */
	@Autowired
    private EnvironmentProperties environmentProperties;

	/** The i paper details dao. */
	@Autowired
	private IPaperDetailsDao iPaperDetailsDao;

	/** The logged in user context holder. */
	@Autowired
	private LoggedInUserContextHolder loggedInUserContextHolder;

	/** The adapter service. */
	@Autowired
	private AdapterService adapterService;

	/** The digital paper dao. */
	@Autowired
	private IDigitalPaperDao digitalPaperDao;

	/** The sequence generator. */
	@Autowired
	private SequenceGenerator sequenceGenerator;

	/** The paper generation utils. */
	@Autowired
	private PaperGenerationUtils paperGenerationUtils;

	/** The common utils. */
	@Autowired
	private CommonUtils commonUtils;

	/** The customer service. */
	@Autowired
	private CustomerService customerService;

	/** The customer dao. */
	@Autowired
	private CustomerDao customerDao;

	/** The email service. */
	@Autowired
	private IEmailService emailService;

	/** The customer service impl. */
	@Autowired
	private CustomerServiceImpl customerServiceImpl;

	/**
	 * Save digital paper.
	 *
	 * @param fieldGroup the field group
	 * @param request the request
	 * @param uploadType the upload type
	 * @param actionType the action type
	 * @return the string
	 * @throws ApplicationException the application exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	public String saveDigitalPaper(FieldGroup fieldGroup, HttpServletRequest request,String uploadType, String actionType)
			throws ApplicationException, IOException {
		String response = null;
		String decodeUploadType = new String(java.util.Base64.getDecoder().decode(actionType));

		UserInfo user = loggedInUserContextHolder.getLoggedInUser();
		Integer companyId = user.getCompanyId();
		try {

			for (FieldGroup field : fieldGroup.getFieldGroups()) {
				if (Boolean.TRUE.equals(ApplicationUtils.isValidList(field.getFieldValues()))) {
					for (FieldValue fieldValue : field.getFieldValues()) {
						if (fieldValue.getField().getFieldName().equals(TableConstants.PD_DIGITAL_PAPER_ID)) {
							continue;
						}
						
						if (fieldValue.getField().getMandatory() != null) {
							String fieldValueStr = fieldValue.getStringValue();
							if (Boolean.FALSE.equals(ApplicationUtils.isValidString(fieldValueStr))
									&& Boolean.TRUE.equals(fieldValue.getField().getMandatory())) {
								throw new ApplicationException(ErrorCodes.MANDATORY_FIELDS);
							}
						}
						if(fieldValue.getField().getFieldType().equals("Dropdown")){
							if(fieldValue.getValue() == null) {
									throw new ApplicationException(ErrorCodes.MANDATORY_FIELDS);
							}else {
								String fieldValueStr = "\"Please Select Value\"";
								if(fieldValue.getValue().toString().equalsIgnoreCase(fieldValueStr)) {
									throw new ApplicationException(ErrorCodes.MANDATORY_FIELDS);
									}
							}
							}
						
						
						// Make Model Usage Validation
						
						if(fieldValue.getField().getFieldName().equalsIgnoreCase(TableConstants.PD_MAKE)) {
							
							List<String> makes = DigitalPaperCache.getMakes();
							boolean noneMatchCheckOfMake = makes.stream().noneMatch(make->make.equalsIgnoreCase(fieldValue.getStringValue()));
							if(noneMatchCheckOfMake) {
								throwInvalidMakeModelUsageException(fieldValue.getField().getAliasName());
							}
						}
						
						
						if(fieldValue.getField().getFieldName().equalsIgnoreCase(TableConstants.PD_MODEL)) {
							List<String> models = DigitalPaperCache.getModels();
							boolean noneMatchCheckOfModel = models.stream().noneMatch(model->model.equalsIgnoreCase(fieldValue.getStringValue()));
							if(noneMatchCheckOfModel) {
								throwInvalidMakeModelUsageException(fieldValue.getField().getAliasName());
							}
							
						}
						
						
						if(fieldValue.getField().getFieldName().equalsIgnoreCase(TableConstants.PD_USAGE)) {
							
							List<String> usageList = DigitalPaperCache.getUsage();
							boolean noneMatchCheckOfUsage = usageList.stream().noneMatch(usage->usage.equalsIgnoreCase(fieldValue.getStringValue()));
							if(noneMatchCheckOfUsage) {
								throwInvalidMakeModelUsageException(fieldValue.getField().getAliasName());
							}
						}
						
						//Min length , Max length and Field value pattern validation
						
						if (fieldValue.getField().getMinlength() > fieldValue.getStringValue().trim().length()) {
							throwMinLengthValidationException(fieldValue);
						}
						if (fieldValue.getField().getMaxlength() < fieldValue.getStringValue().trim().length()) {
							throwMaxLengthValidationException(fieldValue);
						}
						if(!TableConstants.VDMAKE_AND_VDMODEL.contains(fieldValue.getField().getFieldName())) {
						if (ApplicationUtils.isValidString(fieldValue.getField().getRegex())) {
							String regexPattern = fieldValue.getField().getRegex();
							Pattern pattern = Pattern.compile(regexPattern);
							Matcher matcher = pattern.matcher(fieldValue.getStringValue());
							if (Boolean.FALSE.equals(matcher.matches())) {
								throwInvalidFormatException(fieldValue);
							}
						}
					}
					}
				}
			}

			DigitalPaperDto digitalPaperDto = (DigitalPaperDto) adapterService.buildFieldGroup(fieldGroup);
			
			if (ChronoUnit.DAYS.between(digitalPaperDto.getPdEffectiveFrom(),digitalPaperDto.getPdExpireDate())<0) {
				throw new ApplicationException(ErrorCodes.EXP_DATE_GRTR_EFFECTIVE_DATE);
			}

			if (Boolean.TRUE.equals(ApplicationUtils.isValidateObject(digitalPaperDto))) {
				PaperDetails exisitingPaperWithPolicyNumber = digitalPaperDao.checkForDuplicatePolicyNumber(
						digitalPaperDto.getPdPolicyNumber().trim() ,
						PaperStatusEnum.getPaperStatusIdByName(ApplicationConstants.RLE_ACTIVE).getId());
				if (Boolean.TRUE.equals(ApplicationUtils.isValidateObject(exisitingPaperWithPolicyNumber)) && !decodeUploadType.equals(ApplicationConstants.FLEET)) {
					if (isDateOverlapped(exisitingPaperWithPolicyNumber, digitalPaperDto)) {
						throwInvalidPolicyNumberException(exisitingPaperWithPolicyNumber);
					}
				}

				List<PaperDetails> exisitingPaperListWithRegNoAndChassisNo = digitalPaperDao
						.checkDuplicateRegistrationNumberOrChassisNumber(digitalPaperDto.getVdRegistrationNumber(),
								digitalPaperDto.getVdChassis(),
								PaperStatusEnum.getPaperStatusIdByName(ApplicationConstants.RLE_ACTIVE).getId());
				
				if(Boolean.TRUE.equals(ApplicationUtils.isValidList(exisitingPaperListWithRegNoAndChassisNo))) {
					PaperDetails existingPaperWithRegAndChassisNo = exisitingPaperListWithRegNoAndChassisNo.get(ApplicationConstants.ZERO);
					
					if(existingPaperWithRegAndChassisNo.getVdChassis().equalsIgnoreCase(digitalPaperDto.getVdChassis().trim())) {
						throwDuplicateChassisNumberException(existingPaperWithRegAndChassisNo);
					}
					if(existingPaperWithRegAndChassisNo.getVdChassis().equalsIgnoreCase(digitalPaperDto.getVdChassis().trim())
							&& isDateOverlapped(existingPaperWithRegAndChassisNo, digitalPaperDto)) {
						throwDuplicateChassisNumberException(existingPaperWithRegAndChassisNo);
					}
						
					if(existingPaperWithRegAndChassisNo.getVdRegistrationNumber().equalsIgnoreCase(digitalPaperDto.getVdRegistrationNumber().trim())) {
						throwInvalidRegistrationException(existingPaperWithRegAndChassisNo);
					}
					
					if(existingPaperWithRegAndChassisNo.getVdRegistrationNumber().equalsIgnoreCase(digitalPaperDto.getVdRegistrationNumber().trim())
					 && isDateOverlapped(existingPaperWithRegAndChassisNo, digitalPaperDto)) {
						throwInvalidRegistrationException(existingPaperWithRegAndChassisNo);
					}
					
				}


				List<PaperDetails> digitalPaperDataListByEmailId = digitalPaperDao.getDigitalPaperDataListByEmailId(digitalPaperDto.getPdEmailId(),companyId);
				if(ApplicationUtils.isValidList(digitalPaperDataListByEmailId)) {
					throw new ApplicationException(ErrorCodes.EMAIL_EXIST);
				}
				PaperDetails paperDetailsEntity = convertDtoToEntity(digitalPaperDto,request);
				if (ApplicationUtils.isValidateObject(paperDetailsEntity)) {
					Boolean isStockCountUpdated = false;

					UserInfo userInfo = getUserInfo();
					Integer associationId = userInfo.getAssociationId();

					String allocationType = commonUtils.getSystemPropertyValueByPropertyId(request,
							associationId, ApplicationConstants.ALLOCATION_TYPE);

					isStockCountUpdated = commonUtils.updateStockCount(isStockCountUpdated, userInfo, associationId,
							allocationType);

					if(Boolean.TRUE.equals(isStockCountUpdated) ) {
						Boolean isPaperGenerated =false;

						Customer existingCustomerByEmailId = customerDao.getCustomerByEmailId(paperDetailsEntity.getPdEmailId());
						if(ApplicationUtils.isValidateObject(existingCustomerByEmailId)) {
							paperDetailsEntity.setCustomer(existingCustomerByEmailId);
							digitalPaperDao.saveDigitalPaperDetails(paperDetailsEntity);
							isPaperGenerated = paperGenerationUtils.generateDigitalPaper(paperDetailsEntity, user);
							emailService.setEmailForExistingCustomer(paperDetailsEntity);
						}

						else {
							CustomerWithPassword saveCustomer = customerService.saveCustomer(paperDetailsEntity);
							paperDetailsEntity.setCustomer(saveCustomer.getCustomer());
							digitalPaperDao.saveDigitalPaperDetails(paperDetailsEntity);
							isPaperGenerated = paperGenerationUtils.generateDigitalPaper(paperDetailsEntity, user);
							customerServiceImpl.emailSendPart(user.getCompanyName() ,paperDetailsEntity  ,paperDetailsEntity.getPaperId(),saveCustomer.getAutoPassword());
						}


						if (Boolean.TRUE.equals(isPaperGenerated)) {
							response = ApplicationConstants.SUCCESS;
						}
					}
					 else {
						throw new ApplicationException(ErrorCodes.INSUFFICIENT_STOCK);
					}
				}
			} else {
				response = null;
				throw new ApplicationException(ErrorCodes.INVALID_ACTION);
			}
		} catch (ApplicationException e) {
			LOGGER.error("Exception is:::" + ExceptionUtils.getStackTrace(e));
			e.printStackTrace();
			throw new ApplicationException(e.getLocalizedMessage());
		}
		return response;
	}


	/**
	 * @param exisitingPaperWithRegNoAndChassisNo
	 * @throws ApplicationException
	 */
	private void throwInvalidRegistrationException(PaperDetails exisitingPaperWithRegNoAndChassisNo)
			throws ApplicationException {
		List<ErrorId.ErrorHint> errorHintsList = new ArrayList<ErrorId.ErrorHint>();
		errorHintsList.add(new ErrorHint(ApplicationConstants.DIGITAL_PAPER_HINT,
				exisitingPaperWithRegNoAndChassisNo.getPdDigitalPaperId()));
		String errorMessage = ErrorCodes.INVALID_REGISTRATION_NUMBER.getErrorMessage().replace(
				ApplicationConstants.DIGITAL_PAPER_HINT, exisitingPaperWithRegNoAndChassisNo.getPdDigitalPaperId());
		throw new ApplicationException(
				new ErrorId(ErrorCodes.INVALID_REGISTRATION_NUMBER.getErrorCode(), errorMessage, errorHintsList));

	}


	/**
	 * @param exisitingPaperWithChassisNumber
	 * @throws ApplicationException
	 */
	private void throwDuplicateChassisNumberException(PaperDetails exisitingPaperWithChassisNumber)
			throws ApplicationException {
		List<ErrorId.ErrorHint> errorHintsList = new ArrayList<ErrorId.ErrorHint>();
		errorHintsList.add(new ErrorHint(ApplicationConstants.DIGITAL_PAPER_HINT,
				exisitingPaperWithChassisNumber.getPdDigitalPaperId()));
		String errorMessage = ErrorCodes.INVALID_CHASSIS_NUMBER.getErrorMessage()
				.replace(ApplicationConstants.DIGITAL_PAPER_HINT, exisitingPaperWithChassisNumber.getPdDigitalPaperId());
		throw new ApplicationException(
				new ErrorId(ErrorCodes.INVALID_CHASSIS_NUMBER.getErrorCode(), errorMessage, errorHintsList));
	}


	/**
	 * @param exisitingPaperWithPolicyNumber
	 * @throws ApplicationException
	 */
	private void throwInvalidPolicyNumberException(PaperDetails exisitingPaperWithPolicyNumber)
			throws ApplicationException {
		List<ErrorId.ErrorHint> errorHintsList = new ArrayList<ErrorId.ErrorHint>();
		errorHintsList.add(new ErrorHint(ApplicationConstants.DIGITAL_PAPER_HINT,
				exisitingPaperWithPolicyNumber.getPdDigitalPaperId()));
		String errorMessage = ErrorCodes.INVALID_POLCIY_NUMBER.getErrorMessage()
				.replace(ApplicationConstants.DIGITAL_PAPER_HINT, exisitingPaperWithPolicyNumber.getPdDigitalPaperId());
		throw new ApplicationException(
				new ErrorId(ErrorCodes.INVALID_POLCIY_NUMBER.getErrorCode(), errorMessage, errorHintsList));
	}


	/**
	 * @param fieldValue
	 * @throws ApplicationException
	 */
	private void throwInvalidFormatException(FieldValue fieldValue) throws ApplicationException {
		List<ErrorId.ErrorHint> errorHintsList = new ArrayList<ErrorId.ErrorHint>();
		errorHintsList.add(new ErrorHint(ApplicationConstants.FIELD_FORMAT_HINT, fieldValue.getField().getAliasName()));
		String errorMessage = ErrorCodes.INVALID_FORMAT.getErrorMessage()
				.replace(ApplicationConstants.FIELD_FORMAT_HINT, fieldValue.getField().getAliasName());
		throw new ApplicationException(
				new ErrorId(ErrorCodes.INVALID_FORMAT.getErrorCode(), errorMessage, errorHintsList));

	}


	/**
	 * @param fieldValue
	 * @throws ApplicationException
	 */
	private void throwMinLengthValidationException(FieldValue fieldValue) throws ApplicationException {
		List<ErrorId.ErrorHint> errorHintsList = new ArrayList<ErrorId.ErrorHint>();
		errorHintsList.add(
				new ErrorHint(ApplicationConstants.MIN_LENGTH_HINT, fieldValue.getField().getMinlength().toString()));
		errorHintsList.add(new ErrorHint(ApplicationConstants.ALIAS_NAME_HINT, fieldValue.getField().getAliasName()));
		String errorMessage = ErrorCodes.MIN_LENGTH.getErrorMessage()
				.replace(ApplicationConstants.MIN_LENGTH_HINT, fieldValue.getField().getMinlength().toString())
				.replace(ApplicationConstants.ALIAS_NAME_HINT, fieldValue.getField().getAliasName());
		throw new ApplicationException(new ErrorId(ErrorCodes.MIN_LENGTH.getErrorCode(), errorMessage, errorHintsList));
	}

	
	/**
	 * @param fieldValue
	 * @throws ApplicationException
	 */
	private void throwMaxLengthValidationException(FieldValue fieldValue) throws ApplicationException {
		List<ErrorId.ErrorHint> errorHintsList = new ArrayList<ErrorId.ErrorHint>();
		errorHintsList.add(new ErrorHint(ApplicationConstants.FIELD_NAME_HINT, fieldValue.getField().getAliasName()));
		String errorMessage = ErrorCodes.MAX_LENGTH.getErrorMessage().replace(ApplicationConstants.FIELD_NAME_HINT,
				fieldValue.getField().getAliasName());
		throw new ApplicationException(new ErrorId(ErrorCodes.MAX_LENGTH.getErrorCode(), errorMessage, errorHintsList));
	}


	/**
	 * Convert dto to entity.
	 *
	 * @param digitalPaperDto the digital paper dto
	 * @param request the request
	 * @return the paper details
	 * @throws ApplicationException the application exception
	 */
	private PaperDetails convertDtoToEntity(DigitalPaperDto digitalPaperDto, HttpServletRequest request) throws ApplicationException {

		UserInfo userDetails = loggedInUserContextHolder.getLoggedInUser();
		Integer companyId = userDetails.getCompanyId();
		Integer userId = userDetails.getId();

		PaperDetails data = new PaperDetails();
		data.setCompanyId(companyId);
		data.setCreatedBy(userId);
		data.setCreatedDate(LocalDateTime.now());
		data.setModifiedBy(userId);
		data.setModifiedDate(LocalDateTime.now());

		HashMap<String, String> systemValue = digitalPaperCache.getSystemPropertyVAlue();
		if(ApplicationUtils.isValidateObject(systemValue)) {
			SequenceEnum.DIGITAL_PAPER_ID.setLength(systemValue.get(ApplicationConstants.PREFIX).length() + systemValue.get(ApplicationConstants.SUFFIX).length());	
			SequenceEnum.DIGITAL_PAPER_ID.setPrefix(systemValue.get(ApplicationConstants.PREFIX));			
			String digitalPaperId = sequenceGenerator.generateSequence(SequenceEnum.DIGITAL_PAPER_ID);
			data.setPdDigitalPaperId(digitalPaperId); // sequence generator
		}
		LocalDateTime effectiveFromDateTime=digitalPaperDto.getPdEffectiveFrom();
		LocalDateTime startOfTheDay = effectiveFromDateTime.withHour(0).withMinute(0).withSecond(0);
		data.setPdEffectiveFrom(startOfTheDay);
		
		data.setPdEmailId(digitalPaperDto.getPdEmailId());
		
		LocalDateTime effectiveDateTime=digitalPaperDto.getPdExpireDate();
		LocalDateTime endOfTheDay = effectiveDateTime.withHour(23).withMinute(59).withSecond(56);
		data.setPdExpireDate(endOfTheDay);
		
		data.setPdInsuredName(digitalPaperDto.getPdInsuredName());
		data.setPdPhoneNumber(digitalPaperDto.getPdPhoneNumber());
		data.setPdPolicyNumber(digitalPaperDto.getPdPolicyNumber());
		data.setVdChassis(digitalPaperDto.getVdChassis());
		data.setVdLicensedToCarry(digitalPaperDto.getVdLicensedToCarry());
		data.setVdMake(digitalPaperDto.getVdMake());
		data.setVdModel(digitalPaperDto.getVdModel());
		data.setVdRegistrationNumber(digitalPaperDto.getVdRegistrationNumber());
		data.setVdUsage(digitalPaperDto.getVdUsage());
		data.setStatus(PaperStatusEnum.getPaperStatusIdByName("ACTIVE").getId());
		data.setAllocationUserTypeId(userDetails.getAllocationUserType());
		return data;
	}

	/**
	 * @param exisitingPaper
	 * @param digitalPaperDto
	 * @return
	 */
	public boolean isDateOverlapped(PaperDetails exisitingPaper, DigitalPaperDto digitalPaperDto) {

		LocalDateTime commencingDate = digitalPaperDto.getPdEffectiveFrom();
		LocalDateTime existingCommencingDate = exisitingPaper.getPdEffectiveFrom();
		LocalDateTime expiryDate = digitalPaperDto.getPdExpireDate();
		LocalDateTime existingExpiryDate = exisitingPaper.getPdExpireDate();
		if (commencingDate.compareTo(existingCommencingDate) >= 0 // dates between existing dates
				&& expiryDate.compareTo(existingExpiryDate) <= 0
				|| commencingDate.compareTo(existingCommencingDate) <= 0 // past dates between existing dates
						&& expiryDate.compareTo(existingExpiryDate) <= 0
						&& expiryDate.compareTo(existingCommencingDate) >= 0
				|| commencingDate.compareTo(existingCommencingDate) >= 0 // future dates between existing dates
						&& expiryDate.compareTo(existingExpiryDate) >= 0
						&& commencingDate.compareTo(existingExpiryDate) <= 0
				|| commencingDate.compareTo(existingCommencingDate) <= 0 // existing dates between past and future date
						&& expiryDate.compareTo(existingExpiryDate) >= 0
				|| commencingDate.compareTo(existingCommencingDate) <= 0) {
			return true;
		}
		return false;

	}

	/**
	 * @param object
	 * @param variableName
	 * @return
	 */
	public String invokeGetter(Object object, String variableName) {
		String extractedValue = null;
		try {
			PropertyDescriptor pd = new PropertyDescriptor(variableName, object.getClass());
			Method getter = pd.getReadMethod();
			Object value = getter.invoke(object);
			if (value != null) {
				extractedValue = value.toString();
			}
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException
				| IntrospectionException e) {
			e.printStackTrace();
		}
		return extractedValue;
	}

	/**
	 * @param registerNo
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public PaperDetailsDto getpaperDetails(String registerNo) throws ApplicationException {
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		PaperDetailsDto paperDetailsDto = new PaperDetailsDto();
		
		
		if (ApplicationUtils.isValidString(registerNo)) {
			PaperDetails digitalpaper = digitalPaperDao.getPaperDetails(registerNo);
			if (!ApplicationUtils.isValidateObject(digitalpaper)) {
				throw new ApplicationException(ErrorCodes.UNKNOWN_PAPER);
			}
			convertPaperDetailsEntityToDto(paperDetailsDto, digitalpaper,loggedInUser);
		}
		return paperDetailsDto;
	}


	/**
	 * @param paperDetailsDto
	 * @param digitalpaper
	 */
	private void convertPaperDetailsEntityToDto(PaperDetailsDto paperDetailsDto, PaperDetails digitalpaper,UserInfo loggedInUser) {
		paperDetailsDto.setPdDigiltaPaperId(digitalpaper.getPdDigitalPaperId());
		paperDetailsDto.setPdInsuredName(digitalpaper.getPdInsuredName());
		paperDetailsDto.setPdPolicyNumber(digitalpaper.getPdPolicyNumber());
		paperDetailsDto.setPdEffectiveFrom(digitalpaper.getPdEffectiveFrom().toString());
		paperDetailsDto.setPdExpireDate(digitalpaper.getPdExpireDate().toString());
		paperDetailsDto.setPdPhoneNumber(digitalpaper.getPdPhoneNumber());
		paperDetailsDto.setPdEmailId(digitalpaper.getPdEmailId());
		paperDetailsDto.setVdRegistrationNumber(digitalpaper.getVdRegistrationNumber());
		paperDetailsDto.setVdChassis(digitalpaper.getVdChassis());
		paperDetailsDto.setVdLicensedToCarry(digitalpaper.getVdLicensedToCarry());
		paperDetailsDto.setVdMake(digitalpaper.getVdMake());
		paperDetailsDto.setVdModel(digitalpaper.getVdModel());
		paperDetailsDto.setVdUsage(digitalpaper.getVdUsage());
		paperDetailsDto.setStatus(PaperDetailsStatusEnum.getIdByName(digitalpaper.getStatus()));
		paperDetailsDto.setInsurer(loggedInUser.getCompanyName());
		paperDetailsDto.setCreatedDate(digitalpaper.getCreatedDate().toString());
		paperDetailsDto.setIdentity(digitalpaper.getIdentity());
		paperDetailsDto.setDigitalPaperId(digitalpaper.getPaperId());
		FileStorage file = iPaperDetailsDao.getPaperImageById(digitalpaper.getPaperId(),
				ApplicationConstants.UPD_TYPE, ApplicationConstants.RP_TYPE);
		if (ApplicationUtils.isValidateObject(file)) {
			String url = environmentProperties.getDigitalPaperFilePath() + file.getUrl();
			paperDetailsDto.setFileURL(url);
		}
	}

	/**
	 * Convert entity to dto.
	 *
	 * @param data the data
	 * @return the paper details dto
	 */
	private PaperDetailsDto convertEntityToDto(PaperDetails data) {

		PaperDetailsDto dto =  new PaperDetailsDto();
		dto.setPdDigiltaPaperId(data.getPdDigitalPaperId());
		dto.setPdEffectiveFrom(data.getPdEffectiveFrom().toString());
		dto.setPdEmailId(data.getPdEmailId());
		dto.setPdExpireDate(data.getPdExpireDate().toString());
		dto.setPdInsuredName(data.getPdInsuredName());
		dto.setPdPhoneNumber(data.getPdPhoneNumber());
		dto.setPdPolicyNumber(data.getPdPolicyNumber());
		dto.setVdChassis(data.getVdChassis());
		dto.setVdLicensedToCarry(data.getVdLicensedToCarry());
		dto.setVdMake(data.getVdMake());
		dto.setVdModel(data.getVdModel());
		dto.setVdRegistrationNumber(data.getVdRegistrationNumber());
		dto.setVdUsage(data.getVdUsage());
		dto.setStatus(String.valueOf(data.getStatus()));
		dto.setIdentity(data.getIdentity());

		FileStorage paperImageById = iPaperDetailsDao.getPaperImageById(data.getPaperId(), ApplicationConstants.UPD_TYPE, ApplicationConstants.RP_TYPE);

		if (ApplicationUtils.isValidateObject(paperImageById)) {
			String url = environmentProperties.getDigitalPaperFilePath() + paperImageById.getUrl();
			dto.setFileURL(url);
		}

		return dto;
	}
	/**
	 * @return
	 * @throws ApplicationException
	 */
	private UserInfo getUserInfo() throws ApplicationException {
		UserInfo userInfo = loggedInUserContextHolder.getLoggedInUser();
		if (!ApplicationUtils.isValidateObject(userInfo)) {
			throw new ApplicationException(ErrorCodes.INVALID_USER);
		}
		return userInfo;
	}

	/**
	 * Gets the list of login digital paper details.
	 *
	 * @return the list of login digital paper details
	 * @throws ApplicationException the application exception
	 */
	@Override
	public List<PaperDetailsDto> getListOfLoginDigitalPaperDetails() throws ApplicationException {

		UserInfo userDetails = loggedInUserContextHolder.getLoggedInUser();
		Integer customerId= userDetails.getId();



		List<PaperDetailsDto> digitalpaperDto = new ArrayList<PaperDetailsDto>();
		List<PaperDetails> digitalpaper = new ArrayList<PaperDetails>();

			digitalpaper = digitalPaperDao.getDigitalPaperDetailsByCustomer(customerId);
			if(ApplicationUtils.isValidateObject(digitalpaper)) {

				for (PaperDetails data : digitalpaper) {
					digitalpaperDto.add(convertEntityToDto(data));
				}
			}

		return digitalpaperDto;

	}

	/**
	 * Send data to email.
	 *
	 * @param paperIdentity the paper identity
	 * @param dpPolicyNumber the dp policy number
	 * @return the string
	 * @throws ApplicationException the application exception
	 */
	@Override
	public String sendDataToEmail(String paperIdentity, String dpPolicyNumber) throws ApplicationException {
		PaperDetails data = new PaperDetails();
		data = digitalPaperDao.getDigitalPaperData(paperIdentity, dpPolicyNumber);
		File img = null;

		if (ApplicationUtils.isValidateObject(data)) {

			FileStorage file = iPaperDetailsDao.getPaperImageById(data.getPaperId(), ApplicationConstants.UPD_TYPE,
					ApplicationConstants.RP_TYPE);
			if (ApplicationUtils.isValidateObject(file)) {

				String folderPath = environmentProperties.getFileUploadPath() + "/OG_IMAGE/";
				String fileName = file.getUrl();
				// Check if the file exists
				Path filePath = Paths.get(folderPath, fileName);
				boolean fileExists = Files.exists(filePath);

				if (!fileExists) {
					throw new ApplicationException(ErrorCodes.PAPER_NOT_FOUND);
				}

				String url = environmentProperties.getFileUploadPath() + "/OG_IMAGE/" + fileName;
				img = new File(url);

			} else {
				throw new ApplicationException(ErrorCodes.PAPER_NOT_FOUND);
			}

			emailService.sendEmailInCustomerPortal(data, img);
			return ApplicationConstants.MAIL_SENT_SUCCESS;
		}
		return ApplicationConstants.MAIL_SENT_FAILED;
	}

	/**
	 * Convert string to local date time.
	 *
	 * @param dateTimeString the date time string
	 * @return the local date time
	 */
	public LocalDateTime convertStringToLocalDateTime(String dateTimeString) {
		DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
        LocalDateTime dateTime = LocalDateTime.parse(dateTimeString, formatter);
        return dateTime;
	}
	
	/**
	 * Throw invalid make model usage exception.
	 *
	 * @param aliasName the alias name
	 * @throws ApplicationException the application exception
	 */
	private void throwInvalidMakeModelUsageException(String aliasName) throws ApplicationException {
		String errorMessage = ErrorCodes.INVALID_FORMAT.getErrorMessage().replace(
				ApplicationConstants.FIELD_FORMAT_HINT, aliasName);
		throw new ApplicationException(
				new ErrorId(ErrorCodes.INVALID_FORMAT.getErrorCode(), errorMessage));
		
	}

}
