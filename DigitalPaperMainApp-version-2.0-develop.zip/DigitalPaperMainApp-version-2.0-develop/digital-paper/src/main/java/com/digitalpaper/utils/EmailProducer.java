package com.digitalpaper.utils;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import com.digitalpaper.transfer.object.dto.MailRequestDto;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;

/**
 * The Class EmailProducer.
 */
@Component
@RequiredArgsConstructor
public class EmailProducer {

	/** The Constant TOPIC. */
	private static final String TOPIC = "email-topic";
	
	/** The object mapper. */
	private final ObjectMapper objectMapper;

    /** The kafka template. */
    private final KafkaTemplate<String, String> kafkaTemplate;
	
	/**
	 * Send email.
	 *
	 * @param emailMessage the email message
	 * @throws JsonProcessingException the json processing exception
	 */
	public void sendEmail(MailRequestDto emailMessage) throws JsonProcessingException {
		
		String stringObjectOfEmailMessage = objectMapper.writeValueAsString(emailMessage);
		kafkaTemplate.send(TOPIC, stringObjectOfEmailMessage);
    }
	
}
