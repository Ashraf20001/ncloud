package com.digitalpaper.service.usermanagementservice;

import javax.servlet.http.HttpServletRequest;

import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.UserManagementSaveOrUpdateDto;

/**
 * The Interface UserManagementService.
 */
public interface UserManagementService {

	/**
	 * Gets the user page info.
	 *
	 * @param pageIdentity the page identity
	 * @param platformId the platform id
	 * @param request the request
	 * @return the user page info
	 * @throws ApplicationException the application exception
	 */
	public ApplicationResponse getUserPageInfo(String pageIdentity, String platformId, HttpServletRequest request)
			throws ApplicationException;

	/**
	 * Gets the role details for card view.
	 *
	 * @param min the min
	 * @param max the max
	 * @param platformIdentity the platform identity
	 * @param request the request
	 * @return the role details for card view
	 */
	public ApplicationResponse getRoleDetailsForCardView(Integer min, Integer max, String platformIdentity,
			HttpServletRequest request);

	/**
	 * Gets the user details for list view.
	 *
	 * @param min the min
	 * @param max the max
	 * @param request the request
	 * @return the user details for list view
	 */
	public ApplicationResponse getUserDetailsForListView(Integer min, Integer max, HttpServletRequest request);

	/**
	 * Adds the edit user.
	 *
	 * @param userManagementListDto the user management list dto
	 * @param platformIdentity the platform identity
	 * @param request the request
	 * @return the application response
	 */
	public ApplicationResponse addEditUser(UserManagementSaveOrUpdateDto userManagementListDto, String platformIdentity,
			HttpServletRequest request);
}
