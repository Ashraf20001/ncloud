package com.digitalpaper.file.handler.service.impl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;

import com.digitalpaper.file.handler.service.FileHandlerService;

/**
 * The Class FileHandlerServiceImpl.
 */
@Service
public class FileHandlerServiceImpl implements FileHandlerService{
	
	/** The file path. */
	@Value("${dpmainapp.file-upload-path}")
	private String filePath;
	
	/** The Constant FILE_PATH. */
	public static final String FILE_PATH = "Files-Upload/OG_IMAGE/";

	/**
	 * Gets the file data by URL.
	 *
	 * @param fileName the file name
	 * @return the file data by URL
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	public Resource getFileDataByURL(String fileName) throws IOException {
		Resource fileAsResource = null;
			 fileAsResource = getFileAsResource(fileName);
		return fileAsResource;
	}
	
	
	/**
	 * Gets the file as resource.
	 *
	 * @param fileCode the file code
	 * @return the file as resource
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public Resource getFileAsResource(String fileCode) throws IOException {
		Path dirPath = Paths.get(filePath+"/OG_IMAGE/");
		Path foundFile = Files.list(dirPath).filter(file->file.getFileName().toString().startsWith(fileCode))
							.findFirst().orElse(null);
		if (foundFile != null) {
			return new UrlResource(foundFile.toUri());
		}
		return null;
	}

}
