package com.digitalpaper.dao;

import java.util.List;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.entity.BulkImportErrorTable;
import com.digitalpaper.transfer.object.entity.FileStorage;
import com.digitalpaper.transfer.object.entity.PaperDetails;

/**
 * The Interface IPaperDetailsDao.
 */
public interface IPaperDetailsDao {

	/**
	 * @param filterVo 
	 * @param parseBoolean 
	 * @return
	 * @throws ApplicationException 
	 */
	Long getPaperDetailsCount(List<FilterOrSortingVo> filterVo, Integer companyId, Boolean parseBoolean, String searchValue) throws ApplicationException;

	/**
	 * @param skip
	 * @param limit
	 * @param filterVo
	 * @param companyId 
	 * @param removableDigitalPaperIds 
	 * @returns
	 * @throws ApplicationException
	 */
	List<PaperDetails> getPaperDetailsList(Integer skip, Integer limit, String searchValue, List<FilterOrSortingVo> filterVo, Integer companyId,Boolean view, List<String> removableDigitalPaperIds) throws ApplicationException;
	
	/**
	 * 
	 * @param paperIdentity
	 * @return
	 */
	PaperDetails getPaperDetailsByPaperId(String paperIdentity);

	/**
	 * 
	 * @param id
	 * @return
	 */
	List<BulkImportErrorTable> getErrorTableByScratchId(Integer id);

	/**
	 * @param identity
	 * @return
	 * @throws ApplicationException
	 */
	PaperDetails getRevokeStatusData(String identity) throws ApplicationException;

	/**
	 * @param status
	 * @throws ApplicationException
	 */
	void updateStatusDao(PaperDetails status) throws ApplicationException;

	/**
	 * Gets the paper by identity.
	 *
	 * @param identity the identity
	 * @return the paper by identity
	 */
	PaperDetails getPaperByIdentity(String identity);
	
	/**
	 * Save paper image.
	 *
	 * @param storage the storage
	 * @return the integer
	 * @throws ApplicationException the application exception
	 */
	public Integer savePaperImage(FileStorage storage) throws ApplicationException;

	/**
	 * Gets the paper image by id.
	 *
	 * @param paperId the paper id
	 * @param uploadType the upload type
	 * @param rpType the rp type
	 * @return the paper image by id
	 */
	FileStorage getPaperImageById(Integer paperId, String uploadType, String rpType);
	/**
	 * 
	 * @param importTable
	 */
	void deleteErrorData(List<BulkImportErrorTable> importTable);

	/**
	 * @param entityColumnList
	 * @param idList 
	 * @param filterOrSortingVo
	 * @return
	 * @throws ApplicationException
	 */
	List<Object[]> getPaperDetailsDataForDownload(List<String> entityColumnList,Integer companyId,  List<FilterOrSortingVo> filterVo,
			List<Integer> idList, String searchValue) throws ApplicationException;
	
	/**
	 * Update storage data.
	 *
	 * @param fileStorage the file storage
	 * @throws ApplicationException the application exception
	 */
	void updateStorageData(FileStorage fileStorage) throws ApplicationException;

	/**
	 * Save storage data.
	 *
	 * @param storageData the storage data
	 * @throws ApplicationException the application exception
	 */
	void saveStorageData(FileStorage storageData) throws ApplicationException;

	/**
	 * Gets the paper details customer count.
	 *
	 * @param filter the filter
	 * @param companyId the company id
	 * @param searchvalue the searchvalue
	 * @return the paper details customer count
	 * @throws ApplicationException the application exception
	 */
	Long getPaperDetailsCustomerCount(List<FilterOrSortingVo> filter,Integer companyId, String searchvalue) throws ApplicationException;

	/**
	 * Gets the paper details customer list.
	 *
	 * @param min the min
	 * @param max the max
	 * @param filter the filter
	 * @param companyId the company id
	 * @param searchValue the search value
	 * @return the paper details customer list
	 * @throws ApplicationException the application exception
	 */
	List<Object[]> getPaperDetailsCustomerList(Integer min, Integer max, List<FilterOrSortingVo> filter,
			Integer companyId, String searchValue) throws ApplicationException;

	/**
	 * Gets the paper details list for all papers download.
	 *
	 * @param searchValue the search value
	 * @param filterOrSortingVos the filter or sorting vos
	 * @param removableDigitalPaperIds the removable digital paper ids
	 * @param view the view
	 * @param companyId the company id
	 * @return the paper details list for all papers download
	 * @throws ApplicationException the application exception
	 */
	List<PaperDetails> getPaperDetailsListForAllPapersDownload(String searchValue,
			List<FilterOrSortingVo> filterOrSortingVos,List<String> removableDigitalPaperIds
			,Boolean view,Integer companyId) throws ApplicationException;
	
	


}
