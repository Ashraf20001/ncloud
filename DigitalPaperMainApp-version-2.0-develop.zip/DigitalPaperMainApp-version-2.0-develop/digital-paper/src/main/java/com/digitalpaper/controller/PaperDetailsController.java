 package com.digitalpaper.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.digitalpaper.aop.annotation.Auditable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitalpaper.config.base.controller.BaseController;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.file.handler.service.FileHandlerService;
import com.digitalpaper.service.IPaperDetailsService;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.AllSearchFilterDto;
import com.digitalpaper.transfer.object.dto.DownloadListVo;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;
import com.digitalpaper.utils.core.ApplicationUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class PaperDetailsController.
 */
@RestController
@Auditable
public class PaperDetailsController extends BaseController {

	/** IPaperDetailsService. */
	@Autowired
	private IPaperDetailsService iPaperDetailsService;
	
	/** FileHandlerService. */
	@Autowired
	private FileHandlerService fileHandler;

	/**
	 * Gets the paper details count.
	 *
	 * @param view the view
	 * @param searchValue the search value
	 * @param filterVo the filter vo
	 * @return the paper details count
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Paper details count",notes = "Get paper details count",response = Long.class)
	@PostMapping("/get-paperdetails-count")
	public Long getPaperDetailsCount(@ApiParam(value="is View paper details page",required = true) @RequestParam(name="view")String view, @ApiParam(value="Search data",required = true) @RequestParam(name="searchValue") String searchValue,
			@ApiParam(value="Filter vo payload")	@RequestBody(required = false) List<FilterOrSortingVo> filterVo) throws ApplicationException {
		return iPaperDetailsService.getPaperDeatilsCount(filterVo,view,searchValue);
	}

	/**
	 * Gets the paper details list.
	 *
	 * @param skip the skip
	 * @param limit the limit
	 * @param view the view
	 * @param searchValue the search value
	 * @param filterVo the filter vo
	 * @return the paper details list
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Paper details list",notes="Get list of paper details",response = List.class)
	@PostMapping("/get-paperdetails-list")
	public List<PaperDetailsDto> getPaperDetailsList(@ApiParam(value="Skip data count",required = true) @RequestParam(name = "skip") Integer skip,
			@ApiParam(value="Limit data count",required = true)  @RequestParam(name = "limit") Integer limit,
			@ApiParam(value="is View Paper detail page",required = true)  @RequestParam(name="view") String view,
			@ApiParam(value="Search data",required = true)  @RequestParam(name = "searchValue") String searchValue,
			@ApiParam(value="Filter data payload")   @RequestBody(required = false) List<FilterOrSortingVo> filterVo) throws ApplicationException {
		return iPaperDetailsService.getPaperDetailsList(skip, limit,searchValue, filterVo,view);

	}

	/**
	 * Gets the download data.
	 *
	 * @param bulkUploadId the bulk upload id
	 * @param pageIdentity the page identity
	 * @param request the request
	 * @return the download data
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Paper details download",notes="Download paper details as excel",response = ResponseEntity.class)
	@GetMapping("/get-paperExcel")
	public ResponseEntity<ByteArrayResource> getDownloadData(@ApiParam(value = "Bulk import id",required=true)  @RequestParam(name="bulkUploadId") Integer bulkUploadId, @ApiParam(value="Bulk import page identity",required=true) @RequestParam (name="pageIdentity") String pageIdentity, HttpServletRequest request) throws ApplicationException{
		ArrayList<LinkedHashMap<String, Object>> scratchDataInExcel = iPaperDetailsService.getScratchDataInExcel(pageIdentity,bulkUploadId,request);
		ResponseEntity<ByteArrayResource> excelDownload = iPaperDetailsService.excelDownload(scratchDataInExcel);
		return excelDownload;
	}
	
	/**
	 * Gets the success data.
	 *
	 * @param bulkUploadId the bulk upload id
	 * @param pageIdentity the page identity
	 * @param skip the skip
	 * @param limit the limit
	 * @param filterOrSortingVo the filter or sorting vo
	 * @param request the request
	 * @return the success data
	 * @throws ApplicationException the application exception
	 */

	@ApiOperation(value="Bulk import success",notes="Get bulk import success data",response = List.class)
	@PostMapping("/get-successData")
	public ArrayList<LinkedHashMap<String,Object>> getSuccessData(@ApiParam(value="Bulk import id",required=true)  @RequestParam(name="bulkUploadId") Integer bulkUploadId, 
			@ApiParam(value="page identity",required=true)	@RequestParam (name="pageIdentity") String pageIdentity, 
			@ApiParam(value="Skip data count",required = true) @RequestParam (name="skip") Integer skip,
			@ApiParam (value="Limit data count",required = true) @RequestParam (name="limit") Integer limit,
			@ApiParam(value="Filter data payload",required = true) @RequestBody List<FilterOrSortingVo> filterOrSortingVo,HttpServletRequest request ) throws ApplicationException {
		ArrayList<LinkedHashMap<String, Object>> successTable = iPaperDetailsService.getSuccessTable(pageIdentity, bulkUploadId,filterOrSortingVo,request,skip,limit);
		return successTable;
	}

	/**
	 * Gets the error data.
	 *
	 * @param bulkUploadId the bulk upload id
	 * @param pageIdentity the page identity
	 * @param skip the skip
	 * @param limit the limit
	 * @param filterOrSortingVo the filter or sorting vo
	 * @param request the request
	 * @return the error data
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Bulk import error",notes="Get bulk import error data",response = List.class)
	@PostMapping("/get-ErrorData")
	public ArrayList<LinkedHashMap<String,Object>> getErrorData(
			@ApiParam(value="Bulk import id",required=true) @RequestParam(name="bulkUploadId") Integer bulkUploadId,
			@ApiParam(value="page identity",required=true)	@RequestParam (name="pageIdentity") String pageIdentity,
			@ApiParam(value="Skip data count",required = true) @RequestParam (name="skip") Integer skip,
			@ApiParam (value="Limit data count",required = true) @RequestParam (name="limit") Integer limit,
			@ApiParam(value="Filter data payload",required = true) @RequestBody List<FilterOrSortingVo> filterOrSortingVo , HttpServletRequest request) throws ApplicationException {
		ArrayList<LinkedHashMap<String, Object>> errorTable = iPaperDetailsService.getErrorTable(pageIdentity, bulkUploadId,filterOrSortingVo,request,skip,limit);
		return errorTable;
	}

	/**
	 * Gets the total records count.
	 *
	 * @param bulkUploadId the bulk upload id
	 * @return the total records count
	 */

	@ApiOperation(value="Total records count",notes="Get total records count details",response=Long.class)
	@GetMapping("/get-TotalRecordsCount")
	public Long getTotalRecordsCount(@ApiParam(value="Bulk import id",required = true) @RequestParam(name="bulkUploadId") Integer bulkUploadId){
		Long errorTable = iPaperDetailsService.getTotalRecords(bulkUploadId);
		return errorTable;
	}

	/**
	 * Gets the success records count.
	 *
	 * @param bulkUploadId the bulk upload id
	 * @return the success records count
	 */
	@ApiOperation(value = "Success records count",notes="Get success records count details",response=Long.class)
	@GetMapping("/get-SuccessRecordsCount")
	public Long getSuccessRecordsCount(@ApiParam(value="Bulk import id",required = true) @RequestParam(name="bulkUploadId") Integer bulkUploadId) {
		Long successTable = iPaperDetailsService.getSuccessRecordsCount(bulkUploadId);
		return successTable;
	}

	/**
	 * Gets the error records count.
	 *
	 * @param bulkUploadId the bulk upload id
	 * @return the error records count
	 */
	@ApiOperation(value = "Error records count",notes="Get error records count details",response=Long.class)
	@GetMapping("/get-ErrorRecordsCount")
	public Long getErrorRecordsCount(@ApiParam(value="Bulk import id",required = true) @RequestParam(name="bulkUploadId") Integer bulkUploadId){

		Long errorTable = iPaperDetailsService.getErrorRecordsCount(bulkUploadId);
		return errorTable;
	}
	 
 	/**
 	 * Update revoke.
 	 *
 	 * @param identity the identity
 	 * @return the application response
 	 * @throws ApplicationException the application exception
 	 * @throws IOException Signals that an I/O exception has occurred.
 	 */
	@ApiOperation(value = "Revoke status update",notes="Update revoke status using revoke identity",response = ApplicationResponse.class)
	@PostMapping("/update-revoke-status")
	public ApplicationResponse updateRevoke(@ApiParam(value = "Bulk revoke identity",required = true) @RequestParam(name ="identity") String identity) throws ApplicationException, IOException {
		String statusUpdated = iPaperDetailsService.updateRevokeStatus(identity);
		return getApplicationResponse(statusUpdated);

	}

	/**
	 * Gets the paper details data.
	 *
	 * @param identity the identity
	 * @return the paper details data
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Revoke paper detail data fetch",notes="Get paper detail data for revoke operation using paper identity",response = ApplicationResponse.class)
	@GetMapping("/get-revoke-data")
	public PaperDetailsDto getPaperDetailsData(@ApiParam(value="Paper identity",required = true)  @RequestParam(name ="identity") String identity) throws ApplicationException {
		return iPaperDetailsService.getPaperDetailsData(identity);
	}


	/**
	 * Sample excel download.
	 *
	 * @param sampleFileColumns the sample file columns
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Sample file download",notes = "Get sample excel for paper details import",response = ResponseEntity.class)
	@PostMapping("/sample-file-download")
	public ResponseEntity<ByteArrayResource> sampleExcelDownload(@ApiParam(value="File columns payload data",required = true)  @RequestBody List<String> sampleFileColumns)
			throws ApplicationException {
		return iPaperDetailsService.sampleExcelDownload(sampleFileColumns);

	}

	/**
	 * Delete scratch record.
	 *
	 * @param scratchIdentity the scratch identity
	 * @param scratchId the scratch id
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Delete scratch data",notes = "Delete scratch record using scratch identity")
	@GetMapping("/deleteScratch")
	public void deleteScratchRecord(@ApiParam(value="Scratch data identity",required = true) @RequestParam(name="scratchIdentity") String scratchIdentity,
			@ApiParam(value="Scratch id",required = true) @RequestParam(name="scratchId") Integer scratchId ) throws ApplicationException {
		iPaperDetailsService.deleteErrorandScratchData(scratchId, scratchIdentity);
	}
	
	/**
	 * Download paper.
	 *
	 * @param paperId the paper id
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Download a paper",notes = "Download a digital paper using paper id",response=ResponseEntity.class)
	@GetMapping("/download-paper/{paperNumber}")
	public ResponseEntity<Resource> downloadPaper( @ApiParam(value="Paper Number ",required = true) @PathVariable("paperNumber") Integer paperId) throws ApplicationException {
		Resource resource = null;
		String filePath = iPaperDetailsService.getPaperDetailsByPaperId(paperId);
		if(!ApplicationUtils.isValidString(filePath)) {
			throw new ApplicationException(ErrorCodes.INVALID_FILE_PATH);
		}
    	try {
    		resource = fileHandler.getFileDataByURL(filePath);
    	} catch (IOException e) {
    		return ResponseEntity.internalServerError().build();
    	}
    	if (!ApplicationUtils.isValidateObject(resource)) {
    		return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
    	}
    	String contentType = "application/octet-stream";
    	String headerValue = "attachment; filename=\"" + resource.getFilename() + "\"";
    	return ResponseEntity.ok()
            .contentType(MediaType.parseMediaType(contentType))
            .header(HttpHeaders.CONTENT_DISPOSITION, headerValue)
            .body(resource); 
		
	}

	/**
	 * Download paper details.
	 *
	 * @param searchValue the search value
	 * @param downloadVo the download vo
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Download paper details list", notes= "List of Digital paper details download",response = ResponseEntity.class)
	@PostMapping("/paper-details-list-download")
	public ResponseEntity<ByteArrayResource> downloadPaperDetails(@ApiParam(value = "Search data",required = true) @RequestParam(name="searchValue") String searchValue,
			@ApiParam(value = "Download vo payload",required = true) @RequestBody DownloadListVo  downloadVo) throws ApplicationException {
		return iPaperDetailsService.dowloadPaperDetails(downloadVo.getColumnList(),downloadVo.getFilterVo(),downloadVo.getCompanyId(), searchValue);
	}
	
	/**
	 * Gets the column names for dropdown.
	 *
	 * @param pageIdentity the page identity
	 * @param request the request
	 * @return the column names for dropdown
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Get digital paper column data",notes="Column details of Digital paper fetch call",response = List.class)
	@GetMapping("/column-data")
	public List<String> getColumnNamesForDropdown(@ApiParam(value="Digital paper page identity",required = true) @RequestParam(name = "pageIdentity") String pageIdentity,HttpServletRequest request) throws ApplicationException {
		return iPaperDetailsService.getColumnNamesForDropdown(pageIdentity,request);
	}
	
	/**
	 * Save digital paper template.
	 *
	 * @param authorityId the authority id
	 * @param template the template
	 * @return the application response
	 * @throws ApplicationException the application exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@ApiOperation(value="Digital paper template save",notes="Save digital paper template for authority",response = ApplicationResponse.class)
	@PostMapping("/save-digitalpaper-template")
	public ApplicationResponse saveDigitalPaperTemplate(@ApiParam(value="Authority id",required = true) @RequestParam(name = "authorityId") Integer authorityId,
		@ApiParam(value = "Template payload data",required = true)	@RequestBody String template ) throws ApplicationException, IOException{
		
		String responce = iPaperDetailsService.saveDigitalPaperTemplate(authorityId,template);
		return getApplicationResponse(responce);
	}
	
	/**
	 * Send all digital paper mail.
	 *
	 * @param searchValue the search value
	 * @param allSearchFilterDto the all search filter dto
	 * @return the application response
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Digital paper email",notes="Send email to all digital papers",response = ApplicationResponse.class)
	@PostMapping("/all-papers-mail")
	public ApplicationResponse sendAllDigitalPaperMail(@ApiParam(value="Search data",required = true) @RequestParam(name="searchValue") String searchValue,
			@ApiParam(value = "AllSearchFilterDto payload data",required = true)	@RequestBody AllSearchFilterDto allSearchFilterDto ) throws ApplicationException {
		String response=iPaperDetailsService.sendMailForPapers(searchValue,allSearchFilterDto);
		return getApplicationResponse(response);
	}
	
	/**
	 * Download all digital papers.
	 *
	 * @param searchValue the search value
	 * @param view the view
	 * @param allSearchFilterDto the all search filter dto
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Digital paper download",notes="Download all digital papers",response = ResponseEntity.class)
	@PostMapping("/all-papers-download")
	public ResponseEntity<ByteArrayResource> downloadAllDigitalPapers(@ApiParam(value="Search data",required = true) @RequestParam(name="searchValue") String searchValue,
		@ApiParam(value="is View Paper details",required=true)	@RequestParam(name="view") String view, 
		@ApiParam(value = "AllSearchFilterDto payload data",required = true) @RequestBody AllSearchFilterDto allSearchFilterDto) throws ApplicationException {
		Boolean viewValue= !ApplicationUtils.isValidString(view) || Boolean.parseBoolean(view);
		ResponseEntity<ByteArrayResource> response =iPaperDetailsService.downloadAllDigitalPapers(searchValue,viewValue,allSearchFilterDto);
		return response ;
	}
	
	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {
	}

}
