package com.digitalpaper.daoImp;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.digitalpaper.config.common.base.dao.BaseDao;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.IComplaintsDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.entity.Complaints;
import com.digitalpaper.transfer.object.entity.PaperDetails;


/**
 * The Class ComplaintsDaoImpl.
 */
@Repository
public class ComplaintsDaoImpl extends BaseDao implements IComplaintsDao{

	/**
	 * Save complaints details.
	 *
	 * @param complaints the complaints
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void saveComplaintsDetails(Complaints complaints) throws ApplicationException {
		
		try {
			save(complaints, TableConstants.COMPLAINTS);
		} catch (ApplicationException e) {
			throw e;
		}
		
	}

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
		
	}

	/**
	 * Gets the complaints all data.
	 *
	 * @param userId the user id
	 * @return the complaints all data
	 */
	@Override
	public List<Complaints> getComplaintsAllData(Integer userId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Complaints> criteria = builder.createQuery(Complaints.class);
		Root<Complaints> root = criteria.from(Complaints.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.CREATED_BY), userId)));
		return (List<Complaints>) getResultList(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Gets the digital paper details based on email id and name.
	 *
	 * @param name the name
	 * @param emailId the email id
	 * @return the digital paper details based on email id and name
	 */
	@Override
	public PaperDetails getdigitalPaperDetailsBasedOnEmailIdAndName(String name, String emailId) {

		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
        Root<PaperDetails> root = criteria.from(PaperDetails.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.PD_INSURED_NAME),name)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.PD_EMAIL_ID), emailId)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		PaperDetails result = (PaperDetails) getResultList(createQuery(builder, criteria, root, predicates)).stream()
				.findFirst().orElse(null);
		return result;
        
	}

	/**
	 * Gets the complaints details.
	 *
	 * @param emailId the email id
	 * @return the complaints details
	 */
	@Override
	public Complaints getComplaintsDetails(String emailId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Complaints> criteria = builder.createQuery(Complaints.class);
		Root<Complaints> root = criteria.from(Complaints.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.COMPLAINTS_EMAILID), emailId)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		Complaints result = (Complaints) getResultList(createQuery(builder, criteria, root, predicates)).stream()
				.findFirst().orElse(null);
		return result;
	}


}
