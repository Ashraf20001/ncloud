package com.digitalpaper.dao;

import java.util.List;
import java.util.Map;

import org.apache.poi.ss.formula.functions.T;
import org.springframework.data.repository.NoRepositoryBean;

import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.entity.TableEntityMapping;

/**
 * The Interface IDigitalImportExportDao.
 */
@NoRepositoryBean
public interface IDigitalImportExportDao{
	
	/**
	 * Fetch all master data.
	 *
	 * @param className the class name
	 * @return the list
	 */
	List<T> fetchAllMasterData(Class<T> className);

	/**
	 * Save all master datas.
	 *
	 * @param masterObjects the master objects
	 * @param tableName the table name
	 * @param isIdentity the is identity
	 * @param isUpdate the is update
	 * @return the integer
	 * @throws ApplicationException the application exception
	 */
	Integer saveAllMasterDatas(Object masterObjects, String tableName, Boolean isIdentity, Boolean isUpdate) throws ApplicationException;

	/**
	 * Save all master datas mock.
	 *
	 * @param masterObjects the master objects
	 * @param tableName the table name
	 * @throws ApplicationException the application exception
	 */
	void saveAllMasterDatasMock(Object masterObjects, String tableName) throws ApplicationException;

	/**
	 * Gets the entity table mapping.
	 *
	 * @return the entity table mapping
	 */
	List<TableEntityMapping> getEntityTableMapping();

	/**
	 * Gets the join master table.
	 *
	 * @param platformId the platform id
	 * @return the join master table
	 */
	List<TableEntityMapping> getJoinMasterTable(Integer platformId);

	/**
	 * Fetch all master data by identity.
	 *
	 * @param className the class name
	 * @param childObjectId the child object id
	 * @param idFieldName the id field name
	 * @return the object
	 */
	Object fetchAllMasterDataByIdentity(Class<T> className, Integer childObjectId, String idFieldName);

	/**
	 * Update master data.
	 *
	 * @param masterObject the master object
	 * @param entityName the entity name
	 */
	void updateMasterData(Object masterObject, String entityName);

	/**
	 * Wipe and inster table by table name.
	 *
	 * @param tableName the table name
	 */
	void wipeAndInsterTableByTableName(String tableName);

	/**
	 * Gets the list of master datas.
	 *
	 * @param tableName the table name
	 * @return the list of master datas
	 */
	List<Map<String, Object>> getListOfMasterDatas(String tableName);

	/**
	 * Update dynamic record.
	 *
	 * @param tableName the table name
	 * @param columnValues the column values
	 * @param conditionColumn the condition column
	 * @param conditionValue the condition value
	 */
	void updateDynamicRecord(String tableName, Map<String, Object> columnValues, String conditionColumn,
			Object conditionValue);

	/**
	 * Save master data native query.
	 *
	 * @param columnValues the column values
	 * @param tableName the table name
	 * @throws ApplicationException the application exception
	 */
	void saveMasterDataNativeQuery(Map<String, Object> columnValues, String tableName) throws ApplicationException;

	/**
	 * Gets the map result by primary id.
	 *
	 * @param tableName the table name
	 * @param columnName the column name
	 * @param primaryId the primary id
	 * @return the map result by primary id
	 */
	Map<String, Object> getMapResultByPrimaryId(String tableName, String columnName, Integer primaryId);

	/**
	 * Check foreign key constraints disable.
	 */
	void checkForeignKeyConstraintsDisable();

	/**
	 * Check foreign key constraints enable.
	 */
	void checkForeignKeyConstraintsEnable();

}
