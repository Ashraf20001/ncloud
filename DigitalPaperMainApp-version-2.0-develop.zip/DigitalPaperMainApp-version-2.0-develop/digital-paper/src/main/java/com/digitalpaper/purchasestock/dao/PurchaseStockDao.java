package com.digitalpaper.purchasestock.dao;

import java.util.List;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.AssociationDashboardCountDto;
import com.digitalpaper.transfer.object.dto.CompanyTransactionDto;
import com.digitalpaper.transfer.object.entity.PaymentDetails;
import com.digitalpaper.transfer.object.entity.PurchaseOrderEntity;
import com.digitalpaper.transfer.object.entity.StockFileMapping;

/**
 * The Interface PurchaseStockDao.
 */
public interface PurchaseStockDao {
	
	/**
	 * Gets the purchase order list.
	 *
	 * @param companyId the company id
	 * @param min the min
	 * @param max the max
	 * @param searchValue the search value
	 * @param filter the filter
	 * @return the purchase order list
	 * @throws ApplicationException the application exception
	 */
	public List<Object[]>  getPurchaseOrderList(Integer companyId,int min,int max,String searchValue,List<FilterOrSortingVo> filter) throws ApplicationException;
	
	/**
	 * Gets the all purchase order list.
	 *
	 * @param min the min
	 * @param max the max
	 * @param filter the filter
	 * @return the all purchase order list
	 * @throws ApplicationException the application exception
	 */
	public List<PurchaseOrderEntity>  getAllPurchaseOrderList(int min,int max,List<FilterOrSortingVo> filter) throws ApplicationException;

	/**
	 * Gets the payment details by order id.
	 *
	 * @param orderId the order id
	 * @return the payment details by order id
	 */
	public PaymentDetails getPaymentDetailsByOrderId(Integer orderId);
	
	/**
	 * Gets the purchase order from purchase id.
	 *
	 * @param purchaseId the purchase id
	 * @return the purchase order from purchase id
	 */
	public PurchaseOrderEntity getPurchaseOrderFromPurchaseId(String purchaseId);

	/**
	 * Update payment details.
	 *
	 * @param paymentDetails the payment details
	 * @throws ApplicationException the application exception
	 */
	public void updatePaymentDetails(PaymentDetails paymentDetails) throws ApplicationException;

	/**
	 * Update purchase order.
	 *
	 * @param purchaseOrder the purchase order
	 * @throws ApplicationException the application exception
	 */
	public void updatePurchaseOrder(PurchaseOrderEntity purchaseOrder) throws ApplicationException;
	
	/**
	 * Gets the purchase order count.
	 *
	 * @param companyId the company id
	 * @param filterOrSortingVo the filter or sorting vo
	 * @param searchValue the search value
	 * @return the purchase order count
	 * @throws ApplicationException the application exception
	 */
	public Long getPurchaseOrderCount(Integer companyId, List<FilterOrSortingVo> filterOrSortingVo,String searchValue) throws ApplicationException;
	
	/**
	 * Gets the payment details count.
	 *
	 * @param companyTransactionDto the company transaction dto
	 * @param searchValue the search value
	 * @return the payment details count
	 * @throws ApplicationException the application exception
	 */
	public Long getPaymentDetailsCount(CompanyTransactionDto companyTransactionDto, String searchValue) throws ApplicationException;

	/**
	 * Gets the payment details by filter.
	 *
	 * @param companyTransactionList the company transaction list
	 * @param searchvalue the searchvalue
	 * @param matchingKey the matching key
	 * @return the payment details by filter
	 * @throws ApplicationException the application exception
	 */
	public List<PaymentDetails> getPaymentDetailsByFilter(CompanyTransactionDto companyTransactionList, String searchvalue, List<Integer> matchingKey) throws ApplicationException;

	/**
	 * Gets the purchase order from order id.
	 *
	 * @param orderId the order id
	 * @return the purchase order from order id
	 */
	public PurchaseOrderEntity getPurchaseOrderFromOrderId(Integer orderId);

	/**
	 * Gets the all purchase order count.
	 *
	 * @return the all purchase order count
	 */
	public Long getAllPurchaseOrderCount();

	/**
	 * Gets the stock file mapping by order id.
	 *
	 * @param orderId the order id
	 * @return the stock file mapping by order id
	 */
	public StockFileMapping getStockFileMappingByOrderId(Integer orderId);

	/**
	 * Gets the authority dashboard count.
	 *
	 * @param associationId the association id
	 * @return the authority dashboard count
	 */
	public List<AssociationDashboardCountDto> getAuthorityDashboardCount(Integer associationId);


}
