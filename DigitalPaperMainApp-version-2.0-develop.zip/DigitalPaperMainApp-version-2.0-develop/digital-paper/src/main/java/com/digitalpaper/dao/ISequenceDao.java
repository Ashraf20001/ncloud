package com.digitalpaper.dao;

/**
 * The Interface ISequenceDao.
 */
public interface ISequenceDao {

	/**
	 * Save sequence.
	 *
	 * @param obj the obj
	 * @return the int
	 */
	int saveSequence(Object obj);

}
