package com.digitalpaper.restemplate.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.CompanyDto;
import com.digitalpaper.transfer.object.dto.DigitalPaperDto;
import com.digitalpaper.transfer.object.dto.FieldGroup;
import com.digitalpaper.transfer.object.dto.MakeModelUsageDto;
import com.digitalpaper.transfer.object.dto.UserRoleCardDto;

/**
 * The Interface IRestTemplateService.
 */
public interface IRestTemplateService {
	
	/**
	 * @return
	 * @throws ApplicationException
	 */
	Long getCompanyListCount(List<FilterOrSortingVo> filterOrSortingVos) throws ApplicationException;
	
	/**
	 * @param min
	 * @param max
	 * @return
	 * @throws ApplicationException
	 */
	List<CompanyDto> getCompanyList(List<FilterOrSortingVo> filterOrSortingVos) throws ApplicationException;
	
	/**
	 * @param identity
	 * @return
	 * @throws ApplicationException
	 */
	List<String> getMetaDataList(String identity,HttpServletRequest request) throws ApplicationException;

	/**
	 * @param propertyName
	 * @author request
	 * @return
	 */
	String getAllocationType(String propertyName, Integer associationId, HttpServletRequest request);

	/**
	 * @param dto
	 * @param request
	 * @return
	 */
	FieldGroup convertDtoToFieldGroup(DigitalPaperDto dto, HttpServletRequest request);
	/**
	 * @param request
	 * @return
	 * @throws ApplicationException
	 */
	HashMap<String, String> getSystemPropertyValue(HttpServletRequest request) throws ApplicationException;
	/**
	 * @param request
	 * @return
	 */
	Map<Integer, String> allApiPrivilege(HttpServletRequest request);

	/**
	 * @param request
	 * @return
	 * @throws ApplicationException
	 */
	HashMap<Integer, String> getAllCompany(HttpServletRequest request) throws ApplicationException;

	/**
	 * Gets the role details for card view.
	 *
	 * @param min the min
	 * @param request the request
	 * @return the role details for card view
	 */
	List<UserRoleCardDto> getRoleDetailsForCardView(Integer min, HttpServletRequest request);

	/**
	 * Gets the company dto.
	 *
	 * @param companyId the company id
	 * @return the company dto
	 */
	CompanyDto getCompanyDto(Integer companyId);

	/**
	 * Gets the all make model usage dropdowns.
	 *
	 * @param request the request
	 * @return the all make model usage dropdowns
	 */
	MakeModelUsageDto getAllMakeModelUsageDropdowns(HttpServletRequest request);
	
	/**
	 * Gets the all users specific to A company.
	 *
	 * @param request the request
	 * @return the all users specific to A company
	 */
	ApplicationResponse getAllUsersSpecificToACompany(HttpServletRequest request);
	
}
