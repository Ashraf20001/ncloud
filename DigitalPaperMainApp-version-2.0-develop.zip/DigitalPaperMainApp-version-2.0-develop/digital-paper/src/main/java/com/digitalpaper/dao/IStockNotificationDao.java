package com.digitalpaper.dao;

import java.util.List;

import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.entity.NotificationEvent;
import com.digitalpaper.transfer.object.entity.NotificationTemplate;
import com.digitalpaper.transfer.object.entity.StockNotification;

/**
 * The Interface IStockNotificationDao.
 */
public interface IStockNotificationDao {

	/**
	 * Gets the previous notification.
	 *
	 * @param stockId the stock id
	 * @return the previous notification
	 */
	StockNotification getPreviousNotification(Integer stockId);

	/**
	 * Update notification.
	 *
	 * @param notificationEntity the notification entity
	 * @throws ApplicationException the application exception
	 */
	void updateNotification(StockNotification notificationEntity) throws ApplicationException;

	/**
	 * Save notification.
	 *
	 * @param notificationEntity the notification entity
	 * @throws ApplicationException the application exception
	 */
	void saveNotification(StockNotification notificationEntity) throws ApplicationException;

	/**
	 * Gets the notificationevent.
	 *
	 * @param stockPurchase the stock purchase
	 * @return the notificationevent
	 */
	NotificationEvent getNotificationevent(String stockPurchase);

	/**
	 * Gets the notification template.
	 *
	 * @param eventId the event id
	 * @param action the action
	 * @return the notification template
	 */
	NotificationTemplate getNotificationTemplate(Integer eventId, String action);

	/**
	 * Gets the notification data.
	 *
	 * @param companyId the company id
	 * @param skip the skip
	 * @param limit the limit
	 * @return the notification data
	 */
	List<StockNotification> getNotificationData(Integer companyId, Integer skip, Integer limit);

	/**
	 * Gets the notification by authority.
	 *
	 * @param associationId the association id
	 * @param skip the skip
	 * @param limit the limit
	 * @return the notification by authority
	 */
	List<StockNotification> getNotificationByAuthority(Integer associationId, Integer skip, Integer limit);

	/**
	 * Gets the notification count based one company id.
	 *
	 * @param companyId the company id
	 * @return the notification count based one company id
	 */
	Long getNotificationCountBasedOneCompanyId(Integer companyId);

	/**
	 * Gets the notification count.
	 *
	 * @param associationId the association id
	 * @return the notification count
	 */
	Long getNotificationCount(Integer associationId);

	/**
	 * Gets the notification based on id.
	 *
	 * @param notificationId the notification id
	 * @return the notification based on id
	 */
	StockNotification getNotificationBasedOnId(Integer notificationId);
	
	/**
	 * Gets the notification purch history.
	 *
	 * @param companyId the company id
	 * @return the notification purch history
	 */
	List<StockNotification> getNotificationPurchHistory(Integer companyId);
}
