package com.digitalpaper.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.AllSearchFilterDto;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;

/**
 * The Interface IPaperDetailsService.
 */
public interface IPaperDetailsService {

	/**
	 * @return
	 * @throws ApplicationException
	 */
	Long getPaperDeatilsCount(List<FilterOrSortingVo> filterVo, String view,String searchValue) throws ApplicationException;

	/**
	 * @param skip
	 * @param limit
	 * @param filterVo
	 * @return
	 * @throws ApplicationException
	 */
	List<PaperDetailsDto> getPaperDetailsList(Integer skip, Integer limit,String searchValue, List<FilterOrSortingVo> filterVo,String view) throws ApplicationException;

	/**
	 *
	 * @param pageIdentity
	 * @param bulkUploadId
	 * @return
	 */
	ArrayList<LinkedHashMap<String, Object>> getScratchDataInExcel(String pageIdentity, Integer bulkUploadId,HttpServletRequest request) throws ApplicationException;

	/**
	 *
	 * @param scratchDataInExcel
	 * @return
	 */
	ResponseEntity<ByteArrayResource> excelDownload(ArrayList<LinkedHashMap<String, Object>> scratchDataInExcel);

	/**
	 *
	 * @param pageIdentity
	 * @param bulkUploadId
	 * @param filterOrSortingVo
	 * @param limit 
	 * @param skip 
	 * @return
	 * @throws ApplicationException
	 */
	ArrayList<LinkedHashMap<String, Object>> getSuccessTable(String pageIdentity, Integer bulkUploadId, List<FilterOrSortingVo> filterOrSortingVo,HttpServletRequest request, Integer skip, Integer limit) throws ApplicationException;

	/**
	 *
	 * @param pageIdentity
	 * @param bulkUploadId
	 * @param filterOrSortingVo
	 * @param limit 
	 * @param skip 
	 * @return
	 * @throws ApplicationException
	 */
	ArrayList<LinkedHashMap<String, Object>> getErrorTable(String pageIdentity, Integer bulkUploadId, List<FilterOrSortingVo> filterOrSortingVo, HttpServletRequest request, Integer skip, Integer limit) throws ApplicationException;

	/**
	 *
	 * @param bulkUploadId
	 * @return
	 */
	Long getTotalRecords(Integer bulkUploadId);

	/**
	 * @param bulkUploadId
	 * @return
	 */
	Long getSuccessRecordsCount(Integer bulkUploadId);

	/**
	 * @param bulkUploadId
	 * @return
	 */
	Long getErrorRecordsCount(Integer bulkUploadId);
	/**
	 * @param identity
	 * @return
	 * @throws ApplicationException
	 * @throws IOException
	 */
	public String updateRevokeStatus(String identity) throws ApplicationException, IOException;

	/**
	 * @param identity
	 * @return
	 * @throws ApplicationException
	 */
	PaperDetailsDto getPaperDetailsData(String identity) throws ApplicationException;
	/**
	 *
	 * @param scratchId
	 * @param scratchIdentity
	 * @throws ApplicationException
	 */
	public void deleteErrorandScratchData(Integer scratchId, String scratchIdentity) throws ApplicationException;

	/**
	 * @param idList 
	 * @param pageIdentity
	 * @param dowloadListVo
	 * @param request
	 * @return
	 * @throws ApplicationException
	 */
	ResponseEntity<ByteArrayResource> dowloadPaperDetails(List<String> downloadColumns,List<FilterOrSortingVo> filterVo, List<Integer> idList, String searchValue) throws ApplicationException;

	/**
	 * @param pageIdentity
	 * @param request
	 * @return
	 * @throws ApplicationException
	 */
	List<String> getColumnNamesForDropdown(String pageIdentity,HttpServletRequest request) throws ApplicationException;
	
	/**
	 * @param paperId
	 * @return 
	 */
	public String getPaperDetailsByPaperId(Integer paperId);

	/**
	 * @param sampleFileColumns
	 * @return
	 */
	ResponseEntity<ByteArrayResource> sampleExcelDownload(List<String> sampleFileColumns);

	/**
	 * Save digital paper template.
	 *
	 * @param authorityId the authority id
	 * @param template the template
	 * @return the string
	 * @throws ApplicationException the application exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	String saveDigitalPaperTemplate(Integer authorityId, String template) throws ApplicationException, IOException;

	/**
	 * Send mail for papers.
	 *
	 * @param searchValue the search value
	 * @param allSearchFilterDto the all search filter dto
	 * @return the string
	 * @throws ApplicationException the application exception
	 */
	String sendMailForPapers(String searchValue, AllSearchFilterDto allSearchFilterDto) throws ApplicationException;

	/**
	 * Download all digital papers.
	 *
	 * @param searchValue the search value
	 * @param view the view
	 * @param allSearchFilterDto the all search filter dto
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	ResponseEntity<ByteArrayResource> downloadAllDigitalPapers(String searchValue, Boolean view, AllSearchFilterDto allSearchFilterDto) throws ApplicationException;

}
