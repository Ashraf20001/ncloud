
package com.digitalpaper.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitalpaper.service.ICustomerNotificationService;
import com.digitalpaper.transfer.object.dto.CustomerNotificationDto;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class CustomerNotificationController.
 */
@RestController
public class CustomerNotificationController {
	
 
	/** The customer notification service. */
	@Autowired 
	private ICustomerNotificationService customerNotificationService; 
	
	/**
	 * Gets the custom notification count.
	 *
	 * @return the custom notification count
	 */
	@ApiOperation(value="Customer notification details",notes="Get the customer notification list",response=List.class)
	@GetMapping("/get-customer-notification-details")
	public List<CustomerNotificationDto> getCustomNotificationCount() {
		List<CustomerNotificationDto> customerNotificationDto=null;
		 customerNotificationDto=customerNotificationService.getCustomNotificationCount();
		return customerNotificationDto;
	}
    
	/**
	 * Update notification by identity.
	 *
	 * @param identity the identity
	 * @return true, if successful
	 */
	@ApiOperation(value="Update notification details",notes="Update the customer notification",response=List.class)
	@GetMapping("/update-notification")
	public boolean updateNotificationByIdentity(@ApiParam(value = "Customer notification identity",required = true) @RequestParam String identity) {
		boolean isUpdated=false;
		 isUpdated=customerNotificationService.updateNotificationByIdentity(identity);
		return isUpdated;
	}
    
	/**
	 * Gets the particuler paper.
	 *
	 * @param paperId the paper id
	 * @return the particuler paper
	 */
	@ApiOperation(value="Digital paper details",notes="Get the Digital paper details using paper id",response=List.class)
	@GetMapping("/getCustomer-paperDetails")
	public PaperDetailsDto getParticulerPaper(@ApiParam(value="Digital paper id",required = true)  @RequestParam String paperId) {
		PaperDetailsDto paperDetails = customerNotificationService.getpaperBasedOnid(paperId);
		
		return paperDetails;
	}
    
}
