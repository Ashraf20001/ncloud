package com.digitalpaper.daoImp;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Selection;

import org.springframework.stereotype.Repository;

import com.digitalpaper.config.common.base.dao.BaseDao;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.IScratchDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.entity.Scratch;

/**
 * The Class ScratchDaoImpl.
 */
@Repository
public class ScratchDaoImpl extends BaseDao implements IScratchDao {
	
	/**
	 * @param id
	 * @param columnNames
	 * @param isError
	 * @param filter
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public List<Object[]> getScratchEntityByBulkId(Integer id,List<String> columnNames,Boolean isError,List<FilterOrSortingVo> filter,Integer skip,Integer limit) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Object[]> createQuery = builder.createQuery(Object[].class);
		Root<Scratch> root =createQuery.from(Scratch.class);
		List <Selection<?>> selections = new ArrayList<>();
		for(String column : columnNames) {
			selections.add(root.get(column));
		}
		createQuery.multiselect(selections);
		List<Predicate> predicate= new ArrayList<Predicate>();
		predicate.add(builder.and(builder.equal(root.get(TableConstants.BULK_UPLOAD_ID), id)));
		predicate.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETED), false)));
		if(isError) {
			predicate.add(builder.and(builder.equal(root.get(TableConstants.STATUS),false)));
		}
		
		else {
			predicate.add(builder.and(builder.equal(root.get(TableConstants.STATUS),true)));

		}
		List<Predicate> filterPrdicets = getFilterPrdicets(filter, root, builder, createQuery);
		predicate.addAll(filterPrdicets);
		
		return (List<Object[]>)getResultList(createQuery(builder, createQuery, root, predicate).setFirstResult(skip).setMaxResults(limit));
	}

	/**
	 * @param id
	 * @return 
	 */
	@Override
	public Long getTotalScratchCountByBulkId(Integer id) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> createQuery = builder.createQuery(Long.class);
		Root<Scratch> root =createQuery.from(Scratch.class);
		createQuery.select(builder.count(root));
		List<Predicate> predicate= new ArrayList<Predicate>();
		predicate.add(builder.and(builder.equal(root.get(TableConstants.BULK_UPLOAD_ID), id)));
		predicate.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETED), false)));
		return (Long) getSingleResult(createQuery(builder, createQuery, root, predicate));
	}
	
	/**
	 * @param id
	 * @param isError
	 */
	@Override
	public Long getScratchCountByBulkId(Integer id,Boolean isError) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> createQuery = builder.createQuery(Long.class);
		Root<Scratch> root =createQuery.from(Scratch.class);
		createQuery.select(builder.count(root));
		List<Predicate> predicate= new ArrayList<Predicate>();
		if(isError) {
			predicate.add(builder.and(builder.equal(root.get(TableConstants.BULK_UPLOAD_ID), id)));
			predicate.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETED), false)));
			predicate.add(builder.and(builder.equal(root.get(TableConstants.STATUS),false)));
			
			
		}
		else {
			predicate.add(builder.and(builder.equal(root.get(TableConstants.BULK_UPLOAD_ID), id)));
			predicate.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETED), false)));
			predicate.add(builder.and(builder.equal(root.get(TableConstants.STATUS),true)));
		}
		
		return (Long)getSingleResult(createQuery(builder, createQuery, root, predicate));
	}

	/**
	 * 
	 * @param scratchIdentity
	 * @return
	 */
	@Override
	public Scratch getScratchDataByIdentity(String scratchIdentity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Scratch> createQuery = builder.createQuery(Scratch.class);
		Root<Scratch> root =createQuery.from(Scratch.class);
		createQuery.select(root);
		List<Predicate> predicates= new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IDENTITY), scratchIdentity)))	;
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETED), false)));
		
		return (Scratch)getSingleResult(createQuery(builder, createQuery, root, predicates));
		
	}
	
	/**
	 * 
	 * @param scratchData
	 */
	@Override
	public void deleteScratchData(Scratch scratchData) {
		update(scratchData);
	}
	
	
	
	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
		
	}

	/**
	 * Gets the total scratch list by by bulk id.
	 *
	 * @param id the id
	 * @return the total scratch list by by bulk id
	 */ 
	@Override
    public List<Scratch> getTotalScratchListByByBulkId(Integer id) {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<Scratch> createQuery = builder.createQuery(Scratch.class);
        Root<Scratch> root =createQuery.from(Scratch.class);
        createQuery.select(root);
        List<Predicate> predicate= new ArrayList<Predicate>();
        predicate.add(builder.and(builder.equal(root.get(TableConstants.BULK_UPLOAD_ID), id)));
        predicate.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETED), false)));
        predicate.add(builder.and(builder.equal(root.get(TableConstants.STATUS), false)));
        return (List<Scratch>) getResultList(createQuery(builder, createQuery, root, predicate));
    }

}
