package com.digitalpaper.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.digitalpaper.dao.IStockDao;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.entity.Stock;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;
import com.digitalpaper.utils.core.ApplicationUtils;

/**
 * The Class PaperValidationUtils.
 */
@Component
public class PaperValidationUtils {

	/** The context holder. */
	@Autowired
	private LoggedInUserContextHolder contextHolder;
	
	/** The stock dao. */
	@Autowired
	private IStockDao stockDao;
	
	/**
	 * Available count check.
	 *
	 * @return the integer
	 */
	public Integer availableCountCheck() {
		Integer availableStock=null;
		UserInfo userInfo = contextHolder.getLoggedInUser();
		Integer companyId = userInfo.getCompanyId();
		if(ApplicationUtils.isValidId(companyId)) {
			Stock stock=stockDao.getStockData(companyId);
			availableStock=stock.getStockCount() - stock.getUsedCount();
		}
		return availableStock;
	}
	
}
