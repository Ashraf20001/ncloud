package com.digitalpaper.service.impl;

import java.time.LocalDateTime;
import java.time.Month;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.digitalpaper.config.DigitalPaperCache;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.dao.DashBoardDao;
import com.digitalpaper.dao.IPaperDetailsDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.purchasestock.dao.PurchaseStockDao;
import com.digitalpaper.restemplate.service.RestTemplateServiceImpl;
import com.digitalpaper.service.DashBoardService;
import com.digitalpaper.transfer.object.dto.AuthorityBarChartDto;
import com.digitalpaper.transfer.object.dto.BarChartDto;
import com.digitalpaper.transfer.object.dto.CompanyDto;
import com.digitalpaper.transfer.object.dto.DashBoardInputDto;
import com.digitalpaper.transfer.object.dto.DashBoardOutputDto;
import com.digitalpaper.transfer.object.dto.DoughNutDto;
import com.digitalpaper.transfer.object.dto.GraphValuesDto;
import com.digitalpaper.transfer.object.dto.MonthCountDto;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;
import com.digitalpaper.transfer.object.dto.TopCompanyPurchaseDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.dto.ViewHistoryDto;
import com.digitalpaper.transfer.object.entity.FileStorage;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.entity.PaymentDetails;
import com.digitalpaper.transfer.object.entity.StockFileMapping;
import com.digitalpaper.transfer.object.entity.UserType;
import com.digitalpaper.transfer.object.enums.PaperDetailsStatusEnum;
import com.digitalpaper.transfer.object.enums.PaymentModeEnum;
import com.digitalpaper.transfer.object.enums.PaymentStatusEnum;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;
import com.digitalpaper.utils.CommonUtils;
import com.digitalpaper.utils.core.ApplicationDateUtils;
import com.digitalpaper.utils.core.ApplicationUtils;

/**
 * The Class DashBoardServiceImpl.
 */
@Service
@Transactional
public class DashBoardServiceImpl implements DashBoardService {
	
	/**
	 * DashBoardDao
	 */
	@Autowired
	private DashBoardDao dashBoardDao;
	
	/** The resttemplate service. */
	@Autowired
	private RestTemplateServiceImpl resttemplateService;
	
	/**
	 * LoggedInUserContextHolder
	 */
	@Autowired
	private LoggedInUserContextHolder loggedInUserContextHolder;
	
	/**
	 * IPaperDetailsDao
	 */
	@Autowired
	private IPaperDetailsDao iPaperDetailsDao;
	
	/**
	 * PurchaseStockDao
	 */
	@Autowired
	private PurchaseStockDao purchaseStockDao;
	
	/**
	 * DigitalPaperCache
	 */
	@Autowired
	private DigitalPaperCache digitalPaperCache;
	
	/** The common utils. */
	@Autowired
	private CommonUtils commonUtils;
	
	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ApplicationDateUtils.class);

	/**
	 * Sets the dash board dao.
	 *
	 * @param dashBoardDao the new dash board dao
	 */
	public void setDashBoardDao(DashBoardDao dashBoardDao) {
		this.dashBoardDao = dashBoardDao;
	}


	/**
	 * Sets the logged in user context holder.
	 *
	 * @param loggedInUserContextHolder the new logged in user context holder
	 */
	public void setLoggedInUserContextHolder(LoggedInUserContextHolder loggedInUserContextHolder) {
		this.loggedInUserContextHolder = loggedInUserContextHolder;
	}
	
	/**
	 *@return
	 *@throws ApplicationException
	 */
	@Override
	public List<PaperDetailsDto> getCompanyRecentDigitalPapers(DashBoardInputDto dashboardInputDto) throws ApplicationException {
		
		List<PaperDetailsDto> paperDetailsDtoList = new ArrayList<PaperDetailsDto>();
		
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		Integer companyId = loggedInUser.getCompanyId();
		Integer allocationUserTypeId = loggedInUser.getAllocationUserType();
		
		List<PaperDetails> paperDetailsData = dashBoardDao.getRecentAndExpiredPaperDetails(Boolean.FALSE,Boolean.FALSE, companyId, allocationUserTypeId,dashboardInputDto);
		
		if(ApplicationUtils.isValidateObject(paperDetailsData)) {
			paperDetailsDtoList=convertPaperDetailsDataToCardDetailsDto(paperDetailsData,digitalPaperCache.getCompanyList());
		}
		return paperDetailsDtoList;
	}

	/**
	 *@return
	 *@throws ApplicationException
	 */
	@Override
	public List<PaperDetailsDto> getCompanyExpiryDigitalPapers(DashBoardInputDto dashboardInputDto) throws ApplicationException {
		
		List<PaperDetailsDto> paperDetailsDtoList = new ArrayList<PaperDetailsDto>();
		
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		Integer companyId = loggedInUser.getCompanyId();
		Integer allocationUserTypeId = loggedInUser.getAllocationUserType();

		List<PaperDetails> paperDetailsData = dashBoardDao.getRecentAndExpiredPaperDetails(Boolean.FALSE,Boolean.TRUE, companyId,allocationUserTypeId,dashboardInputDto);
		
		if(ApplicationUtils.isValidList(paperDetailsData)) {
			paperDetailsDtoList=convertPaperDetailsDataToCardDetailsDto(paperDetailsData,null);
		}
		return paperDetailsDtoList;
	}

	
	/**
	 *@return
	 *@throws ApplicationException
	 */
	@Override
	public List<ViewHistoryDto> getAllCompaniesRecentTransaction(DashBoardInputDto dashboardInputDto) throws ApplicationException {
		List<ViewHistoryDto> viewHistoryList;
		
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		UserType userTypeId = loggedInUser.getUserTypeId();
		if (!userTypeId.getUserTypeName().equals(ApplicationConstants.ASSOCIATION)) {
			throw new ApplicationException(ErrorCodes.UN_AUTHORIZED);
		}
		
		List<PaymentDetails> allCompaniesRecentTransactionData = dashBoardDao.getAllCompaniesRecentTransaction(dashboardInputDto);
		HashMap<Integer, String> companyList = digitalPaperCache.getCompanyList();
		if(!ApplicationUtils.isValidObject(companyList)) {
			throw new ApplicationException(ErrorCodes.NO_COMPANY_DATA_FOUND);
		}		
		
		viewHistoryList=convertRecentTransactionEntityToViewHistoryDto(allCompaniesRecentTransactionData,companyList);
		
		return viewHistoryList;
	}


	

	/**
	 *@return
	 *@throws ApplicationException
	 */
	@Override
	public List<PaperDetailsDto> getAllCompaniesRecentDigitalPapers(DashBoardInputDto dashboardInputDto) throws ApplicationException{
		List<PaperDetailsDto> paperDetailsDtoList = new ArrayList<PaperDetailsDto>();
		
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		UserType userTypeId = loggedInUser.getUserTypeId();
		if (!userTypeId.getUserTypeName().equals(ApplicationConstants.ASSOCIATION)) {
			throw new ApplicationException(ErrorCodes.UN_AUTHORIZED);
		}
		
		List<PaperDetails> paperDetailsData = dashBoardDao.getRecentAndExpiredPaperDetails(Boolean.TRUE, Boolean.FALSE, null, null,dashboardInputDto);
		HashMap<Integer, String> companyList = digitalPaperCache.getCompanyList();
		if(!ApplicationUtils.isValidObject(companyList)) {
			throw new ApplicationException(ErrorCodes.NO_COMPANY_DATA_FOUND);
		}
		
		paperDetailsDtoList=convertPaperDetailsDataToCardDetailsDto(paperDetailsData,companyList);
		
		return paperDetailsDtoList;
	}
	
	/**
	 * @param paperDetailsList
	 * @param filteredCompanyName 
	 * @return
	 */
	private List<PaperDetailsDto> convertPaperDetailsDataToCardDetailsDto(List<PaperDetails> paperDetailsList, Map<Integer, String> filteredCompanyName) {
		
		List<PaperDetailsDto> paperDetailsDtoList = new ArrayList<PaperDetailsDto>();
		
		for (PaperDetails paperDetails : paperDetailsList) {
			PaperDetailsDto paperDetailsDto = new PaperDetailsDto();
			paperDetailsDto.setCompanyId(paperDetails.getCompanyId());
			if(ApplicationUtils.isValidObject(filteredCompanyName)) {
				paperDetailsDto.setCompanyName(filteredCompanyName.get(paperDetails.getCompanyId()));
			}
			paperDetailsDto.setCreatedDate(paperDetails.getCreatedDate().toString());
			paperDetailsDto.setPdDigiltaPaperId(paperDetails.getPdDigitalPaperId());
			paperDetailsDto.setIdentity(paperDetails.getIdentity());
			paperDetailsDto.setPdEffectiveFrom(paperDetails.getPdEffectiveFrom().toString());
			paperDetailsDto.setPdEmailId(paperDetails.getPdEmailId());
			paperDetailsDto.setPdExpireDate(paperDetails.getPdExpireDate().toString());
			paperDetailsDto.setPdInsuredName(paperDetails.getPdInsuredName());
			paperDetailsDto.setPdPhoneNumber(paperDetails.getPdPhoneNumber());
			paperDetailsDto.setPdPolicyNumber(paperDetails.getPdPolicyNumber());
			paperDetailsDto.setStatus(PaperDetailsStatusEnum.getIdByName(paperDetails.getStatus()));
			paperDetailsDto.setVdChassis(paperDetails.getVdChassis());
			paperDetailsDto.setVdLicensedToCarry(paperDetails.getVdLicensedToCarry());
			paperDetailsDto.setVdMake(paperDetails.getVdMake());
			paperDetailsDto.setVdModel(paperDetails.getVdModel());
			paperDetailsDto.setPdEmailId(paperDetails.getPdEmailId());
			paperDetailsDto.setVdRegistrationNumber(paperDetails.getVdRegistrationNumber());
			paperDetailsDto.setVdUsage(paperDetails.getVdUsage());	
			FileStorage file = iPaperDetailsDao.getPaperImageById(paperDetails.getPaperId(),
					ApplicationConstants.UPD_TYPE, ApplicationConstants.RP_TYPE);
			if(ApplicationUtils.isValidateObject(file)) {
				paperDetailsDto.setFileURL(file.getUrl());
			}	
			paperDetailsDtoList.add(paperDetailsDto);;
		}
		
		return paperDetailsDtoList;	
	}
	
	/**
	 * @param allCompaniesRecentTransactionData
	 * @param filteredCompanyName 
	 * @return
	 */
	private List<ViewHistoryDto> convertRecentTransactionEntityToViewHistoryDto(
			List<PaymentDetails> allCompaniesRecentTransactionData, Map<Integer, String> filteredCompanyName) {
		
		List<ViewHistoryDto> viewHistoryList = new ArrayList<>();
		for(PaymentDetails allCompaniesPaymentDetails:allCompaniesRecentTransactionData) {
			ViewHistoryDto viewHistory= new ViewHistoryDto();
			StockFileMapping stockFileMappingByOrderId = null;
			try {
				 stockFileMappingByOrderId = purchaseStockDao.getStockFileMappingByOrderId(allCompaniesPaymentDetails.getOrderId().getOrderId());
			} catch (Exception e) {
				logger.error("Error while getting company logo ".concat(e.getMessage()) );
			}
			viewHistory.setOrderStatus(allCompaniesPaymentDetails.getOrderId().getOrderStatus());
			viewHistory.setCompanyName(filteredCompanyName.get(allCompaniesPaymentDetails.getOrderId().getCompanyId()));
			viewHistory.setStockCount(allCompaniesPaymentDetails.getOrderId().getStockCount());
			viewHistory.setPurchaseDate(allCompaniesPaymentDetails.getPaymentDate().toString());
			viewHistory.setPaymentStatus(PaymentStatusEnum.getPaymentStatusEnumById(allCompaniesPaymentDetails.getPaymentStatus()).name());
			viewHistory.setPurchaseAmount(allCompaniesPaymentDetails.getPaidAmount());
			viewHistory.setPaymentMethod(PaymentModeEnum.getPaymentModeById(allCompaniesPaymentDetails.getPaymentMode()).name());
			viewHistory.setTransactionId(allCompaniesPaymentDetails.getTransactionId());
			viewHistory.setPurchaseId(allCompaniesPaymentDetails.getOrderId().getPurchaseId());
			viewHistory.setOrderId(allCompaniesPaymentDetails.getOrderId().getOrderId());
			viewHistory.setFileMappingId(ApplicationUtils.isValidateObject(stockFileMappingByOrderId)?stockFileMappingByOrderId.getStorageId():null);
			viewHistory.setCurrencyType(allCompaniesPaymentDetails.getCurrencyType());
			viewHistoryList.add(viewHistory);
		}
		return viewHistoryList;
	}

	/**
	 * @param dashboardInputDto
	 *@return
	 *@throws ApplicationException
	 */
	@Override
	public List<TopCompanyPurchaseDto> getTopPurchaseData(DashBoardInputDto dashboardInputDto) throws ApplicationException {
		
		List<TopCompanyPurchaseDto> topCompanyPurchasesList = new ArrayList<TopCompanyPurchaseDto>();
		
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		UserType userTypeId = loggedInUser.getUserTypeId();
		if (!userTypeId.getUserTypeName().equals(ApplicationConstants.ASSOCIATION)) {
			throw new ApplicationException(ErrorCodes.UN_AUTHORIZED);
		}
		
		List<Object[]> topPurchaseCompanies = dashBoardDao.getTopPurchaseCompanies(dashboardInputDto.getFromDate(), dashboardInputDto.getToDate());
		HashMap<Integer, String> companyList = digitalPaperCache.getCompanyList();
		
		if(!ApplicationUtils.isValidObject(companyList)) {
			throw new ApplicationException(ErrorCodes.NO_COMPANY_DATA_FOUND);
		}
		for(Object[] topPurchases:topPurchaseCompanies) {
			TopCompanyPurchaseDto purchaseDto = new TopCompanyPurchaseDto();
			purchaseDto.setCompanies(companyList.get((Integer)topPurchases[0]));
			purchaseDto.setStockCount((Long)topPurchases[1]);
			topCompanyPurchasesList.add(purchaseDto);
		}
		

		return topCompanyPurchasesList;
	}
	
	/**
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public List<Integer> getAllCompanyIds() throws ApplicationException {

		List<Integer> companyIdList = new ArrayList<Integer>();
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		UserType userTypeId = loggedInUser.getUserTypeId();
		if (!userTypeId.getUserTypeName().equals(ApplicationConstants.ASSOCIATION)) {
			throw new ApplicationException(ErrorCodes.UN_AUTHORIZED);
		}
		List<Integer> paymentCompanyIds = dashBoardDao.getPaymentCompanyIds();
		if (ApplicationUtils.isValidList(paymentCompanyIds)) {
			companyIdList.addAll(paymentCompanyIds);

		}

		return companyIdList;
	}
	
	/**
	 * Gets the all paper company ids.
	 *
	 * @return the all paper company ids
	 * @throws ApplicationException the application exception
	 */
	@Override 
	public List<Integer> getAllPaperCompanyIds() throws ApplicationException{
		List<Integer> companyIdList = new ArrayList<Integer>();
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		UserType userTypeId = loggedInUser.getUserTypeId();
		if (!userTypeId.getUserTypeName().equals(ApplicationConstants.ASSOCIATION)) {
			throw new ApplicationException(ErrorCodes.UN_AUTHORIZED);
		}
		List<Integer> paperCompanyIds = dashBoardDao.getPaperDetailsCompanyIds();
		if (ApplicationUtils.isValidList(paperCompanyIds)) {
			companyIdList.addAll(paperCompanyIds);

		}

		return companyIdList;
	}
	
	/**
	 * Gets the prediction data.
	 *
	 * @return the prediction data
	 */
	@Override
	public DashBoardOutputDto getPredictionData() {
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
	    LocalDateTime currentDateTime = LocalDateTime.now();
	    
	    YearMonth currentMonth = YearMonth.from(currentDateTime);
        YearMonth lastSixMonth = YearMonth.from(currentDateTime).minusMonths(6);
        LocalDateTime dateOfLastSixthMonth = lastSixMonth.atDay(1).atStartOfDay();
        LocalDateTime currentMonthEnd = currentMonth.atEndOfMonth().atTime(23, 59, 59, 999999999); 
        Long sixMonthTotalPaperGenerated = dashBoardDao.getPaperGeneratedCountInCuurentMonth(dateOfLastSixthMonth,currentMonthEnd, loggedInUser.getCompanyId());
        if (!ApplicationUtils.isValidateObject(sixMonthTotalPaperGenerated)) {
        	sixMonthTotalPaperGenerated = 0l;
		}
        
        Long avgPaperGeneratedPerMonth = (long) Math.ceil((double)sixMonthTotalPaperGenerated/6)  ;
        
        
        
        DashBoardOutputDto dashBoardOutputDto = new DashBoardOutputDto();
        
                        
       List<MonthCountDto> paperGenerateCountBasedOnMonthAndCompany = dashBoardDao.getPaperGenerateCountBasedOnMonthAndCompany(loggedInUser.getCompanyId(),dateOfLastSixthMonth,
    		   currentMonthEnd);
       																									
       List<GraphValuesDto> graphList = new ArrayList<>();
       
		if (currentMonth.getMonth().ordinal() + 1 < 7) {

			Month currentMonthValue = currentMonth.getMonth();
			Month startingMonth = currentMonth.minusMonths(6).getMonth();
			

			for (Month month = startingMonth;month.ordinal()+1!=currentMonthValue.ordinal()+3; month = month.plus(1)) {
				GraphValuesDto grapthDto = new GraphValuesDto();
				grapthDto.setXAxis(month.toString());
				grapthDto.setYAxis(0l);
				if (currentMonth.getMonth().ordinal() + 2 == (month.ordinal() + 1)) {
					grapthDto.setYAxis(avgPaperGeneratedPerMonth);
				}

				for (MonthCountDto monthCountDto : paperGenerateCountBasedOnMonthAndCompany) {
					if (monthCountDto.getMonth() == (month.ordinal() + 1)) {
						grapthDto.setYAxis(monthCountDto.getCount());
					}
				}

				graphList.add(grapthDto);
			}
		} else {

			for (Month month : Month.values()) {
				GraphValuesDto grapthDto = new GraphValuesDto();
				grapthDto.setXAxis(month.toString());
				grapthDto.setYAxis(0l);
				if (currentMonth.getMonth().ordinal() + 2 == (month.ordinal() + 1)) {
					grapthDto.setYAxis(avgPaperGeneratedPerMonth);
				}

				for (MonthCountDto monthCountDto : paperGenerateCountBasedOnMonthAndCompany) {
					if (monthCountDto.getMonth() == (month.ordinal() + 1)) {
						grapthDto.setYAxis(monthCountDto.getCount());
					}
				}

				graphList.add(grapthDto);
			}

			if (currentMonth.getMonth().equals(Month.DECEMBER)) {
				graphList.remove(ApplicationConstants.ZERO);
				GraphValuesDto grapthDto = new GraphValuesDto();
				grapthDto.setXAxis(Month.JANUARY.toString());
				grapthDto.setYAxis(avgPaperGeneratedPerMonth);

				graphList.add(grapthDto);
			}
		}

        dashBoardOutputDto.setDashBoardValues(graphList);
        
		return dashBoardOutputDto;
	}
	

	/**
	 * @param dashBoardInputDto
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public List<BarChartDto> getBarChartDataForInsCompany(DashBoardInputDto dashBoardInputDto,HttpServletRequest request) throws ApplicationException {
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		String systemPropertyValueByPropertyId = null;
		try {
			 systemPropertyValueByPropertyId = commonUtils.getSystemPropertyValueByPropertyId(request,
					loggedInUser.getAssociationId(), ApplicationConstants.ALLOCATION_TYPE);
		} catch (ApplicationException e2) {
			e2.printStackTrace();
		}
		List<BarChartDto> barChartList = new ArrayList<>();
		List<GraphValuesDto> graphListForStockAllocated = getDataForInsCompanyStockAllocated(dashBoardInputDto, loggedInUser,systemPropertyValueByPropertyId);
		List<GraphValuesDto> graphListForCertificateIssued = getDataForInsCompanyCertificateIssued(dashBoardInputDto, loggedInUser,systemPropertyValueByPropertyId);
		setDataEntityToDto(barChartList, graphListForStockAllocated, graphListForCertificateIssued);
		return barChartList;
	}


	/**
	 * @param list
	 * @param graphListForStockAllocated
	 * @param graphListForCertificateIssued
	 */
	private void setDataEntityToDto(List<BarChartDto> list, List<GraphValuesDto> graphListForStockAllocated,
			List<GraphValuesDto> graphListForCertificateIssued) {
		for (GraphValuesDto val1 : graphListForStockAllocated) {
			int count = 0;
			BarChartDto allocatedBarchartdto = new BarChartDto();
			for (GraphValuesDto val2 : graphListForCertificateIssued) {
				if (val1.getXAxis().equals(val2.getXAxis())) {
					allocatedBarchartdto.setMonth(val1.getXAxis());
					allocatedBarchartdto.setStockAllocated(val1.getYAxis());
					allocatedBarchartdto.setCertificateIssued(val2.getYAxis());
					list.add(allocatedBarchartdto);
					count++;

				}

			}
			if (count == 0) {
				allocatedBarchartdto.setMonth(val1.getXAxis());
				allocatedBarchartdto.setStockAllocated(val1.getYAxis());
				allocatedBarchartdto.setCertificateIssued(0l);
				list.add(allocatedBarchartdto);
			}
		}
		List<GraphValuesDto> listOneList = graphListForCertificateIssued.stream()
				.filter(two -> !graphListForStockAllocated.stream().anyMatch(one -> one.getXAxis().equals(two.getXAxis())))
				.collect(Collectors.toList());
		for (GraphValuesDto value : listOneList) {
			BarChartDto issuedBarchartdto = new BarChartDto();
			issuedBarchartdto.setMonth(value.getXAxis());
			issuedBarchartdto.setCertificateIssued(value.getYAxis());
			issuedBarchartdto.setStockAllocated(0l);
			list.add(issuedBarchartdto);
		}
	}


	/**
	 * @param dashBoardInputDto
	 * @param loggedInUser
	 * @param systemPropertyValueByPropertyId 
	 * @return
	 */
	private List<GraphValuesDto> getDataForInsCompanyCertificateIssued(DashBoardInputDto dashBoardInputDto,
			UserInfo loggedInUser, String systemPropertyValueByPropertyId) {
		List<GraphValuesDto> graphList2 = new ArrayList<>();
		if (ApplicationUtils.isValidateObject(systemPropertyValueByPropertyId)
				&& !systemPropertyValueByPropertyId.equalsIgnoreCase(ApplicationConstants.NONE)
				&& ApplicationUtils.isValidateObject(loggedInUser.getAllocationUserType())) {

			List<MonthCountDto> monthCertificateIssuedCount = dashBoardDao.getCertificateIssuedCountByMonth(
					dashBoardInputDto, loggedInUser.getCompanyId(), loggedInUser.getAllocationUserType());
			
			if (ApplicationUtils.isValidObject(dashBoardInputDto)) {
				for (MonthCountDto monthCountDto : monthCertificateIssuedCount) {
					GraphValuesDto grapthDto = new GraphValuesDto();
					for (Month month1 : Month.values()) {
						if (monthCountDto.getMonth() == (month1.getValue())) {
							String str = month1.toString().substring(0, 3);
							grapthDto.setXAxis(str);
							grapthDto.setYAxis(monthCountDto.getCount());
						}
					}
					graphList2.add(grapthDto);
				}
			} else {
				for (Month month2 : Month.values()) {
					GraphValuesDto grapthDto = new GraphValuesDto();
					String str = month2.toString().substring(0, 3);
					grapthDto.setXAxis(str);
					grapthDto.setYAxis(0l);
					for (MonthCountDto monthCountDto2 : monthCertificateIssuedCount) {
						if (monthCountDto2.getMonth() == (month2.ordinal() + 1)) {
							grapthDto.setYAxis(monthCountDto2.getCount());
						}
					}
					graphList2.add(grapthDto);
				}
			}
		} else {
			List<MonthCountDto> monthCertificateIssuedCount = dashBoardDao.getAllCompaniesCertificateIssuedCountByMonth(
					dashBoardInputDto, loggedInUser.getCompanyId());
			
			if (ApplicationUtils.isValidObject(dashBoardInputDto)) {
				for (MonthCountDto monthCountDto : monthCertificateIssuedCount) {
					GraphValuesDto grapthDto = new GraphValuesDto();
					for (Month month1 : Month.values()) {
						if (monthCountDto.getMonth() == (month1.getValue())) {
							String str = month1.toString().substring(0, 3);
							grapthDto.setXAxis(str);
							grapthDto.setYAxis(monthCountDto.getCount());
						}
					}
					graphList2.add(grapthDto);
				}
			} else {
				for (Month month2 : Month.values()) {
					GraphValuesDto grapthDto = new GraphValuesDto();
					String str = month2.toString().substring(0, 3);
					grapthDto.setXAxis(str);
					grapthDto.setYAxis(0l);
					for (MonthCountDto monthCountDto2 : monthCertificateIssuedCount) {
						if (monthCountDto2.getMonth() == (month2.ordinal() + 1)) {
							grapthDto.setYAxis(monthCountDto2.getCount());
						}
					}
					graphList2.add(grapthDto);
				}
			}
			
		}
		return graphList2;
	}

	/**
	 * @param dashBoardInputDto
	 * @param loggedInUser
	 * @param systemPropertyValueByPropertyId 
	 * @return
	 */
	private List<GraphValuesDto> getDataForInsCompanyStockAllocated(DashBoardInputDto dashBoardInputDto,
			UserInfo loggedInUser, String systemPropertyValueByPropertyId) {
		List<GraphValuesDto> graphList = new ArrayList<>();
		if (ApplicationUtils.isValidateObject(systemPropertyValueByPropertyId)
				&& !systemPropertyValueByPropertyId.equalsIgnoreCase(ApplicationConstants.NONE)
				&& ApplicationUtils.isValidateObject(loggedInUser.getAllocationUserType())) {
			
			List<MonthCountDto> monthCount = dashBoardDao.getStockAllocatedByAllocationUserType(dashBoardInputDto,
					loggedInUser.getCompanyId(), loggedInUser.getAllocationUserType());

			if (ApplicationUtils.isValidObject(dashBoardInputDto) && !dashBoardInputDto.getFilterType().equalsIgnoreCase(ApplicationConstants.YEAR)) {
				for (MonthCountDto monthCountDto : monthCount) {
					GraphValuesDto grapthDto = new GraphValuesDto();
					for (Month month1 : Month.values()) {
						if (monthCountDto.getMonth() == (month1.getValue())) {
							String str = month1.toString().substring(0, 3);
							grapthDto.setXAxis(str);
							grapthDto.setYAxis(monthCountDto.getCount());
						}
					}
					graphList.add(grapthDto);
				}
			} else if (!ApplicationUtils.isValidObject(dashBoardInputDto) || dashBoardInputDto.getFilterType().equalsIgnoreCase(ApplicationConstants.YEAR)) {
				for (Month month1 : Month.values()) {
					GraphValuesDto grapthDto = new GraphValuesDto();
					String str = month1.toString().substring(0, 3);
					grapthDto.setXAxis(str);
					grapthDto.setYAxis(0l);
					for (MonthCountDto monthCountDto : monthCount) {
						if (monthCountDto.getMonth() == (month1.ordinal() + 1)) {
							grapthDto.setYAxis(monthCountDto.getCount());
						}
					}
					graphList.add(grapthDto);
				}
			}
		} else {
			List<MonthCountDto> monthCount = dashBoardDao.getAllCompaniesBarChart(dashBoardInputDto,
					loggedInUser.getCompanyId());
			if (ApplicationUtils.isValidObject(dashBoardInputDto)) {
				for (MonthCountDto monthCountDto : monthCount) {
					GraphValuesDto grapthDto = new GraphValuesDto();
					for (Month month1 : Month.values()) {
						if (monthCountDto.getMonth() == (month1.getValue())) {
							String str = month1.toString().substring(0, 3);
							grapthDto.setXAxis(str);
							grapthDto.setYAxis(monthCountDto.getCount());
						}
					}
					graphList.add(grapthDto);
				}
			} else {
				for (Month month1 : Month.values()) {
					GraphValuesDto grapthDto = new GraphValuesDto();
					String str = month1.toString().substring(0, 3);
					grapthDto.setXAxis(str);
					grapthDto.setYAxis(0l);
					for (MonthCountDto monthCountDto : monthCount) {
						if (monthCountDto.getMonth() == (month1.ordinal() + 1)) {
							grapthDto.setYAxis(monthCountDto.getCount());
						}
					}
					graphList.add(grapthDto);
				}
			}
		}
		return graphList;
	}

	
	/**
	 * @param dashBoardInputDtoForAuthority
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public List<AuthorityBarChartDto> getBarChartForAuthority(DashBoardInputDto dashBoardInputDtoForAuthority)
			throws ApplicationException {
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		UserType userTypeId = loggedInUser.getUserTypeId();
		if (!userTypeId.getUserTypeName().equals(ApplicationConstants.ASSOCIATION)) {
			throw new ApplicationException(ErrorCodes.UN_AUTHORIZED);
		}
		
		
		List<FilterOrSortingVo> filterOrSortingVo = Collections.<FilterOrSortingVo>emptyList();
		List<CompanyDto> companyList = resttemplateService.getCompanyList(filterOrSortingVo);
		
		List<Integer> companyIdlist = companyList.stream().map(CompanyDto::getCompanyId).collect(Collectors.toList());
		List<AuthorityBarChartDto> authorityBarChartData = dashBoardDao.getauthorityBarChartata(companyIdlist,
				dashBoardInputDtoForAuthority);
		
		for (AuthorityBarChartDto barChartValue : authorityBarChartData) {
			
			Optional<CompanyDto> shortNameCompanyList =companyList.stream().filter(obj -> obj.getCompanyId() == barChartValue.getCompanyId()).findFirst();
			if(shortNameCompanyList.isPresent()) {
				shortNameCompanyList.get();
				barChartValue.setShortName(shortNameCompanyList.get().getShortName());
				barChartValue.setInsuredComapny(shortNameCompanyList.get().getName());
				}

		}
				return authorityBarChartData;
	}
	
	
	/**
	 * Gets the insurance dough nut chart data.
	 *
	 * @param boardInputDto the board input dto
	 * @return the insurance dough nut chart data
	 * @throws ApplicationException the application exception
	 */
	@Override
	public DoughNutDto getInsuranceDoughNutChartData(DashBoardInputDto boardInputDto) throws ApplicationException {

		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		
		if (!ApplicationUtils.isValidateObject(loggedInUser)) {
			throw new ApplicationException(ErrorCodes.INVALID_USER);
		}

		DoughNutDto datas = dashBoardDao.getStatusCount(loggedInUser.getCompanyId(), Boolean.FALSE,
				boardInputDto,loggedInUser.getAllocationUserType());
		
		if (!ApplicationUtils.isValidateObject(datas)) {
			throw new ApplicationException(ErrorCodes.INVALID_STATUS);
		}

		return datas;
	}

	/**
	 * Gets the association dough nut chart data.
	 *
	 * @param boardInputDto the board input dto
	 * @return the association dough nut chart data
	 * @throws ApplicationException the application exception
	 */
	@Override
	public DoughNutDto getAssociationDoughNutChartData(DashBoardInputDto boardInputDto) throws ApplicationException {

		DoughNutDto datas = dashBoardDao.getStatusCount(null, Boolean.TRUE, boardInputDto,null);

		if (!ApplicationUtils.isValidateObject(datas)) {
			throw new ApplicationException(ErrorCodes.INVALID_STATUS);
		}

		return datas;
	}
}
