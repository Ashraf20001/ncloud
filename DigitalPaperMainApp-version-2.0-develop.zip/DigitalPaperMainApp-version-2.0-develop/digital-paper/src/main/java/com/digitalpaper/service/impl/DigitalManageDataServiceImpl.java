package com.digitalpaper.service.impl;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.Column;
import javax.persistence.EntityManager;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.transaction.Transactional;

import org.apache.poi.ss.formula.functions.T;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.digitalpaper.adapter.service.EntityTableMappingFactory;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.dao.IDigitalImportExportDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.service.IDigitalManageDataService;
import com.digitalpaper.transfer.object.entity.TableEntityMapping;
import com.digitalpaper.utils.core.ApplicationUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * The Class DigitalManageDataServiceImpl.
 */
@Service
@Transactional
public class DigitalManageDataServiceImpl implements IDigitalManageDataService {

	
	
	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(DigitalManageDataServiceImpl.class);
	
	/** The i export import dao. */
	@Autowired
	private IDigitalImportExportDao iExportImportDao;
	
	/** The object mapper. */
	@Autowired
	ObjectMapper objectMapper;
	
	/** The entity manager. */
	@Autowired
	EntityManager entityManager;
	
	/** The entity table mapping factory. */
	@Autowired
	private EntityTableMappingFactory entityTableMappingFactory;

	/**
	 * Export master datas.
	 *
	 * @param masterDataDtoList the master data dto list
	 * @return the list
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	public List<Map<String, Object>> exportMasterDatas(List<String> masterDataDtoList) throws IOException {
		List<Map<String, Object>> listOfMasterData = new ArrayList<>();
		for (String tableName : masterDataDtoList.stream().distinct().collect(Collectors.toList())) {
			List<Map<String, Object>> entityDatas = iExportImportDao.getListOfMasterDatas(tableName);
			Map<String, Object> entityMap = new HashMap<>();
			entityMap.put("digital." + tableName, entityDatas);
			listOfMasterData.add(entityMap);
		}
		return listOfMasterData;
	}

	/**
	 * Import master data.
	 *
	 * @param recoveryMasterDataMap the recovery master data map
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws ApplicationException the application exception
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void importMasterData(Map<String, Object> recoveryMasterDataMap) throws IOException, ApplicationException {
		List<Map<String, Object>> recoveryMasterMapList = (List<Map<String, Object>>) recoveryMasterDataMap
				.get("platformTables");
		if(!ApplicationUtils.isValidList(recoveryMasterMapList)) {
			throw new ApplicationException(ErrorCodes.INVALID_MASTER_DATA);
		}
		Boolean isOverride = Boolean.parseBoolean(String.valueOf(recoveryMasterDataMap.get("isOverride")));
		ObjectMapper objectMapper = new ObjectMapper();
		List<TableEntityMapping> tableEntityMappings = objectMapper.convertValue(
		    recoveryMasterDataMap.get("tableEntity"),
		    new TypeReference<List<TableEntityMapping>>() {}
		);
		for (Map<String, Object> recoveryPlatformData : recoveryMasterMapList) {
			String keyTableName = recoveryPlatformData.entrySet().stream().map(Map.Entry::getKey)
					.map(key -> key.contains(".") ? key.substring(key.lastIndexOf(".") + 1) : key)
					.findFirst().orElse(null);
			List<String> parentTableNames = tableEntityMappings.stream().map(TableEntityMapping::getTableName)
					.map(a -> a.contains(".") ? a.substring(a.lastIndexOf(".") + 1) : a).collect(Collectors.toList());
			String tableName = recoveryPlatformData.keySet().stream()
					.map(key -> key.contains(".") ? key.substring(key.lastIndexOf(".") + 1) : key)
					.filter(key -> !parentTableNames.stream().anyMatch(key::contains)).findFirst().orElse(null);
			if (Boolean.FALSE.equals(isOverride)) {
				iExportImportDao.wipeAndInsterTableByTableName(keyTableName);
			}
			saveOrUpdateRecoveryMDM(isOverride, recoveryPlatformData, tableName);
		}
	}

	/**
	 * 
	 * @param isOverride
	 * @param recoveryPlatformData
	 * @param tableName
	 * @throws JsonProcessingException
	 * @throws JsonMappingException
	 * @throws ApplicationException
	 */
	private void saveOrUpdateRecoveryMDM(Boolean isOverride, Map<String, Object> recoveryPlatformData, String tableName)
			throws JsonProcessingException, JsonMappingException, ApplicationException {
		if (ApplicationUtils.isValidString(tableName)) {
			extractMasterDataAndSave(recoveryPlatformData, tableName, isOverride);
		} else {
			extractMasterTableWithJoinColumn(recoveryPlatformData,
					recoveryPlatformData.entrySet().stream().map(Map.Entry::getKey)
							.map(key -> key.contains(".") ? key.substring(key.lastIndexOf(".") + 1) : key)
							.findFirst().orElse(null),
					isOverride);
		}
	}

	/**
	 * save or update entity with join column
	 * @param insertMasterData
	 * @param tableName
	 * @param isOverride
	 * @throws JsonProcessingException
	 * @throws JsonMappingException
	 * @throws ApplicationException
	 */
	@SuppressWarnings("unchecked")
	private void extractMasterTableWithJoinColumn(Map<String, Object> insertMasterData, String tableName,
			Boolean isOverride) throws JsonProcessingException, JsonMappingException, ApplicationException {
		Class<T> entityName = entityTableMappingFactory.getEntityClassByTableName(tableName);
		String userRoleMapping = entityName.getSimpleName();
		String parentTable = insertMasterData.entrySet().stream().map(Map.Entry::getKey).findFirst().orElse(null);
		List<Object> entityDatas = (List<Object>) insertMasterData.get(parentTable);
		for (Object singleEntity : entityDatas) {
			Map<String, Object> childObject = new HashMap<>();
			List<Integer> childObjectIds = new ArrayList<>();
			Map<String, Object> castedData = (Map<String, Object>) singleEntity;
			Integer childObjectId = null;
			String joinColumnName = null;
			for (Field field : entityName.getDeclaredFields()) {
				//reflect to check Id annotation is present
				if (field.isAnnotationPresent(Id.class)) {
					Column tableFieldName = field.getAnnotation(Column.class);
					joinColumnName = tableFieldName.name();
					childObjectId = Integer.parseInt(castedData.get(joinColumnName).toString());
				}
				//reflect to check join column annotation is present
				if (field.isAnnotationPresent(JoinColumn.class)) {
					Class<T> refEntity = (Class<T>) field.getType();
					String columnName = ApplicationUtils.getPrimaryIdColumn(refEntity);
					String entityColumnNameParent = ApplicationUtils.getJoinColumnNameReflect(field);
					if (ApplicationUtils.isValidateObject(castedData.get(entityColumnNameParent))) {
						Integer joinPrimaryId = Integer.parseInt(castedData.get(entityColumnNameParent).toString());
						String childTableName = ApplicationUtils.getEntityName(refEntity);
						childObject = iExportImportDao.getMapResultByPrimaryId(childTableName, columnName,
								joinPrimaryId);
						Integer childPrimaryId = ApplicationUtils.isValidateObject(childObject)
								? Integer.parseInt(childObject.get(columnName).toString())
								: null;
						if(userRoleMapping.equals(ApplicationConstants.USER_ROLE_MAPPING)) {
							joinColumnName = columnName;
							childObjectId = joinPrimaryId;
						}
						childObjectIds.add(childPrimaryId);
						logger.info("Existing Join Column Object :: {}", childObject);
					}
				}
			}
			// check anyone of join column have invalid data
			Boolean ishaveNullChild = childObjectIds.stream().anyMatch(a -> a == null);
			if (Boolean.TRUE.equals(ishaveNullChild)) {
				continue;
			}
			saveOrUpdateMDM(tableName, isOverride, singleEntity, castedData, childObjectId, joinColumnName);
		}
	}
	
	/**
	 * 
	 * @param tableName
	 * @param isOverride
	 * @param singleEntity
	 * @param castedData
	 * @param childObjectId
	 * @param tableFieldName
	 * @throws ApplicationException
	 */
	private void saveOrUpdateMDM(String tableName, Boolean isOverride, Object singleEntity,
			Map<String, Object> castedData, Integer childObjectId, String joinColumnName) throws ApplicationException {
		Map<String, Object> existingValue;
		if (Boolean.TRUE.equals(isOverride)) {
			existingValue = iExportImportDao.getMapResultByPrimaryId(tableName, joinColumnName,
					childObjectId);
			if (ApplicationUtils.isValidateObject(existingValue)) {
				iExportImportDao.updateDynamicRecord(tableName, castedData, joinColumnName,
						existingValue.get(joinColumnName));
				logger.info("Override Existing data with updated Values:: {}", castedData);
			} else {
				iExportImportDao.saveMasterDataNativeQuery(castedData, tableName);
				logger.info("Override have insert data:: {}", castedData);
			}
		} else {
			iExportImportDao.saveMasterDataNativeQuery(castedData, tableName);
			logger.info("Insert Master Data with JoinTable ::{}", singleEntity);
		}
	}

	/**
	 * insert and update master data
	 * @param insertMasterData
	 * @param tableName
	 * @param isIdentity
	 * @param isOverride 
	 * @throws JsonProcessingException
	 * @throws JsonMappingException
	 * @throws ApplicationException
	 */
	@SuppressWarnings("unchecked")
	private void extractMasterDataAndSave(Map<String, Object> insertMasterData, String tableName, Boolean isOverride)
			throws JsonProcessingException, JsonMappingException, ApplicationException {
		Class<T> entityName = entityTableMappingFactory.getEntityClassByTableName(tableName);
		List<Map<String, Object>> recoveryListDatas = (List<Map<String, Object>>) insertMasterData
				.get("digital." + tableName);
		for (Map<String, Object> recoveryEntity : recoveryListDatas) {
			if (Boolean.TRUE.equals(isOverride)) {
				Map<String, Object> existingValue = new HashMap<>();
				String idColumnName = ApplicationConstants.EMPTY_STRING;
				Field idField = Arrays.stream(entityName.getDeclaredFields())
						.filter(field -> field.isAnnotationPresent(Id.class)).findFirst().orElse(null);
				if (ApplicationUtils.isValidateObject(idField)) {
					Column primaryIdTableColName = idField.getAnnotation(Column.class);
					idColumnName = primaryIdTableColName.name();
					existingValue = iExportImportDao.getMapResultByPrimaryId(tableName, idColumnName,
							Integer.parseInt(String.valueOf(recoveryEntity.get(idColumnName))));
					logger.info("Existing Data from Corresponding table :: {}", existingValue);
				}
				if (ApplicationUtils.isValidateObject(existingValue)) {
					iExportImportDao.updateDynamicRecord(tableName, recoveryEntity, idColumnName,
							existingValue.get(idColumnName));
					logger.info("Override MDM recovery :: {}", recoveryEntity);
				} else {
					iExportImportDao.saveMasterDataNativeQuery(recoveryEntity, tableName);
					logger.info("Override-Insert MDM recovery :: {}", recoveryEntity);
				}
			} else {
				logger.info("Insert MDM recovery :: {}", recoveryEntity);
				iExportImportDao.saveMasterDataNativeQuery(recoveryEntity, tableName);
			}
		}

	}
		
}
