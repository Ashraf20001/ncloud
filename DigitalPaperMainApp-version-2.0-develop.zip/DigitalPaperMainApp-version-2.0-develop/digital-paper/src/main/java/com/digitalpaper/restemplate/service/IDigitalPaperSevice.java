package com.digitalpaper.restemplate.service;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.FieldGroup;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;

/**
 * The Interface IDigitalPaperSevice.
 */
public interface IDigitalPaperSevice {

	/**
	 * Save digital paper.
	 *
	 * @param fieldGroup the field group
	 * @param request the request
	 * @param uploadType the upload type
	 * @param actionType the action type
	 * @return the string
	 * @throws ApplicationException the application exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	String saveDigitalPaper(FieldGroup fieldGroup, HttpServletRequest request,String uploadType, String actionType) throws ApplicationException, IOException;

	/**
	 * @param identity
	 * @return
	 * @throws ApplicationException
	 */
	PaperDetailsDto getpaperDetails(String identity) throws ApplicationException;

	/**
	 * Gets the list of login digital paper details.
	 *
	 * @return the list of login digital paper details
	 * @throws ApplicationException the application exception
	 */
	List<PaperDetailsDto> getListOfLoginDigitalPaperDetails() throws ApplicationException;

	/**
	 * Send data to email.
	 *
	 * @param paperId the paper id
	 * @param policyNumber the policy number
	 * @return the string
	 * @throws ApplicationException the application exception
	 */
	String sendDataToEmail(String paperId,String policyNumber) throws ApplicationException;

}
