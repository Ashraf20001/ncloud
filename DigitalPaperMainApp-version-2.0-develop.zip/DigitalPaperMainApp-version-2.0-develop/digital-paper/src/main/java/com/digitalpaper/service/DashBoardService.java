package com.digitalpaper.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.AuthorityBarChartDto;
import com.digitalpaper.transfer.object.dto.BarChartDto;
import com.digitalpaper.transfer.object.dto.DashBoardInputDto;
import com.digitalpaper.transfer.object.dto.DashBoardOutputDto;
import com.digitalpaper.transfer.object.dto.DoughNutDto;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;
import com.digitalpaper.transfer.object.dto.TopCompanyPurchaseDto;
import com.digitalpaper.transfer.object.dto.ViewHistoryDto;

/**
 * The Interface DashBoardService.
 */
public interface DashBoardService {

	
	/**
	 * @return
	 * @throws ApplicationException
	 */
	public List<PaperDetailsDto> getCompanyRecentDigitalPapers(DashBoardInputDto dashboardInputDto) throws ApplicationException;
	
	/**
	 * @return
	 * @throws ApplicationException
	 */
	public List<PaperDetailsDto> getCompanyExpiryDigitalPapers(DashBoardInputDto dashboardInputDto) throws ApplicationException;
	
	/**
	 * @return
	 * @throws ApplicationException
	 */
	public List<ViewHistoryDto> getAllCompaniesRecentTransaction(DashBoardInputDto dashboardInputDto) throws ApplicationException;
	
	/**
	 * @return
	 * @throws ApplicationException
	 */
	public List<PaperDetailsDto> getAllCompaniesRecentDigitalPapers(DashBoardInputDto dashboardInputDto) throws ApplicationException;
	
	/**
	 * @param dashBoardInputDto
	 * @return
	 * @throws ApplicationException
	 */
	public List<TopCompanyPurchaseDto> getTopPurchaseData(DashBoardInputDto dashBoardInputDto) throws ApplicationException;

	/**
	 * @return
	 * @throws ApplicationException
	 */
	public List<Integer> getAllCompanyIds() throws ApplicationException;

	/**
	 * @return
	 * @throws ApplicationException
	 */
	public List<Integer> getAllPaperCompanyIds() throws ApplicationException;

	/**
	 * Gets the prediction data.
	 *
	 * @return the prediction data
	 */
	DashBoardOutputDto getPredictionData();
	
	/**
	 * Gets the bar chart data for ins company.
	 *
	 * @param dashBoardInputDto the dash board input dto
	 * @param request the request
	 * @return the bar chart data for ins company
	 * @throws ApplicationException the application exception
	 */
	List<BarChartDto> getBarChartDataForInsCompany(DashBoardInputDto dashBoardInputDto, HttpServletRequest request) throws ApplicationException;

	/**
	 * @param dashBoardInputDtoForAuthority
	 * @return
	 * @throws ApplicationException
	 */
	List<AuthorityBarChartDto> getBarChartForAuthority(DashBoardInputDto dashBoardInputDtoForAuthority) throws ApplicationException;

	/**
	 * Gets the insurance dough nut chart data.
	 *
	 * @param dashboardInputDto the dashboard input dto
	 * @return the insurance dough nut chart data
	 * @throws ApplicationException the application exception
	 */
	public DoughNutDto getInsuranceDoughNutChartData(DashBoardInputDto dashboardInputDto) throws ApplicationException;

    /**
     * Gets the association dough nut chart data.
     *
     * @param boardInputDto the board input dto
     * @return the association dough nut chart data
     * @throws ApplicationException the application exception
     */
    public DoughNutDto getAssociationDoughNutChartData(DashBoardInputDto boardInputDto) throws ApplicationException;
}
