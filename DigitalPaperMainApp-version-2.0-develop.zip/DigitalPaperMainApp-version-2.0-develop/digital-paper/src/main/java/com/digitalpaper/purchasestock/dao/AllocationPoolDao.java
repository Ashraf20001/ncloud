package com.digitalpaper.purchasestock.dao;

import java.util.List;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.entity.Stock;
import com.digitalpaper.transfer.object.entity.StockPool;

/**
 * The Interface AllocationPoolDao.
 */
public interface AllocationPoolDao {

	/**
	 * Gets the stock by company id.
	 *
	 * @param companyId the company id
	 * @return the stock by company id
	 */
	Stock getStockByCompanyId(Integer companyId);

	/**
	 * Gets the stock pool by id.
	 *
	 * @param poolIdentity the pool identity
	 * @param companyId the company id
	 * @param isTrue the is true
	 * @return the stock pool by id
	 */
	StockPool getStockPoolById(Integer poolIdentity, Integer companyId, Boolean isTrue);

	/**
	 * Update stock.
	 *
	 * @param stock the stock
	 */
	void updateStock(Stock stock);

	/**
	 * Update stock pool.
	 *
	 * @param stockPool the stock pool
	 */
	void updateStockPool(StockPool stockPool);

	/**
	 * Gets the stock pool from identity.
	 *
	 * @param identity the identity
	 * @return the stock pool from identity
	 */
	StockPool getStockPoolFromIdentity(String identity);

	/**
	 * Gets the all stock pool list.
	 *
	 * @param listOfIds the list of ids
	 * @param companyId the company id
	 * @param filterPaginationVo the filter pagination vo
	 * @param min the min
	 * @param max the max
	 * @return the all stock pool list
	 * @throws ApplicationException the application exception
	 */
	List<StockPool> getAllStockPoolList(List<Integer> listOfIds, Integer companyId, List<FilterOrSortingVo> filterPaginationVo, Integer min, Integer max) throws ApplicationException;

}
