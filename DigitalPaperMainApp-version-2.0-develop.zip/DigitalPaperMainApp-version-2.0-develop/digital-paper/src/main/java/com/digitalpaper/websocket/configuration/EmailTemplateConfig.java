package com.digitalpaper.websocket.configuration;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.ui.freemarker.FreeMarkerConfigurationFactoryBean;

/**
 * The Class EmailTemplateConfig.
 */
@Configuration
@EnableKafka
public class EmailTemplateConfig {

	/**
	 * Factory bean.
	 *
	 * @return the free marker configuration factory bean
	 */
	@Primary
	@Bean 
	public FreeMarkerConfigurationFactoryBean factoryBean() {
		FreeMarkerConfigurationFactoryBean bean=new FreeMarkerConfigurationFactoryBean();
		bean.setTemplateLoaderPath("classpath:/tempplate");
		return bean;
	}
	
	/**
	 * Email topic.
	 *
	 * @return the new topic
	 */
	@Bean
    public NewTopic emailTopic() {
        return new NewTopic("email-topic", 1, (short) 1);
    }
}
