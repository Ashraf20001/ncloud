package com.digitalpaper.controller;

import lombok.Data;
import lombok.Setter;

public enum SequenceEnum {

	ORDER_SEQUENCE_ID("TN",9,"com.digitalpaper.transfer.object.entity.StockSequentGenerator"),
	PURCHASE_SEQUENCE_ID("PO",9,"com.digitalpaper.transfer.object.entity.PurchaseSequenceGenerator"),
	
	DIGITAL_PAPER_ID("DP",9,"com.digitalpaper.transfer.object.entity.DigitalPaperIdSequentGenerator"),
	COMPLAINTS_ID("CMP",9,"com.digitalpaper.transfer.object.entity.ComplaintSequenceGenerator");

	String prefix;
	int length;
	String entity;
	
	private SequenceEnum(String prefix, int length, String entity) {
		this.prefix = prefix;
		this.length=length;
		this.entity=entity;
	}
	
	public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public String getEntity() {
		return entity;
	}

	public void setEntity(String entity) {
		this.entity = entity;
	}
}
