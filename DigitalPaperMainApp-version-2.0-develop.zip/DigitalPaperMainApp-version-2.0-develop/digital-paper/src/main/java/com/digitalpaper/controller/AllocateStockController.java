package com.digitalpaper.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitalpaper.config.base.controller.BaseController;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.service.AllocationStockService;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.AllocationStockDto;
import com.digitalpaper.transfer.object.dto.StockCountDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class AllocateStockController.
 */
@RestController
public class AllocateStockController extends BaseController{

	/** The service. */
	@Autowired
	private AllocationStockService service;
	
	
	
	/**
	 * Save allocation stock details.
	 *
	 * @param allocatePaperData the allocate paper data
	 * @return the application response
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Allocation stock save",notes = "Endpoint serves to save the stock allocated for paper generation",response = ApplicationResponse.class)
	@PostMapping("/allocate-paper-save")
	public ApplicationResponse saveAllocationStockDetails(@ApiParam(value="Allocation stock dto payload") @RequestBody AllocationStockDto allocatePaperData) throws ApplicationException {
			 String saveAllocationStock = service.saveAllocationStock(allocatePaperData);
			return getApplicationResponse(saveAllocationStock);
		
	}
	
	/**
	 * Gets the stock count for allocation stock.
	 *
	 * @param companyId the company id
	 * @return the stock count for allocation stock
	 * @throws ApplicationException the application exception
	 * @returns 
	 */
	@ApiOperation(value = "Allocation stock count",notes="Get total number of stocks available for the company",response=StockCountDto.class)
	@GetMapping("/get-allocation-stock-count")
	public StockCountDto getStockCountForAllocationStock( @ApiParam(value = "Stock presented company Id",required = true)  @RequestParam (name="companyId") Integer companyId) throws ApplicationException {
		return service.getStockCountForAllocationStock(companyId);
		
	}

	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {
	}

}
