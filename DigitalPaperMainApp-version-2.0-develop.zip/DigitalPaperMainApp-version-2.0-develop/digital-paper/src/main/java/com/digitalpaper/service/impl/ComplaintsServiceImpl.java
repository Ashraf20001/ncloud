package com.digitalpaper.service.impl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.controller.SequenceEnum;
import com.digitalpaper.controller.SequenceGenerator;
import com.digitalpaper.dao.IComplaintsDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.service.IComplaintsService;
import com.digitalpaper.transfer.object.dto.ComplaintsDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.entity.Complaints;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;
import com.digitalpaper.utils.core.ApplicationUtils;

/**
 * The Class ComplaintsServiceImpl.
 */
@Service
@Transactional
public class ComplaintsServiceImpl implements IComplaintsService{

	/** The complaints dao. */
	@Autowired
	private IComplaintsDao complaintsDao;
	
	/** The sequence generator. */
	@Autowired
	private SequenceGenerator sequenceGenerator;
	
	/** The logged in user context holder. */
	@Autowired
	private LoggedInUserContextHolder loggedInUserContextHolder;
	
	/**
	 * Save complaints details.
	 *
	 * @param complaintsList the complaints list
	 * @return the string
	 * @throws ApplicationException the application exception
	 */
	@Override
	public String saveComplaintsDetails(ComplaintsDto complaintsList) throws ApplicationException {
		Complaints complaints = new Complaints();
		
		UserInfo userDetails = loggedInUserContextHolder.getLoggedInUser();
		Integer userId = userDetails.getId();
		String formattedDate = "";
		if(ApplicationUtils.isValidateObject(complaintsList)) {
			
			PaperDetails existingPaperDetails = complaintsDao.getdigitalPaperDetailsBasedOnEmailIdAndName(complaintsList.getName(),complaintsList.getEmailId());
			Complaints getCompaintsDetails = complaintsDao.getComplaintsDetails(complaintsList.getEmailId());
			
			saveComplaints(complaintsList, complaints, userId);
			
			String isComplaintsExistsMsg;
			if (ApplicationUtils.isValidObject(getCompaintsDetails)) {
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
				formattedDate = getCompaintsDetails.getCreatedDate().format(formatter);
				if (ApplicationUtils.isValidObject(existingPaperDetails)) {
					isComplaintsExistsMsg = ApplicationConstants.COMPLAINTS_ALREADY_REGISTERED_2 + ":"+" "
							+ existingPaperDetails.getVdRegistrationNumber() + " " + ApplicationConstants.ON_THIS + " "+ formattedDate;
				} else {
					isComplaintsExistsMsg = ApplicationConstants.COMPLAINTS_ALREADY_REGISTERED + ":" + formattedDate;
				}
				return isComplaintsExistsMsg;
			}

		}else {
			throw new ApplicationException(ErrorCodes.MANDATORY_FIELDS);
		}
		
		return ApplicationConstants.SUCCESS; 
	}

	/**
	 * Save complaints.
	 *
	 * @param complaintsList the complaints list
	 * @param complaints the complaints
	 * @param userId the user id
	 * @throws ApplicationException the application exception
	 */
	private void saveComplaints(ComplaintsDto complaintsList, Complaints complaints, Integer userId)
			throws ApplicationException {
		complaints.setComplaintType(complaintsList.getCompliantsType());
		complaints.setName(complaintsList.getName());
		complaints.setRemarks(complaintsList.getRemarks());	
		complaints.setCreatedBy(userId);
		
		String complainId = sequenceGenerator.generateSequence(SequenceEnum.COMPLAINTS_ID);
		complaints.setComplaintsId(complainId);
		
		complaints.setCreatedDate(LocalDateTime.now());
		
		String dateOfIncident = complaintsList.getDateOfIncident();			
		LocalDateTime dateTime = LocalDateTime.parse(dateOfIncident);
		
		complaints.setDateOfIncident(dateTime);
		complaints.setEmail_id(complaintsList.getEmailId());
		complaints.setModifiedBy(userId);
		complaints.setModifiedDate(LocalDateTime.now());
				
		complaintsDao.saveComplaintsDetails(complaints);
	}

	/**
	 * Gets the complaints details.
	 *
	 * @return the complaints details
	 * @throws ApplicationException the application exception
	 */
	@Override
	public List<ComplaintsDto> getComplaintsDetails() throws ApplicationException {
		UserInfo userInfo = loggedInUserContextHolder.getLoggedInUser();
		Integer userId = userInfo.getId();
		List<Complaints> complaints = new ArrayList<Complaints>();
		
		List<ComplaintsDto> complaintsDto = new ArrayList<ComplaintsDto>();
		
		complaints = complaintsDao.getComplaintsAllData(userId);
		if(ApplicationUtils.isValidateObject(complaints)) {
			for (Complaints data : complaints) {
				complaintsDto.add(convertEntityToDtoInComplaites(data));
			}
		}
		
		return complaintsDto;
	}

	/**
	 * Convert entity to dto in complaites.
	 *
	 * @param data the data
	 * @return the complaints dto
	 */
	private ComplaintsDto convertEntityToDtoInComplaites(Complaints data) {
		
		ComplaintsDto dto = new ComplaintsDto();
		
		dto.setCompliantsType(data.getComplaintType());
		dto.setDateOfIncident(data.getDateOfIncident().toString());
		dto.setEmailId(data.getEmail_id());
		dto.setName(data.getName());
		dto.setRemarks(data.getRemarks());
		dto.setComplaintsId(data.getComplaintsId());
		
		PaperDetails paperDetails = complaintsDao.getdigitalPaperDetailsBasedOnEmailIdAndName(data.getName(),data.getEmail_id());
		if(ApplicationUtils.isValidateObject(paperDetails)){
			dto.setDigitalPaperId(paperDetails.getPdDigitalPaperId());
		}
		
		return dto;
	}

}
