package com.digitalpaper.dao;

import java.time.LocalDate;
import java.util.List;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.entity.Customer;
import com.digitalpaper.transfer.object.entity.ForgetPassword;

/**
 * The Interface CustomerDao.
 */
public interface CustomerDao {

	/**
	 * Gets the customer details.
	 *
	 * @param min the min
	 * @param max the max
	 * @param filter the filter
	 * @param companyId the company id
	 * @return the customer details
	 * @throws ApplicationException the application exception
	 */
	public List<Customer> getCustomerDetails(Integer min, Integer max,List<FilterOrSortingVo> filter,Integer companyId) throws ApplicationException;

	/**
	 * Save customer.
	 *
	 * @param customer the customer
	 * @throws ApplicationException the application exception
	 */
	public void saveCustomer(Customer customer)throws ApplicationException;

	/**
	 * Gets the customer by email id.
	 *
	 * @param emailId the email id
	 * @return the customer by email id
	 */
	public Customer getCustomerByEmailId(String emailId);
	
	/**
	 * Gets the login customer.
	 *
	 * @param userId the user id
	 * @return the login customer
	 */
	public Customer getLoginCustomer(Integer userId);

	/**
	 * Update customer.
	 *
	 * @param customData the custom data
	 * @throws ApplicationException the application exception
	 */
	public void updateCustomer(Customer customData) throws ApplicationException;
	
	/**
	 * Gets the customer by identity.
	 *
	 * @param customerIdentity the customer identity
	 * @return the customer by identity
	 * @throws ApplicationException the application exception
	 */
	public Customer getCustomerByIdentity(String customerIdentity) throws ApplicationException;
	
	/**
	 * Gets the forget details by email id.
	 *
	 * @param today the today
	 * @param email the email
	 * @return the forget details by email id
	 */
	public List<ForgetPassword> getForgetDetailsByEmailId(LocalDate today, String email);

	/**
	 * Gets the customer id from login table.
	 *
	 * @param identity the identity
	 * @return the customer id from login table
	 */
	ForgetPassword getCustomerIdFromLoginTable(String identity);

	/**
	 * Save forget entry.
	 *
	 * @param forgetEntity the forget entity
	 */
	void saveForgetEntry(ForgetPassword forgetEntity);
	
	/**
	 * Gets the customer count.
	 *
	 * @param companyId the company id
	 * @param filter the filter
	 * @return the customer count
	 * @throws ApplicationException the application exception
	 */
	public Long getCustomerCount(Integer companyId,List<FilterOrSortingVo> filter) throws ApplicationException;
	
	/**
	 * Gets the customer details by email id.
	 *
	 * @param emailId the email id
	 * @return the customer details by email id
	 */
	public Customer getCustomerDetailsByEmailId(String emailId);

}
