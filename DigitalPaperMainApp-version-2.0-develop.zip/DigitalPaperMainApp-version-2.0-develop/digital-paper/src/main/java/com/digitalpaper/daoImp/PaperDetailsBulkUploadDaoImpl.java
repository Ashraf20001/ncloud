package com.digitalpaper.daoImp;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceUnit;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaDelete;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.digitalpaper.config.common.base.dao.BaseDao;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.PaperDetailsBulkUploadDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.transfer.object.entity.BulkImportErrorTable;
import com.digitalpaper.transfer.object.entity.BulkRevokeErrorTable;
import com.digitalpaper.transfer.object.entity.Customer;
import com.digitalpaper.transfer.object.entity.FileStorage;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.entity.Scratch;
import com.digitalpaper.transfer.object.entity.Stock;
import com.digitalpaper.transfer.object.entity.StockPool;

/**
 * The Class PaperDetailsBulkUploadDaoImpl.
 */
@Repository
@org.springframework.transaction.annotation.Transactional
public class PaperDetailsBulkUploadDaoImpl extends BaseDao implements PaperDetailsBulkUploadDao {
	
	/** The entity manager. */
	@PersistenceContext
	private EntityManager entityManager;
	
	/** The entity manager factory. */
	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;

	/**
	 * Save scratch data.
	 *
	 * @param scratch the scratch
	 * @return the integer
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Integer saveScratchData(Scratch scratch) throws ApplicationException {
		Integer scratchId = save(scratch, TableConstants.SCRATCH_TABLE_NAME);
		return scratchId;
		
	}

	

	/**
	 * Gets the paper details by policy number.
	 *
	 * @param policyNumber the policy number
	 * @return the paper details by policy number
	 */
	@Override
	public PaperDetails getPaperDetailsByPolicyNumber(String policyNumber) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
		Root<PaperDetails> root = criteria.from(PaperDetails.class);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.PD_POLICY_NUMBER), policyNumber)));
		return (PaperDetails) getSingleResult(createQuery(builder, criteria, root, predicates));
	}
	
	/**
	 * Gets the paper details based on policy no.
	 *
	 * @param policyNumber the policy number
	 * @return the paper details based on policy no
	 */
	@Override
	public List<PaperDetails> getPaperDetailsBasedOnPolicyNo(String policyNumber) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
		Root<PaperDetails> root = criteria.from(PaperDetails.class);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.PD_POLICY_NUMBER), policyNumber)));
		return (List<PaperDetails> ) getResultList(createQuery(builder, criteria, root, predicates));
	}
		
	
	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {		
	}



	/**
	 * Save bulk import error data.
	 *
	 * @param bulkImportErrorTable the bulk import error table
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void saveBulkImportErrorData(BulkImportErrorTable bulkImportErrorTable) throws ApplicationException {
		save(bulkImportErrorTable, TableConstants.ERROR_TABLE);
		
	}



	/**
	 * Save paper details.
	 *
	 * @param paperDetail the paper detail
	 * @param stockPool the stock pool
	 * @param type the type
	 * @param stock the stock
	 * @return the integer
	 * @throws ApplicationException the application exception
	 */
	@Override
	@org.springframework.transaction.annotation.Transactional(rollbackFor = ApplicationException.class)
	public Integer savePaperDetails(PaperDetails paperDetail, StockPool stockPool, String type, Stock stock) throws ApplicationException {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = null;
		Integer paperId = 0;
		try {
		transaction = entityManager.getTransaction();
		transaction.begin();
			// updating stock pool
		if (type.equals(ApplicationConstants.ALLOCATION_TYPE_1)) {
			CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
			CriteriaUpdate<StockPool> criteriaUpdate = criteriaBuilder.createCriteriaUpdate(StockPool.class);
			Root<StockPool> root = criteriaUpdate.from(StockPool.class);
			criteriaUpdate.set(root.get(TableConstants.USED_COUNT), stockPool.getUsedCount() + ApplicationConstants.ONE);
			Predicate condition = criteriaBuilder.and(
					criteriaBuilder.greaterThan(root.get(TableConstants.STOCK_COUNT),
							root.get(TableConstants.USED_COUNT)),
					criteriaBuilder.equal(root.get(TableConstants.STOCK_POOL_ID), stockPool.getStockPoolId())
			);
			criteriaUpdate.where(condition);
			int rowCount = entityManager.createQuery(criteriaUpdate).executeUpdate();
			if (rowCount==0) {
				throw new Exception();
			}
		}else if(type.equals(ApplicationConstants.ALLOCATION_TYPE_2)){
			CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
			CriteriaUpdate<Stock> criteriaUpdate = criteriaBuilder.createCriteriaUpdate(Stock.class);
			Root<Stock> root = criteriaUpdate.from(Stock.class);
			criteriaUpdate.set(root.get(TableConstants.USED_COUNT), stock.getUsedCount() + ApplicationConstants.ONE);
			Predicate condition = criteriaBuilder.and(
					criteriaBuilder.greaterThan(root.get(TableConstants.STOCK_COUNT),
							root.get(TableConstants.USED_COUNT)),
					criteriaBuilder.equal(root.get(TableConstants.STOCK_ID), stock.getStockId())
			);
			criteriaUpdate.where(condition);
			int rowCount = entityManager.createQuery(criteriaUpdate).executeUpdate();
			if (rowCount==0) {
				throw new ApplicationException(ErrorCodes.PAPER_GENERATION_FAILED);
			}
		}
			
			// saving paper
			paperId = save(paperDetail, TableConstants.ERROR_TABLE);
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			if (transaction.isActive()) {
				transaction.rollback();
				throw new ApplicationException(ErrorCodes.PAPER_GENERATION_FAILED);
			}
		}finally {
			entityManager.close();
		}
		return paperId;

	}


	/**
	 * Check for duplicate policy number.
	 *
	 * @param pdPolicyNumber the pd policy number
	 * @param status the status
	 * @return the paper details
	 */
	@Override
	public PaperDetails checkForDuplicatePolicyNumber(String pdPolicyNumber,Integer status) {
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
        Root<PaperDetails> root = criteria.from(PaperDetails.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.POLICY_NUMBER), pdPolicyNumber)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.PD_STATUS), status)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        PaperDetails paperDetails = (PaperDetails) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);
        return paperDetails;
	}


	/**
	 * Check duplicate registration number or chassis number.
	 *
	 * @param vdRegistrationNumber the vd registration number
	 * @param vdChassisNumber the vd chassis number
	 * @param status the status
	 * @return the list
	 */
	@Override
	public List<PaperDetails> checkDuplicateRegistrationNumberOrChassisNumber(String vdRegistrationNumber, String vdChassisNumber,Integer status) {
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
        Root<PaperDetails> root = criteria.from(PaperDetails.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.or(builder.equal(root.get(TableConstants.CHASIS_NUMBER), vdChassisNumber),
        		builder.equal(root.get(TableConstants.REGISTRATION_NUMBER), vdRegistrationNumber)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.PD_STATUS), status)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        List<PaperDetails> paperDetailsList = (List<PaperDetails>) getResultList(createQuery(builder, criteria, root, predicates));
		return paperDetailsList;
	}



	/**
	 * Gets the stock pool by allocation id.
	 *
	 * @param companyId the company id
	 * @param allocationUserType the allocation user type
	 * @return the stock pool by allocation id
	 */
	@Override
	public StockPool getStockPoolByAllocationId(Integer companyId, Integer allocationUserType) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<StockPool> criteria = builder.createQuery(StockPool.class);
		Root<StockPool> root = criteria.from(StockPool.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.USER_TYPE_ID), allocationUserType)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.COMPANY_ID), companyId)));
		return (StockPool) getSingleResult(createQuery(builder, criteria, root, predicates));
	}



	/**
	 * Update stock pool.
	 *
	 * @param stockPool the stock pool
	 * @return true, if successful
	 */
	@Override
	public boolean updateStockPool(StockPool stockPool){
		
			CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
			CriteriaUpdate<StockPool> criteriaUpdate = criteriaBuilder.createCriteriaUpdate(StockPool.class);
			Root<StockPool> root = criteriaUpdate.from(StockPool.class);
			criteriaUpdate.set(root.get(TableConstants.USED_COUNT), stockPool.getUsedCount() + ApplicationConstants.ONE);

			Predicate condition = criteriaBuilder.and(
			    criteriaBuilder.greaterThan(root.get(TableConstants.STOCK_COUNT), root.get(TableConstants.USED_COUNT)),
			    criteriaBuilder.equal(root.get(TableConstants.STOCK_POOL_ID), stockPool.getStockPoolId() )
			);
			criteriaUpdate.where(condition);
			int rowCount = entityManager.createQuery(criteriaUpdate).executeUpdate();
			boolean updated = rowCount > 0;
			return updated;
		
	}



	/**
	 * Gets the paper details by digital paper id.
	 *
	 * @param paperId the paper id
	 * @return the paper details by digital paper id
	 */
	@Override
	public PaperDetails getPaperDetailsByDigitalPaperId(String paperId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
		Root<PaperDetails> root = criteria.from(PaperDetails.class);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.PD_DIGITAL_PAPER_ID), paperId)));
		return (PaperDetails) getSingleResult(createQuery(builder, criteria, root, predicates));
	}



	/**
	 * Update digital paper.
	 *
	 * @param paperDetails the paper details
	 */
	@Override
	public void updateDigitalPaper(PaperDetails paperDetails) {
		update(paperDetails);
		
	}



	/**
	 * Save bulk revoke error table.
	 *
	 * @param errorTable the error table
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void saveBulkRevokeErrorTable(BulkRevokeErrorTable errorTable) throws ApplicationException {
		save(errorTable, TableConstants.BULK_REVOKE_ERROR_TABLE);
		
	}

	/**
	 * Update stock.
	 *
	 * @param stock the stock
	 * @return true, if successful
	 */
	@Override
	public boolean updateStock(Stock stock) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaUpdate<Stock> criteriaUpdate = criteriaBuilder.createCriteriaUpdate(Stock.class);
		Root<Stock> root = criteriaUpdate.from(Stock.class);
		criteriaUpdate.set(root.get(TableConstants.USED_COUNT), stock.getUsedCount());
		Predicate condition = criteriaBuilder.and(
				criteriaBuilder.greaterThan(root.get(TableConstants.STOCK_COUNT), root.get(TableConstants.USED_COUNT)),
				criteriaBuilder.equal(root.get(TableConstants.STOCK_ID), stock.getStockId()));
		criteriaUpdate.where(condition);
		int rowCount = entityManager.createQuery(criteriaUpdate).executeUpdate();
		boolean isUpdated = rowCount > ApplicationConstants.ZERO;
		return isUpdated;
	}



	/**
	 * Gets the file storage data by paper id.
	 *
	 * @param listOfId the list of id
	 * @return the file storage data by paper id
	 * @throws ApplicationException the application exception
	 */
	@Override
	public List<FileStorage> getFileStorageDataByPaperId(List<Integer> listOfId) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<FileStorage> criteria = builder.createQuery(FileStorage.class);
		Root<FileStorage> root = criteria.from(FileStorage.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
	
		predicates.add(builder.and(root.get(TableConstants.REF_ID).in(listOfId)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.RP_TYPE),ApplicationConstants.RP_TYPE)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.UPLOAD_TYPE),ApplicationConstants.UPD_TYPE)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		return (List<FileStorage>) getResultList(createQuery(builder, criteria, root, predicates));
	}



	/**
	 * Check for duplicate chassis number.
	 *
	 * @param vdChassisNumber the vd chassis number
	 * @param status the status
	 * @return the paper details
	 */
	@Override
	public PaperDetails checkForDuplicateChassisNumber(String vdChassisNumber, Integer status) {
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
        Root<PaperDetails> root = criteria.from(PaperDetails.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.CHASIS_NUMBER), vdChassisNumber)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.PD_STATUS), status)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        PaperDetails paperDetails = (PaperDetails) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);
        return paperDetails;
	}
	
	/**
	 * Gets the customer by email id.
	 *
	 * @param emailId the email id
	 * @return the customer by email id
	 */
	@Override
	public Customer getCustomerByEmailId(String emailId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Customer> createQuery = builder.createQuery(Customer.class);
		Root<Customer> root = createQuery.from(Customer.class);
		createQuery.select(root);
		List<Predicate> predicates=new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.EMAIL), emailId)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.STATUS), true)));
		return (Customer) getSingleResult(createQuery(builder, createQuery, root, predicates));
	}


	/**
	 * Delete paper details.
	 *
	 * @param paperDetail the paper detail
	 */
	@Override
	public void deletePaperDetails(PaperDetails paperDetail) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaDelete<PaperDetails> createQuery = builder.createCriteriaDelete(PaperDetails.class);
		Root<PaperDetails> root = createQuery.from(PaperDetails.class);
		createQuery.where(builder.equal(root.get(TableConstants.PAPER_ID), paperDetail.getPaperId()));
		getSession().createQuery(createQuery).executeUpdate();
	}



	/**
	 * Retrieve stock count.
	 *
	 * @param stockPool the stock pool
	 * @param type the type
	 * @param stock the stock
	 */
	@Override
	public void retrieveStockCount(StockPool stockPool, String type, Stock stock) {
		if (type.equals(ApplicationConstants.ALLOCATION_TYPE_1)) {
			CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
			CriteriaUpdate<StockPool> criteriaUpdate = criteriaBuilder.createCriteriaUpdate(StockPool.class);
			Root<StockPool> root = criteriaUpdate.from(StockPool.class);
			criteriaUpdate.set(root.get(TableConstants.USED_COUNT), stockPool.getUsedCount());
			criteriaUpdate.set(root.get(TableConstants.STOCK_COUNT), stockPool.getStockCount());
			Predicate condition = criteriaBuilder.and(
					criteriaBuilder.equal(root.get(TableConstants.STOCK_POOL_ID), stockPool.getStockPoolId())
			);
			criteriaUpdate.where(condition);
			entityManager.createQuery(criteriaUpdate).executeUpdate();
		}else if(type.equals(ApplicationConstants.ALLOCATION_TYPE_2)){
			CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
			CriteriaUpdate<Stock> criteriaUpdate = criteriaBuilder.createCriteriaUpdate(Stock.class);
			Root<Stock> root = criteriaUpdate.from(Stock.class);
			criteriaUpdate.set(root.get(TableConstants.USED_COUNT), stock.getUsedCount());
			criteriaUpdate.set(root.get(TableConstants.STOCK_COUNT), stock.getStockCount());
			Predicate condition = criteriaBuilder.and(
					criteriaBuilder.equal(root.get(TableConstants.STOCK_ID), stock.getStockId())
			);
			criteriaUpdate.where(condition);
			entityManager.createQuery(criteriaUpdate).executeUpdate();
		}
		
	}



	/**
	 * Gets the digital paper data list by email id.
	 *
	 * @param pdEmailId the pd email id
	 * @param companyId the company id
	 * @return the digital paper data list by email id
	 */
	@Override
	public List<PaperDetails> getDigitalPaperDataListByEmailId(String pdEmailId, Integer companyId) {
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
        Root<PaperDetails> root = criteria.from(PaperDetails.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.PD_EMAIL_ID), pdEmailId)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.COMPANY_ID), companyId)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.STATUS), 1)));
		List<PaperDetails> paperDetails = ( List<PaperDetails>) getResultList(createQuery(builder, criteria, root, predicates));
		return paperDetails;
	}





}
