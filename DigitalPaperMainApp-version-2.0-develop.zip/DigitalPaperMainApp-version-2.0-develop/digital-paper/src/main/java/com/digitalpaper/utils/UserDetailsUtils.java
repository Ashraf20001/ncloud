package com.digitalpaper.utils;

/**
 * The Class UserDetailsUtils.
 */
public class UserDetailsUtils {

}
