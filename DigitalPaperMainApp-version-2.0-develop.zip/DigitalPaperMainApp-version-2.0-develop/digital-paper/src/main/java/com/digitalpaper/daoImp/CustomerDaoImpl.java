package com.digitalpaper.daoImp;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.digitalpaper.config.common.base.dao.BaseDao;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.controller.CustomerController;
import com.digitalpaper.dao.CustomerDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.entity.Customer;
import com.digitalpaper.transfer.object.entity.ForgetPassword;

/**
 * The Class CustomerDaoImpl.
 */
@Repository
public class CustomerDaoImpl extends BaseDao implements CustomerDao {
	
	/**
	 * Logger
	 */
	private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);

	/**
	 * Gets the customer details.
	 *
	 * @param min the min
	 * @param max the max
	 * @param filter the filter
	 * @param companyId the company id
	 * @return the customer details
	 * @throws ApplicationException the application exception
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Customer> getCustomerDetails(Integer min,Integer max,List<FilterOrSortingVo> filter,Integer companyId) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Customer> createQuery = builder.createQuery(Customer.class);
		Root<Customer> root = createQuery.from(Customer.class);
		createQuery.select(root);
		List<Predicate> predicates=new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.COMPANY_ID), companyId)));
		List<Predicate> filterPrdicets = getFilterPrdicets(filter, root, builder, createQuery);
		predicates.addAll(filterPrdicets);
		return (List<Customer>) getResultList(createQuery(builder, createQuery, root, predicates).setFirstResult(min).setMaxResults(max));
	}
	
	/**
	 * Gets the customer count.
	 *
	 * @param companyId the company id
	 * @param filter the filter
	 * @return the customer count
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Long getCustomerCount(Integer companyId, List<FilterOrSortingVo> filter) throws ApplicationException {
		
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> createQuery = builder.createQuery(Long.class);
		Root<Customer> root = createQuery.from(Customer.class);
		createQuery.select(builder.count(root));
		List<Predicate> predicates=new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.COMPANY_ID), companyId)));
		List<Predicate> filterPrdicets = getFilterPrdicets(filter, root, builder, createQuery);
		predicates.addAll(filterPrdicets);
		return (Long) getSingleResult(createQuery(builder, createQuery, root, predicates));
	}
	

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {

	}

	/**
	 * Save customer.
	 *
	 * @param customer the customer
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void saveCustomer(Customer customer) throws ApplicationException {
		save(customer,TableConstants.CUSTOMER_TABLE);
	}

	/**
	 * Gets the login customer.
	 *
	 * @param userId the user id
	 * @return the login customer
	 */
	@Override
	public Customer getLoginCustomer(Integer userId) {

		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Customer> createQuery = builder.createQuery(Customer.class);
		Root<Customer> root = createQuery.from(Customer.class);
		createQuery.select(root);
		List<Predicate> predicates=new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.CUSTOMER_ID), userId)));
		return (Customer) getSingleResult(createQuery(builder, createQuery, root, predicates));
	}

	/**
	 * Update customer.
	 *
	 * @param customData the custom data
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void updateCustomer(Customer customData) throws ApplicationException {

		update(customData);

	}
	
	/**
	 * Gets the customer by email id.
	 *
	 * @param emailId the email id
	 * @return the customer by email id
	 */
	public Customer getCustomerByEmailId(String emailId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Customer> createQuery = builder.createQuery(Customer.class);
		Root<Customer> root = createQuery.from(Customer.class);
		createQuery.select(root);
		List<Predicate> predicates=new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.EMAIL), emailId)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.STATUS), true)));
		return (Customer) getSingleResult(createQuery(builder, createQuery, root, predicates));
	}

	/**
	 * Gets the customer by identity.
	 *
	 * @param customerIdentity the customer identity
	 * @return the customer by identity
	 */
	@Override
	public Customer getCustomerByIdentity(String customerIdentity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Customer> createQuery = builder.createQuery(Customer.class);
		Root<Customer> root = createQuery.from(Customer.class);
		createQuery.select(root);
		List<Predicate> predicates=new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IDENTITY), customerIdentity)));
		return (Customer) getSingleResult(createQuery(builder, createQuery, root, predicates));
		
	}

	/**
	 * Gets the forget details by email id.
	 *
	 * @param today the today
	 * @param email the email
	 * @return the forget details by email id
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<ForgetPassword> getForgetDetailsByEmailId(LocalDate today, String email) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<ForgetPassword> createQuery = builder.createQuery(ForgetPassword.class);
		Root<ForgetPassword> root = createQuery.from(ForgetPassword.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get("createdAt"), today)));
        predicates.add(builder.and(builder.equal(root.get("emailId"), email)));
		return (List<ForgetPassword>) getResultList(createQuery(builder, createQuery, root, predicates));
	}
	
	/**
	 * Gets the customer id from login table.
	 *
	 * @param identity the identity
	 * @return the customer id from login table
	 */
	@Override
	public ForgetPassword getCustomerIdFromLoginTable(String identity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<ForgetPassword> criteria = builder.createQuery(ForgetPassword.class);
		Root<ForgetPassword> root = criteria.from(ForgetPassword.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IDENTITY), identity)));
		ForgetPassword singleResult = (ForgetPassword) getSingleResult(createQuery(builder, criteria, root, predicates));
		return singleResult;
		
	}
	
	/**
	 * Save forget entry.
	 *
	 * @param forgetEntity the forget entity
	 */
	@Override
	public void saveForgetEntry(ForgetPassword forgetEntity) {
		try {
			save(forgetEntity,TableConstants.FORGET_EMAIL);
		} catch (ApplicationException e) {
			logger.error("Error  in AuthDaoImpl saveForgetEntity() ", e);
		}
	}

	/**
	 * Gets the customer details by email id.
	 *
	 * @param emailId the email id
	 * @return the customer details by email id
	 */
	@Override
	public Customer getCustomerDetailsByEmailId(String emailId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Customer> createQuery = builder.createQuery(Customer.class);
		Root<Customer> root = createQuery.from(Customer.class);
		createQuery.select(root);
		List<Predicate> predicates=new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.EMAIL), emailId)));
		return (Customer) getSingleResult(createQuery(builder, createQuery, root, predicates));
	}


	

}
