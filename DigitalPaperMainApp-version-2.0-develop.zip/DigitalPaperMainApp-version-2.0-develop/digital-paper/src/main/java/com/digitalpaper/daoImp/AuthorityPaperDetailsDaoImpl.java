package com.digitalpaper.daoImp;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Selection;

import org.springframework.stereotype.Repository;

import com.digitalpaper.config.common.base.dao.BaseDao;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.IAuthorityPaperDetailsDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.CompanyTransactionDto;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.entity.Stock;
import com.digitalpaper.utils.core.ApplicationUtils;

/**
 * The Class AuthorityPaperDetailsDaoImpl.
 */
@Repository
public class AuthorityPaperDetailsDaoImpl extends BaseDao implements IAuthorityPaperDetailsDao {

	/**
	 * Gets the paper details count by company.
	 *
	 * @param companyTransactionDto the company transaction dto
	 * @param searchValue the search value
	 * @param companyId the company id
	 * @return the paper details count by company
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Long getPaperDetailsCountByCompany(CompanyTransactionDto companyTransactionDto, String searchValue, List<Integer> companyId) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<PaperDetails> root = criteria.from(PaperDetails.class);
		criteria.select(builder.count(root));
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		if (!companyTransactionDto.getCompanyId().isEmpty()) {
			Expression expression = root.get(TableConstants.COMPANY_ID);
			Predicate predicateForId = expression.in(companyTransactionDto.getCompanyId());
			predicates.add(builder.and(predicateForId));
		}
		if(ApplicationUtils.isValidString(companyTransactionDto.getView())) {
			predicates.add(builder.and(builder.equal(root.get(TableConstants.STATUS),1)));
		}
		if (ApplicationUtils.isValidString(searchValue) && !ApplicationUtils.isValidateObject(companyId)) {
			predicates.add(builder.or(builder.like( 
	                builder.concat(root.get(TableConstants.PD_DIGITAL_PAPER_ID), 
	                builder.concat(root.get(TableConstants.PD_POLICY_NUMBER),	
	                builder.concat(root.get(TableConstants.REGISTRATION_NUMBER),	
	               (root.get(TableConstants.PD_INSURED_NAME))))
	                ),"%"+searchValue+"%")));
			
		}
		if(ApplicationUtils.isValidateObject(companyId)){			
			Expression expression2 = root.get(TableConstants.COMPANY_ID);
			Predicate predicateForCompanyId = expression2.in(companyId);
			predicates.add(builder.and(predicateForCompanyId));
		}
		predicates.addAll(getFilterPrdicets(companyTransactionDto.getFilter(), root, builder, criteria));
		return (Long) getSingleResult(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
		
	}

	/**
	 * Gets the paper details by company list.
	 *
	 * @param companyTransactionList the company transaction list
	 * @param searchValue the search value
	 * @param companyId the company id
	 * @return the paper details by company list
	 * @throws ApplicationException the application exception
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<PaperDetails> getPaperDetailsByCompanyList(CompanyTransactionDto companyTransactionList, String searchValue, List<Integer> companyId)
			throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
		Root<PaperDetails> root = criteria.from(PaperDetails.class);
		List<Predicate> predicates = new ArrayList<Predicate>();
		String viewType = companyTransactionList.getView();
		Boolean isSort=false;
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		if (!companyTransactionList.getCompanyId().isEmpty()) {
			Expression expression = root.get(TableConstants.COMPANY_ID);
			Predicate predicateForId = expression.in(companyTransactionList.getCompanyId());
			predicates.add(builder.and(predicateForId));
		}
		if(ApplicationUtils.isValidList(companyTransactionList.getFilter())) {
			isSort = companyTransactionList.getFilter().stream().anyMatch(el->el.getFilterOrSortingType().equals(ApplicationConstants.SORTING));
		}
		if(ApplicationUtils.isValidString(viewType)) {
			predicates.add(builder.and(builder.equal(root.get(TableConstants.STATUS),1)));
			if(!isSort) {
				criteria.orderBy(builder.desc(root.get(TableConstants.CREATED_DATE)));
			}
		}
		if (ApplicationUtils.isValidString(searchValue) && !ApplicationUtils.isValidateObject(companyId)) {
			predicates.add(builder.or(builder.like( 
	                builder.concat(root.get(TableConstants.PD_DIGITAL_PAPER_ID), 
	                builder.concat(root.get(TableConstants.PD_POLICY_NUMBER),	
	                builder.concat(root.get(TableConstants.REGISTRATION_NUMBER),	
	               (root.get(TableConstants.PD_INSURED_NAME))))
	                ),"%"+searchValue+"%")));
			
		}
		if(ApplicationUtils.isValidateObject(companyId)){			
			Expression expression2 = root.get(TableConstants.COMPANY_ID);
			Predicate predicateForCompanyId = expression2.in(companyId);
			predicates.add(builder.and(predicateForCompanyId));
		}
		if (ApplicationUtils.isValidList(companyTransactionList.getFilter())) {

			if (isSort) {
				List<FilterOrSortingVo> sortingFilterList = companyTransactionList.getFilter();
				FilterOrSortingVo filterSort = companyTransactionList.getFilter().stream()
						.filter(filter -> filter.getColumnName().equals(ApplicationConstants.COMPANYNAME)).findFirst()
						.orElse(null);
				if (ApplicationUtils.isValidateObject(filterSort)) {
					sortingFilterList = companyTransactionList.getFilter().stream()
							.filter(filter -> !filter.getColumnName().equals(ApplicationConstants.COMPANYNAME))
							.collect(Collectors.toList());
					boolean direction = filterSort.isAscending();
					if (direction == true) {
						criteria.orderBy(builder.asc(root.get(TableConstants.COMPANY_ID)));
					} else {
						criteria.orderBy(builder.desc(root.get(TableConstants.COMPANY_ID)));
					}
				}
				
				predicates.addAll(getFilterPrdicets(sortingFilterList, root, builder, criteria));
			} else {
				predicates.addAll(getFilterPrdicets(companyTransactionList.getFilter(), root, builder, criteria));
			}
			if (!isSort) {
				criteria.orderBy(builder.desc(root.get(TableConstants.MODIFIED_DATE)));
			}

		}
		else if (!ApplicationUtils.isValidString(viewType)) {
			criteria.orderBy(builder.desc(root.get(TableConstants.MODIFIED_DATE)));
		}
		

		return (List<PaperDetails>) getResultList(createQuery(builder, criteria, root, predicates)
				.setFirstResult(companyTransactionList.getMin()).setMaxResults(companyTransactionList.getMax()));
	}

	/**
	 * Gets the paper details list.
	 *
	 * @param entityColumnNames the entity column names
	 * @param companyId the company id
	 * @param filterVo the filter vo
	 * @param searchValue the search value
	 * @param matchingKey the matching key
	 * @return the paper details list
	 * @throws ApplicationException the application exception
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getPaperDetailsList(List<String> entityColumnNames,List<Integer> companyId, List<FilterOrSortingVo> filterVo,
			String searchValue, List<Integer> matchingKey) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Object[]> criteria = builder.createQuery(Object[].class);
		Root<PaperDetails> root = criteria.from(PaperDetails.class);
		
		
		List <Selection<?>> selections = new ArrayList<>();
		for(String column : entityColumnNames) {
			selections.add(root.get(column));
		}
		criteria.multiselect(selections);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		
		Expression expression = root.get(TableConstants.COMPANY_ID);
		Predicate predicateForId = expression.in(companyId);
		predicates.add(builder.and(predicateForId));
		
		if (ApplicationUtils.isValidString(searchValue) && !ApplicationUtils.isValidateObject(matchingKey)) {
			predicates.add(builder.or(builder.like( 
	                builder.concat(root.get(TableConstants.PD_DIGITAL_PAPER_ID), 
	                builder.concat(root.get(TableConstants.PD_POLICY_NUMBER),	
	                builder.concat(root.get(TableConstants.REGISTRATION_NUMBER),	
	               (root.get(TableConstants.PD_INSURED_NAME))))
	                ),"%"+searchValue+"%")));
		}
		if(ApplicationUtils.isValidateObject(matchingKey)){			
			Expression expression2 = root.get(TableConstants.COMPANY_ID);
			Predicate predicateForCompanyId = expression2.in(matchingKey);
			predicates.add(builder.and(predicateForCompanyId));
		}
		
		if (ApplicationUtils.isValidList(filterVo)) {
			for (FilterOrSortingVo filterSort : filterVo) {
				if (filterSort.getColumnName().equals(ApplicationConstants.COMPANYNAME)) {
					String columnName = filterSort.getColumnName();
					boolean direction = filterSort.isAscending();
					if (direction == true) {
						criteria.orderBy(builder.asc(root.get(TableConstants.COMPANY_ID)));
					} else {
						criteria.orderBy(builder.desc(root.get(TableConstants.COMPANY_ID)));
					}
				} else {
					predicates.addAll(getFilterPrdicets(filterVo, root, builder, criteria));
				}

			}
		}

		if(ApplicationUtils.isValidList(filterVo)){
			if(filterVo.stream().noneMatch(filterVo1->filterVo1.getFilterOrSortingType().equals(ApplicationConstants.SORTING))){
				criteria.orderBy(builder.desc(root.get(TableConstants.MODIFIED_DATE)));
			}
		} else {
			criteria.orderBy(builder.desc(root.get(TableConstants.MODIFIED_DATE)));
		}
		return(List<Object[]>) getResultList(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Gets the stock table count.
	 *
	 * @return the stock table count
	 */
	@Override
	public Long getStockTableCount() {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<Stock> root = criteria.from(Stock.class);
		criteria.select(builder.count(root));
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		return (Long) getSingleResult(createQuery(builder, criteria, root, predicates));
	}



}
