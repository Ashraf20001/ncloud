package com.digitalpaper.utils;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.digitalpaper.config.DigitalPaperCache;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.dao.IStockDao;
import com.digitalpaper.dao.PaperDetailsBulkUploadDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.restemplate.service.RestTemplateServiceImpl;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.entity.Stock;
import com.digitalpaper.transfer.object.entity.StockPool;
import com.digitalpaper.utils.core.ApplicationUtils;

/**
 * The Class CommonUtils.
 */
@Component
public class CommonUtils {
	
	/**
	 * RestTemplateServiceImpl
	 */
	@Autowired
	private RestTemplateServiceImpl restTemplateService;
	
	/**
	 * PaperDetailsBulkUploadDao
	 */
	@Autowired
	private PaperDetailsBulkUploadDao paperDetailsBulkUploadDao;
	
	/**
	 * IStockDao
	 */
	@Autowired
	private IStockDao stockDao;
	
	/**
	 * @param request
	 * @param associationId
	 * @param propertyName
	 * @return
	 * @throws ApplicationException 
	 */
	public String getSystemPropertyValueByPropertyId(HttpServletRequest request, Integer associationId, String propertyName) throws ApplicationException {
		String allocationType = restTemplateService.getAllocationType(propertyName, associationId, request);
		if(!ApplicationUtils.isValidString(allocationType)){
			throw new ApplicationException(ErrorCodes.INVALID_SYSTEM_PROPERTY);
		}
		return allocationType;
	}
	
	/**
	 * @param isStockCountUpdated
	 * @param userInfo
	 * @param associationId
	 * @param allocationType
	 * @return
	 * @throws ApplicationException
	 */
	public synchronized Boolean updateStockCount(Boolean isStockCountUpdated, UserInfo userInfo, Integer associationId,
			String allocationType) throws ApplicationException {
		StockPool stockPool=null;
		try {
			if(allocationType.equals(ApplicationConstants.ALLOCATION_TYPE_1)) {
				stockPool = paperDetailsBulkUploadDao.getStockPoolByAllocationId(userInfo.getCompanyId(),
				userInfo.getAllocationUserType());
				if(!ApplicationUtils.isValidateObject(stockPool)) {
					throw new ApplicationException(ErrorCodes.INVALID_STOCK_POOL);
				}
				if ((stockPool.getStockCount()-stockPool.getUsedCount())<=0) {
					throw new ApplicationException(ErrorCodes.INSUFFICIENT_STOCK);
				}
				isStockCountUpdated = paperDetailsBulkUploadDao.updateStockPool(stockPool);
				}else if(allocationType.equals(ApplicationConstants.ALLOCATION_TYPE_2)) {
					Stock stock = stockDao.getStockData(userInfo.getCompanyId());
					if(!ApplicationUtils.isValidateObject(stock)) {
						throw new ApplicationException(ErrorCodes.INVALID_STOCK);
					}
					if ( stock.getUsedCount() > stock.getStockCount() ) {
						throw new ApplicationException(ErrorCodes.INSUFFICIENT_STOCK);
					}
					stock.setUsedCount(stock.getUsedCount() + ApplicationConstants.ONE);
					isStockCountUpdated = paperDetailsBulkUploadDao.updateStock(stock);
				}
			return isStockCountUpdated;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
		
		
	}
	
	/**
	 * Validate stock count availability.
	 *
	 * @param userInfo the user info
	 * @throws ApplicationException the application exception
	 */
	public void validateStockCountAvailability(UserInfo userInfo) throws ApplicationException {
		StockPool stockPool = null;
		String allocationType = "";
		HashMap<String, String> systemPropertyVAlue = DigitalPaperCache.getSystemPropertyVAlue();
		allocationType = systemPropertyVAlue.get(ApplicationConstants.ALLOCATION_TYPE);
		if (allocationType.equals(ApplicationConstants.ALLOCATION_TYPE_1)) {
			stockPool = paperDetailsBulkUploadDao.getStockPoolByAllocationId(userInfo.getCompanyId(),
					userInfo.getAllocationUserType());
			if (!ApplicationUtils.isValidateObject(stockPool)) {
				throw new ApplicationException(ErrorCodes.INVALID_STOCK_POOL);
			}
			if ((stockPool.getStockCount() - stockPool.getUsedCount()) <= 0) {
				throw new ApplicationException(ErrorCodes.INSUFFICIENT_STOCK);
			}
		} else if (allocationType.equals(ApplicationConstants.ALLOCATION_TYPE_2)) {
			Stock stock = stockDao.getStockData(userInfo.getCompanyId());
			if (!ApplicationUtils.isValidateObject(stock)) {
				throw new ApplicationException(ErrorCodes.INVALID_STOCK);
			}
			if (stock.getUsedCount() > stock.getStockCount()) {
				throw new ApplicationException(ErrorCodes.INSUFFICIENT_STOCK);
			}
		}
	}
	
	

}
