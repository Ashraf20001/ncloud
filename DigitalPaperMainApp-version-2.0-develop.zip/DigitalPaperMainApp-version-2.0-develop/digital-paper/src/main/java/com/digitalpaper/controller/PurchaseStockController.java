package com.digitalpaper.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitalpaper.aop.annotation.Auditable;
import com.digitalpaper.config.base.controller.BaseController;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.service.IStockService;
import com.digitalpaper.service.PurchaseStockService;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.AssociationDashboardCountDto;
import com.digitalpaper.transfer.object.dto.CompanyTransactionDto;
import com.digitalpaper.transfer.object.dto.DownloadListVo;
import com.digitalpaper.transfer.object.dto.PaymentDetailsDto;
import com.digitalpaper.transfer.object.dto.PurchaseOrderDto;
import com.digitalpaper.transfer.object.dto.ViewHistoryDto;
import com.digitalpaper.utils.core.ApplicationUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class PurchaseStockController.
 */
@RestController
@Auditable
public class PurchaseStockController extends BaseController {

	
	/** stockService. */
	@Autowired
	IStockService stockService;
	
	/** purchaseStockService. */
	@Autowired
	private PurchaseStockService purchaseStockService;
	
	/**
	 * Gets the purchase list.
	 *
	 * @param min the min
	 * @param max the max
	 * @param searchValue the search value
	 * @param filterSort the filter sort
	 * @return the purchase list
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Purchase order list",notes="Get the list of purchase order details",response=List.class)
	@PostMapping("/getPurchaseList")
	public List<PurchaseOrderDto> getPurchaseList(
		@ApiParam(value = "Skip data count",required = true) @RequestParam(name = "min") int min, 
		@ApiParam(value="Limit data count",required = true)  @RequestParam(name = "max")int max, 
		@ApiParam(value = "Search data",required = true)  @RequestParam(name = "searchValue") String searchValue,
		@ApiParam(value="Filter data payload")  @RequestBody(required=false)List <FilterOrSortingVo> filterSort) throws ApplicationException{
			return purchaseStockService.getPurchaseList(min, max,searchValue,filterSort);
	}
	
	/**
	 * Purchase stock download.
	 *
	 * @param searchValue the search value
	 * @param downloadVo the download vo
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Purchase stock download",notes="Download the list of purchase order details",response=ResponseEntity.class)
	@PostMapping("/purchaseStock-download")
	public ResponseEntity<InputStreamResource> purchaseStockDownload(
		@ApiParam(value="Search data",required=true)	@RequestParam(name = "searchValue") String searchValue,
		@ApiParam(value="DownloadListVo payload data",required=true) @RequestBody DownloadListVo downloadVo) throws ApplicationException{
		List<PurchaseOrderDto> data = new ArrayList<>();
		try {
			data =	purchaseStockService.getPurchaseList(downloadVo.getMin(), downloadVo.getMax(),searchValue,downloadVo.getFilterVo());
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
		return purchaseStockService.commonDownload(data,downloadVo.getColumnList());
	}
	
	 /**
 	 * Approve or reject purchase details.
 	 *
 	 * @param paymentDetailsDto the payment details dto
 	 * @return getApplicationResponse
 	 * @throws ApplicationException the application exception
 	 */
	@ApiOperation(value="Purchase stock status",notes="Change the status of purchase stock based on approve or reject",response=ApplicationResponse.class)
	@PostMapping("/purchase-details/status")
	 public ApplicationResponse approveOrRejectPurchaseDetails(@ApiParam(value="PaymentDetailsDto payload data",required=true) @RequestBody PaymentDetailsDto paymentDetailsDto) throws ApplicationException {
		 String approveOrRejectPurchaseDetails = purchaseStockService.approveOrRejectPurchaseDetails(paymentDetailsDto);
		 return getApplicationResponse(approveOrRejectPurchaseDetails);
	 }

	/**
	 * Gets the transaction details.
	 *
	 * @param searchvalue the searchvalue
	 * @param companyTransactionList the company transaction list
	 * @return the transaction details
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Transaction details",notes="Get the payment transaction details of stock",response=ApplicationResponse.class)
	@PostMapping("/get-transactionDetails")
	public ApplicationResponse getTransactionDetails(
			@ApiParam(value="Search data",required=true) @RequestParam(name = "searchvalue") String searchvalue, 
			@ApiParam(value="CompanyTransactionDto payload data",required=true) @RequestBody CompanyTransactionDto companyTransactionList) throws ApplicationException{
		List<ViewHistoryDto> transactionDetails = purchaseStockService.getTransactionDetails(companyTransactionList, searchvalue);
		return getApplicationResponse(transactionDetails);
	}
	
	/**
	 * Excel download for transaction.
	 *
	 * @param searchvalue the searchvalue
	 * @param companyTransactionList the company transaction list
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Transaction details download",notes="Download the payment transaction details of stock",response=ResponseEntity.class)
	@PostMapping("/transaction-download")
	public ResponseEntity<InputStreamResource> excelDownloadForTransaction(
			@ApiParam(value="Search data",required=true) @RequestParam(name = "searchvalue") String searchvalue,
			@ApiParam(value="CompanyTransactionDto payload data",required=true) @RequestBody CompanyTransactionDto companyTransactionList) throws ApplicationException{
		List<ViewHistoryDto> transactionDetails = purchaseStockService.getTransactionDetails(companyTransactionList,searchvalue);
		
		ArrayList<HashMap<String, Object>> data = new ArrayList<HashMap<String, Object>>();
		if(ApplicationUtils.isValidateObject(transactionDetails)){
			 data  = purchaseStockService.downloadDataConverting(transactionDetails,companyTransactionList.getSelectedColumn());
		}
		return stockService.excelDownload(data);
	}
	
	/**
	 * Gets the stck file id.
	 *
	 * @param id the id
	 * @return the stck file id
	 */
	@ApiOperation(value="Get stock storage id",notes="Get stock storage details id using stock id",response = Integer.class)
	@GetMapping("/get-stockFileId")
	public Integer getStckFileId(@ApiParam(value="Stock id",required = true) @RequestParam (value = "id") Integer id) {
		return purchaseStockService.getStockFileId(id);
	}
	
	/**
	 * Gets the authority dashboard count.
	 *
	 * @param associatioId the associatio id
	 * @return the authority dashboard count
	 */
	@ApiOperation(value="Get stock status count",notes="Get stock status count for authority dashboard",response = ApplicationResponse.class)
	@GetMapping("/authority/get-dashboard-count")
	public ApplicationResponse getAuthorityDashboardCount(Integer associatioId) {
		List<AssociationDashboardCountDto> associationDashboardCountDto = purchaseStockService.getAuthorityDashboardCount(associatioId);
		return getApplicationResponse(associationDashboardCountDto);
	}
	
	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return PurchaseStockController.class;
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {

	}


	/**
	 * Gets the purchase order count.
	 *
	 * @param searchValue the search value
	 * @param filterOrSortingVo the filter or sorting vo
	 * @return Long
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Insurance purchase order count",notes="Get the total number of orders purchased",response=Long.class)
	@PostMapping("/getCount")
	public Long getPurchaseOrderCount( @ApiParam(value="Search data",required=true) @RequestParam(name = "searchValue") String searchValue,
			@ApiParam(value="FilterVo payload data",required=true)	 @RequestBody List<FilterOrSortingVo> filterOrSortingVo) throws ApplicationException  {
		Long count=purchaseStockService.getPurchaseOrderCount(filterOrSortingVo,searchValue);
		return count;
	}

	/**
	 * Gets the all purchase count.
	 *
	 * @param searchValue the search value
	 * @param companyTransactionDto the company transaction dto
	 * @return the all purchase count
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Authority purchase order count",notes="Get all the number of orders purchased",response=Long.class)
	@PostMapping("/getAllCount")
	public Long getAllPurchaseCount( @ApiParam(value="Search data",required=true) @RequestParam(name = "searchValue") String searchValue,
			@ApiParam(value="CompanyTransactionDto payload data",required=true) 	@RequestBody CompanyTransactionDto companyTransactionDto) throws ApplicationException {
		Long count=purchaseStockService.getAllPurchaseOrderCount(companyTransactionDto, searchValue);
		return count;
	}


}
