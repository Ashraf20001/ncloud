package com.digitalpaper.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.digitalpaper.aop.annotation.Auditable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitalpaper.config.base.controller.BaseController;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.service.ReportsService;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.PreviewReportDto;
import com.digitalpaper.transfer.object.dto.ReportsDto;
import com.digitalpaper.utils.core.ApplicationUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class ReportsController.
 *
 */
@RestController
@Auditable
public class ReportsController extends BaseController {

	/** The report service. */
	@Autowired
	private ReportsService reportService;

	/**
	 * Gets the report data.
	 *
	 * @return the report data
	 */
	@ApiOperation(value="Reports details",notes="Get all the report details",response=ApplicationResponse.class)
	@GetMapping("/get-all-reports")
	public ApplicationResponse getReportData() {

		List<ReportsDto> data = new ArrayList<ReportsDto>();
		try {
			data = reportService.getReportDetailsInCard();
		} catch (ApplicationException e) {

			e.printStackTrace();
		}
		return getApplicationResponse(data);

	}

	/**
	 * Save report data.
	 *
	 * @param reportData the report data
	 */
	@ApiOperation(value = "Save reports",notes="Endpoint serves for the report creation")
	@PostMapping("/save-reports")
	public void saveReportData( @ApiParam(value = "ReportsDto payload",required = true) @RequestBody ReportsDto reportData) {

		try {
			reportService.saveReportCardData(reportData);
		} catch (ApplicationException e) {
			
			e.printStackTrace();
		}
	}

	/**
	 * Gets the report date based on identity.
	 *
	 * @param Identity the identity
	 * @return the report date based on identity
	 */
	@ApiOperation(value = "Get report data",notes="Endpoint serves to fetch the report data based on identity",response = ApplicationResponse.class)
	@PostMapping("/get-reports")
	public ApplicationResponse getReportDateBasedOnIdentity(@ApiParam(value="Reports identity",required = true) @RequestBody String Identity) {

		ReportsDto data = new ReportsDto();

		try {
			data = reportService.getReportDataBasedOneIdentity(Identity);
		} catch (ApplicationException e) {

			e.printStackTrace();
		}

		return getApplicationResponse(data);

	}

	/**
	 * Report card update.
	 *
	 * @param list the list
	 */
	@ApiOperation(value = "Update report data",notes="Endpoint serves to update the report data")
	@PostMapping("/updateData")
	public void ReportCardUpdate(@ApiParam(value="ReportsDto payload data",required = true)  @RequestBody ReportsDto list) {
		try {
			reportService.UpdateValues(list);
		} catch (ApplicationException e) {
			
			e.printStackTrace();
		}
	}

	/**
	 * Export report as excel.
	 *
	 * @param report the report
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Export report",notes="Export report data as excel",response=ResponseEntity.class)
	@PostMapping("/generate/report/export-to-excel")
	public ResponseEntity<ByteArrayResource> exportReportAsExcel(@ApiParam(value="PreviewReportDto payload data",required = true)  @RequestBody PreviewReportDto report)
			throws ApplicationException {
		PreviewReportDto data = reportService.getReviewReportData(report,null,null);
		if (Boolean.FALSE.equals(ApplicationUtils.isValidateObject(data))) {
			return null;
		}
		return reportService.downloadExcelReport(data);
	}

	/**
	 * Export report as CSV.
	 *
	 * @param report the report
	 * @param response the response
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 * @throws Exception the exception
	 */
	@ApiOperation(value="Export report",notes="Export report data as csv",response=ResponseEntity.class)
	@PostMapping("/generate/report/export-to-csv")
	public ResponseEntity<ByteArrayResource> exportReportAsCSV(@ApiParam(value="PreviewReportDto payload data",required = true) @RequestBody PreviewReportDto report,
			HttpServletResponse response) throws ApplicationException, Exception {
		PreviewReportDto data = reportService.getReviewReportData(report,null,null);
		if (Boolean.FALSE.equals(ApplicationUtils.isValidateObject(data))) {
			return null;
		}
		return reportService.writeReportsToCsv(data, response);
	}

	/**
	 * Export report as pdf.
	 *
	 * @param report the report
	 * @return the response entity
	 * @throws Exception the exception
	 */
	@ApiOperation(value="Export report",notes="Export report data as pdf",response=ResponseEntity.class)
	@PostMapping("/generate/report/export-to-pdf")
	public ResponseEntity<ByteArrayResource> exportReportAsPdf( @ApiParam(value="PreviewReportDto payload data",required = true)  @RequestBody PreviewReportDto report) throws Exception {
		PreviewReportDto data = reportService.getReviewReportData(report,null,null);
		if (Boolean.FALSE.equals(ApplicationUtils.isValidateObject(data))) {
			return null;
		}
		return reportService.downloadReportAsPdf(data);
	}

	/**
	 * Gets the preview date.
	 *
	 * @param previewData the preview data
	 * @param min the min
	 * @param max the max
	 * @return the preview date
	 */
	@ApiOperation(value="Preview report",notes="Preview report data for report creation",response=ApplicationResponse.class)
	@PostMapping("/get-previewData")
	public ApplicationResponse getPreviewDate(@ApiParam(value="PreviewReportDto payload data",required = true) @RequestBody PreviewReportDto previewData,
		@ApiParam(value="Skip data count",required = true)	 @RequestParam(name = "min") Integer min,
		@ApiParam(value="Limit data count",required = true)	@RequestParam(name = "max") Integer max) {
		PreviewReportDto data = new PreviewReportDto();
		try {
			data = reportService.getReviewReportData(previewData,min,max);
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
		return getApplicationResponse(data);

	}
	
	/**
	 * Gets the report data count.
	 *
	 * @param previewData the preview data
	 * @return the report data count
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Preview report count",notes="Preview report count data for report creation",response=ApplicationResponse.class)
	@PostMapping("/get-previewData-count")
	public ApplicationResponse getReportDataCount(@ApiParam(value="PreviewReportDto payload data",required = true)  @RequestBody PreviewReportDto previewData)throws ApplicationException {

		return getApplicationResponse(reportService.getPreviewDataCount(previewData));
		
	}
	
	/**
	 * Gets the purchase order column list.
	 *
	 * @return the purchase order column list
	 */
	@ApiOperation(value="Purchase order columns",notes="Get list of purchase order columns",response = ApplicationResponse.class)
	@GetMapping("/get-purchaseOrder-column")
	public ApplicationResponse getPurchaseOrderColumnList() {

		try {
			return getApplicationResponse(reportService.getReportPurchaseOrderColumnList());
		} catch (ApplicationException e) {
			
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Gets the digital paper column list.
	 *
	 * @return the digital paper column list
	 */
	@ApiOperation(value="Digital paper columns",notes="Get list of digital paper columns",response = ApplicationResponse.class)
	@GetMapping("/get-digitalpaper-column")
	public ApplicationResponse getDigitalPaperColumnList() {

		try {
			return getApplicationResponse(reportService.getDigitalPaperColumn());
		} catch (ApplicationException e) {
			
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Gets the insurance company list.
	 *
	 * @return the insurance company list
	 */
	@ApiOperation(value="Company name list",notes = "Get insurance company list",response = ApplicationResponse.class)
	@GetMapping("/get-insuren-company")
	public ApplicationResponse getInsuranceCompanyList() {

		List<String> list = new ArrayList<String>();
		try {
			list = reportService.getInsuredCompanyName();
		} catch (ApplicationException e) {
			
			e.printStackTrace();
		}
		return getApplicationResponse(list);

	}

	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		
		return this.getClass();
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {
	}

}
