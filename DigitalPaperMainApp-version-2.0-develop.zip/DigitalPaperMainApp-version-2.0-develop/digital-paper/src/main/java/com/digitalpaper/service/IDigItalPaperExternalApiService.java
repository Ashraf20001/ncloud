package com.digitalpaper.service;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.DigitalPaperDto;
import com.digitalpaper.transfer.object.dto.ExternalApiDigitalPaperDto;

/**
 * The Interface IDigItalPaperExternalApiService.
 */
public interface IDigItalPaperExternalApiService {

	/**
	 * Save external api dto.
	 *
	 * @param dto the dto
	 * @param request the request
	 * @return the string
	 * @throws ApplicationException the application exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	String saveExternalApiDto(DigitalPaperDto dto,HttpServletRequest request) throws ApplicationException, IOException;

	/**
	 * Gets the external api dto.
	 *
	 * @param pdDigitalPaperId the pd digital paper id
	 * @param request the request
	 * @return the external api dto
	 * @throws ApplicationException the application exception
	 */
	ExternalApiDigitalPaperDto getExternalApiDto(String pdDigitalPaperId, HttpServletRequest request) throws ApplicationException;

}
