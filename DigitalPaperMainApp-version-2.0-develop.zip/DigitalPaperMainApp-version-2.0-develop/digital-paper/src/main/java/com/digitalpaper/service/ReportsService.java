package com.digitalpaper.service;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;

import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.PreviewReportDto;
import com.digitalpaper.transfer.object.dto.ReportsDto;

/**
 * The Interface ReportsService.
 */
public interface ReportsService {

	/**
	 * Gets the report details in card.
	 *
	 * @return the report details in card
	 * @throws ApplicationException the application exception
	 */
	List<ReportsDto> getReportDetailsInCard() throws ApplicationException;

	/**
	 * Save report card data.
	 *
	 * @param reportData the report data
	 * @throws ApplicationException the application exception
	 */
	void saveReportCardData(ReportsDto reportData) throws ApplicationException;

	/**
	 * Gets the report data based one identity.
	 *
	 * @param identity the identity
	 * @return the report data based one identity
	 * @throws ApplicationException the application exception
	 */
	ReportsDto getReportDataBasedOneIdentity(String identity) throws ApplicationException;

	/**
	 * Update values.
	 *
	 * @param list the list
	 * @throws ApplicationException the application exception
	 */
	void UpdateValues(ReportsDto list) throws ApplicationException ;

	/**
	 * Download excel report.
	 *
	 * @param data the data
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	ResponseEntity<ByteArrayResource> downloadExcelReport(PreviewReportDto data) throws ApplicationException;

	/**
	 * Gets the review report data.
	 *
	 * @param report the report
	 * @param min the min
	 * @param max the max
	 * @return the review report data
	 * @throws ApplicationException the application exception
	 */
	PreviewReportDto getReviewReportData(PreviewReportDto report,Integer min,Integer max) throws ApplicationException;

	/**
	 * Gets the report purchase order column list.
	 *
	 * @return the report purchase order column list
	 * @throws ApplicationException the application exception
	 */
	List<String> getReportPurchaseOrderColumnList() throws ApplicationException;

	/**
	 * Gets the digital paper column.
	 *
	 * @return the digital paper column
	 * @throws ApplicationException the application exception
	 */
	List<String> getDigitalPaperColumn() throws ApplicationException;

	/**
	 * Gets the insured company name.
	 *
	 * @return the insured company name
	 * @throws ApplicationException the application exception
	 */
	List<String> getInsuredCompanyName() throws ApplicationException;

	/**
	 * Write reports to csv.
	 *
	 * @param data the data
	 * @param response the response
	 * @return the response entity
	 */
	ResponseEntity<ByteArrayResource> writeReportsToCsv(PreviewReportDto data, HttpServletResponse response);

	/**
	 * Download report as pdf.
	 *
	 * @param data the data
	 * @return the response entity
	 */
	ResponseEntity<ByteArrayResource> downloadReportAsPdf(PreviewReportDto data);

	/**
	 * Gets the preview data count.
	 *
	 * @param previewData the preview data
	 * @return the preview data count
	 * @throws ApplicationException the application exception
	 */
	Long getPreviewDataCount(PreviewReportDto previewData)throws ApplicationException;


}
