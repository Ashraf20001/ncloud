package com.digitalpaper.service.impl;

import java.io.ByteArrayOutputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.dao.IBulkRevokeDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.service.IBulkRevokeService;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.entity.BulkRevokeErrorTable;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;
import com.digitalpaper.utils.core.ApplicationUtils;

/**
 * The Class BulkRevokeServiceImpl.
 */
@Service
@Transactional
public class BulkRevokeServiceImpl implements IBulkRevokeService {

	/**
	 * IBulkRevokeDao
	 */
	@Autowired
	private IBulkRevokeDao iBulkRevokeDao;
	
	/**
	 * LoggedInUserContextHolder
	 */
	@Autowired
	private LoggedInUserContextHolder loggedInUserContextHolder;

	/**
	 * @param filterVo
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Long getRevokeScratchCount(Integer bulkUploadId,List<FilterOrSortingVo> filterVo) throws ApplicationException {
		Long revokeScratchCount = iBulkRevokeDao.getRevokeScratchCount(bulkUploadId,filterVo);
		return revokeScratchCount;
	}

	/**
	 * @param skip
	 * @param limit
	 * @param filterVo
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public ArrayList<LinkedHashMap<String, Object>> getErrorData(Integer skip, Integer limit,Integer bulkUploadId,
			List<FilterOrSortingVo> filterVo) throws ApplicationException {
		List<Object[]> errorList = iBulkRevokeDao.getErrorSuccessData(skip, limit,bulkUploadId,filterVo, Boolean.TRUE);
		List<String> columnName = new ArrayList<>();
		columnName.add(ApplicationConstants.DIGITAL_PAPER_NUMBER);
		columnName.add(ApplicationConstants.POLICY_NUMBER);
		columnName.add(ApplicationConstants.ERROR_MESSAGE);
		columnName.add(ApplicationConstants.BULK_IMPORT_HISTORY_ID);
		columnName.add(ApplicationConstants.IDENTITY);
		ArrayList<LinkedHashMap<String, Object>> columnData = setColumnName(errorList, columnName);
		return columnData;
	}

	/**
	 * @param errorList
	 * @param columnName
	 * @return
	 */
	private ArrayList<LinkedHashMap<String, Object>> setColumnName(List<Object[]> errorSuccessList, List<String> columnName) {
		ArrayList<LinkedHashMap<String, Object>> columnData = new ArrayList<LinkedHashMap<String, Object>>();
		for (Object[] list : errorSuccessList) {
			LinkedHashMap<String, Object> mapData = new LinkedHashMap<>();
			int index = ApplicationConstants.ZERO;
			for (String column : columnName) {
				for (; index < list.length;) {
					mapData.put(column, list[index]);
					break;
				}
				index++;
			}
			columnData.add(mapData);
		}
		return columnData;
	}

	/**
	 * @param skip
	 * @param limit
	 * @param filterVo
	 * @return
	 * @throws ApplicationExceptions
	 */
	@Override
	public ArrayList<LinkedHashMap<String, Object>> getSuccessData(Integer skip, Integer limit,Integer bulkUploadId,
			List<FilterOrSortingVo> filterVo) throws ApplicationException {
		List<Object[]> successList = iBulkRevokeDao.getErrorSuccessData(skip, limit,bulkUploadId, filterVo, Boolean.FALSE);
		List<String> columnName = new ArrayList<>();
		columnName.add(ApplicationConstants.DIGITAL_PAPER_NUMBER);
		columnName.add(ApplicationConstants.POLICY_NUMBER);
		ArrayList<LinkedHashMap<String, Object>> columnData = setColumnName(successList, columnName);
		return columnData;
	}

	/**
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Long getErrorCount(Integer bulkUploadId,List<FilterOrSortingVo> filterVo) throws ApplicationException {
		Long errorCount = iBulkRevokeDao.getErrorSuccesCount(bulkUploadId,filterVo, Boolean.TRUE);
		return errorCount;
	}

	/**
	 * @param filterVo
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Long getSuccessCount(Integer bulkUploadId,List<FilterOrSortingVo> filterVo) throws ApplicationException {
		Long successCount = iBulkRevokeDao.getErrorSuccesCount(bulkUploadId,filterVo, Boolean.FALSE);
		return successCount;
	}

	/**
	 * @param identity
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public String deleteBulkRevoke(String identity) throws ApplicationException {
		if (ApplicationUtils.isValidateObject(identity)) {
			BulkRevokeErrorTable delete = iBulkRevokeDao.getBulkRevokeForDelete(identity);
			UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
			if (ApplicationUtils.isValidateObject(loggedInUser)) {
				LocalDateTime now = LocalDateTime.now();
				delete.setIsDeleted(true);
				delete.setModifiedDate(now);
				delete.setModifiedBy(loggedInUser.getId());
				iBulkRevokeDao.updateBulkRevoke(delete);
			}
		}
		return identity;
	}

	/**
	 * @param pageIdentity
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public ResponseEntity<ByteArrayResource> excelDownload(String pageIdentity,Integer bulkUploadId) throws ApplicationException {
		Long errorCount = getErrorCount(bulkUploadId, null);
		String val = (errorCount != null) ? errorCount.toString() : null;
		int parseInt = Integer.parseInt(val);
		ArrayList<LinkedHashMap<String, Object>> errorDataForExcel = getErrorData(ApplicationConstants.ZERO, parseInt, bulkUploadId, null);
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		HttpHeaders header = new HttpHeaders();

		try {
			List<String> keyList = new ArrayList<>();
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet(ApplicationConstants.BULK_REVOKE);
			XSSFRow hederRow = sheet.createRow((int) ApplicationConstants.ZERO);

			int rowIndex = ApplicationConstants.ZERO;

			for (HashMap<String, Object> map : errorDataForExcel) { // Iterated only for Extracting Header Columns
				Set<String> keys = map.keySet();
				keyList = keys.stream().collect(Collectors.toList());
				for (int i = ApplicationConstants.ZERO; i < keyList.size(); ) {
					if (!keyList.get(i).equalsIgnoreCase(ApplicationConstants.IDENTITY) 
						 && !keyList.get(i).equalsIgnoreCase(ApplicationConstants.BULK_IMPORT_HISTORY_ID)) {
						hederRow.createCell(i).setCellValue(keyList.get(i));
						i++;
					}
					else {
						keyList.remove(i);					}
				}
			}

			for (HashMap<String, Object> map : errorDataForExcel) {
				int columnIndex = ApplicationConstants.ZERO;
				XSSFRow row = sheet.createRow((int) rowIndex + 1);
				for (Entry<String, Object> entry : map.entrySet()) {
					if (!entry.getKey().equals(ApplicationConstants.IDENTITY)
							&& !entry.getKey().equals(ApplicationConstants.BULK_IMPORT_HISTORY_ID)) {
						row.createCell(columnIndex)
								.setCellValue((entry.getValue() != null) ? entry.getValue().toString()
										: ApplicationConstants.WITHOUT_SPACE);
						columnIndex++;
					}

				}
				rowIndex++;
			}

			if (ApplicationUtils.isValidList(keyList)) {
				for (int index = ApplicationConstants.ZERO; index < keyList.size(); index++) {
					sheet.autoSizeColumn(index);
				}
			}

			header.setContentType(new MediaType("application", "force-download"));
			header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ProductTemplate.pdf");

			workbook.write(stream);
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>(new ByteArrayResource(stream.toByteArray()), header, HttpStatus.CREATED);
	}

}
