package com.digitalpaper.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;

/**
 * The Interface IBulkRevokeService.
 */
public interface IBulkRevokeService {
	

	/**
	 * @param bulkUploadId 
	 * @param filterVo
	 * @return
	 * @throws ApplicationException
	 */
	Long getRevokeScratchCount(Integer bulkUploadId, List<FilterOrSortingVo> filterVo) throws ApplicationException;

	/**
	 * @param skip
	 * @param limit
	 * @param filterVo
	 * @return
	 * @throws ApplicationException
	 */
	ArrayList<LinkedHashMap<String, Object>> getErrorData(Integer skip, Integer limit,Integer bulkUploadId, List<FilterOrSortingVo> filterVo)
			throws ApplicationException;
	
	/**
	 * @param skip
	 * @param limit
	 * @param filterVo
	 * @return
	 * @throws ApplicationException
	 */
	ArrayList<LinkedHashMap<String, Object>> getSuccessData(Integer skip, Integer limit,Integer bulkUploadId, List<FilterOrSortingVo> filterVo)
			throws ApplicationException;

	/**
	 * @param bulkUploadId 
	 * @param filterVo 
	 * @return
	 * @throws ApplicationException
	 */
	Long getErrorCount(Integer bulkUploadId, List<FilterOrSortingVo> filterVo) throws ApplicationException;
	
	/**
	 * @param bulkUploadId 
	 * @param filterVo 
	 * @return
	 * @throws ApplicationException
	 */
	Long getSuccessCount(Integer bulkUploadId, List<FilterOrSortingVo> filterVo) throws ApplicationException;

	/**
	 * @param identity
	 * @return
	 * @throws ApplicationException
	 */
	String deleteBulkRevoke(String identity) throws ApplicationException;

	/**
	 * @param pageIdentity
	 * @param bulkUploadId 
	 * @return
	 * @throws ApplicationException
	 */
	ResponseEntity<ByteArrayResource> excelDownload(String pageIdentity, Integer bulkUploadId) throws ApplicationException;

}
