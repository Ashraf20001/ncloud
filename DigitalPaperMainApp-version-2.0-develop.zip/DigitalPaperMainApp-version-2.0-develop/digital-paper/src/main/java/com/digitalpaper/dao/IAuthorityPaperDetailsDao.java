package com.digitalpaper.dao;

import java.util.List;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.CompanyTransactionDto;
import com.digitalpaper.transfer.object.entity.PaperDetails;

/**
 * The Interface IAuthorityPaperDetailsDao.
 */
public interface IAuthorityPaperDetailsDao {

	/**
	 * @param companyTransactionDto
	 * @return
	 * @throws ApplicationException
	 */
	Long getPaperDetailsCountByCompany(CompanyTransactionDto companyTransactionDto, String searchValue, List<Integer> matchingKey) throws ApplicationException;

	/**
	 * @param companyTransactionDto
	 * @return
	 * @throws ApplicationException
	 */
	List<PaperDetails> getPaperDetailsByCompanyList(CompanyTransactionDto companyTransactionDto, String searchValue,List<Integer> companyId) throws ApplicationException;
	
	/**
	 * Gets the paper details list.
	 *
	 * @param entityColumnNames the entity column names
	 * @param companyId the company id
	 * @param list the list
	 * @param searchValue the search value
	 * @param matchingKey the matching key
	 * @return the paper details list
	 * @throws ApplicationException the application exception
	 */
	List<Object[]> getPaperDetailsList(List<String> entityColumnNames,List<Integer> companyId, List<FilterOrSortingVo> list,
			String searchValue, List<Integer> matchingKey) throws ApplicationException;

	/**
	 * Gets the stock table count.
	 *
	 * @return the stock table count
	 */
	Long getStockTableCount();

}