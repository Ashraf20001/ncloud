package com.digitalpaper.daoImp;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.digitalpaper.config.common.base.dao.BaseDao;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.IDigitalPaperDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.entity.PaperDetails;

/**
 * The Class DigitalPaperDaoImpl.
 */
@Repository
public class DigitalPaperDaoImpl extends BaseDao implements IDigitalPaperDao{

	/**
	 * Check for duplicate policy number.
	 *
	 * @param pdPolicyNumber the pd policy number
	 * @param status the status
	 * @return the paper details
	 */
	@Override
	public PaperDetails checkForDuplicatePolicyNumber(String pdPolicyNumber,Integer status) {
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
        Root<PaperDetails> root = criteria.from(PaperDetails.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.POLICY_NUMBER), pdPolicyNumber)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.PD_STATUS), status)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        PaperDetails paperDetails = (PaperDetails) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);
        return paperDetails;
	}

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
		
	}

	/**
	 * Check duplicate registration number or chassis number.
	 *
	 * @param vdRegistrationNumber the vd registration number
	 * @param vdChassisNumber the vd chassis number
	 * @param status the status
	 * @return the list
	 */
	@Override
	public List<PaperDetails> checkDuplicateRegistrationNumberOrChassisNumber(String vdRegistrationNumber, String vdChassisNumber, Integer status) {
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
        Root<PaperDetails> root = criteria.from(PaperDetails.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.or(builder.equal(root.get(TableConstants.REGISTRATION_NUMBER), vdRegistrationNumber),
        		builder.equal(root.get(TableConstants.CHASIS_NUMBER), vdChassisNumber)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.PD_STATUS), status)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        List<PaperDetails> paperDetails = (List<PaperDetails>) getResultList(createQuery(builder, criteria, root, predicates));
		return paperDetails;
	}

	/**
	 * Save digital paper details.
	 *
	 * @param paperDetailsEntity the paper details entity
	 * @return the integer
	 */
	@Override
	public Integer saveDigitalPaperDetails(PaperDetails paperDetailsEntity) { try {
			return save(paperDetailsEntity,TableConstants.PAPER_DETAILS);
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Gets the paper details.
	 *
	 * @param registerNo the register no
	 * @return the paper details
	 */
	@Override
	public PaperDetails getPaperDetails(String registerNo) {

		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
        Root<PaperDetails> root = criteria.from(PaperDetails.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.REGISTRATION_NUMBER), registerNo)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        PaperDetails paperDetails = (PaperDetails) getResultList(createQuery(builder, criteria, root, predicates)).stream()
				.findFirst().orElse(null);
        
		return paperDetails;
	}

	/**
	 * Gets the digital paper details.
	 *
	 * @param companyId the company id
	 * @param UserId the user id
	 * @return the digital paper details
	 */
	@Override
	public List<PaperDetails> getDigitalPaperDetails(Integer companyId, Integer UserId) {


		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
        Root<PaperDetails> root = criteria.from(PaperDetails.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.COMPANY_ID), companyId)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.CUSTOMER).get(TableConstants.CUSTOMER_ID), UserId)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        List<PaperDetails> paperDetails = ( List<PaperDetails>) getResultList(createQuery(builder, criteria, root, predicates));
        
		return paperDetails;
	}
	
	/**
	 * Gets the digital paper details by customer.
	 *
	 * @param customerId the customer id
	 * @return the digital paper details by customer
	 */
	@Override
	public List<PaperDetails> getDigitalPaperDetailsByCustomer(Integer customerId) {


		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
        Root<PaperDetails> root = criteria.from(PaperDetails.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.CUSTOMER).get(TableConstants.CUSTOMER_ID), customerId)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        List<PaperDetails> paperDetails = ( List<PaperDetails>) getResultList(createQuery(builder, criteria, root, predicates));
        
		return paperDetails;
	}

	/**
	 * Gets the digital paper data.
	 *
	 * @param digitalPaperIdentity the digital paper identity
	 * @param pdPolicyNumber the pd policy number
	 * @return the digital paper data
	 */
	@Override
	public PaperDetails getDigitalPaperData(String digitalPaperIdentity, String pdPolicyNumber) {
		
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
        Root<PaperDetails> root = criteria.from(PaperDetails.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.POLICY_NUMBER), pdPolicyNumber)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.IDENTITY), digitalPaperIdentity)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        PaperDetails paperDetails = (PaperDetails) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);
        return paperDetails;
        
	}

	/**
	 * Update digital paer.
	 *
	 * @param paperDetailsEntity the paper details entity
	 */
	@Override
	public void updateDigitalPaer(PaperDetails paperDetailsEntity) {
	
		update(paperDetailsEntity);
		
	}

    /**
     * Gets the digital paper data list by email id.
     *
     * @param emailId the email id
     * @param companyId the company id
     * @return the digital paper data list by email id
     */
    @SuppressWarnings("unchecked")
	@Override
	public List<PaperDetails> getDigitalPaperDataListByEmailId(String emailId,Integer companyId) {
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
        Root<PaperDetails> root = criteria.from(PaperDetails.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.PD_EMAIL_ID), emailId)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.COMPANY_ID), companyId)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.STATUS), 1)));
		List<PaperDetails> paperDetails = ( List<PaperDetails>) getResultList(createQuery(builder, criteria, root, predicates));
        
		return paperDetails;
		
	}

	/**
	 * Check for duplicate chassis number.
	 *
	 * @param vdChassisNumber the vd chassis number
	 * @param status the status
	 * @return the paper details
	 */
	@Override
	public PaperDetails checkForDuplicateChassisNumber(String vdChassisNumber, Integer status) {
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
        Root<PaperDetails> root = criteria.from(PaperDetails.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.CHASIS_NUMBER), vdChassisNumber)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.PD_STATUS), status)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        PaperDetails paperDetails = (PaperDetails) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);
        return paperDetails;
	}

	/**
	 * Gets the paperticuler paper based on id.
	 *
	 * @param customerId the customer id
	 * @param paperId the paper id
	 * @return the paperticuler paper based on id
	 */
	@Override
	public PaperDetails getPaperticulerPaperBasedOnId(Integer customerId, String paperId) {
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
        Root<PaperDetails> root = criteria.from(PaperDetails.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.CUSTOMER).get(TableConstants.CUSTOMER_ID), customerId)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.PD_DIGITAL_PAPER_ID), paperId)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        PaperDetails paperDetails = (PaperDetails) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);
        
		return paperDetails;
	}


}
