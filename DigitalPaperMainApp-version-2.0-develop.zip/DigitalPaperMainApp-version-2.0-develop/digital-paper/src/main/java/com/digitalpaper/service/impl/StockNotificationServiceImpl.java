package com.digitalpaper.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.digitalpaper.config.property.EnvironmentProperties;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.dao.IStockNotificationDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.purchasestock.dao.PurchaseStockDao;
import com.digitalpaper.service.IStockNotificationSevice;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.PurchaseOrderDto;
import com.digitalpaper.transfer.object.dto.StockNotificationDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.entity.NotificationEvent;
import com.digitalpaper.transfer.object.entity.NotificationTemplate;
import com.digitalpaper.transfer.object.entity.PurchaseOrderEntity;
import com.digitalpaper.transfer.object.entity.StockNotification;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;
import com.digitalpaper.utils.core.ApplicationDateUtils;
import com.digitalpaper.utils.core.ApplicationUtils;
import com.digitalpaper.utils.core.RestTemplateUtils;


/**
 * The Class StockNotificationServiceImpl.
 */
@Service
@Transactional
public class StockNotificationServiceImpl implements IStockNotificationSevice{

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ApplicationDateUtils.class);

	/**
	 * IStockNotificationDao
	 */
	@Autowired
	private IStockNotificationDao notificationDao;

	/**
	 * RestTemplateUtils
	 */
	@Autowired
	private RestTemplateUtils restTemplateUtils;
	/**
	 * RestTemplate
	 */
	@Autowired
	private RestTemplate restTemplate;

	/**
	 * SimpMessagingTemplate
	 */

	@Autowired
	private EnvironmentProperties environmentProperties;
	
	/** The logged in user context holder. */
	@Autowired
	private LoggedInUserContextHolder loggedInUserContextHolder;
	
	/** The purchase stock dao. */
	@Autowired
	private PurchaseStockDao purchaseStockDao;
	
	/** The messaging template. */
	@Autowired
	private SimpMessagingTemplate messagingTemplate;
	
	/**
	 * @param ActionBtn
	 * @param StockId
	 * @throws ApplicationException
	 */
	@Override
	public void saveNotification(String action, PurchaseOrderDto stockDetails) throws ApplicationException {
		
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		if(Boolean.FALSE.equals(ApplicationUtils.isValidString(action))) {
			throw new ApplicationException(ErrorCodes.INVALID_ACTION);
		}
		if(Boolean.FALSE.equals(ApplicationUtils.isValidObject(stockDetails))) {
			throw new ApplicationException(ErrorCodes.INVALID_STOCKID);
		}
		NotificationTemplate notificationTemplateDate = new NotificationTemplate();

		NotificationEvent notificationEventData = notificationDao.getNotificationevent(ApplicationConstants.STOCK_PURCHASE);

		if(ApplicationUtils.isValidateObject(notificationEventData)) {
			notificationTemplateDate = notificationDao.getNotificationTemplate(notificationEventData.getEventId(),action);
		}

		StringBuilder finalMessage = new StringBuilder();

		finalMessage.append(notificationTemplateDate.getContent().replaceAll(ApplicationConstants.STOCK_COUNT, stockDetails.getStockCount().toString())
				.replaceAll(ApplicationConstants.COMPANY_NAME, (loggedInUser.getCompanyName() == null) ? "Association" : loggedInUser.getCompanyName().toString()));
		
		JSONObject replacableData = new JSONObject();
		replacableData.put(ApplicationConstants.COMPANY_NAME, loggedInUser.getCompanyName()==null ? "Association" :loggedInUser.getCompanyName());
		replacableData.put(ApplicationConstants.STOCK_COUNT, stockDetails.getStockCount().toString());
		
		String replacableJsonData=replacableData.toString();
		String actionStatus=notificationTemplateDate.getAction();
		PurchaseOrderEntity purchaseOrder = purchaseStockDao.getPurchaseOrderFromOrderId(stockDetails.getOrderId());
		

		if(ApplicationUtils.isValidIdentity(action)) {
			saveStockNotification(stockDetails,finalMessage.toString(),purchaseOrder,loggedInUser,replacableJsonData,actionStatus);
		}
		else {
			throw new ApplicationException(ErrorCodes.INVALID_REQUEST);
		}

		}

	/**
	 * Update notification.
	 *
	 * @param previesData the previes data
	 * @param stockId the stock id
	 * @param content the content
	 */
	public void updateNotification(StockNotification previesData, PurchaseOrderDto stockId,String content) {
		StockNotification notificationEntity = new StockNotification();
		notificationEntity.setActedBy(null); // authority is should be null because some times same for company id and authority id in table
		notificationEntity.setModifiedBy(null);
		notificationEntity.setModifiedDate(LocalDateTime.now());
		notificationEntity.setRead(false);
		notificationEntity.setToNotify(stockId.getCompanyId());
		notificationEntity.setNotificationMsg(content);
		try {
			notificationDao.updateNotification(notificationEntity);
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param actionStatus 
	 * @param replacableJsonData 
	 * @param StockId
	 * @param Content
	 */
	public void saveStockNotification(PurchaseOrderDto stockId,String content,PurchaseOrderEntity purchaseOrder,UserInfo loggedInUser, String replacableJsonData, String actionStatus) {
		StockNotification notificationEntity = new StockNotification();
		if(loggedInUser.getUserTypeId().getUserTypeId().equals(ApplicationConstants.ONE)) {
			notificationEntity.setActedBy(loggedInUser.getAssociationId());
			notificationEntity.setToNotify(stockId.getCompanyId());
			notificationEntity.setIsAssociation(false);
		}else {
			notificationEntity.setActedBy(stockId.getCompanyId());
			notificationEntity.setToNotify(loggedInUser.getAssociationId());
			notificationEntity.setIsAssociation(true);
		}
		notificationEntity.setCreatedBy(loggedInUser.getId());
		notificationEntity.setCreatedDate(LocalDateTime.now());
		notificationEntity.setRead(Boolean.FALSE);
		notificationEntity.setNotificationMsg(content);
		notificationEntity.setOrderId(purchaseOrder);
		notificationEntity.setActionStatus(actionStatus);
		notificationEntity.setReplaceData(replacableJsonData);
		try {
			
			notificationDao.saveNotification(notificationEntity);
			StockNotificationDto notificationDtoObj = new StockNotificationDto();
			notificationDtoObj.setReplaceableData(replacableJsonData);
			notificationDtoObj.setAction(actionStatus);
			notificationDtoObj.setActedBy(notificationEntity.getActedBy());
			notificationDtoObj.setNotificationMsg(notificationEntity.getNotificationMsg());
			notificationDtoObj.setToNotify(notificationEntity.getToNotify());
			notificationDtoObj.setOrderId(notificationEntity.getOrderId().getOrderId());
			notificationDtoObj.setCreatedDate(notificationEntity.getCreatedDate().toString());	
			notificationDtoObj.setNotificationId(notificationEntity.getNotificationId());
			String logoUrl = null;
			try {
				logoUrl =(String)getCompanyLogo(notificationEntity.getActedBy()).getContent();
			} catch (Exception e) {
				logger.error("Error while getting  logo url ".concat(e.getMessage()) );
			}
			notificationDtoObj.setImageUrl(logoUrl);
			String url = ApplicationConstants.WEBSOCKET_ENDPOINT+notificationEntity.getToNotify()+ApplicationConstants.SLASH+notificationEntity.getIsAssociation().toString();
			messagingTemplate.convertAndSend(url,notificationDtoObj);
		} catch (ApplicationException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Gets the login details.
	 *
	 * @param request the request
	 * @return the login details
	 */
	public ApplicationResponse getLoginDetails(HttpServletRequest request) {

		HttpHeaders httpHeaders = restTemplateUtils.configureRestTemplate(request);
		HttpEntity<String> entity = new HttpEntity<String>(httpHeaders);

		String url = environmentProperties.getCommonServicePath()+ApplicationConstants.REST_CALL_URL;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);

		return restTemplate.exchange(builder.toUriString(), HttpMethod.GET, entity, ApplicationResponse.class)
				.getBody();
	}

	/**
	 * Gets the notification.
	 *
	 * @param skip the skip
	 * @param limit the limit
	 * @return the notification
	 * @throws ApplicationException the application exception
	 */
	@Override
	public List<StockNotificationDto> getNotification(Integer skip, Integer limit)throws ApplicationException {
		
		UserInfo userDetails = loggedInUserContextHolder.getLoggedInUser();
		Integer companyId=userDetails.getCompanyId();
		
		List<StockNotification> notificationEntity ;
		if(ApplicationUtils.isValidId(companyId)) {
			
			notificationEntity = notificationDao.getNotificationData(companyId,skip,limit);
			
		}else {
			notificationEntity = notificationDao.getNotificationByAuthority(userDetails.getAssociationId(),skip,limit);
		}
		List<StockNotificationDto> NotificationDto = new ArrayList<>();
		
		if(ApplicationUtils.isValidateObject(notificationEntity)){
			notificationDtoSetMethod(notificationEntity, NotificationDto);
			
		}
			
		return NotificationDto;	
	}

	/**
	 * Notification dto set method.
	 *
	 * @param notificationEntity the notification entity
	 * @param NotificationDto the notification dto
	 */
	public void notificationDtoSetMethod(List<StockNotification> notificationEntity,
			List<StockNotificationDto> NotificationDto) {
		for (StockNotification data : notificationEntity) {
			
			StockNotificationDto notificationDtoObj = new StockNotificationDto();
			
			notificationDtoObj.setActedBy(data.getActedBy());
			notificationDtoObj.setNotificationMsg(data.getNotificationMsg());
			notificationDtoObj.setToNotify(data.getToNotify());
			notificationDtoObj.setOrderId(data.getOrderId().getOrderId());
			notificationDtoObj.setCreatedDate(data.getCreatedDate().toString());	
			notificationDtoObj.setNotificationId(data.getNotificationId());
			notificationDtoObj.setReplaceableData(data.getReplaceData());
			notificationDtoObj.setAction(data.getActionStatus());;
			String logoUrl = null;
			try {
				logoUrl =(String)getCompanyLogo(data.getActedBy()).getContent();
			} catch (Exception e) {
				logger.error("Error while getting  logo url ".concat(e.getMessage()) );
			}
			notificationDtoObj.setImageUrl(logoUrl);
			
			NotificationDto.add(notificationDtoObj);
		}
	}
	
	/**
	 * Gets the company logo.
	 *
	 * @param companyId the company id
	 * @return the company logo
	 */
	public ApplicationResponse getCompanyLogo(Integer companyId) {
		HttpHeaders headers = restTemplateUtils.getGETHeaders();
		HttpEntity<String> staticEntity = new HttpEntity<>(headers);
		if(Boolean.FALSE.equals(ApplicationUtils.isValidId(companyId))) {
			companyId = ApplicationConstants.ZERO; // For retrieving authority's default logo
		}
		String url = environmentProperties.getGateWayPath()+ApplicationConstants.COMPANY_LOGO + ApplicationConstants.SLASH + companyId;
    		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		ResponseEntity<ApplicationResponse> entity = restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
				staticEntity,ApplicationResponse.class);
		return entity.getBody();
	}

	/**
	 * Gets the notification count.
	 *
	 * @return the notification count
	 */
	@Override
	public Long getNotificationCount() {

		UserInfo userDetails = loggedInUserContextHolder.getLoggedInUser();
		Integer companyId=userDetails.getCompanyId();
		Long notificationCount = null;
		
		if(ApplicationUtils.isValidId(companyId)) {
			
			notificationCount = notificationDao.getNotificationCountBasedOneCompanyId(companyId);
			
		}else {
			notificationCount = notificationDao.getNotificationCount(userDetails.getAssociationId());
		}
		return notificationCount;
	}

	/**
	 * Update notification data.
	 *
	 * @param notificationId the notification id
	 */
	@Override
	public void updateNotificationData(Integer notificationId) {
		
		UserInfo userDetails = loggedInUserContextHolder.getLoggedInUser();
		Integer userId = userDetails.getId();
		
		StockNotification notificationEntity ;
		
		notificationEntity= notificationDao.getNotificationBasedOnId(notificationId);
		if(ApplicationUtils.isValidateObject(notificationEntity)) {
			
			notificationEntity.setModifiedBy(userId);
			LocalDateTime now = LocalDateTime.now();
			notificationEntity.setModifiedDate(now);	
			notificationEntity.setRead(true);	
			try {
				notificationDao.updateNotification(notificationEntity);
			} catch (ApplicationException e) {
				e.printStackTrace();
			}
			}
		
		
		
	}

}
