package com.digitalpaper.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.PoolDto;
import com.digitalpaper.transfer.object.dto.StockDto;

/**
 * The Interface AllocationPoolService.
 */
public interface AllocationPoolService {

	/**
	 * Update pool count by pool action.
	 *
	 * @param poolDto the pool dto
	 * @param request the request
	 * @return the stock dto
	 * @throws ApplicationException the application exception
	 */
	public StockDto updatePoolCountByPoolAction(PoolDto poolDto, HttpServletRequest request) throws ApplicationException;

	/**
	 * Gets the stock pool from identity.
	 *
	 * @param identity the identity
	 * @return the stock pool from identity
	 * @throws ApplicationException the application exception
	 */
	public StockDto getStockPoolFromIdentity(String identity) throws ApplicationException;

	/**
	 * Gets the all stock pool.
	 *
	 * @param identity the identity
	 * @param response the response
	 * @param filterPaginationVo the filter pagination vo
	 * @param min the min
	 * @param max the max
	 * @param seachValue the seach value
	 * @return the all stock pool
	 * @throws ApplicationException the application exception
	 */
	public List<StockDto> getAllStockPool(String identity, HttpServletRequest response, List<FilterOrSortingVo> filterPaginationVo, Integer min, Integer max, String seachValue) throws ApplicationException;

	/**
	 * Change stock pool status.
	 *
	 * @param status the status
	 * @param identity the identity
	 * @throws ApplicationException the application exception
	 */
	public void changeStockPoolStatus(boolean status, String identity) throws ApplicationException;

	/**
	 * Gets the stock pool count.
	 *
	 * @param response the response
	 * @return the stock pool count
	 */
	public Integer getStockPoolCount(HttpServletRequest response);

	/**
	 * Gets the allocation type.
	 *
	 * @param request the request
	 * @return the allocation type
	 * @throws ApplicationException the application exception
	 */
	public String getAllocationType(HttpServletRequest request) throws ApplicationException;

}
