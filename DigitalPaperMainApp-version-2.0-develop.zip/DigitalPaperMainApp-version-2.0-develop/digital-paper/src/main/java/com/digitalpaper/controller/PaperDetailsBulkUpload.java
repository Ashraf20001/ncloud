package com.digitalpaper.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitalpaper.config.base.controller.BaseController;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.service.PaperDetailsBulkUploadService;
import com.digitalpaper.transfer.object.dto.BulkImportFieldValidationDto;
import com.digitalpaper.transfer.object.dto.UserInfo;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class PaperDetailsBulkUpload.
 */
@RestController
public class PaperDetailsBulkUpload extends BaseController{

	/** PaperDetailsBulkUploadService. */
	@Autowired
	private PaperDetailsBulkUploadService paperDetailsBulkUploadService;

	/**
	 * Gets the excel sheet reading.
	 *
	 * @param validationDto the validation dto
	 * @param request the request
	 * @return the excel sheet reading
	 */
	@ApiOperation(value="Bulk import",notes = "Paper details bulk upload")
	@PostMapping("/paper-details/bulk-upload")
	public void getExcelSheetReading(@ApiParam(value="BulkImportFieldValidationDto payload data ",required = true)  @RequestBody BulkImportFieldValidationDto validationDto, HttpServletRequest request) {
		paperDetailsBulkUploadService.getExcelSheetReading(validationDto, request);
	}

	/**
	 * Bulk upload sample excel download.
	 *
	 * @param pageIdentity the page identity
	 * @param request the request
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Sample Excel for bulk import",notes = "Sample excel download for bulk import operation",response = ResponseEntity.class)
	@PostMapping("/bulk-upload-excel-download")
	public ResponseEntity<InputStreamResource> bulkUploadSampleExcelDownload(
			@ApiParam(value = "Bulk import page identity",required = true)
			@RequestParam(name = "pageIdentity") String pageIdentity, HttpServletRequest request)
			throws ApplicationException {
		return paperDetailsBulkUploadService.bulkUploadSampleExcelDownload(pageIdentity, request);
	}
	
	/**
	 * Gets the stock available count for bulk upload.
	 *
	 * @param userinfo the userinfo
	 * @return the stock available count for bulk upload
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Available stock details",notes="Get available stock count details for bulk upload")
	@PostMapping("/get-stock-available-count")
	public Boolean getStockAvailableCountForBulkUpload(@ApiParam(value="User info",required = true) @RequestBody UserInfo userinfo) throws ApplicationException {
		return paperDetailsBulkUploadService.validateStockCountAvailability(userinfo);
	}

	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	public Class<?> getClassName() {
		return PaperDetailsBulkUpload.class;
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {

	}



}
