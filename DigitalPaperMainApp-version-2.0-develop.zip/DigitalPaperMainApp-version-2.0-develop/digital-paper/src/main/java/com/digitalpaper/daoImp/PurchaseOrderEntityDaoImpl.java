package com.digitalpaper.daoImp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.digitalpaper.config.common.base.dao.BaseDao;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.IPurchaseOrderEntityDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.CompanyAndCountDto;
import com.digitalpaper.transfer.object.dto.NotificationCount;
import com.digitalpaper.transfer.object.entity.PaymentDetails;
import com.digitalpaper.transfer.object.entity.PurchaseOrderEntity;
import com.digitalpaper.transfer.object.entity.StockNotification;
import com.digitalpaper.utils.core.ApplicationUtils;

/**
 * The Class PurchaseOrderEntityDaoImpl.
 */
@Repository
public class PurchaseOrderEntityDaoImpl extends BaseDao implements IPurchaseOrderEntityDao {

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
	}

	/**
	 * @returns
	 * @throws ApplicationException
	 */
	@Override
	public Long getTotalCountOfCompanyFromTransaction() throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<PurchaseOrderEntity> root = criteria.from(PurchaseOrderEntity.class);
		criteria.select(builder.countDistinct(root.get(TableConstants.COMPANY_ID)));
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		return (Long) getSingleResult(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * @param companyNameMaping
	 * @param limit
	 * @param skip
	 * @return
	 * @throws ApplicationException
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CompanyAndCountDto> getCompanyAndCountList(List<Integer> companyIds,Map<Integer, String> companyNameMaping, Integer skip,
			int limit, List<FilterOrSortingVo> filterVo, Boolean isCount, String searchValue) throws ApplicationException {
		
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<CompanyAndCountDto> criteria = builder.createQuery(CompanyAndCountDto.class);
		Root<PaymentDetails> root = criteria.from(PaymentDetails.class);
		Expression<String> companyIdExpression = (builder.<String>selectCase()
				.when(builder.greaterThan(root.get(TableConstants.ORDER_ID).get(TableConstants.COMPANY_ID), 0), ""));
		Expression<Long> totalTransactionExpression = builder.count(root);
		
		Expression<Long> pendingTransactionExpression = builder.sumAsLong(
				builder.<Integer>selectCase().when(builder.equal(root.get(TableConstants.DP_PAYMENT_STATUS), 2), 1));
		criteria.multiselect(root.get(TableConstants.ORDER_ID).get(TableConstants.COMPANY_ID), companyIdExpression, totalTransactionExpression,
				pendingTransactionExpression);
		
		List<Predicate> predicates = new ArrayList<>();
		if(ApplicationUtils.isValidList(companyIds)) {
			predicates.add(root.get(TableConstants.ORDER_ID).get(TableConstants.COMPANY_ID).in(companyIds));
		}
		List<FilterOrSortingVo> companyFilter = new ArrayList<FilterOrSortingVo>();
		if (ApplicationUtils.isValidList(filterVo)) {
			companyFilter = filterVo.stream()
					.filter(value -> value.getColumnName().equals(ApplicationConstants.COMPANY_FILTER_COLUMN_NAME)
							&& ApplicationUtils.isValidString(value.getValue()))
					.collect(Collectors.toList());
		}
		if (ApplicationUtils.isValidateObject(companyFilter)) {
			for (FilterOrSortingVo filter : companyFilter) {
				if (filter.getCondition().equals(ApplicationConstants.IN)) {
					String companyNameExpression = filter.getValue();
					Integer filterCompanyId = null;
					List<Integer> listOfCompanyIds = new ArrayList<>();
					for (Map.Entry<Integer, String> entry : companyNameMaping.entrySet()) {
						if (entry.getValue().toLowerCase().contains(companyNameExpression.toLowerCase())) {
							filterCompanyId = entry.getKey();
							listOfCompanyIds.add(filterCompanyId);
						}
					}
					if (ApplicationUtils.isValidList(listOfCompanyIds)) {
						predicates.add(builder.and(
								root.get(TableConstants.ORDER_ID).get(TableConstants.COMPANY_ID).in(listOfCompanyIds)));
					}

				}
			}
		}
		Expression<String> parentExpression = root.get(TableConstants.ORDER_ID).get(TableConstants.COMPANY_ID);
		Predicate parentPredicate = parentExpression.in(companyNameMaping.keySet());
		
		predicates.add(builder.and(parentPredicate));
		
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		criteria.groupBy(root.get(TableConstants.ORDER_ID).get(TableConstants.COMPANY_ID));
		
		Map<String, Expression<Long>> columnMap = new HashMap<>();
		columnMap.put(ApplicationConstants.TOTAL_TRANSACTIONS, totalTransactionExpression);
		columnMap.put(ApplicationConstants.PENDING_TRANSACTIONS, pendingTransactionExpression);
		if (ApplicationUtils.isValidList(filterVo)) {
			for (FilterOrSortingVo filterSort : filterVo) {
				getFilterPredicates(builder, criteria, columnMap, filterSort);
				getSortingPredicates(builder, criteria, root, totalTransactionExpression, pendingTransactionExpression,
						filterSort);
			}
		}
		List<CompanyAndCountDto> result = new ArrayList<>();
		if (isCount.equals(Boolean.FALSE) && !ApplicationUtils.isValidString(searchValue)) {
			result = (List<CompanyAndCountDto>) getResultList(
					createQuery(builder, criteria, root, predicates).setFirstResult(skip).setMaxResults(limit));
		} else {
			result = (List<CompanyAndCountDto>) getResultList(createQuery(builder, criteria, root, predicates));
		}
		return result;
	}

	/**
	 * @param builder
	 * @param criteria
	 * @param columnMap
	 * @param filterSort
	 * @throws NumberFormatException
	 */
	private void getFilterPredicates(CriteriaBuilder builder, CriteriaQuery<CompanyAndCountDto> criteria,
			Map<String, Expression<Long>> columnMap, FilterOrSortingVo filterSort) throws NumberFormatException {
		if (!filterSort.getColumnName().equals(ApplicationConstants.COMPANY_FILTER_COLUMN_NAME)) {
			if (filterSort.getCondition().equals(ApplicationConstants.BETWEEN)) {
				if (!(filterSort.getValue() == null) && !(filterSort.getValue2() == null)) {
					Expression<Long> columnExpression = columnMap.get(filterSort.getColumnName());
					criteria.having(builder.between(columnExpression, Long.parseLong(filterSort.getValue()),
							Long.parseLong(filterSort.getValue2())));
				}
			} else if (!(filterSort.getValue() == null) && (filterSort.getValue2() == null)) {
				Expression<Long> totalCountExprsn = columnMap.get(filterSort.getColumnName());
				criteria.having(builder.gt(totalCountExprsn, Long.parseLong(filterSort.getValue())));
			} else if ((filterSort.getValue() == null) && !(filterSort.getValue2() == null)) {
				Expression<Long> pendingCountExprsn = columnMap.get(filterSort.getColumnName());
				criteria.having(builder.lt(pendingCountExprsn, Long.parseLong(filterSort.getValue2())));
			}
		}
	}

	/**
	 * @param builder
	 * @param criteria
	 * @param root
	 * @param totalTransactionExpression
	 * @param pendingTransactionExpression
	 * @param filterSort
	 */
	private void getSortingPredicates(CriteriaBuilder builder, CriteriaQuery<CompanyAndCountDto> criteria,
			Root<PaymentDetails> root, Expression<Long> totalTransactionExpression,
			Expression<Long> pendingTransactionExpression, FilterOrSortingVo filterSort) {

		Map<String, Expression<Long>> columnMap = new HashMap<>();
		columnMap.put(ApplicationConstants.PENDING_TRANSACTIONS, pendingTransactionExpression);
		columnMap.put(ApplicationConstants.TOTAL_TRANSACTIONS, totalTransactionExpression);

		if (filterSort.getFilterOrSortingType().equals(ApplicationConstants.SORTING)) {
			String columnName = filterSort.getColumnName();
			boolean direction = filterSort.isAscending();
			if (columnName.equals(ApplicationConstants.TOTAL_TRANSACTIONS)) {
				if (direction == true) {
					criteria.orderBy(builder.asc(totalTransactionExpression));
				} else {
					criteria.orderBy(builder.desc(totalTransactionExpression));
				}
			} else if (columnName.equals(ApplicationConstants.PENDING_TRANSACTIONS)) {
				if (direction == true) {
					criteria.orderBy(builder.asc(pendingTransactionExpression));
				} else {
					criteria.orderBy(builder.desc(pendingTransactionExpression));
				}
			}
		}
	}

	/**
	 * @param compIdNameMap
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public List<NotificationCount> getNotificationCount(Map<Integer, String> compIdNameMap)
			throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<NotificationCount> criteria = builder.createQuery(NotificationCount.class);
		Root<StockNotification> root = criteria.from(StockNotification.class);
		Expression<Long> countExpression1 = builder.count(root);
		criteria.multiselect(countExpression1, root.get(TableConstants.ACTEDBY));
		List<Predicate> predicates = new ArrayList<>();
		Expression<String> parentExpression = root.get(TableConstants.ACTEDBY);
		Predicate parentPredicate = parentExpression.in(compIdNameMap.keySet());
		predicates.add(builder.and(parentPredicate));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_READ), false)));
		criteria.groupBy(root.get(TableConstants.ACTEDBY));
		@SuppressWarnings("unchecked")
		List<NotificationCount> result = (List<NotificationCount>) getResultList(
				createQuery(builder, criteria, root, predicates));
		return result;
	}

	/**
	 * Gets the all companies count.
	 *
	 * @return the all companies count
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object[] getAllCompaniesCount() throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Object[]> criteria = builder.createQuery(Object[].class);
		Root<PaymentDetails> root = criteria.from(PaymentDetails.class);
		Expression<Long> totalCount = builder.count(root);
		Expression<Long> pendingCount = builder.sumAsLong(
				builder.<Integer>selectCase().when(builder.equal(root.get(TableConstants.DP_PAYMENT_STATUS), 2), 1));
		criteria.multiselect(totalCount, pendingCount);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		Object[] result = (Object[]) getResultList(createQuery(builder, criteria, root, predicates)).stream()
				.findFirst().orElse(null);
		return result;
	}

	/**
	 * Gets the purchase history count.
	 *
	 * @return the purchase history count
	 */
	@Override
	public Long getPurchaseHistoryCount() {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<PaymentDetails> root = criteria.from(PaymentDetails.class);
		criteria.select(builder.countDistinct(root.get(TableConstants.ORDER_ID).get(TableConstants.COMPANY_ID)));
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		return (Long) getSingleResult(createQuery(builder, criteria, root, predicates));
	}

}
