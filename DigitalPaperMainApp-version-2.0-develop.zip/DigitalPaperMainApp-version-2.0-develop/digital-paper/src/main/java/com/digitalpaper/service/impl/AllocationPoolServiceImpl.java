package com.digitalpaper.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.config.property.EnvironmentProperties;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.dao.StockTransactionHistoryDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.exception.core.codes.ErrorId;
import com.digitalpaper.exception.core.codes.ErrorId.ErrorHint;
import com.digitalpaper.purchasestock.dao.AllocationPoolDao;
import com.digitalpaper.restemplate.service.IRestTemplateService;
import com.digitalpaper.service.AllocationPoolService;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.AllPoolDto;
import com.digitalpaper.transfer.object.dto.AllocationUserTypeDto;
import com.digitalpaper.transfer.object.dto.AllocationUserTypeList;
import com.digitalpaper.transfer.object.dto.PoolDto;
import com.digitalpaper.transfer.object.dto.StockDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.dto.UserManagementListDto;
import com.digitalpaper.transfer.object.dto.UserRoleDto;
import com.digitalpaper.transfer.object.entity.Stock;
import com.digitalpaper.transfer.object.entity.StockPool;
import com.digitalpaper.transfer.object.entity.StockTransactionHistory;
import com.digitalpaper.transfer.object.enums.PoolActionTypeEnum;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;
import com.digitalpaper.utils.core.ApplicationUtils;
import com.digitalpaper.utils.core.RestTemplateUtils;

/**
 * The Class AllocationPoolServiceImpl.
 */
@Service
@Transactional
public class AllocationPoolServiceImpl implements AllocationPoolService {
	
	/**
	 * AllocationPoolDao
	 */
	@Autowired
	private AllocationPoolDao allocationPoolDao;
	
	/**
	 * LoggedInUserContextHolder
	 */
	@Autowired
	private LoggedInUserContextHolder loggedInUserContextHolder;
	
	/**
	 * ModelMapper
	 */
	@Autowired
	private ModelMapper modelMapper;
	
	/**
	 * RestTemplateUtils
	 */
	@Autowired
	private RestTemplateUtils restTemplateUtils;
	
	/**
	 *  EnvironmentProperties
	 */
	@Autowired
	private EnvironmentProperties environmentProperties;
	
	/**
	 * RestTemplate
	 */
	@Autowired
    private RestTemplate restTemplate;
	
	/**
	 * IRestTemplateService
	 */
	@Autowired
	private IRestTemplateService restTemplateService;
	
	/** The stock transaction history dao. */
	@Autowired
	private StockTransactionHistoryDao stockTransactionHistoryDao;

	/**
	 * @method updatePoolCountByPoolAction
	 * @param PoolDto
	 * @return StockDto
	 */
	@Override
	public StockDto updatePoolCountByPoolAction(PoolDto poolDto,HttpServletRequest request) throws ApplicationException {
		if (ApplicationUtils.isValidId(poolDto.getStockCount()) && poolDto.getStockCount()<=0) {
			throw new ApplicationException(ErrorCodes.INVALID_STOCK_COUNT);
		}
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		Stock stockByCompanyId = allocationPoolDao.getStockByCompanyId(loggedInUser.getCompanyId());
		if (!ApplicationUtils.isValidateObject(stockByCompanyId)) {
			throw new ApplicationException(ErrorCodes.INVALID_STOCK);
		}
		StockPool stockPoolById = allocationPoolDao.getStockPoolById(poolDto.getPoolId(),loggedInUser.getCompanyId(),Boolean.TRUE);	
		
		ApplicationResponse allUsersSpecificToACompany = restTemplateService.getAllUsersSpecificToACompany(request);
		
		List<Object> content = allUsersSpecificToACompany.getContent();
		
		List<UserManagementListDto> usersList=content.stream().map(el->
			modelMapper.map(el,UserManagementListDto.class)
		).collect(Collectors.toList());
				
		List<UserRoleDto> userRoleList = usersList.stream()
											 .filter(users->users.getIsDisable().equals(Boolean.FALSE))
											 .flatMap(users->users.getUserRoleList().stream()).collect(Collectors.toList());
		List<Integer> poolIdList = userRoleList.stream().map(UserRoleDto::getAllocationUserType)
											.filter(allocationPoolId->ApplicationUtils.isValidId(allocationPoolId))
											.collect(Collectors.toList());
		boolean isPresent = poolIdList.stream().anyMatch(id -> id.equals(poolDto.getUserTypeId()));
		
		if(Boolean.FALSE.equals(isPresent) && !poolDto.getPoolAction().equalsIgnoreCase(ApplicationConstants.DEALLOCATE) ) {
			throwNoUserAssociatedException(poolDto.getPoolName());
		}
		if (!ApplicationUtils.isValidateObject(stockPoolById)) {
			throw new ApplicationException(ErrorCodes.INVALID_STOCK_POOL);
		}
		Integer availableStockCount = stockByCompanyId.getStockCount() - stockByCompanyId.getUsedCount();
		Integer availableStockPoolCount = stockPoolById.getStockCount() - stockPoolById.getUsedCount();
		if (!ApplicationUtils.isValidString(poolDto.getPoolAction())) {
			throw new ApplicationException(ErrorCodes.INVALID_ACTION);
		}
		if ((poolDto.getStockCount() >availableStockCount) && poolDto.getPoolAction().equalsIgnoreCase(ApplicationConstants.ALLOCATE)) {
			throw new ApplicationException(ErrorCodes.INSUFFICIENT_STOCK);
		}
		if (((poolDto.getStockCount() > availableStockPoolCount) && poolDto.getPoolAction().equalsIgnoreCase(ApplicationConstants.REALLOCATE)) || 
				((poolDto.getStockCount() >availableStockPoolCount) && poolDto.getPoolAction().equalsIgnoreCase(ApplicationConstants.DEALLOCATE))) {
			throw new ApplicationException(ErrorCodes.INSUFFICIENT_STOCK);
		}
		Stock updatedStock = null;
		StockPool updatedStockPool = null;
		AllPoolDto allPoolDto = new AllPoolDto();
		if (poolDto.getPoolAction().equalsIgnoreCase(ApplicationConstants.ALLOCATE)) {
			allPoolDto = allocateStock(stockByCompanyId,updatedStock,stockPoolById,updatedStockPool,poolDto,loggedInUser,allPoolDto);
		}
		else if(poolDto.getPoolAction().equalsIgnoreCase(ApplicationConstants.REALLOCATE)) {
			if (ApplicationUtils.isNotValidId(poolDto.getReAllocateToId())) {
				throw new ApplicationException(ErrorCodes.INVALID_REALLOCATION_POOL);
			}
			StockPool reAllocateStockPool = allocationPoolDao.getStockPoolById(poolDto.getReAllocateToId(),loggedInUser.getCompanyId(),Boolean.FALSE);
			if (!ApplicationUtils.isValidateObject(reAllocateStockPool)) {
				throw new ApplicationException(ErrorCodes.INVALID_STOCK_POOL);
			}
			if (Boolean.FALSE.equals(reAllocateStockPool.getIsActive()) ) {
				throw new ApplicationException(ErrorCodes.INACTIVE_STOCK_POOL);
			}
			allPoolDto = reAllocateStock(reAllocateStockPool,stockPoolById,updatedStockPool,poolDto,loggedInUser,allPoolDto,stockByCompanyId);
		}
		else if (poolDto.getPoolAction().equalsIgnoreCase(ApplicationConstants.DEALLOCATE)) {
			allPoolDto = deAllocateStock(stockByCompanyId,updatedStock,stockPoolById,updatedStockPool,poolDto,loggedInUser,allPoolDto);
		}
		
		if (ApplicationUtils.isValidateObject(allPoolDto.getStock())) {
			allocationPoolDao.updateStock(allPoolDto.getStock());
		}
		
		if (ApplicationUtils.isValidateObject(allPoolDto.getStockPool())) {
			allocationPoolDao.updateStockPool(allPoolDto.getStockPool());
		}
		
		if (ApplicationUtils.isValidateObject(allPoolDto.getReAllocateStockPool())) {
			allocationPoolDao.updateStockPool(allPoolDto.getReAllocateStockPool());
		}
		
		StockDto stockDto = modelMapper.map(allPoolDto.getStockPool(), StockDto.class);
		
		return stockDto;
	}



	/**
	 * Throw no user associated exception.
	 *
	 * @param poolName the pool name
	 * @throws ApplicationException the application exception
	 */
	private void throwNoUserAssociatedException(String poolName) throws ApplicationException {
		List<ErrorId.ErrorHint> errorHint = new ArrayList<ErrorId.ErrorHint>();
		errorHint.add(new ErrorHint(ApplicationConstants.POOL,poolName));
		
		String errorMessage = ErrorCodes.NO_USER_ASSOCIATED_POOL.getErrorMessage()
										.replace(ApplicationConstants.POOL, poolName);
							
		throw new ApplicationException(new ErrorId(ErrorCodes.NO_USER_ASSOCIATED_POOL.getErrorCode(),
													errorMessage,
													errorHint));
	}



	/**
	 * @method DeAllocation
	 * @param stockByCompanyId
	 * @param updatedStock
	 * @param stockPoolById
	 * @param updatedStockPool
	 * @param poolDto
	 * @param loggedInUser
	 * @param allPoolDto
	 * @return AllPoolDto
	 */
	private AllPoolDto deAllocateStock(Stock stockByCompanyId, Stock updatedStock, StockPool stockPoolById,
			StockPool updatedStockPool, PoolDto poolDto, UserInfo loggedInUser, AllPoolDto allPoolDto) {
		updatedStock = stockByCompanyId;
		updatedStock.setModifiedBy(loggedInUser.getId());
		updatedStock.setModifiedDate(LocalDateTime.now());
		updatedStock.setUsedCount(stockByCompanyId.getUsedCount() - poolDto.getStockCount());
		
		updatedStockPool = stockPoolById;
		updatedStockPool.setModifiedBy(loggedInUser.getId());
		updatedStockPool.setModifiedDate(LocalDateTime.now());
		updatedStockPool.setStockCount(stockPoolById.getStockCount() - poolDto.getStockCount());
		
		allPoolDto.setStock(updatedStock);
		allPoolDto.setStockPool(updatedStockPool);
		
		
		StockTransactionHistory createDebitHistory = createDebitHistory(poolDto.getPoolAction(),updatedStockPool,updatedStock,poolDto,loggedInUser);
		StockTransactionHistory createCreditHistory = createCreditHistory(poolDto.getPoolAction(),updatedStockPool,updatedStock,poolDto,loggedInUser);
		try {
			stockTransactionHistoryDao.saveStockTransactionHistory(createDebitHistory);
			stockTransactionHistoryDao.saveStockTransactionHistory(createCreditHistory);
		} catch (ApplicationException e) {
			e.printStackTrace();
		}

		return allPoolDto;
	}
	
	/**
	 * Creates the debit history.
	 *
	 * @param poolAction the pool action
	 * @param updatedStockPool the updated stock pool
	 * @param updatedStock the updated stock
	 * @param poolDto the pool dto
	 * @param loggedInUser the logged in user
	 * @return the stock transaction history
	 */
	private StockTransactionHistory createDebitHistory(String poolAction, StockPool updatedStockPool,
			Stock updatedStock, PoolDto poolDto, UserInfo loggedInUser) {
		StockTransactionHistory stockDebitHistory = new StockTransactionHistory();
		stockDebitHistory.setPoolActionType(PoolActionTypeEnum.getPaperStatusIdByName(poolAction).getId());
		stockDebitHistory.setDebitedStock(poolDto.getStockCount());
		stockDebitHistory.setCreditedStock(0);
		if (!poolAction.equals(ApplicationConstants.ALLOCATE)) {
			stockDebitHistory.setStockPoolId(updatedStockPool);
		}
		stockDebitHistory.setStockId(updatedStock);
		stockDebitHistory.setCreatedBy(loggedInUser.getId());
		stockDebitHistory.setCreatedDate(LocalDateTime.now());
		return stockDebitHistory;
	}
	
	/**
	 * Creates the credit history.
	 *
	 * @param poolAction the pool action
	 * @param updatedStockPool the updated stock pool
	 * @param updatedStock the updated stock
	 * @param poolDto the pool dto
	 * @param loggedInUser the logged in user
	 * @return the stock transaction history
	 */
	private StockTransactionHistory createCreditHistory(String poolAction, StockPool updatedStockPool,
			Stock updatedStock, PoolDto poolDto, UserInfo loggedInUser) {
		StockTransactionHistory stockCreditHistory = new StockTransactionHistory();
		stockCreditHistory.setPoolActionType(PoolActionTypeEnum.getPaperStatusIdByName(poolAction).getId());
		stockCreditHistory.setDebitedStock(0);
		stockCreditHistory.setCreditedStock(poolDto.getStockCount());
		if (!poolAction.equals(ApplicationConstants.DEALLOCATE)) {
			stockCreditHistory.setStockPoolId(updatedStockPool);
		}
		stockCreditHistory.setStockId(updatedStock);
		stockCreditHistory.setCreatedBy(loggedInUser.getId());
		stockCreditHistory.setCreatedDate(LocalDateTime.now());
		return stockCreditHistory;
	}





	/**
	 * @method ReAllocation
	 * @param reAllocateStockPool
	 * @param stockPoolById
	 * @param updatedStockPool
	 * @param poolDto
	 * @param loggedInUser
	 * @param allPoolDto
	 * @return AllPoolDto
	 */
	private AllPoolDto reAllocateStock(StockPool reAllocateStockPool, StockPool stockPoolById,
			StockPool updatedStockPool, PoolDto poolDto, UserInfo loggedInUser, AllPoolDto allPoolDto,Stock stockByCompanyId) {
		
		updatedStockPool = stockPoolById;
		updatedStockPool.setModifiedBy(loggedInUser.getId());
		updatedStockPool.setModifiedDate(LocalDateTime.now());
		updatedStockPool.setStockCount(stockPoolById.getStockCount() - poolDto.getStockCount());
		
		reAllocateStockPool.setModifiedBy(loggedInUser.getId());
		reAllocateStockPool.setModifiedDate(LocalDateTime.now());
		reAllocateStockPool.setStockCount(reAllocateStockPool.getStockCount() + poolDto.getStockCount());
		allPoolDto.setReAllocateStockPool(reAllocateStockPool);
		allPoolDto.setStockPool(updatedStockPool);
		
		StockTransactionHistory createDebitHistory = createDebitHistory(poolDto.getPoolAction(),updatedStockPool,stockByCompanyId,poolDto,loggedInUser);
		StockTransactionHistory createCreditHistory = createCreditHistory(poolDto.getPoolAction(),reAllocateStockPool,stockByCompanyId,poolDto,loggedInUser);
		try {
			stockTransactionHistoryDao.saveStockTransactionHistory(createDebitHistory);
			stockTransactionHistoryDao.saveStockTransactionHistory(createCreditHistory);
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
		return allPoolDto;
	}



	/**
	 * @method Allocation
	 * @param stockByCompanyId
	 * @param updatedStock
	 * @param stockPoolById
	 * @param updatedStockPool
	 * @param poolDto
	 * @param loggedInUser
	 * @param allPoolDto
	 * @return AllPoolDto
	 */
	private AllPoolDto allocateStock(Stock stockByCompanyId, Stock updatedStock, StockPool stockPoolById,
			StockPool updatedStockPool, PoolDto poolDto, UserInfo loggedInUser, AllPoolDto allPoolDto) {
		
		
		updatedStock = stockByCompanyId;
		updatedStock.setModifiedBy(loggedInUser.getId());
		updatedStock.setModifiedDate(LocalDateTime.now());
		updatedStock.setUsedCount(stockByCompanyId.getUsedCount() + poolDto.getStockCount());
		
		updatedStockPool = stockPoolById;
		updatedStockPool.setModifiedBy(loggedInUser.getId());
		updatedStockPool.setModifiedDate(LocalDateTime.now());
		updatedStockPool.setStockCount(stockPoolById.getStockCount() + poolDto.getStockCount());
		
		allPoolDto.setStock(updatedStock);
		allPoolDto.setStockPool(updatedStockPool);
		
		StockTransactionHistory createDebitHistory = createDebitHistory(poolDto.getPoolAction(),updatedStockPool,stockByCompanyId,poolDto,loggedInUser);
		StockTransactionHistory createCreditHistory = createCreditHistory(poolDto.getPoolAction(),updatedStockPool,stockByCompanyId,poolDto,loggedInUser);
		try {
			stockTransactionHistoryDao.saveStockTransactionHistory(createDebitHistory);
			stockTransactionHistoryDao.saveStockTransactionHistory(createCreditHistory);
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
		return allPoolDto;
		
	}



	/**
	 * @param identity
	 * @method getStockPoolFromIdentity
	 * @return StockDto
	 * @throws ApplicationException 
	 */
	@Override
	public StockDto getStockPoolFromIdentity(String identity) throws ApplicationException {
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		StockPool stock = allocationPoolDao.getStockPoolFromIdentity(identity);
		if (!ApplicationUtils.isValidateObject(stock)) {
			throw new ApplicationException(ErrorCodes.INVALID_STOCK_POOL);
		}
		StockDto stockDto = modelMapper.map(stock, StockDto.class);
		return stockDto;
	}



	/**
	 * @param identity
	 * @param request
	 * @return List<StockDto>
	 * @throws ApplicationException
	 */
	@Override
	public List<StockDto> getAllStockPool(String identity, HttpServletRequest request,
			List<FilterOrSortingVo> filterPaginationVo, Integer min, Integer max, String searchValue) throws ApplicationException {
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();

		List<FilterOrSortingVo> filterVo = new ArrayList<>();
		List<FilterOrSortingVo> filterVo1 = new ArrayList<>();
		List<FilterOrSortingVo> filterVo2 = new ArrayList<>();
		for (FilterOrSortingVo oneFilterOrSortingVo : filterPaginationVo) {
			if (oneFilterOrSortingVo.getColumnName().equals(ApplicationConstants.NULL)) {
				filterVo2.add(oneFilterOrSortingVo);
			} else if (oneFilterOrSortingVo.getColumnName().equals(ApplicationConstants.USER_TYPE_NAME)
					|| oneFilterOrSortingVo.getColumnName().equals(ApplicationConstants.IDENTITY_CONSTANT)) {
				filterVo1.add(oneFilterOrSortingVo);
			} else {
				filterVo.add(oneFilterOrSortingVo);
			}
		}
		
		List<AllocationUserTypeDto> allocationUserTypeList = getAllocation(request, filterVo1);
		List<Integer> collect = allocationUserTypeList.stream().map(x->x.getId()).collect(Collectors.toList());
		
		min = 0;
		max = allocationUserTypeList.size();


		List<StockPool> listOfPool = allocationPoolDao.getAllStockPoolList(collect, loggedInUser.getCompanyId(),filterVo, min, max);

		if (listOfPool.size() == 0) {
			throw new ApplicationException(ErrorCodes.NO_STOCK_POOL);
		}
		List<StockDto> stocks = listOfPool.stream().map(e -> modelMapper.map(e, StockDto.class))
				.collect(Collectors.toList());

		

		List<StockDto> stocks1 = new ArrayList<>();

		for (StockDto oneStock : stocks) {
			for (AllocationUserTypeDto allocationUserTypeDto : allocationUserTypeList) {
				if (allocationUserTypeDto.getId() == oneStock.getUserTypeId()) {
					StockDto stock = new StockDto();
					stock = oneStock;
					stock.setUserTypeName(allocationUserTypeDto.getUserTypeName());
					stock.setUserTypeIdentity(allocationUserTypeDto.getIdentity());
					stock.setAvailableCount(stock.getStockCount() - stock.getUsedCount());
					stocks1.add(stock);
				}
			}
		}
		List<StockDto> stocks2 = stocks1;
		
		if (ApplicationUtils.isValidString(searchValue)) {
			stocks2 =	stocks2.stream().filter(x->x.getUserTypeName().toLowerCase().contains(searchValue.toLowerCase()) || x.getAvailableCount().toString().contains(searchValue) 
					|| x.getStockCount().toString().contains(searchValue) || x.getUsedCount().toString().contains(searchValue) ).collect(Collectors.toList());
			
		}
		
			if (ApplicationUtils.isValidList(filterVo2)&& filterVo2.get(0).getValue()!= null) {
			
			for (FilterOrSortingVo filter : filterVo2) {
				if (filter.getCondition() != null) {
					if (filter.getCondition().equals(ApplicationConstants.LT) && filter.getValue()!= null) {
						stocks2 = stocks1.stream().filter(e -> (e.getStockCount() - e.getUsedCount()) <= Integer.parseInt(filter.getValue())).collect(Collectors.toList());
					} else if (filter.getCondition().equals(ApplicationConstants.GT) && filter.getValue()!= null) {
						stocks2 = stocks1.stream().filter(e -> (e.getStockCount() - e.getUsedCount()) >= Integer.parseInt(filter.getValue())).collect(Collectors.toList());
					} else if (filter.getCondition().equals(ApplicationConstants.BETWEEN) && filter.getValue()!= null && filter.getValue2()!= null) {
						stocks2 = stocks1.stream().filter(e -> ((e.getStockCount() - e.getUsedCount()) >= Integer.parseInt(filter.getValue())
								 && (e.getStockCount() - e.getUsedCount()) <= Integer.parseInt(filter.getValue2()))).collect(Collectors.toList());
					}
				}
				
			}
		}
		if (ApplicationUtils.isValidateObject(filterPaginationVo)) {
			
			for (FilterOrSortingVo filterPagination : filterPaginationVo) {
				if (filterPagination.getFilterOrSortingType().equals(ApplicationConstants.SORTING)) {
					boolean ascending = filterPagination.isAscending();
					if (filterPagination.getColumnName().equals(ApplicationConstants.USER_TYPE_NAME) && ascending) {
						stocks2 = stocks2.stream().sorted(Comparator.comparing(StockDto::getUserTypeName)).collect(Collectors.toList());
					} else if (filterPagination.getColumnName().equals(ApplicationConstants.USER_TYPE_NAME) && !ascending) {
						stocks2 = stocks2.stream().sorted(Comparator.comparing(StockDto::getUserTypeName).reversed()).collect(Collectors.toList());
					} else if (filterPagination.getColumnName().equals(ApplicationConstants.IDENTITY_CONSTANT)&& ascending) {
						stocks2 = stocks2.stream().sorted(Comparator.comparing(StockDto::getIdentity)).collect(Collectors.toList());
					} else if (filterPagination.getColumnName().equals(ApplicationConstants.IDENTITY_CONSTANT)&& !ascending) {
						stocks2 = stocks2.stream().sorted(Comparator.comparing(StockDto::getIdentity).reversed()).collect(Collectors.toList());
					} else if (filterPagination.getColumnName().equals(ApplicationConstants.NULL) && !ascending) {
						stocks2 = stocks2.stream().sorted(Comparator.comparing(StockDto::getAvailableCount).reversed()).collect(Collectors.toList());
					} else if (filterPagination.getColumnName().equals(ApplicationConstants.NULL) && ascending) {
						stocks2 = stocks2.stream().sorted(Comparator.comparing(StockDto::getAvailableCount)).collect(Collectors.toList());
					}
				}
				
			}

		}
		return stocks2;
	}
	
	/**
	 * Gets the allocation.
	 *
	 * @param request the request
	 * @param filterVo1 the filter vo 1
	 * @return the allocation
	 */
	public List<AllocationUserTypeDto> getAllocation(HttpServletRequest request, List<FilterOrSortingVo> filterVo1){
		HttpHeaders httpHeaders = restTemplateUtils.configureRestTemplate(request);
		HttpEntity<List<FilterOrSortingVo>> entity = new HttpEntity<>(filterVo1,httpHeaders);
		String url = environmentProperties.getCommonServicePath() + ApplicationConstants.USER_TYPE_PATH;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		ResponseEntity<AllocationUserTypeList> exchange = restTemplate.exchange(builder.toUriString(), HttpMethod.POST, entity, AllocationUserTypeList.class);
		AllocationUserTypeList body = exchange.getBody();
		List<AllocationUserTypeDto> allocationUserTypeList = body.getAllocationUserTypeList();
		return allocationUserTypeList;
	}



	/**
	 * Change stock pool status.
	 *
	 * @param status the status
	 * @param identity the identity
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void changeStockPoolStatus(boolean status, String identity) throws ApplicationException {
		StockPool stock = allocationPoolDao.getStockPoolFromIdentity(identity);
		if (!ApplicationUtils.isValidateObject(stock)) {
			throw new ApplicationException(ErrorCodes.INVALID_STOCK_POOL);
		}
		stock.setIsActive(status);
		allocationPoolDao.updateStockPool(stock);
	}



	/**
	 * Gets the stock pool count.
	 *
	 * @param request the request
	 * @return the stock pool count
	 */
	@Override
	public Integer getStockPoolCount(HttpServletRequest request) {
		List<FilterOrSortingVo> filterVo1 = new ArrayList<>();
		List<AllocationUserTypeDto> allocationUserTypeList = getAllocation(request,filterVo1);
		Integer size = allocationUserTypeList.size();
		return size;
	}
	
	/**
	 * @param request
	 */
	@Override
	public String getAllocationType(HttpServletRequest request) throws ApplicationException {
		UserInfo user = loggedInUserContextHolder.getLoggedInUser();
		if (!ApplicationUtils.isValidateObject(user)) {
			throw new ApplicationException(ErrorCodes.INVALID_USER);
		}
		return restTemplateService.getAllocationType(ApplicationConstants.ALLOCATION_TYPE, user.getAssociationId(),
				request);
	}
	

}
