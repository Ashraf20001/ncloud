package com.digitalpaper.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.service.IDigItalPaperExternalApiService;
import com.digitalpaper.transfer.object.dto.DigitalPaperDto;
import com.digitalpaper.transfer.object.dto.ExternalApiDigitalPaperDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class DigItalPaperExternalApiController.
 */
@RestController
public class DigItalPaperExternalApiController {
	
	/** The dig ital paper external api service. */
	@Autowired
	private IDigItalPaperExternalApiService digItalPaperExternalApiService;
	
	/**
	 * Save external api dto.
	 *
	 * @param dto the dto
	 * @param request the request
	 * @return the string
	 * @throws ApplicationException the application exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@ApiOperation(value="Digital paper save",notes="External api digital paper creation",response=String.class)
	@PostMapping("/saveDigitalPaper")
	public String saveExternalApiDto(@ApiParam(value="Digital paper dto payload",required = true)  @RequestBody DigitalPaperDto dto,HttpServletRequest request) throws ApplicationException, IOException {
		return digItalPaperExternalApiService.saveExternalApiDto(dto,request);
	}
	
	/**
	 * Gets the external api dto.
	 *
	 * @param pdDigitalPaperId the pd digital paper id
	 * @param request the request
	 * @return the external api dto
	 * @throws ApplicationException the application exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@ApiOperation(value="Digital paper details",notes="External api digital paper fetch",response=ExternalApiDigitalPaperDto.class)
	@GetMapping("/getDigitalPaper")
	public ExternalApiDigitalPaperDto getExternalApiDto(@ApiParam(value="Digital paperId",required = true)   @RequestParam String pdDigitalPaperId,HttpServletRequest request) throws ApplicationException, IOException {
		return digItalPaperExternalApiService.getExternalApiDto(pdDigitalPaperId,request);
	}

}
