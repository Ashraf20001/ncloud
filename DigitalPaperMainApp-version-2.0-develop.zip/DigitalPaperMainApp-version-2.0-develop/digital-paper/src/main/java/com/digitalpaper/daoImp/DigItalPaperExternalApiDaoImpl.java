package com.digitalpaper.daoImp;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.digitalpaper.config.common.base.dao.BaseDao;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.IDigItalPaperExternalApiDao;
import com.digitalpaper.transfer.object.entity.PaperDetails;

/**
 * The Class DigItalPaperExternalApiDaoImpl.
 */
@Repository
@Transactional
public class DigItalPaperExternalApiDaoImpl  extends BaseDao implements IDigItalPaperExternalApiDao{

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
		
	}

	/**
	 * Gets the external api dto.
	 *
	 * @param pdDigitalPaperId the pd digital paper id
	 * @return the external api dto
	 */
	@Override
	public PaperDetails getExternalApiDto(String pdDigitalPaperId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
		Root<PaperDetails> root = criteria.from(PaperDetails.class);
		criteria.select((root));
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.PD_PURCHASR_ID), pdDigitalPaperId)));
		return (PaperDetails) getSingleResult(createQuery(builder, criteria, root, predicates));
		}

}
