package com.digitalpaper.service.impl;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.mail.MessagingException;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.config.property.EnvironmentProperties;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.CustomerDao;
import com.digitalpaper.dao.IDigitalPaperDao;
import com.digitalpaper.dao.IPaperDetailsDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.restemplate.service.RestTemplateServiceImpl;
import com.digitalpaper.service.CustomerService;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.ChangePasswordDto;
import com.digitalpaper.transfer.object.dto.CustomerDto;
import com.digitalpaper.transfer.object.dto.CustomerWithPassword;
import com.digitalpaper.transfer.object.dto.MailRequestDto;
import com.digitalpaper.transfer.object.dto.ResetPasswordDto;
import com.digitalpaper.transfer.object.dto.ResetPasswordRequest;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.entity.Customer;
import com.digitalpaper.transfer.object.entity.FileStorage;
import com.digitalpaper.transfer.object.entity.ForgetPassword;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;
import com.digitalpaper.utils.EmailProducer;
import com.digitalpaper.utils.core.ApplicationUtils;
import com.fasterxml.jackson.core.JsonProcessingException;

import freemarker.core.ParseException;
import freemarker.template.MalformedTemplateNameException;
import freemarker.template.TemplateException;
import freemarker.template.TemplateNotFoundException;

/**
 * The Class CustomerServiceImpl.
 */
@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	/** The customer dao. */
	@Autowired
	private CustomerDao customerDao;
	
	/** The email producer. */
	@Autowired
	private EmailProducer emailProducer;

	/** The logged in user context holder. */
	@Autowired
	private LoggedInUserContextHolder loggedInUserContextHolder;

	/** The environment properties. */
	@Autowired
    private EnvironmentProperties environmentProperties;
	
	/** The digital paper dao. */
	@Autowired
	private IDigitalPaperDao digitalPaperDao;

	/** The model mapper. */
	@Autowired
	private ModelMapper modelMapper;
	
	/** The i paper details dao. */
	@Autowired
	private IPaperDetailsDao iPaperDetailsDao;

	/** The send email. */
	@Autowired
	private EmailSenderService sendEmail;
	
	/** The rest template service. */
	@Autowired
	private RestTemplateServiceImpl restTemplateService;
	
	/** The url. */
	@Value("${dpmainapp.forgetPasswordUrlCustomer}")
	private String url;
	
	/** The customer portal url. */
	@Value("${dpmainapp.customer-portal-url}")
	private String customerPortalUrl;
	
	/** The Constant Subject. */
	private static final String Subject="Reset Password" ;
	
	/** The Constant expireInMinute. */
	private static final int expireInMinute=10 ;
	
	/** The Constant templateSentence. */
	private static final String templateSentence="To reset your password, please click here : " ;
	
	/** The Constant Template_Folder_Path. */
	public static final String Template_Folder_Path="/Tempplate";
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER= LoggerFactory.getLogger(CustomerServiceImpl.class);
	
	/**
	 * Gets the coustomer count.
	 *
	 * @param filter the filter
	 * @param searchvalue the searchvalue
	 * @return the coustomer count
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Long getCoustomerCount(List<FilterOrSortingVo> filter, String searchvalue) throws ApplicationException {
		
		UserInfo userInfo = loggedInUserContextHolder.getLoggedInUser();
		Integer companyId = userInfo.getCompanyId();
		
		Long paperDetailsCustomerCount= null;
		
		if(ApplicationUtils.isValidId(companyId)) {
			paperDetailsCustomerCount = iPaperDetailsDao.getPaperDetailsCustomerCount(filter,companyId, searchvalue);
			
		}
		return paperDetailsCustomerCount;
	}
	
	/**
	 *@param min
	 *@param max
	 *@param filter
	 *@return
	 *@throws ApplicationException
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 * @throws SecurityException 
	 * @throws NoSuchFieldException 
	 */
	@Override
	public List<CustomerDto> getCustomerList(Integer min,Integer max,List<FilterOrSortingVo> filter, String searchValue) throws ApplicationException{

		List<CustomerDto> customerDtoList = new ArrayList<CustomerDto>();
		UserInfo userInfo = loggedInUserContextHolder.getLoggedInUser();
		Integer companyId = userInfo.getCompanyId();
		List<Object[]> customerDetails = iPaperDetailsDao.getPaperDetailsCustomerList(min, max, filter, companyId, searchValue);
		if(ApplicationUtils.isValidList(customerDetails)) {
			try {
				customerDtoList=convertCustomerDetailsEntitytoDto(customerDetails);
			} catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
				e.printStackTrace();
			}
		}
		return customerDtoList;
	}
	
	/**
	 * Updat customer details.
	 *
	 * @param data the data
	 * @return the string
	 * @throws ApplicationException the application exception
	 * @throws TemplateNotFoundException the template not found exception
	 * @throws MalformedTemplateNameException the malformed template name exception
	 * @throws ParseException the parse exception
	 * @throws MessagingException the messaging exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws TemplateException the template exception
	 */
	@Override
	public String updatCustomerDetails(CustomerDto data) throws ApplicationException, TemplateNotFoundException, MalformedTemplateNameException, ParseException, MessagingException, IOException, TemplateException {
		
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		String companyName = loggedInUser.getCompanyName();

		Customer customerEntity;
		if(ApplicationUtils.isValidIdentity(data.getIdentity())){
			customerEntity = customerDao.getCustomerByIdentity(data.getIdentity());
			
			String oldEmail = customerEntity.getEmail();
					
			if(ApplicationUtils.isValidateObject(customerEntity)) {
				
				customerEntity.setEmail(data.getEmail());
				customerEntity.setStatus(data.getStatus());
				customerEntity.setModifiedDate(LocalDateTime.now());
				customerDao.updateCustomer(customerEntity);
				
				if (!oldEmail.equals(data.getEmail())) {
					sendEmailToChangedEmail(oldEmail,data,companyName);
				}
			}
		}	
		return null;
	}

	/**
	 * Send email to changed email.
	 *
	 * @param oldEmail the old email
	 * @param data the data
	 * @param companyName the company name
	 * @throws MessagingException the messaging exception
	 * @throws TemplateNotFoundException the template not found exception
	 * @throws MalformedTemplateNameException the malformed template name exception
	 * @throws ParseException the parse exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws TemplateException the template exception
	 */
	private void sendEmailToChangedEmail(String oldEmail, CustomerDto data, String companyName) throws MessagingException, TemplateNotFoundException, MalformedTemplateNameException, ParseException, IOException, TemplateException {
		
		MailRequestDto request = new MailRequestDto();
		Map<String, Object> model = new HashMap<>();
		
		model.put(ApplicationConstants.EMAIL_NAME, data.getUsername());
		model.put(ApplicationConstants.OLD_EMAIL_ID, oldEmail);
		model.put(ApplicationConstants.NEW_EMAIL_ID, data.getEmail());
		model.put(ApplicationConstants.EMAIL_COMPANY_NAME, companyName);
		model.put(ApplicationConstants.CUSTOMER_URL, customerPortalUrl);
		
		request.setModel(model);
		request.setTemplateName(ApplicationConstants.EMAIL_CHANGES_TEMPLATE);
		request.setTo(data.getEmail());						
		request.setSubject(ApplicationConstants.EMAIL_SUBJECT);				
		request.setFrom(environmentProperties.getSendEmailName());
		request.setAttachmentName(ApplicationConstants.ATTACHMENT_TEMPLATE);
		
		emailProducer.sendEmail(request);				
	}

	/**
	 * Convert customer details entityto dto.
	 *
	 * @param customerDetailsObject the customer details object
	 * @return the list
	 * @throws NoSuchFieldException the no such field exception
	 * @throws SecurityException the security exception
	 * @throws IllegalArgumentException the illegal argument exception
	 * @throws IllegalAccessException the illegal access exception
	 */
	private List<CustomerDto> convertCustomerDetailsEntitytoDto(List<Object[]> customerDetailsObject) throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		List<CustomerDto> customerDtoList = new ArrayList<CustomerDto>();
			for (Object[] customerObject : customerDetailsObject) {
				CustomerDto customerDto = new CustomerDto();
				Class<?> dtoClass= CustomerDto.class;
				Field[] fields = dtoClass.getDeclaredFields();
				
				for(int i=0; i<Math.min(fields.length,customerObject.length); i++) {
					
					Field declaredField = dtoClass.getDeclaredField(fields[i].getName());
					declaredField.setAccessible(true);
					if(declaredField.getName().equalsIgnoreCase(TableConstants.TB_ADDED_DATE) || 
							declaredField.getName().equalsIgnoreCase(TableConstants.CUSTOMER_URL)) {
						customerObject[i]=ApplicationUtils.isValidateObject(customerObject[i])?customerObject[i].toString():null;
					}
					declaredField.set(customerDto,customerObject[i]);
				}
				customerDtoList.add(customerDto);
				
			}

		
		return customerDtoList;
	}

	/**
	 *@param paperIdentity
	 *@param Password
	 *@throws ApplicationException
	 *@return
	 */
	@Override
	public CustomerWithPassword saveCustomer(PaperDetails paperDetails) throws ApplicationException {
		Customer customerEntity=new Customer();
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		Integer userId=loggedInUser.getId();
		String userPwd = null;
		if(ApplicationUtils.isValidateObject(paperDetails)) {

			customerEntity.setAddedDate(paperDetails.getCreatedDate());
			customerEntity.setCompanyId(paperDetails.getCompanyId());
			customerEntity.setCreatedBy(userId);
			customerEntity.setCreatedDate(LocalDateTime.now());
			customerEntity.setEmail(paperDetails.getPdEmailId());
			customerEntity.setIsFirstTimeLogin(true);
			customerEntity.setUsername(paperDetails.getPdInsuredName());
			customerEntity.setModifiedBy(userId);
			customerEntity.setModifiedDate(LocalDateTime.now());
			BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
			int length = 8;
		    boolean useLetters = true;
		    boolean useNumbers = true;
		    userPwd = RandomStringUtils.random(length, useLetters, useNumbers);
			customerEntity.setPassword(encoder.encode(userPwd));
			customerEntity.setPhoneNumber(paperDetails.getPdPhoneNumber());
			customerEntity.setStatus(true);
		}
		
			customerDao.saveCustomer(customerEntity);
			
			CustomerWithPassword customerWithPassword = new CustomerWithPassword(customerEntity, userPwd);			
			
			


		return customerWithPassword;
	}
	
	/**
	 * Email send part.
	 *
	 * @param companyName the company name
	 * @param paperDetailsEntity the paper details entity
	 * @param digitalPaperId the digital paper id
	 * @param userPsw the user psw
	 */
	public void emailSendPart(String companyName, PaperDetails paperDetailsEntity, Integer digitalPaperId,String userPsw) {
		 
		 MailRequestDto request = new MailRequestDto();
			request.setFrom(environmentProperties.getSendEmailName());
			request.setName( paperDetailsEntity.getPdInsuredName());
			request.setSubject("Digital Paper : " + paperDetailsEntity.getPdDigitalPaperId());
			request.setTo(paperDetailsEntity.getPdEmailId());
			
			FileStorage file = iPaperDetailsDao.getPaperImageById(digitalPaperId,
					ApplicationConstants.UPD_TYPE, ApplicationConstants.RP_TYPE);
			if(ApplicationUtils.isValidateObject(file)) {
				
				String url =environmentProperties.getFileUploadPath()+ "/OG_IMAGE/" +  file.getUrl();
				
				File img = new File(url);
				request.setFileURL(img);	
				}
			
			Map<String, Object> model = new HashMap<>();
			model.put("Name", paperDetailsEntity.getPdInsuredName());
			model.put("paperNumber", paperDetailsEntity.getPdDigitalPaperId());
			model.put("CompanyName", companyName);
			model.put("policyNo",paperDetailsEntity.getPdPolicyNumber());
			model.put("registrationNo",paperDetailsEntity.getVdRegistrationNumber());
			model.put("email",paperDetailsEntity.getPdEmailId() );
			model.put("password", userPsw);
			model.put("link", environmentProperties.getCustomerPortalUrl());
			
			request.setModel(model);
			request.setAttachmentName(ApplicationConstants.ATTACHMENT_TEMPLATE);
			request.setTemplateName(ApplicationConstants.CUSTOMER_EMAIL_TEMPLATE);	
				try {
					emailProducer.sendEmail(request);
				} catch (JsonProcessingException e) {
					LOGGER.error(e.getLocalizedMessage());
					e.printStackTrace();
				}
	}

	/**
	 *@param username
	 *@return CustomerDto
	 */
	@Override
	public CustomerDto getCustomerByUsername(String username) {
		username = username.replaceAll("%20", ApplicationConstants.EMPTY_STRING);
		Customer customer = customerDao.getCustomerDetailsByEmailId(username);
		CustomerDto customerDto = new CustomerDto();
		if(ApplicationUtils.isValidateObject(customer)) {
		 customerDto = modelMapper.map(customer, CustomerDto.class);
		}
		return customerDto;
	}

	/**
	 *@return CustomerDto
	 *@throws ApplicationException
	 */
	@Override
	public CustomerDto getLoginCustomerDetails() throws ApplicationException {

		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		Integer userId = loggedInUser.getId();

		Customer customData = new Customer();
		CustomerDto customDto = new CustomerDto();
		if (ApplicationUtils.isValidId(userId)) {
			customData = customerDao.getLoginCustomer(userId);

			if (ApplicationUtils.isValidateObject(customData)) {

				customDto.setAddedDate(customData.getAddedDate().toString());
				customDto.setCustomerId(customData.getCustomerId());
				customDto.setEmail(customData.getEmail());
				customDto.setUsername(customData.getUsername());
				customDto.setPassword(customData.getPassword());
				customDto.setPhoneNumber(customData.getPhoneNumber());
				ApplicationResponse response = restTemplateService.getCustomerProfileUrl(userId, ApplicationConstants.CUSTOMER_RP_TYPE);
				String customerProfileUrl = response.getContent();
				if(ApplicationUtils.isValidString(customerProfileUrl)) {
					customDto.setCustomerUrl(customerProfileUrl);
				}
				
			}
		}

		return customDto;
	}

	/**
	 *@param data
	 *@return void
	 *@throws ApplicationException
	 *
	 */
	@Override
	public String updateLoginCustomer(CustomerDto data) throws ApplicationException {
		
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		Integer customerId = loggedInUser.getId();

		Customer customData = customerDao.getLoginCustomer(customerId);
		if (!ApplicationUtils.isValidateObject(customData)) {
			throw new ApplicationException(ErrorCodes.INVALID_CUSTOMER);
		}
		
		boolean validPhoneNumber = ApplicationUtils.isValidString(data.getPhoneNumber());
		boolean	validPhoneNumberPattern=validPhoneNumber?phoneNumberValidation(data.getPhoneNumber()) : false;
		
		if(!validPhoneNumberPattern && validPhoneNumber) {
			throw new ApplicationException(ErrorCodes.INVALID_PHONE_NO);
		}
		
		customData.setPhoneNumber(validPhoneNumberPattern && validPhoneNumber?data.getPhoneNumber():customData.getPhoneNumber());
		
		boolean validUserName = ApplicationUtils.isValidString(data.getUsername());
		customData.setUsername(validUserName?data.getUsername():customData.getUsername());

		customerDao.updateCustomer(customData);
		
		return ApplicationConstants.SUCCESS;

	}
	
	/**
	 * Phone number validation.
	 *
	 * @param phoneNumber the phone number
	 * @return the boolean
	 */
	private Boolean phoneNumberValidation(String phoneNumber) {
		String phoneRegex="^\\(?\\+?[\\d\\(\\-\\s\\)]+$";
		Pattern phonePattern = Pattern.compile(phoneRegex);
		return phonePattern.matcher(phoneNumber).matches() && phoneNumber.length()<=14;
	}

	/**
	 *@param resetPasswordDto
	 *@throws ApplicationException
	 */
	@Override
	public void resetCustomerPassword(ResetPasswordDto resetPasswordDto) throws ApplicationException {

		String customerIdentity = resetPasswordDto.getIdentity();
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		String encodePassword = encoder.encode(resetPasswordDto.getNewPassword());

		
		Customer customer = null;
		if (resetPasswordDto.getNewPassword().equals(resetPasswordDto.getConfirmPassword())) {
			customer = customerDao.getCustomerByIdentity(customerIdentity);
		}
		
		// Validating with old password
		String encryptedPassword = customer.getPassword();
		 
		if(encoder.matches(resetPasswordDto.getNewPassword(), encryptedPassword)) {
			throw new ApplicationException(ErrorCodes.OLD_NEW_PASSWORD_ERR);
		}
		
		if (!ApplicationUtils.isValidateObject(customer)) {
			throw new ApplicationException(ErrorCodes.INVALID_CUSTOMER);
		}
		if (customer.getPassword().equals(encodePassword)) {
			throw new ApplicationException(ErrorCodes.OLD_NEW_PASSWORD_ERR);
		}


		if (ApplicationUtils.isValidateObject(customer) && Boolean.TRUE.equals(customer.getIsFirstTimeLogin())) {
			customer.setPassword(encodePassword);
			customer.setIsFirstTimeLogin(false);
			customerDao.updateCustomer(customer);
		} else {
			throw new ApplicationException(ErrorCodes.INVALID_DATA);
		}

	}

	/**
	 *@param emailId
	 *@throws ApplicationException
	 *@return 
	 */
	@Override
	public String validateEmail(String emailId) throws ApplicationException {

		LocalDate today = LocalDate.now();
		List<ForgetPassword> forgetDetails = customerDao.getForgetDetailsByEmailId(today, emailId);

		if (forgetDetails.size() < 3) {
			Customer customerByEmail = customerDao.getCustomerByEmailId(emailId);
			if (ApplicationUtils.isValidateObject(customerByEmail)) {

				ForgetPassword forgetPassword = new ForgetPassword();
				Calendar calendar = Calendar.getInstance();
				calendar.add(Calendar.MINUTE, expireInMinute);
				Date date = calendar.getTime();
				forgetPassword.setExpireTime(date);
				forgetPassword.setEmailId(customerByEmail.getEmail());
				forgetPassword.setCustomerDetails(customerByEmail);
				forgetPassword.setCreatedAt(today);
				forgetPassword.setCustomerIdentity(customerByEmail.getIdentity());
				customerDao.saveForgetEntry(forgetPassword);

				List<ForgetPassword> forgetEmailDetails = customerDao.getForgetDetailsByEmailId(today, emailId);
				ForgetPassword forgetPasswordDetail = forgetEmailDetails.get(forgetEmailDetails.size() - 1);

				String forgetPasswordIdentity = forgetPasswordDetail.getIdentity();
				String customerEmail = customerByEmail.getEmail();
				String encryptedCustomerEmail = doEncryption(customerEmail);

				ResetPasswordRequest resetPasswordRequest = new ResetPasswordRequest();
				resetPasswordRequest.setSubject(Subject);
				resetPasswordRequest.setTo(emailId);
				resetPasswordRequest.setName(customerByEmail.getUsername());
				resetPasswordRequest
						.setTemplate(url + "/" + forgetPasswordIdentity + "/" + encryptedCustomerEmail);
				
				
				sendEmail.sendResetEmail(resetPasswordRequest);

			} else {
				throw new ApplicationException(ErrorCodes.INVALID_EMAIL_ID);
			}
		} else {
			throw new ApplicationException(ErrorCodes.FORGETPWDLIMIT);
		}
		return ApplicationConstants.valid;
	}

	/**
	 * Do encryption.
	 *
	 * @param data the data
	 * @return the string
	 */
	private String doEncryption(String data) {

		return Base64.getEncoder().encodeToString(data.getBytes());
	}
	
	/**
	 *@param resetPasswordDto
	 *@throws ApplicationException
	 *@return the String
	 */
	@Override
	public String updateCustomerPassword(ResetPasswordDto resetPasswordDto) throws ApplicationException {

		ForgetPassword forgetPassword = customerDao.getCustomerIdFromLoginTable(resetPasswordDto.getIdentity());
		if(!ApplicationUtils.isValidateObject(forgetPassword)) {
			throw new ApplicationException(ErrorCodes.INVALID_DATA);
		}
		Date expireTime = forgetPassword.getExpireTime();
		Calendar calendar = Calendar.getInstance();
		Date time = calendar.getTime();
		boolean before = time.before(expireTime);

		if (!resetPasswordDto.getNewPassword().equals(resetPasswordDto.getConfirmPassword())) {
			throw new ApplicationException(ErrorCodes.PWD_MISSMATCH);
		}

		if (!before) {
			throw new ApplicationException(ErrorCodes.LINK_EXPIRED);
		}

		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

		Customer customer = customerDao.getCustomerByIdentity(forgetPassword.getCustomerIdentity());

		if (ApplicationUtils.isValidateObject(customer)) {
			customer.setPassword(encoder.encode(resetPasswordDto.getNewPassword()));
			customerDao.updateCustomer(customer);
		}

		return ApplicationConstants.UPDATE_SUCCESS;
	}

	/**
	 * Change password.
	 *
	 * @param changePassword the change password
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void changePassword(ChangePasswordDto changePassword) throws ApplicationException {
		if(!ApplicationUtils.isValidateObject(changePassword)) {
			throw new ApplicationException(ErrorCodes.INVALID_DATA);
		}
		
		if(!changePassword.getNewPassword().equals(changePassword.getConfirmPassword())) {
			throw new ApplicationException(ErrorCodes.PWD_MISSMATCH);
		}
		
		String newPassword = changePassword.getNewPassword();
		String oldPassword = changePassword.getOldPassword();
		
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		UserInfo userInfo = loggedInUserContextHolder.getLoggedInUser();
		Integer userId = userInfo.getId();
		
		Customer loginCustomer = customerDao.getLoginCustomer(userId);
		if(!ApplicationUtils.isValidObject(loginCustomer)) {
			throw new ApplicationException(ErrorCodes.INVALID_USER);
		}
		
		String encryptedPassword = loginCustomer.getPassword();
		if(passwordEncoder.matches(oldPassword, encryptedPassword)) {
			String encodedNewPassword = passwordEncoder.encode(newPassword);
			loginCustomer.setPassword(encodedNewPassword);
			loginCustomer.setModifiedDate(LocalDateTime.now());
			customerDao.updateCustomer(loginCustomer);
		}
		else
		{
			throw new ApplicationException(ErrorCodes.INVALID_OLD_PASSWORD);
		}
	}

	/**
	 * Customer excel download.
	 *
	 * @param customerList the customer list
	 * @param downloadColumn the download column
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	@Override
	public ResponseEntity<ByteArrayResource> customerExcelDownload(List<CustomerDto> customerList,List<String> downloadColumn)
			throws ApplicationException {
		
		
		ArrayList<LinkedHashMap<String, Object>> DataList = new ArrayList<LinkedHashMap<String, Object>>();
		
		for (CustomerDto customerData : customerList) {
			LinkedHashMap<String, Object> map = new LinkedHashMap<>();
			
			if(ApplicationUtils.isValidateObject(downloadColumn)){
				for (String columnName: downloadColumn) {
					
					switch (columnName.trim()) {
					
					case TableConstants.INSURER_NAME:
						map.put(TableConstants.INSURER_NAME, customerData.getUsername());
						break;
						
					case TableConstants.EMAIL_ID:
						map.put(TableConstants.EMAIL_ID, customerData.getEmail());
						break;
						
					case TableConstants.PHONE_NO:
						map.put(TableConstants.PHONE_NO,customerData.getPhoneNumber());
						break;
						
					case TableConstants.ADDED_DATE:
						map.put(TableConstants.ADDED_DATE, customerData.getAddedDate());
						break;
						
					case TableConstants.STATUS_REPORT:
						map.put(TableConstants.STATUS_REPORT,convertStatusToString( customerData.getStatus()));
						break;						
					
					}
				}
			}
			DataList.add(map);
		}
		
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		HttpHeaders header = new HttpHeaders();
		
		try {
			List<String> keyList = new ArrayList<>();
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet(ApplicationConstants.REPORTS);
			XSSFRow hederRow = sheet.createRow((int) ApplicationConstants.ZERO);

			XSSFFont headerFont = workbook.createFont();
			headerFont.setBold(true);

			XSSFCellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);
			
			int rowIndex = ApplicationConstants.ZERO;
			
			for (LinkedHashMap<String, Object> map : DataList) { // Iterated only for Extracting Header Columns
				Set<String> keys = map.keySet();
				keyList = keys.stream().collect(Collectors.toList());
				for (int i = ApplicationConstants.ZERO; i < keyList.size(); i++) {
					
					XSSFCell headerCell = hederRow.createCell(i);
					 String headerText =Character.toUpperCase(keyList.get(i).charAt(0)) + keyList.get(i).substring(1); // Capitalize the first letter
					 
					headerCell.setCellValue(headerText);
					headerCell.setCellStyle(headerCellStyle);
				}
			}
			
			for (LinkedHashMap<String, Object> map : DataList) {
				int columnIndex = ApplicationConstants.ZERO;
				XSSFRow row = sheet.createRow((int) rowIndex + 1);
				for (Entry<String, Object> entry : map.entrySet()) {
					XSSFCell cell = row.createCell(columnIndex);
					if( entry.getKey().equalsIgnoreCase(TableConstants.ADDED_DATE)) {
						String object =map.get(entry.getKey()).toString();
						DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
						Date date = dateFormat.parse(object);
						DateFormat formatter = new SimpleDateFormat(environmentProperties.getDateFormat());
						String dateStr = formatter.format(date);
						cell.setCellValue(dateStr);
					}

					else {

						cell.setCellValue((entry.getValue() != null) ? entry.getValue().toString()
								: ApplicationConstants.WITHOUT_SPACE);

					}
					columnIndex++;
				}
				rowIndex++;
			}
			
			if (ApplicationUtils.isValidList(keyList)) {
				for (int index = ApplicationConstants.ZERO; index < keyList.size(); index++) {
					sheet.autoSizeColumn(index);
				}
			}

			header.setContentType(new MediaType(ApplicationConstants.APPLICATION,ApplicationConstants.FORCE_DOWNLOAD));
			header.set(HttpHeaders.CONTENT_DISPOSITION, ApplicationConstants.APPLICATION_VND_MS_EXCEL);

			workbook.write(stream);
			workbook.close();
			return new ResponseEntity<>(new ByteArrayResource(stream.toByteArray()), header, HttpStatus.CREATED); 
		}catch (Exception e) {
			e.printStackTrace();
		}

		return new ResponseEntity<>(new ByteArrayResource(stream.toByteArray()), header, HttpStatus.CREATED);
	}

	/**
	 * Convert status to string.
	 *
	 * @param status the status
	 * @return the string
	 */
	private String convertStatusToString(Boolean status) {
		
		String StatusName= ApplicationConstants.INACTIVE;
		if(status) {
			StatusName =ApplicationConstants.RLE_ACTIVE;
		}else {
			StatusName =ApplicationConstants.INACTIVE;
		}
		return StatusName;
	}

	/**
	 * Save user profile url.
	 *
	 * @param customerId the customer id
	 * @param profileUrl the profile url
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void saveUserProfileUrl(Integer customerId, String profileUrl) throws ApplicationException {
		
		Customer customer = customerDao.getLoginCustomer(customerId);
		if(ApplicationUtils.isValidateObject(customer)) {
			customer.setProfileUrl(Integer.valueOf(profileUrl));
		}
		
		customerDao.updateCustomer(customer);
		
	}

	
	/**
	 * Gets the profile picture.
	 *
	 * @param identity the identity
	 * @return the profile picture
	 * @throws ApplicationException the application exception
	 */
	@Override
	public String getProfilePicture(String identity) throws ApplicationException{
			Customer customerByIdentity = customerDao.getCustomerByIdentity(identity);
			Integer userId = customerByIdentity.getCustomerId();
			ApplicationResponse customerProfileUrl = restTemplateService.getCustomerProfileUrl(userId, ApplicationConstants.CUSTOMER_RP_TYPE);
			String url = customerProfileUrl.getContent();
			return url ;
	}

	/**
	 * Save customer from bulk upload.
	 *
	 * @param paperDetails the paper details
	 * @param loggedInUser the logged in user
	 * @return the customer with password
	 * @throws ApplicationException the application exception
	 */
	@Override
	public CustomerWithPassword saveCustomerFromBulkUpload(PaperDetails paperDetails, UserInfo loggedInUser)
			throws ApplicationException {
		Customer customerEntity=new Customer();
		Integer userId=loggedInUser.getId();
		String userPwd = null;

		if(ApplicationUtils.isValidateObject(paperDetails)) {
			customerEntity.setAddedDate(paperDetails.getCreatedDate());
			customerEntity.setCompanyId(paperDetails.getCompanyId());
			customerEntity.setCreatedBy(userId);
			customerEntity.setCreatedDate(LocalDateTime.now());
			customerEntity.setEmail(paperDetails.getPdEmailId());
			customerEntity.setIsFirstTimeLogin(true);
			customerEntity.setUsername(paperDetails.getPdInsuredName());
			customerEntity.setModifiedBy(userId);
			customerEntity.setModifiedDate(LocalDateTime.now());
			BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
			int length = 8;
		    boolean useLetters = true;
		    boolean useNumbers = true;
		    userPwd = RandomStringUtils.random(length, useLetters, useNumbers);
			customerEntity.setPassword(encoder.encode(userPwd));
			customerEntity.setPhoneNumber(paperDetails.getPdPhoneNumber());
			customerEntity.setStatus(true);
		}
			customerDao.saveCustomer(customerEntity);			
			CustomerWithPassword customerWithPassword = new CustomerWithPassword(customerEntity, userPwd);			
		return customerWithPassword;
	}
	

}
