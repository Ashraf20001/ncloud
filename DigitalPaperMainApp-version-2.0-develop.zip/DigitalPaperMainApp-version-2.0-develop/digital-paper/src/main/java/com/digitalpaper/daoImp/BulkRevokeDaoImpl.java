package com.digitalpaper.daoImp;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.digitalpaper.config.common.base.dao.BaseDao;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.IBulkRevokeDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.entity.BulkRevokeErrorTable;

/**
 * The Class BulkRevokeDaoImpl.
 */
@Repository
public class BulkRevokeDaoImpl extends BaseDao implements IBulkRevokeDao {

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {

	}

	/**
	 * @param filterVo
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Long getRevokeScratchCount(Integer bulkUploadId,List<FilterOrSortingVo> filterVo) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<BulkRevokeErrorTable> root = criteria.from(BulkRevokeErrorTable.class);
		criteria.select(builder.count(root));
		List<Predicate> predicates = getFilterPrdicets(filterVo, root, builder, criteria);
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.BR_BULKIMPORTHISTORYID), bulkUploadId)));
		return (Long) getSingleResult(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * @param skip
	 * @param limit
	 * @param filterVo
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public List<Object[]> getErrorSuccessData(Integer skip, Integer limit,Integer bulkUploadId, List<FilterOrSortingVo> filterVo,
			Boolean errorSuccess) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Object[]> criteria = builder.createQuery(Object[].class);
		Root<BulkRevokeErrorTable> root = criteria.from(BulkRevokeErrorTable.class);
		if (Boolean.TRUE.equals(errorSuccess)) {
			criteria.multiselect(root.get(TableConstants.BR_DIGITAL_PAPER_ID),
					root.get(TableConstants.BR_POLICY_NUMBER), root.get(TableConstants.ERROR_MESSAGE),
					root.get(TableConstants.BR_BULKIMPORTHISTORYID), root.get(TableConstants.BR_IDENTITY));
		} else {
			criteria.multiselect(root.get(TableConstants.BR_DIGITAL_PAPER_ID),
					root.get(TableConstants.BR_POLICY_NUMBER),
					root.get(TableConstants.BR_IDENTITY));
		}
		List<Predicate> predicates = getFilterPrdicets(filterVo, root, builder, criteria);
		predicates.add(builder.and(builder.equal(root.get(TableConstants.BULK_IMPORT_HISTORY_ID), bulkUploadId)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		if (Boolean.TRUE.equals(errorSuccess)) {
			predicates.add(builder.and(builder.equal(root.get(TableConstants.BR_STATUS), false)));
		} else {
			predicates.add(builder.and(builder.equal(root.get(TableConstants.BR_STATUS), true)));
		}
		List<Object[]> result = (List<Object[]>) getResultList(
				createQuery(builder, criteria, root, predicates).setFirstResult(skip).setMaxResults(limit));
		return result;
	}
	
	/**
	 * @param identity
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public BulkRevokeErrorTable getBulkRevokeForDelete(String identity) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<BulkRevokeErrorTable> criteria = builder.createQuery(BulkRevokeErrorTable.class);
		Root<BulkRevokeErrorTable> root = criteria.from(BulkRevokeErrorTable.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IDENTITY), identity)));
		BulkRevokeErrorTable result = (BulkRevokeErrorTable) getResultList(
				createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);
		return result;
	}

	/**
	 * @param delete
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public BulkRevokeErrorTable updateBulkRevoke(BulkRevokeErrorTable delete) throws ApplicationException {
		update(delete);
		return delete;

	}

	/**
	 * @param filterVo
	 * @param errorSuccessCount
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Long getErrorSuccesCount(Integer bulkUploadId,List<FilterOrSortingVo> filterVo, Boolean errorSuccessCount)
			throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<BulkRevokeErrorTable> root = criteria.from(BulkRevokeErrorTable.class);
		criteria.select(builder.count(root));
		List<Predicate> predicates = getFilterPrdicets(filterVo, root, builder, criteria);
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		if (Boolean.TRUE.equals(errorSuccessCount)) {
			predicates.add(builder.and(builder.equal(root.get(TableConstants.BR_STATUS), false)));
		} else {
			predicates.add(builder.and(builder.equal(root.get(TableConstants.BR_STATUS), true)));
		}
		predicates.add(builder.and(builder.equal(root.get(TableConstants.BR_BULKIMPORTHISTORYID), bulkUploadId)));
		Long result = (Long) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst()
				.orElse(null);
		return result;
	}

}
