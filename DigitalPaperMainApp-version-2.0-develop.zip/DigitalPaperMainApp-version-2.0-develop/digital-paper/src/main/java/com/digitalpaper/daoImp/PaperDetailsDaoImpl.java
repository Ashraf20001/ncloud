package com.digitalpaper.daoImp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Selection;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.digitalpaper.config.common.base.dao.BaseDao;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.IPaperDetailsDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.entity.BulkImportErrorTable;
import com.digitalpaper.transfer.object.entity.Customer;
import com.digitalpaper.transfer.object.entity.FileStorage;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.utils.core.ApplicationUtils;

/**
 * The Class PaperDetailsDaoImpl.
 */
@Repository
@Transactional
public class PaperDetailsDaoImpl extends BaseDao implements IPaperDetailsDao {
	

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
		
	}

	/**
	 * @return Long
	 * @throws ApplicationException 
	 */
	@Override
	public Long getPaperDetailsCount(List<FilterOrSortingVo> filterVo, Integer companyId,Boolean view,String searchValue) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<PaperDetails> root = criteria.from(PaperDetails.class);
		criteria.select(builder.count(root));
		List<Predicate> predicates = getFilterPrdicets(filterVo, root, builder, criteria);
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DLT_STS), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.COMPANY_ID), companyId)));
		if (ApplicationUtils.isValidString(searchValue)) {
			predicates.add(builder.or(builder.like( 
	                builder.concat(root.get(TableConstants.PD_INSURED_NAME), 
	                builder.concat(root.get(TableConstants.PD_DIGITAL_PAPER_ID), 
	                builder.concat(root.get(TableConstants.PD_POLICY_NUMBER), 
	                		root.get(TableConstants.REGISTRATION_NUMBER)))
	                ),"%"+searchValue+"%")));
		}
		
		if(ApplicationUtils.isValidateObject(view)) {
			if(Boolean.TRUE.equals(view)) {
				predicates.add(builder.and(builder.greaterThan(root.get(TableConstants.EXPIRY_DATE), LocalDateTime.now())));
				predicates.add(builder.and(builder.equal(root.get(TableConstants.STATUS),1)));
			}
			else {
				predicates.add(builder.and(builder.equal(root.get(TableConstants.STATUS),1)));
			}
		} 
		return (Long) getSingleResult(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * @param skip
	 * @param limit
	 * @param filterVo
	 * @return
	 * @throws ApplicationException
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<PaperDetails> getPaperDetailsList(Integer skip, Integer limit, String searchValue, List<FilterOrSortingVo> filterVo, Integer companyId,Boolean view,List<String> removableDPIdList) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
		Root<PaperDetails> root = criteria.from(PaperDetails.class);
		criteria.select(root);
		List<Predicate> predicates = getFilterPrdicets(filterVo, root, builder, criteria);
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		Boolean isSort = false;
		if(ApplicationUtils.isValidList(filterVo)){
			isSort = filterVo.stream().anyMatch(filter->filter.getFilterOrSortingType().equals(ApplicationConstants.SORTING));
		}
		
		if (ApplicationUtils.isValidString(searchValue)) {
			predicates.add(builder.or(builder.like( 
	                builder.concat(root.get(TableConstants.PD_INSURED_NAME), 
	                builder.concat(root.get(TableConstants.PD_DIGITAL_PAPER_ID), 
	                builder.concat(root.get(TableConstants.PD_POLICY_NUMBER), 
	                		root.get(TableConstants.REGISTRATION_NUMBER)))
	                ),"%"+searchValue+"%")));
		}
		
		
		if(ApplicationUtils.isValidList(removableDPIdList)) {
			predicates.add(builder.and(builder.not(root.get(TableConstants.PD_DIGITAL_PAPER_ID).in(removableDPIdList))));
		}
	
		// Insurance dashboard two cards redirect condition
		
		if(ApplicationUtils.isValidateObject(view)) {
			if(Boolean.TRUE.equals(view)) {
				predicates.add(builder.and(builder.greaterThan(root.get(TableConstants.EXPIRY_DATE), LocalDateTime.now())));
				predicates.add(builder.and(builder.equal(root.get(TableConstants.STATUS),1)));
				if(!isSort) {					
					criteria.orderBy(builder.asc(root.get(TableConstants.EXPIRY_DATE)));
				}
			}
			else {
				predicates.add(builder.and(builder.equal(root.get(TableConstants.STATUS),1)));
				if(!isSort) {
					criteria.orderBy(builder.desc(root.get(TableConstants.MODIFIED_DATE)));
				}
			}

		} 
		
		// Normal Paper Details Tab Condition
		
		else if(ApplicationUtils.isValidList(filterVo)) {
			if(!isSort) {
				criteria.orderBy(builder.desc(root.get(TableConstants.MODIFIED_DATE)));
			}	
		}
		else {
			criteria.orderBy(builder.desc(root.get(TableConstants.MODIFIED_DATE)));
		}
		
		List<PaperDetails> result= new ArrayList<PaperDetails>();
		if(limit==ApplicationConstants.ZERO) {
			result = (List<PaperDetails>) getResultList(getBasePredicateResult(builder, criteria, root,null, predicates));
		}else {
			
			result = (List<PaperDetails>) getResultList(getBasePredicateResult(builder, criteria, root,null, predicates).setFirstResult(skip).setMaxResults(limit));
		}
		return result;
	}

	/**
	 * Gets the paper details by paper id.
	 *
	 * @param paperDetailsIdentity the paper details identity
	 * @return the paper details by paper id
	 */
	@Override
	public PaperDetails getPaperDetailsByPaperId(String paperDetailsIdentity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
		Root<PaperDetails> root = criteria.from(PaperDetails.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IDENTITY), paperDetailsIdentity)));
		PaperDetails result=(PaperDetails)getSingleResult(createQuery(builder, criteria, root, predicates));
		
		return result;
	}

	/**
	 * @param id
	 */
	@Override
	public List<BulkImportErrorTable> getErrorTableByScratchId(Integer id) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<BulkImportErrorTable> criteria = builder.createQuery(BulkImportErrorTable.class);
		Root<BulkImportErrorTable> root = criteria.from(BulkImportErrorTable.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.SCRATCH_ID), id)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_ERROR_CLEARED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		return (List<BulkImportErrorTable>)getResultList(createQuery(builder, criteria, root, predicates));
	}
	
	/**
	 * @param identity
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public PaperDetails getRevokeStatusData(String identity) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
		Root<PaperDetails> root = criteria.from(PaperDetails.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IDENTITY), identity)));
		PaperDetails result = (PaperDetails) getResultList(createQuery(builder, criteria, root, predicates)).stream()
				.findFirst().orElse(null);
		return result;
	}

	/**
	 * @param status
	 * @throws ApplicationException
	 */
	@Override
	public void updateStatusDao(PaperDetails status) throws ApplicationException {
		update(status);
	}
	
	/**
	 * 
	 * @param importTable
	 */
	@Override
	public void deleteErrorData(List<BulkImportErrorTable> importTable) {
		for (BulkImportErrorTable bulkImportErrorTable : importTable) {
			update(bulkImportErrorTable);
		}
	}

	/**
	 * Gets the paper by identity.
	 *
	 * @param identity the identity
	 * @return the paper by identity
	 */
	@Override
	public PaperDetails getPaperByIdentity(String identity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<PaperDetails> criteria = builder.createQuery(PaperDetails.class);
		Root<PaperDetails> root = criteria.from(PaperDetails.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IDENTITY), identity)));
		PaperDetails result = (PaperDetails) getResultList(createQuery(builder, criteria, root, predicates)).stream()
				.findFirst().orElse(null);
		return result;
	}
	
	/**
	 * Save paper image.
	 *
	 * @param storage the storage
	 * @return the integer
	 * @throws ApplicationException the application exception
	 */
	public Integer savePaperImage(FileStorage storage) throws ApplicationException {
		return save(storage,TableConstants.FILE_STORAGE);		
	}

	/**
	 * Gets the paper image by id.
	 *
	 * @param paperId the paper id
	 * @param uploadType the upload type
	 * @param rpType the rp type
	 * @return the paper image by id
	 */
	@Override
	public FileStorage getPaperImageById(Integer paperId, String uploadType, String rpType) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<FileStorage> criteria = builder.createQuery(FileStorage.class);
		Root<FileStorage> root = criteria.from(FileStorage.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.REF_ID), paperId)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.UPLOAD_TYPE), uploadType)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.RP_TYPE), rpType)));
		FileStorage result = (FileStorage) getResultList(createQuery(builder, criteria, root, predicates)).stream()
				.findFirst().orElse(null);
		return result;
	}

	/**
	 * @param entityColumnList
	 * @param filterOrSortingVo
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public List<Object[]> getPaperDetailsDataForDownload(List<String> entityColumnList,Integer companyId,  List<FilterOrSortingVo> filterVo, List<Integer> idLists, String searchValue) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Object[]> criteria = builder.createQuery(Object[].class);
		Root<PaperDetails> root = criteria.from(PaperDetails.class);
		List<Selection<?>> selections = new ArrayList<>();
		for (String entityColumn : entityColumnList) { 
			selections.add(root.get(entityColumn));
		}
		criteria.multiselect(selections);
		List<Predicate> predicates = getFilterPrdicets(filterVo, root, builder, criteria);
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.COMPANY_ID), companyId)));
		
		if(ApplicationUtils.isValidList(idLists)) {
			predicates.add(root.get(TableConstants.PAPER_ID).in(idLists));
		}
		
		if (ApplicationUtils.isValidString(searchValue)) {
			predicates.add(builder.or(builder.like( 
	                builder.concat(root.get(TableConstants.PD_INSURED_NAME), 
	                builder.concat(root.get(TableConstants.PD_DIGITAL_PAPER_ID), 
	                builder.concat(root.get(TableConstants.PD_POLICY_NUMBER), 
	                		root.get(TableConstants.REGISTRATION_NUMBER)))
	                ),"%"+searchValue+"%")));
		}
		
		criteria.orderBy(builder.desc(root.get(TableConstants.MODIFIED_DATE)));
		
		List<Object[]> result = (List<Object[]>) getResultList(createQuery(builder, criteria, root, predicates));
		return result;
	}
	
	/**
	 * Gets the paper details customer count.
	 *
	 * @param filter the filter
	 * @param companyId the company id
	 * @param searchvalue the searchvalue
	 * @return the paper details customer count
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Long getPaperDetailsCustomerCount(List<FilterOrSortingVo> filter,Integer companyId, String searchvalue) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> createQuery = builder.createQuery(Long.class);
		Root<PaperDetails> root = createQuery.from(PaperDetails.class);
		createQuery.select(builder.countDistinct(root.get(TableConstants.CUSTOMER)));	
		
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETED), false)));
		if (ApplicationUtils.isValidString(searchvalue)) {
			predicates.add(builder.or(builder.like( 
	                builder.concat(root.get(TableConstants.CUSTOMER_TABLE).get(TableConstants.USER_NAME), 
	                builder.concat(root.get(TableConstants.CUSTOMER_TABLE).get(TableConstants.EMAIL),  
	                		root.get(TableConstants.CUSTOMER_TABLE).get(TableConstants.PHONE_NUMBER))
	                ),"%"+searchvalue+"%")));
		}
		
		List<Predicate> filterPrdicets = getFilterPrdicets(filter, root, builder, createQuery);
		predicates.addAll(filterPrdicets);
		return (Long) getSingleResult(getBasePredicateResult(builder, createQuery, root,null, predicates));
		
	}
	
	/**
	 * Gets the paper details customer list.
	 *
	 * @param min the min
	 * @param max the max
	 * @param filter the filter
	 * @param companyId the company id
	 * @param searchValue the search value
	 * @return the paper details customer list
	 * @throws ApplicationException the application exception
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getPaperDetailsCustomerList(Integer min,Integer max,List<FilterOrSortingVo> filter,Integer companyId, String searchValue) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Object> createQuery = builder.createQuery(Object.class);
		Root<PaperDetails> root = createQuery.from(PaperDetails.class);
		Join<PaperDetails, Customer> customerJoin = root.join("customer");
		
		createQuery.multiselect(
				customerJoin.get(TableConstants.CUSTOMER_ID),
				root.get(TableConstants.PD_INSURED_NAME),
				customerJoin.get(TableConstants.EMAIL),
				customerJoin.get(TableConstants.PHONE_NUMBER),
				root.get(TableConstants.CREATED_DATE),
				customerJoin.get(TableConstants.STATUS),
				customerJoin.get(TableConstants.PASSWORD),
				customerJoin.get(TableConstants.IS_FIRST_TIME_LOGIN),
				customerJoin.get(TableConstants.IDENTITY),
				customerJoin.get(TableConstants.COMPANY_ID),
				customerJoin.get(TableConstants.PROFILE_URL)
				);
		
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IS_DELETED), false)));
		
		if (ApplicationUtils.isValidString(searchValue)) {
			predicates.add(builder.or(builder.like( 
	                builder.concat(root.get(TableConstants.PD_INSURED_NAME), 
	                builder.concat(customerJoin.get(TableConstants.EMAIL),  
	                builder.concat(root.get(TableConstants.CREATED_DATE), customerJoin.get(TableConstants.PHONE_NUMBER)))
	                ),"%"+searchValue+"%")));
		}
		
		Boolean isSort = false;
		if(ApplicationUtils.isValidList(filter)){
			isSort = filter.stream().anyMatch(filterVo->filterVo.getFilterOrSortingType().equals(ApplicationConstants.SORTING));
		}
		
		List<Predicate> filterPrdicets = getFilterPrdicets(filter, root, builder, createQuery);
		predicates.addAll(filterPrdicets);
		
		createQuery.groupBy(customerJoin.get(TableConstants.CUSTOMER_ID));
		
		if(!isSort) {
			createQuery.orderBy(builder.desc(customerJoin.get(TableConstants.MODIFIED_DATE)));
		}
		
		return (List<Object[]>) getResultList(getBasePredicateResult(builder, createQuery, root, null, predicates).setFirstResult(min).setMaxResults(max));
	}
	

	/**
	 * Update storage data.
	 *
	 * @param fileStorage the file storage
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void updateStorageData(FileStorage fileStorage) throws ApplicationException {
		update(fileStorage);
		
	}

	/**
	 * Save storage data.
	 *
	 * @param storageData the storage data
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void saveStorageData(FileStorage storageData) throws ApplicationException {
		save(storageData, TableConstants.FILE_STORAGE);
		
	}

	/**
	 * Gets the paper details list for all papers download.
	 *
	 * @param searchValue the search value
	 * @param filterOrSortingVos the filter or sorting vos
	 * @param removableDigitalPaperIds the removable digital paper ids
	 * @param view the view
	 * @param companyId the company id
	 * @return the paper details list for all papers download
	 * @throws ApplicationException the application exception
	 */
	@Override
	public List<PaperDetails> getPaperDetailsListForAllPapersDownload(String searchValue,
			List<FilterOrSortingVo> filterOrSortingVos, List<String> removableDigitalPaperIds, Boolean view,Integer companyId)
			throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<PaperDetails> criteriaQuery = builder.createQuery(PaperDetails.class);
		Root<PaperDetails> root = criteriaQuery.from(PaperDetails.class);
		criteriaQuery.select(root);

		List<Predicate> predicateList = new ArrayList<Predicate>();

		if (ApplicationUtils.isValidString(searchValue)) {
			predicateList
					.add(builder.or(builder.like(
							builder.concat(root.get(TableConstants.PD_INSURED_NAME),
									builder.concat(root.get(TableConstants.PD_DIGITAL_PAPER_ID),
											builder.concat(root.get(TableConstants.PD_POLICY_NUMBER),
													root.get(TableConstants.REGISTRATION_NUMBER)))),
							"%" + searchValue + "%")));
		}

		predicateList.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicateList.add(builder.and(builder.equal(root.get(TableConstants.COMPANY_ID), companyId)));

		if (ApplicationUtils.isValidList(removableDigitalPaperIds)) {
			predicateList.add(builder
					.and(builder.not(root.get(TableConstants.PD_DIGITAL_PAPER_ID).in(removableDigitalPaperIds))));
		}

		if (ApplicationUtils.isValidList(filterOrSortingVos)) {
			predicateList.addAll(getFilterPrdicets(filterOrSortingVos, root, builder, criteriaQuery));
		}

		if(ApplicationUtils.isValidList(filterOrSortingVos)){
			if(filterOrSortingVos.stream().noneMatch(filterVo->filterVo.getFilterOrSortingType().equals(ApplicationConstants.SORTING))){
				criteriaQuery.orderBy(builder.desc(root.get(TableConstants.MODIFIED_DATE)));
			}
		} else {
			criteriaQuery.orderBy(builder.desc(root.get(TableConstants.MODIFIED_DATE)));
		}


		return (List<PaperDetails>) getResultList(createQuery(builder, criteriaQuery, root, predicateList));
	}

}
