package com.digitalpaper.dao;

import java.util.List;

import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.entity.BulkImportErrorTable;
import com.digitalpaper.transfer.object.entity.BulkRevokeErrorTable;
import com.digitalpaper.transfer.object.entity.Customer;
import com.digitalpaper.transfer.object.entity.FileStorage;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.entity.Scratch;
import com.digitalpaper.transfer.object.entity.Stock;
import com.digitalpaper.transfer.object.entity.StockPool;

/**
 * The Interface PaperDetailsBulkUploadDao.
 */
public interface PaperDetailsBulkUploadDao {

	/**
	 * Save scratch data.
	 *
	 * @param scratch the scratch
	 * @return the integer
	 * @throws ApplicationException the application exception
	 */
	Integer saveScratchData(Scratch scratch) throws ApplicationException;

	/**
	 * Gets the paper details by policy number.
	 *
	 * @param value the value
	 * @return the paper details by policy number
	 */
	PaperDetails getPaperDetailsByPolicyNumber(String value);

	/**
	 * Save bulk import error data.
	 *
	 * @param bulkImportErrorTable the bulk import error table
	 * @throws ApplicationException the application exception
	 */
	void saveBulkImportErrorData(BulkImportErrorTable bulkImportErrorTable) throws ApplicationException;

	/**
	 * Save paper details.
	 *
	 * @param paperDetail the paper detail
	 * @param stockPool the stock pool
	 * @param type the type
	 * @param stock the stock
	 * @return the integer
	 * @throws ApplicationException the application exception
	 */
	Integer savePaperDetails(PaperDetails paperDetail, StockPool stockPool, String type, Stock stock) throws ApplicationException;

	/**
	 * Check for duplicate policy number.
	 *
	 * @param pdPolicyNumber the pd policy number
	 * @param id the id
	 * @return the paper details
	 */
	PaperDetails checkForDuplicatePolicyNumber(String pdPolicyNumber, Integer id);

	/**
	 * Check duplicate registration number or chassis number.
	 *
	 * @param vdRegistrationNumber the vd registration number
	 * @param vdChassis the vd chassis
	 * @param id the id
	 * @return the list
	 */
	List<PaperDetails> checkDuplicateRegistrationNumberOrChassisNumber(String vdRegistrationNumber, String vdChassis,Integer id);

	/**
	 * Gets the stock pool by allocation id.
	 *
	 * @param companyId the company id
	 * @param allocationUserType the allocation user type
	 * @return the stock pool by allocation id
	 */
	StockPool getStockPoolByAllocationId(Integer companyId, Integer allocationUserType);

	/**
	 * Update stock pool.
	 *
	 * @param stockPool the stock pool
	 * @return true, if successful
	 */
	boolean updateStockPool(StockPool stockPool);

	/**
	 * Gets the paper details by digital paper id.
	 *
	 * @param value the value
	 * @return the paper details by digital paper id
	 */
	PaperDetails getPaperDetailsByDigitalPaperId(String value);

	/**
	 * Update digital paper.
	 *
	 * @param paperDetails the paper details
	 */
	void updateDigitalPaper(PaperDetails paperDetails);

	/**
	 * Save bulk revoke error table.
	 *
	 * @param errorTable the error table
	 * @throws ApplicationException the application exception
	 */
	void saveBulkRevokeErrorTable(BulkRevokeErrorTable errorTable) throws ApplicationException;
	
	/**
	 * Update stock.
	 *
	 * @param stock the stock
	 * @return true, if successful
	 */
	public boolean updateStock(Stock stock);

	/**
	 * Gets the paper details based on policy no.
	 *
	 * @param policyNumberObj the policy number obj
	 * @return the paper details based on policy no
	 * @throws ApplicationException the application exception
	 */
	List<PaperDetails> getPaperDetailsBasedOnPolicyNo(String policyNumberObj) throws ApplicationException;

	/**
	 * Gets the file storage data by paper id.
	 *
	 * @param listOfId the list of id
	 * @return the file storage data by paper id
	 * @throws ApplicationException the application exception
	 */
	List<FileStorage> getFileStorageDataByPaperId(List<Integer> listOfId) throws ApplicationException;

	/**
	 * Check for duplicate chassis number.
	 *
	 * @param vdChassisNumber the vd chassis number
	 * @param status the status
	 * @return the paper details
	 */
	PaperDetails checkForDuplicateChassisNumber(String vdChassisNumber, Integer status);

	/**
	 * Gets the customer by email id.
	 *
	 * @param emailId the email id
	 * @return the customer by email id
	 */
	Customer getCustomerByEmailId(String emailId);

	/**
	 * Delete paper details.
	 *
	 * @param paperDetail the paper detail
	 */
	void deletePaperDetails(PaperDetails paperDetail);

	/**
	 * Retrieve stock count.
	 *
	 * @param stockPool the stock pool
	 * @param aLLOCATION_TYPE the a LLOCATIO N TYPE
	 * @param stock the stock
	 */
	void retrieveStockCount(StockPool stockPool, String aLLOCATION_TYPE, Stock stock);

	/**
	 * Gets the digital paper data list by email id.
	 *
	 * @param pdEmailId the pd email id
	 * @param companyId the company id
	 * @return the digital paper data list by email id
	 */
	List<PaperDetails> getDigitalPaperDataListByEmailId(String pdEmailId, Integer companyId);

}
