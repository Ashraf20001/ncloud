package com.digitalpaper.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.digitalpaper.config.property.EnvironmentProperties;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.controller.SequenceEnum;
import com.digitalpaper.controller.SequenceGenerator;
import com.digitalpaper.dao.IStockDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.service.IStockService;
import com.digitalpaper.transfer.object.dto.PurchaseOrderDto;
import com.digitalpaper.transfer.object.dto.SaveStockDataVo;
import com.digitalpaper.transfer.object.dto.StockDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.entity.PaymentDetails;
import com.digitalpaper.transfer.object.entity.PurchaseOrderEntity;
import com.digitalpaper.transfer.object.entity.Stock;
import com.digitalpaper.transfer.object.entity.StockFileMapping;
import com.digitalpaper.transfer.object.entity.StockPool;
import com.digitalpaper.transfer.object.enums.PaymentModeEnum;
import com.digitalpaper.transfer.object.enums.PaymentStatusEnum;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;
import com.digitalpaper.utils.CommonUtils;
import com.digitalpaper.utils.core.ApplicationUtils;

/**
 * The Class StockServiceImpl.
 */
@Service
@Transactional
public class StockServiceImpl implements IStockService {

	/** The stock dao. */
	@Autowired
	public IStockDao stockDao;

	/** The sequence generator. */
	@Autowired
	private SequenceGenerator sequenceGenerator;

	/** The logged in user context holder. */
	@Autowired
	private LoggedInUserContextHolder loggedInUserContextHolder;
	
	/**
	 * EnvironmentProperties
	 */
	@Autowired
	private EnvironmentProperties environmentProperties;	
	
	/** The common utils. */
	@Autowired
	private CommonUtils commonUtils;
	

	/**
	 * Gets the stock data.
	 *
	 * @return the stock data
	 */
	public StockDto getStockData() {

		UserInfo userDetails = loggedInUserContextHolder.getLoggedInUser();
		Integer companyId = userDetails.getCompanyId();

		Stock stockCount = new Stock();
		if (ApplicationUtils.isValidId(companyId)) {
			stockCount = stockDao.getStockData(companyId);
		}
		StockDto stockData = new StockDto();
		if (ApplicationUtils.isValidateObject(stockCount)) {
			stockData.setCompanyId(stockCount.getCompanyId());
			stockData.setCreatedDate(stockCount.getCreatedDate());
			stockData.setIdentity(stockCount.getIdentity());
			stockData.setStockCount(stockCount.getStockCount());
			stockData.setStockId(stockCount.getStockId());
			stockData.setUsedCount(stockCount.getUsedCount());
		}
		return stockData;

	}

	

	/**
	 * Excel download.
	 *
	 * @param data the data
	 * @return the response entity
	 */
	@Override
	public ResponseEntity<InputStreamResource> excelDownload(ArrayList<HashMap<String, Object>> data) {

		HttpHeaders header = new HttpHeaders();

		try {
			List<String> keyList = new ArrayList<>();
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet(ApplicationConstants.PURCHASE_STOCK);
			XSSFRow hederRow = sheet.createRow((int) ApplicationConstants.ZERO);

			XSSFFont headerFont = workbook.createFont();
			headerFont.setBold(true);

			XSSFCellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);
			
			int rowIndex = ApplicationConstants.ZERO;

			for (HashMap<String, Object> map : data) { // Iterated only for Extracting Header Columns
				Set<String> keys = map.keySet();
				keyList = keys.stream().collect(Collectors.toList());
				for (int i = ApplicationConstants.ZERO; i < keyList.size(); i++) {
					XSSFCell headerCell = hederRow.createCell(i);
					 String headerText =Character.toUpperCase(keyList.get(i).charAt(0)) + keyList.get(i).substring(1); // Capitalize the first letter
					 
					headerCell.setCellValue(headerText);
					headerCell.setCellStyle(headerCellStyle);
				}
			}

			for (HashMap<String, Object> map : data) {
				int columnIndex = ApplicationConstants.ZERO;
				XSSFRow row = sheet.createRow((int) rowIndex + 1);
				for (Entry<String, Object> entry : map.entrySet()) {
					XSSFCell cell = row.createCell(columnIndex);

					if( entry.getKey().equalsIgnoreCase(TableConstants.PAYMENT_DATE)) {
						String object =map.get(entry.getKey()).toString();
						DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
						Date date = dateFormat.parse(object);
						DateFormat formatter = new SimpleDateFormat(environmentProperties.getDateFormat());
						String dateStr = formatter.format(date);
						cell.setCellValue(dateStr);
					}

					else {

						cell.setCellValue((entry.getValue() != null) ? entry.getValue().toString()
								: ApplicationConstants.WITHOUT_SPACE);

					}
					columnIndex++;
				}
				rowIndex++;
			}

			if (ApplicationUtils.isValidList(keyList)) {
				for (int index = ApplicationConstants.ZERO; index < keyList.size(); index++) {
					sheet.autoSizeColumn(index);
				}
			}

			header.setContentType(new MediaType("application", "force-download"));
			header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ProductTemplate.pdf");
			
			ByteArrayOutputStream fileOut = new ByteArrayOutputStream();
			String fileName = "Transaction-data.xlsx";
			workbook.write(fileOut);
			fileOut.close();
			workbook.close();
			ByteArrayInputStream in = new ByteArrayInputStream(fileOut.toByteArray());
			InputStreamResource file = new InputStreamResource(in);
			
			return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName)
					.contentType(MediaType.parseMediaType("application/vnd.ms-excel")).body(file);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}

	/**
	 * Gets the purchase details.
	 *
	 * @param selectedColumnList the selected column list
	 * @return the purchase details
	 */
	@Override
	public ArrayList<HashMap<String, Object>> getpurchaseDetails(String[] selectedColumnList) {

		List<PurchaseOrderEntity> data = stockDao.getPurchaseDetails();
		ArrayList<HashMap<String, Object>> list = new ArrayList<>();

		if (ApplicationUtils.isValidateObject(data)) {
			for (int i = 0; i <= data.size() - 1; i++) {
				PurchaseOrderEntity purchaseOrderList = data.get(i);
				HashMap<String, Object> map = new LinkedHashMap<>();

				if (ApplicationUtils.isValidateObject(selectedColumnList)) {
					for (String field : selectedColumnList) {
						switch (field.trim()) {

						case TableConstants.PURCHASE_ID:
							map.put(TableConstants.PURCHASE_ID, purchaseOrderList.getOrderId());
							break;

						case TableConstants.DATEOF_PURCHASE:
							map.put(TableConstants.DATEOF_PURCHASE, purchaseOrderList.getCreatedDate());
							break;

						case TableConstants.PURCHASE_AMT:
							map.put(TableConstants.PURCHASE_AMT, purchaseOrderList.getOrderAmt());
							break;

						case TableConstants.NO_OF_PAPER:
							map.put(TableConstants.NO_OF_PAPER, purchaseOrderList.getOrderAmt());
							break;

						case TableConstants.PAYMENT_METHOD:
							map.put(TableConstants.PAYMENT_METHOD, purchaseOrderList.getOrderStatus());
							break;

						case TableConstants.PAYMENT_STATUS:
							map.put(TableConstants.PAYMENT_STATUS, purchaseOrderList.getOrderStatus());
							break;
						}

					}

				}
				list.add(map);
			}
		}

		return list;
	}

	/**
	 *@param purchaseStockDto
	 */
	@Override
	public Integer saveOrUpdate(SaveStockDataVo purchaseStockDto) throws ApplicationException {
		UserInfo userDetails = loggedInUserContextHolder.getLoggedInUser();
		Integer companyId = userDetails.getCompanyId();
		Integer userId = userDetails.getId();
	
		PurchaseOrderEntity purchaseOrder = buildObjectForPurchaseOrder(purchaseStockDto, companyId, userId,userDetails.getAssociationId());

		Integer purchaseResponce = stockDao.purchaseOrdersave(purchaseOrder);
		PaymentDetails paymentDetails = buildObjectForPaymentDetails(purchaseStockDto, userId, purchaseOrder, userDetails);
		Integer paymentResponce = stockDao.paymentDetailsSave(paymentDetails);
		return purchaseResponce;
	}

	/**
	 * @param purchaseStockDto
	 * @param userId
	 * @param purchaseOrder
	 * @return
	 * @throws NumberFormatException
	 * @throws ApplicationException 
	 */
	private PaymentDetails buildObjectForPaymentDetails(SaveStockDataVo purchaseStockDto, Integer userId,
			PurchaseOrderEntity purchaseOrder, UserInfo userDetails) throws NumberFormatException, ApplicationException {
		PaymentStatusEnum paymentStatusEnum = null;
		String stockSequenceId = sequenceGenerator.generateSequence(SequenceEnum.ORDER_SEQUENCE_ID);
		if (Boolean.FALSE.equals(ApplicationUtils.isValidString(stockSequenceId))) {
			throw new ApplicationException(ErrorCodes.SEQUENCE_NUMBER);
		}
		PaymentDetails paymentDetails = new PaymentDetails();
		paymentStatusEnum = PaymentStatusEnum.getPaymentStatusEnum(ApplicationConstants.SUBMITTED);
		paymentDetails.setCreatedBy(userId);
		paymentDetails.setModifiedBy(userId);
		paymentDetails.setModifiedDate(LocalDateTime.now());
		paymentDetails.setCreatedDate(LocalDateTime.now());
		paymentDetails.setOrderId(purchaseOrder);
		paymentDetails.setCurrencyType(purchaseStockDto.getCurrencyType());
		paymentDetails.setPaidAmount((ApplicationUtils.isValidString(purchaseStockDto.getTotalCostValue()))?Double.parseDouble(purchaseStockDto.getTotalCostValue()):null);
		paymentDetails.setPaymentDate(LocalDateTime.now());
		PaymentModeEnum paymentModeByValue = PaymentModeEnum.getPaymentModeByValues(purchaseStockDto.getPaymentMethod());
		paymentDetails.setPaymentMode(paymentModeByValue.getId());
		paymentDetails.setPaymentStatus(paymentStatusEnum.getId());
		paymentDetails.setTransactionId(stockSequenceId);
		paymentDetails.setAllocationUserTypeId(userDetails.getAllocationUserType());
		return paymentDetails;
	}

	/**
	 * @param data
	 * @param companyId
	 * @param userId
	 * @return
	 * @throws ApplicationException
	 * @throws NumberFormatException
	 */
	private PurchaseOrderEntity buildObjectForPurchaseOrder(SaveStockDataVo purchaseStockDto, Integer companyId,
			Integer userId, Integer associationId) throws ApplicationException, NumberFormatException {
		PurchaseOrderEntity purchaseOrder = new PurchaseOrderEntity();
		PaymentStatusEnum paymentStatusEnum = null;
		if (ApplicationUtils.isValidateObject(purchaseStockDto)) {
			String purchaseSequenceId = sequenceGenerator.generateSequence(SequenceEnum.PURCHASE_SEQUENCE_ID);
			if (Boolean.FALSE.equals(ApplicationUtils.isValidString(purchaseSequenceId))) {
				throw new ApplicationException(ErrorCodes.SEQUENCE_NUMBER);
			}
			paymentStatusEnum = PaymentStatusEnum.getPaymentStatusEnum(ApplicationConstants.SUBMITTED);
			purchaseOrder.setCompanyId(companyId);
			purchaseOrder.setCreatedBy(userId);
			purchaseOrder.setPurchaseId(purchaseSequenceId);
			purchaseOrder.setModifiedDate(LocalDateTime.now());
			purchaseOrder.setModifiedBy(userId);
			purchaseOrder.setCreatedDate(LocalDateTime.now());
			purchaseOrder.setOrderStatus(paymentStatusEnum.getId());
			purchaseOrder.setOrderAmt(purchaseStockDto.getTotalCostValue());
			purchaseOrder.setStockCount(Integer.parseInt(purchaseStockDto.getNumberOfPapers()));
			purchaseOrder.setPurchaseDate(LocalDateTime.now());
			purchaseOrder.setAssociationId(associationId);
			purchaseOrder.setPaymentMethod(
					PaymentModeEnum.getPaymentModeByValues(purchaseStockDto.getPaymentMethod()).getId());
		}
		return purchaseOrder;
	}

	/**
	 * Gets the drop down list.
	 *
	 * @return the drop down list
	 * @throws ApplicationException the application exception
	 */
	@Override
	public List<String> getDropDownList() throws ApplicationException {

		ArrayList<String> List = new ArrayList<>();
		List.add(TableConstants.PURCHASE_ID);
		List.add(TableConstants.TRANSACTION_ID);
		List.add(TableConstants.DATEOF_PURCHASE);
		List.add(TableConstants.NO_OF_PAPER);
		List.add(TableConstants.PURCHASE_AMT);
		List.add(TableConstants.PAYMENT_METHOD);

		return List;
	}

	/**
	 * Map offline payment.
	 *
	 * @param storageIdList the storage id list
	 */
	public void mapOfflinePayment(Map<String, List<Integer>> storageIdList) {
		Set<String> keyList = storageIdList.keySet();
		List<String> key = keyList.stream().toList();
		PurchaseOrderEntity pruchaseOrder = stockDao.getpurchaseOrderByOrderId(Integer.parseInt(key.get(0)));
		for (Integer data : storageIdList.get(key.get(0))) {
			StockFileMapping stockFileMapping = new StockFileMapping();
			stockFileMapping.setOrderId(pruchaseOrder);
			stockFileMapping.setStorageId(data);
			stockDao.saveFileDataForOrder(stockFileMapping);
		}
	}

	/**
	 * Save company id.
	 *
	 * @param companyId the company id
	 * @param userId the user id
	 * @return the stock
	 */
	@Override
	public Stock saveCompanyId(Integer companyId, Integer userId) {
		Stock stockEntity = new Stock();

		stockEntity.setCompanyId(companyId);
		stockEntity.setStockCount(0);
		stockEntity.setUsedCount(0);
		stockEntity.setCreatedBy(userId);
		stockEntity.setCreatedDate(LocalDateTime.now());
		stockEntity.setModifiedDate(LocalDateTime.now());
		stockEntity.setModifiedBy(userId);
		stockDao.stockSave(stockEntity);
		return stockEntity;
	}



	/**
	 * Save allocation ids.
	 *
	 * @param integerList the integer list
	 * @param companyId the company id
	 * @param userId the user id
	 * @param isPoolBasedAllocation the is pool based allocation
	 */
	@Override
	public void saveAllocationIds(List<Integer> integerList,Integer companyId,Integer userId, Boolean isPoolBasedAllocation) {
		
		Stock saveCompanyId = saveCompanyId(companyId, userId);
		if(ApplicationUtils.isValidList(integerList) && isPoolBasedAllocation) {
			for(Integer poolId: integerList) {
				StockPool stockPool = new StockPool();
				stockPool.setCompanyId(companyId);
				stockPool.setIsActive(true);
				stockPool.setCreatedDate(LocalDateTime.now());
				stockPool.setDeleted(false);
				stockPool.setCreatedBy(userId);
				stockPool.setModifiedDate(LocalDateTime.now());
				stockPool.setModifiedBy(userId);
				stockPool.setStockCount(0);
				stockPool.setUsedCount(0);
				stockPool.setUserTypeId(poolId);
				stockPool.setStockId(saveCompanyId);
				stockDao.saveAllocationUserTypeInStockPool(stockPool);
			}
			
			
			
		}
		
	}



	/**
	 * Gets the stock details based on login user.
	 *
	 * @param request the request
	 * @return the stock details based on login user
	 */
	@Override
	public StockDto getStockDetailsBasedOnLoginUser(HttpServletRequest request) {
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		String systemPropertyValueByPropertyId = null;
		try {
			 systemPropertyValueByPropertyId = commonUtils.getSystemPropertyValueByPropertyId(request,
					loggedInUser.getAssociationId(), ApplicationConstants.ALLOCATION_TYPE);
		} catch (ApplicationException e2) {
			e2.printStackTrace();
		}
		StockDto stockDto = new StockDto();
		if(ApplicationUtils.isValidateObject(systemPropertyValueByPropertyId) && !systemPropertyValueByPropertyId.equalsIgnoreCase(ApplicationConstants.NONE) && ApplicationUtils.isValidateObject(loggedInUser.getAllocationUserType()) ) {
			StockPool stockPool = stockDao.getStockPoolByCompanyIdAndAllocationType(loggedInUser.getCompanyId(),loggedInUser.getAllocationUserType());
			stockDto.setCompanyId(stockPool.getCompanyId());
			stockDto.setStockCount(stockPool.getStockCount());
			stockDto.setUsedCount(stockPool.getUsedCount());
			stockDto.setAvailableCount(stockPool.getStockCount() - stockPool.getUsedCount());
		}else {
			Stock stock = stockDao.getStockData(loggedInUser.getCompanyId());
			stockDto.setCompanyId(stock.getCompanyId());
			stockDto.setStockCount(stock.getStockCount());
			stockDto.setUsedCount(stock.getUsedCount());
			stockDto.setAvailableCount(stock.getStockCount() - stock.getUsedCount());
		}
		
		
		return stockDto;
	}

	/**
	 * Gets the purchase order details.
	 *
	 * @param purchaseId the purchase id
	 * @return the purchase order details
	 * @throws ApplicationException the application exception
	 */
	@Override
	public PurchaseOrderDto getPurchaseOrderDetails(Integer purchaseId) throws ApplicationException {
		PurchaseOrderDto responce = new PurchaseOrderDto();
		if(ApplicationUtils.isValidId(purchaseId)) {
		PaymentDetails paymentDetails = stockDao.getParticularPaymentDetails(purchaseId);
		
		if(ApplicationUtils.isValidateObject(paymentDetails)) {
			responce.setPaymentMethod(PaymentModeEnum.getPaymentModeById(paymentDetails.getPaymentMode()).getPaymentMode());
			responce.setPaymentStatus(PaymentStatusEnum.getPaymentStatusEnumById(paymentDetails.getPaymentStatus()).getPaymentStatus());
			responce.setPurchaseAmount(paymentDetails.getPaidAmount());
			responce.setPurchaseDate(paymentDetails.getPaymentDate().toString());
			responce.setPurchaseId(paymentDetails.getOrderId().getPurchaseId());
			responce.setStockCount(paymentDetails.getOrderId().getStockCount());	
			responce.setTransactionId(paymentDetails.getTransactionId());	
			responce.setOrderId(paymentDetails.getOrderId().getOrderId());
			}
		}
		return responce;
	}

}
