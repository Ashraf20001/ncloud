package com.digitalpaper.service.impl;

import java.time.LocalDateTime;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.digitalpaper.config.property.EnvironmentProperties;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.controller.SequenceEnum;
import com.digitalpaper.controller.SequenceGenerator;
import com.digitalpaper.dao.IStockDao;
import com.digitalpaper.dao.IStockNotificationDao;
import com.digitalpaper.dao.StockTransactionHistoryDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.service.AllocationStockService;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.AllocationStockDto;
import com.digitalpaper.transfer.object.dto.StockCountDto;
import com.digitalpaper.transfer.object.dto.StockNotificationDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.entity.NotificationTemplate;
import com.digitalpaper.transfer.object.entity.PurchaseOrderEntity;
import com.digitalpaper.transfer.object.entity.Stock;
import com.digitalpaper.transfer.object.entity.StockNotification;
import com.digitalpaper.transfer.object.entity.StockTransactionHistory;
import com.digitalpaper.transfer.object.entity.UserType;
import com.digitalpaper.transfer.object.enums.PaymentModeEnum;
import com.digitalpaper.transfer.object.enums.PaymentStatusEnum;
import com.digitalpaper.transfer.object.enums.PoolActionTypeEnum;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;
import com.digitalpaper.utils.core.ApplicationUtils;
import com.digitalpaper.utils.core.RestTemplateUtils;

/**
 * The Class AllocationStockServiceImpl.
 */
@Service
@Transactional
public class AllocationStockServiceImpl implements AllocationStockService{

	/** The logged in user context holder. */
	@Autowired
	private LoggedInUserContextHolder loggedInUserContextHolder;

	/** The stock dao. */
	@Autowired
	public IStockDao stockDao;

	/** The sequence generator. */
	@Autowired
    private SequenceGenerator sequenceGenerator;
	
	/** The stock transaction history dao. */
	@Autowired
	private StockTransactionHistoryDao stockTransactionHistoryDao;
	
	/** The notification dao. */
	@Autowired
	private IStockNotificationDao notificationDao;
	
	/** The messaging template. */
	@Autowired
	private SimpMessagingTemplate messagingTemplate;
	
	/** The rest template utils. */
	@Autowired
	private RestTemplateUtils restTemplateUtils;
	
	/**
	 * RestTemplate
	 */
	@Autowired
	private RestTemplate restTemplate;
	
	/** The Constant BONUS. */
	private final static String BONUS = "Bonus";

	/**
	 * SimpMessagingTemplate
	 */

	@Autowired
	private EnvironmentProperties environmentProperties;
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(AllocationStockServiceImpl.class);

	/**
	 * Save allocation stock.
	 *
	 * @param allocatePaperData the allocate paper data
	 * @return the string
	 * @throws ApplicationException the application exception
	 */
	@Override
	public String saveAllocationStock(AllocationStockDto allocatePaperData) throws ApplicationException {
		try {
			UserInfo userDetails = loggedInUserContextHolder.getLoggedInUser();
			Integer companyId=userDetails.getCompanyId();

			Stock stockDetails=stockDao.getStockData(allocatePaperData.getCompanyId());
			if (!ApplicationUtils.isValidateObject(stockDetails)) {
				throw new ApplicationException(ErrorCodes.INVALID_STOCK);
			}
			LocalDateTime date = LocalDateTime.now();
			Stock stockData = null;
			if(ApplicationUtils.isValidateObject(stockDetails)) {

				stockData = stockDetails;
				stockData.setCompanyId(allocatePaperData.getCompanyId());
				stockData.setModifiedBy(companyId);
				stockData.setModifiedDate(date);
				int stockCount = allocatePaperData.getNumberOfPaper()+ stockDetails.getStockCount();
				stockData.setStockCount(stockCount);
				stockDao.updateStock(stockData);
				Integer updateTransactionHistory = updateTransactionHistory(allocatePaperData, userDetails, stockData);
				if (updateTransactionHistory < 0) {
					LOGGER.info("FAILED======>Update Transaction history failed");
				}
				
			}

			PurchaseOrderEntity purchaseOrder = new PurchaseOrderEntity();

			String stockSequenceId=	sequenceGenerator.generateSequence(SequenceEnum.ORDER_SEQUENCE_ID);

			String purchaseSequenceId=	sequenceGenerator.generateSequence(SequenceEnum.PURCHASE_SEQUENCE_ID);

			purchaseOrder.setCompanyId(allocatePaperData.getCompanyId());
			purchaseOrder.setCreatedBy(companyId);
			purchaseOrder.setPurchaseId(purchaseSequenceId);
			LocalDateTime now = LocalDateTime.now();
			purchaseOrder.setCreatedDate(now);
			PaymentStatusEnum paymentStatusEnum = PaymentStatusEnum.getPaymentStatusEnum(ApplicationConstants.SUBMITTED);
			purchaseOrder.setOrderStatus(paymentStatusEnum.getId());
			Double d = new Double(allocatePaperData.getNumberOfPaper()) ;
			purchaseOrder.setOrderAmt(allocatePaperData.getNumberOfPaper()+ApplicationConstants.WITHOUT_SPACE);
			purchaseOrder.setStockCount( allocatePaperData.getNumberOfPaper());
			purchaseOrder.setPurchaseDate(now);
			purchaseOrder.setPaymentMethod(PaymentModeEnum.getPaymentModeByValue(allocatePaperData.getAllocatepaperType()).getId());

			Integer purchase_responce = stockDao.purchaseOrdersave(purchaseOrder);
			sendNotificationToWebsocket(allocatePaperData, userDetails, stockData, purchaseOrder);
		} catch (Exception e) {
			throw new ApplicationException(ErrorCodes.ALLOCATE_STOCK_FAILED);	
		}

		return ApplicationConstants.SUCCESS ;

	}



	/**
	 * Send notification to websocket.
	 *
	 * @param allocatePaperData the allocate paper data
	 * @param userDetails the user details
	 * @param stockData the stock data
	 * @param purchaseOrder the purchase order
	 * @throws ApplicationException the application exception
	 */
	private void sendNotificationToWebsocket(AllocationStockDto allocatePaperData, UserInfo userDetails,
			Stock stockData, PurchaseOrderEntity purchaseOrder) throws ApplicationException {
		StockNotification stockNotification = sendNotification(allocatePaperData, userDetails, stockData, purchaseOrder);
		StockNotificationDto notificationDtoObj = new StockNotificationDto();
		notificationDtoObj.setReplaceableData(stockNotification.getReplaceData());
		notificationDtoObj.setAction(stockNotification.getActionStatus());
		notificationDtoObj.setActedBy(stockNotification.getActedBy());
		notificationDtoObj.setNotificationMsg(stockNotification.getNotificationMsg());
		notificationDtoObj.setToNotify(stockNotification.getToNotify());
		notificationDtoObj.setOrderId((stockNotification!=null)?stockNotification.getOrderId().getOrderId():null);
		notificationDtoObj.setCreatedDate(stockNotification.getCreatedDate().toString());	
		notificationDtoObj.setNotificationId(stockNotification.getNotificationId());
		String logoUrl = null;
		try {
			logoUrl =(String)getCompanyLogo(stockNotification.getActedBy()).getContent();
		} catch (Exception e) {
			LOGGER.error("Error while getting  logo url ".concat(e.getMessage()) );
		}
		notificationDtoObj.setImageUrl(logoUrl);
		String url = ApplicationConstants.WEBSOCKET_ENDPOINT+stockNotification.getToNotify()+ApplicationConstants.SLASH+stockNotification.getIsAssociation().toString();
		messagingTemplate.convertAndSend(url,notificationDtoObj);
	}



	/**
	 * Send notification.
	 *
	 * @param allocatePaperData the allocate paper data
	 * @param userDetails the user details
	 * @param stockData the stock data
	 * @param purchaseOrder the purchase order
	 * @return the stock notification
	 * @throws ApplicationException the application exception
	 */
	private StockNotification sendNotification(AllocationStockDto allocatePaperData, UserInfo userDetails, Stock stockData,
			PurchaseOrderEntity purchaseOrder) throws ApplicationException {
		NotificationTemplate notificationTemplate = notificationDao.getNotificationTemplate(allocatePaperData.getAllocatepaperType().equals(BONUS)?3:4 ,allocatePaperData.getAllocatepaperType().toUpperCase());
		String replace = notificationTemplate.getContent().replace("STOCK_COUNT", String.valueOf(allocatePaperData.getNumberOfPaper()));
		StockNotification notificationEntity = new StockNotification();
		notificationEntity.setActedBy(userDetails.getAssociationId());
		notificationEntity.setActionStatus(allocatePaperData.getAllocatepaperType().toUpperCase());
		notificationEntity.setCreatedBy(userDetails.getId());
		notificationEntity.setCreatedDate(LocalDateTime.now());
		notificationEntity.setIsAssociation(Boolean.FALSE);
		notificationEntity.setIsDeleted(Boolean.FALSE);
		notificationEntity.setNotificationMsg(replace);
		notificationEntity.setToNotify(stockData.getCompanyId());
		notificationEntity.setOrderId(purchaseOrder);
		JSONObject replacableData = new JSONObject();
		replacableData.put(ApplicationConstants.COMPANY_NAME,"Association");
		replacableData.put(ApplicationConstants.STOCK_COUNT, String.valueOf(allocatePaperData.getNumberOfPaper()));
		notificationEntity.setReplaceData(replacableData.toString());
		notificationDao.saveNotification(notificationEntity);
		return notificationEntity;
	}



	/**
	 * Update transaction history.
	 *
	 * @param allocatePaperData the allocate paper data
	 * @param userDetails the user details
	 * @param stockData the stock data
	 * @return the integer
	 * @throws ApplicationException the application exception
	 */
	private Integer updateTransactionHistory(AllocationStockDto allocatePaperData, UserInfo userDetails, Stock stockData)
			throws ApplicationException {
		StockTransactionHistory stockTransactionHistory = new StockTransactionHistory();
		stockTransactionHistory.setCreatedBy(userDetails.getId());
		stockTransactionHistory.setCreatedDate(LocalDateTime.now());
		stockTransactionHistory.setDebitedStock(0);
		stockTransactionHistory.setCreditedStock(allocatePaperData.getNumberOfPaper());
		stockTransactionHistory.setPoolActionType(PoolActionTypeEnum.getPaperStatusIdByName(allocatePaperData.getAllocatepaperType()).getId());
		stockTransactionHistory.setStockId(stockData);
		Integer saveStockTransactionHistory = stockTransactionHistoryDao.saveStockTransactionHistory(stockTransactionHistory);
		return saveStockTransactionHistory;
	}



	/**
	 * @param companyId
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public StockCountDto getStockCountForAllocationStock(Integer companyId) throws ApplicationException {
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		UserType userTypeId = loggedInUser.getUserTypeId();
		if (!userTypeId.getUserTypeName().equals(ApplicationConstants.ASSOCIATION)) {
			throw new ApplicationException(ErrorCodes.UN_AUTHORIZED);
		}
		StockCountDto stockCountDto = stockDao.getStockCountForAllocationStock(companyId);
		return stockCountDto;
	}
	
	/**
	 * Gets the company logo.
	 *
	 * @param companyId the company id
	 * @return the company logo
	 */
	public ApplicationResponse getCompanyLogo(Integer companyId) {
		HttpHeaders headers = restTemplateUtils.getGETHeaders();
		HttpEntity<String> staticEntity = new HttpEntity<>(headers);
		if(Boolean.FALSE.equals(ApplicationUtils.isValidId(companyId))) {
			companyId = ApplicationConstants.ZERO; // For retrieving authority's default logo
		}
		String url = environmentProperties.getGateWayPath()+ApplicationConstants.COMPANY_LOGO + ApplicationConstants.SLASH + companyId;
    		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		ResponseEntity<ApplicationResponse> entity = restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
				staticEntity,ApplicationResponse.class);
		return entity.getBody();
	}

}
