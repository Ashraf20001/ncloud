package com.digitalpaper.purchasestock.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.digitalpaper.config.common.base.dao.BaseDao;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.purchasestock.dao.PurchaseStockDao;
import com.digitalpaper.transfer.object.constants.BasePredicateEntityColumnMap;
import com.digitalpaper.transfer.object.dto.AssociationDashboardCountDto;
import com.digitalpaper.transfer.object.dto.CompanyTransactionDto;
import com.digitalpaper.transfer.object.entity.PaymentDetails;
import com.digitalpaper.transfer.object.entity.PurchaseOrderEntity;
import com.digitalpaper.transfer.object.entity.StockFileMapping;
import com.digitalpaper.utils.core.ApplicationUtils;




/**
 * The Class PurchaseStockDaoImpl.
 */
@Repository
public class PurchaseStockDaoImpl extends BaseDao implements PurchaseStockDao {

	/**
	 * Gets the purchase order list.
	 *
	 * @param companyId the company id
	 * @param min the min
	 * @param max the max
	 * @param searchValue the search value
	 * @param filter the filter
	 * @return the purchase order list
	 * @throws ApplicationException the application exception
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getPurchaseOrderList(Integer companyId,int min,int max,String searchValue,List<FilterOrSortingVo> filter) throws ApplicationException {

		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Object[]> createQuery = builder.createQuery(Object[].class);
		Root<PaymentDetails> paymentDetails = createQuery.from(PaymentDetails.class);
		createQuery.multiselect(paymentDetails.get(TableConstants.ORDER_ID).get(TableConstants.DP_PURCHASE_ID),
				paymentDetails.get(TableConstants.DP_TRANSACTION_ID),
				paymentDetails.get(TableConstants.ORDER_ID).get(TableConstants.STOCK_COUNT),
				paymentDetails.get(TableConstants.ORDER_ID).get(TableConstants.DP_PURCHASE_DATE),
				paymentDetails.get(TableConstants.ORDER_ID).get(TableConstants.COMPANY_ID),
				paymentDetails.get(TableConstants.DP_PAYMENT_AMOUNT),
				paymentDetails.get(TableConstants.DP_PAYMENT_MODE),
				paymentDetails.get(TableConstants.DP_PAYMENT_STATUS),
				paymentDetails.get(TableConstants.DP_CURRENCY_TYPE),
				paymentDetails.get(TableConstants.ORDER_ID).get(TableConstants.ORDER_ID));
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(paymentDetails.get(TableConstants.ORDER_ID).get(TableConstants.IS_DELETED),false)));
		predicates.add(builder.and(builder.equal(paymentDetails.get(TableConstants.ISDELETED), false)));
		
		if (ApplicationUtils.isValidString(searchValue)) {
			predicates.add(builder.or(builder.like( 
	                builder.concat(paymentDetails.get(TableConstants.ORDER_ID).get(TableConstants.DP_PURCHASE_ID), 
	                builder.concat(paymentDetails.get(TableConstants.DP_TRANSACTION_ID), 
	                builder.concat(paymentDetails.get(TableConstants.ORDER_ID).get(TableConstants.STOCK_COUNT),
	                builder.concat(paymentDetails.get(TableConstants.DP_CURRENCY_TYPE),		
	                		paymentDetails.get(TableConstants.DP_PAYMENT_AMOUNT))))
	                ),"%"+searchValue+"%")));
		}
		
		List<Predicate> filterPredicate=getFilterPrdicets(filter, paymentDetails, builder, createQuery);
		if(ApplicationUtils.isValidList(filter)) {
			for (FilterOrSortingVo eachFilter : filter) {
				if(!eachFilter.getFilterOrSortingType().equalsIgnoreCase("SORTING")) {
					createQuery.orderBy(builder.desc(paymentDetails.get(TableConstants.MODIFIED_DATE)));
				}
			}
		}
		else {
			createQuery.orderBy(builder.desc(paymentDetails.get(TableConstants.MODIFIED_DATE)));
		}

		String joinColumnName = BasePredicateEntityColumnMap.basePredicateEntityColumnMap.get(paymentDetails.getModel().getJavaType());
		
		predicates.addAll(filterPredicate);
		return (List<Object[]>) getResultList(
				getBasePredicateResult(builder, createQuery, paymentDetails, joinColumnName, predicates).setFirstResult(min).setMaxResults(max));
	}


	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {

	}

	/**
	 * Gets the payment details by order id.
	 *
	 * @param orderId the order id
	 * @return the payment details by order id
	 */
	@Override
	public PaymentDetails getPaymentDetailsByOrderId(Integer orderId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<PaymentDetails> createQuery = builder.createQuery(PaymentDetails.class);
		Root<PaymentDetails> root = createQuery.from(PaymentDetails.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ORDER_ID).get(TableConstants.ORDER_ID), orderId)));
		return (PaymentDetails) getSingleResult(createQuery(builder, createQuery, root, predicates));
	}

	/**
	 * Gets the purchase order from purchase id.
	 *
	 * @param purchaseId the purchase id
	 * @return the purchase order from purchase id
	 */
	@Override
	public PurchaseOrderEntity getPurchaseOrderFromPurchaseId(String purchaseId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<PurchaseOrderEntity> createQuery = builder.createQuery(PurchaseOrderEntity.class);
		Root<PurchaseOrderEntity> root = createQuery.from(PurchaseOrderEntity.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.DP_PURCHASE_ID), purchaseId)));
		return (PurchaseOrderEntity) getSingleResult(createQuery(builder, createQuery, root, predicates));
	}

	/**
	 * Update payment details.
	 *
	 * @param paymentDetails the payment details
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void updatePaymentDetails(PaymentDetails paymentDetails) throws ApplicationException{
		update(paymentDetails);
	}

	/**
	 * Update purchase order.
	 *
	 * @param purchaseOrder the purchase order
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void updatePurchaseOrder(PurchaseOrderEntity purchaseOrder)  throws ApplicationException {
		update(purchaseOrder);

	}

	/**
	 * Gets the payment details by filter.
	 *
	 * @param companyTransactionList the company transaction list
	 * @param searchvalue the searchvalue
	 * @param matchingKey the matching key
	 * @return the payment details by filter
	 * @throws ApplicationException the application exception
	 */
	@Override
	public List<PaymentDetails> getPaymentDetailsByFilter(CompanyTransactionDto companyTransactionList, String searchvalue,List<Integer> matchingKey) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<PaymentDetails> createQuery = builder.createQuery(PaymentDetails.class);
		Root<PaymentDetails> root = createQuery.from(PaymentDetails.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		if(!companyTransactionList.getCompanyId().isEmpty()) {
			Expression expression=root.get(TableConstants.ORDER_ID).get(TableConstants.COMPANY_ID);
			Predicate predicateForId =expression.in(companyTransactionList.getCompanyId());
			predicates.add(builder.and(predicateForId));
		}
		predicates.addAll(getFilterPrdicets(companyTransactionList.getFilter(), root, builder, createQuery));
		List<FilterOrSortingVo> filter = companyTransactionList.getFilter();
		
		if (ApplicationUtils.isValidString(searchvalue) && matchingKey.isEmpty()) {
			predicates.add(builder.or(builder.like( 
	                builder.concat(root.get(TableConstants.ORDER_ID).get(TableConstants.DP_PURCHASE_ID), 
	                builder.concat(root.get(TableConstants.DP_TRANSACTION_ID), 
	                		(root.get(TableConstants.ORDER_ID).get(TableConstants.STOCK_COUNT))))
	                ,"%"+searchvalue+"%")));
		}	
		
		if(!matchingKey.isEmpty()) {
			Expression expression=root.get(TableConstants.ORDER_ID).get(TableConstants.COMPANY_ID);
			Predicate predicateForCompanyID =expression.in(matchingKey);
			predicates.add(builder.and(predicateForCompanyID));
		}
		
		if(ApplicationUtils.isValidList(filter)) {
			for (FilterOrSortingVo filterOrSortingVo : filter) {
				if(!filterOrSortingVo.getFilterOrSortingType().equalsIgnoreCase("SORTING")) {
					createQuery.orderBy(builder.desc(root.get(TableConstants.MODIFIED_DATE)));
				}
			}
		}
		else {
			createQuery.orderBy(builder.desc(root.get(TableConstants.MODIFIED_DATE)));
		}


		return (List<PaymentDetails>) getResultList(createQuery(builder, createQuery,root,predicates).setFirstResult(companyTransactionList.getMin()).setMaxResults(companyTransactionList.getMax()));
	}

	/**
	 * Gets the purchase order count.
	 *
	 * @param companyId the company id
	 * @param filterOrSortingVos the filter or sorting vos
	 * @param searchValue the search value
	 * @return the purchase order count
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Long getPurchaseOrderCount(Integer companyId,List<FilterOrSortingVo> filterOrSortingVos,String searchValue) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<PaymentDetails> root = criteria.from(PaymentDetails.class);
		criteria.select(builder.count(root));
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ORDER_ID).get(TableConstants.COMPANY_ID), companyId)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ORDER_ID).get(TableConstants.ISDELETED), false)));
		
		if (ApplicationUtils.isValidString(searchValue)) {
			predicates.add(builder.or(builder.like( 
	                builder.concat(root.get(TableConstants.ORDER_ID).get(TableConstants.DP_PURCHASE_ID), 
	                builder.concat(root.get(TableConstants.DP_TRANSACTION_ID), 
	                builder.concat(root.get(TableConstants.ORDER_ID).get(TableConstants.STOCK_COUNT),
	                builder.concat(root.get(TableConstants.DP_CURRENCY_TYPE),		
	                		root.get(TableConstants.DP_PAYMENT_AMOUNT))))
	                ),"%"+searchValue+"%")));
		}
		
		List<Predicate> filterPredicates = getFilterPrdicets(filterOrSortingVos, root, builder, criteria);
		predicates.addAll(filterPredicates);
		return (Long) getSingleResult(createQuery(builder, criteria, root, predicates));

	}

	/**
	 * Gets the payment details count.
	 *
	 * @param companyTransactionDto the company transaction dto
	 * @param searchValue the search value
	 * @return the payment details count
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Long getPaymentDetailsCount(CompanyTransactionDto companyTransactionDto, String searchValue) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<PaymentDetails> root = criteria.from(PaymentDetails.class);
		criteria.select(builder.count(root));
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		if(!companyTransactionDto.getCompanyId().isEmpty()) {
			Expression expression=root.get(TableConstants.ORDER_ID).get(TableConstants.COMPANY_ID);
			Predicate predicateForId =expression.in(companyTransactionDto.getCompanyId());
			predicates.add(builder.and(predicateForId));
		}
		
		if (ApplicationUtils.isValidString(searchValue)) {
			predicates.add(builder.or(builder.like( 
	                builder.concat(root.get(TableConstants.ORDER_ID).get(TableConstants.DP_PURCHASE_ID), 
	                builder.concat(root.get(TableConstants.DP_TRANSACTION_ID), 
	                		(root.get(TableConstants.ORDER_ID).get(TableConstants.STOCK_COUNT))))
	                ,"%"+searchValue+"%")));
		}	
		
		predicates.addAll(getFilterPrdicets(companyTransactionDto.getFilter(), root, builder, criteria));
		criteria.orderBy(builder.asc(root.get(TableConstants.ORDER_ID).get(TableConstants.ORDER_STATUS)),builder.desc(root.get(TableConstants.MODIFIED_DATE)));

		return (Long) getSingleResult(createQuery(builder, criteria, root, predicates));

	}

	/**
	 * Gets the purchase order from order id.
	 *
	 * @param orderId the order id
	 * @return the purchase order from order id
	 */
	@Override
	public PurchaseOrderEntity getPurchaseOrderFromOrderId(Integer orderId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<PurchaseOrderEntity> createQuery = builder.createQuery(PurchaseOrderEntity.class);
		Root<PurchaseOrderEntity> root = createQuery.from(PurchaseOrderEntity.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ORDER_ID), orderId)));
		return (PurchaseOrderEntity) getSingleResult(createQuery(builder, createQuery, root, predicates));
	}

	/**
	 * Gets the all purchase order list.
	 *
	 * @param min the min
	 * @param max the max
	 * @param filter the filter
	 * @return the all purchase order list
	 * @throws ApplicationException the application exception
	 */
	@Override
	public List<PurchaseOrderEntity> getAllPurchaseOrderList(int min, int max, List<FilterOrSortingVo> filter)
			throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<PurchaseOrderEntity> createQuery = builder.createQuery(PurchaseOrderEntity.class);
		Root<PurchaseOrderEntity> root = createQuery.from(PurchaseOrderEntity.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		List<Predicate> filterPredicates = getFilterPrdicets(filter, root, builder, createQuery);
		predicates.addAll(filterPredicates);
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		return (List<PurchaseOrderEntity>) getResultList(createQuery(builder, createQuery,root,predicates).setFirstResult(min).setMaxResults(max));
	}

	/**
	 * Gets the all purchase order count.
	 *
	 * @return the all purchase order count
	 */
	@Override
	public Long getAllPurchaseOrderCount() {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<PurchaseOrderEntity> root = criteria.from(PurchaseOrderEntity.class);
		criteria.select(builder.count(root));
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		return (Long) getSingleResult(createQuery(builder, criteria, root, predicates));

	}

	/**
	 * Gets the stock file mapping by order id.
	 *
	 * @param orderId the order id
	 * @return the stock file mapping by order id
	 */
	@Override
	public StockFileMapping getStockFileMappingByOrderId(Integer orderId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<StockFileMapping> createQuery = builder.createQuery(StockFileMapping.class);
		Root<StockFileMapping> root = createQuery.from(StockFileMapping.class);
		createQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ORDER_ID), orderId)));
		return (StockFileMapping) getSingleResult(createQuery(builder, createQuery, root, predicates));
	}


	/**
	 * Gets the authority dashboard count.
	 *
	 * @param associationId the association id
	 * @return the authority dashboard count
	 */
	@Override
	public List<AssociationDashboardCountDto> getAuthorityDashboardCount(Integer associationId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<AssociationDashboardCountDto> createQuery = builder.createQuery(AssociationDashboardCountDto.class);
		Root<PaymentDetails> root = createQuery.from(PaymentDetails.class);
        Expression<Long> sumExpression = builder.sum(root.get(TableConstants.ORDER_ID).get(TableConstants.STOCK_COUNT));
        Expression<String> statusExpression = root.get(TableConstants.ORDER_ID).get(TableConstants.ORDER_STATUS);

        List<Predicate> predicates = new ArrayList<Predicate>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
        Predicate allocatedStockCount = builder.equal(statusExpression, 3);
        Predicate pendingStockCount = builder.equal(statusExpression, 2);
        createQuery.multiselect(statusExpression, sumExpression)
        .where(builder.or(allocatedStockCount, pendingStockCount))
        .groupBy(statusExpression);
		return (List<AssociationDashboardCountDto>)getResultList(createQuery(builder, createQuery, root, predicates));
	}


}
