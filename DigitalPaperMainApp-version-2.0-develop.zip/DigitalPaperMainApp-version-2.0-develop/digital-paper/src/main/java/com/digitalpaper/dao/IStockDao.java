package com.digitalpaper.dao;

import java.util.List;
import java.util.Map;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.AuthorityStockDto;
import com.digitalpaper.transfer.object.dto.StockCountDto;
import com.digitalpaper.transfer.object.entity.PaymentDetails;
import com.digitalpaper.transfer.object.entity.PurchaseOrderEntity;
import com.digitalpaper.transfer.object.entity.Stock;
import com.digitalpaper.transfer.object.entity.StockFileMapping;
import com.digitalpaper.transfer.object.entity.StockPool;

/**
 * The Interface IStockDao.
 */
public interface IStockDao {

	/**
	 * Gets the stock data.
	 *
	 * @param companyId the company id
	 * @return the stock data
	 */
	Stock getStockData(Integer companyId);

	/**
	 * Gets the purchase details.
	 *
	 * @return the purchase details
	 */
	List<PurchaseOrderEntity> getPurchaseDetails();

	/**
	 * Purchase ordersave.
	 *
	 * @param purchaseOrder the purchase order
	 * @return the integer
	 */
	Integer purchaseOrdersave(PurchaseOrderEntity purchaseOrder);

	/**
	 * Payment details save.
	 *
	 * @param paymentDetails the payment details
	 * @return the integer
	 */
	Integer paymentDetailsSave(PaymentDetails paymentDetails);

	/**
	 * Stock save.
	 *
	 * @param stockData the stock data
	 * @return the integer
	 */
	Integer stockSave(Stock stockData);

	/**
	 * Gets the purchase order data by order id.
	 *
	 * @param orderId the order id
	 * @return the purchase order data by order id
	 */
	PurchaseOrderEntity getpurchaseOrderDataByOrderId(Integer orderId);

	/**
	 * Purchase order update.
	 *
	 * @param purchaseOrder2 the purchase order 2
	 * @throws ApplicationException the application exception
	 */
	void purchaseOrderUpdate(PurchaseOrderEntity purchaseOrder2) throws ApplicationException;

	/**
	 * Gets the payment details based on order id.
	 *
	 * @param companyId the company id
	 * @return the payment details based on order id
	 */
	PaymentDetails getPaymentDetailsBasedOnOrderId(Integer companyId);

	/**
	 * Update payment details.
	 *
	 * @param paymentDetails2 the payment details 2
	 */
	void updatePaymentDetails(PaymentDetails paymentDetails2);
	
     /**
      * Save file data for order.
      *
      * @param stockFileMapping the stock file mapping
      * @return the integer
      */
     Integer saveFileDataForOrder(StockFileMapping stockFileMapping);

	/**
	 * Gets the purchase order by order id.
	 *
	 * @param orderId the order id
	 * @return the purchase order by order id
	 */
	PurchaseOrderEntity getpurchaseOrderByOrderId(Integer orderId);

	/**
	 * Update stock.
	 *
	 * @param stockData the stock data
	 */
	void updateStock(Stock stockData);
	
	/**
	 * Gets the stock pool data.
	 *
	 * @param poolId the pool id
	 * @return the stock pool data
	 */
	StockPool getStockPoolData(Integer poolId);


	/**
 * Gets the stock and count list.
 *
 * @param companyNameMaping the company name maping
 * @param skip the skip
 * @param limit the limit
 * @param companyIds the company ids
 * @param filterVo the filter vo
 * @param isCount the is count
 * @param searchValue the search value
 * @return the stock and count list
 * @throws ApplicationException the application exception
 */
List<AuthorityStockDto> getStockAndCountList(Map<Integer, String> companyNameMaping, Integer skip, Integer limit,
			List<Integer> companyIds, List<FilterOrSortingVo> filterVo,Boolean isCount, String searchValue) throws ApplicationException;

	/**
	 * Gets the total stock count.
	 *
	 * @param companyIdFromStockTable the company id from stock table
	 * @return the total stock count
	 */
	Long getTotalStockCount(List<Integer> companyIdFromStockTable);
	
	/**
	 * Gets the total paper issued count.
	 *
	 * @param companyNameMapping the company name mapping
	 * @return the total paper issued count
	 */
	List<Object[]> getTotalPaperIssuedCount(Map<Integer,String> companyNameMapping);
	
	/**
	 * Save allocation user type in stock pool.
	 *
	 * @param stockPool the stock pool
	 */
	void saveAllocationUserTypeInStockPool(StockPool stockPool);

	/**
	 * Gets the stock count for allocation stock.
	 *
	 * @param companyId the company id
	 * @return the stock count for allocation stock
	 */
	StockCountDto getStockCountForAllocationStock(Integer companyId);

	/**
	 * Gets the stock pool by company id and allocation type.
	 *
	 * @param companyId the company id
	 * @param allocationUserType the allocation user type
	 * @return the stock pool by company id and allocation type
	 */
	StockPool getStockPoolByCompanyIdAndAllocationType(Integer companyId, Integer allocationUserType);

	/**
	 * Gets the particular payment details.
	 *
	 * @param purchaseId the purchase id
	 * @return the particular payment details
	 * @throws ApplicationException the application exception
	 */
	PaymentDetails getParticularPaymentDetails(Integer purchaseId) throws ApplicationException;
	
	/**
	 * Gets the company stock count.
	 *
	 * @param skip the skip
	 * @param limit the limit
	 * @param companyIdsFromStockTable the company ids from stock table
	 * @param filterVo the filter vo
	 * @param isCount the is count
	 * @return the company stock count
	 * @throws ApplicationException the application exception
	 */
	List<Object[]> getCompanyStockCount(Integer skip,Integer limit,List<Integer> companyIdsFromStockTable, List<FilterOrSortingVo> filterVo, Boolean isCount) throws ApplicationException;
	
	/**
	 * Gets the used counts of companies.
	 *
	 * @param skip the skip
	 * @param limit the limit
	 * @param companyIds the company ids
	 * @param companyNameMaping the company name maping
	 * @param filterVo the filter vo
	 * @param isCount the is count
	 * @param searchValue the search value
	 * @return the used counts of companies
	 * @throws ApplicationException the application exception
	 */
	List<Object[]> getUsedCountsOfCompanies(Integer skip, Integer limit,
			List<Integer> companyIds, Map<Integer, String> companyNameMaping,List<FilterOrSortingVo> filterVo, Boolean isCount, String searchValue) throws ApplicationException;

}
