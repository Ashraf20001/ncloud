package com.digitalpaper.service;

import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.AllocationStockDto;
import com.digitalpaper.transfer.object.dto.StockCountDto;

/**
 * The Interface AllocationStockService.
 */
public interface AllocationStockService {

	/**
	 * Save allocation stock.
	 *
	 * @param allocatePaperData the allocate paper data
	 * @return the string
	 * @throws ApplicationException the application exception
	 */
	String saveAllocationStock(AllocationStockDto allocatePaperData) throws ApplicationException;

	/**
	 * @param companyId
	 * @return
	 * @throws ApplicationException
	 */
	StockCountDto getStockCountForAllocationStock(Integer companyId) throws ApplicationException;;

}
