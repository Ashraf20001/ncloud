package com.digitalpaper.config;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * The Class DigitalPaperCache.
 */
@Component
public class DigitalPaperCache {
	
	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(DigitalPaperCache.class);
    
    /** The role api map. */
    private static Map<Integer,String> roleApiMap;
    
    /** The system property V alue. */
    private static HashMap<String,String> systemPropertyVAlue;
    
    /** The company list. */
    private static HashMap<Integer,String> companyList;
    
    /** The makes. */
    private static List<String> makes;
    
    /** The models. */
    private static List<String> models;
    
    /** The usage. */
    private static List<String> usage;
    
    
	/**
	 * Gets the makes.
	 *
	 * @return the makes
	 */
	public static List<String> getMakes() {
		return makes;
	}
	
	/**
	 * Sets the makes.
	 *
	 * @param makes the new makes
	 */
	public static void setMakes(List<String> makes) {
		DigitalPaperCache.makes = makes;
	}
	
	/**
	 * Gets the models.
	 *
	 * @return the models
	 */
	public static List<String> getModels() {
		return models;
	}
	
	/**
	 * Sets the models.
	 *
	 * @param models the new models
	 */
	public static void setModels(List<String> models) {
		DigitalPaperCache.models = models;
	}
	
	/**
	 * Gets the usage.
	 *
	 * @return the usage
	 */
	public static List<String> getUsage() {
		return usage;
	}
	
	/**
	 * Sets the usage.
	 *
	 * @param usage the new usage
	 */
	public static void setUsage(List<String> usage) {
		DigitalPaperCache.usage = usage;
	}
	
	/**
	 * Gets the company list.
	 *
	 * @return the company list
	 */
	public static HashMap<Integer, String> getCompanyList() {
		return companyList;
	}
	
	/**
	 * Sets the company list.
	 *
	 * @param companyList the company list
	 */
	public static void setCompanyList(HashMap<Integer, String> companyList) {
		DigitalPaperCache.companyList = companyList;
	}
	
	/**
	 * Gets the system property V alue.
	 *
	 * @return the system property V alue
	 */
	public static HashMap<String, String> getSystemPropertyVAlue() {
		return systemPropertyVAlue;
	}
	
	/**
	 * Sets the system property V alue.
	 *
	 * @param systemPropertyVAlue the system property V alue
	 */
	public static void setSystemPropertyVAlue(HashMap<String, String> systemPropertyVAlue) {
		DigitalPaperCache.systemPropertyVAlue = systemPropertyVAlue;
	}
	
	/**
	 * Gets the role api map.
	 *
	 * @return the role api map
	 */
	public static Map<Integer, String> getRoleApiMap() {
		return roleApiMap;
	}
	
	/**
	 * Sets the role api map.
	 *
	 * @param roleApiMap the role api map
	 */
	public static void setRoleApiMap(Map<Integer, String> roleApiMap) {
		DigitalPaperCache.roleApiMap = roleApiMap;
	}


	/**
	 * The Enum DigitalCacheItem.
	 */
	private enum DigitalCacheItem {
		
		/** The role api maps. */
		roleApiMaps
	}

	/**
	 * Pork cache.
	 *
	 * @param cacheName the cache name
	 */
	public void porkCache(String cacheName) {
		logger.info("Pork Cache method invoked .....", cacheName);
		if (DigitalCacheItem.roleApiMaps.name().equalsIgnoreCase(cacheName)) {
			setRoleApiMap(null);
			logger.info("Cache Cleared successfully ....." + cacheName);
		}
	}

	/**
	 * Clear cache.
	 */
	public void clearCache() {
		DigitalPaperCache.roleApiMap = null;
	}
}
