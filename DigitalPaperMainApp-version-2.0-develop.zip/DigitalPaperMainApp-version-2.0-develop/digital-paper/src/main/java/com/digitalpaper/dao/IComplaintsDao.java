package com.digitalpaper.dao;

import java.util.List;

import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.entity.Complaints;
import com.digitalpaper.transfer.object.entity.PaperDetails;

/**
 * The Interface IComplaintsDao.
 */
public interface IComplaintsDao {

	/**
	 * Save complaints details.
	 *
	 * @param complaints the complaints
	 * @throws ApplicationException the application exception
	 */
	void saveComplaintsDetails(Complaints complaints) throws ApplicationException;

	/**
	 * Gets the complaints all data.
	 *
	 * @param userId the user id
	 * @return the complaints all data
	 */
	List<Complaints> getComplaintsAllData(Integer userId);

	/**
	 * Gets the digital paper details based on email id and name.
	 *
	 * @param name the name
	 * @param emailId the email id
	 * @return the digital paper details based on email id and name
	 */
	PaperDetails getdigitalPaperDetailsBasedOnEmailIdAndName(String name, String emailId);

	/**
	 * Gets the complaints details.
	 *
	 * @param emailId the email id
	 * @return the complaints details
	 */
	Complaints getComplaintsDetails(String emailId);

}
