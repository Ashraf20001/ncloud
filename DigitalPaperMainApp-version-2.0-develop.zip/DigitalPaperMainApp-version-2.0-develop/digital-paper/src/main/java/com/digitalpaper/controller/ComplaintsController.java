package com.digitalpaper.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.digitalpaper.config.base.controller.BaseController;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.service.IComplaintsService;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.ComplaintsDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;


/**
 * The Class ComplaintsController.
 */
@RestController
@RequestMapping("/complaints")
public class ComplaintsController extends BaseController {
	
	
	/** The complaints service. */
	@Autowired
	private IComplaintsService complaintsService;
	
	/**
	 * Save complaints.
	 *
	 * @param complaintsList the complaints list
	 * @return the application response
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Complaints save",notes="Create complaints for the policy holder",response = ApplicationResponse.class)
	@PostMapping("/save")
	public ApplicationResponse saveComplaints(@ApiParam(value = "Complaints dto payload",required = true) @RequestBody ComplaintsDto complaintsList) throws ApplicationException {
		String complaintsStatus = complaintsService.saveComplaintsDetails(complaintsList);
		return getApplicationResponse(complaintsStatus);

	}
	
	/**
	 * Gets the complaints.
	 *
	 * @return the complaints
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Complaints details",notes="Get complaints details for the policy holder",response = ApplicationResponse.class)
	@GetMapping("/get-all-details")
	public ApplicationResponse getComplaints() throws ApplicationException {
		
		List<ComplaintsDto> data = new ArrayList<ComplaintsDto>();
		data = complaintsService.getComplaintsDetails();
		
		return getApplicationResponse(data);
	}

	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {
		
	}

}
