package com.digitalpaper.controller;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitalpaper.config.base.controller.BaseController;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.service.IBulkRevokeService;
import com.digitalpaper.transfer.object.core.ApplicationResponse;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class BulkRevokeController.
 */
@RestController
public class BulkRevokeController extends BaseController {

	/** The i bulk revoke service. */
	@Autowired
	private IBulkRevokeService iBulkRevokeService;

	/**
	 * Gets the revoke scratch count.
	 *
	 * @param bulkUploadId the bulk upload id
	 * @param filterVo the filter vo
	 * @return the revoke scratch count
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Bulk revoke error",notes="Get Bulk revoke error scratch count for bulk upload id",response=Long.class)
	@PostMapping("/get-revoke-scratch-count")
	public Long getRevokeScratchCount(@ApiParam(value = "Bulk upload id",required = true) @RequestParam(name="bulkUploadId") Integer bulkUploadId,@ApiParam(value = "Filter data payload")  @RequestBody(required = false) List<FilterOrSortingVo> filterVo)
			throws ApplicationException {
		return iBulkRevokeService.getRevokeScratchCount(bulkUploadId,filterVo);

	}

	/**
	 * Gets the error data.
	 *
	 * @param skip the skip
	 * @param limit the limit
	 * @param bulkUploadId the bulk upload id
	 * @param filterVo the filter vo
	 * @return the error data
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Bulk revoke error data",notes="Get Bulk revoke error data  for bulk upload id",response=ArrayList.class)
	@PostMapping("/get-br-error-data")
	public ArrayList<LinkedHashMap<String, Object>> getErrorData(@ApiParam(value="Skip data count",required = true) @RequestParam(name = "skip") Integer skip,
			@ApiParam(value="Limit data count",required = true)  @RequestParam(name = "limit") Integer limit,
			@ApiParam(value="Bulk upload Id",required = true)  @RequestParam(name = "bulkUploadId") Integer bulkUploadId,
			@ApiParam(value = "Filter vo payload")   @RequestBody(required = false) List<FilterOrSortingVo> filterVo) throws ApplicationException {
		return iBulkRevokeService.getErrorData(skip, limit,bulkUploadId, filterVo);

	}

	/**
	 * Gets the success data.
	 *
	 * @param skip the skip
	 * @param limit the limit
	 * @param bulkUploadId the bulk upload id
	 * @param filterVo the filter vo
	 * @return the success data
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Bulk revoke success data",notes="Get Bulk revoke success data for bulk upload id",response=ArrayList.class)
	@PostMapping("/get-br-success-data")
	public ArrayList<LinkedHashMap<String, Object>> getSuccessData(@ApiParam(value = "Skip data count",required = true) @RequestParam(name = "skip") Integer skip,
			@ApiParam(value = "Limit data count",required = true) @RequestParam(name = "limit") Integer limit, 
			@ApiParam(value="Bulk upload id",required = true) @RequestParam(name = "bulkUploadId") Integer bulkUploadId,
			@ApiParam(value="Filter vo payload")  @RequestBody(required = false) List<FilterOrSortingVo> filterVo) throws ApplicationException {
		return iBulkRevokeService.getSuccessData(skip, limit,bulkUploadId, filterVo);

	}
	
	/**
	 * Gets the error count.
	 *
	 * @param bulkUploadId the bulk upload id
	 * @param filterVo the filter vo
	 * @return the error count
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Bulk revoke error count",notes="Get Bulk revoke error count for bulk upload id",response=ArrayList.class)
	@PostMapping("/get-br-error-count")
	public Long getErrorCount(@ApiParam(value="Bulk upload id",required = true) @RequestParam(name = "bulkUploadId") Integer bulkUploadId,
			@ApiParam(value="Filter vo payload")  @RequestBody(required = false) List<FilterOrSortingVo> filterVo) throws ApplicationException {
		return iBulkRevokeService.getErrorCount(bulkUploadId,filterVo);

	}
	
	/**
	 * Gets the success count.
	 *
	 * @param bulkUploadId the bulk upload id
	 * @param filterVo the filter vo
	 * @return the success count
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Bulk revoke success count",notes="Get bulk upload success count for bulk upload id",response = Long.class)
	@PostMapping("/get-br-success-count")
	public Long getSuccessCount(@ApiParam(value="Bulk upload id",required = true)  @RequestParam(name = "bulkUploadId") Integer bulkUploadId,
			@ApiParam(value = "Filter vo payload")  @RequestBody(required = false) List<FilterOrSortingVo> filterVo) throws ApplicationException {
		return iBulkRevokeService.getSuccessCount(bulkUploadId,filterVo);
	}
	
	/**
	 * Delete bulk revoke.
	 *
	 * @param identity the identity
	 * @return the application response
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Delete bulk revoke",notes="Delete bulk revoke error table based on bulk revoke error identity",response = ApplicationResponse.class)
	@PostMapping("/delete-bulk-revoke")
	public ApplicationResponse deleteBulkRevoke(@ApiParam(value = "Bulk revoke error table identity",required = true)  @RequestParam (name="identity") String identity) throws ApplicationException {
		return getApplicationResponse(iBulkRevokeService.deleteBulkRevoke(identity));
		
	}

	/**
	 * Sample excel download.
	 *
	 * @param pageIdentity the page identity
	 * @param bulkUploadId the bulk upload id
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value="Bulk revoke download",notes="Download bulk revoke list as excel",response = ResponseEntity.class)
	@PostMapping("/br-excel-file-download")
	public ResponseEntity<ByteArrayResource> sampleExcelDownload(
			@ApiParam(value=" Bulk revoke page Identity",required = true)
		  @RequestParam(name = "pageIdentity") String pageIdentity,
		  @ApiParam(value="Bulk revoke id")	@RequestParam(name = "bulkUploadId") Integer bulkUploadId) throws ApplicationException {
		return iBulkRevokeService.excelDownload(pageIdentity, bulkUploadId);

	}
	
	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {
		
	}
	
}
