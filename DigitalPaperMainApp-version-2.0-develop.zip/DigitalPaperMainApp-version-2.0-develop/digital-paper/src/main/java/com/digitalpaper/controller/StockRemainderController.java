package com.digitalpaper.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.digitalpaper.file.handler.service.IEmailService;
import com.digitalpaper.transfer.object.dto.StockDto;

import freemarker.template.TemplateException;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class StockRemainderController.
 */
@RestController
public class StockRemainderController {

	/** The service. */
	@Autowired
	private IEmailService service;
	
	/**
	 * Stock email.
	 *
	 * @param stock the stock
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws TemplateException the template exception
	 */
	@ApiOperation(value="Stock reminder",notes="Send reminder mail to company for the stocks  ")
	@PostMapping("/send-stock-remainder")
	public void stockEmail(@ApiParam(value="StockDto payload data",required = true) @RequestBody StockDto stock) throws IOException, TemplateException {
		service.stockRemainderMail(stock);
	}

}
