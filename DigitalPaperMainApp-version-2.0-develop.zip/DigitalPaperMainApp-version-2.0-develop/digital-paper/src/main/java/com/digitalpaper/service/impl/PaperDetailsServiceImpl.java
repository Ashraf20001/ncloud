package com.digitalpaper.service.impl;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.digitalpaper.config.DigitalPaperCache;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.config.property.EnvironmentProperties;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.IPaperDetailsDao;
import com.digitalpaper.dao.IScratchDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.file.handler.service.impl.EmailServiceImpl;
import com.digitalpaper.restemplate.service.IRestTemplateService;
import com.digitalpaper.service.IPaperDetailsService;
import com.digitalpaper.transfer.object.dto.AllSearchFilterDto;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.entity.BulkImportErrorTable;
import com.digitalpaper.transfer.object.entity.FileStorage;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.entity.Scratch;
import com.digitalpaper.transfer.object.enums.PaperDetailsStatusEnum;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;
import com.digitalpaper.utils.PaperGenerationUtils;
import com.digitalpaper.utils.core.ApplicationDateUtils;
import com.digitalpaper.utils.core.ApplicationUtils;

/**
 * The Class PaperDetailsServiceImpl.
 */
@Service
@Transactional
public class PaperDetailsServiceImpl implements IPaperDetailsService {

	/**
	 * IPaperDetailsDao
	 */
	@Autowired
	private IPaperDetailsDao iPaperDetailsDao;
	/**
	 * IScratchDao
	 */
	@Autowired
	private IScratchDao scratchDao;

	/** The dp template folder. */
	@Value("${dpmainapp.dp-template-path}")
	private String dp_template_folder;

	/**
	 * EnvironmentProperties
	 */
	@Autowired
	private EnvironmentProperties environmentProperties;
	
	
	/** The email service impl. */
	@Autowired
	private EmailServiceImpl emailServiceImpl;


      /** The Constant logger. */
      private static final Logger logger = LoggerFactory.getLogger(ApplicationDateUtils.class);



	/**
	 * LoggedInUserContextHolder
	 */
	@Autowired
	private LoggedInUserContextHolder loggedInUserContextHolder;

	/** The i rest template service. */
	@Autowired
	private IRestTemplateService iRestTemplateService;
	
	/**
	 * 
	 */
	@Autowired
	private DigitalPaperCache digitalPaperCache;

	/** The paper generation utils. */
	@Autowired
	private PaperGenerationUtils paperGenerationUtils;

	/**
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public Long getPaperDeatilsCount(List<FilterOrSortingVo> filterVo,String view,String searchValue) throws ApplicationException {
		valueListStringConversion(filterVo);
		UserInfo userInfo = getUserInfo();
		Integer companyId = userInfo.getCompanyId();
		if (ApplicationUtils.isNotValidId(companyId)
				&& !(userInfo.getUserTypeId().getUserTypeId().equals(ApplicationConstants.ONE))) {
			throw new ApplicationException(ErrorCodes.INVALID_ACTION);
		}
		Boolean parseBoolean=null;
		if(!view.equals(ApplicationConstants.NULL)) {
			parseBoolean= Boolean.parseBoolean(view);
		}
		
		Long paperDetailsCount = iPaperDetailsDao.getPaperDetailsCount(filterVo, companyId,parseBoolean,searchValue);
		return paperDetailsCount;
	}

	/**
	 * @return
	 * @throws ApplicationException
	 */
	private UserInfo getUserInfo() throws ApplicationException {
		UserInfo userInfo = loggedInUserContextHolder.getLoggedInUser();
		if(!ApplicationUtils.isValidateObject(userInfo)) {
			throw new ApplicationException(ErrorCodes.INVALID_USER);
		}
		return userInfo;
	}

	/**
	 * @param filterVo
	 */
	private void valueListStringConversion(List<FilterOrSortingVo> filterVo) {
		if (ApplicationUtils.isValidList(filterVo)) {
			for (FilterOrSortingVo filterObject : filterVo) {
				List<String> valueList = filterObject.getValueList();
				if (ApplicationUtils.isValidList(valueList)) {
					List<String> integerListData = new ArrayList<String>();
					for (String value : valueList) {
						if (filterObject.getColumnName().equals(ApplicationConstants.PD_STATUS)) {
							Integer val = PaperDetailsStatusEnum.getNameById(value);
							integerListData.add(val.toString());
						}
					}
					valueList = integerListData;
				}
				filterObject.setValueList(valueList);
			}
		}
	}

	/**
	 * @param skips
	 * @param limit
	 * @param filterVo
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public List<PaperDetailsDto> getPaperDetailsList(Integer skip, Integer limit,String searchValue, List<FilterOrSortingVo> filterVo,String view)
			throws ApplicationException {
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		valueListStringConversion(filterVo);
		UserInfo userInfo = getUserInfo();
		Integer companyId = userInfo.getCompanyId();
		if (ApplicationUtils.isNotValidId(companyId)
				&& !(userInfo.getUserTypeId().getUserTypeId().equals(ApplicationConstants.ONE))) {
			throw new ApplicationException(ErrorCodes.INVALID_ACTION);
		}
		Boolean parseBoolean=null;
		if(!view.equals(ApplicationConstants.NULL)) {
			parseBoolean= Boolean.parseBoolean(view);
		}
		 
		List<PaperDetails> paperDetailsList = iPaperDetailsDao.getPaperDetailsList(skip, limit,searchValue, filterVo, companyId,parseBoolean,null);
		List<PaperDetailsDto> paperDetailsListDto = convertEntityToDto(paperDetailsList, userInfo);
		return paperDetailsListDto;
	}

	/**
	 * @param paperDetailsList
	 * @param loggedInUser
	 * @return
	 * @throws ParseException 
	 */
	private List<PaperDetailsDto> convertEntityToDto(List<PaperDetails> paperDetailsList, UserInfo loggedInUser) {
		List<PaperDetailsDto> paperDetailsListDto = new ArrayList<>();
		for (PaperDetails paperDetails : paperDetailsList) {
			PaperDetailsDto paperDetailsDto = new PaperDetailsDto();
			paperDetailsDto.setPdDigiltaPaperId(paperDetails.getPdDigitalPaperId());
			paperDetailsDto.setPdPolicyNumber(paperDetails.getPdPolicyNumber());
			paperDetailsDto.setPdInsuredName(paperDetails.getPdInsuredName());
			paperDetailsDto.setVdRegistrationNumber(paperDetails.getVdRegistrationNumber());
			paperDetailsDto.setPdEffectiveFrom(paperDetails.getPdEffectiveFrom().toString());
			paperDetailsDto.setPdExpireDate(paperDetails.getPdExpireDate().toString());
			String dateString = paperDetails.getCreatedDate().toString();
			paperDetailsDto.setPdPhoneNumber(paperDetails.getPdPhoneNumber());
			paperDetailsDto.setCreatedDate(dateString);
			paperDetailsDto.setPdEffectiveFrom((ApplicationUtils.isValidateObject(paperDetails.getPdEffectiveFrom()))?paperDetails.getPdEffectiveFrom().toString():null);
			paperDetailsDto.setPdExpireDate((ApplicationUtils.isValidateObject(paperDetails.getPdExpireDate()))?paperDetails.getPdExpireDate().toString():null);
			paperDetailsDto.setStatus(PaperDetailsStatusEnum.getIdByName(paperDetails.getStatus()));
			paperDetailsDto.setIdentity(paperDetails.getIdentity());
			paperDetailsDto.setVdMake(paperDetails.getVdMake());
			paperDetailsDto.setVdModel(paperDetails.getVdModel());
			paperDetailsDto.setInsurer(loggedInUser.getCompanyName());
			paperDetailsDto.setVdUsage(paperDetails.getVdUsage());
			paperDetailsDto.setVdLicensedToCarry(paperDetails.getVdLicensedToCarry());
			paperDetailsDto.setVdChassis(paperDetails.getVdChassis());
			paperDetailsDto.setDigitalPaperId(paperDetails.getPaperId());
			paperDetailsDto.setPdEmailId(paperDetails.getPdEmailId());

			FileStorage file = iPaperDetailsDao.getPaperImageById(paperDetails.getPaperId(),
					ApplicationConstants.UPD_TYPE, ApplicationConstants.RP_TYPE);
			if(ApplicationUtils.isValidateObject(file)) {
				String fileDownloadUrl = environmentProperties.getDigitalPaperFilePath();
				paperDetailsDto.setFileURL(fileDownloadUrl + file.getUrl());
			}
			paperDetailsListDto.add(paperDetailsDto);
		}
		return paperDetailsListDto;
	}

	/**
	 * @param pageIdentity
	 * @param bulkUploadId
	 * @throws ApplicationException
	 * @return
	 */
	@Override
    public ArrayList<LinkedHashMap<String, Object>> getScratchDataInExcel(String pageIdentity, Integer bulkUploadId,HttpServletRequest request) throws ApplicationException {
        List<String> excelColumnList = iRestTemplateService.getMetaDataList(pageIdentity, request);
        excelColumnList.add(TableConstants.SCRATCH_ID);
        LinkedHashMap<String, String> metaDatasScratchTableColumnMap = getMetaDatasScratchTableColumnMap(excelColumnList);
        if (!ApplicationUtils.isValidId(bulkUploadId)) {
            throw new ApplicationException(ErrorCodes.INVALID_BULK_UPLOAD_ID);
        }
        List<Scratch> totalScratchListByByBulkId = scratchDao.getTotalScratchListByByBulkId(bulkUploadId);
        ArrayList<LinkedHashMap<String, Object>> excelDatalist = new ArrayList<>();
        for (Scratch scratch : totalScratchListByByBulkId) {
            LinkedHashMap<String, Object> hashmap = new LinkedHashMap<String, Object>();
            for (String columnName : excelColumnList) {
                Class<? extends Scratch> clazz = scratch.getClass();
                try {
                    java.lang.reflect.Field field = clazz.getDeclaredField(metaDatasScratchTableColumnMap.get(columnName));
                    field.setAccessible(true);
                    Object fieldValue = field.get(scratch);
                    hashmap.put(columnName, fieldValue);
                } catch (NoSuchFieldException e) {
                    e.printStackTrace();
                } catch (SecurityException e) {
                    e.printStackTrace();
                }catch (IllegalArgumentException | IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
            List<String> errorList = scratch.getBulkImportErrorTable().stream().map(BulkImportErrorTable::getErrorMessage).collect(Collectors.toList());
            List<String> errorFieldName = scratch.getBulkImportErrorTable().stream().map(BulkImportErrorTable::getFieldName).collect(Collectors.toList());
            hashmap.put(ApplicationConstants.ERROR_MESSAGE, errorList);
            hashmap.put(ApplicationConstants.ERROR_FIELDS, errorFieldName);
            excelDatalist.add(hashmap);
        }
        return excelDatalist;
    }

	/**
	 * @param data
	 * @return
	 */

	@Override
    public ResponseEntity<ByteArrayResource> excelDownload(ArrayList<LinkedHashMap<String, Object>> data){
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        HttpHeaders header = new HttpHeaders();
        try {
            List<String> keyList = new ArrayList<>();
            Workbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet(ApplicationConstants.ERROR_DATA);
            Row headerRow = sheet.createRow(0);
            Set<String> keySet = data.get(0).keySet();
            keyList = keySet.stream().collect(Collectors.toList());
            keyList.removeIf((x)->x.contains(TableConstants.SCRATCH_ID));
            for (int cellNum = 0; cellNum < keyList.size(); cellNum++) {
                if (!keyList.get(cellNum).equals(ApplicationConstants.ERROR_FIELDS) && !keyList.get(cellNum).equals(TableConstants.SCRATCH_ID)) {
                    headerRow.createCell(cellNum).setCellValue(keyList.get(cellNum));
                }
            }
            
            for (int rowNum = 0; rowNum < data.size(); rowNum++) {
                Row row = sheet.createRow(rowNum+1);
                LinkedHashMap<String, Object> rowData = data.get(rowNum);
                List<String> errorFieldLists = (List<String>)rowData.get(ApplicationConstants.ERROR_FIELDS);
                for (int cellNum = 0; cellNum < rowData.size()-1; cellNum++) {
                    Cell cell = row.createCell(cellNum);
                    rowData.get(keySet);
                    Object object = rowData.get(keyList.get(cellNum));
                    if (object instanceof List) {
                        if (!keyList.get(cellNum).equals(ApplicationConstants.ERROR_FIELDS)) {
                            StringBuilder errorMessageBuilder = new StringBuilder();
                            for (String str : (List<String>) object) {
                                errorMessageBuilder.append(" ").append(str);
                            }
                            String errorMessage = errorMessageBuilder.toString();
                            cell.setCellValue(errorMessage);
                        }
                    }else {
                        if (!keyList.get(cellNum).equalsIgnoreCase(TableConstants.SCRATCH_ID)) {
                            cell.setCellValue(object+"");
                            if (errorFieldLists.contains(keyList.get(cellNum))) {
                                 CellStyle style = workbook.createCellStyle();
                                 Font font = workbook.createFont();
                                 font.setColor(IndexedColors.RED.getIndex());
                                 style.setFont(font);
                                 cell.setCellStyle(style);
                             }
                        }
                    }
                }
            }
            workbook.write(stream);
            workbook.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        header.setContentType(new MediaType("application", "force-download"));
        header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ProductTemplate.pdf");
        return new ResponseEntity<>(new ByteArrayResource(stream.toByteArray()), header, HttpStatus.CREATED);
    }

	/**
	 * @param identity
	 * @return
	 * @throws ApplicationException
	 * @throws IOException
	 */
	@Override
	public String updateRevokeStatus(String identity) throws ApplicationException, IOException {
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		if (ApplicationUtils.isValidIdentity(identity)) {
			PaperDetails revokeData = iPaperDetailsDao.getRevokeStatusData(identity);
			updateRevoke(loggedInUser, revokeData);
		} else {
			throw new ApplicationException(ErrorCodes.INVALID_IDENTITY);
		}
		return ApplicationConstants.UPDATE_SUCESS;
	}

	/**
	 * ̥
	 *
	 * @param loggedInUser
	 * @param revokeData
	 * @throws ApplicationException
	 * @throws IOException
	 */
	private void updateRevoke(UserInfo loggedInUser, PaperDetails revokeData) throws ApplicationException, IOException {
		if (!revokeData.getStatus().equals(PaperDetailsStatusEnum.REVOKED.getStatusNameById())
				&& (!revokeData.getStatus().equals(PaperDetailsStatusEnum.EXPIRED.getStatusNameById()))) {
			revokeData.setStatus(PaperDetailsStatusEnum.REVOKED.getStatusNameById());
			revokeData.setModifiedBy(loggedInUser.getId());
			LocalDateTime dateTime = LocalDateTime.now();
			revokeData.setModifiedDate(dateTime);
			revokeData.setCancelledDate(dateTime);
			iPaperDetailsDao.updateStatusDao(revokeData);

			FileStorage file = iPaperDetailsDao.getPaperImageById(revokeData.getPaperId(),
					ApplicationConstants.UPD_TYPE, ApplicationConstants.RP_TYPE);
			if(ApplicationUtils.isValidateObject(file)) {
				Boolean isRevoked = paperGenerationUtils.revokeDigitalPaper(file.getUrl());
			}
		} else {
			throw new ApplicationException(ErrorCodes.INVALID_STATUS);
		}
	}

	/**
	 * @param identity
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public PaperDetailsDto getPaperDetailsData(String identity) throws ApplicationException {
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		PaperDetailsDto paperDetailsDto = convertEntityToDto(identity, loggedInUser);
		return paperDetailsDto;
	}

	/**
	 * @param identity
	 * @param loggedInUser
	 * @return
	 * @throws ApplicationException
	 */
	private PaperDetailsDto convertEntityToDto(String identity, UserInfo loggedInUser) throws ApplicationException {
		PaperDetails revokeData = iPaperDetailsDao.getRevokeStatusData(identity);
		PaperDetailsDto paperDetailsDto = new PaperDetailsDto();
		paperDetailsDto.setPdDigiltaPaperId(revokeData.getPdDigitalPaperId());
		paperDetailsDto.setPdInsuredName(revokeData.getPdInsuredName());
		paperDetailsDto.setCompanyId(revokeData.getCompanyId());
		paperDetailsDto.setPdPolicyNumber(revokeData.getPdPolicyNumber());
		paperDetailsDto.setPdEffectiveFrom(revokeData.getPdEffectiveFrom().toString());
		paperDetailsDto.setPdExpireDate(revokeData.getPdExpireDate().toString());
		paperDetailsDto.setPdPhoneNumber(revokeData.getPdPhoneNumber());
		paperDetailsDto.setPdEmailId(revokeData.getPdEmailId());
		paperDetailsDto.setVdRegistrationNumber(revokeData.getVdRegistrationNumber());
		paperDetailsDto.setVdChassis(revokeData.getVdChassis());
		paperDetailsDto.setVdLicensedToCarry(revokeData.getVdLicensedToCarry());
		paperDetailsDto.setVdMake(revokeData.getVdMake());
		paperDetailsDto.setVdModel(revokeData.getVdModel());
		paperDetailsDto.setVdUsage(revokeData.getVdUsage());
		paperDetailsDto.setStatus(PaperDetailsStatusEnum.getIdByName(revokeData.getStatus()));
		HashMap<Integer, String> companyList = digitalPaperCache.getCompanyList();
		paperDetailsDto.setInsurer(companyList.get(revokeData.getCompanyId()));
		paperDetailsDto.setCompanyName(companyList.get(revokeData.getCompanyId()));	
		paperDetailsDto.setCreatedDate(revokeData.getCreatedDate().toString());
		paperDetailsDto.setIdentity(revokeData.getIdentity());
		paperDetailsDto.setDigitalPaperId(revokeData.getPaperId());
		FileStorage file = iPaperDetailsDao.getPaperImageById(revokeData.getPaperId(),
				ApplicationConstants.UPD_TYPE, ApplicationConstants.RP_TYPE);
		if(ApplicationUtils.isValidateObject(file)) {
			String url = environmentProperties.getDigitalPaperFilePath() + file.getUrl();
			paperDetailsDto.setFileURL(url);
		}
		return paperDetailsDto;
	}

	/**
	 * @param pageIdentity
	 * @param bulkUploadId
	 * @throws ApplicationException
	 * @return
	 */
	@Override
	public ArrayList<LinkedHashMap<String, Object>> getSuccessTable (String pageIdentity,Integer bulkUploadId,List<FilterOrSortingVo> filterOrSortingVo,HttpServletRequest request,Integer skip,Integer limit) throws ApplicationException{

		List<String> fieldList = iRestTemplateService.getMetaDataList(pageIdentity,request);
		fieldList.add(TableConstants.SCRATCH_ID);

		List<String> entityColumnList = new ArrayList<String>();
		LinkedHashMap<String, String> metaDatasScratchTableColumnMap = getMetaDatasScratchTableColumnMap(fieldList);
		
		Set<Entry<String, String>> entrySet = metaDatasScratchTableColumnMap.entrySet();
		List<String> columnHeaderList = entrySet.stream().map(el->el.getKey()).collect(Collectors.toList());
		
		columnHeaderList.add(ApplicationConstants.ERROR_MESSAGE); // adding extra column header for getting error message
		
		entityColumnList = entrySet.stream().map(el->el.getValue()).collect(Collectors.toList());
		
		
		List<Object[]> scratchSuccessEntityByBulkId = scratchDao.getScratchEntityByBulkId(bulkUploadId,
				entityColumnList, Boolean.FALSE,filterOrSortingVo,skip,limit);
		ArrayList<LinkedHashMap<String, Object>> hashmapArrayList = new ArrayList<>();

		if (ApplicationUtils.isValidList(scratchSuccessEntityByBulkId)) {
			for (Object[] object : scratchSuccessEntityByBulkId) {
				LinkedHashMap<String, Object> hashmap = new LinkedHashMap<String, Object>();
				int index = ApplicationConstants.ZERO;
				for (String column : columnHeaderList) {
					if(index < object.length) {
						hashmap.put(column, object[index]);
					}

					index++;
				}
				hashmapArrayList.add(hashmap);
			}
		}

		return hashmapArrayList;

	}

	/**
	 * @param pageIdentity
	 * @param bulkUploadId
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public ArrayList<LinkedHashMap<String, Object>> getErrorTable(String pageIdentity, Integer bulkUploadId,List<FilterOrSortingVo> filterOrSortingVo, HttpServletRequest request, Integer skip, Integer limit) throws ApplicationException {

		List<String> fieldList = iRestTemplateService.getMetaDataList(pageIdentity,request);
		fieldList.add(TableConstants.IDENTITY);
		fieldList.add(TableConstants.SCRATCH_ID);

		List<String> entityColumnList = new ArrayList<String>();
		LinkedHashMap<String, String> metaDatasScratchTableColumnMap = getMetaDatasScratchTableColumnMap(fieldList);
		
		Set<Entry<String, String>> entrySet = metaDatasScratchTableColumnMap.entrySet();
		List<String> columnHeaderList = entrySet.stream().map(el->el.getKey()).collect(Collectors.toList());
		
		columnHeaderList.add(ApplicationConstants.ERROR_MESSAGE); // adding extra column header for getting error message
		
		entityColumnList = entrySet.stream().map(el->el.getValue()).collect(Collectors.toList());
		
		List<Object[]> scratchErrorEntityByBulkId = scratchDao.getScratchEntityByBulkId(bulkUploadId,
				entityColumnList,Boolean.TRUE,filterOrSortingVo,skip,limit);


		ArrayList<LinkedHashMap<String, Object>> hashmapArrayList = new ArrayList<>();

		if (ApplicationUtils.isValidList(scratchErrorEntityByBulkId)) {
			for (Object[] object : scratchErrorEntityByBulkId) {
				LinkedHashMap<String, Object> hashmap = new LinkedHashMap<String, Object>();
				List<BulkImportErrorTable> errorTableByScratchId = iPaperDetailsDao.getErrorTableByScratchId((Integer)object[object.length-1]);
				int index = 0;
				for (String column : columnHeaderList) {
					if (index < object.length) {
						hashmap.put(column, object[index]);
					}

					if(index==object.length && (column.equalsIgnoreCase(ApplicationConstants.ERROR_MESSAGE))) {
						List<String> errorMessages= new ArrayList<>();
						List<String> errorFields = new ArrayList<>();
						for(BulkImportErrorTable errorScratch:errorTableByScratchId)
						{
							errorMessages.add(errorScratch.getErrorMessage());
							errorFields.add(errorScratch.getFieldName());

						}
						hashmap.put(column, errorMessages);
						hashmap.put(ApplicationConstants.ERROR_FIELDS, errorFields);
					}
					index++;

				}
				hashmapArrayList.add(hashmap);
			}
		}

		return hashmapArrayList;

	}

	/**
	 * @param bulkUploadId
	 * @return
	 */

	@Override
	public Long getTotalRecords(Integer bulkUploadId) {

		Long scratchCountByBulkId = scratchDao.getTotalScratchCountByBulkId(bulkUploadId);

		return scratchCountByBulkId;
	}

	/**
	 * @param bulkUploadId
	 * @return
	 */
	@Override
	public Long getSuccessRecordsCount(Integer bulkUploadId) {
		Long scratchCountByBulkId = scratchDao.getScratchCountByBulkId(bulkUploadId,Boolean.FALSE);

		return scratchCountByBulkId;
	}

	/**
	 * @param bulkUploadId
	 * @return
	 */
	@Override
	public Long getErrorRecordsCount(Integer bulkUploadId) {

		Long scratchCountByBulkId = scratchDao.getScratchCountByBulkId(bulkUploadId,Boolean.TRUE);

		return scratchCountByBulkId;
	}

	/**
	 * Delete errorand scratch data.
	 *
	 * @param scratchId the scratch id
	 * @param scratchIdentity the scratch identity
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void deleteErrorandScratchData(Integer scratchId, String scratchIdentity) throws ApplicationException {

		UserInfo userInfo = loggedInUserContextHolder.getLoggedInUser();
		Integer id = userInfo.getId();

		Scratch scratchDataByIdentity = scratchDao.getScratchDataByIdentity(scratchIdentity);
		if(!ApplicationUtils.isValidateObject(scratchDataByIdentity)) {
			throw new ApplicationException(ErrorCodes.INVALID_IDENTITY);
		}

		List<BulkImportErrorTable> errorTableListByScratchId = iPaperDetailsDao.getErrorTableByScratchId(scratchId);

		if(!ApplicationUtils.isValidList(errorTableListByScratchId)) {
			throw new ApplicationException(ErrorCodes.INVALID_ID);
		}

		scratchDataByIdentity.setIsDeleted(true);
		scratchDataByIdentity.setModifiedDate(LocalDateTime.now());
		scratchDataByIdentity.setModifiedBy(id);

		List<BulkImportErrorTable> updatedErrorTableList= new ArrayList<BulkImportErrorTable>();

		for(BulkImportErrorTable errorTable: errorTableListByScratchId) {
			errorTable.setDeleted(true);
			errorTable.setModifiedDate(LocalDateTime.now());
			errorTable.setModifiedBy(id);
			updatedErrorTableList.add(errorTable);
		}
		scratchDao.deleteScratchData(scratchDataByIdentity);
		iPaperDetailsDao.deleteErrorData(updatedErrorTableList);

	}

	/**
	 * @param pageIdentity
	 * @param dowloadListVo
	 * @param request
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public ResponseEntity<ByteArrayResource> dowloadPaperDetails(List<String> downloadList,List<FilterOrSortingVo> filterVo,List<Integer> idList, String searchValue) throws ApplicationException {

		UserInfo userInfo = loggedInUserContextHolder.getLoggedInUser();
		Integer companyId = userInfo.getCompanyId();
		
		List<String> entityColumnList = getPaperDetailsEntityColumnList();

		Map<String, String> mapCoumnName = new HashMap<>();
		for (int i = 0; i < downloadList.size() && i < entityColumnList.size(); i++) {
			mapCoumnName.put(downloadList.get(i), entityColumnList.get(i));
		}
		List<String> selectEntityColumn = new ArrayList<>();
		for (String column : downloadList) {
			selectEntityColumn.add(mapCoumnName.get(column));
		}
		valueListStringConversion(filterVo);
		List<Object[]> getPaperDetailsData = iPaperDetailsDao.getPaperDetailsDataForDownload(selectEntityColumn,companyId, filterVo,idList, searchValue);

		ArrayList<LinkedHashMap<String, Object>> excelDataList = new ArrayList<LinkedHashMap<String, Object>>();

		if(ApplicationUtils.isValidateObject(getPaperDetailsData)) {
			for(Object[] paperDetails:getPaperDetailsData) {
				LinkedHashMap<String,Object> excelDataMap = new LinkedHashMap<String,Object>();
				int index=0;
				for(String list: downloadList) {
					if(index<paperDetails.length) {

						if(list.equalsIgnoreCase("Status")) {
							String idByName = PaperDetailsStatusEnum.getIdByName((Integer)paperDetails[index]);
							excelDataMap.put(list, idByName);

						}

						else {
							excelDataMap.put(list,paperDetails[index]);
						}
					}
					index++;
				}
				excelDataList.add(excelDataMap);
			}


	}

		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		HttpHeaders header = new HttpHeaders();

		try {
			List<String> keyList = new ArrayList<>();
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet(ApplicationConstants.REPORT_LOSS);
			XSSFRow headerRow = sheet.createRow((int) ApplicationConstants.ZERO);
			
			XSSFFont headerFont = workbook.createFont();
			headerFont.setBold(true);

			XSSFCellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);
			
			XSSFCellStyle style=workbook.createCellStyle();
			Font font = workbook.createFont();
			font.setColor(IndexedColors.RED.getIndex());
			style.setFont(font);

			int rowIndex = ApplicationConstants.ZERO;

			for (LinkedHashMap<String, Object> excelData : excelDataList) { // Iterated only for Extracting Header Columns
				Set<String> keys = excelData.keySet();
				keyList = keys.stream().collect(Collectors.toList());
				for (int i = ApplicationConstants.ZERO; i < keyList.size(); i++) {
					XSSFCell headerCell = headerRow.createCell(i);
					 String headerText =Character.toUpperCase(keyList.get(i).charAt(0)) + keyList.get(i).substring(1); // Capitalize the first letter
					 
					headerCell.setCellValue(headerText);
					headerCell.setCellStyle(headerCellStyle);
					
				}
			}

			for (HashMap<String, Object> excelData : excelDataList) {
				int columnIndex = ApplicationConstants.ZERO;
				XSSFRow row = sheet.createRow((int) rowIndex + 1);
				for (Entry<String, Object> entry : excelData.entrySet()) {

					XSSFCell cell = row.createCell(columnIndex);

					if( entry.getKey().equalsIgnoreCase(TableConstants.TAB_EFFECTIVE_FROM) || entry.getKey().equalsIgnoreCase(TableConstants.TAB_EFFECTIVE_TO)) {
						String object =excelData.get(entry.getKey()).toString();
						String dateStr = parseLocalDateTimeToFormattedDate(object);
						cell.setCellValue(dateStr);
					}

					else {

						cell.setCellValue((entry.getValue() != null) ? entry.getValue().toString()
								: ApplicationConstants.WITHOUT_SPACE);

					}
					columnIndex++;
				}
				rowIndex++;
			}


			header.setContentType(new MediaType("application", "force-download"));
			header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ProductTemplate.pdf");

			workbook.write(stream);
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>(new ByteArrayResource(stream.toByteArray()), header, HttpStatus.CREATED);
	}

	/**
	 * Parses the local date time to formatted date.
	 *
	 * @param object the object
	 * @return the string
	 * @throws ParseException the parse exception
	 */
	private String parseLocalDateTimeToFormattedDate(String object) throws ParseException {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
		Date date = dateFormat.parse(object);
		DateFormat formatter = new SimpleDateFormat(environmentProperties.getDateFormat());
		String dateStr = formatter.format(date);
		return dateStr;
	}

	/**
	 * @param pageIdentity
	 * @param request
	 * @return
	 * @throws ApplicationException
	 */
	@Override
	public List<String> getColumnNamesForDropdown(String pageIdentity,HttpServletRequest request) throws ApplicationException {
		List<String> fieldList = iRestTemplateService.getMetaDataList(pageIdentity, request);

	return fieldList;
	}

	/**
	 *@param paperId
	 */
	@Override
	public String getPaperDetailsByPaperId(Integer paperId) {
		String fileName = null;
		FileStorage file = iPaperDetailsDao.getPaperImageById(paperId, ApplicationConstants.UPD_TYPE,
				ApplicationConstants.RP_TYPE);
		if (ApplicationUtils.isValidateObject(file)) {
			fileName = file.getUrl();
		}
		return fileName;
	}

	/**
	 * Sample excel download.
	 *
	 * @param sampleFileColumns the sample file columns
	 * @return the response entity
	 */
	@Override
	public ResponseEntity<ByteArrayResource> sampleExcelDownload(List<String> sampleFileColumns) {
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		HttpHeaders header = new HttpHeaders();

		try {
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet(ApplicationConstants.REPORT_LOSS);
			XSSFRow headerRow = sheet.createRow((int) ApplicationConstants.ZERO);

			int rowIndex = ApplicationConstants.ZERO;

			for (String sampleFile : sampleFileColumns) { // Iterated only for Extracting Header Columns
				headerRow.createCell(rowIndex).setCellValue(sampleFile);
				rowIndex++;
			}

			header.setContentType(new MediaType("application", "force-download"));
			header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ProductTemplate.pdf");

			workbook.write(stream);
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>(new ByteArrayResource(stream.toByteArray()), header, HttpStatus.CREATED);
	}

	/**
	 * Save digital paper template.
	 *
	 * @param authorityId the authority id
	 * @param template the template
	 * @return the string
	 * @throws ApplicationException the application exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	public String saveDigitalPaperTemplate(Integer authorityId, String template)
			throws ApplicationException, IOException {

		if (ApplicationUtils.isValidString(template)) {

			String folderPath = dp_template_folder;
			String fileName = ApplicationConstants.FILE_NAME + authorityId + ".txt";

			File folder = new File(folderPath);
			if (folder.exists()) {

				String filePath = folderPath + File.separator + fileName;

				FileWriter writer = new FileWriter(filePath);
				writer.write("");
				writer.close();
			} else {

				folder.mkdirs();
				System.out.println("Folder created successfully.");
			}
			String filePath = folderPath + File.separator + fileName;

			FileWriter fileWriter = new FileWriter(filePath);
			fileWriter.write(template);
			fileWriter.close();

			FileStorage fileStorage = new FileStorage();
			fileStorage = iPaperDetailsDao.getPaperImageById(authorityId, ApplicationConstants.UPLOAD_TYPE,
					ApplicationConstants.REPORT_TYPE);

			if (ApplicationUtils.isValidateObject(fileStorage)) {
				fileStorage.setUrl("dp_template" + authorityId);
				fileStorage.setReferenceId(authorityId);

				iPaperDetailsDao.updateStorageData(fileStorage);
			} else {
				FileStorage storageData = new FileStorage();

				Date currentDate = new Date();
				storageData.setCreatedDate(currentDate.toString());
				storageData.setReferenceId(authorityId);
				storageData.setReportType(ApplicationConstants.REPORT_TYPE);
				storageData.setStorageType(ApplicationConstants.STORAGE_TYPE);
				storageData.setUploadType(ApplicationConstants.UPLOAD_TYPE);
				storageData.setUrl(ApplicationConstants.FILE_NAME + authorityId);

				iPaperDetailsDao.saveStorageData(storageData);
			}

		}
		return ApplicationConstants.SAVED_SUCCESS;
	}
	
	/**
	 * Gets the paper details entity column list.
	 *
	 * @return the paper details entity column list
	 */
	private List<String> getPaperDetailsEntityColumnList() {
		List<String> entityColumnList= new ArrayList<>();
		entityColumnList.add(TableConstants.PD_DIGITAL_PAPER_ID);
		entityColumnList.add(TableConstants.POLICY_NUMBER);
		entityColumnList.add(TableConstants.PD_INSURED_NAME);
		entityColumnList.add(TableConstants.REGISTRATION_NUMBER);
		entityColumnList.add(TableConstants.EFFECTIVE_START_DATE);
		entityColumnList.add(TableConstants.EXPIRY_DATE);
		entityColumnList.add(TableConstants.STATUS);
		entityColumnList.add(TableConstants.PD_PHONE_NUMBER);
		entityColumnList.add(TableConstants.PD_EMAIL_ID);
		entityColumnList.add(TableConstants.CHASIS_NUMBER);
		entityColumnList.add(TableConstants.PD_LICENCE_TO_CARRY);
		entityColumnList.add(TableConstants.PD_MAKE);
		entityColumnList.add(TableConstants.PD_MODEL);
		entityColumnList.add(TableConstants.PD_USAGE);
		return entityColumnList;
	}


	

	/**
	 * Gets the entity map.
	 *
	 * @return the entity map
	 */
	private LinkedHashMap<String,String> getEntityMap(){
		LinkedHashMap<String, String> fieldsEntityColumnMap = new LinkedHashMap<String,String>();
		fieldsEntityColumnMap.put(TableConstants.TAB_POLICY_NUMBER,TableConstants.POLICY_NUMBER);
		fieldsEntityColumnMap.put(TableConstants.TAB_INSURED_NAME, TableConstants.PD_INSURED_NAME);
		fieldsEntityColumnMap.put(TableConstants.PHONE_NO,TableConstants.PD_PHONE_NUMBER);
		fieldsEntityColumnMap.put(TableConstants.EMAIL_ID, TableConstants.PD_EMAIL_ID);
		fieldsEntityColumnMap.put(TableConstants.TAB_EFFECTIVE_FROM,TableConstants.EFFECTIVE_START_DATE);
		fieldsEntityColumnMap.put(TableConstants.TAB_EXPIRY_DATE,TableConstants.EXPIRY_DATE);
		fieldsEntityColumnMap.put(TableConstants.TAB_REGISTRATION_NO,TableConstants.REGISTRATION_NUMBER);
		fieldsEntityColumnMap.put(TableConstants.CHASSIS_NUMBER, TableConstants.CHASIS_NUMBER);
		fieldsEntityColumnMap.put(TableConstants.LICENSE_TO_CARRY, TableConstants.PD_LICENCE_TO_CARRY);
		fieldsEntityColumnMap.put(TableConstants.MAKE,TableConstants.PD_MAKE);
		fieldsEntityColumnMap.put(TableConstants.MODEL, TableConstants.PD_MODEL);
		fieldsEntityColumnMap.put(TableConstants.TAB_USAGE, TableConstants.PD_USAGE);
		fieldsEntityColumnMap.put(TableConstants.IDENTITY, TableConstants.IDENTITY);
		fieldsEntityColumnMap.put(TableConstants.SCRATCH_ID, TableConstants.SCRATCH_ID);
		return fieldsEntityColumnMap;
		
		
	}
	
	/*
	 * This is the method which returns the corresponding entity field name in dp_scratch 
	 * table of meta data's field.
	 * 
	 * If new fields are added at meta data in future, new 'entry' should be made in getEntityMap()
	 * method and also new column should be added in dp_scratch table.
	 */
	
	/**
	 * Gets the meta datas scratch table column map.
	 *
	 * @param fieldList the field list
	 * @return the meta datas scratch table column map
	 */
	private LinkedHashMap<String,String> getMetaDatasScratchTableColumnMap(List<String> fieldList){
		
		LinkedHashMap<String, String> metaDataFieldsEntityColumnMap = new LinkedHashMap<String,String>();
		LinkedHashMap<String, String> entityMap = getEntityMap();
		for (String field : fieldList) {
			if(entityMap.containsKey(field)) {
				metaDataFieldsEntityColumnMap.put(field, entityMap.get(field));
			}
		}
		
		return metaDataFieldsEntityColumnMap;		
	}

	/**
	 * Send mail for papers.
	 *
	 * @param searchValue the search value
	 * @param allSearchFilter the all search filter
	 * @return the string
	 * @throws ApplicationException the application exception
	 */
	@Override
	public String sendMailForPapers(String searchValue,AllSearchFilterDto allSearchFilter) throws ApplicationException {
		UserInfo userInfo = loggedInUserContextHolder.getLoggedInUser();
		Integer companyId = userInfo.getCompanyId();
		
		List<FilterOrSortingVo> filterVo;
		List<String> removableDigitalPaperIds;
		
		if(ApplicationUtils.isValidateObject(allSearchFilter)) {
			 removableDigitalPaperIds= allSearchFilter.getDigitalPaperIds();
			filterVo=allSearchFilter.getFilterOrSortingVos();
		}
		else {
			throw  new ApplicationException(ErrorCodes.INVALID_INPUT);
		}
		
		
		
		valueListStringConversion(filterVo);
		if (ApplicationUtils.isNotValidId(companyId)
				&& !(userInfo.getUserTypeId().getUserTypeId().equals(ApplicationConstants.ONE))) {
			throw new ApplicationException(ErrorCodes.INVALID_ACTION);
		}
		ExecutorService executorService = Executors.newFixedThreadPool(1);
		executorService.submit(() -> {
			try {
				sendEmailForAllPapers(searchValue, filterVo, userInfo, companyId,removableDigitalPaperIds);
				executorService.shutdown();

			} catch (ApplicationException e) {
				e.printStackTrace();
				executorService.shutdown();
			}
		});

		return ApplicationConstants.SUCCESS;
	}

	/**
	 * Send email for all papers.
	 *
	 * @param searchValue the search value
	 * @param filterVo the filter vo
	 * @param userInfo the user info
	 * @param companyId the company id
	 * @param removableDigitalPaperIds the removable digital paper ids
	 * @throws ApplicationException the application exception
	 */
	public void sendEmailForAllPapers(String searchValue, List<FilterOrSortingVo> filterVo, UserInfo userInfo,
			Integer companyId, List<String> removableDigitalPaperIds) throws ApplicationException {
		List<PaperDetails> paperDetailsList = iPaperDetailsDao.getPaperDetailsList(ApplicationConstants.ZERO, ApplicationConstants.ZERO,searchValue, filterVo, companyId,null,removableDigitalPaperIds);
		if(ApplicationUtils.isValidList(paperDetailsList)) {
			List<PaperDetailsDto> paperDetailsListDto = convertEntityToDto(paperDetailsList, userInfo);
			HashMap<Integer, String> companyList = DigitalPaperCache.getCompanyList();
			String companyName = companyList.get(companyId);
			emailServiceImpl.sendMailForDigitalPapers(paperDetailsListDto, companyName, companyList);
		}
	}

	/**
	 * Download all digital papers.
	 *
	 * @param searchValue the search value
	 * @param view the view
	 * @param allSearchFilterDto the all search filter dto
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	@Override
	public ResponseEntity<ByteArrayResource> downloadAllDigitalPapers(String searchValue, Boolean view, AllSearchFilterDto allSearchFilterDto) throws ApplicationException {
		
		UserInfo loggedInUser = loggedInUserContextHolder.getLoggedInUser();
		if(!ApplicationUtils.isValidObject(loggedInUser)) {
			throw new ApplicationException(ErrorCodes.INVALID_USER);
		}
		
		Integer companyId= loggedInUser.getCompanyId();
		
		List<FilterOrSortingVo> filterOrSortingVos;
		List<String> removableDigitalPaperIds;
		
		if(ApplicationUtils.isValidateObject(allSearchFilterDto)) {
			removableDigitalPaperIds=allSearchFilterDto.getDigitalPaperIds();
			filterOrSortingVos=allSearchFilterDto.getFilterOrSortingVos();
		}
		else {
			throw  new ApplicationException(ErrorCodes.INVALID_INPUT);
		}
		
		valueListStringConversion(filterOrSortingVos);
		
		List<PaperDetails> paperDetails=iPaperDetailsDao.getPaperDetailsListForAllPapersDownload(searchValue,filterOrSortingVos,removableDigitalPaperIds,view,companyId);
		
		ArrayList<LinkedHashMap<String,Object>> downloadDataList ;
		
		try {
			downloadDataList=convertPaperDetailsEntityToLinkedHashMapList(paperDetails);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ApplicationException(ErrorCodes.ERR_DATE_TYPE);
		}
		
		
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		HttpHeaders header = new HttpHeaders();

		try {
			List<String> keyList = new ArrayList<>();
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet(ApplicationConstants.PAPER_DETAILS);
			XSSFRow headerRow = sheet.createRow((int) ApplicationConstants.ZERO);
			
			XSSFFont headerFont = workbook.createFont();
			headerFont.setBold(true);

			XSSFCellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);
			
			XSSFCellStyle style=workbook.createCellStyle();
			Font font = workbook.createFont();
			font.setColor(IndexedColors.RED.getIndex());
			style.setFont(font);

			int rowIndex = ApplicationConstants.ZERO;
			
			LinkedHashMap<String, Object> downloadData = downloadDataList.get(0);
			Set<String> keySet = downloadData.keySet();
			keyList = keySet.stream().collect(Collectors.toList());
			for (int i = ApplicationConstants.ZERO; i < keySet.size(); i++) {
				XSSFCell headerCell = headerRow.createCell(i);
				headerCell.setCellValue(keyList.get(i));
				headerCell.setCellStyle(headerCellStyle);

			}


			for (LinkedHashMap<String, Object> excelData : downloadDataList) {
				int columnIndex = ApplicationConstants.ZERO;
				XSSFRow row = sheet.createRow((int) rowIndex + 1);
				for (Entry<String, Object> entry : excelData.entrySet()) {

					XSSFCell cell = row.createCell(columnIndex);
					cell.setCellValue((entry.getValue() != null) ? entry.getValue().toString()
								: ApplicationConstants.WITHOUT_SPACE);
					columnIndex++;
					}
				rowIndex++;
					
				}


			header.setContentType(new MediaType("application", "force-download"));
			header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ProductTemplate.pdf");

			workbook.write(stream);
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>(new ByteArrayResource(stream.toByteArray()), header, HttpStatus.CREATED);
		
	}

	/**
	 * Convert paper details entity to linked hash map list.
	 *
	 * @param paperDetails the paper details
	 * @return the array list
	 * @throws ParseException the parse exception
	 */
	private ArrayList<LinkedHashMap<String, Object>> convertPaperDetailsEntityToLinkedHashMapList(
			List<PaperDetails> paperDetails) throws ParseException {
		
		ArrayList<LinkedHashMap<String, Object>> downloadDataList = new ArrayList<LinkedHashMap<String, Object>>();
		
		for (PaperDetails paperDetail : paperDetails) {
			LinkedHashMap<String, Object> downloadData = new LinkedHashMap<String,Object>();
			
			downloadData.put(TableConstants.TAB_DIGITAL_NUMBER, paperDetail.getPdDigitalPaperId());
			downloadData.put(TableConstants.TAB_POLICY_NO, paperDetail.getPdPolicyNumber());
			downloadData.put(TableConstants.TAB_INSURED_NAME, paperDetail.getPdInsuredName());
			downloadData.put(TableConstants.TAB_REGISTRATION_NO,paperDetail.getVdRegistrationNumber() );
			downloadData.put(TableConstants.TAB_EFFECTIVE_FROM, parseLocalDateTimeToFormattedDate(paperDetail.getPdEffectiveFrom().toString()));
			downloadData.put(TableConstants.TAB_EXPIRY_DATE, parseLocalDateTimeToFormattedDate(paperDetail.getPdExpireDate().toString()));
			downloadData.put(TableConstants.TAB_STATUS, PaperDetailsStatusEnum.getIdByName(paperDetail.getStatus()));
			downloadDataList.add(downloadData);
			
		}
		
		return downloadDataList;
	}
}

