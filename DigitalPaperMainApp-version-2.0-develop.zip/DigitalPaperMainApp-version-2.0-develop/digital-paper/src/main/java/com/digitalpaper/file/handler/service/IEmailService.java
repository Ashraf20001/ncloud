package com.digitalpaper.file.handler.service;

import java.io.File;
import java.io.IOException;
import java.util.List;

import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.MailRequestDto;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;
import com.digitalpaper.transfer.object.dto.StockDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.fasterxml.jackson.core.JsonProcessingException;

import freemarker.template.TemplateException;

/**
 * The Interface IEmailService.
 */
public interface IEmailService {

	/**
	 * Sets the email part.
	 *
	 * @param paperDetailsDto the paper details dto
	 * @return the string
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws TemplateException the template exception
	 */
	String setEmailPart(List<PaperDetailsDto> paperDetailsDto) throws IOException, TemplateException;
	
	/**
	 * Sets the email for existing customer.
	 *
	 * @param paperDetails the paper details
	 * @return the string
	 * @throws JsonProcessingException the json processing exception
	 */
	String setEmailForExistingCustomer(PaperDetails paperDetails) throws JsonProcessingException;

	/**
	 * Send email throw kafka.
	 *
	 * @param request the request
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws TemplateException the template exception
	 */
	void sendEmailThrowKafka(MailRequestDto request) throws IOException, TemplateException;
	
	/**
	 * Sets the email for existing customer from bulk upload.
	 *
	 * @param paperDetails the paper details
	 * @param userDetails the user details
	 * @return the string
	 * @throws JsonProcessingException the json processing exception
	 */
	String setEmailForExistingCustomerFromBulkUpload(PaperDetails paperDetails, UserInfo userDetails) throws JsonProcessingException;

	/**
	 * Stock remainder mail.
	 *
	 * @param request the request
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws TemplateException the template exception
	 */
	void stockRemainderMail(StockDto request) throws IOException, TemplateException;
	
	/**
	 * Send email in customer portal.
	 *
	 * @param paperDetails the paper details
	 * @param imageFile the image file
	 * @throws ApplicationException the application exception
	 */
	public void sendEmailInCustomerPortal(PaperDetails paperDetails,File imageFile) throws ApplicationException;



}
