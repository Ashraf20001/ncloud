package com.digitalpaper.service;

import java.util.List;

import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.PurchaseOrderDto;
import com.digitalpaper.transfer.object.dto.StockNotificationDto;

/**
 * The Interface IStockNotificationSevice.
 */
public interface IStockNotificationSevice {

	/**
	 * Save notification.
	 *
	 * @param action the action
	 * @param stockDetails the stock details
	 * @throws ApplicationException the application exception
	 */
	void saveNotification(String action, PurchaseOrderDto stockDetails) throws ApplicationException;

	/**
	 * Gets the notification.
	 *
	 * @param skip the skip
	 * @param limit the limit
	 * @return the notification
	 * @throws ApplicationException the application exception
	 */
	List<StockNotificationDto> getNotification(Integer skip, Integer limit)throws ApplicationException;

	/**
	 * Gets the notification count.
	 *
	 * @return the notification count
	 */
	Long getNotificationCount();

	/**
	 * Update notification data.
	 *
	 * @param notificationId the notification id
	 */
	void updateNotificationData(Integer notificationId);

}
