package com.digitalpaper.daoImp;

import org.springframework.stereotype.Repository;

import com.digitalpaper.config.common.base.dao.BaseDao;
import com.digitalpaper.dao.ISequenceDao;

/**
 * The Class SequenceDaoImpl.
 */
@Repository
public class SequenceDaoImpl extends BaseDao implements ISequenceDao {

	
	/**
	 * Save sequence.
	 *
	 * @param obj the obj
	 * @return the int
	 */
	@Override
	public int saveSequence(Object obj) {
		int sequenceId=saveWithoutId(obj);
		return sequenceId;
	}

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
		
	}
}
