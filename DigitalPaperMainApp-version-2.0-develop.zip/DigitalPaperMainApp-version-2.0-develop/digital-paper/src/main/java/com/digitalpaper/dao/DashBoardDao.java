package com.digitalpaper.dao;

import java.time.LocalDateTime;
import java.util.List;

import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.AuthorityBarChartDto;
import com.digitalpaper.transfer.object.dto.DashBoardInputDto;
import com.digitalpaper.transfer.object.dto.DoughNutDto;
import com.digitalpaper.transfer.object.dto.MonthCountDto;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.entity.PaymentDetails;

/**
 * The Interface DashBoardDao.
 */
public interface DashBoardDao {
	
	/**
	 * Gets the expiry digital paper count in next month.
	 *
	 * @param startingDateTime the starting date time
	 * @param endingDateTime the ending date time
	 * @param companyId the company id
	 * @return the expiry digital paper count in next month
	 */
	Long getExpiryDigitalPaperCountInNextMonth(LocalDateTime startingDateTime, LocalDateTime endingDateTime, Integer companyId);

	/**
	 * Gets the paper generated count in cuurent month.
	 *
	 * @param currentMonthStartingDateTime the current month starting date time
	 * @param currentMonthsndingDateTime the current monthsnding date time
	 * @param companyId the company id
	 * @return the paper generated count in cuurent month
	 */
	Long getPaperGeneratedCountInCuurentMonth(LocalDateTime currentMonthStartingDateTime,
			LocalDateTime currentMonthsndingDateTime, Integer companyId);

	/**
	 * Gets the paper generate count based on month and company.
	 *
	 * @param companyId the company id
	 * @param startofLastSixMonth the startof last six month
	 * @param endOfLastSixMonth the end of last six month
	 * @return the paper generate count based on month and company
	 */
	List<MonthCountDto> getPaperGenerateCountBasedOnMonthAndCompany(Integer companyId ,LocalDateTime startofLastSixMonth, 
			LocalDateTime endOfLastSixMonth);

	/**
	 * @param isAssociation
	 * @param forExpiryDetails
	 * @param companyId
	 * @return
	 */
	public List<PaperDetails> getRecentAndExpiredPaperDetails(boolean isAssociation,boolean forExpiryDetails,Integer companyId, Integer allocationTypeId,DashBoardInputDto dashboardInputDto );
	
	/**
	 * @return
	 */
	public List<PaymentDetails> getAllCompaniesRecentTransaction(DashBoardInputDto dashboardInputDto);
	
	/**
	 * @param fromDate
	 * @param toDate
	 * @return
	 */
	public List<Object[]> getTopPurchaseCompanies(LocalDateTime fromDate,LocalDateTime toDate);

	/**
	 * @return
	 */
	public List<Integer> getPaymentCompanyIds();

	/**
	 * @return
	 */
	public List<Integer> getPaperDetailsCompanyIds();

	/**
	 * @param dashBoardInputDto
	 * @param companyId
	 * @param allocationUserTypeId 
	 * @return
	 */
	List<MonthCountDto> getCertificateIssuedCountByMonth(DashBoardInputDto dashBoardInputDto, Integer companyId, Integer allocationUserTypeId);

	/**
	 * @param companyNameMaping
	 * @param dashBoardInputDtoForAuthority
	 * @return
	 */
	List<AuthorityBarChartDto> getauthorityBarChartata(List<Integer> companyNameMaping,
			DashBoardInputDto dashBoardInputDtoForAuthority);
	
	 /**
 	 * Gets the status count.
 	 *
 	 * @param companyId the company id
 	 * @param isAssociation the is association
 	 * @param boardInputDto the board input dto
 	 * @param allocationUserType the allocation user type
 	 * @return the status count
 	 * @throws ApplicationException the application exception
 	 */
 	DoughNutDto getStatusCount(Integer companyId,boolean isAssociation , DashBoardInputDto boardInputDto,Integer allocationUserType) throws  ApplicationException;

	/**
	 * Gets the all companies bar chart.
	 *
	 * @param dashBoardInputDto the dash board input dto
	 * @param companyId the company id
	 * @return the all companies bar chart
	 */
	List<MonthCountDto> getAllCompaniesBarChart(DashBoardInputDto dashBoardInputDto, Integer companyId);

	/**
	 * Gets the all companies certificate issued count by month.
	 *
	 * @param dashBoardInputDto the dash board input dto
	 * @param companyId the company id
	 * @return the all companies certificate issued count by month
	 */
	List<MonthCountDto> getAllCompaniesCertificateIssuedCountByMonth(DashBoardInputDto dashBoardInputDto,
			Integer companyId);

	/**
	 * Gets the stock allocated by allocation user type.
	 *
	 * @param dashBoardInputDto the dash board input dto
	 * @param companyId the company id
	 * @param allocationUserType the allocation user type
	 * @return the stock allocated by allocation user type
	 */
	List<MonthCountDto> getStockAllocatedByAllocationUserType(DashBoardInputDto dashBoardInputDto, Integer companyId,
			Integer allocationUserType);

}
