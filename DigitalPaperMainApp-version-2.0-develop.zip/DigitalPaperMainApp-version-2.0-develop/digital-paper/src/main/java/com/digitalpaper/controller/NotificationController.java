package com.digitalpaper.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitalpaper.config.base.controller.BaseController;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.service.IStockNotificationSevice;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.StockNotificationDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class NotificationController.
 */
@RestController
public class NotificationController extends BaseController{

	/** The notification service. */
	@Autowired
	private IStockNotificationSevice notificationService;

	/**
	 * Gets the notification.
	 *
	 * @param skip the skip
	 * @param limit the limit
	 * @return the notification
	 */
	@ApiOperation(value = "Notification details",notes="Get Notification list",response=ApplicationResponse.class)
	@GetMapping("/get-notification")
	public ApplicationResponse getNotification(@ApiParam(value="Skip data count",required = true) @RequestParam(value = "skip") Integer skip,
		@ApiParam(value = "Limit data count",required = true)	@RequestParam(value="limit") Integer limit) {

		List<StockNotificationDto> dto  = new ArrayList<>();
		 try {
			dto= notificationService.getNotification(skip,limit);
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
		return getApplicationResponse(dto);
	}

	/**
	 * Gets the notification count.
	 *
	 * @return the notification count
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Notification count",notes="Get Notification count",response=ApplicationResponse.class)
	@GetMapping("/get-notification-Count")
	public ApplicationResponse getNotificationCount() throws ApplicationException{
	Long StockNotificationDto =	notificationService.getNotificationCount();
				return getApplicationResponse(StockNotificationDto);
		}
	
	/**
	 * Update notification.
	 *
	 * @param notificationId the notification id
	 * @throws ApplicationException the application exception
	 */
	@ApiOperation(value = "Notification update",notes="Updation Notification data")
	@PostMapping("/Update-notificationt")
	public void updateNotification(@ApiParam(value="Notification Id",required = true) @RequestBody Integer notificationId) throws ApplicationException{
		notificationService.updateNotificationData(notificationId);

		}

	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}


	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}


	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {

	}



}
