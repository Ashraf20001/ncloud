package com.digitalpaper.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.WordUtils;
import org.apache.poi.ss.usermodel.BuiltinFormats;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.digitalpaper.adapter.service.DataConverterFactory;
import com.digitalpaper.adapter.service.FieldClassMapper;
import com.digitalpaper.config.DigitalPaperCache;
import com.digitalpaper.config.property.EnvironmentProperties;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.constants.core.DataTypeConstantsDto;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.controller.SequenceEnum;
import com.digitalpaper.controller.SequenceGenerator;
import com.digitalpaper.dao.IPaperDetailsDao;
import com.digitalpaper.dao.IStockDao;
import com.digitalpaper.dao.PaperDetailsBulkUploadDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.exception.core.codes.ErrorId;
import com.digitalpaper.exception.core.codes.ErrorId.ErrorHint;
import com.digitalpaper.file.handler.service.IEmailService;
import com.digitalpaper.restemplate.service.IRestTemplateService;
import com.digitalpaper.restemplate.service.RestTemplateServiceImpl;
import com.digitalpaper.service.PaperDetailsBulkUploadService;
import com.digitalpaper.transfer.object.dto.BulkImportFieldValidationDto;
import com.digitalpaper.transfer.object.dto.BulkImportHistoryDto;
import com.digitalpaper.transfer.object.dto.BulkImportMapping;
import com.digitalpaper.transfer.object.dto.CustomerWithPassword;
import com.digitalpaper.transfer.object.dto.FieldDto;
import com.digitalpaper.transfer.object.dto.IConfigurable;
import com.digitalpaper.transfer.object.dto.MailRequestDto;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;
import com.digitalpaper.transfer.object.dto.ScratchDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.entity.BulkImportErrorTable;
import com.digitalpaper.transfer.object.entity.BulkRevokeErrorTable;
import com.digitalpaper.transfer.object.entity.Customer;
import com.digitalpaper.transfer.object.entity.FileStorage;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.entity.Scratch;
import com.digitalpaper.transfer.object.entity.Stock;
import com.digitalpaper.transfer.object.entity.StockPool;
import com.digitalpaper.transfer.object.enums.PaperStatusEnum;
import com.digitalpaper.utils.CommonUtils;
import com.digitalpaper.utils.EmailProducer;
import com.digitalpaper.utils.PaperGenerationUtils;
import com.digitalpaper.utils.core.ApplicationUtils;

import freemarker.template.Configuration;
import freemarker.template.TemplateException;

/**
 * @author CBT 12
 *
 */
@Service
public class PaperDetailsBulkUploadServiceImpl implements PaperDetailsBulkUploadService {

	/** The Constant SET. */
	public static final String SET = "set";

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(PaperDetailsBulkUploadServiceImpl.class);

	/**
	 * DataConverterFactory
	 */
	@Autowired
	private DataConverterFactory converterFactory;
	
	/**
	 * ModelMapper
	 */
	@Autowired
	private ModelMapper modelMapper;

	/** The email producer. */
	@Autowired
	private EmailProducer emailProducer;
	
	/**
	 * PaperDetailsBulkUploadDao
	 */
	@Autowired
	private PaperDetailsBulkUploadDao paperDetailsBulkUploadDao;

	/**
	 * FieldClassMapper
	 */
	@Autowired
	private FieldClassMapper fieldClassMapper;

	/**
	 * SequenceGenerator
	 */
	@Autowired
	private SequenceGenerator sequenceGenerator;

	/** The paper generation utils. */
	@Autowired
	private PaperGenerationUtils paperGenerationUtils;

	/** The i paper details dao. */
	@Autowired
	private IPaperDetailsDao iPaperDetailsDao;

	/** The rest template service impl. */
	@Autowired
	private RestTemplateServiceImpl restTemplateServiceImpl;

	/** The i rest template service. */
	@Autowired
	private IRestTemplateService iRestTemplateService;

	/** The environment properties. */
	@Autowired
	private EnvironmentProperties environmentProperties;

	/** The email service. */
	@Autowired
	private IEmailService emailService;

	/** The customer service impl. */
	@Autowired
	private CustomerServiceImpl customerServiceImpl;
	
	
	/** The stock dao. */
	@Autowired
	private IStockDao stockDao;
	
	/** The common utils. */
	@Autowired
	private CommonUtils commonUtils;
	
	/** The allocation type. */
	public static String ALLOCATION_TYPE = null;

	/** The dp compress folder. */
	@Value("${dpmainapp.dp-compress-folder-path}")
	private String dp_compress_folder;

	/** The Constant Template_Folder_Path. */
	public static final String Template_Folder_Path = "/Tempplate";
	
	/** The chassis or registration. */
	public static String CHASSIS_OR_REGISTRATION;
	

	/**
	 * @param validationDto
	 *
	 * method collects object from consumer and validates
	 * @throws ApplicationException
	 * @throws IOException
	 * @throws TemplateException
	 */
	@Override
	public void getExcelSheetReading(BulkImportFieldValidationDto validationDto, HttpServletRequest request) {
		logger.info("Bulk upload started");
		HashMap<String, String> systemPropertyVAlue = DigitalPaperCache.getSystemPropertyVAlue();
		ALLOCATION_TYPE = systemPropertyVAlue.get(ApplicationConstants.ALLOCATION_TYPE);

		List<List<FieldDto>> totalFieldList = new ArrayList<>();
		List<FieldDto> fieldList = new ArrayList<>(validationDto.getFieldList());
		List<Map<String, String>> mapList = validationDto.getMapList();
		for (Map<String, String> map : mapList) {
			List<FieldDto> fieldListCopy = new ArrayList<>();
			for (FieldDto fieldDto : fieldList) {
				FieldDto fieldDtoObj = new FieldDto();
				fieldDtoObj.setAliasName(fieldDto.getAliasName());
				fieldDtoObj.setColumnName(fieldDto.getColumnName());
				fieldDtoObj.setFieldName(fieldDto.getFieldName());
				fieldDtoObj.setFieldType(fieldDto.getFieldType());
				fieldDtoObj.setFieldId(fieldDto.getFieldId());
				fieldDtoObj.setMaxLength(fieldDto.getMaxLength());
				fieldDtoObj.setMinLength(fieldDto.getMinLength());
				fieldDtoObj.setRegex(fieldDto.getRegex());
				fieldDtoObj.setDefaultValues(fieldDto.getDefaultValues());
				fieldDtoObj.setMandatory(fieldDto.isMandatory());
				fieldDtoObj.setIsCoreData(fieldDto.getIsCoreData());
				String value = map.get(fieldDto.getFieldName());
				fieldDtoObj.setValue((ApplicationUtils.isValidString(value)) ? value.toString() : null);
				fieldListCopy.add(fieldDtoObj);
			}
			totalFieldList.add(fieldListCopy);
		}
		if (validationDto.getUploadAction().equals(ApplicationConstants.UPLOAD)) {
			try {
				validatePaperDetails(totalFieldList, validationDto, request);
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (validationDto.getUploadType().equals(ApplicationConstants.FLEET)
					&& Boolean.TRUE.equals(validationDto.getIsLastProcess())) {
				fileCompressMethod(validationDto);
			}
		} else {
			revokePaperDetails(totalFieldList, validationDto);
			validationDto.getBulkImportHistoryDto().setPoolId(validationDto.getUserInfo().getAllocationUserType());
			sendBulkImportHistoryDtoToUpdate(validationDto);
		}
	}

	/**
	 * File compress method.
	 *
	 * @param validationDto the validation dto
	 */
	private void fileCompressMethod(BulkImportFieldValidationDto validationDto) {
		String companyName = validationDto.getUserInfo().getCompanyName();

		String policyNumberObj = null;
		Integer i = 0;
		policyNumberObj = validationDto.getMapList().get(i).get(TableConstants.POLICY_NUMBER);
		List<FileStorage> getFileStorageData = new ArrayList<>();
		List<PaperDetails> paperDetailsList;
		try {
			paperDetailsList = paperDetailsBulkUploadDao.getPaperDetailsBasedOnPolicyNo(policyNumberObj);
			List<Integer> listOfId = paperDetailsList.stream().map(PaperDetails::getPaperId).toList();
			getFileStorageData = paperDetailsBulkUploadDao.getFileStorageDataByPaperId(listOfId);

		} catch (ApplicationException e) {
			e.printStackTrace();
		}

		List<String> fileNameList = new ArrayList<>();
		for (FileStorage storedFileData : getFileStorageData) {

			String url = environmentProperties.getFileUploadPath() + "/OG_IMAGE/" + storedFileData.getUrl();
			fileNameList.add(url);
		}

		if (ApplicationUtils.isValidateObject(fileNameList)) {

			String folderPath = dp_compress_folder;

			File folder = new File(folderPath);
			if (!folder.exists()) {

				folder.mkdirs();
				logger.info("Folder created successfully.");
			}

			String destinationFile = dp_compress_folder + "/" + policyNumberObj + "_compressed.zip";

			try {
				FileOutputStream fos = new FileOutputStream(destinationFile);
				ZipOutputStream zipOut = new ZipOutputStream(fos);

				for (String file : fileNameList) {
					File fileToZip = new File(file);
					FileInputStream fis = new FileInputStream(fileToZip);
					ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
					zipOut.putNextEntry(zipEntry);

					byte[] bytes = new byte[1024];
					int length;
					while ((length = fis.read(bytes)) >= 0) {
						zipOut.write(bytes, 0, length);
					}

					fis.close();
				}

				zipOut.close();
				fos.close();

				MailRequestDto request = new MailRequestDto();
				String toEmailId = validationDto.getMapList().get(i).get(TableConstants.PD_EMAIL_ID);
				String name = validationDto.getMapList().get(i).get(TableConstants.PD_INSURED_NAME);

				request.setFrom(environmentProperties.getSendEmailName());
				request.setName(companyName);
				request.setSubject(ApplicationConstants.EMAIL_SUB + policyNumberObj);
				request.setTo(toEmailId);
				File file = new File(destinationFile);

				request.setFileURL(file);

				Map<String, Object> model = new HashMap<>();
				model.put("Name", WordUtils.capitalize(name));
				model.put("policyNumber", policyNumberObj);
				model.put("CompanyName", WordUtils.capitalize(companyName));

				request.setModel(model);
				request.setAttachmentName("compressed_file.zip");
				request.setTemplateName(ApplicationConstants.DP_FEELT_TEMPLATE);

				emailProducer.sendEmail(request);

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}

	}

	/**
	 * @param totalFieldList
	 * @param validationDto
	 *
	 * method used for bulk revoke along with validation
	 */
	private void revokePaperDetails(List<List<FieldDto>> totalFieldList, BulkImportFieldValidationDto validationDto) {
		String policyNumber = validationDto.getMapList().get(0).get(TableConstants.POLICY_NUMBER);
		String policyNumberObj = null;
		Integer i = 0;
		for (List<FieldDto> list : totalFieldList) {
			for (FieldDto fieldDto : list) {
				try {
					if (fieldDto.getFieldName().equals(TableConstants.PD_DIGITAL_PAPER_ID)) {
						String paperId = validationDto.getMapList().get(i).get(TableConstants.PD_DIGITAL_PAPER_ID);
						policyNumberObj = validationDto.getMapList().get(i).get(TableConstants.POLICY_NUMBER);

						if (!ApplicationUtils.isValidString(paperId)) {
							ErrorId paperStatusError = new ErrorId("E7127", fieldDto.getAliasName() + ApplicationConstants.VALUE_EMPTY );
							throw new ApplicationException(paperStatusError);
						}

						PaperDetails paperDetails = paperDetailsBulkUploadDao.getPaperDetailsByDigitalPaperId(paperId);

						if (ApplicationUtils.isValidateObject(paperDetails)) {
							if (paperDetails.getStatus() != 1) {
								PaperStatusEnum paperStatusById = PaperStatusEnum
										.getPaperStatusById(paperDetails.getStatus());
								ErrorId paperStatusError = new ErrorId("E7136", ApplicationConstants.PAPER_ALREADY_IN
										+ paperStatusById.getPaperStatus() + ApplicationConstants.CONDITION);
								throw new ApplicationException(paperStatusError);
							}
							if (!policyNumberObj.equals(policyNumber)
									&& validationDto.getUploadType().equals(ApplicationConstants.FLEET)) {
								ErrorId paperStatusError = new ErrorId("E7137",
										ApplicationConstants.FLEET_POL_NO_MISMATCH);
								throw new ApplicationException(paperStatusError);
							}
							if (!policyNumberObj.equals(paperDetails.getPdPolicyNumber())) {
								ErrorId paperStatusError = new ErrorId("E7138", ApplicationConstants.POL_NO_MISMATCH);
								throw new ApplicationException(paperStatusError);
							}
							paperDetails.setStatus(3);
							paperDetails.setModifiedDate(LocalDateTime.now());
							paperDetails.setCancelledDate(LocalDateTime.now());
							paperDetailsBulkUploadDao.updateDigitalPaper(paperDetails);
							FileStorage file = iPaperDetailsDao.getPaperImageById(paperDetails.getPaperId(),
									ApplicationConstants.UPD_TYPE, ApplicationConstants.RP_TYPE);
							if (ApplicationUtils.isValidateObject(file)) {
								paperGenerationUtils.revokeDigitalPaper(file.getUrl());
							}
							String substringBetween = ApplicationConstants.PAPER_REVOKED;
							String success = ApplicationConstants.SUCCESS;
							BulkRevokeErrorTable errorTable = new BulkRevokeErrorTable();
							saveBulkRevokeErrorTable(fieldDto, validationDto, errorTable, substringBetween,
									paperDetails.getPdPolicyNumber(), success);
							updatePoolCountDetails(validationDto.getUserInfo(), validationDto, success);
							try {
								paperDetailsBulkUploadDao.saveBulkRevokeErrorTable(errorTable);
							} catch (ApplicationException e1) {
								e1.printStackTrace();
							}
						} else {
							ErrorId noPaperFound = new ErrorId("E7133", ApplicationConstants.NO_PAPER_FOUND);
							throw new ApplicationException(noPaperFound);
						}
					}
				} catch (Exception e) {
					System.err.println(e);
					String substringBetween = StringUtils.substringBetween(e.getMessage(),
							ApplicationConstants.STR_ERR_START, ApplicationConstants.STR_ERR_END);
					String fail = ApplicationConstants.FAILED;
					BulkRevokeErrorTable errorTable = new BulkRevokeErrorTable();
					saveBulkRevokeErrorTable(fieldDto, validationDto, errorTable, substringBetween, policyNumberObj,
							fail);
					updatePoolCountDetails(validationDto.getUserInfo(), validationDto, fail);
					try {
						paperDetailsBulkUploadDao.saveBulkRevokeErrorTable(errorTable);
					} catch (ApplicationException e1) {
						e1.printStackTrace();
					}
				}

			}
			i++;
		}
	}

	/**
	 * @param fieldDto
	 * @param validationDto
	 * @param errorTable
	 * @param substringBetween
	 *
	 *                         method saves bulk revoke success error data
	 */
	private void saveBulkRevokeErrorTable(FieldDto fieldDto, BulkImportFieldValidationDto validationDto,
			BulkRevokeErrorTable errorTable, String substringBetween, String policyNumber, String status) {
		errorTable.setDigitalPaperId(fieldDto.getValue());
		errorTable.setPolicyNumber(policyNumber);
		errorTable.setErrorMessage(substringBetween);
		errorTable.setBulkImportHistoryId(validationDto.getBulkImportHistoryDto().getUploadId());
		errorTable.setCreatedBy(validationDto.getUserInfo().getId());
		errorTable.setCreatedDate(LocalDateTime.now());
		errorTable.setStatus(status.equals(ApplicationConstants.SUCCESS) ? true : false);

	}

	/**
	 * @param totalFieldList
	 * @param validationDto
	 *
	 *                       method to validate bulk upload paper details
	 * @throws IOException
	 */
	private void validatePaperDetails(List<List<FieldDto>> totalFieldList, BulkImportFieldValidationDto validationDto,
			HttpServletRequest request) throws IOException {
		Class<?> scratch = ScratchDto.class;
		logger.info("validatePaperDetails() method started");
		for (List<FieldDto> list : totalFieldList) {
			IConfigurable object = getObject(scratch);
			for (FieldDto field : list) {
				if (!field.getFieldName().equals(TableConstants.PD_DIGITAL_PAPER_ID)) {

					String setMethodName = getSetMethodName(field.getFieldName());
					try {
						Method declaredMethod = scratch.getDeclaredMethod(setMethodName, String.class);
						declaredMethod.invoke(object, field.getValue());
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			String paperStatus = validateAndSavePaperDetails(list, object, validationDto, request);
		}
		validationDto.getBulkImportHistoryDto().setPoolId(validationDto.getUserInfo().getAllocationUserType());
		sendBulkImportHistoryDtoToUpdate(validationDto);
	}

	/**
	 * @param validationDto
	 * @return BulkImportHistoryDto
	 */
	private BulkImportHistoryDto sendBulkImportHistoryDtoToUpdate(BulkImportFieldValidationDto validationDto) {
		BulkImportHistoryDto sendBulkImportHistoryDtoToUpdate = restTemplateServiceImpl
				.sendBulkImportHistoryDtoToUpdate(validationDto);
		return sendBulkImportHistoryDtoToUpdate;

	}

	/**
	 * @param list
	 * @param configurableObject
	 * @param validationDto
	 * @param request
	 * @return
	 * @throws IOException
	 */
	private String validateAndSavePaperDetails(List<FieldDto> list, IConfigurable configurableObject,
			BulkImportFieldValidationDto validationDto, HttpServletRequest request) throws IOException {
		Class<?> paperDetails = PaperDetailsDto.class;
		IConfigurable object = getObject(paperDetails);
		String uploadType = validationDto.getUploadType();
		String policyNumber = validationDto.getMapList().get(0).get(TableConstants.POLICY_NUMBER);
		List<BulkImportErrorTable> bulkImportError = new ArrayList<>();
		Integer uploadId = validationDto.getBulkImportHistoryDto().getUploadId();
		UserInfo loggedInUser = validationDto.getUserInfo();
		for (FieldDto fieldDto : list) {
			try {
				if (!fieldDto.getFieldName().equals(TableConstants.PD_DIGITAL_PAPER_ID)) {

					if (!ApplicationUtils.isValidString(fieldDto.getValue())) {
						ErrorId paperStatusError = new ErrorId("E7127", fieldDto.getAliasName() + ApplicationConstants.VALUE_EMPTY );
						throw new ApplicationException(paperStatusError);
					}
					if (fieldDto.getFieldName().equals(TableConstants.POLICY_NUMBER)
							&& uploadType.equals(ApplicationConstants.FLEET)) {
						if (!policyNumber.equals(fieldDto.getValue())) {
							ErrorId invalidFleetEntry = new ErrorId("E7134",
									ApplicationConstants.INVALID_FLEET_UPLOAD + policyNumber);
							throw new ApplicationException(invalidFleetEntry);
						}
					}

					if (fieldDto.getFieldName().equals(TableConstants.EXPIRY_DATE)
							|| fieldDto.getFieldName().equals(TableConstants.EFFECTIVE_START_DATE)) {
						boolean validDateFormat = isValidDateFormat(fieldDto.getValue());
						if (Boolean.FALSE.equals(validDateFormat)) {
							throw new ApplicationException(ErrorCodes.ERR_DATE_TYPE);
						}
						LocalDateTime convertedTime = (LocalDateTime) convertDataType(fieldDto);
						int compareTo = convertedTime.toLocalDate().compareTo(LocalDateTime.now().toLocalDate());
						if (compareTo < 0 && !fieldDto.getFieldName().equals(TableConstants.EFFECTIVE_START_DATE)) {
							throw new ApplicationException(ErrorCodes.ERR_DATE_TYPE);
						}
					}

					else if (fieldDto.getFieldType().equals(DataTypeConstantsDto.INTEGER)) {
						try {
							Integer.parseInt(fieldDto.getValue());
						} catch (Exception e) {
							throw new ApplicationException(ErrorCodes.ERR_INTEGER_TYPE);
						}
					} else if (ApplicationUtils.isValidId(fieldDto.getMinLength()) && fieldDto.getValue().length() < fieldDto.getMinLength()) {
						throwMinLengthValidationException(fieldDto);
					} else if (ApplicationUtils.isValidId(fieldDto.getMaxLength()) && fieldDto.getValue().length() > fieldDto.getMaxLength()) {
						throwMaxLengthValidationException(fieldDto);
					}
					if (ApplicationUtils.isValidString(fieldDto.getRegex())) {
						boolean isPattern = Pattern.matches(fieldDto.getRegex(), fieldDto.getValue());
						if (!isPattern) {
							ErrorId errRegex = new ErrorId("E7134",
									ApplicationConstants.ERR_INVALID + fieldDto.getAliasName());
							throw new ApplicationException(errRegex);
						}
					}

					String setMethodName = null;
					Object convertDataType = null;
					Class<?> class1 = null;
					if (fieldDto.getFieldType().equals(DataTypeConstantsDto.PDATE)
							|| fieldDto.getFieldType().equals(DataTypeConstantsDto.FDATE)) {
						try {
							setMethodName = getSetMethodName(fieldDto.getFieldName());
							convertDataType = convertDataType(fieldDto).toString();
							String tempFieldType = DataTypeConstantsDto.STRING;
							class1 = fieldClassMapper.getClass(tempFieldType);
						} catch (Exception e) {
							throw new ApplicationException(ErrorCodes.ERR_DATE_TYPE);
						}
					} else {
						setMethodName = getSetMethodName(fieldDto.getFieldName());
						convertDataType = convertDataType(fieldDto);
						String tempFieldType = getTempFieldType(fieldDto.getFieldType());
						class1 = fieldClassMapper.getClass(tempFieldType);
					}

					try {
						Method declaredMethod = paperDetails.getDeclaredMethod(setMethodName, class1);
						declaredMethod.invoke(object, convertDataType);
					} catch (Exception e) {
						throw new ApplicationException(ErrorCodes.ERR_SAVING);
					}
					
					
					// Make Model and Usage Validation Starts
					
					try {
						if(fieldDto.getFieldName().equals(TableConstants.PD_MAKE)) {
							List<String> makes = DigitalPaperCache.getMakes();
							boolean noneMatchCheckOfMake = makes.stream().noneMatch(make->make.equalsIgnoreCase(fieldDto.getValue()));
							if(noneMatchCheckOfMake) {
								throwInvalidMakeModelUsageException(fieldDto.getAliasName());
							}
						}
					} catch (ApplicationException e) {
						BulkImportErrorTable errorTable = new BulkImportErrorTable();
						updateBulkErrorTableForOneObject(e, fieldDto, loggedInUser, errorTable, validationDto,
								TableConstants.PD_MAKE);
						bulkImportError.add(errorTable);
					}
					
					try {
						if(fieldDto.getFieldName().equals(TableConstants.PD_MODEL)) {
							List<String> models = DigitalPaperCache.getModels();
							boolean noneMatchCheckOfModel = models.stream().noneMatch(model->model.equalsIgnoreCase(fieldDto.getValue()));
							if(noneMatchCheckOfModel) {
								throwInvalidMakeModelUsageException(fieldDto.getAliasName());
							}
						}
					}catch(ApplicationException e) {
						BulkImportErrorTable errorTable = new BulkImportErrorTable();
						updateBulkErrorTableForOneObject(e, fieldDto, loggedInUser, errorTable, validationDto,
								TableConstants.PD_MODEL);
						bulkImportError.add(errorTable);
					}
					
					try {
						if(fieldDto.getFieldName().equals(TableConstants.PD_USAGE)) {
							List<String> usageList = DigitalPaperCache.getUsage();
							boolean noneMatchCheckOfUsage = usageList.stream().noneMatch(usage->usage.equalsIgnoreCase(fieldDto.getValue()));
							if(noneMatchCheckOfUsage) {
								throwInvalidMakeModelUsageException(fieldDto.getAliasName());
							}
						}
					} catch (ApplicationException e) {
						BulkImportErrorTable errorTable = new BulkImportErrorTable();
						updateBulkErrorTableForOneObject(e, fieldDto, loggedInUser, errorTable, validationDto,
								TableConstants.PD_USAGE);
						bulkImportError.add(errorTable);
					}
					
					
					
					
					
					
					
				}
				if (list.get(list.size() - 1).getFieldName().equals(fieldDto.getFieldName())) { // check for last
																								// columnName
					PaperDetailsDto digitalPaperDto = (PaperDetailsDto) object;
					try {

						if (Boolean.TRUE.equals(ApplicationUtils.isValidateObject(digitalPaperDto))
								&& uploadType.equals(ApplicationConstants.NORMAL)) {
							PaperDetails exisitingPaperWithPolicyNumber = paperDetailsBulkUploadDao
									.checkForDuplicatePolicyNumber(digitalPaperDto.getPdPolicyNumber(), PaperStatusEnum
											.getPaperStatusIdByName(ApplicationConstants.RLE_ACTIVE).getId());
							if (Boolean.TRUE
									.equals(ApplicationUtils.isValidateObject(exisitingPaperWithPolicyNumber))) {
								if (isDateOverlapped(exisitingPaperWithPolicyNumber, digitalPaperDto)) {
											throwInvalidPolicyNumberException(exisitingPaperWithPolicyNumber);
								}
							}
						}
					} catch (ApplicationException e) {
						BulkImportErrorTable errorTable = new BulkImportErrorTable();
						updateBulkErrorTableForOneObject(e, fieldDto, loggedInUser, errorTable, validationDto,
								TableConstants.POLICY_NUMBER);
						bulkImportError.add(errorTable);
					}
					
					try {
						List<PaperDetails> exisitingPaperListWithRegNoAndChassisNo = paperDetailsBulkUploadDao
								.checkDuplicateRegistrationNumberOrChassisNumber(
										digitalPaperDto.getVdRegistrationNumber().trim(), digitalPaperDto.getVdChassis().trim(), PaperStatusEnum
												.getPaperStatusIdByName(ApplicationConstants.RLE_ACTIVE).getId());
						if (Boolean.TRUE.equals(ApplicationUtils.isValidList(exisitingPaperListWithRegNoAndChassisNo))) {
							
							PaperDetails existingPaperWithRegAndChassisNo = exisitingPaperListWithRegNoAndChassisNo.get(ApplicationConstants.ZERO);
							if(existingPaperWithRegAndChassisNo.getVdChassis().equalsIgnoreCase(digitalPaperDto.getVdChassis().trim())) {
								CHASSIS_OR_REGISTRATION="";
								CHASSIS_OR_REGISTRATION=TableConstants.CHASIS_NUMBER;
								throwDuplicateChassisNumberException(existingPaperWithRegAndChassisNo);
							}
							if(existingPaperWithRegAndChassisNo.getVdChassis().equalsIgnoreCase(digitalPaperDto.getVdChassis().trim())
									&& isDateOverlapped(existingPaperWithRegAndChassisNo, digitalPaperDto)) {
								CHASSIS_OR_REGISTRATION="";
								CHASSIS_OR_REGISTRATION=TableConstants.CHASIS_NUMBER;
								throwDuplicateChassisNumberException(existingPaperWithRegAndChassisNo);
							}
								
							if(existingPaperWithRegAndChassisNo.getVdRegistrationNumber().equalsIgnoreCase(digitalPaperDto.getVdRegistrationNumber().trim())) {
								CHASSIS_OR_REGISTRATION="";
								CHASSIS_OR_REGISTRATION=TableConstants.REGISTRATION_NUMBER;
								throwInvalidRegistrationException(existingPaperWithRegAndChassisNo);
							}
							
							if(existingPaperWithRegAndChassisNo.getVdRegistrationNumber().equalsIgnoreCase(digitalPaperDto.getVdRegistrationNumber().trim())
							 && isDateOverlapped(existingPaperWithRegAndChassisNo, digitalPaperDto)) {
								CHASSIS_OR_REGISTRATION="";
								CHASSIS_OR_REGISTRATION=TableConstants.REGISTRATION_NUMBER;
								throwInvalidRegistrationException(existingPaperWithRegAndChassisNo);
							}
							
						}
					} catch (ApplicationException e) {
						BulkImportErrorTable errorTable = new BulkImportErrorTable();
						if(CHASSIS_OR_REGISTRATION.equalsIgnoreCase(TableConstants.REGISTRATION_NUMBER)) {
							updateBulkErrorTableForOneObject(e, fieldDto, loggedInUser, errorTable, validationDto,
									TableConstants.REGISTRATION_NUMBER);
						}
						else {
							updateBulkErrorTableForOneObject(e, fieldDto, loggedInUser, errorTable, validationDto,
									TableConstants.CHASIS_NUMBER);
						}
						bulkImportError.add(errorTable);
					}
					
					
					// Email validation starts
					
					List<PaperDetails> digitalPaperDataListByEmailId = paperDetailsBulkUploadDao.getDigitalPaperDataListByEmailId(digitalPaperDto.getPdEmailId(),loggedInUser.getCompanyId());
					if(ApplicationUtils.isValidList(digitalPaperDataListByEmailId) && uploadType.equals(ApplicationConstants.NORMAL)) {
						BulkImportErrorTable errorTable = new BulkImportErrorTable();
						updateBulkErrorTableForOneObject(new ApplicationException(ErrorCodes.EMAIL_EXIST), fieldDto, loggedInUser, errorTable, validationDto,
								TableConstants.PD_EMAIL_ID);
						bulkImportError.add(errorTable);
					}

				}

			} catch (ApplicationException e) {
				BulkImportErrorTable errorTable = new BulkImportErrorTable();
				updateBulkErrorTable(e, fieldDto, loggedInUser, errorTable, validationDto);
				bulkImportError.add(errorTable);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		Scratch scratchId ;
		if (!bulkImportError.isEmpty()) {
			String fail = ApplicationConstants.FAILED;
			 scratchId = saveScratchData(configurableObject, uploadId, loggedInUser, fail);
			for (BulkImportErrorTable bulkImportErrorTable : bulkImportError) {
				bulkImportErrorTable.setScratchId(scratchId);
				try {
					paperDetailsBulkUploadDao.saveBulkImportErrorData(bulkImportErrorTable);
				} catch (ApplicationException e) {
					e.printStackTrace();
				}
			}
			updatePoolCountDetails(loggedInUser, validationDto, fail);
			return ApplicationConstants.FAILED;
		} else {
			String success = ApplicationConstants.SUCCESS;
			PaperDetailsDto paperDetailsDto = (PaperDetailsDto) object;
			PaperDetails paperDetail = modelMapper.map(paperDetailsDto, PaperDetails.class);
			paperDetail.setPdEffectiveFrom(convertStringToLocalDateTime(paperDetailsDto.getPdEffectiveFrom()));
			paperDetail.setPdExpireDate(convertStringToLocalDateTime(paperDetailsDto.getPdExpireDate()));
			boolean savePaperDetails;
			try {
				 savePaperDetails = savePaperDetails(validationDto,paperDetail, loggedInUser, request);
			} catch (Exception e) {
				logger.info(e.toString());
				savePaperDetails = false;
				e.printStackTrace();
			}
			if (savePaperDetails) {
				scratchId = saveScratchData(configurableObject, uploadId, loggedInUser, success);
			} else {
				scratchId = saveScratchData(configurableObject, uploadId, loggedInUser, ApplicationConstants.FAILED);
			}
			if (!savePaperDetails) {
				BulkImportErrorTable bulkImportErrorTable = new BulkImportErrorTable();
				bulkImportErrorTable.setCreatedBy(loggedInUser.getId());
				bulkImportErrorTable.setCreatedDate(LocalDateTime.now());
				bulkImportErrorTable.setModifiedDate(LocalDateTime.now());
				bulkImportErrorTable.setModifiedBy(loggedInUser.getId());
				bulkImportErrorTable.setDeleted(false);
				bulkImportErrorTable.setErrorCleared(false);
				bulkImportErrorTable.setErrorMessage(ErrorCodes.INSUFFICIENT_STOCK.getErrorMessage()
						+ ApplicationConstants.SLASH + ApplicationConstants.PAPER_CREATION_FAILED);
				bulkImportErrorTable.setScratchId(scratchId);
				try {
					paperDetailsBulkUploadDao.saveBulkImportErrorData(bulkImportErrorTable);
				} catch (ApplicationException e) {
					logger.info(e.toString());
				}
				updatePoolCountDetails(loggedInUser, validationDto, ApplicationConstants.FAILED);
			} else {
				updatePoolCountDetails(loggedInUser, validationDto, success);
			}
			return ApplicationConstants.SUCCESS;
		}

	}

	/**
	 * Throw invalid make model usage exception.
	 *
	 * @param aliasName the alias name
	 * @throws ApplicationException the application exception
	 */
	private void throwInvalidMakeModelUsageException(String aliasName) throws ApplicationException {
		String errorMessage = ErrorCodes.INVALID_FORMAT.getErrorMessage().replace(
				ApplicationConstants.FIELD_FORMAT_HINT, aliasName);
		throw new ApplicationException(
				new ErrorId(ErrorCodes.INVALID_FORMAT.getErrorCode(), errorMessage));
		
	}

	/**
	 * @param loggedInUser
	 * @param validationDto
	 * @param status
	 */
	private void updatePoolCountDetails(UserInfo loggedInUser, BulkImportFieldValidationDto validationDto,
			String status) {
		BulkImportHistoryDto bulkImportHistoryDto = validationDto.getBulkImportHistoryDto();
		if (status.equals(ApplicationConstants.SUCCESS)) {
			bulkImportHistoryDto.setSuccessCount(bulkImportHistoryDto.getSuccessCount() + 1);
		} else {
			bulkImportHistoryDto.setFailureCount(bulkImportHistoryDto.getFailureCount() + 1);
		}
		bulkImportHistoryDto.setTotalCount(bulkImportHistoryDto.getTotalCount() + 1);
	}

	/**
	 * @param paperDetail
	 * @param loggedInUser
	 * @return
	 * @throws IOException 
	 * @throws ApplicationException 
	 */
	public boolean savePaperDetails(BulkImportFieldValidationDto validationDto, PaperDetails paperDetail,
			UserInfo loggedInUser, HttpServletRequest request) throws IOException, ApplicationException {

		logger.info("saving generate paper started");
			Integer savePaperDetails = 0;
			paperDetail.setIsDeleted(false);
			paperDetail.setStatus(1);
			paperDetail.setCreatedDate(LocalDateTime.now());
			paperDetail.setCreatedBy(loggedInUser.getId());
			paperDetail.setModifiedDate(LocalDateTime.now());
			paperDetail.setModifiedBy(loggedInUser.getId());
			paperDetail.setCompanyId(loggedInUser.getCompanyId());
			paperDetail.setAllocationUserTypeId(loggedInUser.getAllocationUserType());
			savePaperDetails = digitalPaperSave(paperDetail, loggedInUser, savePaperDetails, validationDto);

		return (savePaperDetails > 0) ? true : false;
	}

	/**
	 * Digital paper save.
	 *
	 * @param paperDetail the paper detail
	 * @param loggedInUser the logged in user
	 * @param savePaperDetails the save paper details
	 * @param validationDto the validation dto
	 * @return the integer
	 * @throws ApplicationException the application exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public  Integer digitalPaperSave(PaperDetails paperDetail, UserInfo loggedInUser, Integer savePaperDetails, BulkImportFieldValidationDto validationDto)
            throws ApplicationException, IOException {
		
        HashMap<String, String> systemValue = DigitalPaperCache.getSystemPropertyVAlue();
        if(ApplicationUtils.isValidateObject(systemValue)) {
            SequenceEnum.DIGITAL_PAPER_ID.setLength(systemValue.get(ApplicationConstants.PREFIX).length() + systemValue.get(ApplicationConstants.SUFFIX).length()); 
            SequenceEnum.DIGITAL_PAPER_ID.setPrefix(systemValue.get(ApplicationConstants.PREFIX));          
            try {
            	String digitalPaperId = sequenceGenerator.generateSequence(SequenceEnum.DIGITAL_PAPER_ID);
            	paperDetail.setPdDigitalPaperId(digitalPaperId); // sequence generator
			} catch (Exception e) {
				e.printStackTrace();
			}
        }
        logger.info("saving customer started");
        Customer customerByEmailId = paperDetailsBulkUploadDao.getCustomerByEmailId(paperDetail.getPdEmailId());
        Stock stock = new Stock();
        StockPool stockPool = new StockPool();
        if (ALLOCATION_TYPE.equals(ApplicationConstants.ALLOCATION_TYPE_2)) {
        	 stock = stockDao.getStockData(loggedInUser.getCompanyId());
        	 if (!ApplicationUtils.isValidateObject(stock)) {
 				throw new ApplicationException(ErrorCodes.INVALID_STOCK_POOL);
 			}
 			if (Boolean.FALSE.equals(stock.getStockCount()>stock.getUsedCount()) ) {
 				throw new ApplicationException(ErrorCodes.INSUFFICIENT_STOCK);
 			}
		}else if(ALLOCATION_TYPE.equals(ApplicationConstants.ALLOCATION_TYPE_1)){
			stockPool = paperDetailsBulkUploadDao.getStockPoolByAllocationId(loggedInUser.getCompanyId(),
					loggedInUser.getAllocationUserType());
			if (!ApplicationUtils.isValidateObject(stockPool)) {
				throw new ApplicationException(ErrorCodes.INVALID_STOCK_POOL);
			}
			if (Boolean.FALSE.equals(stockPool.getStockCount()>stockPool.getUsedCount()) ) {
				throw new ApplicationException(ErrorCodes.INSUFFICIENT_STOCK);
			}
		}
        
        
        if(ApplicationUtils.isValidateObject(customerByEmailId)) {
            paperDetail.setCustomer(customerByEmailId);
            logger.info("papger generation starts");
            	savePaperDetails = savePaperAndGeneratePaper(paperDetail, stock, stockPool,loggedInUser);
            if (validationDto.getUploadType().equals(ApplicationConstants.NORMAL)) {
                emailService.setEmailForExistingCustomerFromBulkUpload(paperDetail, loggedInUser);
            }
        }
        else {
            CustomerWithPassword saveCustomer = customerServiceImpl.saveCustomerFromBulkUpload(paperDetail,loggedInUser);
            paperDetail.setCustomer(saveCustomer.getCustomer());
            	savePaperDetails = savePaperAndGeneratePaper(paperDetail, stock, stockPool,loggedInUser);
            if (validationDto.getUploadType().equals(ApplicationConstants.NORMAL)) {
                customerServiceImpl.emailSendPart(loggedInUser.getCompanyName() ,paperDetail  ,paperDetail.getPaperId(),saveCustomer.getAutoPassword());
            }
        }
        return savePaperDetails;
    }
	
	/**
	 * Save paper and generate paper.
	 *
	 * @param paperDetail the paper detail
	 * @param stock the stock
	 * @param stockPool the stock pool
	 * @param loggedInUser the logged in user
	 * @return the integer
	 * @throws ApplicationException the application exception
	 */
	public Integer savePaperAndGeneratePaper(PaperDetails paperDetail, Stock stock, StockPool stockPool, UserInfo loggedInUser)
			throws ApplicationException {
		Integer savePaperDetails = 0;
		try {
			savePaperDetails = paperDetailsBulkUploadDao.savePaperDetails(paperDetail,stockPool,ALLOCATION_TYPE, stock);
			if (savePaperDetails == 0) {
			    throw new ApplicationException(ErrorCodes.ERR_SAVING);
			}
	         paperGenerationUtils.generateDigitalPaper(paperDetail,loggedInUser);
		} catch (Exception e) {
			logger.info(e.getLocalizedMessage());
			logger.info(e.toString());
			if (ApplicationUtils.isValidId(paperDetail.getPaperId())) {
				logger.info("paper deleted:-" + paperDetail.getPaperId());
				paperDetailsBulkUploadDao.deletePaperDetails(paperDetail);
				paperDetailsBulkUploadDao.retrieveStockCount(stockPool,ALLOCATION_TYPE, stock);
			}
			 throw new ApplicationException(ErrorCodes.PAPER_GENERATION_FAILED);
			 
		}
		
		return savePaperDetails;
	}
	
	
	/**
	 * @param e
	 * @param fieldDto
	 * @param loggedInUser
	 * @param errorTable
	 */
	private void updateBulkErrorTable(ApplicationException e, FieldDto fieldDto, UserInfo loggedInUser,
			BulkImportErrorTable errorTable, BulkImportFieldValidationDto validationDto) {
		List<BulkImportMapping> bulkImportMappingData = validationDto.getBulkImportMappingData();
		Map<String, String> mappingField = new HashMap<>();
		for (BulkImportMapping bulkImportMapping : bulkImportMappingData) {
			mappingField.put(bulkImportMapping.getBulkImportFieldName(), bulkImportMapping.getBulkImportAliasName());
		}
		String substringBetween = StringUtils.substringBetween(e.getMessage(), ApplicationConstants.STR_ERR_START,
				ApplicationConstants.STR_ERR_END);
		errorTable.setErrorMessage(substringBetween);
		errorTable.setFieldName(mappingField.get(fieldDto.getFieldName()));
		errorTable.setErrorCleared(false);
		errorTable.setCreatedDate(LocalDateTime.now());
		errorTable.setCreatedBy(loggedInUser.getId());
	}

	/**
	 * @param e
	 * @param fieldDto
	 * @param loggedInUser
	 * @param errorTable
	 * @param validationDto
	 * @param fieldName
	 */
	private void updateBulkErrorTableForOneObject(ApplicationException e, FieldDto fieldDto, UserInfo loggedInUser,
			BulkImportErrorTable errorTable, BulkImportFieldValidationDto validationDto, String fieldName) {
		List<BulkImportMapping> bulkImportMappingData = validationDto.getBulkImportMappingData();
		Map<String, String> mappingField = new HashMap<>();
		for (BulkImportMapping bulkImportMapping : bulkImportMappingData) {
			mappingField.put(bulkImportMapping.getBulkImportFieldName(), bulkImportMapping.getBulkImportAliasName());
		}
		String substringBetween = StringUtils.substringBetween(e.getMessage(), ApplicationConstants.STR_ERR_START,
				ApplicationConstants.STR_ERR_END);
		errorTable.setErrorMessage(substringBetween);
		errorTable.setFieldName(mappingField.get(fieldName));
		errorTable.setErrorCleared(false);
		errorTable.setCreatedDate(LocalDateTime.now());
		errorTable.setCreatedBy(loggedInUser.getId());
	}

	/**
	 * @param object
	 * @param uploadId
	 * @param loggedInUser
	 * @param status
	 * @return
	 */
	private Scratch saveScratchData(IConfigurable object, Integer uploadId, UserInfo loggedInUser, String status) {
		ScratchDto scratchDto = (ScratchDto) object;
		scratchDto.setCompanyId(loggedInUser.getCompanyId().toString());
		scratchDto.setBulkUploadId(uploadId);
		scratchDto.setStatus((status.equals(ApplicationConstants.SUCCESS)) ? true : false);
		Scratch scratch = new Scratch();
		scratch = mapScratchDtoToScratch(scratchDto, scratch, loggedInUser);
		Integer saveScratchData = 0;
		try {
			saveScratchData = paperDetailsBulkUploadDao.saveScratchData(scratch);
			scratch.setScratchId(saveScratchData);
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
		return scratch;
	}

	/**
	 * Map scratch dto to scratch.
	 *
	 * @param scratchDto the scratch dto
	 * @param scratch the scratch
	 * @param loggedInUser the logged in user
	 * @return the scratch
	 */
	private Scratch mapScratchDtoToScratch(ScratchDto scratchDto, Scratch scratch, UserInfo loggedInUser) {
		scratch.setBulkUploadId(scratchDto.getBulkUploadId());
		scratch.setCompanyId(scratchDto.getCompanyId());
		scratch.setCreatedBy(loggedInUser.getId());
		scratch.setCreatedDate(LocalDateTime.now());
		scratch.setPdEffectiveFrom(convertDate(scratchDto.getPdEffectiveFrom()));
		scratch.setPdEmailId(scratchDto.getPdEmailId());
		scratch.setPdExpireDate(convertDate(scratchDto.getPdExpireDate()));
		scratch.setPdInsuredName(scratchDto.getPdInsuredName());
		scratch.setPdPhoneNumber(scratchDto.getPdPhoneNumber());
		scratch.setPdPolicyNumber(scratchDto.getPdPolicyNumber());
		scratch.setStatus(scratchDto.getStatus());
		scratch.setVdChassis(scratchDto.getVdChassis());
		scratch.setVdLicensedToCarry(scratchDto.getVdLicensedToCarry());
		scratch.setVdMake(scratchDto.getVdMake());
		scratch.setVdModel(scratchDto.getVdModel());
		scratch.setVdRegistrationNumber(scratchDto.getVdRegistrationNumber());
		scratch.setVdUsage(scratchDto.getVdUsage());

		return scratch;

	}

	
	    /**
    	 * Convert date.
    	 *
    	 * @param inputDate the input date
    	 * @return the string
    	 */
    	public String convertDate(String inputDate) {
	    	if(ApplicationUtils.isValidString(inputDate)){
	    		
	    		String formattedDate = inputDate.replace('-', '/');
	    		return formattedDate;
	    	}
	    	return null;
	    }
	    
	/**
	 * @param fieldType
	 * @return
	 */
	private String getTempFieldType(String fieldType) {
		String temp = null;
		if (fieldType.equals(DataTypeConstantsDto.DROPDOWN) || fieldType.equals(DataTypeConstantsDto.STRING)
				|| fieldType.equals(DataTypeConstantsDto.TEXT) || fieldType.equals(DataTypeConstantsDto.MULTI_SELECT)
				|| fieldType.equals(DataTypeConstantsDto.DOWNLOAD) || fieldType.equals(DataTypeConstantsDto.FILE)) {
			temp = DataTypeConstantsDto.STRING;
		} else if (fieldType.equals(DataTypeConstantsDto.FDATE) || fieldType.equals(DataTypeConstantsDto.PDATE)) {
			temp = DataTypeConstantsDto.LOCAL_DATE_TIME;
		} else if (fieldType.equals(DataTypeConstantsDto.CHECKBOX) || fieldType.equals(DataTypeConstantsDto.TOGGLE)) {
			temp = DataTypeConstantsDto.BOOLEAN;
		} else if (fieldType.equals(DataTypeConstantsDto.LONG)) {
			temp = DataTypeConstantsDto.LONG;
		} else if (fieldType.equals(DataTypeConstantsDto.DOUBLE)) {
			temp = DataTypeConstantsDto.DOUBLE;
		} else if (fieldType.equals(DataTypeConstantsDto.INTEGER)) {
			temp = DataTypeConstantsDto.INTEGER;
		}
		return temp;
	}

	/**
	 * @param fieldDto
	 * @return
	 * @throws ApplicationException
	 */
	private Object convertDataType(FieldDto fieldDto) throws ApplicationException {
		String fieldType = fieldDto.getFieldType();
		String temp = getTempFieldType(fieldType);
		String fieldValue = (ApplicationUtils.isValidString(fieldDto.getValue())) ? fieldDto.getValue() : "0";
		Object convertedObject = null;
		if (temp != null && temp == DataTypeConstantsDto.LOCAL_DATE_TIME) {
			try {
				String[] split = fieldValue.split("[-/]+");
				if (split.length == 3) {
					fieldValue = split[2] + "-" + split[1] + "-" + split[0].concat("T00:00:00.000Z");
				}
				if(fieldDto.getFieldName().equals(TableConstants.EXPIRY_DATE) && split.length==3) {
					fieldValue = split[2] + "-" + split[1] + "-" + split[0].concat("T23:59:56.999Z");
				}
			} catch (Exception e) {
			}
		}
		convertedObject = converterFactory.dataConverter(fieldType, fieldValue);

		return convertedObject;
	}

	/**
	 * @param fieldName
	 * @return
	 */
	private String getSetMethodName(String fieldName) {
		String fieldName1 = fieldName.substring(0, 1).toUpperCase();
		String fieldName2 = fieldName.substring(1, fieldName.length());
		String setMethodName = "";
		setMethodName = SET + fieldName1 + fieldName2;
		return setMethodName;
	}

	/**
	 * Gets the object.
	 *
	 * @param className the class name
	 * @return the object
	 */
	public IConfigurable getObject(Class<?> className) {
		try {
			Object obj = className.getConstructor().newInstance();

			if (!(obj instanceof IConfigurable)) {
				throw new Exception("Invalid Configurable");
			}

			return (IConfigurable) obj;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	/**
	 * Bulk upload sample excel download.
	 *
	 * @param pageIdentity the page identity
	 * @param request the request
	 * @return the response entity
	 * @throws ApplicationException the application exception
	 */
	@Override
	public ResponseEntity<InputStreamResource> bulkUploadSampleExcelDownload(String pageIdentity,
			HttpServletRequest request) throws ApplicationException {
		List<String> metaDatas = iRestTemplateService.getMetaDataList(pageIdentity, request);

		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		HttpHeaders header = new HttpHeaders();

		try {
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet(ApplicationConstants.REPORT_LOSS);
			XSSFRow headerRow = sheet.createRow((int) ApplicationConstants.ZERO);
			XSSFCellStyle style = workbook.createCellStyle();
			style.setDataFormat((short) BuiltinFormats.getBuiltinFormat("text"));

			int rowIndex = ApplicationConstants.ZERO;

			for (String mapStr : metaDatas) { // Iterated only for Extracting Header Columns
				headerRow.createCell(rowIndex).setCellValue(mapStr);
				if (mapStr.equals("Effective From") || mapStr.equals("Expiry Date")) {
					sheet.setDefaultColumnStyle(metaDatas.indexOf(mapStr), style);
				}
				rowIndex++;
			}

			header.setContentType(new MediaType("application", "force-download"));
			header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ProductTemplate.pdf");

			workbook.write(stream);
			
			ByteArrayOutputStream fileOut = new ByteArrayOutputStream();
			String fileName = "Bulk-upload-sample.xlsx";
			workbook.write(fileOut);
			fileOut.close();
			workbook.close();
			
			ByteArrayInputStream in = new ByteArrayInputStream(fileOut.toByteArray());
			InputStreamResource file = new InputStreamResource(in);
			
			return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName)
					.contentType(MediaType.parseMediaType("application/vnd.ms-excel")).body(file);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null ;
	}

	/**
	 * @return
	 * @throws ApplicationException
	 */
	public boolean isDateOverlapped(PaperDetails exisitingPaper, PaperDetailsDto digitalPaperDto)
			throws ApplicationException {

		try {
			LocalDateTime commencingDate = convertStringToLocalDateTime(digitalPaperDto.getPdEffectiveFrom());
			LocalDateTime existingCommencingDate = exisitingPaper.getPdEffectiveFrom();
			LocalDateTime expiryDate = convertStringToLocalDateTime(digitalPaperDto.getPdExpireDate());
			LocalDateTime existingExpiryDate = exisitingPaper.getPdExpireDate();
			if (commencingDate.compareTo(existingCommencingDate) >= 0 // dates between existing dates
					&& expiryDate.compareTo(existingExpiryDate) <= 0
					|| commencingDate.compareTo(existingCommencingDate) <= 0 // past dates between existing dates
							&& expiryDate.compareTo(existingExpiryDate) <= 0
							&& expiryDate.compareTo(existingCommencingDate) >= 0
					|| commencingDate.compareTo(existingCommencingDate) >= 0 // future dates between existing dates
							&& expiryDate.compareTo(existingExpiryDate) >= 0
							&& commencingDate.compareTo(existingExpiryDate) <= 0
					|| commencingDate.compareTo(existingCommencingDate) <= 0 // existing dates between past and future
																				// date
							&& expiryDate.compareTo(existingExpiryDate) >= 0
					|| commencingDate.compareTo(existingCommencingDate) <= 0) {
				return true;
			}
		} catch (Exception e) {
			return false;
		}

		return false;
	}



	/**
	 * Convert string to local date time.
	 *
	 * @param dateTimeString the date time string
	 * @return the local date time
	 */
	public LocalDateTime convertStringToLocalDateTime(String dateTimeString) {
		DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
		LocalDateTime dateTime = LocalDateTime.parse(dateTimeString, formatter);
		return dateTime;
	}
	

	/**
	 * @param fieldDto
	 * @throws ApplicationException
	 */
	private void throwMinLengthValidationException(FieldDto fieldDto) throws ApplicationException {
		List<ErrorId.ErrorHint> errorHintsList = new ArrayList<ErrorId.ErrorHint>();
		errorHintsList.add(new ErrorHint(ApplicationConstants.MIN_LENGTH_HINT,fieldDto.getMinLength().toString()));
		errorHintsList.add(new ErrorHint(ApplicationConstants.ALIAS_NAME_HINT, fieldDto.getAliasName()));
		String errorMessage = ErrorCodes.MIN_LENGTH.getErrorMessage().replace(ApplicationConstants.MIN_LENGTH_HINT, fieldDto.getMinLength().toString())
							  .replace(ApplicationConstants.ALIAS_NAME_HINT, fieldDto.getAliasName());
		throw new ApplicationException(new ErrorId(ErrorCodes.MIN_LENGTH.getErrorCode(),
				errorMessage,errorHintsList));
	}
	
	/**
	 * @param fieldDto
	 * @throws ApplicationException
	 */
	private void throwMaxLengthValidationException(FieldDto fieldDto) throws ApplicationException {

		List<ErrorId.ErrorHint> errorHintsList = new ArrayList<ErrorId.ErrorHint>();
		errorHintsList.add(new ErrorHint(ApplicationConstants.FIELD_NAME_HINT,fieldDto.getAliasName()));
		String errorMessage = ErrorCodes.MAX_LENGTH.getErrorMessage().replace(ApplicationConstants.FIELD_NAME_HINT,fieldDto.getAliasName());
		throw new ApplicationException(new ErrorId(ErrorCodes.MAX_LENGTH.getErrorCode(), errorMessage, errorHintsList));
	}

	/**
	 * @param exisitingPaperWithPolicyNumber
	 * @throws ApplicationException
	 */
	private void throwInvalidPolicyNumberException(PaperDetails exisitingPaperWithPolicyNumber)
			throws ApplicationException {
		List<ErrorId.ErrorHint> errorHintsList = new ArrayList<ErrorId.ErrorHint>();
		errorHintsList.add(new ErrorHint(ApplicationConstants.DIGITAL_PAPER_HINT,
				exisitingPaperWithPolicyNumber.getPdDigitalPaperId()));
		String errorMessage = ErrorCodes.INVALID_POLCIY_NUMBER.getErrorMessage()
				.replace(ApplicationConstants.DIGITAL_PAPER_HINT, exisitingPaperWithPolicyNumber.getPdDigitalPaperId());
		throw new ApplicationException(
				new ErrorId(ErrorCodes.INVALID_POLCIY_NUMBER.getErrorCode(), errorMessage, errorHintsList));
	}
	
	/**
	 * @param exisitingPaperWithChassisNumber
	 * @throws ApplicationException
	 */
	private void throwDuplicateChassisNumberException(PaperDetails exisitingPaperWithChassisNumber)
			throws ApplicationException {
		List<ErrorId.ErrorHint> errorHintsList = new ArrayList<ErrorId.ErrorHint>();
		errorHintsList.add(new ErrorHint(ApplicationConstants.DIGITAL_PAPER_HINT,
				exisitingPaperWithChassisNumber.getPdDigitalPaperId()));
		String errorMessage = ErrorCodes.INVALID_CHASSIS_NUMBER.getErrorMessage()
				.replace(ApplicationConstants.DIGITAL_PAPER_HINT, exisitingPaperWithChassisNumber.getPdDigitalPaperId());
		throw new ApplicationException(
				new ErrorId(ErrorCodes.INVALID_CHASSIS_NUMBER.getErrorCode(), errorMessage, errorHintsList));
	}

	
	/**
	 * @param exisitingPaperWithRegNoAndChassisNo
	 * @throws ApplicationException
	 */
	private void throwInvalidRegistrationException(PaperDetails exisitingPaperWithRegNoAndChassisNo)
			throws ApplicationException {
		List<ErrorId.ErrorHint> errorHintsList = new ArrayList<ErrorId.ErrorHint>();
		errorHintsList.add(new ErrorHint(ApplicationConstants.DIGITAL_PAPER_HINT,
				exisitingPaperWithRegNoAndChassisNo.getPdDigitalPaperId()));
		String errorMessage = ErrorCodes.INVALID_REGISTRATION_NUMBER.getErrorMessage().replace(
				ApplicationConstants.DIGITAL_PAPER_HINT, exisitingPaperWithRegNoAndChassisNo.getPdDigitalPaperId());
		throw new ApplicationException(
				new ErrorId(ErrorCodes.INVALID_REGISTRATION_NUMBER.getErrorCode(), errorMessage, errorHintsList));

	}
	
	  /**
  	 * Checks if is valid date format.
  	 *
  	 * @param fieldDto the field dto
  	 * @return true, if is valid date format
  	 */
  	public static boolean isValidDateFormat(String fieldDto) {
	        String pattern = "^(0[1-9]|[1-2][0-9]|3[0-1])[/\\-](0[1-9]|1[0-2])[/\\-]\\d{4}$";
	        Pattern datePattern = Pattern.compile(pattern);
	        Matcher matcher = datePattern.matcher(fieldDto);
	        return matcher.matches();
	    }

	/**
	 * Validate stock count availability.
	 *
	 * @param userinfo the userinfo
	 * @return the boolean
	 * @throws ApplicationException the application exception
	 */
	@SuppressWarnings("finally")
	@Override
	public Boolean validateStockCountAvailability(UserInfo userinfo) throws ApplicationException {
		Boolean isErrorThrown=false;
		try {
			commonUtils.validateStockCountAvailability(userinfo);
		} catch (Exception e) {
			isErrorThrown=true;
			e.printStackTrace();
		}
		finally {
			return isErrorThrown;
		}
	}

}
