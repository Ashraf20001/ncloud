-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: digital_paper
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `complaints`
--

DROP TABLE IF EXISTS `complaints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `complaints` (
  `complaint_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `email_id` varchar(50) DEFAULT NULL,
  `date_of_incident` timestamp NULL DEFAULT NULL,
  `compliant_type` varchar(45) DEFAULT NULL,
  `remarks` varchar(100) DEFAULT NULL,
  `identity` varchar(150) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `modified_by` int DEFAULT NULL,
  PRIMARY KEY (`complaint_id`),
  UNIQUE KEY `identity_UNIQUE` (`identity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `digital_certificate_details`
--

DROP TABLE IF EXISTS `digital_certificate_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `digital_certificate_details` (
  `certificate_id` bigint NOT NULL AUTO_INCREMENT,
  `certificate_no` varchar(45) DEFAULT NULL,
  `policy_holder` varchar(45) DEFAULT NULL,
  `policy_no` varchar(45) DEFAULT NULL,
  `registration_no` varchar(50) DEFAULT NULL,
  `chassis_no` varchar(45) DEFAULT NULL,
  `insurer_name` varchar(45) DEFAULT NULL,
  `usage` varchar(45) DEFAULT NULL,
  `license_to_carry` int DEFAULT NULL,
  `mark_type` varchar(45) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `modified_by` int DEFAULT NULL,
  `identity` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`certificate_id`),
  UNIQUE KEY `identity_UNIQUE` (`identity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `digital_paper_details`
--

DROP TABLE IF EXISTS `digital_paper_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `digital_paper_details` (
  `paper_id` bigint NOT NULL AUTO_INCREMENT,
  `paper_no` varchar(45) DEFAULT NULL,
  `certificate_id` bigint DEFAULT NULL,
  `storage_id` bigint DEFAULT NULL,
  `company_id` bigint DEFAULT NULL,
  `stock_pool_id` bigint DEFAULT NULL,
  `paper_lot_id` bigint DEFAULT NULL,
  `effective_start_date` timestamp NULL DEFAULT NULL,
  `expiry_date` timestamp NULL DEFAULT NULL,
  `cancelled_date` timestamp NULL DEFAULT NULL,
  `identity` varchar(150) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `modified_by` int DEFAULT NULL,
  PRIMARY KEY (`paper_id`),
  UNIQUE KEY `identity_UNIQUE` (`identity`),
  KEY `paper_certificate_id_idx` (`certificate_id`),
  KEY `paper_storage_id_idx` (`storage_id`),
  KEY `paper_stackpool_id_idx` (`stock_pool_id`),
  KEY `paper_paper_lot_fk_idx` (`paper_lot_id`),
  CONSTRAINT `paper_certificate_id` FOREIGN KEY (`certificate_id`) REFERENCES `digital_certificate_details` (`certificate_id`),
  CONSTRAINT `paper_paper_lot_fk` FOREIGN KEY (`paper_lot_id`) REFERENCES `paper_generation_lot` (`paper_lot_id`),
  CONSTRAINT `paper_stackpool_id` FOREIGN KEY (`stock_pool_id`) REFERENCES `stock_pool` (`stock_pool_id`),
  CONSTRAINT `paper_storage_id` FOREIGN KEY (`storage_id`) REFERENCES `storage_details` (`storage_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dp_scratch`
--

DROP TABLE IF EXISTS `dp_scratch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dp_scratch` (
  `scratch_id` bigint NOT NULL AUTO_INCREMENT,
  `policy_holder` varchar(45) DEFAULT NULL,
  `policy_no` varchar(45) DEFAULT NULL,
  `registration_no` varchar(45) DEFAULT NULL,
  `chassis_no` varchar(45) DEFAULT NULL,
  `insurer_name` varchar(45) DEFAULT NULL,
  `usage` varchar(45) DEFAULT NULL,
  `license_to_carry` int DEFAULT NULL,
  `mark_type` varchar(45) DEFAULT NULL,
  `company_id` bigint DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `identity` varchar(150) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `modified_by` int DEFAULT NULL,
  PRIMARY KEY (`scratch_id`),
  UNIQUE KEY `identity_UNIQUE` (`identity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `error_table`
--

DROP TABLE IF EXISTS `error_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `error_table` (
  `error_id` bigint NOT NULL AUTO_INCREMENT,
  `scratch_id` bigint DEFAULT NULL,
  `field_name` varchar(45) DEFAULT NULL,
  `error_message` varchar(200) DEFAULT NULL,
  `is_err_cleared` tinyint(1) DEFAULT NULL,
  `identity` varchar(150) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `modified_by` int DEFAULT NULL,
  PRIMARY KEY (`error_id`),
  UNIQUE KEY `identity_UNIQUE` (`identity`),
  KEY `error_scratch_fk_idx` (`scratch_id`),
  CONSTRAINT `error_scratch_fk` FOREIGN KEY (`scratch_id`) REFERENCES `dp_scratch` (`scratch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paper_generation_lot`
--

DROP TABLE IF EXISTS `paper_generation_lot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paper_generation_lot` (
  `paper_lot_id` bigint NOT NULL AUTO_INCREMENT,
  `generated_count` bigint DEFAULT NULL,
  `generated_date` timestamp NULL DEFAULT NULL,
  `generated_by` int DEFAULT NULL,
  `paper_type` varchar(45) DEFAULT NULL,
  `stock_pool_id` bigint DEFAULT NULL,
  `source` varchar(45) DEFAULT NULL,
  `identity` varchar(150) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `modified_by` int DEFAULT NULL,
  PRIMARY KEY (`paper_lot_id`),
  UNIQUE KEY `identity_UNIQUE` (`identity`),
  KEY `stock_generation_pool_fk_idx` (`stock_pool_id`),
  CONSTRAINT `stock_generation_pool_fk` FOREIGN KEY (`stock_pool_id`) REFERENCES `stock_pool` (`stock_pool_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payment_details`
--

DROP TABLE IF EXISTS `payment_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_details` (
  `payment_id` bigint NOT NULL AUTO_INCREMENT,
  `order_id` bigint DEFAULT NULL,
  `payment_date` timestamp NULL DEFAULT NULL,
  `payment_mode` varchar(50) DEFAULT NULL,
  `paid_amount` bigint DEFAULT NULL,
  `payment_status` int DEFAULT NULL,
  `transaction_id` varchar(45) DEFAULT NULL,
  `identity` varchar(150) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `modified_by` int DEFAULT NULL,
  PRIMARY KEY (`payment_id`),
  UNIQUE KEY `identity_UNIQUE` (`identity`),
  UNIQUE KEY `transaction_id_UNIQUE` (`transaction_id`),
  KEY `payment_order_id_fk_idx` (`order_id`),
  CONSTRAINT `payment_order_id_fk` FOREIGN KEY (`order_id`) REFERENCES `purchase_order` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `purchase_order`
--

DROP TABLE IF EXISTS `purchase_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_order` (
  `order_id` bigint NOT NULL AUTO_INCREMENT,
  `order_no` varchar(45) DEFAULT NULL,
  `stock_count` bigint DEFAULT NULL,
  `purchase_date` timestamp NULL DEFAULT NULL,
  `company_id` bigint DEFAULT NULL,
  `order_status` int DEFAULT NULL,
  `purchase_id` varchar(45) DEFAULT NULL,
  `order_amt` bigint DEFAULT NULL,
  `identity` varchar(150) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `modified_by` int DEFAULT NULL,
  `payment_method` int DEFAULT NULL,
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `identity_UNIQUE` (`identity`),
  UNIQUE KEY `order_id_UNIQUE` (`purchase_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reports` (
  `report_id` bigint NOT NULL AUTO_INCREMENT,
  `report_name` varchar(45) DEFAULT NULL,
  `from_date` timestamp NULL DEFAULT NULL,
  `to_date` timestamp NULL DEFAULT NULL,
  `report_type` int DEFAULT NULL,
  `file_type` int DEFAULT NULL,
  `total_columns` int DEFAULT NULL,
  `identity` varchar(150) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `modified_by` int DEFAULT NULL,
  PRIMARY KEY (`report_id`),
  UNIQUE KEY `identity_UNIQUE` (`identity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reports_column_mapping`
--

DROP TABLE IF EXISTS `reports_column_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reports_column_mapping` (
  `reports_column_mapping_id` bigint NOT NULL AUTO_INCREMENT,
  `report_id` bigint DEFAULT NULL,
  `column_name` varchar(50) DEFAULT NULL,
  `order` int DEFAULT NULL,
  `identity` varchar(150) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `modified_by` int DEFAULT NULL,
  PRIMARY KEY (`reports_column_mapping_id`),
  UNIQUE KEY `identity_UNIQUE` (`identity`),
  KEY `reports_id_fkk_idx` (`report_id`),
  CONSTRAINT `reports_id_fkk` FOREIGN KEY (`report_id`) REFERENCES `reports` (`report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stock`
--

DROP TABLE IF EXISTS `stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock` (
  `stock_id` bigint NOT NULL AUTO_INCREMENT,
  `stock_count` bigint DEFAULT NULL,
  `used_count` bigint DEFAULT NULL,
  `company_id` bigint DEFAULT NULL,
  `identity` varchar(150) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `modified_by` int DEFAULT NULL,
  PRIMARY KEY (`stock_id`),
  UNIQUE KEY `identity_UNIQUE` (`identity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stock_notification`
--

DROP TABLE IF EXISTS `stock_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_notification` (
  `notification_id` int NOT NULL AUTO_INCREMENT,
  `notification_message` varchar(500) DEFAULT NULL,
  `acted_by` int DEFAULT NULL,
  `to_notify` int DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT NULL,
  `identity` varchar(150) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `modified_by` int DEFAULT NULL,
  PRIMARY KEY (`notification_id`),
  UNIQUE KEY `identity_UNIQUE` (`identity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stock_pool`
--

DROP TABLE IF EXISTS `stock_pool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_pool` (
  `stock_pool_id` bigint NOT NULL AUTO_INCREMENT,
  `stock_count` bigint DEFAULT NULL,
  `used_count` bigint DEFAULT NULL,
  `company_id` bigint DEFAULT NULL,
  `stock_id` bigint DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `modified_by` int DEFAULT NULL,
  `identity` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`stock_pool_id`),
  UNIQUE KEY `identity_UNIQUE` (`identity`),
  KEY `stock_id_fk_idx` (`stock_id`),
  CONSTRAINT `stock_id_fk` FOREIGN KEY (`stock_id`) REFERENCES `stock` (`stock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stock_pool_history`
--

DROP TABLE IF EXISTS `stock_pool_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_pool_history` (
  `pool_history_id` int NOT NULL,
  `stock_count` bigint DEFAULT NULL,
  `used_count` bigint DEFAULT NULL,
  `company_id` bigint DEFAULT NULL,
  `stock_id` bigint DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `modified_by` int DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `identity` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`pool_history_id`),
  UNIQUE KEY `identity_UNIQUE` (`identity`),
  KEY `history_stock_fk_idx` (`stock_id`),
  CONSTRAINT `history_stock_fk` FOREIGN KEY (`stock_id`) REFERENCES `stock` (`stock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stock_pool_mapping`
--

DROP TABLE IF EXISTS `stock_pool_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_pool_mapping` (
  `pool_mapping_id` bigint NOT NULL AUTO_INCREMENT,
  `pool_owner` int DEFAULT NULL,
  `stock_pool_id` bigint DEFAULT NULL,
  `company_id` bigint DEFAULT NULL,
  `allocated_date` timestamp NULL DEFAULT NULL,
  `allocated_by` int DEFAULT NULL,
  `identity` varchar(150) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `modified_by` int DEFAULT NULL,
  PRIMARY KEY (`pool_mapping_id`),
  UNIQUE KEY `identity_UNIQUE` (`identity`),
  KEY `stock_pool_id_fk_idx` (`stock_pool_id`),
  CONSTRAINT `stock_pool_id_fk` FOREIGN KEY (`stock_pool_id`) REFERENCES `stock_pool` (`stock_pool_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `storage_details`
--

DROP TABLE IF EXISTS `storage_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `storage_details` (
  `storage_id` bigint NOT NULL AUTO_INCREMENT,
  `storage_identity` varchar(150) DEFAULT NULL,
  `ref_id` bigint DEFAULT NULL,
  `rp_type` varchar(45) DEFAULT NULL,
  `stg_type` varchar(45) DEFAULT NULL,
  `up_type` varchar(45) DEFAULT NULL,
  `url` varchar(200) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `modified_by` int DEFAULT NULL,
  PRIMARY KEY (`storage_id`),
  UNIQUE KEY `storage_identity_UNIQUE` (`storage_identity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-09 19:43:44


INSERT INTO `digital_paper`.`payment_details` (`payment_id`, `order_id`, `payment_date`, `payment_mode`, `paid_amount`, `payment_status`, `identity`, `is_deleted`, `created_date`, `created_by`, `modified_date`, `modified_by`) VALUES ('1', '1', '2023-02-06 00:00:00', '2', '10000', '1', 'uitrewasDZFxghjkf564e4svx', '0', '2023-02-06 00:00:00', '3', '2023-02-06 00:00:00', '3');
ALTER TABLE `digital_paper`.`purchase_order` 
DROP FOREIGN KEY `company_purchase_fk`;
ALTER TABLE `digital_paper`.`purchase_order` 
DROP INDEX `company_purchase_fk_idx` ;
;
INSERT INTO `digital_paper`.`purchase_order` (`order_id`, `order_no`, `stock_count`, `purchase_date`, `company_id`, `order_status`, `order_amt`, `identity`, `is_deleted`, `created_date`, `created_by`, `modified_date`, `modified_by`) VALUES ('1', '1', '1000', '2023-02-06 00:00:00', '2', '2', '10000', 'fhdgsfgvfce4erdxas', '0', '2023-02-06 00:00:00', '3', '2023-02-06 00:00:00', '3');

ALTER TABLE `digital_paper`.`payment_details` 
ADD COLUMN `transaction_id` VARCHAR(45) NULL DEFAULT NULL AFTER `payment_status`,
ADD UNIQUE INDEX `transaction_id_UNIQUE` (`transaction_id` ASC) VISIBLE;
;

UPDATE `digital_paper`.`payment_details` SET `transaction_id` = 'TRAN123' WHERE (`payment_id` = '1');

ALTER TABLE `digital_paper`.`purchase_order` 
ADD COLUMN `purchase_id` VARCHAR(45) NULL DEFAULT NULL AFTER `order_status`,
ADD UNIQUE INDEX `order_id_UNIQUE` (`purchase_id` ASC) VISIBLE;
;

UPDATE `digital_paper`.`purchase_order` SET `purchase_id` = 'PO1234' WHERE (`order_id` = '1');

ALTER TABLE `digital_paper`.`payment_details` 
CHANGE COLUMN `payment_status` `payment_status` INT NULL DEFAULT NULL ;


ALTER TABLE `digital_paper`.`purchase_order` 
CHANGE COLUMN `order_status` `order_status` INT NULL DEFAULT NULL ;

ALTER TABLE `digital_paper`.`stock_notification` 
ADD COLUMN `order_id` INT NULL DEFAULT NULL AFTER `modified_by`,
ADD INDEX `fk_order_id_idx` (`order_id` ASC) VISIBLE;
;
ALTER TABLE `digital_paper`.`stock_notification` 
ADD CONSTRAINT `fk_order_id`
  FOREIGN KEY (`order_id`)
  REFERENCES `digital_paper`.`purchase_order` (`order_status`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

ALTER TABLE `digital_paper`.`stock_notification` 
CHANGE COLUMN `notification_id` `notification_id` INT NOT NULL AUTO_INCREMENT ;


ALTER TABLE `digital_paper`.`payment_details` 
CHANGE COLUMN `payment_mode` `payment_mode` INT NULL DEFAULT NULL ;

ALTER TABLE `digital_paper`.`payment_details` 
CHANGE COLUMN `payment_id` `payment_id` BIGINT NOT NULL AUTO_INCREMENT ;

INSERT INTO `recovery_db`.`section` (`section_id`, `section_name`, `association`, `page_id`, `identity`, `is_deleted`, `created_date`, `created_by`, `modified_date`, `modified_by`, `order_by`) VALUES ('104', 'User Role Card', '1', '37', 'hgdfvxdzsfcdsx4wrgae4e', '0', '2023-01-23', '1', '2023-01-23', '1', '104');


\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

ALTER TABLE `digital_paper`.`stock_pool` 
ADD COLUMN `user_type_id` INT NULL DEFAULT NULL AFTER `identity`;


ALTER TABLE `digital_paper`.`stock_pool` 
ADD COLUMN `is_active` TINYINT(1) NULL DEFAULT NULL AFTER `user_type_id`;

/*Paper Details
CREATE TABLE `paper_details` (
	`paper_id` bigint NOT NULL AUTO_INCREMENT,
	`paper_number` varchar(45) DEFAULT NULL,
	`policy_holder` varchar(45) DEFAULT NULL,
	`policy_number` varchar(45) DEFAULT NULL,
	`registration_number` varchar(45) DEFAULT NULL,
	`chassis_number` varchar(45) DEFAULT NULL,
	`insured_name` varchar(45) DEFAULT NULL,
	`usage` varchar(45) DEFAULT NULL,
	`license_to_carry` VARCHAR(45) DEFAULT NULL ,
	`make` VARCHAR(45)  DEFAULT NULL,
	`status` TINYINT(1)  DEFAULT NULL,
	`is_deleted` tinyint(1) DEFAULT NULL,
	`created_date` timestamp NULL DEFAULT NULL,
	`created_by` int DEFAULT NULL,
	`modified_date` timestamp NULL DEFAULT NULL,
	`modified_by` int DEFAULT NULL,
	`identity` varchar(150) DEFAULT NULL,
    `model` VARCHAR(45) DEFAULT NULL,
    `phone_number` VARCHAR(45) DEFAULT NULL,
    `email_id` VARCHAR(100) DEFAULT NULL,
	`company_id` bigint DEFAULT NULL,
	`stock_pool_id` bigint DEFAULT NULL,
	`paper_pool_id` bigint DEFAULT NULL,
	`effective_start_date` timestamp NULL DEFAULT NULL,
	`expiry_date` timestamp NULL DEFAULT NULL,
	`cancelled_date` timestamp NULL DEFAULT NULL,
	`storage_id` bigint DEFAULT NULL,
	 PRIMARY KEY (`paper_id`),
)




INSERT INTO `recovery_db`.`section` (`section_name`, `parent_section`, `association`, `page_id`, `identity`, `is_deleted`, `created_date`, `created_by`, `modified_date`, `modified_by`) VALUES ('Paper Details', '80', '1', '34', 'harshaBjsdgfouwclsh', '0', '2023-01-23', '1', '2023-01-23', '1');
INSERT INTO `recovery_db`.`section` (`section_name`, `parent_section`, `association`, `page_id`, `identity`, `is_deleted`, `created_date`, `created_by`, `modified_date`, `modified_by`) VALUES ('Vehicle Details', '80', '1', '34', 'oiutghetfghi7uefhcnoiaeyd', '0', '2023-01-23', '1', '2023-01-23', '1');

#field entry
INSERT INTO `recovery_db`.`field` (`field_name`, `field_type`, `alias_name`, `is_mandatory`, `is_core_data`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `min_length`, `max_length`, `is_sys_generated`) VALUES ('pdDigitalPaperId', 'Integer', 'Digital Paper', '0', '0', '0', 'rtersgdfscdweawsd', '2023-05-11', '3', '2023-05-11', '3', '0', '100000', '1');
INSERT INTO `recovery_db`.`field` (`field_name`, `field_type`, `alias_name`, `is_mandatory`, `is_core_data`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `min_length`, `max_length`, `is_sys_generated`) VALUES ('pdPolicyNumber', 'String', 'Policy Number', '1', '0', '0', 'rtersgdtycdweawsd', '2023-05-11', '3', '2023-05-11', '3', '0', '100', '1');
INSERT INTO `recovery_db`.`field` (`field_name`, `field_type`, `alias_name`, `is_mandatory`, `is_core_data`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `min_length`, `max_length`, `is_sys_generated`) VALUES ('pdInsuredName', 'String', 'Insured Name', '1', '0', '0', 'lllrsgdtycdweawsd', '2023-05-11', '3', '2023-05-11', '3', '0', '100', '1');
INSERT INTO `recovery_db`.`field` (`field_name`, `field_type`, `alias_name`, `is_mandatory`, `is_core_data`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `min_length`, `max_length`, `is_sys_generated`) VALUES ('pdPhoneNumber', 'String', 'Phone Number', '1', '0', '0', 'rtuirgfauidtycdweawsd', '2023-05-11', '3', '2023-05-11', '3', '0', '100', '1');
INSERT INTO `recovery_db`.`field` (`field_name`, `field_type`, `alias_name`, `is_mandatory`, `is_core_data`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `min_length`, `max_length`, `is_sys_generated`) VALUES ('pdEmailId', 'String', 'EmailId', '1', '0', '0', 'rtersgdtikjaefweawsd', '2023-05-11', '3', '2023-05-11', '3', '0', '100', '1');
INSERT INTO `recovery_db`.`field` (`field_name`, `field_type`, `alias_name`, `is_mandatory`, `is_core_data`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `min_length`, `max_length`, `is_sys_generated`) VALUES ('pdEffectiveFrom', 'pDate', 'Effective From', '0', '0', '0', 'rtersgdtycwrietfgwied', '2023-05-11', '3', '2023-05-11', '3', '0', '100', '1');
INSERT INTO `recovery_db`.`field` (`field_name`, `field_type`, `alias_name`, `is_mandatory`, `is_core_data`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `min_length`, `max_length`, `is_sys_generated`) VALUES ('pdExpireDate', 'pDate', 'Expire Date', '1', '0', '0', 'rterrweafseawsd', '2023-05-11', '3', '2023-05-11', '3', '0', '100', '1');
INSERT INTO `recovery_db`.`field` (`field_name`, `field_type`, `alias_name`, `is_mandatory`, `is_core_data`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `min_length`, `max_length`, `is_sys_generated`) VALUES ('vdRegistrationNumber', 'String', 'RegistrationNumber', '1', '0', '0', 'royiiguipdweawsd', '2023-05-11', '3', '2023-05-11', '3', '0', '100', '1');
INSERT INTO `recovery_db`.`field` (`field_name`, `field_type`, `alias_name`, `is_mandatory`, `is_core_data`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `min_length`, `max_length`, `is_sys_generated`) VALUES ('vdChassis', 'String', 'Chassis', '1', '0', '0', 'io8eyifgwiudweawsd', '2023-05-11', '3', '2023-05-11', '3', '0', '100', '1');
INSERT INTO `recovery_db`.`field` (`field_name`, `field_type`, `alias_name`, `is_mandatory`, `is_core_data`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `min_length`, `max_length`, `is_sys_generated`) VALUES ('vdLicensedToCarry', 'Integer', 'Licensed to carry', '1', '0', '0', 'rtersgdtycdweresgvsd', '2023-05-11', '3', '2023-05-11', '3', '0', '100', '1');
INSERT INTO `recovery_db`.`field` (`field_name`, `field_type`, `alias_name`, `is_mandatory`, `is_core_data`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `min_length`, `max_length`, `is_sys_generated`) VALUES ('vdMake', 'Dropdown', 'Make', '1', '0', '0', 'rtersgdtvasdzxcweawsd', '2023-05-11', '3', '2023-05-11', '3', '0', '100', '1');
INSERT INTO `recovery_db`.`field` (`field_name`, `field_type`, `alias_name`, `is_mandatory`, `is_core_data`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `min_length`, `max_length`, `is_sys_generated`) VALUES ('vdModel', 'Dropdown', 'Model', '1', '0', '0', 'rtersgdtyewfcdeawsd', '2023-05-11', '3', '2023-05-11', '3', '0', '100', '1');
INSERT INTO `recovery_db`.`field` (`field_name`, `field_type`, `alias_name`, `is_mandatory`, `is_core_data`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `min_length`, `max_length`, `is_sys_generated`) VALUES ('vdUsage', 'Dropdown', 'Usage', '1', '0', '0', 'rtersgdsdvzcxdweawsd', '2023-05-11', '3', '2023-05-11', '3', '0', '100', '1');


#metadata build
INSERT INTO `recovery_db`.`meta_data` (`page_id`, `section_id`, `field_id`, `entity`, `column_name`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `platform_id`) VALUES ('34', '104', '123', 'PaperDetails', 'pdDigitalPaper', '0', 'utwefdwsterystgrsfds', '2023-04-12', '2', '2023-04-12', '3', '2');
INSERT INTO `recovery_db`.`meta_data` (`page_id`, `section_id`, `field_id`, `entity`, `column_name`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `platform_id`) VALUES ('34', '104', '124', 'PaperDetails', 'pdPolicyNumber', '0', 'turyjdthsrgaefsdas', '2023-04-12', '2', '2023-04-12', '3', '2');
INSERT INTO `recovery_db`.`meta_data` (`page_id`, `section_id`, `field_id`, `entity`, `column_name`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `platform_id`) VALUES ('34', '104', '125', 'PaperDetails', 'pdInsuredName', '0', 'ioutrtasdfygiuhn7yuihk', '2023-04-12', '2', '2023-04-12', '3', '2');
INSERT INTO `recovery_db`.`meta_data` (`page_id`, `section_id`, `field_id`, `entity`, `column_name`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `platform_id`) VALUES ('34', '104', '126', 'PaperDetails', 'pdPhoneNumber', '0', 'zsd567r6t89y8p9ri6dctv', '2023-04-12', '2', '2023-04-12', '3', '2');
INSERT INTO `recovery_db`.`meta_data` (`page_id`, `section_id`, `field_id`, `entity`, `column_name`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `platform_id`) VALUES ('34', '104', '127', 'PaperDetails', 'pdEmailId', '0', 'w4e57r67t8p79uyidtxvjh', '2023-04-12', '2', '2023-04-12', '3', '2');
INSERT INTO `recovery_db`.`meta_data` (`page_id`, `section_id`, `field_id`, `entity`, `column_name`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `platform_id`) VALUES ('34', '104', '128', 'PaperDetails', 'pdEffectiveFrom', '0', 'w46e56876oyystrxcygu', '2023-04-12', '2', '2023-04-12', '3', '2');
INSERT INTO `recovery_db`.`meta_data` (`page_id`, `section_id`, `field_id`, `entity`, `column_name`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `platform_id`) VALUES ('34', '104', '129', 'PaperDetails', 'pdExpireDate', '0', 'poiurdtxcvli6yhut', '2023-04-12', '2', '2023-04-12', '3', '2');
INSERT INTO `recovery_db`.`meta_data` (`page_id`, `section_id`, `field_id`, `entity`, `column_name`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `platform_id`) VALUES ('34', '105', '130', 'PaperDetails', 'vdRegistrationNumber', '0', 'sdfupuo;lfcgj bnlk', '2023-04-12', '2', '2023-04-12', '3', '2');
INSERT INTO `recovery_db`.`meta_data` (`page_id`, `section_id`, `field_id`, `entity`, `column_name`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `platform_id`) VALUES ('34', '105', '131', 'PaperDetails', 'vdChassis', '0', 'sryiyutfuutifydtguhipjo', '2023-04-12', '2', '2023-04-12', '3', '2');
INSERT INTO `recovery_db`.`meta_data` (`page_id`, `section_id`, `field_id`, `entity`, `column_name`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `platform_id`) VALUES ('34', '105', '132', 'PaperDetails', 'vdLicensedToCarry', '0', 'zxdftyuiolkjhdsxcfghj', '2023-04-12', '2', '2023-04-12', '3', '2');
INSERT INTO `recovery_db`.`meta_data` (`page_id`, `section_id`, `field_id`, `entity`, `column_name`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `platform_id`) VALUES ('34', '105', '133', 'PaperDetails', 'vdMake', '0', 'qwer67890poiuytfdsxcvbn', '2023-04-12', '2', '2023-04-12', '3', '2');
INSERT INTO `recovery_db`.`meta_data` (`page_id`, `section_id`, `field_id`, `entity`, `column_name`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `platform_id`) VALUES ('34', '105', '134', 'PaperDetails', 'vdModel', '0', 'poiuytrewsdfghjnv', '2023-04-12', '2', '2023-04-12', '3', '2');
INSERT INTO `recovery_db`.`meta_data` (`page_id`, `section_id`, `field_id`, `entity`, `column_name`, `is_deleted`, `identity`, `created_date`, `created_by`, `modified_date`, `modified_by`, `platform_id`) VALUES ('34', '105', '135', 'PaperDetails', 'vdUsage', '0', 'wertyuiopoiugfdxcvbnm', '2023-04-12', '2', '2023-04-12', '3', '2');



ALTER TABLE `recovery_db`.`bulk_import_history` 
ADD COLUMN `platform_id` INT NULL DEFAULT NULL AFTER `is_deleted`,
ADD INDEX `fk_platform_id_idx` (`platform_id` ASC) VISIBLE;
;
ALTER TABLE `recovery_db`.`bulk_import_history` 
ADD CONSTRAINT `fk_platform_id`
  FOREIGN KEY (`platform_id`)
  REFERENCES `recovery_db`.`platform` (`platform_id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

ALTER TABLE `recovery_db`.`bulk_import_mapping` 
ADD COLUMN `platform_id` INT NULL DEFAULT NULL AFTER `bulk_import_aliasName`;


INSERT INTO `recovery_db`.`bulk_import_mapping` (`bulk_import_fieldName`, `bulk_import_aliasName`, `platform_id`) VALUES ('pdDigiltaPaperId', 'Paper Number', '2');
INSERT INTO `recovery_db`.`bulk_import_mapping` (`bulk_import_fieldName`, `bulk_import_aliasName`, `platform_id`) VALUES ('pdPolicyNumber', 'Policy Number', '2');
INSERT INTO `recovery_db`.`bulk_import_mapping` (`bulk_import_fieldName`, `bulk_import_aliasName`, `platform_id`) VALUES ('vdRegistrationNumber', 'Registration Number', '2');
INSERT INTO `recovery_db`.`bulk_import_mapping` (`bulk_import_fieldName`, `bulk_import_aliasName`, `platform_id`) VALUES ('vdChassis', 'Chassis Number', '2');
INSERT INTO `recovery_db`.`bulk_import_mapping` (`bulk_import_fieldName`, `bulk_import_aliasName`, `platform_id`) VALUES ('pdInsuredName', 'Insured Name', '2');
INSERT INTO `recovery_db`.`bulk_import_mapping` (`bulk_import_fieldName`, `bulk_import_aliasName`, `platform_id`) VALUES ('vdUsage', 'Usage', '2');
INSERT INTO `recovery_db`.`bulk_import_mapping` (`bulk_import_fieldName`, `bulk_import_aliasName`, `platform_id`) VALUES ('vdLicensedToCarry', 'License to carry', '2');
INSERT INTO `recovery_db`.`bulk_import_mapping` (`bulk_import_fieldName`, `bulk_import_aliasName`, `platform_id`) VALUES ('vdMake', 'Make', '2');
INSERT INTO `recovery_db`.`bulk_import_mapping` (`bulk_import_fieldName`, `bulk_import_aliasName`, `platform_id`) VALUES ('vdModel', 'Model', '2');
INSERT INTO `recovery_db`.`bulk_import_mapping` (`bulk_import_fieldName`, `bulk_import_aliasName`, `platform_id`) VALUES ('pdPhoneNumber', 'Phone Number', '2');
INSERT INTO `recovery_db`.`bulk_import_mapping` (`bulk_import_fieldName`, `bulk_import_aliasName`, `platform_id`) VALUES ('pdEmailId', 'Email Id', '2');
INSERT INTO `recovery_db`.`bulk_import_mapping` (`bulk_import_fieldName`, `bulk_import_aliasName`, `platform_id`) VALUES ('pdEffectiveFrom', 'Effective Start Date', '2');
INSERT INTO `recovery_db`.`bulk_import_mapping` (`bulk_import_fieldName`, `bulk_import_aliasName`, `platform_id`) VALUES ('pdExpireDate', 'Expiry Date', '2');


ALTER TABLE `digital_paper`.`dp_scratch` 
CHANGE COLUMN `license_to_carry` `license_to_carry` VARCHAR(10) NULL DEFAULT NULL ,
CHANGE COLUMN `effective_from` `effective_from` VARCHAR(45) NULL DEFAULT NULL ,
CHANGE COLUMN `expiry_date` `expiry_date` VARCHAR(45) NULL DEFAULT NULL ;
ALTER TABLE `digital_paper`.`dp_scratch` 
CHANGE COLUMN `status` `status` INT NULL DEFAULT NULL ;


UPDATE `recovery_db`.`field` SET `field_type` = 'String' WHERE (`field_id` = '132');

UPDATE `recovery_db`.`field` SET `regex` = '^[0-9+ ]*$' WHERE (`field_name` = 'pdPhoneNumber');
UPDATE `recovery_db`.`field` SET `regex` = '^[a-zA-Z0-9.+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$' WHERE (`field_name` = 'pdEmailId');
UPDATE `recovery_db`.`field` SET `regex` = '^[a-zA-Z0-9]*$' WHERE (`field_id` = '130');
UPDATE `recovery_db`.`field` SET `regex` = '^[a-zA-Z0-9]*$' WHERE (`field_id` = '131');
UPDATE `recovery_db`.`field` SET `regex` = '^[a-zA-Z0-9]*$' WHERE (`field_id` = '132');
UPDATE `recovery_db`.`field` SET `regex` = '^[a-zA-Z0-9]*$' WHERE (`field_id` = '133');
UPDATE `recovery_db`.`field` SET `regex` = '^[a-zA-Z0-9]*$' WHERE (`field_id` = '134');
UPDATE `recovery_db`.`field` SET `regex` = '^[a-zA-Z0-9]*$' WHERE (`field_id` = '135');


CREATE TABLE `bulk_revoke_success_error_table` (
  `success_error_id` int NOT NULL AUTO_INCREMENT,
  `success_error_message` varchar(150) DEFAULT NULL,
  `paper_id` varchar(45) DEFAULT NULL,
  `bulk_import_history_id` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `identity` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`success_error_id`),
  UNIQUE KEY `error_id_UNIQUE` (`success_error_id`),
  UNIQUE KEY `identity_UNIQUE` (`identity`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--INSERT FIELD DROP DOWN MAP TABLE -------------------------------

SET @field_id = (SELECT field_id FROM recovery_dp.field where field.field_name = "vdMake");
set @dropdown_id=(SELECT dropdownListId FROM recovery_dp.dropdownlist where dropdownlist.name = "Make");
INSERT INTO `recovery_dp`.`field_dropdown_map` 
(`field_id`, `dropdownlist_id`,,`identity`,`is_deleted`, `created_date`, `created_by`, `modified_date`, `modified_by`)
VALUES (@field_id, @dropdown_id,"178494027700002", "0", '2023-03-15', '1', '2023-03-15', '1');
-- roll back -----------------------------
DELETE FROM `recovery_dp`.`field_dropdown_map` WHERE (`field_id` = @field_id);

-- ------------------------------------------------

ALTER TABLE `digital-paper`.`reports` 
ADD COLUMN `status` VARCHAR(100) NULL AFTER `modified_by`,
ADD COLUMN `period` VARCHAR(45) NULL AFTER `status`,
CHANGE COLUMN `report_name` `insurend_name` VARCHAR(100) NULL DEFAULT NULL ,
CHANGE COLUMN `total_columns` `selected_column` INT NULL DEFAULT NULL ;
