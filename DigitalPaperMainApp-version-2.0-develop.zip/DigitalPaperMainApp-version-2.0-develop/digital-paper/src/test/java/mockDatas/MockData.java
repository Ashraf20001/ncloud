package mockDatas;

import java.io.File;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.text.WordUtils;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.mockdata.PurchaseOrderMockData;
import com.digitalpaper.transfer.object.dto.CompanyTransactionDto;
import com.digitalpaper.transfer.object.dto.ComplaintsDto;
import com.digitalpaper.transfer.object.dto.FieldDto;
import com.digitalpaper.transfer.object.dto.DigitalPaperDto;
import com.digitalpaper.transfer.object.dto.Field;
import com.digitalpaper.transfer.object.dto.FieldGroup;
import com.digitalpaper.transfer.object.dto.FieldValue;
import com.digitalpaper.transfer.object.dto.MailRequestDto;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;
import com.digitalpaper.transfer.object.dto.PreviewReportDto;
import com.digitalpaper.transfer.object.dto.PurchaseOrderDto;
import com.digitalpaper.transfer.object.dto.ReportsDto;
import com.digitalpaper.transfer.object.dto.SaveStockDataVo;
import com.digitalpaper.transfer.object.dto.StockDto;
import com.digitalpaper.transfer.object.dto.StockNotificationDto;
import com.digitalpaper.transfer.object.dto.SystemPropertyValueDto;
import com.digitalpaper.transfer.object.dto.ViewHistoryDto;
import com.digitalpaper.transfer.object.entity.Complaints;
import com.digitalpaper.transfer.object.entity.FileStorage;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.entity.PaymentDetails;
import com.digitalpaper.transfer.object.entity.PurchaseOrderEntity;
import com.digitalpaper.transfer.object.entity.Stock;

public class MockData {

	public static StockDto getStockVoMockData() {
		StockDto dtos = new StockDto();
		dtos.setCompanyId(1);
		dtos.setStockCount(200);
		dtos.setUsedCount(50);
		return dtos;

	}
	
	//Mock Data for companyId and companyName Map
	public static HashMap<Integer,String> companyIdNameMockData(){
		HashMap<Integer, String> companyMapMockData = new HashMap<Integer,String>();
		companyMapMockData.put(1,"Dream Insurance");
		companyMapMockData.put(2, "Smile Insurance");
		companyMapMockData.put(3, "Normal Company");
		return companyMapMockData;
	}

	public static List<ReportsDto> getReportListMock() {
		List<ReportsDto> data = new ArrayList<>();
		ReportsDto report = new ReportsDto();

		report.setFileType(1);
		report.setIdentity("34werweriuwr234");
		report.setInsuredName("yuva");
		long i = 123;
		report.setPaperDetailsActiveCount(i);
		report.setPaperDetailsActiveCount(i);
		report.setPaperDetailsTotalCount(i);
		report.setPeriod("2 month");
		report.setReportName("yuvarani");
		report.setReportType(1);

		List<String> list = new ArrayList<>();
		list.add("selected column");
		list.add("report");
		list.add("model");

		report.setSelectedColumn(list);
		long u = 3;
		report.setSelectedColumnCount(u);
		report.setStatus(list);

		data.add(report);

		return data;

	}
	
	public static ReportsDto getReportsDtoMock() {
		ReportsDto report = new ReportsDto();

		report.setIdentity("98347rh487ry47ry");
		report.setInsuredName("yuva");
		long i = 123;
		report.setPaperDetailsActiveCount(i);
		report.setPaperDetailsActiveCount(i);
		report.setPaperDetailsTotalCount(i);
		report.setPeriod("2 month");
		report.setReportName("yuvarani");
		report.setReportType(1);

		List<String> list = new ArrayList<>();
		list.add("Status");
		list.add("Make");
		list.add("model");

		report.setSelectedColumn(list);
		long u = 3;
		report.setSelectedColumnCount(u);
		report.setStatus(list);;

		return report;

	}
	
	public static ReportsDto getReportsDtoNullMock() {
		ReportsDto report = new ReportsDto();

		report.setIdentity("98347rh487ry47ry");
		report.setInsuredName("yuva");
		long i = 123;
		report.setPaperDetailsActiveCount(i);
		report.setPaperDetailsActiveCount(i);
		report.setPaperDetailsTotalCount(i);
		report.setPeriod("2 month");
		report.setReportName("yuvarani");
		report.setReportType(1);

		List<String> list = new ArrayList<>();
		list.add("Status");
		list.add("Make");
		list.add("model");

		report.setSelectedColumn(list);
		long u = 3;
		report.setSelectedColumnCount(u);
		report.setStatus(list);;

		return null;

	}

	public static ReportsDto getReportMock() {
		ReportsDto report = new ReportsDto();

		report.setIdentity("98347rh487ry47ry");
		report.setInsuredName("yuva");
		long i = 123;
		report.setPaperDetailsActiveCount(i);
		report.setPaperDetailsActiveCount(i);
		report.setPaperDetailsTotalCount(i);
		report.setPeriod("2 month");
		report.setReportName("yuvarani");
		report.setReportType(1);

		List<String> list = new ArrayList<>();
		list.add("Status");
		list.add("Make");
		list.add("model");

		report.setSelectedColumn(list);
		long u = 3;
		report.setSelectedColumnCount(u);
		report.setStatus(list);;

		return null;

	}

	
	public static PreviewReportDto getPreviewReportDtoDtoMock() {
		PreviewReportDto dto = new PreviewReportDto();
		dto.setReportData(getReportsDtoMock());	
		List<FilterOrSortingVo> filter = new ArrayList<>();
		dto.setFilterVo(filter);
		

		return dto;

	}
	
	public static List<String> getListOfStringDtoMock() {
		
		List<String> data = new ArrayList<>();
		
		data.add("Selected Column");
		data.add("model");
		data.add("Make");
		data.add("register number");

		return data;

	}
	
	public static ResponseEntity<ByteArrayResource> getResponceEntityMockData(){
		
	}

	public static MailRequestDto getMailRequestDtoMock() {
		MailRequestDto dto = new MailRequestDto();

		dto.setFrom("yuva@gmail.com");
		dto.setName("ekrufg");
		dto.setSubject("qerkjhqer");
		dto.setTo("yuvathy17@gmail.com");

		File img = new File("uyeriu928374_png");
		dto.setFile(img);

		return dto;

	}

	public static Map<String, Object> getMapStringObjectMockData() {
		Map<String, Object> model = new HashMap<String, Object>();

		model.put("Name", WordUtils.capitalize("askujfhqf"));
		model.put("paperNumber", "wfjkhw");
		model.put("CompanyName", "skdfj");
		model.put("policyNo", "rkfhrf");
		model.put("registrationNo", ",rjfnj	rf	rf");

		return model;
	}

	public static List<PaperDetailsDto> getPaperDetailsDtoMockData() {

		List<PaperDetailsDto> list = new ArrayList<>();

		PaperDetailsDto data = new PaperDetailsDto();
		data.setCreatedDate(LocalDateTime.now());
		data.setDigitalPaperId(3);
		data.setFileURL("wieuyiwe");
		data.setIdentity("w87efyh3478ryhf34");
		data.setInsurer("yu8sjnb");
		data.setPdDigiltaPaperId("iehdfuiq");
		data.setPdEffectiveFrom(LocalDateTime.now());
		data.setPdEmailId("kudyhd");
		data.setPdExpireDate(LocalDateTime.now());
		data.setPdInsuredName("kuedyhiudn");
		data.setPdPhoneNumber("876756445655");
		data.setPdPolicyNumber("OIWDUIJDH");
		data.setStatus("skefjh");
		data.setVdChassis("KAWH983eyh938");
		data.setVdLicensedToCarry("aKJHFiowf");
		data.setVdMake("qoeruqi");
		data.setVdModel("23984728347");
		data.setVdRegistrationNumber("uiewhrfw");
		data.setVdUsage("jsdhfsdyf");

		list.add(data);

		return list;
	}

	public static FileStorage getFileStorageMockData() {

		FileStorage data = new FileStorage();
		data.setCreatedDate("12/05/2023");
		data.setDeleted(false);
		Long i = (long) 83764874;
		data.setFileSize(i);
		data.setReferenceId(i);
		data.setReportType("re_type");
		data.setStorageId(3);
		data.setStorageType("TOU_TYPE");
		data.setUploadType("werwef");
		data.setUrl("238764ehgdr2376_pgn");

		return data;
	}

	public static List<StockNotificationDto> getStockNotificationMock() {

		List<StockNotificationDto> list = new ArrayList<>();
		StockNotificationDto dto = new StockNotificationDto();

		dto.setActedBy(1);
		LocalDateTime now = LocalDateTime.now();
		dto.setCreatedDate(now);
		dto.setImageUrl("weiuruirfbff");
		dto.setNotificationId(2);
		dto.setNotificationMsg("100 stock request by peter");
		dto.setOrderId(2);
		dto.setToNotify(2);

		list.add(dto);
		return list;

	}

	public static SystemPropertyValueDto SystemPropertyValueDtoVoMockData() {
		SystemPropertyValueDto dtos = new SystemPropertyValueDto();
		dtos.setAssociationId(1);
		dtos.setPropertyId(1);
		dtos.setPropertyValue("wuiery");
		dtos.setPropertyValueId(1);
		return dtos;

	}

	public static SaveStockDataVo SaveStockDataVoVoMockData() {
		SaveStockDataVo dtos = new SaveStockDataVo();
		dtos.setNumberOfPapers("2");
		dtos.setPaymentMethod("213");
		dtos.setTotalCostValue("213");

		ArrayList<String> data = new ArrayList<String>();
		data.add("9384ry");
		data.add("suefywuief");
		data.add("sjdhvg");
		dtos.setUploadFileName(true);
		return dtos;

	}

	public static PurchaseOrderEntity purchaseOrderMockData() {
		PurchaseOrderEntity purchaseVo = new PurchaseOrderEntity();

		purchaseVo.setCompanyId(2);
		purchaseVo.setOrderStatus(2);
		purchaseVo.setOrderAmt("USD");
		purchaseVo.setOrderId(1);
//		purchaseVo.setOrderNo("3465");
		purchaseVo.setStockCount(123);

		return purchaseVo;
	}

	public static PaymentDetails PaymentDetailsMockData() {
		PaymentDetails dtos = new PaymentDetails();

		dtos.setOrderId(purchaseOrderMockData());
		dtos.setPaidAmount("USD");
		dtos.setPaymentMode(2);
		dtos.setPaymentStatus(2);
		return dtos;

	}

	public static Stock StockMockData() {
		Stock dtos = new Stock();

		dtos.setCompanyId(1);
		dtos.setStockCount(1234);
		dtos.setStockId(12);
		dtos.setUsedCount(23);
		dtos.setCreatedDate(LocalDateTime.now());
		dtos.setModifiedDate(LocalDateTime.now());
		dtos.setCreatedBy(3);
		dtos.setModifiedBy(3);
		return dtos;

	}

	public static ComplaintsDto getComplaintsDtoMock() {

		ComplaintsDto data = new ComplaintsDto();
		data.setCompanyId(1);
		data.setCompliantsType("this is reference type");
		data.setDateOfIncident("12/09/2023");
		data.setEmailId("uva@gmal.com");
		data.setName("rani");
		data.setRemarks("drink and drive");

		return data;

	}

	public static Complaints getComplaintsMock() {

		Complaints data = new Complaints();
		data.setComplaintsId(1);
		data.setComplaintType("this is reference type");
		data.setDateOfIncident(LocalDateTime.now());
		data.setEmail_id("uva@gmal.com");
		data.setName("rani");
		data.setRemarks("drink and drive");

		return data;

	}

	public static List<Complaints> getListComplaintsMock() {

		List<Complaints> list = new ArrayList<Complaints>();
		Complaints data = new Complaints();
		data.setComplaintsId(1);
		data.setComplaintType("this is reference type");
		data.setDateOfIncident(LocalDateTime.now());
		data.setEmail_id("uva@gmal.com");
		data.setName("rani");
		data.setRemarks("drink and drive");
		list.add(data);
		return list;

	}

	public static List<ComplaintsDto> getComplainDtoListMock() {

		List<ComplaintsDto> list = new ArrayList<ComplaintsDto>();

		ComplaintsDto data = new ComplaintsDto();
		data.setCompanyId(1);
		data.setCompliantsType("this is reference type");
		data.setDateOfIncident(LocalDateTime.now());
		data.setEmailId("uva@gmal.com");
		data.setName("rani");
		data.setRemarks("drink and drive");

		list.add(data);

		return list;

	}

	public static Stock StockMockData1() {
		Stock dtos = new Stock();

		dtos.setCompanyId(1);
		dtos.setStockCount(1234);
		dtos.setStockId(12);
		dtos.setUsedCount(24);
		dtos.setCreatedDate(LocalDateTime.now());
		dtos.setModifiedDate(LocalDateTime.now());
		dtos.setCreatedBy(3);
		dtos.setModifiedBy(3);
		return dtos;

	}

	public static DigitalPaperDto getDigitalPaperDtoMock() {
		DigitalPaperDto dto = new DigitalPaperDto();

		dto.setPdDigitalPaperId("qiuwy");
		dto.setPdEffectiveFrom(LocalDateTime.now());
		dto.setPdEmailId("iutuyyu");
		dto.setPdExpireDate(LocalDateTime.now());
		dto.setPdInsuredName("euii");
		dto.setPdPhoneNumber("89632489273");
		dto.setPdPolicyNumber("weutfwf");
		dto.setVdChassis("efuyuwif");
		dto.setVdLicensedToCarry("2");
		dto.setVdMake("weriuyewif");
		dto.setVdModel("weuirtuef");
		dto.setVdRegistrationNumber("eriuyrg");
		dto.setVdUsage("oieruir");

		return dto;
	}

	public static List<DigitalPaperDto> getListOfDigitalPaperDtoMock() {

		List<DigitalPaperDto> data = new ArrayList<DigitalPaperDto>();

		DigitalPaperDto dto = new DigitalPaperDto();

		dto.setPdDigitalPaperId("qiuwy");
		dto.setPdEffectiveFrom(LocalDateTime.now());
		dto.setPdEmailId("iutuyyu");
		dto.setPdExpireDate(LocalDateTime.now());
		dto.setPdInsuredName("euii");
		int i = 89632489;
//		Long l= new Long(i);
//		dto.setPdPhoneNumber(l);
//		dto.setPdPolicyNumber("weutfwf");
//		dto.setVdChassis("efuyuwif");
//		dto.setVdLicensedToCarry(7);
		dto.setVdMake("weriuyewif");
		dto.setVdModel("weuirtuef");
		dto.setVdRegistrationNumber("eriuyrg");
		dto.setVdUsage("oieruir");
		data.add(dto);

		return data;
	}

	public static List<PaperDetails> getListOfDigitalPaperMock() {

		List<PaperDetails> data = new ArrayList<PaperDetails>();

		PaperDetails dto = new PaperDetails();

		dto.setPdDigitalPaperId("qiuwy");
		dto.setPdEffectiveFrom(LocalDateTime.now());
		dto.setPdEmailId("iutuyyu");
		dto.setPdExpireDate(LocalDateTime.now());
		dto.setPdInsuredName("euii");
		int i = 89632489;
//		Long l= new Long(i);
//		dto.setPdPhoneNumber(l);
//		dto.setPdPolicyNumber("weutfwf");
//		dto.setVdChassis("efuyuwif");
//		dto.setVdLicensedToCarry(7);
		dto.setVdMake("weriuyewif");
		dto.setVdModel("weuirtuef");
		dto.setVdRegistrationNumber("eriuyrg");
		dto.setVdUsage("oieruir");
		data.add(dto);

		return data;
	}

	public static PaperDetails getPaperDetailsMockData() {

		PaperDetails data = new PaperDetails();
		data.setCancelledDate(LocalDateTime.now());
		data.setCompanyId(1);
		data.setCreatedBy(2);
		data.setCreatedDate(LocalDateTime.now());
		data.setIdentity("ekrufyhifhqeruifheirf");
		data.setIsDeleted(false);
		data.setModifiedBy(2);
		data.setModifiedDate(LocalDateTime.now());
		data.setPaperId(2);
		data.setPaperPoolId(3);
		data.setPdDigitalPaperId("wuiefyufe");
		data.setPdEffectiveFrom(LocalDateTime.now());
		data.setPdEmailId("uiertyuytg");
		data.setPdExpireDate(LocalDateTime.now());
		data.setPdInsuredName("werewrewqwe");
		data.setPdPhoneNumber("9847872568234");
		data.setPdPolicyNumber("48768347134");
		data.setPolicyHolder("wirueyiuwrwer");
		data.setStatus(4);
		data.setStockPoolId(4);
		data.setStorageId("utruwer");
		data.setVdChassis("qerfuyqri");
		return data;
	}

	public static List<Integer> getCompanyIdList() {
		List<Integer> companyIdList = new ArrayList<Integer>();
		companyIdList.add(1);
		companyIdList.add(2);
		return companyIdList;
	}

	public static CompanyTransactionDto getCompanyTransactionDto() {
		CompanyTransactionDto companyTransactionDto = new CompanyTransactionDto();

		companyTransactionDto.setCompanyId(getCompanyIdList());
		companyTransactionDto.setFilter(PurchaseOrderMockData.getListFilterOrSortingVo());
		companyTransactionDto.setMax(10);
		companyTransactionDto.setMin(0);

		return companyTransactionDto;
	}

	public static List<ViewHistoryDto> getViewHistoryDtoList() {
		ViewHistoryDto viewHistory = new ViewHistoryDto();
		viewHistory.setCompanyName("AXA insurance");
		viewHistory.setOrderId(2);
		viewHistory.setPaymentMethod("Cash");
		viewHistory.setPaymentStatus("SUBMITTED");
		viewHistory.setPurchaseAmount("USD");
		viewHistory.setPurchaseDate("23-05-2023");
		viewHistory.setPurchaseId("ass1");
		viewHistory.setStockCount(300);
		viewHistory.setTransactionId("TXN001");

		List<ViewHistoryDto> viewList = new ArrayList<ViewHistoryDto>();
		viewList.add(viewHistory);

		return viewList;
	}

	public static List<FieldDto> getFieldDtoList() {
		List<FieldDto> list = new ArrayList<FieldDto>();
		FieldDto dto = new FieldDto();
		dto.setAliasName("alias_name");
		dto.setColumnName("column_name");
		dto.setDefaultValues("default,values");
		dto.setEntityName("entity");
		dto.setFieldId(null);
		dto.setFieldType("Dropdown");
		;
		dto.setFieldName("field_name");
		dto.setMandatory(false);
		dto.setIsCoreData(true);
		list.add(dto);
		return list;
	}

	public static FieldGroup getFieldGroupData() {

		List<FieldGroup> fieldGroup = new ArrayList<>();
		List<FieldValue> fieldValueList = new ArrayList<>();

		Field field = new Field();
		field.setFieldId("sdfdfssssss");
		field.setFieldName("tpName");
		field.setFieldType("String");
		field.setMandatory(false);
		field.setIsCoreData(false);

		Field f2 = new Field();
		f2.setFieldId("1");
		f2.setFieldName("ipName");
		f2.setFieldType("MultiSelect");
		f2.setReferenceId(1);
		f2.setMandatory(false);
		f2.setIsCoreData(false);

		Field f3 = new Field();
		f3.setFieldId("2");
		f3.setFieldName("vpName");
		f3.setFieldType("String");
		f3.setReferenceId(2);
		f3.setMandatory(false);
		f3.setIsCoreData(false);

		Field f4 = new Field();
		f4.setFieldId(null);
		f4.setFieldName("tpName");
		f4.setFieldType("String");
		f4.setMandatory(false);
		f4.setIsCoreData(false);

		FieldValue fieldValue = new FieldValue();
		fieldValue.setField(field);
		fieldValue.setValue("AGS insurance");

		FieldValue fv2 = new FieldValue();
		fv2.setField(f2);
		fv2.setValue("xyz insurance");

		FieldValue fv3 = new FieldValue();
		fv3.setField(f3);
		fv3.setValue("ops insurance");

		FieldValue fv4 = new FieldValue();
		fv4.setField(f4);
		fv4.setValue("abc insurance");

		fieldValueList.add(fieldValue);
		fieldValueList.add(fv2);
		fieldValueList.add(fv3);
		fieldValueList.add(fv4);

		FieldGroup child = new FieldGroup();
		child.setGroupName("ThirdPartyDetails");
		child.setFieldValues(fieldValueList);
		child.setFieldGroups(null);

		FieldGroup parent = new FieldGroup();
		parent.setGroupName("NotificationStage");
		parent.setFieldValues(new ArrayList<>());
		fieldGroup.add(child);

		FieldGroup fieldGroup2 = new FieldGroup();
		fieldGroup2.setGroupName("ClaimDetailsDto");
		fieldGroup2.setFieldValues(new ArrayList<>());

		return fieldGroup2;

	}
}
