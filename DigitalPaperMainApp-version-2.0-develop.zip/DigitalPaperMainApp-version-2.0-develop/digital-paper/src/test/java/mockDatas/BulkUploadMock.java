package mockDatas;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.digitalpaper.mockdata.AllocationPoolMockData;
import com.digitalpaper.transfer.object.dto.BulkImportFieldValidationDto;
import com.digitalpaper.transfer.object.dto.BulkImportHistoryDto;
import com.digitalpaper.transfer.object.dto.BulkImportMapping;
import com.digitalpaper.transfer.object.dto.BulkImportTriggerConsumerDto;
import com.digitalpaper.transfer.object.dto.FieldDto;
import com.digitalpaper.transfer.object.dto.PlatformDetailsDto;
import com.digitalpaper.transfer.object.dto.PoolCountDetails;
import com.digitalpaper.transfer.object.dto.ScratchDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.dto.UserRoleDto;
import com.digitalpaper.transfer.object.entity.BulkImportErrorTable;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.entity.Scratch;
import com.digitalpaper.transfer.object.entity.StockPool;
import com.digitalpaper.transfer.object.entity.UserType;

public class BulkUploadMock {
	
	public static BulkImportTriggerConsumerDto getBulkImportTriggerConsumerDto() {
		BulkImportTriggerConsumerDto dto = new BulkImportTriggerConsumerDto();
		dto.setBulkImportHistoryDto(getBulkImportHistoryDto());
		dto.setBulkImportIdentity("identity");
		dto.setInsurer("insurer");
		dto.setPageIdentity("page_identity");
		dto.setUploadType("NORMAL");
		dto.setUserId(1);
		dto.setUserInfo(getUserInfo());
		dto.setPoolCountDetails(getPoolCountDetails());
		
		return dto;
	}
	
	public static BulkImportHistoryDto getBulkImportHistoryDto() {
		BulkImportHistoryDto dto = new BulkImportHistoryDto();
		dto.setFailureCount(0);
		dto.setPageId(1);
		dto.setPlatformId(2);
		dto.setPoolId(1);
		dto.setStatus("status");
		dto.setUploadId(1);
		dto.setUploadType(1);
		dto.setSuccessCount(0);
		dto.setTotalCount(0);
		dto.setIdentity("identity");
		return dto;
	}
	
	public static PoolCountDetails getPoolCountDetails() {
		PoolCountDetails countDetails = new PoolCountDetails();
		countDetails.setFailedPaperGenerateCount(0);
		countDetails.setReservedPaperCount(0);
		countDetails.setSuccessPaperGenerateCount(0);
		return countDetails;
	}
	
	
	public static BulkImportMapping getBulkImportMapping() {
		BulkImportMapping dto = new BulkImportMapping();
		dto.setBulkImportAliasName("aliasName");
		dto.setBulkImportFieldName("fieldName");
		return dto;
	}
	

	
	public static List<BulkImportMapping> getListBulkImportMapping(){
		 List<BulkImportMapping> list = new ArrayList<>();
		 list.add(getBulkImportMapping());
		 return list;
		
	}
	
	

	
	public static BulkImportFieldValidationDto getBulkImportFieldValidationDto() {
		BulkImportFieldValidationDto dto = new BulkImportFieldValidationDto();
		dto.setBulkImportHistoryDto(getBulkImportHistoryDto());
		dto.setBulkImportMappingData(getListBulkImportMapping());
		dto.setFieldList(getListOfFieldDto());
		dto.setInitialRowNumber(0);
		dto.setInsurerName("name");
		dto.setIsLastProcess(true);
		dto.setMapList(getListOfMap());
		dto.setPoolCountDetails(getPoolCountDetails());
		dto.setTotalRowInExcel(1);
		dto.setUploadAction("UPLOAD");
		dto.setUploadType("NORMAL");
		dto.setUserId("id");
		dto.setUserInfo(getUserInfo());
		return dto;
		
	}
	
	public static BulkImportFieldValidationDto getBulkImportFieldValidationDto1() {
		BulkImportFieldValidationDto dto = new BulkImportFieldValidationDto();
		dto.setBulkImportHistoryDto(getBulkImportHistoryDto());
		dto.setBulkImportMappingData(getListBulkImportMapping());
		dto.setFieldList(getListOfFieldDto1());
		dto.setInitialRowNumber(0);
		dto.setInsurerName("name");
		dto.setIsLastProcess(true);
		dto.setMapList(getListOfMap1());
		dto.setPoolCountDetails(getPoolCountDetails());
		dto.setTotalRowInExcel(1);
		dto.setUploadAction("UPLOAD");
		dto.setUploadType("NORMAL");
		dto.setUserId("id");
		dto.setUserInfo(getUserInfo());
		return dto;
		
	}
	
	public static BulkImportFieldValidationDto getBulkImportFieldValidationDto2() {
		BulkImportFieldValidationDto dto = new BulkImportFieldValidationDto();
		dto.setBulkImportHistoryDto(getBulkImportHistoryDto());
		dto.setBulkImportMappingData(getListBulkImportMapping());
		dto.setFieldList(getListOfFieldDto());
		dto.setInitialRowNumber(0);
		dto.setInsurerName("name");
		dto.setIsLastProcess(true);
		dto.setMapList(getListOfMap());
		dto.setPoolCountDetails(getPoolCountDetails());
		dto.setTotalRowInExcel(1);
		dto.setUploadAction("REVOKE");
		dto.setUploadType("NORMAL");
		dto.setUserId("id");
		dto.setUserInfo(getUserInfo());
		return dto;
		
	}
	
	public static BulkImportFieldValidationDto getBulkImportFieldValidationDto3() {
		BulkImportFieldValidationDto dto = new BulkImportFieldValidationDto();
		dto.setBulkImportHistoryDto(getBulkImportHistoryDto());
		dto.setBulkImportMappingData(getListBulkImportMapping());
		dto.setFieldList(getListOfFieldDto2());
		dto.setInitialRowNumber(0);
		dto.setInsurerName("name");
		dto.setIsLastProcess(true);
		dto.setMapList(getListOfMap());
		dto.setPoolCountDetails(getPoolCountDetails());
		dto.setTotalRowInExcel(1);
		dto.setUploadAction("UPLOAD");
		dto.setUploadType("NORMAL");
		dto.setUserId("id");
		dto.setUserInfo(getUserInfo());
		return dto;
		
	}
	
	public static BulkImportFieldValidationDto getBulkImportFieldValidationDto4() {
		BulkImportFieldValidationDto dto = new BulkImportFieldValidationDto();
		dto.setBulkImportHistoryDto(getBulkImportHistoryDto());
		dto.setBulkImportMappingData(getListBulkImportMapping());
		dto.setFieldList(getListOfFieldDto1());
		dto.setInitialRowNumber(0);
		dto.setInsurerName("name");
		dto.setIsLastProcess(true);
		dto.setMapList(getListOfMap2());
		dto.setPoolCountDetails(getPoolCountDetails());
		dto.setTotalRowInExcel(1);
		dto.setUploadAction("UPLOAD");
		dto.setUploadType("NORMAL");
		dto.setUserId("id");
		dto.setUserInfo(getUserInfo());
		return dto;
		
	}
	
	
	 public static UserInfo getUserInfo() { 
		 UserInfo userInfo = new UserInfo(); 
		 UserType type = new UserType(); 
		 type.setUserTypeId(1); 
		 type.setUserTypeName("INSURANCE_COMPANY"); 
		 userInfo.setId(1); 
		 userInfo.setIdentity("tdfsgzx"); 
		 userInfo.setPlatformIdentity("sdascX"); 
		 userInfo.setUsername("name"); 
		 userInfo.setFirstTimeLogin(false); 
		 userInfo.setRoles(getUserRoleDtoList()); 	 
		 userInfo.setEmail("email");
		 userInfo.setUserTypeId(type);
		 userInfo.setPlatformDetailsDto(getPlatformDetails());		 
		 userInfo.setCompanyId(1);
		 return userInfo; 
		 }
	 
	 public static List<UserRoleDto> getUserRoleDtoList() {
		UserRoleDto userRoleDto = new UserRoleDto();
		userRoleDto.setRoleId(1);
		userRoleDto.setRoleName("manager");		
		return null;
	}
	 
	 public static PlatformDetailsDto getPlatformDetails() {
		 PlatformDetailsDto platformDetailsDto = new PlatformDetailsDto();
		 platformDetailsDto.setPlatformId(1);
		 platformDetailsDto.setPlatformIdentity("adalkdadiad");
		 platformDetailsDto.setPlatformName("DigitalPaper");
		 
		 return platformDetailsDto;
	 }
	 
	 public static FieldDto getFieldDto() {
		 FieldDto dto = new FieldDto();
		 dto.setAliasName("Digital paper");
		 dto.setFieldName("pdDigitalPaperId");
		 dto.setFieldType("String");
		 dto.setMandatory(true);
		 dto.setMaxLength(100);
		 dto.setMinLength(1);
		 dto.setRegex("^[a-zA-Z0-9 ]*$");
		 dto.setValue(null);
		 return dto;
	 }
	 
	 public static FieldDto getFieldDto1() {
		 FieldDto dto = new FieldDto();
		 dto.setAliasName("Policy Number");
		 dto.setFieldName("pdPolicyNumber");
		 dto.setFieldType("String");
		 dto.setMandatory(true);
		 dto.setMaxLength(100);
		 dto.setMinLength(1);
		 dto.setRegex("^[a-zA-Z0-9 ]*$");
		 dto.setValue(null);
		 return dto;
	 }
	 
	 public static FieldDto getFieldDto2() {
		 FieldDto dto = new FieldDto();
		 dto.setAliasName("Registration Number");
		 dto.setFieldName("vdRegistrationNumber");
		 dto.setFieldType("String");
		 dto.setMaxLength(100);
		 dto.setMinLength(1);
		 dto.setMandatory(true);
		 dto.setValue(null);
		 return dto;
	 }
	 
	 public static FieldDto getFieldDto3() {
		 FieldDto dto = new FieldDto();
		 dto.setAliasName("Chassis Number");
		 dto.setFieldName("vdChassis");
		 dto.setFieldType("String");
		 dto.setMandatory(true);
		 dto.setValue(null);
		 return dto;
	 }
	 
	 public static FieldDto getFieldDto4() {
		 FieldDto dto = new FieldDto();
		 dto.setAliasName("Insured Name");
		 dto.setFieldName("pdInsuredName");
		 dto.setFieldType("String");
		 dto.setMandatory(true);
		 dto.setValue(null);
		 return dto;
	 }
	 
	 public static FieldDto getFieldDto5() {
		 FieldDto dto = new FieldDto();
		 dto.setAliasName("Usage");
		 dto.setFieldName("vdUsage");
		 dto.setFieldType("String");
		 dto.setMandatory(true);
		 dto.setValue(null);
		 return dto;
	 }
	 
	 public static FieldDto getFieldDto6() {
		 FieldDto dto = new FieldDto();
		 dto.setAliasName("Licence to carry");
		 dto.setFieldName("vdLicensedToCarry");
		 dto.setFieldType("Integer");
		 dto.setMandatory(true);
		 dto.setValue(null);
		 return dto;
	 }
	 
	 public static FieldDto getFieldDto7() {
		 FieldDto dto = new FieldDto();
		 dto.setAliasName("Make");
		 dto.setFieldName("vdMake");
		 dto.setFieldType("String");
		 dto.setMandatory(true);
		 dto.setValue(null);
		 return dto;
	 }
	 
	 public static FieldDto getFieldDto8() {
		 FieldDto dto = new FieldDto();
		 dto.setAliasName("Model");
		 dto.setFieldName("vdModel");
		 dto.setFieldType("String");
		 dto.setMandatory(true);
		 dto.setValue(null);
		 return dto;
	 }
	 
	 public static FieldDto getFieldDto9() {
		 FieldDto dto = new FieldDto();
		 dto.setAliasName("Phone Number");
		 dto.setFieldName("pdPhoneNumber");
		 dto.setFieldType("String");
		 dto.setMandatory(true);
		 dto.setValue(null);
		 return dto;
	 }
	 
	 public static FieldDto getFieldDto10() {
		 FieldDto dto = new FieldDto();
		 dto.setAliasName("Email Id");
		 dto.setFieldName("pdEmailId");
		 dto.setFieldType("String");
		 dto.setMandatory(true);
		 dto.setValue(null);
		 return dto;
	 }
	 
	 public static FieldDto getFieldDto11() {
		 FieldDto dto = new FieldDto();
		 dto.setAliasName("Effective From");
		 dto.setFieldName("pdEffectiveFrom");
		 dto.setFieldType("fDate");
		 dto.setMandatory(true);
		 dto.setValue(null);
		 return dto;
	 }
	 
	 public static FieldDto getFieldDto12() {
		 FieldDto dto = new FieldDto();
		 dto.setAliasName("Expire Date");
		 dto.setFieldName("pdExpireDate");
		 dto.setFieldType("fDate");
		 dto.setMandatory(true);
		 dto.setValue(null);
		 return dto;
	 }
	 
	 public static List<FieldDto> getListOfFieldDto(){
		 List<FieldDto> list = new ArrayList<>();
		 list.add(getFieldDto());
		 list.add(getFieldDto1());
		 list.add(getFieldDto2());
		 list.add(getFieldDto3());
		 list.add(getFieldDto4());
		 list.add(getFieldDto5());
		 list.add(getFieldDto6());
		 list.add(getFieldDto7());
		 list.add(getFieldDto8());
		 list.add(getFieldDto9());
		 list.add(getFieldDto10());
		 list.add(getFieldDto11());
		 list.add(getFieldDto12());
		 return list;
	 }
	 public static List<FieldDto> getListOfFieldDto2(){
		 List<FieldDto> list = new ArrayList<>();
		 list.add(getFieldDto11());
		 list.add(getFieldDto12());
		 return list;
	 }
	 
	 public static List<FieldDto> getListOfFieldDto1(){
		 List<FieldDto> list = new ArrayList<>();
		 list.add(getFieldDto());
		 list.add(getFieldDto1());
		 list.add(getFieldDto2());
		 list.add(getFieldDto3());
		 list.add(getFieldDto4());
		 list.add(getFieldDto5());
		 list.add(getFieldDto6());
		 list.add(getFieldDto7());
		 list.add(getFieldDto8());
		 list.add(getFieldDto9());
		 list.add(getFieldDto10());
		 return list;
	 }
	 
	 public static List<Map<String,String>> getListOfMap1(){
			List<Map<String,String>> list = new ArrayList<>();
			Map<String,String> map = new HashMap<>();
			map.put("pdDigitalPaperId", "1");
			map.put("pdPolicyNumber", "PO886868");
			map.put("vdRegistrationNumber", "HA435JU787");
			map.put("vdChassis", "CH78568GG7868");
			map.put("pdInsuredName", "Insured");
			map.put("vdUsage", "PRIVATE");
			map.put("vdLicensedToCarry", "4");
			map.put("vdMake", "Honda");
			map.put("vdModel", "UI");
			map.put("pdPhoneNumber", "9898989898");
			map.put("pdEmailId", "email@email.com");
			list.add(map);
			return list;
		}
	 

		public static List<Map<String,String>> getListOfMap(){
			List<Map<String,String>> list = new ArrayList<>();
			Map<String,String> map = new HashMap<>();
			map.put("pdDigitalPaperId", "1");
			map.put("pdPolicyNumber", "PO886868");
			map.put("vdRegistrationNumber", "HA435JU787");
			map.put("vdChassis", "CH78568GG7868");
			map.put("pdInsuredName", "Insured");
			map.put("vdUsage", "PRIVATE");
			map.put("vdLicensedToCarry", "4");
			map.put("vdMake", "Honda");
			map.put("vdModel", "UI");
			map.put("pdPhoneNumber", "9898989898");
			map.put("pdEmailId", "email@email.com");
			map.put("pdEffectiveFrom", "11/01/2023");
			map.put("pdExpireDate", "11/02/2023");
			list.add(map);
			return list;
		}
		
		public static List<Map<String,String>> getListOfMap2(){
			List<Map<String,String>> list = new ArrayList<>();
			Map<String,String> map = new HashMap<>();
			map.put("pdDigitalPaperId", "1");
			map.put("pdPolicyNumber", "");
			map.put("vdRegistrationNumber", "HA435JU787");
			map.put("vdChassis", "CH78568GG7868");
			map.put("pdInsuredName", "Insured");
			map.put("vdUsage", "PRIVATE");
			map.put("vdLicensedToCarry", "4");
			map.put("vdMake", "Honda");
			map.put("vdModel", "UI");
			map.put("pdPhoneNumber", "9898989898");
			map.put("pdEmailId", "email@email.com");
			map.put("pdEffectiveFrom", "11/01/2023");
			map.put("pdExpireDate", "11/02/2023");
			list.add(map);
			return list;
		}
	 
	 public static PaperDetails getPaperDetails1() {
		 PaperDetails details = new PaperDetails();
		 details.setPdDigitalPaperId("1");
		 details.setPdEffectiveFrom(LocalDateTime.now());
		 details.setPdExpireDate(LocalDateTime.now());
		 details.setPdEmailId("email@email.com");
		 details.setPdInsuredName("Insured");
		 details.setPdPolicyNumber("PO886868");
		 details.setPdPhoneNumber("9898989898");
		 details.setVdRegistrationNumber("HA435JU787");
		 details.setVdChassis("CH78568GG7868");
		 details.setVdMake("Honda");
		 details.setVdModel("UI");
		 details.setVdLicensedToCarry("4");
		 details.setStatus(1);
		 
		 return details;
	 }
	 
	 public static PaperDetails getPaperDetails3() {
		 PaperDetails details = new PaperDetails();
		 details.setPdDigitalPaperId("1");
		 details.setPdEffectiveFrom(LocalDateTime.now());
		 details.setPdExpireDate(LocalDateTime.now());
		 details.setPdEmailId("email@email.com");
		 details.setPdInsuredName("Insured");
		 details.setPdPolicyNumber("PO886868");
		 details.setPdPhoneNumber("9898989898");
		 details.setVdRegistrationNumber("HA435JU787");
		 details.setVdChassis("CH78568GG7868");
		 details.setVdMake("Honda");
		 details.setVdModel("UI");
		 details.setVdLicensedToCarry("4");
		 details.setStatus(0);
		 
		 return details;
	 }
	 
	 public static PaperDetails getPaperDetails2() {
		 PaperDetails details = new PaperDetails();
		 details.setPdDigitalPaperId("1");
		 details.setPdEffectiveFrom(LocalDateTime.now());
		 details.setPdExpireDate(LocalDateTime.now());
		 details.setPdEmailId("email@email.com");
		 details.setPdInsuredName("Insured");
		 details.setPdPolicyNumber("PO8868680");
		 details.setPdPhoneNumber("9898989898");
		 details.setVdRegistrationNumber("HA435JU7870");
		 details.setVdChassis("CH78568GG7868");
		 details.setVdMake("Honda");
		 details.setVdModel("UI");
		 details.setVdLicensedToCarry("4");
		 
		 return details;
	 }
	 
	 public static BulkImportErrorTable getBulkImportErrorTable() {
		 BulkImportErrorTable bulkImportErrorTable = new BulkImportErrorTable();
		 bulkImportErrorTable.setErrorMessage("error_message");
		 bulkImportErrorTable.setFieldName("fieldName");
		 bulkImportErrorTable.setScratchId(1);
		 bulkImportErrorTable.setErrorId(1);
		 return bulkImportErrorTable;
	 }
	 
	 public static Scratch getScratch() {
		 Scratch scratch = new Scratch();
		 scratch.setBulkUploadId(1);
		 scratch.setCompanyId("1");
		 scratch.setPdEmailId("email@email.com");
		 scratch.setPdInsuredName("Insured");
		 scratch.setPdPolicyNumber("PO8868680");
		 scratch.setPdPhoneNumber("9898989898");
		 scratch.setVdRegistrationNumber("HA435JU7870");
		 scratch.setVdChassis("CH78568GG7868");
		 scratch.setVdMake("Honda");
		 scratch.setVdModel("UI");
		 scratch.setVdLicensedToCarry("4");
		 return scratch;
		 
	 }
	 
	 public static Scratch getScratch1() {
		 Scratch scratch = new Scratch();
		 scratch.setBulkUploadId(1);
		 scratch.setCompanyId("1");
		 scratch.setPdEmailId("email@email.com");
		 scratch.setPdInsuredName("Insured");
		 scratch.setPdPolicyNumber("PO8868680");
		 scratch.setPdPhoneNumber("9898989898");
		 scratch.setVdRegistrationNumber("HA435JU7870");
		 scratch.setVdChassis("CH78568GG7868");
		 scratch.setVdMake("Honda");
		 scratch.setVdModel("UI");
		 scratch.setVdLicensedToCarry("4");
		 return scratch;
		 
	 }
	 
	 public static ScratchDto getScratchDto() {
		 ScratchDto scratch = new ScratchDto();
		 scratch.setBulkUploadId(1);
		 scratch.setCompanyId("1");
		 scratch.setPdEmailId("email@email.com");
		 scratch.setPdInsuredName("Insured");
		 scratch.setPdPolicyNumber("PO8868680");
		 scratch.setPdPhoneNumber("9898989898");
		 scratch.setVdRegistrationNumber("HA435JU7870");
		 scratch.setVdChassis("CH78568GG7868");
		 scratch.setVdMake("Honda");
		 scratch.setVdModel("UI");
		 scratch.setVdLicensedToCarry("4");
		 return scratch;
		 
	 }
	 
	 public static StockPool getStockPool() {
		 return AllocationPoolMockData.getStockPool();
	 }
	

}
