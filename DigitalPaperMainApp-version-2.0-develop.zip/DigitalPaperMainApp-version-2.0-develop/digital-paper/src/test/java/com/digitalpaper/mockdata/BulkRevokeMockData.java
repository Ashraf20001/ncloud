//package com.digitalpaper.mockdata;
//
//import java.time.LocalDateTime;
//import java.util.ArrayList;
//import java.util.List;
//
//import com.digitalpaper.transfer.object.dto.BulkRevokeCountDto;
//import com.digitalpaper.transfer.object.dto.BulkRevokeDto;
//import com.digitalpaper.transfer.object.entity.BulkRevokeErrorTable;
//
//public class BulkRevokeMockData {
//
//	public static List<BulkRevokeDto> getBulkRevokeDto() {
//		List<BulkRevokeDto> list = new ArrayList<>();
//		BulkRevokeDto dto = new BulkRevokeDto();
//		LocalDateTime now = LocalDateTime.now();
//		dto.setErrorId(1);
//		dto.setDigitalPaperId("1");
//		dto.setPolicyNumber("123");
//		dto.setBulkImportHistoryId(1);
//		dto.setIdentity("q112");
//		dto.setStatus(1);;
//		dto.setCreatedBy(1);
//		dto.setModifiedBy(1);
//		dto.setModifiedDate(now);
//		dto.setCreatedDate(now);
//		list.add(dto);
//		return list;
//	}
//	
//	public static BulkRevokeCountDto getCountDto() {
//		BulkRevokeCountDto dto = new BulkRevokeCountDto();
//		dto.setTotalCount(10l);
//		dto.setSuccessCount(5l);
//		dto.setErrorCount(1l);
//		return dto;
//	}
//	
//	public static List<BulkRevokeErrorTable> getRevokeScratch() {
//		List<BulkRevokeErrorTable> list = new ArrayList<>();
//		BulkRevokeErrorTable entity = new BulkRevokeErrorTable();
//		LocalDateTime now = LocalDateTime.now();
//		entity.setErrorId(1);
//		entity.setDigitalPaperId("1");
//		entity.setPolicyNumber("123");
//		entity.setBulkImportHistoryId(1);
//		entity.setIdentity("123");
//		entity.setIsDeleted(false);
//		entity.setStatus(1);
//		entity.setErrorMessage("a");
//		entity.setCreatedBy(1);
//		entity.setModifiedBy(1);
//		entity.setModifiedDate(now);
//		entity.setCreatedDate(now);
//		list.add(entity);
//		return list;
//	}
//	
//	public static BulkRevokeErrorTable getDataForIdentity() {
//		BulkRevokeErrorTable entity = new BulkRevokeErrorTable();
//		LocalDateTime now = LocalDateTime.now();
//		entity.setErrorId(1);
//		entity.setDigitalPaperId("1");
//		entity.setPolicyNumber("123");
//		entity.setBulkImportHistoryId(1);
//		entity.setIdentity("123");
//		entity.setIsDeleted(false);
//		entity.setStatus(1);
//		entity.setErrorMessage("a");
//		entity.setCreatedBy(1);
//		entity.setModifiedBy(1);
//		entity.setModifiedDate(now);
//		entity.setCreatedDate(now);
//		return entity;
//	}
//}
