package com.digitalpaper.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.modelmapper.ModelMapper;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.config.DigitalPaperCache;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.IAuthorityPaperDetailsDao;
import com.digitalpaper.dao.IStockDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.mockdata.AuthorityPaperDetailsMockData;
import com.digitalpaper.mockdata.PaperDetailsMockData;
import com.digitalpaper.mockdata.PurchaseHistoryMockData;
import com.digitalpaper.restemplate.service.IRestTemplateService;
import com.digitalpaper.service.impl.AuthorityPaperDetailsServiceImpl;
import com.digitalpaper.transfer.object.dto.AuthorityStockDto;
import com.digitalpaper.transfer.object.dto.CompanyDto;
import com.digitalpaper.transfer.object.dto.CompanyTransactionDto;
import com.digitalpaper.transfer.object.dto.CompanyViewDto;
import com.digitalpaper.transfer.object.dto.DownloadListVo;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.entity.UserType;
import com.digitalpaper.transfer.object.enums.PaperDetailsStatusEnum;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;
import com.digitalpaper.utils.core.ApplicationUtils;

import mockDatas.MockData;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@ContextConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class AuthorityPaperDetailsServiceTest {

	@InjectMocks
	private AuthorityPaperDetailsServiceImpl serviceMock;
	
	@Mock
	private IStockDao daoMock;
	
	@Mock
	private IRestTemplateService iRestTemplateServiceMock;
	
	@Mock
	private LoggedInUserContextHolder loggedInUserContextHolder;
	
	@Mock
	private IAuthorityPaperDetailsDao iAuthorityPaperDetailsDao;
	
	@Mock
	private DigitalPaperCache digitalPaperCache;
	
	@Test
	public void getAuthorityPaperCount() {
		Long value = 10l;
		List<FilterOrSortingVo> filter = PurchaseHistoryMockData.getFilterOrSorting();
		Map<Integer, String> companyNameMap = PurchaseHistoryMockData.getComMap();
		List<AuthorityStockDto> dto = AuthorityPaperDetailsMockData.getAuthorityStockDtoList();
		try {
			UserInfo user = PurchaseHistoryMockData.getUserInfo();
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(user);
			when(daoMock.getStockAndCountList(companyNameMap, 0, 10, filter, Boolean.TRUE)).thenReturn(dto);
			when(serviceMock.getStockCount(filter)).thenReturn(value);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	public void getAuthorityPaperCount_ErrorFlow() {
		List<FilterOrSortingVo> filterVo = PurchaseHistoryMockData.getFilterOrSorting();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseHistoryMockData.getUserInfo1());
			ApplicationException ap = new ApplicationException(ErrorCodes.UN_AUTHORIZED);
			ApplicationException exception = assertThrows(ApplicationException.class, () -> {
				serviceMock.getStockCount(filterVo);
			});
			assertEquals(ap.toString(), exception.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	

	@Test
	public void getAuthorityPaperList() {
		List<CompanyDto> value = PurchaseHistoryMockData.getCompanyViewDto();
		Map<Integer, String> companyNameMap = PurchaseHistoryMockData.getComMap();
		List<FilterOrSortingVo> filterVo = PurchaseHistoryMockData.getFilterOrSorting();
		List<AuthorityStockDto> dto = AuthorityPaperDetailsMockData.getAuthorityStockDtoList();
		List<AuthorityStockDto> dto1 = AuthorityPaperDetailsMockData.getAuthorityStockDtoForObject();
		Object obj = AuthorityPaperDetailsMockData.getObj();
		HashMap<Integer, String> companyIdNameMockData = MockData.companyIdNameMockData();
		ModelMapper map = new ModelMapper();
		Long[] i = null;
		i=map.map(obj, Long[].class);
//		 Object[] i =AuthorityPaperDetailsMockData.getTotalStockCount();
		try {
			UserInfo user = PurchaseHistoryMockData.getUserInfo();
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(user);
//			when(iRestTemplateServiceMock.getCompanyList(filterVo)).thenReturn(value);
			when(digitalPaperCache.getCompanyList()).thenReturn(companyIdNameMockData);
			when(daoMock.getStockAndCountList(companyNameMap, 0, 10, filterVo, null)).thenReturn(dto);
			when(daoMock.getTotalStockCount()).thenReturn((i));
			assertNotNull(serviceMock.getStockData(0, 10, filterVo));
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	public void getAuthorityPaperList_ErrorFlow() {
		List<FilterOrSortingVo> filterVo = PurchaseHistoryMockData.getFilterOrSorting();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseHistoryMockData.getUserInfo1());
			ApplicationException ap = new ApplicationException(ErrorCodes.UN_AUTHORIZED);
			ApplicationException exception = assertThrows(ApplicationException.class, () -> {
				serviceMock.getStockData(1, 10, filterVo);
			});
			assertEquals(ap.toString(), exception.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	public void getPaperDetailsByCompanyCount() {
		UserInfo user = PurchaseHistoryMockData.getUserInfo();
		CompanyTransactionDto companyTranDto = AuthorityPaperDetailsMockData.getCompanyTransactionDto();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(user);
			when(iAuthorityPaperDetailsDao.getPaperDetailsCountByCompany(companyTranDto)).thenReturn(10l);
			when(serviceMock.getPaperDetailsByCompanyCount(companyTranDto)).thenReturn(10l);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void getPaperDetailsByCompanyCount_ErrorFlow() {
		CompanyTransactionDto companyTranDto = AuthorityPaperDetailsMockData.getCompanyTransactionDto();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseHistoryMockData.getUserInfo1());
			ApplicationException ap = new ApplicationException(ErrorCodes.UN_AUTHORIZED);
			ApplicationException exception = assertThrows(ApplicationException.class, () -> {
				serviceMock.getPaperDetailsByCompanyCount(companyTranDto);
			});
			assertEquals(ap.toString(), exception.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	public void getPaperDetailsByCompanyList() {
		List<CompanyDto> value = PurchaseHistoryMockData.getCompanyViewDto();
		CompanyTransactionDto companyTranDto = AuthorityPaperDetailsMockData.getCompanyTransactionDto();
		List<PaperDetails> paperDetails = PaperDetailsMockData.getPaperDetails();
		List<PaperDetailsDto> paperDetailsDto = PaperDetailsMockData.getPaperDetailsDto();
//		List<FilterOrSortingVo> filterList = new ArrayList<FilterOrSortingVo>();
		HashMap<Integer, String> companyIdNameMockData = MockData.companyIdNameMockData();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseHistoryMockData.getUserInfo());
//			when(iRestTemplateServiceMock.getCompanyList(filterList)).thenReturn(value);
			when(digitalPaperCache.getCompanyList()).thenReturn(companyIdNameMockData);
			when(iAuthorityPaperDetailsDao.getPaperDetailsByCompanyList(companyTranDto)).thenReturn(paperDetails);
			when(serviceMock.getPaperDetailsByCompanyList(companyTranDto)).thenReturn(paperDetailsDto);			
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	public void getPaperDetailsByCompanyList_ErrorFlow() {
		CompanyTransactionDto companyTranDto = AuthorityPaperDetailsMockData.getCompanyTransactionDto();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseHistoryMockData.getUserInfo1());
			ApplicationException ap = new ApplicationException(ErrorCodes.UN_AUTHORIZED);
			ApplicationException exception = assertThrows(ApplicationException.class, () -> {
				serviceMock.getPaperDetailsByCompanyList(companyTranDto);
			});
			assertEquals(ap.toString(), exception.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	
	

	@Test
	public void downloadPaperInExcel() throws ApplicationException {
		DownloadListVo downloadVo = AuthorityPaperDetailsMockData.getDownloadListVo();
		List<String> columnList = AuthorityPaperDetailsMockData.getDownloadListVo().getColumnList();
		List<FilterOrSortingVo> filter = AuthorityPaperDetailsMockData.getDownloadListVo().getFilterVo();
		Map<Integer, String> companyNameMap = PurchaseHistoryMockData.getComMap();

		Long stockCount = 10l;
		Integer skip = 0;
		Integer limit = 10;
		List<CompanyDto> value = PurchaseHistoryMockData.getCompanyViewDto();
		Object obj = AuthorityPaperDetailsMockData.getObj();
		ModelMapper map = new ModelMapper();
		Long[] i = null;
		i = map.map(obj, Long[].class);

		List<AuthorityStockDto> stockData = AuthorityPaperDetailsMockData.getAuthorityStockDtoList();

		ArrayList<HashMap<String, Object>> excelDataList = AuthorityPaperDetailsMockData.getExcelDataList();

		UserInfo user = PurchaseHistoryMockData.getUserInfo();
		
		HashMap<Integer, String> companyIdNameMockData = MockData.companyIdNameMockData();


		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(user);
//			when(iRestTemplateServiceMock.getCompanyList(filterList)).thenReturn(value);
			when(digitalPaperCache.getCompanyList()).thenReturn(companyIdNameMockData);
			when(daoMock.getStockAndCountList(companyNameMap, 0, 0, filter, Boolean.TRUE)).thenReturn(stockData);
			when(daoMock.getTotalStockCount()).thenReturn((i));
			serviceMock.downloadPaperInExcel(downloadVo);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}

	}
				
	@Test
	public void downloadViewPaper() throws ApplicationException {
		
		 MockHttpServletRequest request = new MockHttpServletRequest();
		    request.setParameter("firstName", "Spring");
		    request.setParameter("lastName", "Test");
		    
		List<String> entityColumnNames = AuthorityPaperDetailsMockData.getEntityColumnNames();
		List<FilterOrSortingVo> filter = PurchaseHistoryMockData.getFilterOrSorting();
		List<Integer> companyId = AuthorityPaperDetailsMockData.getCompanyId();
		List<String> columnList = AuthorityPaperDetailsMockData.getDownloadListVo().getColumnList();
		DownloadListVo downloadVo = AuthorityPaperDetailsMockData.getDownloadListVo();
		 List<String> excelHeaderList = AuthorityPaperDetailsMockData.getMetaDataList();
		when(iRestTemplateServiceMock.getMetaDataList(anyString(), any(HttpServletRequest.class))).thenReturn(AuthorityPaperDetailsMockData.getMetaDataList());
		when(iAuthorityPaperDetailsDao.getPaperDetailsList(anyList(), anyList())).thenReturn(AuthorityPaperDetailsMockData.getPaperDetailsList());
		 
		 
//		 List<String> excelHeaderList =
				 AuthorityPaperDetailsMockData.getExcelHeaderList();
		 List<String> entityColumnList=AuthorityPaperDetailsMockData.getEntityColumnList();
//		 ArrayList<HashMap<String, Object>> excelDataList =
				 Map<String, String> mapColumnName =  AuthorityPaperDetailsMockData.getMapColumnName();
//				 List<String> selectEntityColumn =  AuthorityPaperDetailsMockData.getSelectEntityColumn();
				 
					List<Integer> companyIdList = AuthorityPaperDetailsMockData.getCompanyIdList();
					List<Object[]> getPaperDetailsData = AuthorityPaperDetailsMockData.getPaperDetailsList();
					ArrayList<HashMap<String, Object>> excelDataList = AuthorityPaperDetailsMockData.getExcelDataList();
					HashMap<String,Object> excelDataMap = AuthorityPaperDetailsMockData.getExcelDataMap();
		 serviceMock.downloadViewPaper(downloadVo, request);
	}
	
	@Test
	public void getStockTableCount() {
		try {
		when(iAuthorityPaperDetailsDao.getStockTableCount()).thenReturn(anyLong());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
