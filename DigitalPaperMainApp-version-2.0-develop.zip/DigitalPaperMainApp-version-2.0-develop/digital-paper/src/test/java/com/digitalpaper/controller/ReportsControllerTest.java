package com.digitalpaper.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletResponse;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.service.ReportsService;
import com.digitalpaper.test.DigitalPaperUnitTest;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.ReportsDto;
import com.digitalpaper.utils.core.ApplicationUtils;

import mockDatas.MockData;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class ReportsControllerTest extends DigitalPaperUnitTest {

	@InjectMocks
	private ReportsController controller;

	@Mock
	private ReportsService serviceMock;

	@Test
	void getReportData_Happy_Flow() {

		try {
			when(serviceMock.getReportDetailsInCard()).thenReturn(MockData.getReportListMock());
			ApplicationResponse actualResult = controller.getReportData();
		} catch (ApplicationException e) {

			e.printStackTrace();
		}
	}

	@Test
	void saveReportData_Happy_Flow() {

		try {
			doNothing().when(serviceMock).saveReportCardData(MockData.getReportsDtoMock());
			controller.saveReportData(MockData.getReportsDtoMock());
		} catch (ApplicationException e) {

			e.printStackTrace();
		}

	}
	
	@Test
	void saveReportData_Error_Flow() {
		try {
			doNothing().when(serviceMock).saveReportCardData(null);
			controller.saveReportData(MockData.getReportsDtoMock());
		} catch (ApplicationException e) {

			Assertions.fail(e.toString());
		}

	}

	@Test
	void getReportDateBasedOnIdentity_Happy_Flow() {
		String Identity = "98347rh487ry47ry";
		try {
			when(serviceMock.getReportDataBasedOneIdentity(Identity)).thenReturn(MockData.getReportsDtoMock());
			ApplicationResponse actualResult = controller.getReportDateBasedOnIdentity(Identity);
		} catch (ApplicationException e) {

			e.printStackTrace();
		}
	}

	@Test
	void getReportDateBasedOnIdentity_Error_Flow() {
		String Identity = null;
		try {
			when(serviceMock.getReportDataBasedOneIdentity(anyString())).thenReturn(MockData.getReportsDtoMock());
			ApplicationResponse actualResult = controller.getReportDateBasedOnIdentity(Identity);
		} catch (ApplicationException e) {

			Assertions.fail(e.toString());
		}
	}

	
	@Test
	void ReportCardUpdate_Happy_Flow() {
		try {
			doNothing().when(serviceMock).UpdateValues(MockData.getReportsDtoMock());
			controller.ReportCardUpdate(MockData.getReportsDtoMock());
		} catch (ApplicationException e) {

			e.printStackTrace();
		}
	}
	
	@Test
	void ReportCardUpdate_Error_Flow() {
		ReportsDto data = MockData.getReportsDtoNullMock();
		try {
			doNothing().when(serviceMock).UpdateValues(data);
			if(ApplicationUtils.isValidateObject(data)) {
				controller.ReportCardUpdate(MockData.getReportsDtoMock());
				assertNotNull(controller);
				
			}
		} catch (ApplicationException e) {

			Assertions.fail(e.toString());
		}
	}


	@Test
	void getPreviewDate_Happy_Flow() {
		try {
			when(serviceMock.getReviewReportData(MockData.getPreviewReportDtoDtoMock()))
					.thenReturn(MockData.getPreviewReportDtoDtoMock());
			ApplicationResponse actualResult = controller.getPreviewDate(MockData.getPreviewReportDtoDtoMock());

		} catch (ApplicationException e) {

			e.printStackTrace();
		}
	}

	@Test
	void getPurchaseOrderColumnList_Happy_Flow() {

		try {
			when(serviceMock.getReportPurchaseOrderColumnList()).thenReturn(MockData.getListOfStringDtoMock());
			ApplicationResponse actualResult = controller.getPurchaseOrderColumnList();
		} catch (ApplicationException e) {

			e.printStackTrace();
		}
	}

	@Test
	void getDigitalPaperColumnList_Happy_Flow() {
		try {
			when(serviceMock.getDigitalPaperColumn()).thenReturn(MockData.getListOfStringDtoMock());
			ApplicationResponse actualResult = controller.getDigitalPaperColumnList();
		} catch (ApplicationException e) {

			e.printStackTrace();
		}

	}
	
	@Test
	void getInsuranceCompanyList_Happy_Flow() {
		try {
			when(serviceMock.getInsuredCompanyName()).thenReturn(MockData.getListOfStringDtoMock());
			ApplicationResponse actualResult = controller.getInsuranceCompanyList();
		} catch (ApplicationException e) {
			
			e.printStackTrace();
		}
		
	}
	
	@Test 
	void exportReportAsExcel_Happy_Flow() {
		HttpHeaders header = new HttpHeaders();
		ResponseEntity<ByteArrayResource> response = new ResponseEntity<ByteArrayResource>(any(ByteArrayResource.class),header,HttpStatus.CREATED);
		
		try {
			when(serviceMock.getReviewReportData(MockData.getPreviewReportDtoDtoMock())).thenReturn(MockData.getPreviewReportDtoDtoMock());
			when(serviceMock.downloadExcelReport(MockData.getPreviewReportDtoDtoMock())).thenReturn(response);
			response = controller.exportReportAsExcel(MockData.getPreviewReportDtoDtoMock());
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test 
	void exportReportAsCSV_Happy_Flow() throws Exception {
		HttpHeaders header = new HttpHeaders();
		ResponseEntity<ByteArrayResource> response = new ResponseEntity<ByteArrayResource>(any(ByteArrayResource.class),header,HttpStatus.CREATED);
		HttpServletResponse httpServer = null;
		try {
			when(serviceMock.getReviewReportData(MockData.getPreviewReportDtoDtoMock())).thenReturn(MockData.getPreviewReportDtoDtoMock());
			when(serviceMock.writeReportsToCsv(MockData.getPreviewReportDtoDtoMock(),httpServer)).thenReturn(response);
			response = controller.exportReportAsCSV(MockData.getPreviewReportDtoDtoMock(),httpServer);
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test 
	void exportReportAsPdf_Happy_Flow() throws Exception {
		HttpHeaders header = new HttpHeaders();
		ResponseEntity<ByteArrayResource> response = new ResponseEntity<ByteArrayResource>(any(ByteArrayResource.class),header,HttpStatus.CREATED);
		
		try {
			when(serviceMock.getReviewReportData(MockData.getPreviewReportDtoDtoMock())).thenReturn(MockData.getPreviewReportDtoDtoMock());
			when(serviceMock.downloadReportAsPdf(MockData.getPreviewReportDtoDtoMock())).thenReturn(response);
			response = controller.exportReportAsPdf(MockData.getPreviewReportDtoDtoMock());
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
