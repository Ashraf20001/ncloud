//package com.digitalpaper.servicetest;
//
//import static org.mockito.Mockito.when;
//
//import java.util.List;
//
//import org.assertj.core.api.Assertions;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//import org.springframework.test.context.web.WebAppConfiguration;
//
//import com.digitalpaper.DigitalPaperApplication;
//import com.digitalpaper.config.model.FilterOrSortingVo;
//import com.digitalpaper.dao.IBulkRevokeDao;
//import com.digitalpaper.mockdata.BulkRevokeMockData;
//import com.digitalpaper.mockdata.PurchaseHistoryMockData;
//import com.digitalpaper.service.impl.BulkRevokeServiceImpl;
//import com.digitalpaper.transfer.object.dto.BulkRevokeCountDto;
//import com.digitalpaper.transfer.object.dto.BulkRevokeDto;
//import com.digitalpaper.transfer.object.entity.BulkRevokeErrorTable;
//
//@ExtendWith(SpringExtension.class)
//@WebAppConfiguration
//@ContextConfiguration
//@SpringBootTest(classes = DigitalPaperApplication.class)
//public class BulkRevokeServiceTest {
//
//	@InjectMocks
//	private BulkRevokeServiceImpl bulkRevokeServiceImplMock;
//
//	@Mock
//	private IBulkRevokeDao iBulkRevokeDaoMock;
//
//	@Test
//	public void getBulkScratchCount() {
//		Long val = 10l;
//		List<FilterOrSortingVo> filter = PurchaseHistoryMockData.getFilterOrSorting();
//		try {
//			when(iBulkRevokeDaoMock.getRevokeScratchCount(filter)).thenReturn(val);
//			when(bulkRevokeServiceImplMock.getRevokeScratchCount(filter)).thenReturn(val);
//		} catch (Exception e) {
//			Assertions.fail(e.toString());
//		}
//	}
//
//	@Test
//	public void getBulkScratchData() {
//		List<FilterOrSortingVo> filter = PurchaseHistoryMockData.getFilterOrSorting();
//		List<BulkRevokeDto> dto = BulkRevokeMockData.getBulkRevokeDto();
//		List<BulkRevokeErrorTable> entity = BulkRevokeMockData.getRevokeScratch();
//		try {
//			when(iBulkRevokeDaoMock.getRevokeScratchData(1, 10, filter)).thenReturn(entity);
//			when(bulkRevokeServiceImplMock.getRevokeScratchData(1, 10, filter)).thenReturn(dto);
//		} catch (Exception e) {
//			Assertions.fail(e.toString());
//		}
//	}
//̥
//	@Test
//	public void getSuccessErrorCount() {
//		BulkRevokeCountDto dto = BulkRevokeMockData.getCountDto();
//		try {
//			when(iBulkRevokeDaoMock.getSuccesErrorCount()).thenReturn(dto);
//			when(bulkRevokeServiceImplMock.getSuccessErrorCount()).thenReturn(dto);
//		} catch (Exception e) {
//			Assertions.fail(e.toString());
//		}
//	}
//	
//	@Test
//	public void deleteBulkRevoke() {
//		BulkRevokeErrorTable entity = BulkRevokeMockData.getDataForIdentity();
//		try {
//			when(iBulkRevokeDaoMock.getBulkRevokeForDelete("123")).thenReturn(entity);
//			when(iBulkRevokeDaoMock.updateBulkRevoke(entity)).thenReturn(entity);
//			when(bulkRevokeServiceImplMock.deleteBulkRevoke("123")).thenReturn("123");
//		} catch (Exception e) {
//			Assertions.fail(e.toString());
//		}
//	}
//}
