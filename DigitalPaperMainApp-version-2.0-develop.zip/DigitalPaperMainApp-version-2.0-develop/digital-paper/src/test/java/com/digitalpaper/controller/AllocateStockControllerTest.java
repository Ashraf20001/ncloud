package com.digitalpaper.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.mockdata.AllocateStockMockData;
import com.digitalpaper.service.AllocationStockService;
import com.digitalpaper.transfer.object.dto.AllocationStockDto;
import com.digitalpaper.transfer.object.dto.StockCountDto;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class AllocateStockControllerTest {

	@InjectMocks
	private AllocateStockController controllerMock;
	
	@Mock
	private AllocationStockService serviceMock;
	
	@Test
	public void getStockCountForAllocationStock() {
		try {
			when(serviceMock.getStockCountForAllocationStock(1)).thenReturn(AllocateStockMockData.getStockCountDto());
			StockCountDto result = controllerMock.getStockCountForAllocationStock(1);
			assertNotNull(result);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
}
