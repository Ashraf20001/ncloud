package com.digitalpaper.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.mockdata.PaperDetailsMockData;
import com.digitalpaper.restemplate.service.IDigitalPaperSevice;
import com.digitalpaper.test.DigitalPaperUnitTest;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.DigitalPaperDto;
import com.digitalpaper.transfer.object.dto.FieldGroup;

import mockDatas.MockData;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class DigitalPaperControllerTest extends DigitalPaperUnitTest{

	
	@InjectMocks
	private DigitalPaperController controller;
	
	@Mock
	private IDigitalPaperSevice serviceMock;
	
	@Test
	public void saveDigitalPaper_Happy_flow() {
		Boolean isRollback = false;
		try {
			when(serviceMock.updateStockPaperCount(isRollback, 1)).thenReturn(MockData.StockMockData());
			try {
				when(serviceMock.saveDigitalPaper(MockData.getFieldGroupData())).thenReturn("success");
				controller.saveDigitalPaper(MockData.getFieldGroupData());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ApplicationException e) {
			
			e.printStackTrace();
		}
	}
	
	@Test
	public void saveDigitalPaper_Error_flow() {
		Boolean isRollback = false;
		try {
			when(serviceMock.updateStockPaperCount(isRollback, 1)).thenReturn(MockData.StockMockData());
			try {
				when(serviceMock.saveDigitalPaper(MockData.getFieldGroupData())).thenReturn(null);
				when(serviceMock.updateStockPaperCount(true, 1)).thenReturn(MockData.StockMockData1());
				controller.saveDigitalPaper(MockData.getFieldGroupData());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ApplicationException e) {
			
			e.printStackTrace();
		}
	}
	
	@Test
	public void getpaperDetails_Happy_Flow() {
		try {
			when(serviceMock.getpaperDetails("9w387riweufyiuer")).thenReturn(PaperDetailsMockData.getDetails());
			ApplicationResponse actualResult = controller.getpaperDetails("9w387riweufyiuer");
			assertNotNull(actualResult);
		} catch (ApplicationException e) {
			Assertions.fail(e.toString());
		}
	}
}
