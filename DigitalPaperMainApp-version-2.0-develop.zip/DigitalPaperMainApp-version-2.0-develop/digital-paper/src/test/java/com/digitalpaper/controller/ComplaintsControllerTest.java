package com.digitalpaper.controller;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.service.IComplaintsService;
import com.digitalpaper.transfer.object.core.ApplicationResponse;

import mockDatas.MockData;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class ComplaintsControllerTest {
	
	@InjectMocks
	private ComplaintsController complaintsController;
	
	@Mock
	private IComplaintsService serviceMock;
	
	@Test
	 void saveComplaints_Happy_Flow() {
		
		
		try {
			doNothing().when(serviceMock).saveComplaintsDetails(MockData.getComplaintsDtoMock());
			complaintsController.saveComplaints(MockData.getComplaintsDtoMock());
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
		
	}
	
	@Test
	void getComplaints_Happy_Flow() {
		try {
			when(serviceMock.getComplaintsDetails()).thenReturn(MockData.getComplainDtoListMock());
			ApplicationResponse actualResult = complaintsController.getComplaints();
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

}
