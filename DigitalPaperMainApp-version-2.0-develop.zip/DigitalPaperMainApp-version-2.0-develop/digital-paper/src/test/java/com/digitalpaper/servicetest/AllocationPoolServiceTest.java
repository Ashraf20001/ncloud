package com.digitalpaper.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.modelmapper.ModelMapper;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.client.RestTemplate;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.config.property.EnvironmentProperties;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.mockdata.AllocationPoolMockData;
import com.digitalpaper.mockdata.PurchaseOrderMockData;
import com.digitalpaper.purchasestock.dao.AllocationPoolDao;
import com.digitalpaper.service.impl.AllocationPoolServiceImpl;
import com.digitalpaper.transfer.object.dto.AllocationUserTypeDto;
import com.digitalpaper.transfer.object.dto.AllocationUserTypeList;
import com.digitalpaper.transfer.object.dto.StockDto;
import com.digitalpaper.transfer.object.entity.Stock;
import com.digitalpaper.transfer.object.entity.StockPool;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;
import com.digitalpaper.utils.core.RestTemplateUtils;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class AllocationPoolServiceTest {
	
	public static final String BASE_URL = "http://10.10.10.43:9090/api/get-role-page-info";
	public static final String AUTHORIZATION = "Authorization";
	public static final String SAVED = "Saved Successfully!!";
	public static final String PLATFORM_ID = "platformId";
	public static final String DUMMY_URL = "127.0.0.1";
	public static final String TEST = "test";

	
	@InjectMocks
	private AllocationPoolServiceImpl allocationPoolService;
	
	@Mock
	private AllocationPoolDao allocationPoolDao;
	
	@Mock
	private LoggedInUserContextHolder loggedInUserContextHolder;
	
	@Mock
	private ModelMapper modelMapper;
	
	@Mock
	private RestTemplateUtils restTemplateUtils;
	
	@Mock
	private EnvironmentProperties environmentProperties;
	
	@Mock
	private RestTemplate restTemplate;
	
	
	@Test
	void updatePoolCountByPoolAction_happy_flow() {
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo1());
			when(allocationPoolDao.getStockByCompanyId(anyInt())).thenReturn(AllocationPoolMockData.getStock());
			when(allocationPoolDao.getStockPoolById(anyInt(), any(Integer.class))).thenReturn(AllocationPoolMockData.getStockPool());
			doNothing().when(allocationPoolDao).updateStock(any(Stock.class));
			doNothing().when(allocationPoolDao).updateStockPool(any(StockPool.class));
			when(modelMapper.map(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any())).thenReturn(AllocationPoolMockData.getStockDto());
			StockDto actual = allocationPoolService.updatePoolCountByPoolAction(AllocationPoolMockData.getPoolDto());
			assertEquals(AllocationPoolMockData.getStockDto().getCompanyId(), actual.getCompanyId());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void updatePoolCountByPoolAction_happy_flow1() {
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo1());
			when(allocationPoolDao.getStockByCompanyId(anyInt())).thenReturn(AllocationPoolMockData.getStock());
			when(allocationPoolDao.getStockPoolById(anyInt(), any(Integer.class))).thenReturn(AllocationPoolMockData.getStockPool());
			doNothing().when(allocationPoolDao).updateStock(any(Stock.class));
			doNothing().when(allocationPoolDao).updateStockPool(any(StockPool.class));
			when(modelMapper.map(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any())).thenReturn(AllocationPoolMockData.getStockDto());
			StockDto actual = allocationPoolService.updatePoolCountByPoolAction(AllocationPoolMockData.getPoolDto1());
			assertEquals(AllocationPoolMockData.getStockDto().getCompanyId(), actual.getCompanyId());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	
	@Test
	void updatePoolCountByPoolAction_happy_flow2() {
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo1());
			when(allocationPoolDao.getStockByCompanyId(anyInt())).thenReturn(AllocationPoolMockData.getStock());
			when(allocationPoolDao.getStockPoolById(anyInt(), any(Integer.class))).thenReturn(AllocationPoolMockData.getStockPool());
			doNothing().when(allocationPoolDao).updateStock(any(Stock.class));
			doNothing().when(allocationPoolDao).updateStockPool(any(StockPool.class));
			when(modelMapper.map(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any())).thenReturn(AllocationPoolMockData.getStockDto());
			StockDto actual = allocationPoolService.updatePoolCountByPoolAction(AllocationPoolMockData.getPoolDto2());
			assertEquals(AllocationPoolMockData.getStockDto().getCompanyId(), actual.getCompanyId());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void updatePoolCountByPoolAction_error_flow1() {
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo1());
			ApplicationException ap = new ApplicationException(ErrorCodes.INVALID_STOCK);
            ApplicationException
                    exception = assertThrows(ApplicationException.class, () -> {
                    	allocationPoolService.updatePoolCountByPoolAction(AllocationPoolMockData.getPoolDto2());
            });
            assertEquals(ap.toString(),exception.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void updatePoolCountByPoolAction_error_flow2() {
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo1());
			when(allocationPoolDao.getStockByCompanyId(anyInt())).thenReturn(AllocationPoolMockData.getStock());
			ApplicationException ap = new ApplicationException(ErrorCodes.INVALID_STOCK_POOL);
            ApplicationException
                    exception = assertThrows(ApplicationException.class, () -> {
                    	allocationPoolService.updatePoolCountByPoolAction(AllocationPoolMockData.getPoolDto2());
            });
            assertEquals(ap.toString(),exception.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void updatePoolCountByPoolAction_error_flow3() {
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo1());
			when(allocationPoolDao.getStockByCompanyId(anyInt())).thenReturn(AllocationPoolMockData.getStock());
			when(allocationPoolDao.getStockPoolById(anyInt(), any(Integer.class))).thenReturn(AllocationPoolMockData.getStockPool());
			ApplicationException ap = new ApplicationException(ErrorCodes.INVALID_ACTION);
            ApplicationException
                    exception = assertThrows(ApplicationException.class, () -> {
                    	allocationPoolService.updatePoolCountByPoolAction(AllocationPoolMockData.getPoolDto3());
            });
            assertEquals(ap.toString(),exception.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	
	@Test
	void updatePoolCountByPoolAction_error_flow4() {
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo1());
			when(allocationPoolDao.getStockByCompanyId(anyInt())).thenReturn(AllocationPoolMockData.getStock());
			when(allocationPoolDao.getStockPoolById(anyInt(), any(Integer.class))).thenReturn(AllocationPoolMockData.getStockPool());
			ApplicationException ap = new ApplicationException(ErrorCodes.INSUFFICIENT_STOCK);
            ApplicationException
                    exception = assertThrows(ApplicationException.class, () -> {
                    	allocationPoolService.updatePoolCountByPoolAction(AllocationPoolMockData.getPoolDto4());
            });
            assertEquals(ap.toString(),exception.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getStockPoolFromIdentity_happy_flow() {
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo1());
			when(allocationPoolDao.getStockPoolFromIdentity(anyString())).thenReturn(AllocationPoolMockData.getStockPool());
			when(modelMapper.map(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any())).thenReturn(AllocationPoolMockData.getStockDto());
			StockDto stockPoolFromIdentity = allocationPoolService.getStockPoolFromIdentity("id");
			assertEquals(stockPoolFromIdentity.getCompanyId(), AllocationPoolMockData.getStockDto().getCompanyId());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getStockPoolFromIdentity_error_flow() {
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo1());
			when(allocationPoolDao.getStockPoolFromIdentity(anyString())).thenReturn(null);
			when(modelMapper.map(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any())).thenReturn(AllocationPoolMockData.getStockDto());
			ApplicationException ex = new ApplicationException(ErrorCodes.INVALID_STOCK_POOL);
			ApplicationException
            exception = assertThrows(ApplicationException.class, () -> {
            	allocationPoolService.getStockPoolFromIdentity("id");
            });
			 assertEquals(ex.toString(),exception.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void changeStockPoolStatus_happy_Flow() {
		try {
			when(allocationPoolDao.getStockPoolFromIdentity(anyString())).thenReturn(AllocationPoolMockData.getStockPool());
			doNothing().when(allocationPoolDao).updateStock(any(Stock.class));
			allocationPoolService.changeStockPoolStatus(false, "id");
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void changeStockPoolStatus_error_Flow() {
		try {
			when(allocationPoolDao.getStockPoolFromIdentity(anyString())).thenReturn(null);
			ApplicationException ex = new ApplicationException(ErrorCodes.INVALID_STOCK_POOL);
			ApplicationException
            exception = assertThrows(ApplicationException.class, () -> {
            	allocationPoolService.changeStockPoolStatus(false,"id");
            });
			 assertEquals(ex.toString(),exception.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getStockPoolCount_happy_flow() {
		AllocationUserTypeList expected = AllocationPoolMockData.getAllocationUserTypeList();
		String baseUrl=BASE_URL;
		try {
			MockHttpServletRequest request = new MockHttpServletRequest();
			request.addHeader(AUTHORIZATION,DUMMY_URL);
	          
	      	HttpHeaders httpHeaders = new HttpHeaders();
	        httpHeaders.add(TEST, TEST);
        	
        	when(restTemplateUtils.configureRestTemplate(request)).thenReturn(httpHeaders);
        	ResponseEntity<AllocationUserTypeList> entity=new ResponseEntity<AllocationUserTypeList>(expected,HttpStatus.ACCEPTED);
        	 when(restTemplate.exchange(ArgumentMatchers.anyString(),
	                    ArgumentMatchers.any(HttpMethod.class),
	                    ArgumentMatchers.any(), 
	                    eq(AllocationUserTypeList.class))).thenReturn(entity);
        	 when(environmentProperties.getCommonServicePath()).thenReturn(baseUrl);
        	 Integer stockPoolCount = allocationPoolService.getStockPoolCount(request);
        	 assertEquals(stockPoolCount, 1);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getAllStockPool_happy_Flow() {
		AllocationUserTypeList expected = AllocationPoolMockData.getAllocationUserTypeList();
		String baseUrl=BASE_URL;
		try {
			MockHttpServletRequest request = new MockHttpServletRequest();
			request.addHeader(AUTHORIZATION,DUMMY_URL);
	          
	      	HttpHeaders httpHeaders = new HttpHeaders();
	        httpHeaders.add(TEST, TEST);
        	
        	when(restTemplateUtils.configureRestTemplate(request)).thenReturn(httpHeaders);
        	ResponseEntity<AllocationUserTypeList> entity=new ResponseEntity<AllocationUserTypeList>(expected,HttpStatus.ACCEPTED);
        	 when(restTemplate.exchange(ArgumentMatchers.anyString(),
	                    ArgumentMatchers.any(HttpMethod.class),
	                    ArgumentMatchers.any(), 
	                    eq(AllocationUserTypeList.class))).thenReturn(entity);
        	 when(environmentProperties.getCommonServicePath()).thenReturn(baseUrl);


			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo1());
			when(allocationPoolDao.getAllStockPoolList(anyString(), anyInt(),anyList(), anyInt(), anyInt())).thenReturn(AllocationPoolMockData.getListStockPool());
			when(modelMapper.map(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any())).thenReturn(AllocationPoolMockData.getStockDto());
			List<StockDto> allStockPool = allocationPoolService.getAllStockPool("id",request, AllocationPoolMockData.getFilterOrSortingVoList(),0,10);
			
			assertEquals(allStockPool.get(0).getCompanyId(), 1);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getAllStockPool_happy_Flow1() {
		AllocationUserTypeList expected = AllocationPoolMockData.getAllocationUserTypeList();
		String baseUrl=BASE_URL;
		try {
			MockHttpServletRequest request = new MockHttpServletRequest();
			request.addHeader(AUTHORIZATION,DUMMY_URL);
	          
	      	HttpHeaders httpHeaders = new HttpHeaders();
	        httpHeaders.add(TEST, TEST);
        	
        	when(restTemplateUtils.configureRestTemplate(request)).thenReturn(httpHeaders);
        	ResponseEntity<AllocationUserTypeList> entity=new ResponseEntity<AllocationUserTypeList>(expected,HttpStatus.ACCEPTED);
        	 when(restTemplate.exchange(ArgumentMatchers.anyString(),
	                    ArgumentMatchers.any(HttpMethod.class),
	                    ArgumentMatchers.any(), 
	                    eq(AllocationUserTypeList.class))).thenReturn(entity);
        	 when(environmentProperties.getCommonServicePath()).thenReturn(baseUrl);


			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo1());
			when(allocationPoolDao.getAllStockPoolList(anyString(), anyInt(),anyList(), anyInt(), anyInt())).thenReturn(AllocationPoolMockData.getListStockPool());
			when(modelMapper.map(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any())).thenReturn(AllocationPoolMockData.getStockDto());
			List<StockDto> allStockPool = allocationPoolService.getAllStockPool("id",request, AllocationPoolMockData.getFilterOrSortingVoList1(),0,10);
			
			assertEquals(allStockPool.get(0).getCompanyId(), 1);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getAllStockPool_happy_Flow2() {
		AllocationUserTypeList expected = AllocationPoolMockData.getAllocationUserTypeList();
		String baseUrl=BASE_URL;
		try {
			MockHttpServletRequest request = new MockHttpServletRequest();
			request.addHeader(AUTHORIZATION,DUMMY_URL);
	          
	      	HttpHeaders httpHeaders = new HttpHeaders();
	        httpHeaders.add(TEST, TEST);
        	
        	when(restTemplateUtils.configureRestTemplate(request)).thenReturn(httpHeaders);
        	ResponseEntity<AllocationUserTypeList> entity=new ResponseEntity<AllocationUserTypeList>(expected,HttpStatus.ACCEPTED);
        	 when(restTemplate.exchange(ArgumentMatchers.anyString(),
	                    ArgumentMatchers.any(HttpMethod.class),
	                    ArgumentMatchers.any(), 
	                    eq(AllocationUserTypeList.class))).thenReturn(entity);
        	 when(environmentProperties.getCommonServicePath()).thenReturn(baseUrl);


			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo1());
			when(allocationPoolDao.getAllStockPoolList(anyString(), anyInt(),anyList(), anyInt(), anyInt())).thenReturn(AllocationPoolMockData.getListStockPool());
			when(modelMapper.map(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any())).thenReturn(AllocationPoolMockData.getStockDto());
			List<StockDto> allStockPool = allocationPoolService.getAllStockPool("id",request, AllocationPoolMockData.getFilterOrSortingVoList2(),0,10);
			
			assertEquals(allStockPool.get(0).getCompanyId(), 1);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	
	@Test
	void getAllStockPool_happy_Flow3() {
		AllocationUserTypeList expected = AllocationPoolMockData.getAllocationUserTypeList();
		String baseUrl=BASE_URL;
		try {
			MockHttpServletRequest request = new MockHttpServletRequest();
			request.addHeader(AUTHORIZATION,DUMMY_URL);
	          
	      	HttpHeaders httpHeaders = new HttpHeaders();
	        httpHeaders.add(TEST, TEST);
        	
        	when(restTemplateUtils.configureRestTemplate(request)).thenReturn(httpHeaders);
        	ResponseEntity<AllocationUserTypeList> entity=new ResponseEntity<AllocationUserTypeList>(expected,HttpStatus.ACCEPTED);
        	 when(restTemplate.exchange(ArgumentMatchers.anyString(),
	                    ArgumentMatchers.any(HttpMethod.class),
	                    ArgumentMatchers.any(), 
	                    eq(AllocationUserTypeList.class))).thenReturn(entity);
        	 when(environmentProperties.getCommonServicePath()).thenReturn(baseUrl);


			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo1());
			when(allocationPoolDao.getAllStockPoolList(anyString(), anyInt(),anyList(), anyInt(), anyInt())).thenReturn(AllocationPoolMockData.getListStockPool());
			when(modelMapper.map(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any())).thenReturn(AllocationPoolMockData.getStockDto());
			List<StockDto> allStockPool = allocationPoolService.getAllStockPool("id",request, AllocationPoolMockData.getFilterOrSortingVoList3(),0,10);
			
			assertEquals(allStockPool.get(0).getCompanyId(), 1);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getAllStockPool_happy_Flow4() {
		AllocationUserTypeList expected = AllocationPoolMockData.getAllocationUserTypeList();
		String baseUrl=BASE_URL;
		try {
			MockHttpServletRequest request = new MockHttpServletRequest();
			request.addHeader(AUTHORIZATION,DUMMY_URL);
	          
	      	HttpHeaders httpHeaders = new HttpHeaders();
	        httpHeaders.add(TEST, TEST);
        	
        	when(restTemplateUtils.configureRestTemplate(request)).thenReturn(httpHeaders);
        	ResponseEntity<AllocationUserTypeList> entity=new ResponseEntity<AllocationUserTypeList>(expected,HttpStatus.ACCEPTED);
        	 when(restTemplate.exchange(ArgumentMatchers.anyString(),
	                    ArgumentMatchers.any(HttpMethod.class),
	                    ArgumentMatchers.any(), 
	                    eq(AllocationUserTypeList.class))).thenReturn(entity);
        	 when(environmentProperties.getCommonServicePath()).thenReturn(baseUrl);


			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo1());
			when(allocationPoolDao.getAllStockPoolList(anyString(), anyInt(),anyList(), anyInt(), anyInt())).thenReturn(AllocationPoolMockData.getListStockPool());
			when(modelMapper.map(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any())).thenReturn(AllocationPoolMockData.getStockDto());
			List<StockDto> allStockPool = allocationPoolService.getAllStockPool("id",request, AllocationPoolMockData.getFilterOrSortingVoList4(),0,10);
			
			assertEquals(allStockPool.get(0).getCompanyId(), 1);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getAllStockPool_happy_Flow5() {
		AllocationUserTypeList expected = AllocationPoolMockData.getAllocationUserTypeList();
		String baseUrl=BASE_URL;
		try {
			MockHttpServletRequest request = new MockHttpServletRequest();
			request.addHeader(AUTHORIZATION,DUMMY_URL);
	          
	      	HttpHeaders httpHeaders = new HttpHeaders();
	        httpHeaders.add(TEST, TEST);
        	
        	when(restTemplateUtils.configureRestTemplate(request)).thenReturn(httpHeaders);
        	ResponseEntity<AllocationUserTypeList> entity=new ResponseEntity<AllocationUserTypeList>(expected,HttpStatus.ACCEPTED);
        	 when(restTemplate.exchange(ArgumentMatchers.anyString(),
	                    ArgumentMatchers.any(HttpMethod.class),
	                    ArgumentMatchers.any(), 
	                    eq(AllocationUserTypeList.class))).thenReturn(entity);
        	 when(environmentProperties.getCommonServicePath()).thenReturn(baseUrl);


			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo1());
			when(allocationPoolDao.getAllStockPoolList(anyString(), anyInt(),anyList(), anyInt(), anyInt())).thenReturn(AllocationPoolMockData.getListStockPool());
			when(modelMapper.map(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any())).thenReturn(AllocationPoolMockData.getStockDto());
			List<StockDto> allStockPool = allocationPoolService.getAllStockPool("id",request, AllocationPoolMockData.getFilterOrSortingVoList5(),0,10);
			
			assertEquals(allStockPool.get(0).getCompanyId(), 1);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	

}
