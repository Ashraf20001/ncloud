package com.digitalpaper.mockdata;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.transfer.object.dto.AssociationDashboardCountDto;
import com.digitalpaper.transfer.object.dto.CompanyTransactionDto;
import com.digitalpaper.transfer.object.dto.PaymentDetailsDto;
import com.digitalpaper.transfer.object.dto.PlatformDetailsDto;
import com.digitalpaper.transfer.object.dto.PurchaseOrderDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.dto.UserRoleDto;
import com.digitalpaper.transfer.object.dto.ViewHistoryDto;
import com.digitalpaper.transfer.object.entity.PaymentDetails;
import com.digitalpaper.transfer.object.entity.PurchaseOrderEntity;
import com.digitalpaper.transfer.object.entity.Stock;
import com.digitalpaper.transfer.object.entity.StockFileMapping;
import com.digitalpaper.transfer.object.entity.UserType;

public class PurchaseOrderMockData {

	public static PurchaseOrderDto getPurchaseOrderDto() {
		PurchaseOrderDto purchaseOrderDto = new PurchaseOrderDto();
		purchaseOrderDto.setCompanyId(2);
		purchaseOrderDto.setPaymentStatus(ApplicationConstants.SUCCESS);
		purchaseOrderDto.setPurchaseAmount(null);
		purchaseOrderDto.setPurchaseId("ass1");
		purchaseOrderDto.setTransactionId("TXN001");
		purchaseOrderDto.setPurchaseDate(LocalDateTime.now());
		purchaseOrderDto.setStockCount(180);
		purchaseOrderDto.setPaymentMethod("Cash");
		return purchaseOrderDto;
	}

	public static List<PurchaseOrderDto> getPurchaseOrderDtoList() {
		List<PurchaseOrderDto> purchaseList = new ArrayList<PurchaseOrderDto>();
		purchaseList.add(getPurchaseOrderDto());
		return purchaseList;
	}

	public static PaymentDetailsDto getPaymentDetailsDto() {
		PaymentDetailsDto detailsDto = new PaymentDetailsDto();
		detailsDto.setActionButton("SUCCESS");
		detailsDto.setCompanyName("AXA");
		detailsDto.setNoOfPapers("1000");
		detailsDto.setPaymentStatus("SUCCESS");
		detailsDto.setPaymentType("cash");
		detailsDto.setPurchaseAmount("10000");
		detailsDto.setPurchaseId("PO123");
		detailsDto.setTransactionId("TRAN123");
		return detailsDto;
	}

	public static PaymentDetailsDto getPaymentDetailsDto1() {
		PaymentDetailsDto detailsDto = new PaymentDetailsDto();
		detailsDto.setActionButton("FAILED");
		detailsDto.setCompanyName("AXA");
		detailsDto.setNoOfPapers("1000");
		detailsDto.setPaymentStatus("FAILED");
		detailsDto.setPaymentType("cash");
		detailsDto.setPurchaseAmount("10000");
		detailsDto.setPurchaseId("PO123");
		detailsDto.setTransactionId("TRAN123");
		return detailsDto;
	}

	public static PaymentDetailsDto getPaymentDetailsDto3() {
		PaymentDetailsDto detailsDto = new PaymentDetailsDto();
		detailsDto.setActionButton("SUBMITTED");
		detailsDto.setCompanyName("AXA");
		detailsDto.setNoOfPapers("1000");
		detailsDto.setPaymentStatus("SUBMITTED");
		detailsDto.setPaymentType("cash");
		detailsDto.setPurchaseAmount("10000");
		detailsDto.setPurchaseId("PO123");
		detailsDto.setTransactionId("TRAN123");
		return detailsDto;
	}

	public static PaymentDetailsDto getPaymentDetailsDto4() {
		PaymentDetailsDto detailsDto = new PaymentDetailsDto();
		detailsDto.setActionButton("SUBMITTED");
		detailsDto.setCompanyName("AXA");
		detailsDto.setNoOfPapers("1000");
		detailsDto.setPaymentStatus("SUBMITTED");
		detailsDto.setPaymentType("paytm");
		detailsDto.setPurchaseAmount("10000");
		detailsDto.setPurchaseId("PO123");
		detailsDto.setTransactionId("TRAN123");
		return detailsDto;
	}

	  public static UserInfo getUserInfo() {
	    	UserInfo userInfo = new UserInfo();
	    	UserType type = new UserType();
	    	type.setUserTypeId(1);
	    	type.setUserTypeName("ASSOCIATION");

	    	PlatformDetailsDto detailsDto = new PlatformDetailsDto();
	    	detailsDto.setPlatformId(2);
	    	detailsDto.setPlatformIdentity("identity");
	    	detailsDto.setPlatformName("DIGITAL_PAPER");

	    	userInfo.setId(1);
	    	userInfo.setIdentity("tdfsgzx");
	    	userInfo.setPlatformIdentity("sdascX");
	    	userInfo.setUsername("name");
	    	userInfo.setFirstTimeLogin(false);
	    	userInfo.setRoles(getUserRoleDtoList());
	    	userInfo.setEmail("email");
	    	userInfo.setUserTypeId(type);
	    	userInfo.setPlatformDetailsDto(detailsDto);
	    	userInfo.setCompanyId(2);
	    	return userInfo;
	    }

	  public static UserInfo getUserInfo1() {
	    	UserInfo userInfo = new UserInfo();
	    	UserType type = new UserType();
	    	type.setUserTypeId(1);
	    	type.setUserTypeName("INSURANCE_COMPANY");

	    	PlatformDetailsDto detailsDto = new PlatformDetailsDto();
	    	detailsDto.setPlatformId(2);
	    	detailsDto.setPlatformIdentity("identity");
	    	detailsDto.setPlatformName("DIGITAL_PAPER");

	    	userInfo.setId(1);
	    	userInfo.setIdentity("tdfsgzx");
	    	userInfo.setPlatformIdentity("sdascX");
	    	userInfo.setUsername("name");
	    	userInfo.setFirstTimeLogin(false);
	    	userInfo.setRoles(getUserRoleDtoList());
	    	userInfo.setEmail("email");
	    	userInfo.setUserTypeId(type);
	    	userInfo.setPlatformDetailsDto(detailsDto);
	    	userInfo.setCompanyId(1);
	    	userInfo.setAllocationUserType(1);
	    	return userInfo;
	    }

	  public static List<UserRoleDto> getUserRoleDtoList() {
	        List<UserRoleDto> userRoleDtos = new ArrayList<>();
	        userRoleDtos.add(getUserRoleDto());
	        return userRoleDtos;
	    }

	  public static UserRoleDto getUserRoleDto() {
	        return new UserRoleDto(1,"Admin");
	    }

	  public static PaymentDetails getPaymentDetails() {
		  PaymentDetails details = new PaymentDetails();
		  details.setId(1);
		  details.setIdentity("identity");
		  details.setIsDeleted(false);
		  details.setPaidAmount("USD");
		  details.setPaymentMode(1);
		  details.setPaymentStatus(2);
		  details.setTransactionId("TRAN123");
		  details.setOrderId(getPurchaseOrderEntity());
		  details.setPaymentDate(LocalDateTime.now());
		  return details;
	  }

	  public static PurchaseOrderEntity getPurchaseOrderEntity() {
		  PurchaseOrderEntity purchaseOrderEntity = new PurchaseOrderEntity();
		  purchaseOrderEntity.setIdentity("identity");
		  purchaseOrderEntity.setIsDeleted(false);
		  purchaseOrderEntity.setOrderAmt("USD");
		  purchaseOrderEntity.setOrderId(1);
		  purchaseOrderEntity.setOrderStatus(2);
//		  purchaseOrderEntity.setOrderNo("PO123");
		  purchaseOrderEntity.setPurchaseId("pur123");
		  purchaseOrderEntity.setStockCount(10000);
		  purchaseOrderEntity.setPaymentMethod(1);
		  purchaseOrderEntity.setCompanyId(2);
		  return purchaseOrderEntity;
	  }

	  public static List<PaymentDetails> getListOfPaymentDetails(){
		  List<PaymentDetails> list = new ArrayList<>();
		  list.add(getPaymentDetails());
		  return list;
	  }

	  public static FilterOrSortingVo getFilterOrSortingVo() {
		  FilterOrSortingVo vo = new FilterOrSortingVo();
		  List<String> valueList=new ArrayList<String>();
		  valueList.add("Cheque");
		  vo.setColumnName("paymentMethod");
		  vo.setCondition("Equal");
		  vo.setFilterOrSortingType("FILTER");
		  vo.setType("Integer");
		  vo.setValueList(valueList);
		  return vo;
	  }

	  public static List<FilterOrSortingVo> getListFilterOrSortingVo(){
		  List<FilterOrSortingVo> list = new ArrayList<>();
		  list.add(getFilterOrSortingVo());
		  return list;

	  }

	  public static List<PurchaseOrderEntity> getPurchaseOrderEntityList(){
		  List<PurchaseOrderEntity> purchaseOrderEntityList= new ArrayList<PurchaseOrderEntity>();
		  purchaseOrderEntityList.add(getPurchaseOrderEntity());
		  return purchaseOrderEntityList;
	  }
	  
	  public static Object[] getObjectArray() {
		  Object[] object= {"PO001","TRANS001",300,LocalDateTime.now(),2,"500",1,2,1};
		  return object;
	  }

	  public static List<Object[]> getScratchTableObject() {
		  List<Object[]> objectList=new ArrayList<>();
		  Object[] object= {"PO001","AXA insurance",LocalDateTime.now(),LocalDateTime.now(),1,1};
		  objectList.add(object);
		  return objectList;
	  }
	  public static List<Object[]> getListObject(){
		  List<Object[]> objectList=new ArrayList<>();
		  objectList.add(getObjectArray());
		  return objectList;
	  }
	  
	  public static StockFileMapping getStockFileMapping() {
		  StockFileMapping stockFileMapping = new StockFileMapping();
		  stockFileMapping.setId(1);
		  stockFileMapping.setIdentity("adjaldsd");
		  stockFileMapping.setOrderId(getPurchaseOrderEntity());
		  stockFileMapping.setStorageId(12);
		  
		  return stockFileMapping;
		  
	  }
	  
	  public static List <AssociationDashboardCountDto> getAssociationDashboardCountDto() {
		  AssociationDashboardCountDto associationDashboardCountDto = new  AssociationDashboardCountDto();
		  associationDashboardCountDto.setCount(1);
		  associationDashboardCountDto.setStatus(2);
		  
		    List<AssociationDashboardCountDto> dashboardCountList = new ArrayList<>();
		    dashboardCountList.add(associationDashboardCountDto);
		    
		    return dashboardCountList;
			
		}
	  

	  public static ArrayList<HashMap<String,Object>> getArrayListHashmapData(){
		  ArrayList<HashMap<String, Object>> arrayList = new ArrayList<HashMap<String,Object>>();
		  
		  HashMap<String, Object> dataHashMap = new HashMap<String, Object>();
		  dataHashMap.put(TableConstants.PURCHASE_ID,"PO000005");
		  dataHashMap.put(TableConstants.COMPANY_NAME, "Axa insurance");
		  dataHashMap.put(TableConstants.TRANSACTION_ID, "TN0000259");
		  
		  arrayList.add(dataHashMap);
		  return arrayList;
	  }
	  
	  public static  Stock getStock() {
		  Stock stock = new Stock();
		  stock.setCompanyId(2);
		  stock.setCreatedBy(3);
		  stock.setCreatedDate(LocalDateTime.now());
		  stock.setIdentity("ffff");
		  stock.setIsDeleted(true);
		  stock.setModifiedBy(4);
		  stock.setModifiedDate(LocalDateTime.now());
		  stock.setStockCount(10);
		  stock.setStockId(1);
		  stock.setUsedCount(2);
		  
		  return stock;
		  
		  
		  
	  }
	   //down naga
	  
	  public static ViewHistoryDto getViewHistoryDto() {
		  
		  ViewHistoryDto viewHistoryDto = new ViewHistoryDto();
		  viewHistoryDto.setCompanyName("axa");
		  viewHistoryDto.setFileMappingId(1);
		  viewHistoryDto.setOrderId(3);
		  viewHistoryDto.setOrderStatus(4);
		  viewHistoryDto.setPaymentMethod("cash");
		  viewHistoryDto.setPurchaseAmount("100");
		  viewHistoryDto.setPurchaseDate("12/03/22");
		  viewHistoryDto.setPurchaseId("2");
		  viewHistoryDto.setStockCount(20);
		  viewHistoryDto.setTransactionId("cxcc");
		  
		  return viewHistoryDto;
		  
		  }
	  
	  public static ArrayList<HashMap<String, Object>> getDataList(){
		  ArrayList<HashMap<String, Object>> DataList = new ArrayList<HashMap<String, Object>>();
		  HashMap<String, Object> map = new   HashMap<String, Object>();
		  map.put(TableConstants.PURCHASR_ID, "P0012");
		  map.put(TableConstants.COMPANY_NAME, "ABC");
		  
		  map.put(TableConstants.TRANSACTION_ID, "P002");
		  map.put(TableConstants.DATEOF_PURCHASE, "17051996");
		  map.put(TableConstants.PURCHASE_AMT, "45");
		  
		  map.put(TableConstants.PAYMENT_METHOD, "card");
		  map.put(TableConstants.PAYMENT_STATUS, "active");
		  DataList.add(map);
		  return DataList;
		  
	  }
	  
	  public static List<String> getColumnList(){
		  List<String> columnList = new  ArrayList<String>();
		  columnList.add("Purchase Id");
		  columnList.add("company name");
		  columnList.add("Transaction ID");
		  columnList.add("Date of Purchase");
		  columnList.add("NO.of Papers");
		  columnList.add("Purchase Amount");
		  columnList.add("Payment Method");
		  columnList.add("Payment Status");
		  return columnList;
		  
	  }
	  
}
	  
	  //down naga
	  
//	  public static ViewHistoryDto getViewHistoryDto() {
//
//}

