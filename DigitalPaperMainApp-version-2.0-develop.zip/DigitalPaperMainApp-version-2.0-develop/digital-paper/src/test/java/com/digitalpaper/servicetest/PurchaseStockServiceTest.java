package com.digitalpaper.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.modelmapper.ModelMapper;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.client.RestTemplate;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.config.DigitalPaperCache;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.config.property.EnvironmentProperties;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.IStockDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.mockdata.PurchaseHistoryMockData;
import com.digitalpaper.mockdata.PurchaseOrderMockData;
import com.digitalpaper.purchasestock.dao.PurchaseStockDao;
import com.digitalpaper.restemplate.service.IRestTemplateService;
import com.digitalpaper.service.IPurchaseHistoryService;
import com.digitalpaper.service.IStockNotificationSevice;
import com.digitalpaper.service.impl.PurchaseStockServiceImpl;
import com.digitalpaper.transfer.object.dto.CompanyTransactionDto;
import com.digitalpaper.transfer.object.dto.PurchaseOrderDto;
import com.digitalpaper.transfer.object.dto.ViewHistoryDto;
import com.digitalpaper.transfer.object.entity.PaymentDetails;
import com.digitalpaper.transfer.object.entity.PurchaseOrderEntity;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;
import com.digitalpaper.utils.core.RestTemplateUtils;

import mockDatas.MockData;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class PurchaseStockServiceTest {

	@InjectMocks
	private PurchaseStockServiceImpl purchaseStockServiceImpl;

	@Mock
	private PurchaseStockDao purchaseStockDao;

	@Mock
	private RestTemplateUtils restTemplateUtils;

	@Mock
	private RestTemplate restTemplate;
	@Mock
	private EnvironmentProperties environmentProperties;

	@Mock
	private LoggedInUserContextHolder loggedInUserContextHolder;

	@Mock
	private ModelMapper modelMapper;

	@Mock
	private IStockNotificationSevice notificationSevice;

	@Mock
	private IPurchaseHistoryService purchaseHistoryService;

	@Mock
	private IRestTemplateService iRestTemplateService;
	
	@Mock
	private DigitalPaperCache digitalPaperCache;

	@Mock
	private IStockDao stockDao;

	@Test
	void approveOrRejectPurchaseDetails_happyFlow() {
		String expected = ApplicationConstants.UPDATE_SUCESS;
		PurchaseOrderEntity purchaseOrderEntity = PurchaseOrderMockData.getPurchaseOrderEntity();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo());

			when(purchaseStockDao.getPaymentDetailsByOrderId(any(Integer.class)))
					.thenReturn(PurchaseOrderMockData.getPaymentDetails());
			when(purchaseStockDao.getPurchaseOrderFromPurchaseId(anyString()))
					.thenReturn(PurchaseOrderMockData.getPurchaseOrderEntity());
			doNothing().when(purchaseStockDao).updatePaymentDetails(any(PaymentDetails.class));
			doNothing().when(purchaseStockDao).updatePurchaseOrder(any(PurchaseOrderEntity.class));
			doNothing().when(notificationSevice).saveNotification(any(String.class), any(PurchaseOrderDto.class));
			when(modelMapper.map(purchaseOrderEntity, PurchaseOrderDto.class))
					.thenReturn(PurchaseOrderMockData.getPurchaseOrderDto());
			when(stockDao.getStockData(anyInt())).thenReturn(PurchaseOrderMockData.getStock());
			doNothing().when(stockDao).updateStock(PurchaseOrderMockData.getStock());
			String actual = purchaseStockServiceImpl
					.approveOrRejectPurchaseDetails(PurchaseOrderMockData.getPaymentDetailsDto());
			assertEquals(expected, actual);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	void approveOrRejectPurchaseDetails_happyFlow2() {
		String expected = ApplicationConstants.UPDATE_SUCESS;
		PurchaseOrderEntity purchaseOrderEntity = PurchaseOrderMockData.getPurchaseOrderEntity();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo());
			when(purchaseStockDao.getPaymentDetailsByOrderId(any(Integer.class)))
					.thenReturn(PurchaseOrderMockData.getPaymentDetails());
			when(purchaseStockDao.getPurchaseOrderFromPurchaseId(anyString()))
					.thenReturn(PurchaseOrderMockData.getPurchaseOrderEntity());
			doNothing().when(purchaseStockDao).updatePaymentDetails(any(PaymentDetails.class));
			doNothing().when(purchaseStockDao).updatePurchaseOrder(any(PurchaseOrderEntity.class));
			doNothing().when(notificationSevice).saveNotification(any(String.class), any(PurchaseOrderDto.class));
			when(modelMapper.map(purchaseOrderEntity, PurchaseOrderDto.class))
					.thenReturn(PurchaseOrderMockData.getPurchaseOrderDto());
			String actual = purchaseStockServiceImpl
					.approveOrRejectPurchaseDetails(PurchaseOrderMockData.getPaymentDetailsDto1());
			assertEquals(expected, actual);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	void approveOrRejectPurchaseDetails_error_Flow() {
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo1());
			ApplicationException ap = new ApplicationException(ErrorCodes.UN_AUTHORIZED);
			ApplicationException exception = assertThrows(ApplicationException.class, () -> {
				purchaseStockServiceImpl.approveOrRejectPurchaseDetails(PurchaseOrderMockData.getPaymentDetailsDto1());
			});
			assertEquals(ap.toString(), exception.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	void approveOrRejectPurchaseDetails_error_Flow1() {
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo1());
			when(purchaseStockDao.getPaymentDetailsByOrderId(any(Integer.class)))
					.thenReturn(PurchaseOrderMockData.getPaymentDetails());
			when(purchaseStockDao.getPurchaseOrderFromPurchaseId(anyString()))
					.thenReturn(PurchaseOrderMockData.getPurchaseOrderEntity());
			ApplicationException ap = new ApplicationException(ErrorCodes.UN_AUTHORIZED);
			ApplicationException exception = assertThrows(ApplicationException.class, () -> {
				purchaseStockServiceImpl.approveOrRejectPurchaseDetails(PurchaseOrderMockData.getPaymentDetailsDto4());
			});
			assertEquals(ap.toString(), exception.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	void getTransactionDetails_happy_flow() {
		List<ViewHistoryDto> historyDtoList = MockData.getViewHistoryDtoList();
		HashMap<Integer, String> companyIdNameMockData = MockData.companyIdNameMockData();

		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo());
//			when(iRestTemplateService.getCompanyList(filterList)).thenReturn(PurchaseHistoryMockData.getCompanyViewDto());
			when(digitalPaperCache.getCompanyList()).thenReturn(companyIdNameMockData);
			when(purchaseStockDao.getPaymentDetailsByFilter(any()))
					.thenReturn(PurchaseOrderMockData.getListOfPaymentDetails());
//			when(purchaseStockDao.getPaymentDetailsByFilter(MockData.getCompanyTransactionDto())).thenReturn(PurchaseOrderMockData.getListOfPaymentDetails());
			List<ViewHistoryDto> actual = purchaseStockServiceImpl
					.getTransactionDetails(MockData.getCompanyTransactionDto());
			assertNotNull(actual);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void getPurchaseList_HappyFlow() {
		Integer companyId = 2;
		Integer min = 0;
		Integer max = 10;
		List<PurchaseOrderDto> actual;
		List<Object[]> expected;

		try {
			expected = PurchaseOrderMockData.getListObject();
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo());
			when(purchaseStockDao.getPurchaseOrderList(companyId, min, max, null)).thenReturn(expected);
			actual = purchaseStockServiceImpl.getPurchaseList(min, max, null);
			assertNotNull(actual);
		} catch (ApplicationException e) {
			Assertions.fail(e.toString());
		}

	}

	@Test
	public void getPurchaseCount_HappyFlow() throws ApplicationException {
		Integer companyId = 2;
		Long expected = 23L;
		List<FilterOrSortingVo> filter = PurchaseOrderMockData.getListFilterOrSortingVo();

		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo());
			when(purchaseStockDao.getPurchaseOrderCount(companyId, filter)).thenReturn(expected);
			Long actual = purchaseStockServiceImpl.getPurchaseOrderCount(filter);
			assertEquals(actual, expected);
		} catch (ApplicationException e) {
			Assertions.fail(e.toString());
		}

	}

	@Test
	public void getAllPurchaseCount_HappyFlow() {
		CompanyTransactionDto companyTransaction = MockData.getCompanyTransactionDto();
		Long expected = 23L;
		try {
			when(purchaseStockDao.getPaymentDetailsCount(companyTransaction)).thenReturn(expected);
			Long actual = purchaseStockServiceImpl.getAllPurchaseOrderCount(companyTransaction);
			assertEquals(actual, expected);
		} catch (ApplicationException e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void getAllPurchaseCount_ErrorFlow() {
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo1());
			ApplicationException ap = new ApplicationException(ErrorCodes.UN_AUTHORIZED);
			ApplicationException exception = assertThrows(ApplicationException.class, () -> {
				purchaseStockServiceImpl.getTransactionDetails(MockData.getCompanyTransactionDto());
			});
			assertEquals(ap.toString(), exception.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void getAllPurchaseCount_ErrorFlow1() {
		CompanyTransactionDto companyTransaction = null;
		ApplicationException ap = new ApplicationException(ErrorCodes.INVALID_DATA);
		ApplicationException exception = assertThrows(ApplicationException.class, () -> {
			purchaseStockServiceImpl.getAllPurchaseOrderCount(companyTransaction);
		});
		assertEquals(ap.toString(), exception.toString());
	}

	@Test
	public void getAllPurchaseCount_ErrorFlow2() {
		CompanyTransactionDto companyTransaction = MockData.getCompanyTransactionDto();
		companyTransaction.setCompanyId(null);
		ApplicationException ap = new ApplicationException(ErrorCodes.INVALID_SELECTION);
		ApplicationException exception = assertThrows(ApplicationException.class, () -> {
			purchaseStockServiceImpl.getAllPurchaseOrderCount(companyTransaction);
		});
		assertEquals(ap.toString(), exception.toString());
	}

	@Test
	public void getStockFileId() {
		Integer storageId = null;

		try {
			when(purchaseStockDao.getStockFileMappingByOrderId(anyInt()))
					.thenReturn(PurchaseOrderMockData.getStockFileMapping());
			purchaseStockServiceImpl.getStockFileId(1);
		}

		catch (Exception e) {
			Assertions.fail(e.toString());
		}

	}

	@Test
	public void testDownloadDataConverting() {

		List<ViewHistoryDto> mockDto = new ArrayList<>();
		ViewHistoryDto mockViewHistoryDto = PurchaseOrderMockData.getViewHistoryDto();
		mockDto.add(mockViewHistoryDto);

		List<String> mockSelectedColumnList = new ArrayList<>();
		mockSelectedColumnList.add(TableConstants.COMPANYNAME);
		mockSelectedColumnList.add(TableConstants.PURCHASE_ID);
		mockSelectedColumnList.add(TableConstants.TRANSACTION_ID);
		mockSelectedColumnList.add(TableConstants.PAYMENT_DATE);
		mockSelectedColumnList.add(TableConstants.PAYMENT_TYPE);
		mockSelectedColumnList.add(TableConstants.AMOUNT);
		mockSelectedColumnList.add(TableConstants.PAYMENT_STATUS);

		ArrayList<HashMap<String, Object>> result = purchaseStockServiceImpl.downloadDataConverting(mockDto,
				mockSelectedColumnList);

		Assertions.assertEquals(1, result.size());
	}

	@Test
	public void commonDownload() throws ApplicationException {

		List<PurchaseOrderDto> data = PurchaseOrderMockData.getPurchaseOrderDtoList();
		List<String> columnList = PurchaseOrderMockData.getColumnList();

		ArrayList<HashMap<String, Object>> DataList = PurchaseOrderMockData.getDataList();
//				HashMap<String, Object> map = PurchaseOrderMockData.getMap();

//		List<String> mockSelectedColumnList = new ArrayList<>();
//		mockSelectedColumnList.add(TableConstants.PURCHASE_ID);
//		mockSelectedColumnList.add(TableConstants.TRANSACTION_ID);
//		mockSelectedColumnList.add(TableConstants.DATEOF_PURCHASE);
//		mockSelectedColumnList.add(TableConstants.NO_OF_PAPER);
//		mockSelectedColumnList.add(TableConstants.PURCHASE_AMT);
//		mockSelectedColumnList.add(TableConstants.PAYMENT_METHOD);
//		mockSelectedColumnList.add(TableConstants.PAYMENT_STATUS);

//		ResponseEntity<ByteArrayResource> result =
		purchaseStockServiceImpl.commonDownload(data, columnList);

//		Assertions.assertEquals(2, ((List<ViewHistoryDto>) result).size());

	}

	@Test
	public void commonDownload1() throws ApplicationException {

		List<PurchaseOrderDto> data = PurchaseOrderMockData.getPurchaseOrderDtoList();
		List<String> columnList = new ArrayList<String>();
		columnList.add("column1");
		columnList.add("column2");

		ResponseEntity<ByteArrayResource> result = purchaseStockServiceImpl.commonDownload(data, columnList);

		Assertions.assertNotNull(result);
		Assertions.assertEquals(HttpStatus.CREATED, result.getStatusCode());
		Assertions.assertNotNull(result.getBody());
	}

}
