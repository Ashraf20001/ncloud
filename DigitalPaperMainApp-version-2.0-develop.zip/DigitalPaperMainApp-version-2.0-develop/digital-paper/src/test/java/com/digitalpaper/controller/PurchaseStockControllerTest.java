package com.digitalpaper.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.config.base.controller.BaseController;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.mockdata.AuthorityPaperDetailsMockData;
import com.digitalpaper.mockdata.PurchaseHistoryMockData;
import com.digitalpaper.mockdata.PurchaseOrderMockData;
import com.digitalpaper.service.IStockService;
import com.digitalpaper.service.PurchaseStockService;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.AssociationDashboardCountDto;
import com.digitalpaper.transfer.object.dto.CompanyTransactionDto;
import com.digitalpaper.transfer.object.dto.DownloadListVo;
import com.digitalpaper.transfer.object.dto.PaymentDetailsDto;
import com.digitalpaper.transfer.object.dto.PurchaseOrderDto;
import com.digitalpaper.transfer.object.dto.ViewHistoryDto;
import com.digitalpaper.transfer.object.entity.PaymentDetails;
import com.digitalpaper.utils.core.ApplicationUtils;

import mockDatas.MockData;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class PurchaseStockControllerTest {

	@InjectMocks
	private PurchaseStockController purchaseStockController;

	@Mock
	private PurchaseStockService purchaseStockService;
	
	@Mock
	private BaseController baseController;
	
	@Mock
	private IStockService iStockService;


	@Test
	public void getPurchaseList_HappyFlow() {
		Integer max,min;
		min=0;max=10;

		try {
			List<PurchaseOrderDto> actual,expected;
			expected=PurchaseOrderMockData.getPurchaseOrderDtoList();
			when(purchaseStockService.getPurchaseList(min, max, 
					PurchaseHistoryMockData.getFilterOrSorting())).thenReturn(expected);
			actual=purchaseStockController.getPurchaseList(min, max, PurchaseHistoryMockData.getFilterOrSorting());
			assertEquals(expected, actual);
		} catch (ApplicationException e) {
			Assertions.fail(e.toString());
		}
	}


	@Test
	void approveOrRejectPurchaseDetails_happy_flow() {
		String expected = ApplicationConstants.UPDATE_SUCESS;
		PaymentDetailsDto paymentDetailsDto = PurchaseOrderMockData.getPaymentDetailsDto();
		try {
			when(purchaseStockService.approveOrRejectPurchaseDetails(any(PaymentDetailsDto.class))).thenReturn(expected);
			ApplicationResponse approveOrRejectPurchaseDetails = purchaseStockController.approveOrRejectPurchaseDetails(paymentDetailsDto);
			assertNotNull(approveOrRejectPurchaseDetails);
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
	}


	@Test
	void getTransactionDetails_happy_flow() {
		List<ViewHistoryDto> expected = MockData.getViewHistoryDtoList();
		try {
			when(purchaseStockService.getTransactionDetails(MockData.getCompanyTransactionDto())).thenReturn(expected);
			ApplicationResponse transactionDetails = purchaseStockController.getTransactionDetails(MockData.getCompanyTransactionDto());
//			List<ViewHistoryDto> actual =(List<ViewHistoryDto>)transactionDetails.getContent();
//			assertEquals(actual.get(0), expected);
			assertNotNull(transactionDetails);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getPurchaseOrderCount_HappyFlow() {
		Long expected=23L;Long actual;
		List<FilterOrSortingVo> filter=PurchaseOrderMockData.getListFilterOrSortingVo();
		try {
			when(purchaseStockService.getPurchaseOrderCount(filter)).thenReturn(expected);
			actual=purchaseStockController.getPurchaseOrderCount(filter);
			assertEquals(actual, expected);
		}
		catch(Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getAllPurchaseCount_HappyFlow(){
		Long expected=23L;Long actual;
		CompanyTransactionDto companyTransMock=MockData.getCompanyTransactionDto();
		try {
			when(purchaseStockService.getAllPurchaseOrderCount(companyTransMock)).thenReturn(expected);
			actual=purchaseStockController.getAllPurchaseCount(companyTransMock);
			assertEquals(actual, expected);
		} catch (Exception e) {
			 Assertions.fail(e.toString());	
		}
	}
	
	
	
	@Test
	void getAuthorityDashboardCount_HappyFlow()
	{
		Integer associatioId = 1;
		List<AssociationDashboardCountDto> associationDashboardCountDto;
		try {
		when(purchaseStockService.getAuthorityDashboardCount(associatioId)).thenReturn(PurchaseOrderMockData.getAssociationDashboardCountDto());
		purchaseStockController.getAuthorityDashboardCount(associatioId);
		}
		 catch (Exception e) {
			 Assertions.fail(e.toString());	
		}
		
	}
	

	
	@Test
	void  getStckFileId_HappyFlow()
	{
		try {
			when(purchaseStockService.getStockFileId(anyInt())).thenReturn(10);
		}
		 catch (Exception e) {
			 Assertions.fail(e.toString());	
		}
	}
	
	
	
	@Test
	void excelDownloadForTransaction_HappyFlow()
	{
//		List<ViewHistoryDto> transactionDetails=purchaseStockService.getTransactionDetails(AuthorityPaperDetailsMockData.getCompanyTransactionDto());
//		 AuthorityPaperDetailsMockData.getCompanyTransactionDto();
		CompanyTransactionDto companyTransactionDto = AuthorityPaperDetailsMockData.getCompanyTransactionDto();
		List<String> selectedColumn = companyTransactionDto.getSelectedColumn();
		ArrayList<HashMap<String, Object>> arrayListHashmapData = PurchaseOrderMockData.getArrayListHashmapData();
		HttpHeaders header = new HttpHeaders();
		header.setContentType(new MediaType("application", "force-download"));
		try
		{
			when(purchaseStockService.getTransactionDetails(companyTransactionDto)).thenReturn(MockData.getViewHistoryDtoList());
			when( purchaseStockService.downloadDataConverting(MockData.getViewHistoryDtoList(),selectedColumn)).thenReturn(arrayListHashmapData);
			when(iStockService.excelDownload(arrayListHashmapData)).thenReturn(any());
			purchaseStockController.excelDownloadForTransaction(companyTransactionDto);
		}
		catch(Exception e) {
			Assertions.fail(e.toString());
		}
	}


	
	@Test
	void purchaseStockDownloadHappyFlow() throws ApplicationException
	{
		 
		        
		        DownloadListVo downloadListVo = PurchaseHistoryMockData.getDownloadListVo1();
		        
//		      
//		       List<FilterOrSortingVo> filterVo = PurchaseHistoryMockData.getDownloadListVo().getFilterVo();
		        List<FilterOrSortingVo> filterVo = PurchaseHistoryMockData.getFilterOrSorting();
//		       List<String> columnList = PurchaseHistoryMockData.getDownloadListVo().getColumnList();
		        
		        List<String> columnList = Arrays.asList("Column1", "Column2", "Column3");
		        List<Integer> companyId = Arrays.asList(1, 2, 3);

		        List<PurchaseOrderDto> data = PurchaseOrderMockData.getPurchaseOrderDtoList();
		       

		        when(purchaseStockService.getPurchaseList(anyInt(), anyInt(), any()))
		                .thenReturn(data);

		        ResponseEntity<ByteArrayResource> expectedResponse = ResponseEntity.ok().build();
		        when(purchaseStockService.commonDownload(data,downloadListVo.getColumnList() ))
		                .thenReturn(expectedResponse);

		        
		        ResponseEntity<ByteArrayResource> response = null;
		        try {
		            response = purchaseStockController.purchaseStockDownload(downloadListVo);
		        } catch (ApplicationException e) {
		            e.printStackTrace();
		        }

		     
		    }
		
	}
	
	
	
	
	


