package com.digitalpaper.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletRequest;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.service.PaperDetailsBulkUploadService;
import com.digitalpaper.transfer.object.dto.BulkImportFieldValidationDto;
import com.digitalpaper.transfer.object.dto.PoolCountDetails;
import com.digitalpaper.transfer.object.dto.UserInfo;

import mockDatas.BulkUploadMock;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class PaperDetailsBulkUploadTest {
	
	@InjectMocks
	private PaperDetailsBulkUpload paperDetailsBulkUpload;
	
	@Mock
	private PaperDetailsBulkUploadService paperDetailsBulkUploadService;
	
	@Test
	void getExcelSheetReading_happy_flow() {
		try {
			doNothing().when(paperDetailsBulkUploadService).getExcelSheetReading(any(BulkImportFieldValidationDto.class),any(HttpServletRequest.class));
			paperDetailsBulkUpload.getExcelSheetReading(null,null);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
//	@Test
//	void checkAndReservePaperDetails_happy_flow() {
//		try {
//			when(paperDetailsBulkUploadService.checkAndReservePaperDetails(any(UserInfo.class),anyInt())).thenReturn(BulkUploadMock.getPoolCountDetails());
//			ResponseEntity<PoolCountDetails> checkAndReservePaperDetails = paperDetailsBulkUpload.checkAndReservePaperDetails(BulkUploadMock.getUserInfo(), 0);
//			PoolCountDetails body = checkAndReservePaperDetails.getBody();
//			assertEquals(body.getFailedPaperGenerateCount(), 0);
//		} catch (Exception e) {
//			Assertions.fail(e.toString());
//		}
//	}

}
