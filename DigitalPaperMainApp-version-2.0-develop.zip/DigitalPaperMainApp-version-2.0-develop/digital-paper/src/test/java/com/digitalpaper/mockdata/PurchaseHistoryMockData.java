package com.digitalpaper.mockdata;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.transfer.object.dto.AssociationDashboardCountDto;
import com.digitalpaper.transfer.object.dto.CompanyAndCountDto;
import com.digitalpaper.transfer.object.dto.CompanyDto;
import com.digitalpaper.transfer.object.dto.CompanyViewDto;
import com.digitalpaper.transfer.object.dto.DownloadListVo;
import com.digitalpaper.transfer.object.dto.NotificationCount;
import com.digitalpaper.transfer.object.dto.PlatformDetailsDto;
import com.digitalpaper.transfer.object.dto.PurchaseHistoryViewDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.dto.UserRoleDto;
import com.digitalpaper.transfer.object.entity.PurchaseOrderEntity;
import com.digitalpaper.transfer.object.entity.UserType;
import com.digitalpaper.transfer.object.enums.PaymentStatusEnum;

public class PurchaseHistoryMockData {

	public static List<PurchaseHistoryViewDto> getPurchHistyViewDto() {
		List<PurchaseHistoryViewDto> purchList = new ArrayList<>();
		PurchaseHistoryViewDto purchHisty = new PurchaseHistoryViewDto();
		purchHisty.setCompanyName("digital paper");
		purchHisty.setPendingTransactions(100l);
		purchHisty.setTotalTransactions(200l);
		purchList.add(purchHisty);
		return purchList;

	}

	public static List<FilterOrSortingVo> getFilterOrSorting() {
		List<FilterOrSortingVo> filterOrSortingVos = new ArrayList<>();
		FilterOrSortingVo filterOrSortingVo = new FilterOrSortingVo();
		List<Integer> integer = new ArrayList<Integer>();
		integer.add(1);
		filterOrSortingVo.setColumnName("");
		filterOrSortingVo.setCondition("Equal");
		filterOrSortingVo.setValue("0");
		filterOrSortingVo.setType("Integer");
		filterOrSortingVo.setIntgerValueList(integer);
		filterOrSortingVo.setValueList(getListofStringValue());	
		filterOrSortingVos.add(filterOrSortingVo);
		return filterOrSortingVos;
	}
	
	public static List<FilterOrSortingVo> getFilterOrSorting1() {
		List<FilterOrSortingVo> filterOrSortingVos = new ArrayList<>();
		FilterOrSortingVo filterOrSortingVo = new FilterOrSortingVo();
		List<Integer> integer = new ArrayList<Integer>();
		integer.add(1);
		filterOrSortingVo.setColumnName("status");
		filterOrSortingVo.setCondition("Equal");
		filterOrSortingVo.setValue("0");
		filterOrSortingVo.setType("Integer");
		filterOrSortingVo.setIntgerValueList(integer);
		filterOrSortingVo.setValueList(getListofStringValue());	
		filterOrSortingVos.add(filterOrSortingVo);
		return filterOrSortingVos;
	}
	
	public static DownloadListVo getDownloadListVo() {
		DownloadListVo filterOrSortingVos =new  DownloadListVo();
		FilterOrSortingVo filterOrSortingVo = new FilterOrSortingVo();
		filterOrSortingVo.setColumnName("");
		filterOrSortingVo.setCondition("Equal");
		filterOrSortingVo.setValue("0");
		filterOrSortingVo.setType("Integer");
		
		
		
		return filterOrSortingVos;
	}
	
	//below naga 
	
	public static DownloadListVo getDownloadListVo1() {
		
//		DownloadListVo filterOrSortingVos =new  DownloadListVo();
//		FilterOrSortingVo filterOrSortingVo = new FilterOrSortingVo();
//		filterOrSortingVo.setColumnName("");
//		filterOrSortingVo.setCondition("Equal");
//		filterOrSortingVo.setValue("0");
//		filterOrSortingVo.setType("Integer");
		
		DownloadListVo downloadListVo = new DownloadListVo();
		FilterOrSortingVo filterOrSortingVo = new FilterOrSortingVo();
		filterOrSortingVo.setColumnName("");
		filterOrSortingVo.setCondition("Equal");
		filterOrSortingVo.setValue("0");
		filterOrSortingVo.setType("Integer");
		downloadListVo.setFilterVo(getFilterOrSorting());
		 List<String> columnList = new ArrayList<String>();
		 columnList.add("Column1");
		 columnList.add("Column2");
//		 List<String> columnList = Arrays.asList("Column1", "Column2", "Column3");
		 
//		 List<Integer> companyId = Arrays.asList(1, 2, 3);
		 List<Integer> companyId = new  ArrayList<Integer>();
		 companyId.add(1);
		 companyId.add(2);
		 downloadListVo.setColumnList(columnList);
		 downloadListVo.setCompanyId(companyId);	
		 downloadListVo.setMax(144);
		 downloadListVo.setMin(39);;
		 
		 
		return downloadListVo;
		
		
		
	}

	public static PurchaseOrderEntity getPurchaseOrderEntity() {
		PurchaseOrderEntity entity = new PurchaseOrderEntity();
		entity.setCompanyId(1);
		entity.setIdentity("eee");
		entity.setCreatedBy(1);
		entity.setIsDeleted(false);
		entity.setOrderAmt("USD");
		entity.setOrderId(2);
//		entity.setOrderNo(1);
		entity.setOrderStatus(PaymentStatusEnum.SUBMITTED.getId());
		entity.setPurchaseId("1");
		entity.setStockCount(1);
		return entity;
	}
	
	public static List<CompanyDto> getCompanyViewDto() {
		List<CompanyDto> list = new ArrayList<>();
		CompanyDto company = new CompanyDto();
		company.setCompanyId(1);
		company.setName("company");
		company.setEmail("wtert.com");
		company.setLocation("dfyy");
		company.setAddress("fgfyyu");
		company.setPassword("wetert");		
		company.setPhone("235345");
		company.setShortName("ff");
		list.add(company);
		CompanyDto company1 = new CompanyDto();
		company1.setCompanyId(2);
		company1.setName("nasfhak");
		company1.setEmail("wtert.com");
		company1.setLocation("dfyy");
		company1.setAddress("fgfyyu");
		company1.setPassword("wetert");		
		company1.setPhone("235345");
		company1.setPhone("44444");
		company1.setShortName("gg");
//		company1.setEmInsMaxPayableAmount(23464.000);
//		company1.setEmInsMaxTime(12.00);
//		company1.setEmInsIsActive(true);	
//		company1.setEmInsShortName("ff");
		list.add(company1);
		return list;

	}
	
	public static List<CompanyAndCountDto> getCompanyAndCountDto() {
		
		List<CompanyAndCountDto> list = new ArrayList<>();
		
		CompanyAndCountDto company = new CompanyAndCountDto();
		company.setComapanyName("weui");
		company.setCompanyId(1);
		company.setPendingCount(new Long(3423));
//		company.setPendingCount(0L);
		company.setTotalCount(new Long(21376));
//		company.setTotalCount(2333L);
		company.setNotification(0L);
		list.add(company);
		return list;

	}
	
	public static List<String> getListofStringValue(){
		List<String> list = new ArrayList<>();
		list.add("Active");
		list.add("Expired");
		list.add("Revoked");
		return list;
		
	}

	public static ArrayList<HashMap<String, Object>> getMapListValue(){
		
		ArrayList<HashMap<String, Object>> data = new ArrayList<HashMap<String, Object>>();
		
		HashMap<String, Object> map = new LinkedHashMap<>();
		
		map.put("asud", "uwetrr");
		map.put("asud", "uwetrr");
		map.put("asud", "uwetrr");
		
		data.add(map);
		
		return data;
		
	}

	
	public static List<PurchaseOrderEntity> getPurchaseOrderEntityList() {
		List<PurchaseOrderEntity> list = new ArrayList<>();
		PurchaseOrderEntity entity = new PurchaseOrderEntity();
		entity.setCompanyId(1);
		entity.setIdentity("eee");
		entity.setCreatedBy(1);
		entity.setIsDeleted(false);
		entity.setOrderAmt("1");
		entity.setOrderId(2);
//		entity.setOrderNo("1");
		entity.setOrderStatus(PaymentStatusEnum.FAILED.getId());
		entity.setPurchaseId("1");
		entity.setStockCount(1);
		list.add(entity);
		return list;
	}
	//beloe naga
	
	public static List<CompanyAndCountDto> getCompanyAndCount() {
		List<CompanyAndCountDto> list = new ArrayList<>();
		CompanyAndCountDto dto = new CompanyAndCountDto();
		dto.setCompanyId(1);
		dto.setComapanyName("company");
		dto.setTotalCount(100l);
		dto.setPendingCount(50l);
		list.add(dto);
		CompanyAndCountDto dto1 = new CompanyAndCountDto();
		dto1.setCompanyId(2);
		dto1.setComapanyName("company2");
		dto1.setTotalCount(10l);
		dto1.setPendingCount(5l);
		list.add(dto1);
		return list;
	}
	
	public static Map<Integer, String> getComMap() {
		Map<Integer, String> map = new HashMap<>();
		map.put(1, "company");
		map.put(2, "company2");	
		return map;	
	}
	
	public static List<NotificationCount> getNotifiCount() {
		List<NotificationCount> val = new ArrayList<>();
		NotificationCount count = new NotificationCount();
		count.setCompanyId(1);
		count.setNotificationCount(10l);
		val.add(count);
		return val;
		
	}
	  public static UserInfo getUserInfo() {
	    	UserInfo userInfo = new UserInfo();
	    	UserType type = new UserType();
	    	type.setUserTypeId(1);
	    	type.setUserTypeName("ASSOCIATION");

	    	PlatformDetailsDto detailsDto = new PlatformDetailsDto();
	    	detailsDto.setPlatformId(2);
	    	detailsDto.setPlatformIdentity("identity");
	    	detailsDto.setPlatformName("DIGITAL_PAPER");

	    	userInfo.setId(1);
	    	userInfo.setIdentity("tdfsgzx");
	    	userInfo.setPlatformIdentity("sdascX");
	    	userInfo.setUsername("name");
	    	userInfo.setFirstTimeLogin(false);
	    	userInfo.setRoles(getUserRoleDtoList());
	    	userInfo.setEmail("email");
	    	userInfo.setUserTypeId(type);
	    	userInfo.setPlatformDetailsDto(detailsDto);
	    	userInfo.setCompanyId(2);
	    	return userInfo;
	    }
	  
	  public static UserInfo getUserInfoError() {
	    	UserInfo userInfo = new UserInfo();
	    	UserType type = new UserType();
	    	type.setUserTypeId(2);
	    	type.setUserTypeName("ASSOCIATION");

	    	PlatformDetailsDto detailsDto = new PlatformDetailsDto();
	    	detailsDto.setPlatformId(2);
	    	detailsDto.setPlatformIdentity("identity");
	    	detailsDto.setPlatformName("DIGITAL_PAPER");

	    	userInfo.setId(1);
	    	userInfo.setIdentity("tdfsgzx");
	    	userInfo.setPlatformIdentity("sdascX");
	    	userInfo.setUsername("name");
	    	userInfo.setFirstTimeLogin(false);
	    	userInfo.setRoles(getUserRoleDtoList());
	    	userInfo.setEmail("email");
	    	userInfo.setUserTypeId(type);
	    	userInfo.setPlatformDetailsDto(detailsDto);
	    	userInfo.setCompanyId(2);
	    	return userInfo;
	    }
	  
	  public static UserInfo getUserInfoFailFlow() {
	    	UserInfo userInfo = new UserInfo();
	    	UserType type = new UserType();
	    	type.setUserTypeId(1);
	    	type.setUserTypeName("ASSOCIATION");

	    	PlatformDetailsDto detailsDto = new PlatformDetailsDto();
	    	detailsDto.setPlatformId(2);
	    	detailsDto.setPlatformIdentity("identity");
	    	detailsDto.setPlatformName("DIGITAL_PAPER");

	    	userInfo.setId(1);
	    	userInfo.setIdentity("tdfsgzx");
	    	userInfo.setPlatformIdentity("sdascX");
	    	userInfo.setUsername("name");
	    	userInfo.setFirstTimeLogin(false);
	    	userInfo.setRoles(getUserRoleDtoList());
	    	userInfo.setEmail("email");
	    	userInfo.setUserTypeId(type);
	    	userInfo.setPlatformDetailsDto(detailsDto);
	    	userInfo.setCompanyId(2);
	    	return null;
	    }

	  public static UserInfo getUserInfo1() {
	    	UserInfo userInfo = new UserInfo();
	    	UserType type = new UserType();
	    	type.setUserTypeId(1);
//	    	 below naga
	    	type.setUserTypeName("Association");

	    	PlatformDetailsDto detailsDto = new PlatformDetailsDto();
	    	detailsDto.setPlatformId(2);
	    	detailsDto.setPlatformIdentity("identity");
	    	detailsDto.setPlatformName("DIGITAL_PAPER");

	    	userInfo.setId(1);
	    	userInfo.setIdentity("tdfsgzx");
	    	userInfo.setPlatformIdentity("sdascX");
	    	userInfo.setUsername("name");
	    	userInfo.setFirstTimeLogin(false);
	    	userInfo.setRoles(getUserRoleDtoList());
	    	userInfo.setEmail("email");
	    	userInfo.setUserTypeId(type);
	    	userInfo.setPlatformDetailsDto(detailsDto);
	    	return userInfo;
	    }

	  public static List<UserRoleDto> getUserRoleDtoList() {
	        List<UserRoleDto> userRoleDtos = new ArrayList<>();
	        userRoleDtos.add(getUserRoleDto());
	        return userRoleDtos;
	    }

	  public static UserRoleDto getUserRoleDto() {
	        return new UserRoleDto(1,"Admin");
	    }

	  public static DownloadListVo getDownload() {
		  DownloadListVo dd = new DownloadListVo();
		  dd.setColumnList(getListofStringValue());
		  dd.setFilterVo(getFilterOrSorting()); 
		return dd;
		  
	  }
	  // below naga
	  
	  public static ArrayList<HashMap<String, Object>> getArrayListMockData() {
	        ArrayList<HashMap<String, Object>> list = new ArrayList<>();

	        HashMap<String, Object> data1 = new HashMap<>();
	        data1.put("Insured Company", "ABC Insurance");
	        data1.put("Total Transaction", 100);
	        data1.put("Pending Transaction", 20);
	        list.add(data1);

	        HashMap<String, Object> data2 = new HashMap<>();
	        data2.put("Insured Company", "XYZ Insurance");
	        data2.put("Total Transaction", 50);
	        data2.put("Pending Transaction", 10);
	        list.add(data2);

	        return list;
	    }
	  
	  
	  
	  // below naga
	  
	  public static  Object[] getAllCompaniesCount() {
		    Object[] mockData = new Object[2];
		    mockData[0] = 1000L;  
		    mockData[1] = 500L;   
		    return mockData;
		}
	  
	  
	  // below naga
	 public static Map<Integer, String> getcompanyNameMaping()
	 {
		 HashMap<Integer,String> hashMap = new HashMap<Integer,String>();
		 hashMap.put(1, "AxaCompany");
		 hashMap.put(2, "reliance");
		 
 		 return hashMap;
		 
	 }
	  
	
	
	 
	}
	





	  
	  
	 

