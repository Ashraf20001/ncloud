package com.digitalpaper.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.poi.sl.usermodel.ObjectMetaData.Application;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.dao.IPaperDetailsDao;
import com.digitalpaper.dao.IScratchDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.mockdata.PaperDetailsMockData;
import com.digitalpaper.mockdata.PurchaseHistoryMockData;
import com.digitalpaper.mockdata.PurchaseOrderMockData;
import com.digitalpaper.restemplate.service.IRestTemplateService;
import com.digitalpaper.service.impl.PaperDetailsServiceImpl;
import com.digitalpaper.transfer.object.dto.FieldDto;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.entity.BulkImportErrorTable;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.entity.Scratch;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;

import mockDatas.MockData;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@ContextConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class PaperDetailsServiceTest {

	@InjectMocks
	private PaperDetailsServiceImpl paperDetailsSerImplMock;

	@Mock
	private IPaperDetailsDao iPaperDetailsDaoMock;

	@Mock
	private IScratchDao scratchDao;

	@Mock
	private LoggedInUserContextHolder loggedInUserContextHolder;

	@Mock
	private IRestTemplateService iRestTemplateServiceMock;

	@Test
	public void getPaperDetailsCount_HappyFlow() {
		Long val = 10l;
		List<FilterOrSortingVo> filter = PurchaseHistoryMockData.getFilterOrSorting();
		UserInfo user = PurchaseHistoryMockData.getUserInfo();
		Integer companyId = user.getCompanyId();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(user);
			when(iPaperDetailsDaoMock.getPaperDetailsCount(filter,companyId)).thenReturn(val);
			Long result = paperDetailsSerImplMock.getPaperDeatilsCount(filter);
			assertNotNull(result);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void getPaperDetailsCount_FlowFail() {
		List<FilterOrSortingVo> filter = PurchaseHistoryMockData.getFilterOrSorting1();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(null);
			ApplicationException applicationException = new ApplicationException(ErrorCodes.INVALID_USER);
			 ApplicationException applicationException2 = assertThrows(ApplicationException.class,()->{
					paperDetailsSerImplMock.getPaperDeatilsCount(filter);
				});
			assertEquals(applicationException.toString(), applicationException2.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void getPaperDeatilsCount_FlowFail2() {
		List<FilterOrSortingVo> filter = PurchaseHistoryMockData.getFilterOrSorting1();
		UserInfo user = PurchaseHistoryMockData.getUserInfoError();
		user.setCompanyId(null);
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(user);
			ApplicationException applicationException = new ApplicationException(ErrorCodes.INVALID_ACTION);
			ApplicationException applicationException2 = assertThrows(ApplicationException.class,()->{
				paperDetailsSerImplMock.getPaperDeatilsCount(filter);
			});
			assertEquals(applicationException.toString(), applicationException2.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void getPaperDetailsList_HappyFlow() {
		Integer skip =0;
		Integer limit =10;
		Integer companyId=2;
		List<FilterOrSortingVo> filter = PurchaseHistoryMockData.getFilterOrSorting();
		List<PaperDetails> entity = PaperDetailsMockData.getPaperDetails();
		List<PaperDetailsDto> dto = PaperDetailsMockData.getPaperDetailsDto();
		UserInfo user = PurchaseHistoryMockData.getUserInfo();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(user);
			when(iPaperDetailsDaoMock.getPaperDetailsList(skip, limit, filter,companyId)).thenReturn(entity);
			List<PaperDetailsDto> paperDetailsList = paperDetailsSerImplMock.getPaperDetailsList(skip, limit, filter);
			assertNotNull(paperDetailsList);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void getPaperDetailsList_FailFlow() {
		Integer skip =0;
		Integer limit =10;
		List<FilterOrSortingVo> filter = PurchaseHistoryMockData.getFilterOrSorting1();
		List<PaperDetails> entity = PaperDetailsMockData.getPaperDetails();
		List<PaperDetailsDto> dto = PaperDetailsMockData.getPaperDetailsDto();
		UserInfo user = PurchaseHistoryMockData.getUserInfoError();
		user.setCompanyId(null);

		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(user);
			ApplicationException applicationException = new ApplicationException(ErrorCodes.INVALID_ACTION);
			ApplicationException applicationException2 = assertThrows(ApplicationException.class,()->{
				paperDetailsSerImplMock.getPaperDetailsList(skip, limit, filter);
			});
			assertEquals(applicationException.toString(), applicationException2.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void getScratchDataInExcel_HappyFlow() {
		Integer bulkUploadId=1;
		String pageIdentity="c741ae6b5c3a49b888d2592a51c6bu8u";
		Integer skip=0;
		Integer limit=2;
		List<FilterOrSortingVo> filterOrSortingVo = new ArrayList<>();
		List<String> entityColumnList = paperDetailsSerImplMock.getEntityColumnList();
		Long count=2L;

		try {

			when(scratchDao.getScratchEntityByBulkId(bulkUploadId, entityColumnList, Boolean.TRUE, filterOrSortingVo, skip, limit)).thenReturn(PurchaseOrderMockData.getListObject());
			when(scratchDao.getScratchCountByBulkId(bulkUploadId, Boolean.TRUE)).thenReturn(count);
			ArrayList<HashMap<String, Object>> scratchDataInExcel = paperDetailsSerImplMock.getScratchDataInExcel(pageIdentity, bulkUploadId, null);
			assertNotNull(scratchDataInExcel);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void getScratchDataInExcel_ErrorFlow() {
		Integer bulkUploadId=null;
		String pageIdentity="c741ae6b5c3a49b888d2592a51c6bu8u";

		ApplicationException exception=new ApplicationException(ErrorCodes.INVALID_BULK_UPLOAD_ID);
		ApplicationException assertThrows = assertThrows(ApplicationException.class,()->{
			paperDetailsSerImplMock.getScratchDataInExcel(pageIdentity, bulkUploadId, null);
		});
		assertEquals(exception.toString(), assertThrows.toString());
	}

	@Test
	public void updateRevoke_HappyFlow() {
		PaperDetails dto = PaperDetailsMockData.getPaperData();
		try {
			UserInfo user = PurchaseHistoryMockData.getUserInfo();
			String comId1 = user.getCompanyName();
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(user);
			when(iPaperDetailsDaoMock.getRevokeStatusData("123")).thenReturn(dto);
			String updateRevokeStatus = paperDetailsSerImplMock.updateRevokeStatus("123");
			assertNotNull(updateRevokeStatus);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void excelDownload_HappyFlow() {
		Integer scratchId=1;
		HttpHeaders header = new HttpHeaders();
		header.setContentType(new MediaType("application", "force-download"));
//		ResponseEntity<ByteArrayResource> response = new ResponseEntity<̥>(any(ByteArrayResource.class),header, HttpStatus.SC_CREATED);
		try {
			when(iPaperDetailsDaoMock.getErrorTableByScratchId(scratchId)).thenReturn(PaperDetailsMockData.getBulkImportTableList());
			ResponseEntity<ByteArrayResource> excelDownload = paperDetailsSerImplMock.excelDownload(PaperDetailsMockData.getExcelList());
			assertNotNull(excelDownload);

		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void updateRevoke_FailureFlow() {
		try {
			PaperDetails dto = PaperDetailsMockData.getPaperData1();
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseHistoryMockData.getUserInfo1());
			when(iPaperDetailsDaoMock.getRevokeStatusData("123")).thenReturn(dto);
    		ApplicationException ap = new ApplicationException(ErrorCodes.INVALID_STATUS);
            ApplicationException
                    exception = assertThrows(ApplicationException.class, () -> {
                    	paperDetailsSerImplMock.updateRevokeStatus("123");
            });
            assertEquals(ap.toString(),exception.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void updateRevoke_FailureFlow1() {
		try {
			ApplicationException ap = new ApplicationException(ErrorCodes.INVALID_IDENTITY);
            ApplicationException
                    exception = assertThrows(ApplicationException.class, () -> {
                    	paperDetailsSerImplMock.updateRevokeStatus("");
            });
            assertEquals(ap.toString(),exception.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void getPaperDetails() {
		PaperDetails dto = PaperDetailsMockData.getPaperData();
		PaperDetailsDto dto1 = PaperDetailsMockData.getDetails();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseHistoryMockData.getUserInfo1());
			when(iPaperDetailsDaoMock.getRevokeStatusData("123")).thenReturn(dto);
			when(iPaperDetailsDaoMock.getPaperImageById(dto.getPaperId(), ApplicationConstants.UPD_TYPE, ApplicationConstants.RP_TYPE)).thenReturn(PaperDetailsMockData.getFileStorage());
			PaperDetailsDto paperDetailsData = paperDetailsSerImplMock.getPaperDetailsData("123");
			assertNotNull(paperDetailsData);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void getPaperDetailsByPaperId() {
		Integer paperId=1;
		try {
			when(iPaperDetailsDaoMock.getPaperImageById(paperId, ApplicationConstants.UPD_TYPE, ApplicationConstants.RP_TYPE)).thenReturn(PaperDetailsMockData.getFileStorage());
			String paperDetailsByPaperId = paperDetailsSerImplMock.getPaperDetailsByPaperId(paperId);
			assertNotNull(paperDetailsByPaperId);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}

	}

	@Test
	public void sampleExcelDownload_HappyFlow() {
		List<String> str = PaperDetailsMockData.getColumnList();
		HttpHeaders header = new HttpHeaders();
		header.setContentType(new MediaType("application", "force-download"));
		try {
			ResponseEntity<ByteArrayResource> excelDownload = paperDetailsSerImplMock.sampleExcelDownload(str);
			assertNotNull(excelDownload);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}

	}


	@Test
	public void getSuccessTable_HappyFlow() {

		Integer bulkUploadId=1;
		List<String> columnList = PaperDetailsMockData.entityColumnList();
		List<Object[]> obj = PurchaseOrderMockData.getScratchTableObject();
		List<FilterOrSortingVo> filterOrSortingVo = PurchaseOrderMockData.getListFilterOrSortingVo();
		String pageIdentity="c741ae6b5c3a49b888d2592a51c6bu8u";
		Integer skip=0;
		Integer limit=10;


		try {
			when(scratchDao.getScratchEntityByBulkId(bulkUploadId, columnList, Boolean.FALSE, filterOrSortingVo, skip, limit)).thenReturn(obj);
			ArrayList<HashMap<String, Object>> successTable = paperDetailsSerImplMock.getSuccessTable(pageIdentity, bulkUploadId, filterOrSortingVo, null, skip, limit);
			assertNotNull(successTable);

		}
		catch(ApplicationException e) {
			Assertions.fail(e.toString());
		}

	}

	@Test
	public void getErrorTable_HappyFlow() {

		Integer bulkUploadId=1;
		List<String> columnList = PaperDetailsMockData.entityColumnList();
		List<Object[]> obj = PurchaseOrderMockData.getScratchTableObject();
		List<FilterOrSortingVo> filterOrSortingVo = PurchaseOrderMockData.getListFilterOrSortingVo();
		String pageIdentity="c741ae6b5c3a49b888d2592a51c6bu8u";
		Integer skip=0;
		Integer limit=10;
		try {
			when(scratchDao.getScratchEntityByBulkId(bulkUploadId, columnList, Boolean.TRUE, filterOrSortingVo, skip, limit)).thenReturn(obj);
			ArrayList<HashMap<String, Object>> errorTable = paperDetailsSerImplMock.getErrorTable(pageIdentity, bulkUploadId, filterOrSortingVo, null, skip, limit);
			assertNotNull(errorTable);

		}
		catch(ApplicationException e) {
			Assertions.fail(e.toString());
		}

	}

	@Test
	public void getTotalCount_HappyFlow() {
		Integer bulkUploadId=1;
		Long count=1L;
		when(scratchDao.getTotalScratchCountByBulkId(bulkUploadId)).thenReturn(count);
		Long totalRecords = paperDetailsSerImplMock.getTotalRecords(bulkUploadId);
		assertNotNull(totalRecords);
	}

	@Test
	public void getSuccessCount_HappyFlow() {
		Integer bulkUploadId=1;
		Long count=1L;
		when(scratchDao.getScratchCountByBulkId(bulkUploadId,Boolean.FALSE)).thenReturn(count);
		Long totalRecords = paperDetailsSerImplMock.getSuccessRecordsCount(bulkUploadId);
		assertNotNull(totalRecords);
	}

	@Test
	public void getErrorCount_HappyFlow() {
		Integer bulkUploadId=1;
		Long count=1L;
		when(scratchDao.getScratchCountByBulkId(bulkUploadId,Boolean.TRUE)).thenReturn(count);
		Long totalRecords = paperDetailsSerImplMock.getErrorRecordsCount(bulkUploadId);
		assertNotNull(totalRecords);
	}

	@Test
	public void deleteErrorandScratchData_HappyFlow() {
		Integer scratchId=1;
		String scratchIdentity="aeroiqurgfqiqor";
		Scratch scratchData = PaperDetailsMockData.getScratchData();
		List<BulkImportErrorTable> importTableList = PaperDetailsMockData.getBulkImportTableList();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseHistoryMockData.getUserInfo1());
			when(scratchDao.getScratchDataByIdentity(scratchIdentity)).thenReturn(scratchData);
			when(iPaperDetailsDaoMock.getErrorTableByScratchId(scratchId)).thenReturn(importTableList);
			doNothing().when(scratchDao).deleteScratchData(scratchData);
			doNothing().when(iPaperDetailsDaoMock).deleteErrorData(importTableList);
			paperDetailsSerImplMock.deleteErrorandScratchData(scratchId, scratchIdentity);


		} catch (Exception e) {
			Assertions.fail(e.toString());
		}

	}

	@Test
	public void deleteErrorandScratchData_ErrorFlow1() {
		String scratchIdentity=null;
		Integer scratchId=1;


		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseHistoryMockData.getUserInfo1());
			ApplicationException exception= new ApplicationException(ErrorCodes.INVALID_IDENTITY);
			ApplicationException exception2 = assertThrows(ApplicationException.class, ()->{
				paperDetailsSerImplMock.deleteErrorandScratchData(scratchId,scratchIdentity);
			});
			assertEquals(exception.toString(), exception2.toString());
		}
		catch(Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void deleteErrorandScratchData_ErrorFlow2() {
		String scratchIdentity="aeroiqurgfqiqor";
		Scratch scratchData = PaperDetailsMockData.getScratchData();

		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseHistoryMockData.getUserInfo1());
			ApplicationException exception= new ApplicationException(ErrorCodes.INVALID_ID);
			when(scratchDao.getScratchDataByIdentity(scratchIdentity)).thenReturn(scratchData);
			ApplicationException exception2 = assertThrows(ApplicationException.class, ()->{
				paperDetailsSerImplMock.deleteErrorandScratchData(null,scratchIdentity);
			});
			assertEquals(exception.toString(), exception2.toString());
		}
		catch(Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void dowloadPaperDetails_HappyFlow() {

		List<String> columnList = PaperDetailsMockData.getColumnList();
		List<String> entityColumnList = PaperDetailsMockData.entityColumnList();
		HttpHeaders header = new HttpHeaders();
		header.setContentType(new MediaType("application", "force-download"));
//		ResponseEntity<ByteArrayResource> response = new ResponseEntity<>(any(ByteArrayResource.class), header, HttpStatus.SC_CREATED);

		try {
			when(iPaperDetailsDaoMock.getPaperDetailsDataForDownload(entityColumnList)).thenReturn(PurchaseOrderMockData.getListObject());
			ResponseEntity<ByteArrayResource> dowloadPaperDetails = paperDetailsSerImplMock.dowloadPaperDetails(columnList);
			assertNotNull(dowloadPaperDetails);

		} catch (Exception e) {
			Assertions.fail(e.toString());
		}

	}

	@Test
	public void getColumnNamesForDropdown_HappyFlow() {
		String pageIdentity="c741ae6b5c3a49b888d2592a51c6bu8u";
		List<String> columnList = PaperDetailsMockData.getColumnList();
		try {
			when(iRestTemplateServiceMock.getMetaDataList(pageIdentity, null)).thenReturn(columnList);
			List<String> columnNamesForDropdown = paperDetailsSerImplMock.getColumnNamesForDropdown(pageIdentity, null);
			assertNotNull(columnNamesForDropdown);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
}
