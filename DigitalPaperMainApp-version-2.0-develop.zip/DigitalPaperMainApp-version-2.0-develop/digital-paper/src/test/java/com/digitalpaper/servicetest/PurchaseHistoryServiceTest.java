package com.digitalpaper.servicetest;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.config.DigitalPaperCache;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.dao.IPurchaseOrderEntityDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.mockdata.PurchaseHistoryMockData;
import com.digitalpaper.mockdata.PurchaseOrderMockData;
import com.digitalpaper.restemplate.service.IRestTemplateService;
import com.digitalpaper.service.impl.PurchaseHistoryServiceImpl;
import com.digitalpaper.transfer.object.dto.CompanyAndCountDto;
import com.digitalpaper.transfer.object.dto.CompanyDto;
import com.digitalpaper.transfer.object.dto.NotificationCount;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;

import mockDatas.MockData;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@ContextConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class PurchaseHistoryServiceTest {

	@InjectMocks
	private PurchaseHistoryServiceImpl purchHistryServiceImplMock;

	@Mock
	private IPurchaseOrderEntityDao iPurchaseHistoryDaoMock;
	
	@Mock
	private LoggedInUserContextHolder loggedInUserContextHolder;
	
	@Mock
	private IRestTemplateService iRestTemplateServiceMock;
	
	@Mock
	private CompanyAndCountDto companyAndCountDto;
	
	@Mock
	private IRestTemplateService iRestTemplateService;
	
	@Mock
	private DigitalPaperCache digitalPaperCache;

	@Test
	public void getPurchOrderCount_HappyFlow() {
		Integer skip = 1;
		Integer limit = 10;
		Long val =10l;
		Long result;
		List<FilterOrSortingVo> filterVo = PurchaseHistoryMockData.getFilterOrSorting();
		List<CompanyDto> value = PurchaseHistoryMockData.getCompanyViewDto();
		Map<Integer, String> companyNameMap = PurchaseHistoryMockData.getComMap();
		List<CompanyAndCountDto> comCount = PurchaseHistoryMockData.getCompanyAndCount();
		HashMap<Integer, String> companyIdNameMockData = MockData.companyIdNameMockData();
		try {
			UserInfo user = PurchaseHistoryMockData.getUserInfo();
			Integer comId1 = user.getCompanyId();
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(user);
//			when(iRestTemplateServiceMock.getCompanyList(filterList)).thenReturn(value);
			when(digitalPaperCache.getCompanyList()).thenReturn(companyIdNameMockData);
			when(iPurchaseHistoryDaoMock.getCompanyAndCountList(companyNameMap, skip, limit, filterVo,Boolean.TRUE)).thenReturn(comCount);
			result = purchHistryServiceImplMock.getPurchaseOrderEntityCount(filterVo);
			assertNotNull(result);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	public void getPurchOrderCount_ErrorFlow() {
		UserInfo user = PurchaseHistoryMockData.getUserInfo();
		Integer comId1 = user.getCompanyId();
		List<FilterOrSortingVo> filterVo = PurchaseHistoryMockData.getFilterOrSorting();
		try {
    		when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseHistoryMockData.getUserInfo1());
    		ApplicationException ap = new ApplicationException(ErrorCodes.UN_AUTHORIZED);
            ApplicationException
                    exception = assertThrows(ApplicationException.class, () -> {
                    	purchHistryServiceImplMock.getPurchaseOrderEntityCount(filterVo);
            });
            assertEquals(ap.toString(),exception.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	
	@Test
	public void getPurchOrderCount_EmptyCompanyListFlow() {
	    UserInfo user = PurchaseHistoryMockData.getUserInfo();
	    Integer comId1 = user.getCompanyId();
	    List<FilterOrSortingVo> filterVo = PurchaseHistoryMockData.getFilterOrSorting();
	    HashMap<Integer, String> companyIdNameMockData = MockData.companyIdNameMockData();
	    try {
	        when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseHistoryMockData.getUserInfo());
	        List<CompanyDto> emptyCompanyList = Collections.emptyList(); 
//	        when(iRestTemplateService.getCompanyList(filterList)).thenReturn(emptyCompanyList);
	        when(digitalPaperCache.getCompanyList()).thenReturn(companyIdNameMockData);
	        Long totalCount = purchHistryServiceImplMock.getPurchaseOrderEntityCount(filterVo);

	        assertEquals(0, totalCount);
	    } catch (Exception e) {
	        Assertions.fail(e.toString());
	    }
	}

	@Test
	public void getPurchaseOrderList_HappyFlow() {
		Integer skip = 1;
		Integer limit = 10;
		List<CompanyDto> value = PurchaseHistoryMockData.getCompanyViewDto();
		List<FilterOrSortingVo> filterVo = PurchaseHistoryMockData.getFilterOrSorting();
//		Map<Integer, String> companyNameMap = PurchaseHistoryMockData.getComMap();
		HashMap<Integer, String> companyIdNameMockData = MockData.companyIdNameMockData();
		List<CompanyAndCountDto> comCount = PurchaseHistoryMockData.getCompanyAndCount();
		List<NotificationCount> notifiCount = PurchaseHistoryMockData.getNotifiCount();
		Object[ ] obj = new Object[23];
		try {

			UserInfo user = PurchaseHistoryMockData.getUserInfo();
			Integer comId1 = user.getCompanyId();
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(user);
//			when(iRestTemplateServiceMock.getCompanyList(filterList)).thenReturn(value);
			when(digitalPaperCache.getCompanyList()).thenReturn(companyIdNameMockData);
			when(iPurchaseHistoryDaoMock.getCompanyAndCountList(companyIdNameMockData, skip, 10, filterVo, Boolean.FALSE)).thenReturn(comCount);
			when(iPurchaseHistoryDaoMock.getNotificationCount(companyIdNameMockData)).thenReturn(notifiCount);
			when(iPurchaseHistoryDaoMock.getAllCompaniesCount()).thenReturn(obj);
			when(purchHistryServiceImplMock.getPurchaseOrderData(skip, limit, filterVo)).thenReturn(comCount);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	public void getPurchaseOrderList_FailFlow() {
		Integer skip = 1;
		Integer limit = 10;
		List<FilterOrSortingVo> filterVo = PurchaseHistoryMockData.getFilterOrSorting();
    	try {
    		when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo1());
    		ApplicationException ap = new ApplicationException(ErrorCodes.UN_AUTHORIZED);
            ApplicationException
                    exception = assertThrows(ApplicationException.class, () -> {
                    	purchHistryServiceImplMock.getPurchaseOrderData(skip, limit, filterVo);
            });
            assertEquals(ap.toString(),exception.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
    }
	
	  
		@Test
		public void getDownloadDataToExcel() {

			List<CompanyAndCountDto> mockDto = PurchaseHistoryMockData.getCompanyAndCount();

			List<String> mockSelectedColumnList = new ArrayList<>();
			mockSelectedColumnList.add(TableConstants.INSURED_COMPANY);
			mockSelectedColumnList.add(TableConstants.TOTAL_TRANSACTION);
			mockSelectedColumnList.add(TableConstants.PENDING_TRANSACTION);

			ArrayList<HashMap<String, Object>> result = purchHistryServiceImplMock.getDownloadDataToExcel(mockDto,
					mockSelectedColumnList);

			Assertions.assertEquals(2, result.size());
		}
		
		
		

		
		@Test
		public void  getpurchaseOrderDataInDownload() throws ApplicationException {
			
			Integer skip = 1;
			Integer limit = 10;
			Map<Integer, String> companyNameMaping=PurchaseHistoryMockData.getcompanyNameMaping();
			 List<FilterOrSortingVo> getFilterOrSorting	=PurchaseHistoryMockData.getFilterOrSorting();
			List<CompanyAndCountDto> companyAndCountList = iPurchaseHistoryDaoMock.getCompanyAndCountList(companyNameMaping,  skip, limit, getFilterOrSorting, Boolean.FALSE);
			List<NotificationCount> getNotificationCount = PurchaseHistoryMockData.getNotifiCount();
			HashMap<Integer, String> companyIdNameMockData = MockData.companyIdNameMockData();
			
			try
			{
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseHistoryMockData.getUserInfo());
//			when(iRestTemplateService.getCompanyList(filterList)).thenReturn(PurchaseHistoryMockData.getCompanyViewDto());
			when(digitalPaperCache.getCompanyList()).thenReturn(companyIdNameMockData);
			when(iPurchaseHistoryDaoMock.getCompanyAndCountList(companyNameMaping,skip,limit,getFilterOrSorting,Boolean.FALSE)).thenReturn(PurchaseHistoryMockData.getCompanyAndCountDto());
			when(iPurchaseHistoryDaoMock.getNotificationCount(companyNameMaping)).thenReturn(PurchaseHistoryMockData.getNotifiCount());
			when(iPurchaseHistoryDaoMock.getAllCompaniesCount()).thenReturn(PurchaseHistoryMockData.getAllCompaniesCount());
//			when()
			purchHistryServiceImplMock.getpurchaseOrderDataInDownload(getFilterOrSorting);
			
			}
			catch (Exception e) {
				Assertions.fail(e.toString());
			}
			
	    	
	    }
		
		
		@Test
		public void  getpurchaseOrderDataInDownload_errorFlow() throws ApplicationException {
			UserInfo user = PurchaseHistoryMockData.getUserInfo();
			Integer comId1 = user.getCompanyId();
			List<FilterOrSortingVo> filterVo = PurchaseHistoryMockData.getFilterOrSorting();
			try {
	    		when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseHistoryMockData.getUserInfo1());
	    		ApplicationException ap = new ApplicationException(ErrorCodes.UN_AUTHORIZED);
	            ApplicationException
	                    exception = assertThrows(ApplicationException.class, () -> {
	                    	purchHistryServiceImplMock.getpurchaseOrderDataInDownload(filterVo);
	                    });
	                    assertEquals(ap.toString(),exception.toString());
	        		} catch (Exception e) {
	        			Assertions.fail(e.toString());
	        		}
	        	}
			
			
		}
		


	 
	 

	
	
	
	
	
	
	



