package com.digitalpaper.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.service.impl.StockServiceImpl;
import com.digitalpaper.test.DigitalPaperUnitTest;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.StockDto;

import mockDatas.MockData;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class StockControllerTest extends DigitalPaperUnitTest{
	
	@InjectMocks
	private StockController controller;
	
	@Mock
	private StockServiceImpl stockServiceMock;
	
	@Test
	void getStockDetails_Happy_flow() throws ApplicationException {
		
		when(stockServiceMock.getStockData()).thenReturn(MockData.getStockVoMockData());
		StockDto actual= controller.getStockDetails();
	}

	

	@Test
	void stockSave_Happy_flow() throws ApplicationException {
		
		when(stockServiceMock.saveOrUpdate(MockData.SaveStockDataVoVoMockData())).thenReturn(1);
		ApplicationResponse actual= controller.stockSave(MockData.SaveStockDataVoVoMockData());
	}
	
//	@Test
//	void saveCompanyId_HappyFlow() {
//		Integer companyId=2;
//		Integer userId=3;
//		
//		doNothing().when(stockServiceMock).saveCompanyId(companyId, userId);
//		controller.saveCompanyId(companyId, userId);
//	}
	
	@Test
	void getStockDetailsBasedOnLoginUser_happy_flow() {
		try {
			when(stockServiceMock.getStockDetailsBasedOnLoginUser()).thenReturn(MockData.getStockVoMockData());
			ApplicationResponse stockDetailsBasedOnLoginUser = controller.getStockDetailsBasedOnLoginUser();
			StockDto stockDto = (StockDto)stockDetailsBasedOnLoginUser.getContent();
			assertEquals(stockDto.getStockCount(), MockData.getStockVoMockData().getStockCount());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

}
