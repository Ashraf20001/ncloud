package com.digitalpaper.servicetest;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.dao.IComplaintsDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.mockdata.PurchaseOrderMockData;
import com.digitalpaper.service.impl.ComplaintsServiceImpl;
import com.digitalpaper.transfer.object.dto.ComplaintsDto;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;

import mockDatas.MockData;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class ComplaintsSeriviceTest {

	
	@InjectMocks
	public ComplaintsServiceImpl complaintsService;
	
	
	@Mock
	private IComplaintsDao complaintsDao;
	
	@Mock
	private LoggedInUserContextHolder loggedInUserContextHolder;
	
	@Test
	void saveComplaintsDetails_Happy_flow() {
		
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo());
			doNothing().when(complaintsDao).saveComplaintsDetails(MockData.getComplaintsMock());
			complaintsService.saveComplaintsDetails(MockData.getComplaintsDtoMock());
			
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	void getComplaintsDetails_Happy_flow() {
		try {
			when(complaintsDao.getComplaintsAllData()).thenReturn(MockData.getListComplaintsMock());
			List<ComplaintsDto> actuallResult = complaintsService.getComplaintsDetails();
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
