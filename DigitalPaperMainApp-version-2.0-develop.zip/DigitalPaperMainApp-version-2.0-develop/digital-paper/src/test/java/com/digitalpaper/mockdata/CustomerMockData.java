package com.digitalpaper.mockdata;

import java.io.File;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.digitalpaper.transfer.object.dto.ChangePasswordDto;
import com.digitalpaper.transfer.object.dto.CustomerDto;
import com.digitalpaper.transfer.object.dto.MailRequestDto;
import com.digitalpaper.transfer.object.dto.MailResponse;
import com.digitalpaper.transfer.object.dto.ResetPasswordDto;
import com.digitalpaper.transfer.object.dto.ResetPasswordRequest;
import com.digitalpaper.transfer.object.entity.Customer;
import com.digitalpaper.transfer.object.entity.ForgetPassword;

public class CustomerMockData {
	public static Customer getCustomerData() {
		Customer customer = new Customer();
		customer.setAddedDate(LocalDateTime.now());
		customer.setCompanyId(2);
		customer.setCreatedBy(3);
		customer.setCreatedDate(LocalDateTime.now());
		customer.setCustomerId(1);
		customer.setEmail("customer@gmail.com");
		customer.setIsFirstTimeLogin(false);
		customer.setUsername("naga");
		customer.setIsDeleted(false);
		customer.setModifiedBy(3);
		customer.setModifiedDate(LocalDateTime.now());
		customer.setPhoneNumber("9243847231");
		customer.setIsDeleted(false);
		customer.setCustomerId(1);
		customer.setIdentity(UUID.randomUUID().toString());
		customer.setPassword("Axa@123");
		customer.setStatus(true);
		return customer;
	}
	
	public static Customer getEncryptedPasswordCustomerData() {
		Customer customer = new Customer();
		customer.setAddedDate(LocalDateTime.now());
		customer.setCompanyId(2);
		customer.setCreatedBy(3);
		customer.setCreatedDate(LocalDateTime.now());
		customer.setCustomerId(1);
		customer.setEmail("customer@gmail.com");
		customer.setIsFirstTimeLogin(false);
		customer.setUsername("naga");
		customer.setIsDeleted(false);
		customer.setModifiedBy(3);
		customer.setModifiedDate(LocalDateTime.now());
		customer.setPhoneNumber("9243847231");
		customer.setIsDeleted(false);
		customer.setCustomerId(1);
		customer.setIdentity(UUID.randomUUID().toString());
		customer.setPassword("$2a$12$MsAFOwJh0NNW5pcta2zvYuCt/AnHOfn.nFbhcfgqGlUIBVh0bvbw6");
		customer.setStatus(true);
		return customer;
	}
	
	public static Customer getFirstTimeLoginCustomerData() {
		Customer customer = new Customer();
		customer.setAddedDate(LocalDateTime.now());
		customer.setCompanyId(2);
		customer.setCreatedBy(3);
		customer.setCreatedDate(LocalDateTime.now());
		customer.setCustomerId(1);
		customer.setEmail("customer@gmail.com");
		customer.setIsFirstTimeLogin(true);
		customer.setUsername("naga");
		customer.setIsDeleted(false);
		customer.setModifiedBy(3);
		customer.setModifiedDate(LocalDateTime.now());
		customer.setPhoneNumber("9243847231");
		customer.setIsDeleted(false);
		customer.setCustomerId(1);
		customer.setIdentity(UUID.randomUUID().toString());
		customer.setPassword("Axa@123");
		customer.setStatus(true);
		return customer;
	}
	
	public static Customer getExistingCustomerData() {
		Customer customer = new Customer();
		customer.setAddedDate(LocalDateTime.now());
		customer.setCompanyId(2);
		customer.setCreatedBy(3);
		customer.setCreatedDate(LocalDateTime.now());
		customer.setCustomerId(1);
		customer.setEmail("customer@gmail.com");
		customer.setIsFirstTimeLogin(false);
		customer.setUsername("cbt");
		customer.setIsDeleted(false);
		customer.setModifiedBy(3);
		customer.setModifiedDate(LocalDateTime.now());
		customer.setPhoneNumber("9243847231");
		customer.setIsDeleted(false);
		customer.setCustomerId(1);
		customer.setIdentity(UUID.randomUUID().toString());
		customer.setPassword("Axa@123");
		customer.setStatus(true);
		return customer;
	}
	
	public static List<Customer> getCustomerList(){
		List<Customer> customerList = new ArrayList<Customer>();
		customerList.add(getCustomerData());
		return customerList;
	}
	
	public static CustomerDto getCustomerDto() {
		CustomerDto customerDto= new CustomerDto();
		customerDto.setAddedDate(LocalDateTime.now().toString());
		customerDto.setCustomerId(1);
		customerDto.setEmail("customer@gmail.com");
		customerDto.setUsername("naga");
		customerDto.setPassword("Axa@123");
		customerDto.setPhoneNumber("9372323342");
		customerDto.setStatus(false);
		customerDto.setCompanyId(2);
		customerDto.setIsFirstTimeLogin(false);
		customerDto.setIdentity(UUID.randomUUID().toString());
		return customerDto;
	}
	
	public static List<CustomerDto> getCustomerDtoList(){
		List<CustomerDto>  customerDtoList=new ArrayList<CustomerDto>();
		customerDtoList.add(getCustomerDto());
		return customerDtoList;
	}
	
	public static ResetPasswordDto getResetPasswordDto() {
		ResetPasswordDto resetPasswordDto = new ResetPasswordDto();
		resetPasswordDto.setNewPassword("test@123");
		resetPasswordDto.setConfirmPassword("test@123");
		resetPasswordDto.setIdentity(UUID.randomUUID().toString());
		return resetPasswordDto;
	}
	
	public static ChangePasswordDto getChangePasswordDto() {
		ChangePasswordDto changePasswordDto = new ChangePasswordDto();
		changePasswordDto.setNewPassword("test@123");
		changePasswordDto.setOldPassword("Axa@123");
		changePasswordDto.setConfirmPassword("test@123");
		return changePasswordDto;

	}
	
	public static MailRequestDto getMailRequestMockData() {
		MailRequestDto mailRequestDto = new MailRequestDto();
		mailRequestDto.setFrom("dpcbt@gmail.com");
		mailRequestDto.setTo("dhanapalsp1998@gmail.com");
		mailRequestDto.setName("cbt");
		mailRequestDto.setSubject("Digital Paper : DP002392");
		String url = "Files-Upload/OG_IMAGE/OG_DP0000029_1685353403518.png";
		File file = new File(url);
		mailRequestDto.setFile(file);

		return mailRequestDto;
	}

	public static Map<String, Object> getModelHashMap() {
		Map<String, Object> model = new HashMap<>();
		model.put("Name","cbt");
		model.put("paperNumber","DP002392");
		model.put("CompanyName", "Axa insurance");
		model.put("policyNo","PO0001");
		model.put("registrationNo","REG08301");
		model.put("userName","naga");
		model.put("password","Axa@123");
		return model;
	}
	
	public static MailResponse getMailResponse() {
		MailResponse response = new MailResponse();
		response.setMessage("mail send to : " + "dhanapalsp1998@gmail.com");
		response.setStatus(Boolean.TRUE);
		return response;
	}
	
	public static ForgetPassword getForgetPasswordMockData() {
		ForgetPassword forgetPassword = new ForgetPassword();
		forgetPassword.setCreatedAt(LocalDate.now());
		forgetPassword.setCustomerDetails(getCustomerData());
		forgetPassword.setCustomerIdentity(UUID.randomUUID().toString());
		forgetPassword.setEmailId("customer@gmail.com");
		forgetPassword.setExpireTime(new Date());
		forgetPassword.setId(1);
		forgetPassword.setIdentity(UUID.randomUUID().toString());
		return forgetPassword;
	}
	
	public static ForgetPassword getForgetPasswordBeforeExpiryTimeMockData() {
		ForgetPassword forgetPassword = new ForgetPassword();
		forgetPassword.setCreatedAt(LocalDate.now());
		forgetPassword.setCustomerDetails(getCustomerData());
		forgetPassword.setCustomerIdentity(UUID.randomUUID().toString());
		forgetPassword.setEmailId("customer@gmail.com");
		Date beforeDateTime = new Date();
		forgetPassword.setExpireTime(new Date(beforeDateTime.getTime() + 1000*60*15));
		forgetPassword.setId(1);
		forgetPassword.setIdentity(UUID.randomUUID().toString());
		return forgetPassword;
	}
	
	public static List<ForgetPassword> getForgetPasswordList(){
		List<ForgetPassword> forgetPasswordList = new ArrayList<ForgetPassword>();
		forgetPasswordList.add(getForgetPasswordMockData());
		forgetPasswordList.add(getForgetPasswordMockData());
		forgetPasswordList.add(getForgetPasswordMockData());
		return forgetPasswordList;
	}
	
	public static List<ForgetPassword> getForgetPasswordSingleList(){
		List<ForgetPassword> forgetPasswordList = new ArrayList<ForgetPassword>();
		forgetPasswordList.add(getForgetPasswordMockData());
		return forgetPasswordList;
	}
	 
	public static ResetPasswordRequest getResetPasswordRequestData() {
		ResetPasswordRequest resetPasswordRequest = new ResetPasswordRequest();
		resetPasswordRequest.setSubject("Reset Password");
		resetPasswordRequest.setTo("customer@gmail.com");
		resetPasswordRequest
				.setTemplate("To resetPassword click here :" + "http://localhost:4200/reset_password" + "/" + "aldufyoarfoiwuf" + "/" + "USI==");
		return resetPasswordRequest;
	}
	
	public static List<ForgetPassword> getEmptyForgetPasswordList(){
		List<ForgetPassword> forgetPasswordList = new ArrayList<ForgetPassword>();
		return forgetPasswordList;
	}
}
