package com.digitalpaper.mockdata;

import com.digitalpaper.transfer.object.dto.StockCountDto;

public class AllocateStockMockData {

	public static StockCountDto getStockCountDto() {
		StockCountDto stockCountDto = new StockCountDto();
		stockCountDto.setTotalCount(10);
		stockCountDto.setTotalCount(1);
		return stockCountDto;

	}
}
