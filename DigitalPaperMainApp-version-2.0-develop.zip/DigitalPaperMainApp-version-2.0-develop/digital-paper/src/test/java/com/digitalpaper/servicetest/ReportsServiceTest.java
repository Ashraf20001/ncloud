package com.digitalpaper.servicetest;

import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.dao.ReportsDao;
import com.digitalpaper.mockdata.PurchaseOrderMockData;
import com.digitalpaper.service.impl.ReportsServiceImpl;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class ReportsServiceTest {

	
	@InjectMocks
	private ReportsServiceImpl serviceMock;
	
	
	@Mock
	private ReportsDao daoMock;
	
	@Mock
	private LoggedInUserContextHolder loggedInUserContextHolder;
	
	
	@Test
	void getReportDetailsInCard_Happy_Flow() {
		
		Integer userId=3;
		when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo());
		when(daoMock.getreportsDataBasedOnUserId(userId)).thenReturn(null)
		
	}
}
