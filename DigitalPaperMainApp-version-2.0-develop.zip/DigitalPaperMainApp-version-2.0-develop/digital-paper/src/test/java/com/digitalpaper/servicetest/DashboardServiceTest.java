package com.digitalpaper.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.config.DigitalPaperCache;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.dao.IPaperDetailsDao;
import com.digitalpaper.daoImp.DashBoardDaoImpl;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.mockdata.DashBoardMockData;
import com.digitalpaper.mockdata.PaperDetailsMockData;
import com.digitalpaper.mockdata.PurchaseHistoryMockData;
import com.digitalpaper.mockdata.PurchaseOrderMockData;
import com.digitalpaper.purchasestock.dao.PurchaseStockDao;
import com.digitalpaper.restemplate.service.IRestTemplateService;
import com.digitalpaper.service.impl.DashBoardServiceImpl;
import com.digitalpaper.transfer.object.dto.BarChartDto;
import com.digitalpaper.transfer.object.dto.CompanyViewDto;
import com.digitalpaper.transfer.object.dto.DashBoardInputDto;
import com.digitalpaper.transfer.object.dto.DashBoardOutputDto;
import com.digitalpaper.transfer.object.dto.DoughNutDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.entity.FileStorage;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.entity.PaymentDetails;
import com.digitalpaper.transfer.object.entity.StockFileMapping;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;

import mockDatas.MockData;


@WebAppConfiguration
@ExtendWith(SpringExtension.class)
@ContextConfiguration
@SpringBootTest(classes=DigitalPaperApplication.class)
public class DashboardServiceTest {

	@InjectMocks
	private DashBoardServiceImpl serviceMock;

	@Mock
	private DashBoardDaoImpl daoMock;

	@Mock
	private LoggedInUserContextHolder loggedInUserContextHolder;

	@Mock
	private IRestTemplateService iRestTemplateServiceMock;
	
	@Mock
	private IRestTemplateService iRestTemplateService;
	
	@Mock
	private IPaperDetailsDao iPaperDetailsDao;
	
	@Mock
	private PurchaseStockDao purchaseStockDao;
	
	@Mock
	private DigitalPaperCache digitalPaperCache;
	
	
	
	@Test
	public void getInsBarChart_HappyFlow() {
		try {
			UserInfo user = PurchaseHistoryMockData.getUserInfo();
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(user);
			when(daoMock.getStockAllocatedCountByMonth(any(DashBoardInputDto.class), anyInt(),anyInt()))
					.thenReturn(DashBoardMockData.getMonthCount());
			when(daoMock.getCertificateIssuedCountByMonth(any(DashBoardInputDto.class), anyInt(),anyInt()))
					.thenReturn(DashBoardMockData.getMonthCount());
			List<BarChartDto> barChartDataForInsCompany = serviceMock.getBarChartDataForInsCompany(DashBoardMockData.getDashBoardInputDto1());
			assertNotNull(barChartDataForInsCompany);
		} catch (Exception e) { 
			Assertions.fail(e.toString());   
		} 
	}
	
	@Test
	void getCompanyRecentDigitalPapers_HappyFlow() {
		DashBoardInputDto dashBoardInputDto = DashBoardMockData.getDashBoardInputDto();
		UserInfo userInfo = PurchaseOrderMockData.getUserInfo1();
		Integer companyId=userInfo.getCompanyId();
		Integer allocationUserType = userInfo.getAllocationUserType();
		List<PaperDetails> expected = PaperDetailsMockData.getPaperDetails();
		FileStorage fileStorage = PaperDetailsMockData.getFileStorage();
		Integer paperId=1;
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(userInfo);
			when(daoMock.getRecentAndExpiredPaperDetails(Boolean.FALSE,Boolean.FALSE, companyId,allocationUserType,dashBoardInputDto)).thenReturn(expected);
			when(iPaperDetailsDao.getPaperImageById(paperId,
					ApplicationConstants.UPD_TYPE, ApplicationConstants.RP_TYPE)).thenReturn(fileStorage);
			
			assertNotNull(serviceMock.getCompanyRecentDigitalPapers(dashBoardInputDto));
			} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
			
	@Test
	public void getInsBarChart1_HappyFlow() {
		try {
			UserInfo user = PurchaseHistoryMockData.getUserInfo();
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(user);
			when(daoMock.getStockAllocatedCountByMonth(any(),any(),any())).thenReturn(DashBoardMockData.getMonthCount());
			when(daoMock.getCertificateIssuedCountByMonth(any(),any(),any())).thenReturn(DashBoardMockData.getMonthCount());
			List<BarChartDto> barChartDataForInsCompany = serviceMock.getBarChartDataForInsCompany(DashBoardMockData.getDashBoardInputDto2());
			assertNotNull(barChartDataForInsCompany);
		} catch (Exception e) { 
			Assertions.fail(e.toString());   
		} 
	}

	@Test
	public void getInsBarChart_ErrorFlow() {
		try {
			UserInfo user = PurchaseHistoryMockData.getUserInfo();
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(user);
			when(daoMock.getStockAllocatedCountByMonth(any(),any(),any())).thenReturn(DashBoardMockData.getMonthCount());
			when(daoMock.getCertificateIssuedCountByMonth(any(),any(),any())).thenReturn(DashBoardMockData.getMonthCount1());
			List<BarChartDto> barChartDataForInsCompany = serviceMock.getBarChartDataForInsCompany(DashBoardMockData.getDashBoardInputDto1());
			assertNotNull(barChartDataForInsCompany);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getCompanyExpiryDigitalPapers_HappyFlow() {
		UserInfo userInfo = PurchaseOrderMockData.getUserInfo1();
		Integer companyId=userInfo.getCompanyId();
		Integer allocationUserType = userInfo.getAllocationUserType();
		List<PaperDetails> expected = PaperDetailsMockData.getPaperDetails();
		FileStorage fileStorage = PaperDetailsMockData.getFileStorage();
		DashBoardInputDto dashBoardInputDto = DashBoardMockData.getDashBoardInputDto();
		Integer paperId=1;
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(userInfo);
			when(daoMock.getRecentAndExpiredPaperDetails(Boolean.FALSE,Boolean.TRUE, companyId,allocationUserType,dashBoardInputDto)).thenReturn(expected);
			when(iPaperDetailsDao.getPaperImageById(paperId,
					ApplicationConstants.UPD_TYPE, ApplicationConstants.RP_TYPE)).thenReturn(fileStorage);
			
			assertNotNull(serviceMock.getCompanyExpiryDigitalPapers(dashBoardInputDto));
			
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	
	@Test
	void getAllCompaniesRecentTransaction_HappyFlow() {
		DashBoardInputDto dashBoardInputDto = DashBoardMockData.getDashBoardInputDto();
		UserInfo userInfo = PurchaseOrderMockData.getUserInfo();
		List<PaymentDetails> expected = PurchaseOrderMockData.getListOfPaymentDetails();
		Integer orderId=1;
		StockFileMapping stockFileMapping = PurchaseOrderMockData.getStockFileMapping();
		HashMap<Integer, String> companyIdNameMockData = MockData.companyIdNameMockData();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(userInfo);
			when(daoMock.getAllCompaniesRecentTransaction(dashBoardInputDto)).thenReturn(expected);
//			when(iRestTemplateService.getCompanyList(filterList)).thenReturn(companyViewDto);
			when(digitalPaperCache.getCompanyList()).thenReturn(companyIdNameMockData);
			when(purchaseStockDao.getStockFileMappingByOrderId(orderId)).thenReturn(null);
			when(purchaseStockDao.getStockFileMappingByOrderId(orderId)).thenReturn(stockFileMapping);
			assertNotNull(serviceMock.getAllCompaniesRecentTransaction(dashBoardInputDto));
			
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getAllCompaniesRecentTransaction_HappyFlow_ErrorFlow() {
		UserInfo userInfo = PurchaseOrderMockData.getUserInfo1();
		DashBoardInputDto dashBoardInputDto = DashBoardMockData.getDashBoardInputDto();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(userInfo);
			ApplicationException exception = new ApplicationException(ErrorCodes.UN_AUTHORIZED);
			ApplicationException exception2 = assertThrows(ApplicationException.class,()->{
				serviceMock.getAllCompaniesRecentTransaction(dashBoardInputDto);
			});
			assertEquals(exception.toString(),exception2.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	

	@Test
	void getAllCompaniesRecentTransaction_HappyFlow_ErrorFlow3() {
		UserInfo userInfo = PurchaseOrderMockData.getUserInfo();
		DashBoardInputDto dashBoardInputDto = DashBoardMockData.getDashBoardInputDto();
		List<PaymentDetails> expected = PurchaseOrderMockData.getListOfPaymentDetails();
		HashMap<Integer, String> companyIdNameMockData = MockData.companyIdNameMockData();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(userInfo);
			when(daoMock.getAllCompaniesRecentTransaction(dashBoardInputDto)).thenReturn(expected);
//			when(iRestTemplateService.getCompanyList(filterList)).thenReturn(null);
			when(digitalPaperCache.getCompanyList()).thenReturn(companyIdNameMockData);
			ApplicationException exception = new ApplicationException(ErrorCodes.NO_COMPANY_DATA_FOUND);
			ApplicationException exception2 = assertThrows(ApplicationException.class, ()->{
				serviceMock.getAllCompaniesRecentTransaction(dashBoardInputDto);
			});
			assertEquals(exception.toString(),exception2.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getAllCompaniesRecentDigitalPapers_HappyFlow() {
		UserInfo userInfo = PurchaseOrderMockData.getUserInfo();
		List<PaperDetails> expected = PaperDetailsMockData.getPaperDetails();
		DashBoardInputDto dashBoardInputDto = DashBoardMockData.getDashBoardInputDto();
		FileStorage fileStorage = PaperDetailsMockData.getFileStorage();
		Integer paperId = 1;
		HashMap<Integer, String> companyIdNameMockData = MockData.companyIdNameMockData();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(userInfo);
			when(daoMock.getRecentAndExpiredPaperDetails(Boolean.TRUE, Boolean.FALSE, null,null,dashBoardInputDto)).thenReturn(expected);
//			when(iRestTemplateService.getCompanyList(filterList)).thenReturn(companyViewDto);
			when(digitalPaperCache.getCompanyList()).thenReturn(companyIdNameMockData);
			when(iPaperDetailsDao.getPaperImageById(paperId, ApplicationConstants.UPD_TYPE,
					ApplicationConstants.RP_TYPE)).thenReturn(fileStorage);
			assertNotNull(serviceMock.getAllCompaniesRecentDigitalPapers(dashBoardInputDto));

		} catch (Exception e) {
			Assertions.fail(e.toString());
		}

	}
	
	@Test
	void getAllCompaniesRecentDigitalPapers_ErrorFlow() {
		UserInfo userInfo = PurchaseOrderMockData.getUserInfo1();
		DashBoardInputDto dashBoardInputDto = DashBoardMockData.getDashBoardInputDto();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(userInfo);
			ApplicationException exception = new ApplicationException(ErrorCodes.UN_AUTHORIZED);
			ApplicationException exception2 = assertThrows(ApplicationException.class,()->{
				serviceMock.getAllCompaniesRecentDigitalPapers(dashBoardInputDto);
			});
			assertEquals(exception.toString(),exception2.toString());
				} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	@Test
	public void getAuthorityBarChart_HappyFlow() {
		HashMap<Integer, String> companyIdNameMockData = MockData.companyIdNameMockData();
		try {
			UserInfo user = PurchaseHistoryMockData.getUserInfo();
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(user);
//			when(iRestTemplateServiceMock.getCompanyList(filterList)).thenReturn(value);
			when(digitalPaperCache.getCompanyList()).thenReturn(companyIdNameMockData);
			when(serviceMock.getBarChartForAuthority(DashBoardMockData.getDashBoardInputDto()))
					.thenReturn(DashBoardMockData.getAuthorityBarChart());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void getAuthorityBarChart_ErrorFlow() {
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseHistoryMockData.getUserInfo1());
			ApplicationException ap = new ApplicationException(ErrorCodes.UN_AUTHORIZED);
			ApplicationException exception = assertThrows(ApplicationException.class, () -> {
				serviceMock.getBarChartForAuthority(DashBoardMockData.getDashBoardInputDto());
			});
			assertEquals(ap.toString(), exception.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	
	@Test
	void getAllCompaniesRecentDigitalPapers_ErrorFlow3() {
		UserInfo userInfo = PurchaseOrderMockData.getUserInfo();
		List<PaperDetails> expected = PaperDetailsMockData.getPaperDetails();
		DashBoardInputDto dashBoardInputDto = DashBoardMockData.getDashBoardInputDto();
//		List<FilterOrSortingVo> filterList = new ArrayList<FilterOrSortingVo>();
		HashMap<Integer, String> companyIdNameMockData = MockData.companyIdNameMockData();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(userInfo);
			when(daoMock.getRecentAndExpiredPaperDetails(Boolean.TRUE, Boolean.FALSE, null,null,dashBoardInputDto)).thenReturn(expected);
//			when(iRestTemplateService.getCompanyList(filterList)).thenReturn(null);
			when(digitalPaperCache.getCompanyList()).thenReturn(companyIdNameMockData);
			ApplicationException exception = new ApplicationException(ErrorCodes.NO_COMPANY_DATA_FOUND);
			ApplicationException exception2 = assertThrows(ApplicationException.class, ()->{
				serviceMock.getAllCompaniesRecentDigitalPapers(dashBoardInputDto);
			});
			assertEquals(exception.toString(),exception2.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getTopPurchaseData_HappyFlow() {
		UserInfo userInfo = PurchaseOrderMockData.getUserInfo();
		DashBoardInputDto dashBoardInputDto = DashBoardMockData.getDashBoardInputDto();
		HashMap<Integer, String> companyIdNameMockData = MockData.companyIdNameMockData();		
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(userInfo);
			when(daoMock.getTopPurchaseCompanies(dashBoardInputDto.getFromDate(),dashBoardInputDto.getToDate())).thenReturn(DashBoardMockData.getDashBoardObjects());
//			when(iRestTemplateService.getCompanyList(filterList)).thenReturn(companyViewDto);
			when(digitalPaperCache.getCompanyList()).thenReturn(companyIdNameMockData);
			assertNotNull(serviceMock.getTopPurchaseData(dashBoardInputDto));
			
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
		
	}
	
	@Test
	void getTopPurchaseData_ErrorFlow() {
		UserInfo userInfo = PurchaseOrderMockData.getUserInfo1();
		DashBoardInputDto dashBoardInputDto = DashBoardMockData.getDashBoardInputDto();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(userInfo);
			ApplicationException exception = new ApplicationException(ErrorCodes.UN_AUTHORIZED);
			ApplicationException exception2 = assertThrows(ApplicationException.class,()->{
				serviceMock.getTopPurchaseData(dashBoardInputDto);
			});
			assertEquals(exception.toString(),exception2.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getTopPurchaseData_ErrorFlow3() {
		UserInfo userInfo = PurchaseOrderMockData.getUserInfo();
		DashBoardInputDto dashBoardInputDto = DashBoardMockData.getDashBoardInputDto();
//		List<FilterOrSortingVo> filterList = new ArrayList<FilterOrSortingVo>();
		HashMap<Integer, String> companyIdNameMockData = MockData.companyIdNameMockData();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(userInfo);
			when(daoMock.getTopPurchaseCompanies(dashBoardInputDto.getFromDate(),dashBoardInputDto.getToDate())).thenReturn(DashBoardMockData.getDashBoardObjects());
//			when(iRestTemplateService.getCompanyList(filterList)).thenReturn(null);
			when(digitalPaperCache.getCompanyList()).thenReturn(companyIdNameMockData);
			ApplicationException exception = new ApplicationException(ErrorCodes.NO_COMPANY_DATA_FOUND);
			ApplicationException exception2 = assertThrows(ApplicationException.class, () -> {
				serviceMock.getTopPurchaseData(dashBoardInputDto);
			});
			assertEquals(exception.toString(), exception2.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getAllCompanyIds_HappyFlow() {
		UserInfo userInfo = PurchaseOrderMockData.getUserInfo();
		List<Integer> companyIdList = DashBoardMockData.getCompanyIdList();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(userInfo);
			when(daoMock.getPaymentCompanyIds()).thenReturn(companyIdList);
			assertNotNull(serviceMock.getAllCompanyIds());
			
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getAllCompanyIds_ErrorFlow() {
		UserInfo userInfo = PurchaseOrderMockData.getUserInfo1();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(userInfo);
			ApplicationException exception = new ApplicationException(ErrorCodes.UN_AUTHORIZED);
			ApplicationException exception2 = assertThrows(ApplicationException.class,()->{
				serviceMock.getAllCompanyIds();
			});
			assertEquals(exception.toString(),exception2.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getAllPaperCompanyIds_HappyFlow() {
		UserInfo userInfo = PurchaseOrderMockData.getUserInfo();
		List<Integer> companyIdList = DashBoardMockData.getCompanyIdList();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(userInfo);
			when(daoMock.getPaperDetailsCompanyIds()).thenReturn(companyIdList);
			assertNotNull(serviceMock.getAllPaperCompanyIds());
			
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getAllPaperCompanyIds_ErrorFlow() {
		UserInfo userInfo = PurchaseOrderMockData.getUserInfo1();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(userInfo);
			ApplicationException exception = new ApplicationException(ErrorCodes.UN_AUTHORIZED);
			ApplicationException exception2 = assertThrows(ApplicationException.class,()->{
				serviceMock.getAllPaperCompanyIds();
			});
			assertEquals(exception.toString(),exception2.toString());
				} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	void getPredictionData_happy_flow() {
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo1());
			when(daoMock.getPaperGeneratedCountInCuurentMonth(any(LocalDateTime.class),any(LocalDateTime.class), anyInt())).thenReturn(10l);
			when(daoMock.getPaperGenerateCountBasedOnMonthAndCompany(anyInt())).thenReturn(DashBoardMockData.getListMonthCountDto());
			DashBoardOutputDto predictionData = serviceMock.getPredictionData();
//			assertEquals(predictionData.getDashBoardValues().get(0).getYAxis(), 10);
			assertNotNull(predictionData);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	  
    @Test
    public void getInsuranceDoughNutChartData_HappyFlow()
    {
        
        try {
            when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo());
            when(daoMock.getStatusCount(any(Integer.class),any(Boolean.class), any(DashBoardInputDto.class))).thenReturn(DashBoardMockData.getDoughNutDtoData());
            DoughNutDto insuranceDoughNutChartData = serviceMock.getInsuranceDoughNutChartData(DashBoardMockData.getDashBoardInputDto());
            assertEquals(insuranceDoughNutChartData.getRevoked(), DashBoardMockData.getDoughNutDtoData().getRevoked());
        } catch (Exception e) {
            Assertions.fail(e.toString());
        }
        
        
    }
    
	@Test
	public void getAssociationDoughNutChartData_HappyFlow() {

		try {
//          when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo());
			when(daoMock.getStatusCount(any(), any(Boolean.class), any(DashBoardInputDto.class)))
					.thenReturn(DashBoardMockData.getDoughNutDtoData());
			DoughNutDto insuranceDoughNutChartData = serviceMock
					.getAssociationDoughNutChartData(DashBoardMockData.getDashBoardInputDto());
			assertEquals(insuranceDoughNutChartData.getRevoked(), DashBoardMockData.getDoughNutDtoData().getRevoked());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
  
    }

}
