package com.digitalpaper.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.List;

import javax.mail.MessagingException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.mockdata.CustomerMockData;
import com.digitalpaper.mockdata.PurchaseOrderMockData;
import com.digitalpaper.service.CustomerService;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.ChangePasswordDto;
import com.digitalpaper.transfer.object.dto.CustomerDto;
import com.digitalpaper.transfer.object.dto.ResetPasswordDto;

import freemarker.core.ParseException;
import freemarker.template.MalformedTemplateNameException;
import freemarker.template.TemplateException;
import freemarker.template.TemplateNotFoundException;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class CustomerControllerTest {
	
	@InjectMocks
	private CustomerController customerController;
	
	@Mock
	private CustomerService customerService;
	
	@Test
	void getcustomerList_HappyFlow() {
		Integer min=0;
		Integer max=10;
		List<FilterOrSortingVo> filterMock= PurchaseOrderMockData.getListFilterOrSortingVo();
		List<CustomerDto> expected=CustomerMockData.getCustomerDtoList();
		try {
			when(customerService.getCustomerList(min, max, filterMock)).thenReturn(CustomerMockData.getCustomerDtoList());
			ApplicationResponse actual = customerController.getcustomerList(min, max, filterMock);
			assertNotNull(actual);
		} catch (ApplicationException e) {
			Assertions.fail(e.toString());
		}
	}
	
	
	@Test
	void getCustomerData_Happy_flow() {
		
		try {
			when(customerService.getLoginCustomerDetails()).thenReturn(CustomerMockData.getCustomerDto());
			ApplicationResponse actualResult = customerController.getCustomerData();
			assertNotNull(actualResult.getContent());
		} catch (ApplicationException e) {
			Assertions.fail(e.toString());
		}
		
	}
	
	@Test
	void getCustomerCount_Happy_Flow() {
		
		List<FilterOrSortingVo> filterMock= PurchaseOrderMockData.getListFilterOrSortingVo();
		long count = 12;
		try {
			when(customerService.getCoustomerCount(filterMock)).thenReturn(count);
			ApplicationResponse actuallResult = customerController.getCustomerCount(filterMock);
			assertNotNull(actuallResult);
		} catch (ApplicationException e) {
			
			e.printStackTrace();
		}
		
	}
	
	@Test
	void updateCustomer_Happy_Flow() throws TemplateNotFoundException, MalformedTemplateNameException, ParseException, ApplicationException, MessagingException, IOException, TemplateException {
		
		when(customerService.updatCustomerDetails(CustomerMockData.getCustomerDto())).thenReturn(null);
		ApplicationResponse actualResult = customerController.updateCustomer(CustomerMockData.getCustomerDto());
		assertNotNull(actualResult);
	}
	
	@Test
	void updateLoginCustomer_Happy_Flow() {
		
		try {
			doNothing().when(customerService).updateLoginCustomer(CustomerMockData.getCustomerDto());
			customerController.updateLoginCustomer(CustomerMockData.getCustomerDto());
		} catch (ApplicationException e) {
			Assertions.fail(e.toString());
		}
		
	
	}
	
	@Test
	void getCustomerByUsername_HappyFlow() {
		
		String username="naga";
		CustomerDto customerDtoMock = CustomerMockData.getCustomerDto();
		try {
			when(customerService.getCustomerByUsername(username)).thenReturn(customerDtoMock);
			ResponseEntity<CustomerDto> customerByUsername = customerController.getCustomerByUsername(username);
			assertNotNull(customerByUsername.getBody());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getResetFirstTimePassword_HappyFlow() {
		
		ResetPasswordDto resetPasswordDto = CustomerMockData.getResetPasswordDto();
		
		try {
			doNothing().when(customerService).resetCustomerPassword(resetPasswordDto);
			ApplicationResponse resetFirstTimePassword = customerController.resetFirstTimePassword(resetPasswordDto);
			assertNotNull(resetFirstTimePassword.getContent());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getforgetPassword_HappyFlow() {
		String emailId="customer@gmail.com";
		String validateEmail="valid Email Id";
		
		try {
			when(customerService.validateEmail(emailId)).thenReturn(validateEmail);
			ApplicationResponse forgetPassword = customerController.forgetPassword(emailId);
			assertNotNull(forgetPassword.getContent());
		} catch (ApplicationException e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getUpdatePassword_HappyFlow() {
		ResetPasswordDto resetPasswordDto = CustomerMockData.getResetPasswordDto();
		String updateStatus=ApplicationConstants.UPDATE_SUCCESS;
		try {
			when(customerService.updateCustomerPassword(resetPasswordDto)).thenReturn(updateStatus);
			ApplicationResponse updatePassword = customerController.updatePassword(resetPasswordDto);
			assertNotNull(updatePassword.getContent());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getchangePassword_HappyFow() {
		ChangePasswordDto changePasswordDto = CustomerMockData.getChangePasswordDto();
		try {
			doNothing().when(customerService).changePassword(changePasswordDto);
			customerController.changePassword(changePasswordDto);
			
		} catch (ApplicationException e) {
			Assertions.fail(e.toString());
		}
	}
	
}
