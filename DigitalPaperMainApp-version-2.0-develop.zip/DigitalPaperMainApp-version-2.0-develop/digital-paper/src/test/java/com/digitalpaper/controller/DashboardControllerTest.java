package com.digitalpaper.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertEquals;


import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.mockdata.DashBoardMockData;
import com.digitalpaper.mockdata.PaperDetailsMockData;
import com.digitalpaper.service.DashBoardService;
import com.digitalpaper.transfer.object.dto.DashBoardInputDto;
import com.digitalpaper.transfer.object.dto.DashBoardOutputDto;
import com.digitalpaper.transfer.object.dto.TopCompanyPurchaseDto;
import com.digitalpaper.transfer.object.core.ApplicationResponse;

import mockDatas.MockData;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes =DigitalPaperApplication.class)
public class DashboardControllerTest {

	@InjectMocks
	private DashBoardController dashBoardController;
	
	@Mock
	private DashBoardService dashBoardService;
	
	@Test
	void getRecentDigitalPapers_HappyFlow() {
	
		try {
			when(dashBoardService.getCompanyRecentDigitalPapers()).thenReturn(PaperDetailsMockData.getPaperDetailsDto());
			dashBoardController.getRecentDigitalPapers();
		} catch (ApplicationException e) {
			Assertions.fail(e.toString());
		}
		
	}
	
	@Test
	void getExpiryDigitalPapers_HappyFlow() {
		try {
			when(dashBoardService.getCompanyExpiryDigitalPapers()).thenReturn(PaperDetailsMockData.getPaperDetailsDto());
			dashBoardController.getUpcomingExpiryDigitalPapers();
		} catch (ApplicationException e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getAllRecentDigitalPapers_HappyFlow() {
		try {
			when(dashBoardService.getAllCompaniesRecentDigitalPapers()).thenReturn(PaperDetailsMockData.getPaperDetailsDto());
			dashBoardController.getAllRecentDigitalPapers();
			} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	void getPredictionData_happy_flow() {
		try {
			when(dashBoardService.getPredictionData()).thenReturn(DashBoardMockData.getListOfGrapValueDto());
			ApplicationResponse predictionData = dashBoardController.getPredictionData();
			assertEquals(predictionData.getContent(), DashBoardMockData.getListOfGrapValueDto());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getAllRecentTransactions_HappyFlow() {
		try {
			when(dashBoardService.getAllCompaniesRecentTransaction()).thenReturn(MockData.getViewHistoryDtoList());
			dashBoardController.getAllRecentTransactions();
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getTopCompaniesPurchases_HappyFlow() {
		
		DashBoardInputDto dashBoardInputDto = DashBoardMockData.getDashBoardInputDto();
		List<TopCompanyPurchaseDto> topPurchaseCompaniesList = DashBoardMockData.getTopPurchaseCompaniesList();
		try {
			when(dashBoardService.getTopPurchaseData(dashBoardInputDto)).thenReturn(topPurchaseCompaniesList);
			dashBoardController.getTopCompaniesPurchases(dashBoardInputDto);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getAllCompaniesId_HappyFlow() {
		List<Integer> expected = DashBoardMockData.getCompanyIdList();
		try {
			when(dashBoardService.getAllCompanyIds()).thenReturn(expected);
			dashBoardController.getAllCompaniesId();
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getPaperComapnyIds_HappyFlow() {
		List<Integer> expected = DashBoardMockData.getCompanyIdList();
		try {
			when(dashBoardService.getAllPaperCompanyIds()).thenReturn(expected);
			dashBoardController.getPaperComapnyIds();
			} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

		@Test
	public void getInsCompanyBarChart() {
		try {
			when(dashBoardService.getBarChartDataForInsCompany(DashBoardMockData.getDashBoardInputDto()))
					.thenReturn(DashBoardMockData.getBarChartList());
			ApplicationResponse response = dashBoardController.getBarChartDataForInsCompany(DashBoardMockData.getDashBoardInputDto());
			assertNotNull(response);
			} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void getAuthorityBarChart() {
		try {
			when(dashBoardService.getBarChartForAuthority(DashBoardMockData.getDashBoardInputDto()))
					.thenReturn(DashBoardMockData.getAuthorityBarChart());
			ApplicationResponse response = dashBoardController.getBarChartForAuthority(DashBoardMockData.getDashBoardInputDto());
			assertNotNull(response);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
    public void testGetInsurancePieChartData()  {
        try {
            when(dashBoardService.getInsuranceDoughNutChartData(DashBoardMockData.getDashBoardInputDto())).thenReturn(DashBoardMockData.getDoughNutDtoData());
            dashBoardController.getInsurancePieChartData(DashBoardMockData.getDashBoardInputDto());
        } catch (ApplicationException e) {
            Assertions.fail(e.toString());
        }
       
    
    }
    
    @Test
    public void getAssociationPieChartData() {
        
   
        try {
            when(dashBoardService.getAssociationDoughNutChartData(DashBoardMockData.getDashBoardInputDto()))
                    .thenReturn(DashBoardMockData.getDoughNutDtoData());
            dashBoardController.getAssociationPieChartData(DashBoardMockData.getDashBoardInputDto());
        } catch (ApplicationException e) {
            Assertions.fail(e.toString());
        }
   }
}
