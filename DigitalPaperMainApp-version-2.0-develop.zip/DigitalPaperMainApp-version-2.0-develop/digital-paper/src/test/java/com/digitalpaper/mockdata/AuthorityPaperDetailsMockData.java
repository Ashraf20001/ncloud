package com.digitalpaper.mockdata;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.modelmapper.ModelMapper;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.transfer.object.dto.AuthorityStockDto;
import com.digitalpaper.transfer.object.dto.CompanyTransactionDto;
import com.digitalpaper.transfer.object.dto.DownloadListVo;
import com.digitalpaper.transfer.object.enums.PaperDetailsStatusEnum;

public class AuthorityPaperDetailsMockData {

	public static List<AuthorityStockDto> getAuthorityStockDtoList() {
		List<AuthorityStockDto> list = new ArrayList<>();
		AuthorityStockDto dto = new AuthorityStockDto();
		dto.setCompanyId(1);
		dto.setStockCount(100);
		dto.setAvailableStock(50);
		dto.setPaperIssued(50);
		dto.setInsuredComapny("abc");
		list.add(dto);
		return list;
	}
	
	public static Object getObject() {
		Object obj = null;
		List<Integer> nt = new ArrayList<>();	
		nt.add(1);
		nt.add(2);
		nt.add(3);
		ModelMapper map = new ModelMapper();
		obj = map.map(nt, Object.class);
		return obj;
	}
	
	public static Object getObj() {
		Object obj = null;
		List<Long> lang = new ArrayList<>();
		lang.add(10l);
		lang.add(20l);
		lang.add(30l);
		ModelMapper map = new ModelMapper();
		obj = map.map(lang, Object.class);
		return obj;
	}
	public static List<AuthorityStockDto> getAuthorityStockDtoForObject() {
		List<AuthorityStockDto> list = new ArrayList<>();
		AuthorityStockDto dto = new AuthorityStockDto();
		Object obj = getObject();
		ModelMapper map = new ModelMapper();
		Integer[] i = null;
		i=map.map(obj, Integer[].class);
		dto.setStockCount(i[0]);
		dto.setPaperIssued(i[1]);
		dto.setAvailableStock(i[2]);
		list.add(dto);
		return list;
	}
	
	public static CompanyTransactionDto getCompanyTransactionDto() {
		CompanyTransactionDto companyTransactionDto = new CompanyTransactionDto();

		companyTransactionDto.setCompanyId(getCompanyIdList());
		companyTransactionDto.setFilter(getListFilterOrSortingVo());
		companyTransactionDto.setMax(10);
		companyTransactionDto.setMin(0);

		return companyTransactionDto;
	}

	public static List<Integer> getCompanyIdList() {
		List<Integer> companyIdList = new ArrayList<Integer>();
		companyIdList.add(1);
		companyIdList.add(2);
		return companyIdList;
	}
	
	  public static List<FilterOrSortingVo> getListFilterOrSortingVo(){
		  List<FilterOrSortingVo> list = new ArrayList<>();
		  list.add(getFilterOrSortingVo());
		  return list;

	  }
	
	  public static FilterOrSortingVo getFilterOrSortingVo() {
		  FilterOrSortingVo vo = new FilterOrSortingVo();
		  List<String> valueList=new ArrayList<String>();
		  valueList.add(PaperDetailsStatusEnum.ACTIVE.getStatusIdByName());
		  vo.setColumnName("status");
		  vo.setCondition("Equal");
		  vo.setFilterOrSortingType("FILTER");
		  vo.setType("Integer");
		  vo.setValueList(valueList);
		  return vo;
	  }
	  
		public static DownloadListVo getDownloadListVo() {

			DownloadListVo downloadListVo = new DownloadListVo();
			FilterOrSortingVo filterOrSortingVo = new FilterOrSortingVo();
			filterOrSortingVo.setColumnName("");
			filterOrSortingVo.setCondition("Equal");
			filterOrSortingVo.setValue("0");
			filterOrSortingVo.setType("Integer");
			List<String> columnList = new ArrayList<String>();
			columnList.add(ApplicationConstants.TAB_DIGITAL_PAPER_NO);
			columnList.add(TableConstants.TAB_STOCK_COUNT);
			columnList.add(TableConstants.TAB_AVAILABLE_STOCK);
			columnList.add(TableConstants.TAB_PAPERS_ISSUED);
//			 List<String> columnList = Arrays.asList("Column1", "Column2", "Column3");

//			 List<Integer> companyId = Arrays.asList(1, 2, 3);
			List<Integer> companyId = new ArrayList<Integer>();
			companyId.add(1);
			companyId.add(2);
			downloadListVo.setColumnList(columnList);
			downloadListVo.setCompanyId(companyId);
			downloadListVo.setMax(144);
			downloadListVo.setMin(39);
			downloadListVo.setFilterVo(getListFilterOrSortingVo());
			

			return downloadListVo;

		}
		
		public  static Object[] getTotalStockCount() {
		    Object[] mockData = new Object[3];
		    mockData[0] = 100; // totalStockCount
		    mockData[1] = 80; // availableCount
		    mockData[2] = 20; // paperIssuedCount
		    return mockData;
		}
	
		public static ArrayList<HashMap<String, Object>>  getExcelDataList() {

			ArrayList<HashMap<String, Object>> excelDataList = new ArrayList<HashMap<String, Object>>();

			HashMap<String, Object> dataMap = new HashMap<String, Object>();

			dataMap.put(TableConstants.TAB_INSURED_COMAPNY, "abc");
			dataMap.put(TableConstants.TAB_STOCK_COUNT, 30);
			dataMap.put(TableConstants.TAB_AVAILABLE_STOCK, 500);
			dataMap.put(TableConstants.TAB_PAPERS_ISSUED, 499);
			excelDataList.add(dataMap);
			return excelDataList;
		}
		
		
		public static List<String>  getMetaDataList() {
			List<String>  getMetaDataList = new ArrayList<>();
			getMetaDataList.add(ApplicationConstants.TAB_DIGITAL_PAPER_NO);
			getMetaDataList.add(TableConstants.TAB_STOCK_COUNT);
			getMetaDataList.add(TableConstants.TAB_AVAILABLE_STOCK);
			getMetaDataList.add(TableConstants.TAB_PAPERS_ISSUED);
			
			return getMetaDataList ;
			
			
		}
		
		public static List<String> getEntityColumnNames() {
			
			List<String>  list = new ArrayList<String>();
			list.add("string1");
			list.add("string2");
			
			return list;
			
			
		}
		
		public static List<Integer> getCompanyId()
		{
			List<Integer> companyId = new ArrayList<Integer>();
			 companyId.add(1);
			 companyId.add(2);
			return companyId;
		}
		
		public static List<String> getEntityColumnList()
		{
		List<String> getEntityColumnList = new ArrayList<String>();
		getEntityColumnList.add(TableConstants.PD_DIGITAL_PAPER_ID);
		getEntityColumnList.add(TableConstants.PD_INSURED_NAME);
		getEntityColumnList.add(TableConstants.POLICY_NUMBER);
		getEntityColumnList.add(TableConstants.PD_PHONE_NUMBER);
		getEntityColumnList.add(TableConstants.PD_EMAIL_ID);
		getEntityColumnList.add(TableConstants.EFFECTIVE_START_DATE);
		getEntityColumnList.add(TableConstants.EXPIRY_DATE);
		getEntityColumnList.add(TableConstants.REGISTRATION_NUMBER);
		getEntityColumnList.add(TableConstants.CHASIS_NUMBER);
		getEntityColumnList.add(TableConstants.PD_LICENCE_TO_CARRY);
		getEntityColumnList.add(TableConstants.PD_MAKE);
		getEntityColumnList.add(TableConstants.PD_MODEL);
		getEntityColumnList.add(TableConstants.PD_USAGE);
		getEntityColumnList.add(TableConstants.SCRATCH_ID);

		return getEntityColumnList;
		}
		
		public static List<String> getExcelHeaderList() {
			
			List<String> excelHeaderList = new ArrayList<String>();
			
			excelHeaderList.add(ApplicationConstants.TAB_DIGITAL_PAPER_NO);
			return excelHeaderList;
			
		}
		
		public static Map<String, String> getMapColumnName()
		{
			 Map<String, String> MapColumnName = new  HashMap<String, String>();
			 List<String> excelHeaderList = new  ArrayList<String>();
			 MapColumnName.put("abc", "cde");
			 MapColumnName.put("ddd", "rrr");
			return MapColumnName;
			
		}
		
		public static List<String> getSelectEntityColumn(){
			 List<String> getSelectEntityColumn = new ArrayList<String>();
			 getSelectEntityColumn.add("Insured Company");
			 getSelectEntityColumn.add("Stock Count");
			 getSelectEntityColumn.add("Available Stock");
			 getSelectEntityColumn.add("Papers Issued");
			return getSelectEntityColumn;
			
		}
		
//		public static List<Integer> getCompanyIdList1(){
//			 List<Integer> companyIdList = new  ArrayList<Integer>();
//			 companyIdList.add(1);
//			 companyIdList.add(2);
//			return companyIdList;
//			 
//
//		}
		public static HashMap<String,Object> getExcelDataMap(){
			 HashMap<String,Object> map	= new HashMap<String,Object>();
			 map.put("hhh", "hhe");
			 map.put("hhr", "hhv");
			return map;
			 
		}
		public static ArrayList<HashMap<String, Object>> excelDataList(){
		 ArrayList<HashMap<String, Object>> excelDataList = new ArrayList<HashMap<String,Object>>();
		 HashMap<String,Object> map	= new HashMap<String,Object>();
		 map.put("hhh", "hhe");
		 map.put("hhr", "hhv");
		 excelDataList.add(map);
		return excelDataList;
		}
		
		public static List<Object[]> getPaperDetailsList() {
			
			

			Object[] data1 = { "DP03187", "Author1", "P0839133","1371381399"};
			Object[] data2 = { "DP03187", "Author2", "PO546477","1313678399"};

			List<Object[]> mockData = new ArrayList<>();
			mockData.add(data1);
			mockData.add(data2);
			
//			List<Integer> CompanyId = AuthorityPaperDetailsMockData.getCompanyId();
			
//			 List<Object[]> filteredData = new ArrayList<>();
//			    for (Object[] data : mockData) {
//			        Integer paperCompanyId = (Integer) data[3];
//			        if (companyId.contains(paperCompanyId)) {
//			            filteredData.add(data);
//			        }
//			    }

//			    return filteredData;
			return mockData;

			

		}
	


		
		
		
}
