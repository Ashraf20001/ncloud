package com.digitalpaper.mockdata;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;
import com.digitalpaper.transfer.object.entity.BulkImportErrorTable;
import com.digitalpaper.transfer.object.entity.FileStorage;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.entity.Scratch;
import com.digitalpaper.transfer.object.enums.PaperDetailsStatusEnum;

public class PaperDetailsMockData {

	public static List<PaperDetailsDto> getPaperDetailsDto() {
		List<PaperDetailsDto> list = new ArrayList<>();
		PaperDetailsDto dto = new PaperDetailsDto();
		dto.setPdDigiltaPaperId("1");
		dto.setPdPolicyNumber("1");
		dto.setVdRegistrationNumber("123");
		dto.setPdInsuredName("cbt");
		dto.setPdEffectiveFrom(null);
		LocalDateTime now = LocalDateTime.now();
		dto.setPdEffectiveFrom(now);
		dto.setPdExpireDate(now);
		dto.setStatus("Active");
		dto.setCreatedDate(now);
		list.add(dto);
		return list;
	}

	public static List<PaperDetails> getPaperDetails() {
		List<PaperDetails> list = new ArrayList<>();
		PaperDetails dto = new PaperDetails();
		LocalDateTime now = LocalDateTime.now();
		dto.setPaperId(1);
		dto.setPdDigitalPaperId("DP0238213");
		dto.setPolicyHolder("ppp");
		dto.setPdPolicyNumber("1");
		dto.setPaperPoolId(1);
		dto.setPdPhoneNumber("919999");
		dto.setCancelledDate(now);
		dto.setVdChassis("455454");
		dto.setCompanyId(1);
		dto.setCreatedBy(12);
		dto.setCreatedDate(now);
		dto.setPdEffectiveFrom(now);
		dto.setPdExpireDate(now);
		dto.setIdentity("ewrwrwwr");
		dto.setPdInsuredName("cbt");
		dto.setIsDeleted(false);
		dto.setVdLicensedToCarry("TN03");
		dto.setVdMake("m");
		dto.setVdModel("m");
		dto.setModifiedBy(2);
		dto.setModifiedDate(now);
		dto.setStatus(1);
		dto.setStorageId("1");
		dto.setVdUsage("a");
		dto.setStockPoolId(2);
		dto.setAllocationUserTypeId(1);
		list.add(dto);
		return list;
	}
	public static PaperDetailsDto getDetails() {
		PaperDetailsDto dto = new PaperDetailsDto();
		dto.setPdDigiltaPaperId("1");
		dto.setPdPolicyNumber("1");
		dto.setVdRegistrationNumber("123");
		dto.setPdInsuredName("cbt");
		dto.setPdEffectiveFrom(null);
		LocalDateTime now = LocalDateTime.now();
		dto.setPdEffectiveFrom(now);
		dto.setPdExpireDate(now);
		dto.setStatus("Active");
		dto.setVdChassis("111");
		dto.setPdEmailId("sss");
		dto.setPdPhoneNumber("123344");
		dto.setIdentity("123");
		dto.setPdInsuredName("axa");
		dto.setInsurer("aaaa");
		dto.setVdLicensedToCarry("aaaass");
		dto.setVdMake("make");
		dto.setVdModel("anb");
		dto.setCreatedDate(now);
		return dto;

	}

	public static PaperDetails getPaperData() {
		PaperDetails dto = new PaperDetails();
		LocalDateTime now = LocalDateTime.now();
		dto.setPaperId(1);
		dto.setPdDigitalPaperId("DP0238213");
		dto.setPolicyHolder("ppp");
		dto.setPdPolicyNumber("1");
		dto.setPaperPoolId(1);
		dto.setPdPhoneNumber("919999");
		dto.setCancelledDate(now);
		dto.setVdChassis("455454");
		dto.setCompanyId(1);
		dto.setCreatedBy(12);
		dto.setCreatedDate(now);
		dto.setPdEffectiveFrom(now);
		dto.setPdExpireDate(now);
		dto.setIdentity("123");
		dto.setPdInsuredName("cbt");
		dto.setIsDeleted(false);
		dto.setVdLicensedToCarry("TN03");
		dto.setVdMake("m");
		dto.setVdModel("m");
		dto.setModifiedBy(2);
		dto.setModifiedDate(now);
		dto.setStatus(PaperDetailsStatusEnum.ACTIVE.getStatusNameById());
		dto.setStorageId("1");
		dto.setVdUsage("a");
		dto.setStockPoolId(2);
		dto.setCustomer(CustomerMockData.getCustomerData());
		dto.setPdEmailId("customer@gmail.com");
		return dto;
	}

	public static PaperDetails getPaperData1() {
		PaperDetails dto = new PaperDetails();
		LocalDateTime now = LocalDateTime.now();
		dto.setPaperId(1);
		dto.setPdDigitalPaperId("DP0238213");
		dto.setPolicyHolder("ppp");
		dto.setPdPolicyNumber("1");
		dto.setPaperPoolId(1);
		dto.setPdPhoneNumber("919999");
		dto.setCancelledDate(now);
		dto.setVdChassis("455454");
		dto.setCompanyId(1);
		dto.setCreatedBy(12);
		dto.setCreatedDate(now);
		dto.setPdEffectiveFrom(now);
		dto.setPdExpireDate(now);
		dto.setIdentity("123");
		dto.setPdInsuredName("cbt");
		dto.setIsDeleted(false);
		dto.setVdLicensedToCarry("TN03");
		dto.setVdMake("m");
		dto.setVdModel("m");
		dto.setModifiedBy(2);
		dto.setModifiedDate(now);
		dto.setStatus(PaperDetailsStatusEnum.REVOKED.getStatusNameById());
		dto.setStorageId("1");
		dto.setVdUsage("a");
		dto.setStockPoolId(2);
		return dto;
	}

	public static List<String> getStringList() {
		List<String> str = new ArrayList<>();
		str.add("a");
		str.add("b");
		return str;
	}

	public static BulkImportErrorTable getBulkImportErrorTable() {
		BulkImportErrorTable bulkImportErrorTable= new BulkImportErrorTable();
		bulkImportErrorTable.setCreatedBy(3);
		bulkImportErrorTable.setCreatedDate(LocalDateTime.now());
		bulkImportErrorTable.setDeleted(false);
		bulkImportErrorTable.setErrorCleared(false);
		bulkImportErrorTable.setErrorId(1);
		bulkImportErrorTable.setErrorMessage("yadtaiydq");
		bulkImportErrorTable.setFieldName("Policy Number");
		bulkImportErrorTable.setIdentity("ytwetiqwd");
		bulkImportErrorTable.setModifiedBy(3);
		bulkImportErrorTable.setModifiedDate(LocalDateTime.now());
		bulkImportErrorTable.setScratchId(1);
		return bulkImportErrorTable;
	}

	public static List<BulkImportErrorTable> getBulkImportTableList(){
		List<BulkImportErrorTable> bulkImportErrorTables= new ArrayList<>();
		bulkImportErrorTables.add(getBulkImportErrorTable());
		return bulkImportErrorTables;
	}

	public static List<String> getColumnList(){
		List<String> columnList = new ArrayList<>();
		columnList.add("Policy Number");
		columnList.add("Insured Name");
		columnList.add("Effective From");
		columnList.add("Effective to");
		columnList.add("Registration No");
		columnList.add("scratchId");
		return columnList;
	}

	public static List<String> entityColumnList(){
		List<String> columnList = new ArrayList<>();
		columnList.add(TableConstants.PD_DIGITAL_PAPER_ID);
		columnList.add(TableConstants.POLICY_NUMBER);
		columnList.add(TableConstants.PD_INSURED_NAME);
		columnList.add(TableConstants.PD_PHONE_NUMBER);
		columnList.add(TableConstants.PD_EMAIL_ID);
		columnList.add(TableConstants.EFFECTIVE_START_DATE);
		columnList.add(TableConstants.EXPIRY_DATE);
		columnList.add(TableConstants.REGISTRATION_NUMBER);
		columnList.add(TableConstants.CHASIS_NUMBER);
		columnList.add(TableConstants.PD_LICENCE_TO_CARRY);
		columnList.add(TableConstants.PD_MAKE);
		columnList.add(TableConstants.PD_MODEL);
		columnList.add(TableConstants.PD_USAGE);
		columnList.add(TableConstants.SCRATCH_ID);
		return columnList;
	}

	public static ArrayList<HashMap<String,Object>> getExcelList() {

		ArrayList<HashMap<String, Object>> excelData = new ArrayList<>();
		HashMap<String, Object> map = new HashMap<>();
		map.put("Policy Number", "PO001");
		map.put("Insured Name", "viswa");
		map.put("Effective From", LocalDateTime.now());
		map.put("Effective to", LocalDateTime.now());
		map.put("Registration No", "REG0002");
		map.put("scratchId", 1);
		excelData.add(map);
		return excelData;

  }

	public static Scratch getScratchData() {
		Scratch scratch = new Scratch();
		scratch.setBulkUploadId(1);
		scratch.setCompanyId("2");
		scratch.setCreatedBy(3);
		scratch.setCreatedDate(LocalDateTime.now());
		scratch.setIdentity("sdaiufafiu");
		scratch.setIsDeleted(false);
		scratch.setModifiedBy(3);
		scratch.setModifiedDate(LocalDateTime.now());
		scratch.setPdEffectiveFrom("23/02/2023");
		scratch.setPdEmailId("harsha@gmail.com");
		scratch.setPdExpireDate("24/02/2023");
		scratch.setPdInsuredName("harsha");
		scratch.setPdPhoneNumber("934134137493");
		scratch.setPdPolicyNumber("PO023874");
		scratch.setPolicyHolder("kanagaraj");
		scratch.setScratchId(1);
		scratch.setStatus(true);
		scratch.setVdChassis("EGN0982034");
		scratch.setVdLicensedToCarry("2");
		scratch.setVdMake("Honda");
		scratch.setVdModel("Shine");
		scratch.setVdRegistrationNumber("TN02AD0192");
		scratch.setVdUsage("Private");
		return scratch;
	}

	public static FileStorage getFileStorage() {
		FileStorage fileStorage = new FileStorage();
		fileStorage.setStorageId(1);
		fileStorage.setStorageType("Local");
		fileStorage.setUploadType("PPR_GEN");
		fileStorage.setCreatedDate("06/02/2023");
		fileStorage.setDeleted(false);
		fileStorage.setFileSize(100L);
		fileStorage.setIdentity("askasiasy");
		fileStorage.setReferenceId(2);
		fileStorage.setReportType("digital-paper");
		fileStorage.setUrl("OG_DP0000029_1685353403518.png");
		return fileStorage;
	}

}
