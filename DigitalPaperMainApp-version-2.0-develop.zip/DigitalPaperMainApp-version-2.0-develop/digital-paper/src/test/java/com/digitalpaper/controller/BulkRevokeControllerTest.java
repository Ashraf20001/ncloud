//package com.digitalpaper.controller;
//
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static org.mockito.ArgumentMatchers.longThat;
//import static org.mockito.Mockito.when;
//
//import java.util.List;
//
//import org.assertj.core.api.Assertions;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//import org.springframework.test.context.web.WebAppConfiguration;
//
//import com.digitalpaper.DigitalPaperApplication;
//import com.digitalpaper.config.model.FilterOrSortingVo;
//import com.digitalpaper.mockdata.BulkRevokeMockData;
//import com.digitalpaper.mockdata.PurchaseHistoryMockData;
//import com.digitalpaper.service.IBulkRevokeService;
//import com.digitalpaper.transfer.object.core.ApplicationResponse;
//import com.digitalpaper.transfer.object.dto.BulkRevokeCountDto;
//import com.digitalpaper.transfer.object.dto.BulkRevokeDto;
//
//@ExtendWith(SpringExtension.class)
//@WebAppConfiguration
//@SpringBootTest(classes = DigitalPaperApplication.class)
//public class BulkRevokeControllerTest {
//
//	@InjectMocks
//	private BulkRevokeController bulkRevokeConMock;
//
//	@Mock
//	private IBulkRevokeService iBulkRevokeSerMock;
//
//	@Test
//	public void getBulkScratchCount() {
//		Long val = 10l;
//		List<FilterOrSortingVo> filter = PurchaseHistoryMockData.getFilterOrSorting();
//		try {
//			when(iBulkRevokeSerMock.getRevokeScratchCount(filter)).thenReturn(val);
//			Long result = bulkRevokeConMock.getRevokeScratchCount(filter);
//			assertNotNull(result);
//		} catch (Exception e) {
//			Assertions.fail(e.toString());
//		}
//	}
//
//	@Test
//	public void getBulkScratchData() {
//		List<FilterOrSortingVo> filter = PurchaseHistoryMockData.getFilterOrSorting();
//		List<BulkRevokeDto> dto = BulkRevokeMockData.getBulkRevokeDto();
//		try {
//			when(iBulkRevokeSerMock.getRevokeScratchData(1, 10, filter)).thenReturn(dto);
//			List<BulkRevokeDto> result = bulkRevokeConMock.getRevokeScratchData(1, 10, filter);
//			assertNotNull(result);
//		} catch (Exception e) {
//			Assertions.fail(e.toString());
//		}
//	}
//
//	@Test
//	public void getSuccessErrorCount() {
//		BulkRevokeCountDto dto = BulkRevokeMockData.getCountDto();
//		try {
//			when(iBulkRevokeSerMock.getSuccessErrorCount()).thenReturn(dto);
//			BulkRevokeCountDto result = bulkRevokeConMock.getSuccessErrorCount();
//			assertNotNull(result);
//		} catch (Exception e) {
//			Assertions.fail(e.toString());
//		}
//	}
//	
//	@Test
//	public void deleteBulkRevoke() {
//		
//		try {
//			when(iBulkRevokeSerMock.deleteBulkRevoke("123")).thenReturn("123");
//			ApplicationResponse response = bulkRevokeConMock.deleteBulkRevoke("123");
//			assertNotNull(response);
//		} catch (Exception e) {
//			Assertions.fail(e.toString());
//		}
//	}
//}
