package com.digitalpaper.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.daoImp.StockDaoImpl;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.mockdata.AllocateStockMockData;
import com.digitalpaper.mockdata.PurchaseHistoryMockData;
import com.digitalpaper.service.impl.AllocationStockServiceImpl;
import com.digitalpaper.transfer.object.dto.StockCountDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@ContextConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class AllocationStockServiceTest {

	@InjectMocks
	private AllocationStockServiceImpl serviceMock;
	
	@Mock
	private StockDaoImpl daoMock;
	
	@Mock
	private LoggedInUserContextHolder loggedInUserContextHolder;
	
	@Test
	public void getStockCountForAllocationStock_HappyFlow() {
		try {
			UserInfo user = PurchaseHistoryMockData.getUserInfo();
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(user);
			when(daoMock.getStockCountForAllocationStock(1)).thenReturn(AllocateStockMockData.getStockCountDto());
			StockCountDto stockCountDto = serviceMock.getStockCountForAllocationStock(1);
			assertNotNull(stockCountDto);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	public void getStockCountForAllocationStock_ErrorFlow() {
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseHistoryMockData.getUserInfo1());
			ApplicationException ap = new ApplicationException(ErrorCodes.UN_AUTHORIZED);
			ApplicationException exception = assertThrows(ApplicationException.class, () -> {
				serviceMock.getStockCountForAllocationStock(null);
			});
			assertEquals(ap.toString(), exception.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
}
