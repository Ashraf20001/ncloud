package com.digitalpaper.controller;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.service.IStockNotificationSevice;
import com.digitalpaper.service.impl.StockServiceImpl;
import com.digitalpaper.test.DigitalPaperUnitTest;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.StockDto;
import com.digitalpaper.transfer.object.dto.StockNotificationDto;

import mockDatas.MockData;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class NotificationControllerTest  extends DigitalPaperUnitTest {
	
	@InjectMocks
	private NotificationController controller;
	
	@Mock
	private IStockNotificationSevice ServiceMock;

	
	@Test
	public void getNotification_Happy_flow() {
		
		try {
			when(ServiceMock.getNotification()).thenReturn(MockData.getStockNotificationMock());
			ApplicationResponse actual = controller.getNotification();
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getNotificationCount_Happy_flow() {
		long i = 384756453;
		
		try {
			when(ServiceMock.getNotificationCount()).thenReturn(i);
			ApplicationResponse actual = controller.getNotificationCount();
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
		
		
	}

}
