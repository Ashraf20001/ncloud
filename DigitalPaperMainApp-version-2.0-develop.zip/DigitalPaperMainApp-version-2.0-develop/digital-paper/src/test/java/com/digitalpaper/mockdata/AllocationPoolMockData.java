package com.digitalpaper.mockdata;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.transfer.object.dto.AllocationUserTypeDto;
import com.digitalpaper.transfer.object.dto.AllocationUserTypeList;
import com.digitalpaper.transfer.object.dto.PoolDto;
import com.digitalpaper.transfer.object.dto.StockDto;
import com.digitalpaper.transfer.object.entity.Stock;
import com.digitalpaper.transfer.object.entity.StockPool;

public class AllocationPoolMockData {
	
	public static StockDto getStockDto() {
		StockDto dto = new StockDto();
		dto.setCompanyId(1);
		dto.setCreatedDate(LocalDateTime.now());
		dto.setIdentity("rdygukjnk");
		dto.setStockCount(100);
		dto.setStockId(1);
		dto.setUsedCount(20);
		dto.setUserTypeId(1);
		return dto;
	}
	
	public static PoolDto getPoolDto() {
		PoolDto dto = new PoolDto();
		dto.setPoolAction("ALLOCATE");
		dto.setPoolId(1);
		dto.setPoolName(null);
		dto.setReAllocateToId(2);
		dto.setStockCount(10);
		return dto;
	}
	
	public static PoolDto getPoolDto1() {
		PoolDto dto = new PoolDto();
		dto.setPoolAction("REALLOCATE");
		dto.setPoolId(1);
		dto.setPoolName(null);
		dto.setReAllocateToId(2);
		dto.setStockCount(10);
		return dto;
	}
	
	public static PoolDto getPoolDto2() {
		PoolDto dto = new PoolDto();
		dto.setPoolAction("DEALLOCATE");
		dto.setPoolId(1);
		dto.setPoolName(null);
		dto.setReAllocateToId(2);
		dto.setStockCount(10);
		return dto;
	}
	
	public static PoolDto getPoolDto3() {
		PoolDto dto = new PoolDto();
		dto.setPoolId(1);
		dto.setPoolName(null);
		dto.setReAllocateToId(2);
		dto.setStockCount(10);
		return dto;
	}
	
	public static PoolDto getPoolDto4() {
		PoolDto dto = new PoolDto();
		dto.setPoolAction("ALLOCATE");
		dto.setPoolId(1);
		dto.setPoolName(null);
		dto.setReAllocateToId(2);
		dto.setStockCount(1000);
		return dto;
	}
	
	public static Stock getStock() {
		Stock stock = new Stock();
		stock.setCompanyId(1);
		stock.setCreatedBy(1);
		stock.setIdentity("qert");
		stock.setStockCount(100);
		stock.setUsedCount(50);
		return stock;
	}
	
	public static Stock getStock1() {
		Stock stock = new Stock();
		stock.setCompanyId(1);
		stock.setCreatedBy(1);
		stock.setIdentity("qert");
		stock.setStockCount(1000);
		stock.setUsedCount(50);
		return stock;
	}
	
	public static StockPool getStockPool() {
		StockPool stock = new StockPool();
		stock.setCompanyId(1);
		stock.setCreatedBy(1);
		stock.setIdentity("qert");
		stock.setStockCount(100);
		stock.setUsedCount(50);
		stock.setUserTypeId(1);
		return stock;
	}
	
	public static StockPool getStockPool1() {
		StockPool stock = new StockPool();
		stock.setCompanyId(1);
		stock.setCreatedBy(1);
		stock.setIdentity("qert");
		stock.setStockCount(1000);
		stock.setUsedCount(50);
		stock.setUserTypeId(1);
		return stock;
	}
	
	public static List<StockPool> getListStockPool(){
		List<StockPool> list = new ArrayList<>();
		list.add(getStockPool());
		return list;
	}
	
	public static List<StockDto> getListStockDto(){
		List<StockDto> list = new ArrayList<>();
		list.add(getStockDto());
		return list;
	}
	
	public static FilterOrSortingVo getFilterOrSortingVoLt() {
		FilterOrSortingVo filterOrSortingVo = new FilterOrSortingVo();
		filterOrSortingVo.setColumnName("col");
		filterOrSortingVo.setCondition("Lt");
		filterOrSortingVo.setFilterOrSortingType("FILTER");
		filterOrSortingVo.setValue("1000");
		filterOrSortingVo.setType("Integer");
		return filterOrSortingVo;
	}
	
	public static FilterOrSortingVo getFilterOrSortingVoBw() {
		FilterOrSortingVo filterOrSortingVo = new FilterOrSortingVo();
		filterOrSortingVo.setColumnName("col");
		filterOrSortingVo.setCondition("Bw");
		filterOrSortingVo.setFilterOrSortingType("FILTER");
		filterOrSortingVo.setValue("10");
		filterOrSortingVo.setValue2("100");
		filterOrSortingVo.setType("Integer");
		return filterOrSortingVo;
	}
	
	public static FilterOrSortingVo getFilterOrSortingVoGt() {
		FilterOrSortingVo filterOrSortingVo = new FilterOrSortingVo();
		filterOrSortingVo.setColumnName("col");
		filterOrSortingVo.setCondition("Gt");
		filterOrSortingVo.setFilterOrSortingType("FILTER");
		filterOrSortingVo.setValue("10");
		filterOrSortingVo.setType("Integer");
		return filterOrSortingVo;
	}
	
	public static FilterOrSortingVo getFilterOrSortingVo11() {
		FilterOrSortingVo filterOrSortingVo = new FilterOrSortingVo();
		filterOrSortingVo.setColumnName(ApplicationConstants.USER_TYPE_NAME);
		filterOrSortingVo.setCondition("Gt");
		filterOrSortingVo.setFilterOrSortingType("FILTER");
		filterOrSortingVo.setValue("10");
		filterOrSortingVo.setType("Integer");
		return filterOrSortingVo;
	}
	
	public static FilterOrSortingVo getFilterOrSortingVo22() {
		FilterOrSortingVo filterOrSortingVo = new FilterOrSortingVo();
		filterOrSortingVo.setColumnName(ApplicationConstants.IDENTITY_CONSTANT);
		filterOrSortingVo.setCondition("Gt");
		filterOrSortingVo.setFilterOrSortingType("FILTER");
		filterOrSortingVo.setValue("10");
		filterOrSortingVo.setType("Integer");
		return filterOrSortingVo;
	}
	
	public static FilterOrSortingVo getFilterOrSortingVo3() {
		FilterOrSortingVo filterOrSortingVo = new FilterOrSortingVo();
		filterOrSortingVo.setColumnName(ApplicationConstants.NULL);
		filterOrSortingVo.setCondition("Gt");
		filterOrSortingVo.setFilterOrSortingType("FILTER");
		filterOrSortingVo.setValue("10");
		filterOrSortingVo.setType("Integer");
		return filterOrSortingVo;
	}
	
	public static FilterOrSortingVo getFilterOrSortingVo4() {
		FilterOrSortingVo filterOrSortingVo = new FilterOrSortingVo();
		filterOrSortingVo.setColumnName(ApplicationConstants.NULL);
		filterOrSortingVo.setCondition("Lt");
		filterOrSortingVo.setFilterOrSortingType("FILTER");
		filterOrSortingVo.setValue("1000");
		filterOrSortingVo.setType("Integer");
		return filterOrSortingVo;
	}
	
	public static FilterOrSortingVo getFilterOrSortingVo5() {
		FilterOrSortingVo filterOrSortingVo = new FilterOrSortingVo();
		filterOrSortingVo.setColumnName(ApplicationConstants.NULL);
		filterOrSortingVo.setCondition("Bw");
		filterOrSortingVo.setFilterOrSortingType("FILTER");
		filterOrSortingVo.setValue("10");
		filterOrSortingVo.setValue2("100");
		filterOrSortingVo.setType("Integer");
		return filterOrSortingVo;
	}
	public static FilterOrSortingVo getFilterOrSorting() {
		FilterOrSortingVo filterOrSortingVo = new FilterOrSortingVo();
		filterOrSortingVo.setColumnName("null");
		filterOrSortingVo.setCondition("");
		filterOrSortingVo.setFilterOrSortingType("SORTING");
		filterOrSortingVo.setValue("");
		filterOrSortingVo.setType("");
		return filterOrSortingVo;
	}
	
	public static FilterOrSortingVo getFilterOrSorting1() {
		FilterOrSortingVo filterOrSortingVo = new FilterOrSortingVo();
		filterOrSortingVo.setColumnName(ApplicationConstants.USER_TYPE_NAME);
		filterOrSortingVo.setCondition("");
		filterOrSortingVo.setFilterOrSortingType("SORTING");
		filterOrSortingVo.setValue("");
		filterOrSortingVo.setType("");
		return filterOrSortingVo;
	}
	
	public static FilterOrSortingVo getFilterOrSorting2() {
		FilterOrSortingVo filterOrSortingVo = new FilterOrSortingVo();
		filterOrSortingVo.setColumnName(ApplicationConstants.USER_TYPE_NAME);
		filterOrSortingVo.setCondition("");
		filterOrSortingVo.setFilterOrSortingType("SORTING");
		filterOrSortingVo.setValue("");
		filterOrSortingVo.setType("");
		filterOrSortingVo.setAscending(true);
		return filterOrSortingVo;
	}
	
	public static FilterOrSortingVo getFilterOrSorting3() {
		FilterOrSortingVo filterOrSortingVo = new FilterOrSortingVo();
		filterOrSortingVo.setColumnName(ApplicationConstants.IDENTITY_CONSTANT);
		filterOrSortingVo.setCondition("");
		filterOrSortingVo.setFilterOrSortingType("SORTING");
		filterOrSortingVo.setValue("");
		filterOrSortingVo.setType("");
		filterOrSortingVo.setAscending(true);
		return filterOrSortingVo;
	}
	
	public static FilterOrSortingVo getFilterOrSorting4() {
		FilterOrSortingVo filterOrSortingVo = new FilterOrSortingVo();
		filterOrSortingVo.setColumnName(ApplicationConstants.IDENTITY_CONSTANT);
		filterOrSortingVo.setCondition("");
		filterOrSortingVo.setFilterOrSortingType("SORTING");
		filterOrSortingVo.setValue("");
		filterOrSortingVo.setType("");
		return filterOrSortingVo;
	}
	
	public static FilterOrSortingVo getFilterOrSorting5() {
		FilterOrSortingVo filterOrSortingVo = new FilterOrSortingVo();
		filterOrSortingVo.setColumnName(ApplicationConstants.NULL);
		filterOrSortingVo.setCondition("");
		filterOrSortingVo.setFilterOrSortingType("SORTING");
		filterOrSortingVo.setValue("");
		filterOrSortingVo.setType("");
		filterOrSortingVo.setAscending(true);
		return filterOrSortingVo;
	}
	
	public static List<FilterOrSortingVo> getFilterOrSortingVoList(){
		List<FilterOrSortingVo> list = new ArrayList<>();
		list.add(getFilterOrSortingVoLt());
		list.add(getFilterOrSortingVo11());
		list.add(getFilterOrSortingVo22());
		list.add(getFilterOrSortingVo3());
		list.add(getFilterOrSortingVo4());
		list.add(getFilterOrSortingVo5());
		list.add(getFilterOrSorting());
		return list;
	}
	
	public static List<FilterOrSortingVo> getFilterOrSortingVoList1(){
		List<FilterOrSortingVo> list = new ArrayList<>();
		list.add(getFilterOrSortingVoLt());
		list.add(getFilterOrSortingVo11());
		list.add(getFilterOrSortingVo22());
		list.add(getFilterOrSortingVo3());
		list.add(getFilterOrSortingVo4());
		list.add(getFilterOrSortingVo5());
		list.add(getFilterOrSorting1());
		return list;
	}
	
	public static List<FilterOrSortingVo> getFilterOrSortingVoList2(){
		List<FilterOrSortingVo> list = new ArrayList<>();
		list.add(getFilterOrSortingVoLt());
		list.add(getFilterOrSortingVo11());
		list.add(getFilterOrSortingVo22());
		list.add(getFilterOrSortingVo3());
		list.add(getFilterOrSortingVo4());
		list.add(getFilterOrSortingVo5());
		list.add(getFilterOrSorting2());
		return list;
	}
	
	public static List<FilterOrSortingVo> getFilterOrSortingVoList3(){
		List<FilterOrSortingVo> list = new ArrayList<>();
		list.add(getFilterOrSortingVoLt());
		list.add(getFilterOrSortingVo11());
		list.add(getFilterOrSortingVo22());
		list.add(getFilterOrSortingVo3());
		list.add(getFilterOrSortingVo4());
		list.add(getFilterOrSortingVo5());
		list.add(getFilterOrSorting3());
		return list;
	}
	
	public static List<FilterOrSortingVo> getFilterOrSortingVoList4(){
		List<FilterOrSortingVo> list = new ArrayList<>();
		list.add(getFilterOrSortingVoLt());
		list.add(getFilterOrSortingVo11());
		list.add(getFilterOrSortingVo22());
		list.add(getFilterOrSortingVo3());
		list.add(getFilterOrSortingVo4());
		list.add(getFilterOrSortingVo5());
		list.add(getFilterOrSorting4());
		return list;
	}
	
	public static List<FilterOrSortingVo> getFilterOrSortingVoList5(){
		List<FilterOrSortingVo> list = new ArrayList<>();
		list.add(getFilterOrSortingVoLt());
		list.add(getFilterOrSortingVo11());
		list.add(getFilterOrSortingVo22());
		list.add(getFilterOrSortingVo3());
		list.add(getFilterOrSortingVo4());
		list.add(getFilterOrSortingVo5());
		list.add(getFilterOrSorting5());
		return list;
	}
	
	public static AllocationUserTypeDto getAllocationUserTypeDto() {
		AllocationUserTypeDto dto = new AllocationUserTypeDto();
		dto.setId(1);
		dto.setIdentity("werfghjkdf");
		dto.setUserTypeName("employee");
		return dto;
	}
	
	public static List<AllocationUserTypeDto> getListAllocationUserTypeDto(){
		 List<AllocationUserTypeDto> list = new ArrayList<>();
		 list.add(getAllocationUserTypeDto());
		 return list;
	}
	
	public static AllocationUserTypeList getAllocationUserTypeList() {
		AllocationUserTypeList typeList = new AllocationUserTypeList();
		typeList.setAllocationUserTypeList(getListAllocationUserTypeDto());
		return typeList;
	}

}
