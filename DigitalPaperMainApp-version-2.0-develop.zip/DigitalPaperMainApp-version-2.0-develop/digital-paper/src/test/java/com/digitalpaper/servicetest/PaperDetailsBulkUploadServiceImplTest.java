package com.digitalpaper.servicetest;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.modelmapper.ModelMapper;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.client.RestTemplate;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.adapter.service.DataConverterFactory;
import com.digitalpaper.adapter.service.FieldClassMapper;
import com.digitalpaper.config.property.EnvironmentProperties;
import com.digitalpaper.controller.SequenceEnum;
import com.digitalpaper.controller.SequenceGenerator;
import com.digitalpaper.dao.IPaperDetailsDao;
import com.digitalpaper.dao.PaperDetailsBulkUploadDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.restemplate.service.RestTemplateServiceImpl;
import com.digitalpaper.service.impl.PaperDetailsBulkUploadServiceImpl;
import com.digitalpaper.transfer.object.dto.BulkImportFieldValidationDto;
import com.digitalpaper.transfer.object.dto.ScratchDto;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.entity.Scratch;
import com.digitalpaper.transfer.object.entity.StockPool;
import com.digitalpaper.utils.PaperGenerationUtils;
import com.digitalpaper.utils.core.RestTemplateUtils;

import mockDatas.BulkUploadMock;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class PaperDetailsBulkUploadServiceImplTest {
	
	@InjectMocks
	private PaperDetailsBulkUploadServiceImpl bulkUploadServiceImpl;
	
	@Mock
	private DataConverterFactory converterFactory;
	
	@Mock
	private ModelMapper modelMapper;
	
	@Mock
	private PaperDetailsBulkUploadDao paperDetailsBulkUploadDao;
	
	@Mock
	private FieldClassMapper fieldClassMapper;
	
	@Mock
	private EnvironmentProperties environmentProperties;
	
	@Mock
	private RestTemplate restTemplate;
	
	@Mock
	private RestTemplateUtils restTemplateUtils;
	
	@Mock
    private SequenceGenerator sequenceGenerator;
	
	@Mock
	private PaperGenerationUtils paperGenerationUtils;
	
	@Mock
	private IPaperDetailsDao iPaperDetailsDao;
	
	@Mock
	private RestTemplateServiceImpl restTemplateServiceImpl;
	
	
	@Test
	void getExcelSheetReading_happy_flow() {
		Class<?> cls = String.class;
		try {
			when(restTemplateServiceImpl.sendBulkImportHistoryDtoToUpdate(any(BulkImportFieldValidationDto.class))).thenReturn(BulkUploadMock.getBulkImportHistoryDto());
			when(paperDetailsBulkUploadDao.checkForDuplicatePolicyNumber(anyString(), anyInt())).thenReturn(BulkUploadMock.getPaperDetails1());
			when(converterFactory.dataConverter(anyString(), anyString())).thenReturn("9898989898");
			Mockito.doReturn(cls).when(fieldClassMapper).getClass(anyString());
			doNothing().when(paperDetailsBulkUploadDao).saveBulkImportErrorData(BulkUploadMock.getBulkImportErrorTable());
			when(modelMapper.map(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any())).thenReturn(BulkUploadMock.getScratch());
			when(paperDetailsBulkUploadDao.saveScratchData(any(Scratch.class))).thenReturn(1);
			bulkUploadServiceImpl.getExcelSheetReading(BulkUploadMock.getBulkImportFieldValidationDto(),null);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getExcelSheetReading_happy_flow1() {
		Class<?> cls = String.class;
		try {
			when(restTemplateServiceImpl.sendBulkImportHistoryDtoToUpdate(any(BulkImportFieldValidationDto.class))).thenReturn(BulkUploadMock.getBulkImportHistoryDto());
			when(paperDetailsBulkUploadDao.checkForDuplicatePolicyNumber(anyString(), anyInt())).thenReturn(BulkUploadMock.getPaperDetails1());
			when(converterFactory.dataConverter(anyString(), anyString())).thenReturn("9898989898");
			Mockito.doReturn(cls).when(fieldClassMapper).getClass(anyString());
			doNothing().when(paperDetailsBulkUploadDao).saveBulkImportErrorData(BulkUploadMock.getBulkImportErrorTable());
			when(modelMapper.map(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any())).thenReturn(BulkUploadMock.getScratch());
			when(modelMapper.map(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any())).thenReturn(BulkUploadMock.getPaperDetails1());
			when(paperDetailsBulkUploadDao.saveScratchData(any(Scratch.class))).thenReturn(1);
			when(paperDetailsBulkUploadDao.getStockPoolByAllocationId(anyInt(),anyInt())).thenReturn(BulkUploadMock.getStockPool());
			when(paperDetailsBulkUploadDao.updateStockPool(any(StockPool.class))).thenReturn(true);
			when(sequenceGenerator.generateSequence(SequenceEnum.DIGITAL_PAPER_ID)).thenReturn("1");
			when(paperDetailsBulkUploadDao.savePaperDetails(any(PaperDetails.class))).thenReturn(1);
			doNothing().when(paperGenerationUtils).generateDigitalPaper(any(PaperDetails.class));
			bulkUploadServiceImpl.getExcelSheetReading(BulkUploadMock.getBulkImportFieldValidationDto1(),null);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getExcelSheetReading_happy_flow2() {
		Class<?> cls = String.class;
		try {
			when(restTemplateServiceImpl.sendBulkImportHistoryDtoToUpdate(any(BulkImportFieldValidationDto.class))).thenReturn(BulkUploadMock.getBulkImportHistoryDto());
			when(paperDetailsBulkUploadDao.checkForDuplicatePolicyNumber(anyString(), anyInt())).thenReturn(BulkUploadMock.getPaperDetails1());
			when(converterFactory.dataConverter(anyString(), anyString())).thenReturn("9898989898");
			Mockito.doReturn(cls).when(fieldClassMapper).getClass(anyString());
			doNothing().when(paperDetailsBulkUploadDao).saveBulkImportErrorData(BulkUploadMock.getBulkImportErrorTable());
			when(modelMapper.map(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any())).thenReturn(BulkUploadMock.getScratch());
			when(modelMapper.map(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any())).thenReturn(BulkUploadMock.getPaperDetails1());
			when(paperDetailsBulkUploadDao.saveScratchData(any(Scratch.class))).thenReturn(1);
			when(paperDetailsBulkUploadDao.getStockPoolByAllocationId(anyInt(),anyInt())).thenReturn(BulkUploadMock.getStockPool());
			when(paperDetailsBulkUploadDao.updateStockPool(any(StockPool.class))).thenReturn(true);
			when(sequenceGenerator.generateSequence(SequenceEnum.DIGITAL_PAPER_ID)).thenReturn("1");
			when(paperDetailsBulkUploadDao.savePaperDetails(any(PaperDetails.class))).thenReturn(1);
			doNothing().when(paperGenerationUtils).generateDigitalPaper(any(PaperDetails.class));
			doNothing().when(paperDetailsBulkUploadDao).updateDigitalPaper(any(PaperDetails.class));
			doNothing().when(paperGenerationUtils).revokeDigitalPaper(anyString());
			bulkUploadServiceImpl.getExcelSheetReading(BulkUploadMock.getBulkImportFieldValidationDto2(),null);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getExcelSheetReading_happy_flow3() {
		Class<?> cls = String.class;
		try {
			when(restTemplateServiceImpl.sendBulkImportHistoryDtoToUpdate(any(BulkImportFieldValidationDto.class))).thenReturn(BulkUploadMock.getBulkImportHistoryDto());
			when(paperDetailsBulkUploadDao.checkForDuplicatePolicyNumber(anyString(), anyInt())).thenReturn(BulkUploadMock.getPaperDetails1());
			when(converterFactory.dataConverter(anyString(), anyString())).thenReturn("9898989898");
			Mockito.doReturn(cls).when(fieldClassMapper).getClass(anyString());
			doNothing().when(paperDetailsBulkUploadDao).saveBulkImportErrorData(BulkUploadMock.getBulkImportErrorTable());
			when(modelMapper.map(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any())).thenReturn(BulkUploadMock.getScratch());
			when(modelMapper.map(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any())).thenReturn(BulkUploadMock.getPaperDetails1());
			when(paperDetailsBulkUploadDao.saveScratchData(any(Scratch.class))).thenReturn(1);
			when(paperDetailsBulkUploadDao.getStockPoolByAllocationId(anyInt(),anyInt())).thenReturn(BulkUploadMock.getStockPool());
			when(paperDetailsBulkUploadDao.updateStockPool(any(StockPool.class))).thenReturn(true);
			when(sequenceGenerator.generateSequence(SequenceEnum.DIGITAL_PAPER_ID)).thenReturn("1");
			when(paperDetailsBulkUploadDao.getPaperDetailsByDigitalPaperId(anyString())).thenReturn(BulkUploadMock.getPaperDetails1());
			when(paperDetailsBulkUploadDao.savePaperDetails(any(PaperDetails.class))).thenReturn(1);
			doNothing().when(paperGenerationUtils).generateDigitalPaper(any(PaperDetails.class));
			doNothing().when(paperDetailsBulkUploadDao).updateDigitalPaper(any(PaperDetails.class));
			doNothing().when(paperGenerationUtils).revokeDigitalPaper(anyString());
			bulkUploadServiceImpl.getExcelSheetReading(BulkUploadMock.getBulkImportFieldValidationDto2(),null);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	
	@Test
	void getExcelSheetReading_error_flow() {
		try {
			when(paperDetailsBulkUploadDao.getPaperDetailsByDigitalPaperId(anyString())).thenReturn(BulkUploadMock.getPaperDetails3());
			
			doNothing().when(paperDetailsBulkUploadDao).saveBulkImportErrorData(BulkUploadMock.getBulkImportErrorTable());
			
			bulkUploadServiceImpl.getExcelSheetReading(BulkUploadMock.getBulkImportFieldValidationDto2(),null);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getExcelSheetReading_happy_flow4() {
		Class<?> cls = LocalDateTime.class;
		
		try {
			when(restTemplateServiceImpl.sendBulkImportHistoryDtoToUpdate(any(BulkImportFieldValidationDto.class))).thenReturn(BulkUploadMock.getBulkImportHistoryDto());
			when(paperDetailsBulkUploadDao.checkForDuplicatePolicyNumber(anyString(), anyInt())).thenReturn(BulkUploadMock.getPaperDetails1());
			when(converterFactory.dataConverter(anyString(), anyString())).thenReturn(LocalDateTime.now());
			Mockito.doReturn(cls).when(fieldClassMapper).getClass(anyString());
			doNothing().when(paperDetailsBulkUploadDao).saveBulkImportErrorData(BulkUploadMock.getBulkImportErrorTable());
			when(modelMapper.map(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any())).thenReturn(BulkUploadMock.getScratch());
			when(modelMapper.map(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any())).thenReturn(BulkUploadMock.getPaperDetails1());
			when(paperDetailsBulkUploadDao.saveScratchData(any(Scratch.class))).thenReturn(1);
			when(paperDetailsBulkUploadDao.getStockPoolByAllocationId(anyInt(),anyInt())).thenReturn(BulkUploadMock.getStockPool());
			when(paperDetailsBulkUploadDao.updateStockPool(any(StockPool.class))).thenReturn(true);
			when(sequenceGenerator.generateSequence(SequenceEnum.DIGITAL_PAPER_ID)).thenReturn("1");
			when(paperDetailsBulkUploadDao.savePaperDetails(any(PaperDetails.class))).thenReturn(0);
			when(paperDetailsBulkUploadDao.checkDuplicateRegistrationNumberWithInusrerName(anyString(), anyString(), anyString(), anyInt())).thenReturn(BulkUploadMock.getPaperDetails1());
			doNothing().when(paperGenerationUtils).generateDigitalPaper(any(PaperDetails.class));
			bulkUploadServiceImpl.getExcelSheetReading(BulkUploadMock.getBulkImportFieldValidationDto3(),null);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getExcelSheetReading_happy_flow5() {
		Class<?> cls = String.class;
		try {
			when(restTemplateServiceImpl.sendBulkImportHistoryDtoToUpdate(any(BulkImportFieldValidationDto.class))).thenReturn(BulkUploadMock.getBulkImportHistoryDto());
			when(paperDetailsBulkUploadDao.checkForDuplicatePolicyNumber(anyString(), anyInt())).thenReturn(BulkUploadMock.getPaperDetails1());
			when(converterFactory.dataConverter(anyString(), anyString())).thenReturn("9898989898");
			Mockito.doReturn(cls).when(fieldClassMapper).getClass(anyString());
			doNothing().when(paperDetailsBulkUploadDao).saveBulkImportErrorData(BulkUploadMock.getBulkImportErrorTable());
			when(modelMapper.map(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any())).thenReturn(BulkUploadMock.getScratch());
			when(modelMapper.map(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any())).thenReturn(BulkUploadMock.getPaperDetails1());
			when(paperDetailsBulkUploadDao.saveScratchData(any(Scratch.class))).thenReturn(1);
			when(paperDetailsBulkUploadDao.getStockPoolByAllocationId(anyInt(),anyInt())).thenReturn(BulkUploadMock.getStockPool());
			when(paperDetailsBulkUploadDao.updateStockPool(any(StockPool.class))).thenReturn(true);
			when(sequenceGenerator.generateSequence(SequenceEnum.DIGITAL_PAPER_ID)).thenReturn("1");
			when(paperDetailsBulkUploadDao.savePaperDetails(any(PaperDetails.class))).thenReturn(1);
			doNothing().when(paperGenerationUtils).generateDigitalPaper(any(PaperDetails.class));
			doNothing().when(paperDetailsBulkUploadDao).updateDigitalPaper(any(PaperDetails.class));
			doNothing().when(paperGenerationUtils).revokeDigitalPaper(anyString());
			bulkUploadServiceImpl.getExcelSheetReading(BulkUploadMock.getBulkImportFieldValidationDto4(),null);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

}
