package com.digitalpaper.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.dao.IStockDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.mockdata.PurchaseOrderMockData;
import com.digitalpaper.service.impl.StockServiceImpl;
import com.digitalpaper.transfer.object.dto.StockDto;
import com.digitalpaper.transfer.object.dto.SystemPropertyValueDto;
import com.digitalpaper.transfer.object.entity.Stock;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;

import mockDatas.MockData;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class StockServiceTest {
	
	@InjectMocks
    private StockServiceImpl service;
	
    @Mock
    private IStockDao stockDao;
    
    @Mock
    private LoggedInUserContextHolder loggedInUserContextHolder;
    
    @Test
    void getStockData_Happy_flow() throws ApplicationException {
    	doNothing().when(stockDao).getStockData(1);
		StockDto actual = service.getStockData();
    	
    }
    
    
    @Test
    void saveOrUpdate_Happy_flow() throws ApplicationException {
    	doNothing().when(stockDao).purchaseOrdersave(MockData.purchaseOrderMockData());
    	doNothing().when(stockDao).paymentDetailsSave(MockData.PaymentDetailsMockData());
    	doNothing().when(stockDao).stockSave(MockData.StockMockData());
		Integer actual = service.saveOrUpdate(MockData.SaveStockDataVoVoMockData());
    	
    }
    
    @Test
    void saveCompanyId_HappyFlow() {
    	Integer companyId=2;
    	Integer userId=3;
    	Stock stockData=MockData.StockMockData();
    	when(stockDao.stockSave(stockData)).thenReturn(anyInt());
    	service.saveCompanyId(companyId, userId);
    }
    
    @Test
    void getStockDetailsBasedOnLoginUser_happy_flow() {
    	try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo());
			when(stockDao.getStockData(anyInt())).thenReturn(MockData.StockMockData());
			StockDto stockDetailsBasedOnLoginUser = service.getStockDetailsBasedOnLoginUser();
			assertEquals(stockDetailsBasedOnLoginUser.getStockCount(), MockData.StockMockData().getStockCount());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
    }
    
}
