package com.digitalpaper.servicetest;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.io.IOException;

import javax.mail.internet.MimeMessage;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.config.property.EnvironmentProperties;
import com.digitalpaper.dao.IPaperDetailsDao;
import com.digitalpaper.file.handler.service.impl.EmailServiceImpl;
import com.digitalpaper.mockdata.PurchaseHistoryMockData;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;

import freemarker.core.ParseException;
import freemarker.template.Configuration;
import freemarker.template.MalformedTemplateNameException;
import freemarker.template.TemplateException;
import freemarker.template.TemplateNotFoundException;
import mockDatas.MockData;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@ContextConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class EmailServiceImplTest {

	
	@InjectMocks
	private EmailServiceImpl serviceMock;
	
	@Mock
	private Configuration config;
	
	@Mock
    private MimeMessage mimeMessage;
	
	@Mock
	private JavaMailSender sender;
	
	@Mock
	private EnvironmentProperties environmentProperties;
	
	@Mock
	private IPaperDetailsDao iPaperDetailsDao;
	
	@Mock
	private LoggedInUserContextHolder loggedInUserContextHolder;
	
	@Test
	public void sendEmailInDigitalPaper_Happy_Flow() {	
		
		try {
			
			serviceMock.sendEmailInDigitalPaper(MockData.getMailRequestDtoMock(), MockData.getMapStringObjectMockData());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TemplateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	@Test
	public void setEmailPart_Happy_Flow() throws TemplateNotFoundException, MalformedTemplateNameException, ParseException, IOException {
		UserInfo user = PurchaseHistoryMockData.getUserInfo();
		
		when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(user);
		when(iPaperDetailsDao.getPaperImageById(any(Integer.class),any(String.class),any(String.class))).thenReturn(MockData.getFileStorageMockData());
		when(environmentProperties.getFileUploadPath()+ "/OG_IMAGE/").thenReturn("localhost//4200:getemagurl");
		when(sender.createMimeMessage()).thenReturn(any());
		when(config.getTemplate("emal-template.ftl")).thenReturn(any());
//		doNothing().when(sender).send(mimeMessage);
		serviceMock.setEmailPart(MockData.getPaperDetailsDtoMockData());
	}
	
}
