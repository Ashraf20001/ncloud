package com.digitalpaper.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.mockdata.AuthorityPaperDetailsMockData;
import com.digitalpaper.mockdata.PaperDetailsMockData;
import com.digitalpaper.mockdata.PurchaseHistoryMockData;
import com.digitalpaper.service.IAuthorityPaperDetailsService;
import com.digitalpaper.transfer.object.dto.AuthorityStockDto;
import com.digitalpaper.transfer.object.dto.CompanyTransactionDto;
import com.digitalpaper.transfer.object.dto.DownloadListVo;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class AuthorityPaperDetailsControllerTest {

	@InjectMocks
	private AuthorityPaperDetailsController controllerMock;
	
	@Mock
	private IAuthorityPaperDetailsService serviceMock;
	
	@Test
	public void getAuthorityPaperDetailsCount() {
		Long value = 10l;
		List<FilterOrSortingVo> filter = PurchaseHistoryMockData.getFilterOrSorting();
		try {
			when(serviceMock.getStockCount(filter)).thenReturn(value);
			Long val = controllerMock.getStockCount(filter);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	public void getAuthorityPaperDetailsList() {
		List<FilterOrSortingVo> filter = PurchaseHistoryMockData.getFilterOrSorting();
		List<AuthorityStockDto> dto = AuthorityPaperDetailsMockData.getAuthorityStockDtoList();
		try {
			when(serviceMock.getStockData(0, 10, filter)).thenReturn(dto);
			when(controllerMock.getStockData(1, 2, filter)).thenReturn(dto);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	public void getPaperDetailsByCompanyCount() {
		CompanyTransactionDto companyTranDto = AuthorityPaperDetailsMockData.getCompanyTransactionDto();
		try {
			when(serviceMock.getPaperDetailsByCompanyCount(companyTranDto)).thenReturn(10l);
			when(controllerMock.getPaperDetailsByCompanyCount(companyTranDto)).thenReturn(10l);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	public void getPaperDetailsByCompanyList() {
		CompanyTransactionDto companyTranDto = AuthorityPaperDetailsMockData.getCompanyTransactionDto();
		List<PaperDetailsDto> paperDetails = PaperDetailsMockData.getPaperDetailsDto();
		try {
			when(serviceMock.getPaperDetailsByCompanyList(companyTranDto)).thenReturn(paperDetails);
			when(controllerMock.getPaperDetailsByCompanyList(companyTranDto)).thenReturn(paperDetails);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	public void downloadPaperDetails() {
		DownloadListVo downloadVo = AuthorityPaperDetailsMockData.getDownloadListVo();
		ResponseEntity<ByteArrayResource> response = null;
		try {
			when(serviceMock.downloadPaperInExcel(downloadVo)).thenReturn(ResponseEntity.ok().build());
			response = controllerMock.downloadPaperDetails(downloadVo);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}

		assertEquals(HttpStatus.OK, response.getStatusCode());

	}
	
	
	@Test
	public void  dropDownForPaperDetails() {
		ArrayList<String> List = new ArrayList<>(Arrays.asList("string1", "string2"));
		try {
			when(serviceMock.getColumnsInDropDownPaperDetails()).thenReturn(List);
			controllerMock.dropDownForPaperDetails();
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	

	
	@Test
	public void downloadViewPaper() {
		DownloadListVo downloadVo = AuthorityPaperDetailsMockData.getDownloadListVo();
		ResponseEntity<ByteArrayResource> response = null;
		try {
			when(serviceMock.downloadViewPaper(downloadVo, null)).thenReturn(ResponseEntity.ok().build());
			response = controllerMock.downloadViewPaper(downloadVo, null);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}

		assertEquals(HttpStatus.OK, response.getStatusCode());

	}
	
	
}
	

