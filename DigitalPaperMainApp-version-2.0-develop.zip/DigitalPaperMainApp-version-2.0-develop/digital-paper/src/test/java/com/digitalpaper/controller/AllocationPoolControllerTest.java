package com.digitalpaper.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.mockdata.AllocationPoolMockData;
import com.digitalpaper.service.AllocationPoolService;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.PoolDto;
import com.digitalpaper.transfer.object.dto.StockDto;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class AllocationPoolControllerTest {
	
	@InjectMocks
	private AllocationPoolController allocationPoolController;
	
	@Mock
	private AllocationPoolService allocationPoolService;
	
	@Test
	void poolAction_happy_flow() {
		StockDto stockDto = AllocationPoolMockData.getStockDto();
		try {
			when(allocationPoolService.updatePoolCountByPoolAction(any(PoolDto.class))).thenReturn(AllocationPoolMockData.getStockDto());
			ApplicationResponse poolAction = allocationPoolController.poolAction(AllocationPoolMockData.getPoolDto());
			StockDto actual =(StockDto)poolAction.getContent();
			assertEquals(actual.getCompanyId(), stockDto.getCompanyId());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getStockPoolFromIdentity_happy_flow() {
		try {
			when(allocationPoolService.getStockPoolFromIdentity(anyString())).thenReturn(AllocationPoolMockData.getStockDto());
			ApplicationResponse stockPoolFromIdentity = allocationPoolController.getStockPoolFromIdentity("id");
			StockDto actual =(StockDto)stockPoolFromIdentity.getContent();
			assertEquals(actual.getCompanyId(), AllocationPoolMockData.getStockDto().getCompanyId());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getAllStockPool_happy_flow() {
		try {
			MockHttpServletRequest request = new MockHttpServletRequest();
			when(allocationPoolService.getAllStockPool(anyString(), any(HttpServletRequest.class), anyList(), anyInt(), any())).thenReturn(AllocationPoolMockData.getListStockDto());
			ApplicationResponse allStockPool = allocationPoolController.getAllStockPool(AllocationPoolMockData.getFilterOrSortingVoList(), "id", request, 0, 10);
			List<StockDto> actual =(List<StockDto>)allStockPool.getContent();
			assertEquals(actual.get(0).getCompanyId(), AllocationPoolMockData.getListStockDto().get(0).getCompanyId());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void changeStockPoolStatus_happy_flow() {
		try {
			MockHttpServletRequest request = new MockHttpServletRequest();
			doNothing().when(allocationPoolService).changeStockPoolStatus(anyBoolean(), anyString());
			allocationPoolController.changeStockPoolStatus(false, "jai");
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void getStockPoolCount_happy_Flow() {
		try {
			MockHttpServletRequest request = new MockHttpServletRequest();
			when(allocationPoolService.getStockPoolCount(any(HttpServletRequest.class))).thenReturn(10);
			ApplicationResponse stockPoolCount = allocationPoolController.getStockPoolCount(request);
			Integer number = (Integer)stockPoolCount.getContent();
			assertEquals(number, 10);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}


}
