package com.digitalpaper.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.mockdata.PaperDetailsMockData;
import com.digitalpaper.mockdata.PurchaseHistoryMockData;
import com.digitalpaper.mockdata.PurchaseOrderMockData;
import com.digitalpaper.service.IPaperDetailsService;
import com.digitalpaper.test.DigitalPaperUnitTest;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.dto.FieldDto;
import com.digitalpaper.transfer.object.dto.PaperDetailsDto;

import mockDatas.MockData;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class PaperDetailsControllerTest extends DigitalPaperUnitTest {

	@InjectMocks
	private PaperDetailsController paperDetailsConMock;
	
	@Mock
	private IPaperDetailsService iPaperDetailsServiceMock;
	
	@Test
	public void getPaperDetailsCount() {
		Long value = 10l;
		List<FilterOrSortingVo> filter = PurchaseHistoryMockData.getFilterOrSorting();
		try {
			when(iPaperDetailsServiceMock.getPaperDeatilsCount(filter)).thenReturn(value);
			Long result = paperDetailsConMock.getPaperDetailsCount(filter);
			assertNotNull(result);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	public void getPaperDetailsList() {
		Integer skip =0;
		Integer limit =10;
		List<FilterOrSortingVo> filter = PurchaseHistoryMockData.getFilterOrSorting();
		List<PaperDetailsDto> dto = PaperDetailsMockData.getPaperDetailsDto();
		try {
			when(iPaperDetailsServiceMock.getPaperDetailsList(skip, limit, filter)).thenReturn(dto);
			List<PaperDetailsDto> result = paperDetailsConMock.getPaperDetailsList(skip, limit, filter);
			assertNotNull(result);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	public void updateRevokeStatus() {
		try {
			when(iPaperDetailsServiceMock.updateRevokeStatus("123")).thenReturn("123");
			ApplicationResponse response = paperDetailsConMock.updateRevoke("123");
			assertNotNull(response);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void getDownloadData_HappyFlow() {
		Integer bulkUploadId=1;
		String pageIdentity="c741ae6b5c3a49b888d2592a51c6bu8u";
		ResponseEntity<ByteArrayResource> byteArray = new ResponseEntity<>(HttpStatus.ACCEPTED);
		
		try {
			when(iPaperDetailsServiceMock.getScratchDataInExcel(pageIdentity, bulkUploadId, null)).thenReturn(PaperDetailsMockData.getExcelList());
			when(iPaperDetailsServiceMock.excelDownload(PaperDetailsMockData.getExcelList())).thenReturn(byteArray);
			ResponseEntity<ByteArrayResource> downloadData = paperDetailsConMock.getDownloadData(bulkUploadId, pageIdentity, null);
			} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	
	@Test
	public void updateRevokedList() {
		PaperDetailsDto dto = PaperDetailsMockData.getDetails();
		try {
			when(iPaperDetailsServiceMock.getPaperDetailsData("123")).thenReturn(dto);
			PaperDetailsDto result = paperDetailsConMock.getPaperDetailsData("123");
			assertNotNull(result);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void excelDownload() {
		 ResponseEntity<ByteArrayResource> byteArray = new ResponseEntity<>(HttpStatus.ACCEPTED);
		 ArrayList<HashMap<String, Object>> excelList = PaperDetailsMockData.getExcelList();
		 List<String> columnList = PaperDetailsMockData.getColumnList();
		 
		try {
			when(iPaperDetailsServiceMock.excelDownload(excelList)).thenReturn(byteArray);
			when(paperDetailsConMock.sampleExcelDownload(columnList)).thenReturn(byteArray);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}

	}
	
	@Test
	public void getSuccessData_HappyFlow() {
		Integer bulkUploadId=1;
		List<FieldDto> fieldDto = MockData.getFieldDtoList();
		String pageIdentity="c741ae6b5c3a49b888d2592a51c6bu8u";
		Integer skip=0;
		Integer limit=10;
		List<FilterOrSortingVo> filterOrSortingVo = PurchaseOrderMockData.getListFilterOrSortingVo();
		
		try {
			when(iPaperDetailsServiceMock.getSuccessTable(pageIdentity, bulkUploadId, filterOrSortingVo, null, skip, limit)).thenReturn(PaperDetailsMockData.getExcelList());
			ArrayList<HashMap<String, Object>> successData = paperDetailsConMock.getSuccessData(bulkUploadId, pageIdentity, skip, limit, filterOrSortingVo, null);
			assertNotNull(successData);
			
		} catch (ApplicationException e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	public void getErrorData_HappyFlow() {
		Integer bulkUploadId=1;
		List<FieldDto> fieldDto = MockData.getFieldDtoList();
		String pageIdentity="c741ae6b5c3a49b888d2592a51c6bu8u";
		Integer skip=0;
		Integer limit=10;
		List<FilterOrSortingVo> filterOrSortingVo = PurchaseOrderMockData.getListFilterOrSortingVo();
		
		try {
			when(iPaperDetailsServiceMock.getErrorTable(pageIdentity, bulkUploadId, filterOrSortingVo, null, skip, limit)).thenReturn(PaperDetailsMockData.getExcelList());
			ArrayList<HashMap<String, Object>> errorData = paperDetailsConMock.getErrorData(bulkUploadId, pageIdentity, skip, limit, filterOrSortingVo, null);
			assertNotNull(errorData);
			
		} catch (ApplicationException e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	public void getTotalRecordsCount_HappyFlow() {
		Integer bulkUploadId=1;
		Long count =3L;

		when(iPaperDetailsServiceMock.getTotalRecords(bulkUploadId)).thenReturn(count);
		Long totalRecordsCount = paperDetailsConMock.getTotalRecordsCount(bulkUploadId);
		assertNotNull(totalRecordsCount);

		
	}
	
	@Test
	public void getSuccessRecordsCount_HappyFlow() {
		Integer bulkUploadId=1;
		Long count =3L;

		when(iPaperDetailsServiceMock.getSuccessRecordsCount(bulkUploadId)).thenReturn(count);
		Long successCount = paperDetailsConMock.getSuccessRecordsCount(bulkUploadId);
		assertNotNull(successCount);

	}
	
	@Test
	public void getErrorRecordsCount_HappyFlow() {
		Integer bulkUploadId=1;

		Long count =3L;

		when(iPaperDetailsServiceMock.getErrorRecordsCount(bulkUploadId)).thenReturn(count);
		Long errorCounts = paperDetailsConMock.getErrorRecordsCount(bulkUploadId);
		assertNotNull(errorCounts);
	}
}
