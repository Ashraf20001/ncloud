package com.digitalpaper.servicetest;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.adapter.service.AdapterService;
import com.digitalpaper.dao.IDigitalPaperDao;
import com.digitalpaper.dao.IPaperDetailsDao;
import com.digitalpaper.dao.IStockDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.mockdata.PaperDetailsMockData;
import com.digitalpaper.mockdata.PurchaseHistoryMockData;
import com.digitalpaper.service.impl.DigitalPaperSeviceImpl;
import com.digitalpaper.transfer.object.dto.DigitalPaperDto;
import com.digitalpaper.transfer.object.dto.FieldGroup;
import com.digitalpaper.transfer.object.dto.StockDto;
import com.digitalpaper.transfer.object.dto.UserInfo;
import com.digitalpaper.transfer.object.entity.Stock;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;

import mockDatas.MockData;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@ContextConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class DigitalPaperServiceTest {

	@InjectMocks
	private DigitalPaperSeviceImpl digitaslPaperSerciveMock;
	
	@Mock
	private IDigitalPaperDao digitalPaperDaoMock;
	
	@Mock
	private AdapterService adapterService;
	
	@Mock
	private LoggedInUserContextHolder loggedInUserContextHolder;
	
	@Mock
	public IStockDao stockDao;
	
	@Mock
	private IPaperDetailsDao iPaperDetailsDao;
	
	@Test
	public void updateStockPaperCount_Happy_Flow() {
		
		UserInfo user = PurchaseHistoryMockData.getUserInfo();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(user);
			when(stockDao.getStockData(2)).thenReturn(MockData.StockMockData());
			doNothing().when(stockDao).updateStock(MockData.StockMockData());
			Stock actual = digitaslPaperSerciveMock.updateStockPaperCount(true,2);
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void updateStockPaperCount_Error_Flow() {
		
		UserInfo user = PurchaseHistoryMockData.getUserInfo();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(user);
			when(stockDao.getStockData(2)).thenReturn(MockData.StockMockData());
			doNothing().when(stockDao).updateStock(MockData.StockMockData());
			Stock actual = digitaslPaperSerciveMock.updateStockPaperCount(false,2);
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void saveDigitalPaper_Happy_Flow() {
		
		FieldGroup fieldGroup = new FieldGroup();
		
		try {
			when(adapterService.buildFieldGroup(any())).thenReturn(MockData.getDigitalPaperDtoMock());
			when(digitalPaperDaoMock.checkForDuplicatePolicyNumber("wiurywrf",1)).thenReturn(MockData.getPaperDetailsMockData());
			when(digitalPaperDaoMock.checkDuplicateRegistrationNumberWithInusrerName("eiwuer", "eIUYIWUE", "WEUIYEF", 2)).thenReturn(MockData.getPaperDetailsMockData());
			doNothing().when(digitalPaperDaoMock).saveDigitalPaperDetails(MockData.getPaperDetailsMockData());
			
			try {
				String acuelResult = digitaslPaperSerciveMock.saveDigitalPaper(fieldGroup);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ApplicationException e) {
			
			e.printStackTrace();
		}
	}
	
	@Test
	public void saveDigitalPaper_Error_Flow() {
		
		FieldGroup fieldGroup = new FieldGroup();
		
		try {
			when(adapterService.buildFieldGroup(any())).thenReturn(MockData.getDigitalPaperDtoMock());
			when(digitalPaperDaoMock.checkForDuplicatePolicyNumber("wiurywrf",1)).thenReturn(MockData.getPaperDetailsMockData());
			when(digitalPaperDaoMock.checkDuplicateRegistrationNumberWithInusrerName("eiwuer", "eIUYIWUE", "WEUIYEF", 2)).thenReturn(MockData.getPaperDetailsMockData());
			doNothing().when(digitalPaperDaoMock).saveDigitalPaperDetails(MockData.getPaperDetailsMockData());
			
			try {
				String acuelResult = digitaslPaperSerciveMock.saveDigitalPaper(fieldGroup);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ApplicationException e) {
			
			e.printStackTrace();
		}
	}
	
	@Test
	public void getpaperDetails_Happy_flow() {
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseHistoryMockData.getUserInfo1());
			when(digitalPaperDaoMock.getPaperDetails("83476wueryuy")).thenReturn(PaperDetailsMockData.getPaperData());
			when(iPaperDetailsDao.getPaperImageById(1, "PPR_GEN", "digital-paper")).thenReturn(PaperDetailsMockData.getFileStorage());
			when(digitaslPaperSerciveMock.getpaperDetails("83476wueryuy")).thenReturn(PaperDetailsMockData.getDetails());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
}
