package com.digitalpaper.mockdata;

import static java.time.temporal.TemporalAdjusters.firstDayOfYear;
import static java.time.temporal.TemporalAdjusters.lastDayOfYear;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.digitalpaper.transfer.object.dto.AuthorityBarChartDto;
import com.digitalpaper.transfer.object.dto.BarChartDto;
import com.digitalpaper.transfer.object.dto.DashBoardInputDto;
import com.digitalpaper.transfer.object.dto.DashBoardOutputDto;
import com.digitalpaper.transfer.object.dto.DoughNutDto;
import com.digitalpaper.transfer.object.dto.GraphValuesDto;
import com.digitalpaper.transfer.object.dto.MonthCountDto;
import com.digitalpaper.transfer.object.dto.TopCompanyPurchaseDto;

public class DashBoardMockData {

	public static DashBoardInputDto getDashBoardInputDto() {
		DashBoardInputDto dashBoardInputDto = new DashBoardInputDto();
		
		LocalDateTime now = LocalDateTime.now(); 
		LocalDateTime firstDay = now.with(firstDayOfYear()); 
		LocalDateTime lastDay = now.with(lastDayOfYear());
		dashBoardInputDto.setFromDate(firstDay);
		dashBoardInputDto.setToDate(lastDay);
		dashBoardInputDto.setFilterType("CurrentYear");
		return dashBoardInputDto;
	}
	
	public static DashBoardOutputDto getBoardOutputDto() {
		DashBoardOutputDto dashBoardOutputDto = new DashBoardOutputDto();
		dashBoardOutputDto.setDashBoardValues(getGraphValuesDto());
		return dashBoardOutputDto;
		
	}
	
	public static List<GraphValuesDto> getGraphValuesDto(){
			
		List<GraphValuesDto> graphValueDtoList= new ArrayList<GraphValuesDto>();
		
		GraphValuesDto graphValuesDto = new GraphValuesDto();
		graphValuesDto.setXAxis("Axa insurance");
		graphValuesDto.setYAxis(500L);
		
		graphValueDtoList.add(graphValuesDto);
		return graphValueDtoList;
	}
	
	public static List<Object[]> getDashBoardObjects(){
		List<Object[]> dashboardObjectData= new ArrayList<Object[]>();
		Object[] object= {1,500L};
		Object[] object2= {2,1000L};
		dashboardObjectData.add(object);
		dashboardObjectData.add(object2);
		return dashboardObjectData;
	}
	
	public static List<Integer> getCompanyIdList(){
		List<Integer> idList = new ArrayList<Integer>();
		idList.add(2);
		idList.add(236);
		return idList;
	}
	
	public static TopCompanyPurchaseDto getTopPurchaseCompaniesDto(){
		TopCompanyPurchaseDto topCompanyPurchaseDto = new TopCompanyPurchaseDto();
		topCompanyPurchaseDto.setCompanies("Axa insurance");
		topCompanyPurchaseDto.setStockCount(1239L);
		return topCompanyPurchaseDto;
	}
	
	public static List<TopCompanyPurchaseDto> getTopPurchaseCompaniesList(){
		List<TopCompanyPurchaseDto> companyPurchases = new ArrayList<TopCompanyPurchaseDto>();
		companyPurchases.add(getTopPurchaseCompaniesDto());
		return companyPurchases;
	}
	
	public static DashBoardOutputDto getListOfGrapValueDto() {
        DashBoardOutputDto dto = new DashBoardOutputDto();
        List<GraphValuesDto> list = new ArrayList<>();
        GraphValuesDto graph = new GraphValuesDto();
        graph.setXAxis("JANUARY");
        graph.setYAxis(10l);
        list.add(graph);
        dto.setDashBoardValues(list);
        return dto;
    }
	
	public static DashBoardInputDto getDashBoardInputDto1() {
		DashBoardInputDto dto = new DashBoardInputDto();
		dto.setFilterType("");
		dto.setFromDate(LocalDateTime.now());
		dto.setToDate(LocalDateTime.now());
		return dto;	
	}
	
	public static DashBoardInputDto getDashBoardInputDto2() {
		DashBoardInputDto dto = new DashBoardInputDto();
		dto.setFilterType("");
		dto.setFromDate(LocalDateTime.now());
		dto.setToDate(LocalDateTime.now());
		return null;	
	}

	public static List<BarChartDto> getBarChartList() {
		List<BarChartDto> list = new ArrayList<>();
		BarChartDto dto = new BarChartDto();
		dto.setCertificateIssued(100l);
		dto.setMonth("JANUARY");
		dto.setStockAllocated(200l);
		list.add(dto);
		return list;
	}
	
	public static List<AuthorityBarChartDto> getAuthorityBarChart() {
		List<AuthorityBarChartDto> list = new ArrayList<>();
		AuthorityBarChartDto dto = new AuthorityBarChartDto();
		dto.setCompanyId(1);
		dto.setInsuredComapny("abc");
		dto.setShortName("a");
		dto.setDigitalPaperAllocated(100);
		dto.setDigitalPaperPurchased(200);
		list.add(dto);
		return list;
	}
	
	public static List<MonthCountDto> getMonthCount() {
		List<MonthCountDto> list = new ArrayList<>();
//		list.add(new MonthCountDto(0,10l));
//		Month[] month1 = Month.values();
		MonthCountDto dto = new MonthCountDto();
		dto.setCount(10l);
		dto.setMonth(1);
		list.add(dto);
		
		return list;
	}
	
	public static List<MonthCountDto> getMonthCount1() {
		List<MonthCountDto> list = new ArrayList<>();
//		list.add(new MonthCountDto(0,10l));
//		Month[] month1 = Month.values();
		MonthCountDto dto = new MonthCountDto();
		dto.setCount(10l);
		dto.setMonth(2);
		list.add(dto);
		
		return list;
	}

	public static List<MonthCountDto> getListMonthCountDto() {
		List<MonthCountDto> list = new ArrayList<>();
		MonthCountDto dto = new MonthCountDto();
		dto.setCount(10l);
		dto.setMonth(2);
		list.add(dto);
		
		return list;
	}
	
	  public static DoughNutDto getDoughNutDtoData() {
	         DoughNutDto doughNut = new DoughNutDto();
	         doughNut.setActive(3L);
	         doughNut.setExpired(2L);
	         doughNut.setRevoked(5L);
	        return doughNut;
	        
	    }

	
}
