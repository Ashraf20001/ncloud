package com.digitalpaper.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.bind.annotation.RequestBody;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.mockdata.PurchaseHistoryMockData;
import com.digitalpaper.service.IPurchaseHistoryService;
import com.digitalpaper.service.IStockService;
import com.digitalpaper.transfer.object.dto.CompanyAndCountDto;
import com.digitalpaper.transfer.object.dto.CompanyViewDto;
import com.digitalpaper.transfer.object.dto.DownloadListVo;
import com.digitalpaper.transfer.object.dto.PurchaseHistoryViewDto;
import com.digitalpaper.utils.core.ApplicationUtils;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class PurchaseHistoryControllerTest {

	@InjectMocks
	private PurchaseHistoryController purchHistryConMock;

	@Mock
	private IPurchaseHistoryService iPurchHistryServiceMock;

	@Mock
	IStockService stockServiceMock;

	@Test
	public void getPurchaseHistoryData() {
		Integer skip = 0;
		int limit = 5;
		List<FilterOrSortingVo> filtvo = PurchaseHistoryMockData.getFilterOrSorting();
		List<CompanyAndCountDto> companyCount = PurchaseHistoryMockData.getCompanyAndCount();
		List<PurchaseHistoryViewDto> purchHistryDto = PurchaseHistoryMockData.getPurchHistyViewDto();
		try {
			when(iPurchHistryServiceMock.getPurchaseOrderData(skip, limit, filtvo)).thenReturn(companyCount);
			List<CompanyAndCountDto> result = purchHistryConMock.getPurchaseOrderData(skip, limit, filtvo);
			assertNotNull(result);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
	public void getPurchaseHisCount() {
		Long count = 10l;
		List<FilterOrSortingVo> filtvo = PurchaseHistoryMockData.getFilterOrSorting();
		try {
			when(iPurchHistryServiceMock.getPurchaseOrderEntityCount(filtvo)).thenReturn(count);
			Long result = purchHistryConMock.getPurchaseOrderCount(filtvo);
			assertNotNull(result);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}

	}



	@Test
	public void DownloadMethod_Happy_flow() {
		List<CompanyAndCountDto> dto = PurchaseHistoryMockData.getCompanyAndCount();
//            		asserstockServiceMock.excelDownload();
		try {
			when(iPurchHistryServiceMock
					.getpurchaseOrderDataInDownload(PurchaseHistoryMockData.getDownload().getFilterVo()))
					.thenReturn(PurchaseHistoryMockData.getCompanyAndCount());
			when(iPurchHistryServiceMock.getDownloadDataToExcel(dto,
					PurchaseHistoryMockData.getDownload().getColumnList()))
					.thenReturn(PurchaseHistoryMockData.getArrayListMockData());

			purchHistryConMock.DownloadMethod(PurchaseHistoryMockData.getDownloadListVo());

		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}

	@Test
    public void testDownloadMethod1() throws ApplicationException {
		        
		        List<CompanyAndCountDto> dto = PurchaseHistoryMockData.getCompanyAndCount();
//		        ArrayList<HashMap<String, Object>> data = PurchaseHistoryMockData.getArrayListMockData();
		        ArrayList<HashMap<String, Object>> data = PurchaseHistoryMockData.getArrayListMockData();

                DownloadListVo downloadListVo = PurchaseHistoryMockData.getDownloadListVo();

		        when(iPurchHistryServiceMock.getpurchaseOrderDataInDownload(downloadListVo.getFilterVo()))
		                .thenReturn(dto);
		        when(iPurchHistryServiceMock.getDownloadDataToExcel(dto, downloadListVo.getColumnList()))
		                .thenReturn(PurchaseHistoryMockData.getArrayListMockData());
		        when(stockServiceMock.excelDownload(data)).thenReturn(ResponseEntity.ok().build());

		        
		        ResponseEntity<ByteArrayResource> response = null;
		        try {
		            response = purchHistryConMock.DownloadMethod(downloadListVo);
		        } catch (Exception e) {
		            Assertions.fail(e.toString());
		        }

		      
		        assertEquals(HttpStatus.OK, response.getStatusCode());
		        

		        
		        verify(iPurchHistryServiceMock).getpurchaseOrderDataInDownload(downloadListVo.getFilterVo());
		        verify(iPurchHistryServiceMock).getDownloadDataToExcel(dto, downloadListVo.getColumnList());
		        verify(stockServiceMock).excelDownload(data);
		    }

}
