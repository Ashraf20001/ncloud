package com.digitalpaper.controller;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.io.IOException;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.file.handler.service.IEmailService;
import com.digitalpaper.test.DigitalPaperUnitTest;

import freemarker.template.TemplateException;
import mockDatas.MockData;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class EmailControllerTest {

	@InjectMocks
	private EmailController controller;
	
	@Mock
	private IEmailService serviceMock;
	
	@Test
	public void sendEmail_Happy_Flow() {
		String response="Mail Sent Successfully";
		try {
//			doNothing().when(serviceMock).setEmailPart(MockData.getPaperDetailsDtoMockData());
			when(serviceMock.setEmailPart(MockData.getPaperDetailsDtoMockData())).thenReturn(response);
			controller.sendEmail(MockData.getPaperDetailsDtoMockData());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (TemplateException e) {
			e.printStackTrace();
		}
	}
}
