package com.digitalpaper.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.modelmapper.ModelMapper;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.digitalpaper.DigitalPaperApplication;
import com.digitalpaper.config.model.FilterOrSortingVo;
import com.digitalpaper.config.property.EnvironmentProperties;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.dao.CustomerDao;
import com.digitalpaper.dao.IDigitalPaperDao;
import com.digitalpaper.dao.IPaperDetailsDao;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.exception.core.codes.ErrorCodes;
import com.digitalpaper.file.handler.service.IEmailService;
import com.digitalpaper.mockdata.CustomerMockData;
import com.digitalpaper.mockdata.PaperDetailsMockData;
import com.digitalpaper.mockdata.PurchaseOrderMockData;
import com.digitalpaper.service.impl.CustomerServiceImpl;
import com.digitalpaper.service.impl.EmailSenderService;
import com.digitalpaper.transfer.object.dto.ChangePasswordDto;
import com.digitalpaper.transfer.object.dto.CustomerDto;
import com.digitalpaper.transfer.object.dto.MailRequestDto;
import com.digitalpaper.transfer.object.dto.ResetPasswordDto;
import com.digitalpaper.transfer.object.dto.ResetPasswordRequest;
import com.digitalpaper.transfer.object.entity.Customer;
import com.digitalpaper.transfer.object.entity.FileStorage;
import com.digitalpaper.transfer.object.entity.ForgetPassword;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;

import freemarker.core.ParseException;
import freemarker.template.MalformedTemplateNameException;
import freemarker.template.TemplateException;
import freemarker.template.TemplateNotFoundException;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DigitalPaperApplication.class)
public class CustomerServiceTest {

	@InjectMocks
	private CustomerServiceImpl customerServiceImpl;
	
	@Mock
	private CustomerDao customerDao;
	
	@Mock
	private IPaperDetailsDao paperDao;
	
	@Mock
	private LoggedInUserContextHolder loggedInUserContextHolder;
	
	@Mock
	private IDigitalPaperDao digitalPaperDao;
	
	@Mock
	private IEmailService emailService;
	
	@Mock
	private EnvironmentProperties environmentProperties;
	
	@Mock
	private ModelMapper modelMapper;
	
	@Mock
	private JavaMailSender sender;
	
	@Mock
	private EmailSenderService sendEmail;
	
	@Test
	void getCustomerList_HappyFlow() {
		Integer min=0;
		Integer max=10;
		List<FilterOrSortingVo> filter= PurchaseOrderMockData.getListFilterOrSortingVo();
		Integer companyId=2;
		
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo());
			when(customerDao.getCustomerDetails(min, max, filter, companyId)).thenReturn(CustomerMockData.getCustomerList());
			List<CustomerDto> customerList = customerServiceImpl.getCustomerList(min, max, filter);
			assertNotNull(customerList);
		}
		catch(Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void saveCustomer_HappyFlow() {
		Customer customerData = CustomerMockData.getCustomerData();
		String username = customerData.getUsername();
		String password = customerData.getPassword();
		PaperDetails paperDetailsMock = PaperDetailsMockData.getPaperData();
		FileStorage fileStorage = PaperDetailsMockData.getFileStorage();
		Integer paperId = paperDetailsMock.getPaperId();
		String registrationNumber = paperDetailsMock.getVdRegistrationNumber();
		MailRequestDto mailRequestMockData = CustomerMockData.getMailRequestMockData();
		Map<String, Object> modelHashMap = CustomerMockData.getModelHashMap();

		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo());
			when(customerDao.checkExistingCustomerBasedOnEmailAndUserName(username, password)).thenReturn(null);
			doNothing().when(customerDao).saveCustomer(customerData);
			when(digitalPaperDao.getPaperDetails(registrationNumber)).thenReturn(paperDetailsMock);
			when(paperDao.getPaperImageById(paperId, ApplicationConstants.UPD_TYPE, ApplicationConstants.RP_TYPE))
					.thenReturn(fileStorage);
			when(emailService.sendEmailInDigitalPaper(mailRequestMockData, modelHashMap))
					.thenReturn(CustomerMockData.getMailResponse());
			when(environmentProperties.getSendEmailName()).thenReturn(mailRequestMockData.getFrom());
			Customer saveCustomer = customerServiceImpl.saveCustomer(paperDetailsMock);
			assertNotNull(saveCustomer);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
//	@Test
//	void saveCustomer_HappyFlow1() {
//		Customer customerData = CustomerMockData.getCustomerData();
//		String username = customerData.getUsername();
//		String email = customerData.getEmail();
//		PaperDetails paperDetailsMock = PaperDetailsMockData.getPaperData();
//		FileStorage fileStorage = PaperDetailsMockData.getFileStorage();
//		Integer paperId = paperDetailsMock.getPaperId();
//		String registrationNumber = paperDetailsMock.getVdRegistrationNumber();
//		MailRequestDto mailRequestMockData = CustomerMockData.getMailRequestMockData();
//		Map<String, Object> modelHashMap = CustomerMockData.getModelHashMap();
//
//		try {
//			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo());
//			when(customerDao.checkExistingCustomerBasedOnEmailAndUserName(username, email)).thenReturn(CustomerMockData.getExistingCustomerData());
////			doNothing().when(customerDao).saveCustomer(customerData);
////			when(digitalPaperDao.getPaperDetails(registrationNumber)).thenReturn(paperDetailsMock);
////			when(paperDao.getPaperImageById(paperId, ApplicationConstants.UPD_TYPE, ApplicationConstants.RP_TYPE))
////					.thenReturn(fileStorage);
////			when(emailService.sendEmailInDigitalPaper(mailRequestMockData, modelHashMap))
////					.thenReturn(CustomerMockData.getMailResponse());
////			when(environmentProperties.getSendEmailName()).thenReturn(mailRequestMockData.getFrom());
//			Customer saveCustomer = customerServiceImpl.saveCustomer(paperDetailsMock);
//			assertNotNull(saveCustomer);
//		} catch (Exception e) {
//			Assertions.fail(e.toString());
//		}
//	}
	
	
	@Test 
	void getLoginCustomerDetails_Happy_Flow() {
		
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo());
			when(customerDao.getLoginCustomer(1)).thenReturn(CustomerMockData.getCustomerData());
			CustomerDto actualResult  = customerServiceImpl.getLoginCustomerDetails();
			assertNotNull(actualResult);
		} catch (ApplicationException e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test 
	void updateLoginCustomer_Happy_Flow() {
		
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo());
			when(customerDao.getLoginCustomer(1)).thenReturn(CustomerMockData.getCustomerData());
			doNothing().when(customerDao).updateCustomer(CustomerMockData.getCustomerData());
			String updateLoginCustomer = customerServiceImpl.updateLoginCustomer(CustomerMockData.getCustomerDto());
			assertNotNull(updateLoginCustomer);
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	void updateLoginCustomer_Error_Flow() {
		when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo());
		when(customerDao.getLoginCustomer(1)).thenReturn(null);
		ApplicationException exception = new ApplicationException(ErrorCodes.INVALID_CUSTOMER);
		ApplicationException exception2 = assertThrows(ApplicationException.class, ()->{
			customerServiceImpl.updateLoginCustomer(null);
		});
		assertEquals(exception.toString(), exception2.toString());
	}
	
	@Test
	void updateLoginCustomer_Error_Flow2() {
		CustomerDto customerData = CustomerMockData.getCustomerDto();
		customerData.setPhoneNumber("#$%&$@!*392");
		when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo());
		when(customerDao.getLoginCustomer(1)).thenReturn(CustomerMockData.getCustomerData());
		ApplicationException exception = new ApplicationException(ErrorCodes.INVALID_PHONE_NO);
		ApplicationException exception2 = assertThrows(ApplicationException.class, ()->{
			customerServiceImpl.updateLoginCustomer(customerData);
		});
		assertEquals(exception.toString(), exception2.toString());
		
	}
	
	
	@Test
	void getCustomerByUsername_HappyFlow() {
		Customer customerData = CustomerMockData.getCustomerData();
		CustomerDto customerDto = CustomerMockData.getCustomerDto();
		String username = customerData.getUsername();
		when(customerDao.getCustomerByUsername(username)).thenReturn(customerData);
		when(modelMapper.map(customerData, CustomerDto.class)).thenReturn(customerDto);
		CustomerDto customerByUsername = customerServiceImpl.getCustomerByUsername(username);
		assertNotNull(customerByUsername);
	}
	
	@Test
	void getCoustomerCount_Hapy_Flow() {
		Integer CompanyCount= 2;
		long count = 12;
		List<FilterOrSortingVo> filterMock= PurchaseOrderMockData.getListFilterOrSortingVo();
		
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo());
			when(customerDao.getCustomerCount(CompanyCount, filterMock)).thenReturn(count);
			Long actual	= customerServiceImpl.getCoustomerCount(filterMock);
		} catch (ApplicationException e) {
			
			e.printStackTrace();
		}
	}
	
	@Test
	void updatCustomerDetails_Happy_Flow() throws TemplateNotFoundException, MalformedTemplateNameException, ParseException, MessagingException, IOException, TemplateException {
		Customer customerData = CustomerMockData.getCustomerData();
		MimeMessage message = sender.createMimeMessage();
		
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo());
			when(customerDao.getCustomerByIdentity(anyString())).thenReturn(customerData);
			doNothing().when(customerDao).updateCustomer(CustomerMockData.getFirstTimeLoginCustomerData());
			doNothing().when(sender).send(message);
			String actual= customerServiceImpl.updatCustomerDetails(CustomerMockData.getCustomerDto());
		} catch (ApplicationException e) {
			
			e.printStackTrace();
		}
		
	}
	
	@Test
	void getResetCustomerPassword_HappyFlow() {
		ResetPasswordDto resetPasswordDto = CustomerMockData.getResetPasswordDto();
		try {
			when(customerDao.getCustomerByIdentity(anyString())).thenReturn(CustomerMockData.getFirstTimeLoginCustomerData());
			doNothing().when(customerDao).updateCustomer(CustomerMockData.getFirstTimeLoginCustomerData());
			customerServiceImpl.resetCustomerPassword(resetPasswordDto);
			
		} catch (ApplicationException e) {
			Assertions.fail(e.toString());
		}
		
	}
	
	@Test
	void getResetCustomerPassword_ErrorFlow1() {
		ResetPasswordDto resetPasswordDto = CustomerMockData.getResetPasswordDto();
		try {
			when(customerDao.getCustomerByIdentity(anyString())).thenReturn(null);
			ApplicationException exception1 = new ApplicationException(ErrorCodes.INVALID_DATA);
			ApplicationException exception2 = assertThrows(ApplicationException.class,()->{
				customerServiceImpl.resetCustomerPassword(resetPasswordDto);
			});
			assertEquals(exception1.toString(), exception2.toString());
			
		} catch (ApplicationException e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void validateEmail_HappyFlow() {
		LocalDate today = LocalDate.now();
		String emailId="customer@gmail.com";
		List<ForgetPassword> forgetPasswordList = CustomerMockData.getEmptyForgetPasswordList();
		List<ForgetPassword> forgetPasswordSingleList = CustomerMockData.getForgetPasswordSingleList();
		Customer customerData = CustomerMockData.getCustomerData();
		ForgetPassword forgetPasswordMockData = CustomerMockData.getForgetPasswordMockData();
		ResetPasswordRequest resetPasswordData = CustomerMockData.getResetPasswordRequestData();
		try {
			when(customerDao.getForgetDetailsByEmailId(today,emailId)).thenReturn(forgetPasswordList);
			when(customerDao.getCustomerByUsername(customerData.getEmail())).thenReturn(customerData);
			doNothing().when(customerDao).saveForgetEntry(forgetPasswordMockData);
			when(customerDao.getForgetDetailsByEmailId(today,emailId)).thenReturn(forgetPasswordSingleList);
			when(sendEmail.sendResetEmail(resetPasswordData)).thenReturn(CustomerMockData.getMailResponse());
			String validateEmail = customerServiceImpl.validateEmail(emailId);
			assertNotNull(validateEmail);
			
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void validateEmail_ErrorFlow() {
		LocalDate today = LocalDate.now();
		String emailId="customer@gmail.com";
		List<ForgetPassword> forgetPasswordList = CustomerMockData.getForgetPasswordList();
		try {
			when(customerDao.getForgetDetailsByEmailId(today,emailId)).thenReturn(forgetPasswordList);
			ApplicationException applicationException = new ApplicationException(ErrorCodes.FORGETPWDLIMIT);
			ApplicationException applicationException2 = assertThrows(ApplicationException.class, ()->{
				customerServiceImpl.validateEmail(emailId);
			});
			assertEquals(applicationException.toString(), applicationException2.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void validateEmail_ErrorFlow2() {
		LocalDate today = LocalDate.now();
		String emailId="customer@gmail.com";
		List<ForgetPassword> forgetPasswordList = CustomerMockData.getEmptyForgetPasswordList();
		Customer customerData = CustomerMockData.getCustomerData();
		try {
			when(customerDao.getForgetDetailsByEmailId(today,emailId)).thenReturn(forgetPasswordList);
			when(customerDao.getCustomerByUsername(customerData.getEmail())).thenReturn(null);
			ApplicationException applicationException = new ApplicationException(ErrorCodes.INVALID_EMAIL_ID);
			ApplicationException applicationException2 = assertThrows(ApplicationException.class, ()->{
				customerServiceImpl.validateEmail(emailId);
			});
			assertEquals(applicationException.toString(), applicationException2.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void updateCustomerPassword_HappyFlow() {
		ResetPasswordDto resetPasswordDto = CustomerMockData.getResetPasswordDto();
		ForgetPassword forgetPasswordMockData = CustomerMockData.getForgetPasswordBeforeExpiryTimeMockData();
		Customer customerData = CustomerMockData.getCustomerData();
		try {
			when(customerDao.getCustomerIdFromLoginTable(anyString())).thenReturn(forgetPasswordMockData);
			when(customerDao.getCustomerByIdentity(anyString())).thenReturn(customerData);
			doNothing().when(customerDao).updateCustomer(customerData);
			String updateCustomerPassword = customerServiceImpl.updateCustomerPassword(resetPasswordDto);
			assertNotNull(updateCustomerPassword);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void updateCustomerPassword_ErrorFlow() {
			ResetPasswordDto resetPasswordDto = CustomerMockData.getResetPasswordDto();
		
		try {
			when(customerDao.getCustomerIdFromLoginTable(anyString())).thenReturn(null);
			ApplicationException applicationException = new ApplicationException(ErrorCodes.INVALID_DATA);
			ApplicationException applicationException2 = assertThrows(ApplicationException.class, ()->{
				customerServiceImpl.updateCustomerPassword(resetPasswordDto);
			});
			assertEquals(applicationException.toString(), applicationException2.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void updateCustomerPassword_ErrorFlow2() {
		ResetPasswordDto resetPasswordDto = CustomerMockData.getResetPasswordDto();
		resetPasswordDto.setConfirmPassword("Axa@123");
		ForgetPassword forgetPasswordMockData = CustomerMockData.getForgetPasswordBeforeExpiryTimeMockData();
		
		try {
			when(customerDao.getCustomerIdFromLoginTable(anyString())).thenReturn(forgetPasswordMockData);
			ApplicationException applicationException = new ApplicationException(ErrorCodes.PWD_MISSMATCH);
			ApplicationException applicationException2 = assertThrows(ApplicationException.class ,()->{
				customerServiceImpl.updateCustomerPassword(resetPasswordDto);
			});
			assertEquals(applicationException.toString(),applicationException2.toString());
			
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void updateCustomerPassword_ErrorFlow3() {
		ResetPasswordDto resetPasswordDto = CustomerMockData.getResetPasswordDto();
		ForgetPassword forgetPasswordMockData = CustomerMockData.getForgetPasswordMockData();
		try {
			when(customerDao.getCustomerIdFromLoginTable(anyString())).thenReturn(forgetPasswordMockData);
			ApplicationException applicationException = new ApplicationException(ErrorCodes.LINK_EXPIRED);
			ApplicationException applicationException2 = assertThrows(ApplicationException.class, ()->{
				customerServiceImpl.updateCustomerPassword(resetPasswordDto);
			});
			assertEquals(applicationException.toString(), applicationException2.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void changePassword_HappyFlow() {
		ChangePasswordDto changePasswordDto = CustomerMockData.getChangePasswordDto();
		Customer customerData = CustomerMockData.getEncryptedPasswordCustomerData();
		Integer userId=1;
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo());
			when(customerDao.getLoginCustomer(userId)).thenReturn(customerData);
			doNothing().when(customerDao).updateCustomer(customerData);
			customerServiceImpl.changePassword(changePasswordDto);
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void changePassword_ErrorFlow() {
		try {
			ApplicationException applicationException= new ApplicationException(ErrorCodes.INVALID_DATA);
			ApplicationException applicationException2 = assertThrows(ApplicationException.class, ()->{
				customerServiceImpl.changePassword(null);
			});
			assertEquals(applicationException.toString(), applicationException2.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void changePassword_ErrorFlow2() {
		ChangePasswordDto changePasswordDto = CustomerMockData.getChangePasswordDto();
		changePasswordDto.setConfirmPassword("Axa@123");
		try {
			ApplicationException applicationException= new ApplicationException(ErrorCodes.PWD_MISSMATCH);
			ApplicationException applicationException2 = assertThrows(ApplicationException.class, ()->{
				customerServiceImpl.changePassword(changePasswordDto);
			});
			assertEquals(applicationException.toString(), applicationException2.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void changePassword_ErrorFlow3() {
		ChangePasswordDto changePasswordDto = CustomerMockData.getChangePasswordDto();
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo());
			when(customerDao.getLoginCustomer(null)).thenReturn(null);
			ApplicationException applicationException = new ApplicationException(ErrorCodes.INVALID_USER);
			ApplicationException applicationException2 = assertThrows(ApplicationException.class, () -> {
				customerServiceImpl.changePassword(changePasswordDto);
			});
			assertEquals(applicationException.toString(), applicationException2.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	@Test
	void changePassword_ErrorFlow4() {
		ChangePasswordDto changePasswordDto = CustomerMockData.getChangePasswordDto();
		Customer customerData = CustomerMockData.getCustomerData();
		Integer userId = 1;
		try {
			when(loggedInUserContextHolder.getLoggedInUser()).thenReturn(PurchaseOrderMockData.getUserInfo());
			when(customerDao.getLoginCustomer(userId)).thenReturn(customerData);
			ApplicationException applicationException = new ApplicationException(ErrorCodes.INVALID_OLD_PASSWORD);
			ApplicationException applicationException2 = assertThrows(ApplicationException.class, () -> {
				customerServiceImpl.changePassword(changePasswordDto);
			});
			assertEquals(applicationException.toString(), applicationException2.toString());
		} catch (Exception e) {
			Assertions.fail(e.toString());
		}
	}
	
	
}
