package com.digitalpaper.adapter.service;

import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.dto.FieldGroup;
import com.digitalpaper.transfer.object.dto.IConfigurable;


/**
 * The Interface AdapterService.
 */
public interface AdapterService {
	
	/**
	 * Builds the field values.
	 *
	 * @param data the data
	 * @param clss the clss
	 * @param instant the instant
	 * @throws ApplicationException the application exception
	 */
	public void buildFieldValues(FieldGroup data,Class<?> clss,IConfigurable instant) throws ApplicationException;
	
	/**
	 * Builds the field group.
	 *
	 * @param data the data
	 * @return the i configurable
	 * @throws ApplicationException the application exception
	 */
	public IConfigurable buildFieldGroup(FieldGroup data) throws ApplicationException;

}
