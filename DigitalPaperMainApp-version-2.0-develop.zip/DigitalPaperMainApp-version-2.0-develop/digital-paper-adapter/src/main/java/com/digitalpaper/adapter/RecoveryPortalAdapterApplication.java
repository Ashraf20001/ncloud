package com.digitalpaper.adapter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * The Class RecoveryPortalAdapterApplication.
 */
@SpringBootApplication
public class RecoveryPortalAdapterApplication {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		SpringApplication.run(RecoveryPortalAdapterApplication.class, args);
	}

}
