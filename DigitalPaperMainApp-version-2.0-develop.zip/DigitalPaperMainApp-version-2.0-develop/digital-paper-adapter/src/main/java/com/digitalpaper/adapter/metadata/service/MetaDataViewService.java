package com.digitalpaper.adapter.metadata.service;

/**
 * The Interface MetaDataViewService.
 */
public interface MetaDataViewService {

}
