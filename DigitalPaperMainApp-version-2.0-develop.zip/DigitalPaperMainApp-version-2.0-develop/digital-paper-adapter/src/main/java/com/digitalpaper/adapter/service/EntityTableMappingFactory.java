package com.digitalpaper.adapter.service;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.poi.ss.formula.functions.T;
import org.springframework.stereotype.Component;

import com.digitalpaper.transfer.object.entity.NotificationEvent;
import com.digitalpaper.transfer.object.entity.NotificationTemplate;


/**
 * A factory for creating EntityTableMapping objects.
 */
@Component
public class EntityTableMappingFactory {
	
	/**
	 * table entity mapping
	 */
	Map<String, Object> tableEntitMap = new HashMap<>();
	
	/**
	 * Entity table map.
	 */
	@PostConstruct
	void entityTableMap() {
		tableEntitMap.put("notification_event", NotificationEvent.class);
		tableEntitMap.put("notification_template", NotificationTemplate.class);
	}
	
	/**
	 * Gets the entity class by table name.
	 *
	 * @param tableName the table name
	 * @return the entity class by table name
	 */
	@SuppressWarnings("unchecked")
	public Class<T> getEntityClassByTableName(String tableName) {
		return (Class<T>)tableEntitMap.get(tableName);
	}

}
