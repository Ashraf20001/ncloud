/*
 * @author codeboard
 */
package com.digitalpaper.exception.core.codes;

/**
 * The Class ErrorCodes.
 */
public class ErrorCodes {

	/** The Constant BAD_REQUEST. */
	public static final ErrorId BAD_REQUEST = new ErrorId("E0029", "Bad Request");

	/**
	 * The invalid column name.
	 */
	public static final ErrorId INVALID_COLUMN_NAME = new ErrorId("E0003", "Invalid column name to filter..!");

	/**
	 * The invalid data.
	 */
	public static final ErrorId INVALID_DATA = new ErrorId("E0002",
			"Data type not valid. Please provide data with valid data type..!");

	/**
	 * The invalid method name.
	 */
	public static final ErrorId INVALID_METHOD_NAME = new ErrorId("E0004", "Invalid Method name..!");

	/** The Constant UN_AUthorized. */
	public static final ErrorId UN_AUthorized = new ErrorId("E0005", "Invalid user name..!");
	
	/** The Constant FORGETPWDLIMIT. */
	public static final ErrorId FORGETPWDLIMIT=new ErrorId("E0006","Cannot send more than 3 emails per day." );
	
	/** The Constant INVALIDEMAIL. */
	public static final ErrorId INVALIDEMAIL=new ErrorId("E0007","Email is not registered") ;
	
	/** The Constant PWDFAILED. */
	public static final ErrorId PWDFAILED=new ErrorId("E0008","ResetPassword is failed ") ;
	
	/** The Constant USERNAME_EXIST. */
	public static final ErrorId USERNAME_EXIST=new ErrorId("E0009","Username already  exist ") ;
	
	/** The Constant SHORTNAME_EXIST. */
	public static final ErrorId SHORTNAME_EXIST=new ErrorId("E0014","ShortName already  exist ") ;
	
	/** The Constant EMAIL_EXIST. */
	public static final ErrorId EMAIL_EXIST=new ErrorId("E0010","Email is already  exist ") ;
	
	/** The Constant BAD_CREDINTIAL. */
	public static final ErrorId BAD_CREDINTIAL=new ErrorId("E0011","Invalid Username & Password") ;
	
	/** The Constant PWD_MISSMATCH. */
	public static final ErrorId PWD_MISSMATCH=new ErrorId("E0012","new password is not matched with confirm password ") ;
	
	/** The Constant LINK_EXPIRED. */
	public static final ErrorId LINK_EXPIRED=new ErrorId("E0013","Link is expired ") ;

	/**
	 * The internal error.
	 */
	public static final ErrorId INTERNAL_ERROR = new ErrorId("E0000", "Something went wrong. Please try again...");

	/** The Constant INVALID_REPORT_LOSS_DTO. */
	/*
	  *REPORT LOSS ERROR CODES
	 */
	public static final ErrorId INVALID_REPORT_LOSS_DTO = new ErrorId("E5006","Invalid data in report loss dto");
	
	/** The Constant INVALID_REPORT_LOSS_INSURED_INFO. */
	public static final ErrorId INVALID_REPORT_LOSS_INSURED_INFO = new ErrorId("E5007","Invalid data in report loss insured info");
	
	/** The Constant INVALID_REPORT_LOSS_INSURED_INFO_COMPANY. */
	public static final ErrorId INVALID_REPORT_LOSS_INSURED_INFO_COMPANY = new ErrorId("E5008","Invalid data in report loss -insured info -company");
	
	/** The Constant INVALID_REPORT_LOSS_INSURED_INFO_VEHICLE_DETAILS. */
	public static final ErrorId INVALID_REPORT_LOSS_INSURED_INFO_VEHICLE_DETAILS = new ErrorId("E5009","Invalid data in report loss -insured info -vehicle details");
	
	/** The Constant INVALID_REPORT_LOSS_THIRD_PARTY_INFO. */
	public static final ErrorId INVALID_REPORT_LOSS_THIRD_PARTY_INFO = new ErrorId("E5010","Invalid data in report loss -third party info");
	
	/** The Constant INVALID_REPORT_LOSS_THIRD_PARTY_INFO_COMPANY. */
	public static final ErrorId INVALID_REPORT_LOSS_THIRD_PARTY_INFO_COMPANY = new ErrorId("E5011","Invalid data in report loss -third party info -company");
	
	/** The Constant INVALID_REPORT_LOSS_THIRD_PARTY_INFO_VEHICLE_DETAILS. */
	public static final ErrorId INVALID_REPORT_LOSS_THIRD_PARTY_INFO_VEHICLE_DETAILS = new ErrorId("E5012","Invalid data in report loss -third party info -vehicle details");
	
	/** The Constant INVALID_REPORT_LOSS_GARAGE_INFO. */
	public static final ErrorId INVALID_REPORT_LOSS_GARAGE_INFO = new ErrorId("E5013","Invalid data in report loss -garage info");
	
	/** The Constant INVALID_REPORT_LOSS_GARAGE_INFO_CONTACT. */
	public static final ErrorId INVALID_REPORT_LOSS_GARAGE_INFO_CONTACT = new ErrorId("E5014","Invalid data in report loss -garage info -contact");
	
	/** The Constant INVALID_REPORT_LOSS_USER_COMMENT_INFO. */
	public static final ErrorId INVALID_REPORT_LOSS_USER_COMMENT_INFO = new ErrorId("E5015","Invalid page id or role id");
	
	/** The Constant INVALID_REPORT_LOSS_TOTAL_LOSS. */
	public static final ErrorId INVALID_REPORT_LOSS_TOTAL_LOSS = new ErrorId("E5061","Invalid data in total loss dto");

	/** The Constant INVALID_REPORT_LOSS_MANDATORY_FIELDS_GARAGE. */
	/*
	*Mandatory fields in report loss
	*/
	public static final ErrorId INVALID_REPORT_LOSS_MANDATORY_FIELDS_GARAGE = new ErrorId("E5016","Invalid garage name, GarageSurveyAllocationDate, GarageSurveyDueDate and GarageAddressLocation in insured info");
	
	/** The Constant INVALID_REPORT_LOSS_MANDATORY_FIELDS_THIRD_PARTY. */
	public static final ErrorId INVALID_REPORT_LOSS_MANDATORY_FIELDS_THIRD_PARTY = new ErrorId("E5017","Please Enter The Mandatory  Field Third Party Company Name");
	
	/** The Constant INVALID_REPORT_LOSS_MANDATORY_FIELDS_INSURED_INFO. */
	public static final ErrorId INVALID_REPORT_LOSS_MANDATORY_FIELDS_INSURED_INFO = new ErrorId("E5018","Invalid model, make or registraion no in insured info");
	
	/** The Constant INVALID_IDENTITY. */
	public static final ErrorId INVALID_IDENTITY = new ErrorId("E5019","Invalid identity");
	
	/** The Constant INVALID_CLAIM_ID. */
	public static final ErrorId INVALID_CLAIM_ID = new ErrorId("E5020","Invalid claim id");
	
	/** The Constant NUMBER_FORMAT_EXCEPTION. */
	public static final ErrorId NUMBER_FORMAT_EXCEPTION= new ErrorId("E5021","Invalid number");
	
	/** The Constant INVALID_PAGE_OR_ROLE_ID. */
	public static final ErrorId INVALID_PAGE_OR_ROLE_ID= new ErrorId("E5022","Invalid page or role id");
	
	/** The Constant INVALID_FIELD_DATA. */
	public static final ErrorId INVALID_FIELD_DATA= new ErrorId("E5023","Invalid field data");
	
	/** The Constant INVALID_SECTION_DATA. */
	public static final ErrorId INVALID_SECTION_DATA= new ErrorId("E5024","Invalid section data");
	
	/** The Constant INVALID_META_DATA. */
	public static final ErrorId INVALID_META_DATA= new ErrorId("E5025","Invalid meta data");
	
	/** The Constant INVALID_CLAIM_SUMMARY_DETAILS. */
	public static final ErrorId INVALID_CLAIM_SUMMARY_DETAILS= new ErrorId("E5026","Invalid claim summary details");
    
    /** The Constant UN_AUTHORIZED. */
    public static final ErrorId UN_AUTHORIZED = new ErrorId("E5027","Unauthorized");
    
    /** The Constant INVALID_REPORT_LOSS_LOSS_DETAILS. */
    public static final ErrorId INVALID_REPORT_LOSS_LOSS_DETAILS = new ErrorId("E5028","Invalid data in report loss -loss details");
    
    /** The Constant INVALID_REPORT_LOSS_POLICE_REPORT. */
    public static final ErrorId INVALID_REPORT_LOSS_POLICE_REPORT = new ErrorId("E5029","Invalid data in report loss -police report");
    
    /** The Constant INVALID_REPORT_LOSS_SURVEY_DETAILS. */
    public static final ErrorId INVALID_REPORT_LOSS_SURVEY_DETAILS = new ErrorId("E5030","Invalid data in report loss -survey details");
    
    /** The Constant INVALID_REPORT_LOSS_SURVEY_REPORT. */
    public static final ErrorId INVALID_REPORT_LOSS_SURVEY_REPORT= new ErrorId("E5031","Invalid data in report loss -survey report");
    
    /** The Constant INVALID_REPORT_LOSS_RESERVE_REVIEW. */
    public static final ErrorId INVALID_REPORT_LOSS_RESERVE_REVIEW = new ErrorId("E5032","Invalid data in report loss -reserve review");
    
    /** The Constant INVALID_REPORT_LOSS_GARAGE_INVOICE. */
    public static final ErrorId INVALID_REPORT_LOSS_GARAGE_INVOICE = new ErrorId("E5033","Invalid data in report loss -garage invoice");
    
    /** The Constant INVALID_REPORT_LOSS_DEBIT_NOTE. */
    public static final ErrorId INVALID_REPORT_LOSS_DEBIT_NOTE = new ErrorId("E5034","Invalid data in report loss -debit note");
    
    /** The Constant INVALID_REPORT_LOSS_CREDIT_NOTE. */
    public static final ErrorId INVALID_REPORT_LOSS_CREDIT_NOTE = new ErrorId("E5035","Invalid data in report loss -credit note");
    
    /** The Constant INVALID_REPORT_LOSS_RECOVERY_DETAILS. */
    public static final ErrorId INVALID_REPORT_LOSS_RECOVERY_DETAILS = new ErrorId("E5036","Invalid data in report loss -recovery details");
    
    /** The Constant INVALID_FILE. */
    public static final ErrorId INVALID_FILE = new ErrorId("E5037","Invalid file");
    
    /** The Constant INVALID_COMPANY. */
    public static final ErrorId INVALID_COMPANY = new ErrorId("E5039","Invalid Company");


/** The Constant SF_LOSS_DETAILS. */
    public static final ErrorId SF_LOSS_DETAILS = new ErrorId("E5039","Mandatory Details Yet to be Filled Under Loss Details");
    
    /** The Constant SF_CLAIM_NUMBER. */
    public static final ErrorId SF_CLAIM_NUMBER = new ErrorId("E5040","Mandatory Details Yet to Fill Under Claim Number");
    
    /** The Constant SF_REGISTRATION_NUMBER. */
    public static final ErrorId SF_REGISTRATION_NUMBER = new ErrorId("E5041","Mandatory Details Yet to Fill Under Registration Number");
    
    /** The Constant SF_TP_COMPANYNAME. */
    public static final ErrorId SF_TP_COMPANYNAME = new ErrorId("E5042","Mandatory Details Yet to Fill Under \"TP CompanyName");
    
    /** The Constant SF_MODEL. */
    public static final ErrorId SF_MODEL = new ErrorId("E5043","Mandatory Details Yet to Fill Under Model");
    
    /** The Constant SF_MAKE. */
    public static final ErrorId SF_MAKE = new ErrorId("E5044","Mandatory Details Yet to Fill Under Make");
    
    /** The Constant SF_POLICY_ID. */
    public static final ErrorId SF_POLICY_ID = new ErrorId("E5045","Mandatory Details Yet to Fill Under PolicyID");
    
    /** The Constant SF_TP_INSURANCE_CLAIM_NO. */
    public static final ErrorId SF_TP_INSURANCE_CLAIM_NO = new ErrorId("E5046","TP Claim Number Yet to be Filled");
    
    /** The Constant SF_POLICY_REPORT. */
    public static final ErrorId SF_POLICY_REPORT = new ErrorId("E5047","Police Report Yet to be Uploaded");
    
    /** The Constant SF_GARAGE_NAME. */
    public static final ErrorId SF_GARAGE_NAME = new ErrorId("E5048","Mandatory Details Yet to Fill Under Garage Name");
    
    /** The Constant SF_GARAGE_LOCATION. */
    public static final ErrorId SF_GARAGE_LOCATION = new ErrorId("E5049","Mandatory Details Yet to Fill Under Garage Location");
    
    /** The Constant SF_SURVEY_DUE_DATE. */
    public static final ErrorId SF_SURVEY_DUE_DATE = new ErrorId("E5050","Mandatory Details Yet to Fill Under \"Survey Due Date\"");
    
    /** The Constant SF_SURVEY_ALLOCATION_DATE. */
    public static final ErrorId SF_SURVEY_ALLOCATION_DATE = new ErrorId("E5051","Mandatory Details Yet to Fill Under Survey Allocation Date");
    
    /** The Constant SF_SURVEY_REPORT. */
    public static final ErrorId SF_SURVEY_REPORT = new ErrorId("E5052","Survey Report Yet to be Uploaded");
    
    /** The Constant SF_SURVEY_AMOUNT. */
    public static final ErrorId SF_SURVEY_AMOUNT = new ErrorId("E5053","Expenses Yet to be Filled");
    
    /** The Constant SF_LABOUR_COST. */
    public static final ErrorId SF_LABOUR_COST = new ErrorId("E5054","Mandatory Details Yet to Fill Under Labour Cost");
    
    /** The Constant SF_SPARE_PARTS. */
    public static final ErrorId SF_SPARE_PARTS = new ErrorId("E5055","Mandatory Details Yet to Fill Under Spare parts Amount");
    
    /** The Constant SF_CREDIT_NOTE. */
    public static final ErrorId SF_CREDIT_NOTE = new ErrorId("E5056","Mandatory Details Yet to Fill Under Credit Note");
    
    /** The Constant SF_DEBIT_NOTE. */
    public static final ErrorId SF_DEBIT_NOTE = new ErrorId("E5057","Mandatory Details Yet to Fill Under Debit Note");
    
    /** The Constant SF_GARAGE_REPORT. */
    public static final ErrorId SF_GARAGE_REPORT = new ErrorId("E5058"," Garage Invoice Yet to be Uploaded");
    
    /** The Constant SF_INSURANCE_COMPANY_NAME. */
    public static final ErrorId SF_INSURANCE_COMPANY_NAME = new ErrorId("E5059","Mandatory Details Yet to Fill Under Insurance Company Name");
    
    /** The Constant SF_POLICE_REPORT. */
    public static final ErrorId SF_POLICE_REPORT = new ErrorId("E5060","Police Report Yet to be Uploaded");
    
    /** The Constant SF_GARAGE_SURVEY_DTLS. */
    public static final ErrorId SF_GARAGE_SURVEY_DTLS = new ErrorId("E7113","Garage Details and Survey Details are Yet to be Filled");



    /** The Constant REPORT_GENERATION. */
    /*
     * Notification
     */
    public static final ErrorId REPORT_GENERATION = new ErrorId("E5061","Error occured during generation of report");
    
    /** The Constant ALREADY_WORKING. */
    public static final ErrorId ALREADY_WORKING = new ErrorId("E5062","Someone is already working on this claim");
    
    /** The Constant INVALID_ROLE. */
    public static final ErrorId INVALID_ROLE = new ErrorId("E5063","User not mapped to any role, Please contact the Admin");
    
    /** The Constant INVALID_TEMPLATE. */
    public static final ErrorId INVALID_TEMPLATE = new ErrorId("E5064","Template is not available for the given Notification Event");
    
    /** The Constant INVALID_EVENT. */
    public static final ErrorId INVALID_EVENT = new ErrorId("E5065","Notification Event is not available for the given Status");
    
    /** The Constant UNMAPPED_USER. */
    public static final ErrorId UNMAPPED_USER = new ErrorId("E5066","User not yet mapped to an Insurance Company");
    
    /** The Constant INVALID_USER. */
    public static final ErrorId INVALID_USER = new ErrorId("E5067","User not found!!");
    
    /** The Constant INVALID_LOGGED_IN_USER. */
    public static final ErrorId INVALID_LOGGED_IN_USER = new ErrorId("E5068","User is not related to the Claim");

    /** The Constant SF_TOTALLOSS_AMT_1. */
    public static final ErrorId SF_TOTALLOSS_AMT_1 = new ErrorId("E5069","Please Enter the Mandatory Field-Total Loss Amount 1");
    
    /** The Constant SF_ADJUSTERNAME_1. */
    public static final ErrorId SF_ADJUSTERNAME_1 = new ErrorId("E5070","Please Enter the Mandatory Field-Adjuster Name 1");
    
    /** The Constant SF_SURVEY_DATE_1. */
    public static final ErrorId SF_SURVEY_DATE_1 = new ErrorId("E5071","Please Enter the Mandatory Field-Survey Date 1");
    
    /** The Constant COMPANY_IS_NOT_MAPPED_THE_USER. */
    public static final ErrorId COMPANY_IS_NOT_MAPPED_THE_USER = new ErrorId("E5094","No Company is mapped to User");
    
    /** The Constant SF_COMMENTS. */
    public static final ErrorId SF_COMMENTS = new ErrorId("E5072","Comments Required for Action.");
    
    /** The Constant SF_COMMENTS_DETAILS. */
    public static final ErrorId SF_COMMENTS_DETAILS = new ErrorId("E5112","Enter Comments for the Details Provided");
    
    /** The Constant SF_COMMENTS_NEED_INFO. */
    public static final ErrorId SF_COMMENTS_NEED_INFO = new ErrorId("E5113","Enter Comments for Need Info");
    
    /** The Constant SF_COMMENTS_DISPUTE. */
    public static final ErrorId SF_COMMENTS_DISPUTE = new ErrorId("E7117","Enter Comments for Disputing");
    
    /** The Constant SF_COMMENTS_REJECTION. */
    public static final ErrorId SF_COMMENTS_REJECTION = new ErrorId("E7118","Enter Comments for Rejection");

    /** The Constant INVALID_USER_ROLE_DATA. */
    public static final ErrorId INVALID_USER_ROLE_DATA =new ErrorId("E5095","Invalid user role data");

    /** The Constant INVALID_FIELD_IDENTITY. */
    public static final ErrorId INVALID_FIELD_IDENTITY = new ErrorId("E5073", "Invalid Field Identity");

	/** The Constant INVALID_STAGE_DETAILS. */
	public static final ErrorId INVALID_STAGE_DETAILS = new ErrorId("E5074", "Invalid Stage Details");

	/** The Constant INVALID_FIELD_CONFIG_DATA. */
	public static final ErrorId INVALID_FIELD_CONFIG_DATA = new ErrorId("E5075", "Invalid Field Configuration Data");

	/** The Constant INVALID_ACTION_FOR_CORE_DATA. */
	public static final ErrorId INVALID_ACTION_FOR_CORE_DATA = new ErrorId("E5076", "Cannot Delete Field Marked as CoreData");

	/** The Constant INVALID_DROP_DOWN. */
	public static final ErrorId INVALID_DROP_DOWN = new ErrorId("E5077", "Invalid DropdownList Identity");

	/** The Constant INVALID_PAGE. */
	public static final ErrorId INVALID_PAGE = new ErrorId("E5078", "Invalid Page Identity");

	/** The Constant INVALID_COMPANY_DTO. */
	public static final ErrorId INVALID_COMPANY_DTO = new ErrorId("E5079","Invalid data in company dto");

	/** The Constant INVALID_PAGE_ID. */
	public static final ErrorId INVALID_PAGE_ID = new ErrorId("E5081", "Invalid Page Id");
	
	/** The Constant INVALID_ACTION. */
	public static final ErrorId INVALID_ACTION= new ErrorId("E5082", "Invalid Action");
	
	/** The Constant SEQUENCE_NUMBER. */
	public static final ErrorId SEQUENCE_NUMBER= new ErrorId("E5100", "Invalid Sequence Number");

	/*
	 * ApprovalLimit and ApprovalLevel
	 */

	/** The Constant INVALID_APPROVAL_LIMIT. */
	public static final ErrorId INVALID_APPROVAL_LIMIT = new ErrorId("E5099", "Invalid Approval Limit");
	
	/** The Constant INVALID_FIELD_ENTRY. */
	public static final ErrorId INVALID_FIELD_ENTRY = new ErrorId("E5105", "Invalid Entry of Fields");



    /** The Constant INVALID_USER_DATA. */
    public static final ErrorId INVALID_USER_DATA =new ErrorId("E5080","Invalid User data");
    
    /** The Constant INVALID_PAGE_ID_OR_USER_ID. */
    public static final ErrorId INVALID_PAGE_ID_OR_USER_ID =new ErrorId("E5097","Invalid User Id or Page Id");
	/** The Constant APL_TOTALLOSS_ESTIMATED. */
	public static final ErrorId APL_TOTALLOSS_ESTIMATED = new ErrorId("E5103", "Approved Limit Execeded for totalLossEstimated");
	
	/** The Constant APL_CLAIM_AMOUNT. */
	public static final ErrorId APL_CLAIM_AMOUNT = new ErrorId("E5083", "Approved Limit Execeded for claimamount");
	
	/** The Constant APL_TP_CLAIM_AMOUNT. */
	public static final ErrorId APL_TP_CLAIM_AMOUNT = new ErrorId("E5104", "Approved Limit Execeded for tpclaimamount");
	
	/** The Constant APL_SUM_INSURED. */
	public static final ErrorId APL_SUM_INSURED= new ErrorId("E5102", "Approved Limit Execeded for Suminsured");
	
	/** The Constant INVALID_PHONE_NO. */
	public static final ErrorId INVALID_PHONE_NO = new ErrorId("E5096", "Invalid Phone number");
	
	/** The Constant ROLE_ALREADY_SAVED. */
	public static final ErrorId ROLE_ALREADY_SAVED = new ErrorId("E5101", "Role already saved");
    
    /** The Constant INVALID_FILE_PATH. */
    public static final ErrorId INVALID_FILE_PATH = new ErrorId("E5106", "Invalid File Path");
    
    /** The Constant INVALID_UPLOAD_ID. */
    public static final ErrorId INVALID_UPLOAD_ID = new ErrorId("E5084", "Invalid Upload ID");


	/** The Constant ERR_TOTALCALIMAMOUNT_MIN. */
	public static final ErrorId ERR_TOTALCALIMAMOUNT_MIN = new ErrorId("E5107", "Total Claim Amount is less than your approval limit. This has to be approved by your Supervisor");
	
	/** The Constant ERR_TOTALCALIMAMOUNT_MAX. */
	public static final ErrorId ERR_TOTALCALIMAMOUNT_MAX = new ErrorId("E5108", "Total Claim  Amount is more than your approval limit. This has to be approved by your Supervisor");
	
	/** The Constant ERR_CLAIMANOUNT_MIN. */
	public static final ErrorId ERR_CLAIMANOUNT_MIN = new ErrorId("E5085", " Claim Amount is less than your approval limit. This has to be approved by your Supervisor");
	
	/** The Constant ERR_CLAIMANOUNT_MAX. */
	public static final ErrorId ERR_CLAIMANOUNT_MAX = new ErrorId("E5086", " Claim Amount is more than your approval limit. This has to be approved by your Supervisor");
	
	/** The Constant ERR_SUMINSURED_MIN. */
	public static final ErrorId ERR_SUMINSURED_MIN = new ErrorId("E5087", "Sum Insured Amount is less than your approval limit. This has to be approved by your Supervisor");
	
	/** The Constant ERR_SUMINSURED_MAX. */
	public static final ErrorId ERR_SUMINSURED_MAX = new ErrorId("E5088", "Sum Insured Amount is more than your approval limit. This has to be approved by your Supervisor");
	
	/** The Constant ERR_RESERVEAMOUNT_MIN. */
	public static final ErrorId ERR_RESERVEAMOUNT_MIN = new ErrorId("E5089", "Reserve Amount is less than your approval limit. This has to be approved by your Supervisor");
	
	/** The Constant ERR_RESERVEAMOUNT_MAX. */
	public static final ErrorId ERR_RESERVEAMOUNT_MAX = new ErrorId("E5090", "Reserve Amount is more than your approval limit. This has to be approved by your Supervisor");
	
	/** The Constant ERR_TOTALLOSSESTIMATED_MIN. */
	public static final ErrorId ERR_TOTALLOSSESTIMATED_MIN = new ErrorId("E5091", "TotalLoss Estimated Amount is less than your approval limit. This has to be approved by your Supervisor");
	
	/** The Constant ERR_TOTALLOSSESTIMATED_MAX. */
	public static final ErrorId ERR_TOTALLOSSESTIMATED_MAX = new ErrorId("E5092", "TotalLoss Estimated Amount is more than your approval limit. This has to be approved by your Supervisor");

	/** The Constant AMOUNT_EXCEDED. */
	public static final ErrorId AMOUNT_EXCEDED = new ErrorId("E5093", "Entered Amount Exceeded The Limit(1000000)");

	/** The Constant INVALID_STORAGE_REFERENCE_ID. */
	public static final ErrorId INVALID_STORAGE_REFERENCE_ID = new ErrorId("E6101", "Invalid Reference Id");

    /** The Constant SF_POLICE_REPORT_NUMBER. */
    public static final ErrorId SF_POLICE_REPORT_NUMBER = new ErrorId("E6102","Please Enter the  Mandatory Field  \"Police Report Number\"");

	/** The Constant INVALID_DROPDOWNLIST_ID. */
	public static final ErrorId INVALID_DROPDOWNLIST_ID = new ErrorId("E7101", "Invalid DropdownList Id!");

	/** The Constant INVALID_REPORT_DATA. */
	public static final ErrorId INVALID_REPORT_DATA = new ErrorId("E7102", "Invalid Data to Generate Report");
    
    /** The Constant INVALID_USER_NAME. */
    public static final ErrorId INVALID_USER_NAME = new ErrorId("E7103", "Invalid User Name");
    
    /** The Constant INVALID_PASSWORD. */
    public static final ErrorId INVALID_PASSWORD = new ErrorId("E7104", "Please Enter The Password");
    
    /** The Constant REASON_FOR_REPORT_LOSS. */
    public static final ErrorId REASON_FOR_REPORT_LOSS = new ErrorId("E7105", "Please Enter the Mandatory Field-Reason for Total loss ");
    
    /** The Constant INVALID_ROLE_NAME. */
    public static final ErrorId INVALID_ROLE_NAME = new ErrorId("E7106", "Role Name Already Exist!");
	
	/** The Constant INVALID_USER_TYPE. */
	public static final ErrorId INVALID_USER_TYPE = new ErrorId("E7107", "Invalid User Type");
    
    /** The Constant INVALID_USER_ROLE_NAME. */
    public static final ErrorId INVALID_USER_ROLE_NAME = new ErrorId("E7108", "Invalid Role Name");
    
    /** The Constant INVALID_EMAIL_ID. */
    public static final ErrorId INVALID_EMAIL_ID = new ErrorId("E7109", "Email is not registered");
   
   /** The Constant INVALID_COMPANY_ID. */
   public static final ErrorId INVALID_COMPANY_ID = new ErrorId("E7110", "Invalid Company Id");
   
   /** The Constant SHORTID_EXISTS. */
   public static final ErrorId SHORTID_EXISTS = new ErrorId("E5110","Short Id Already Exist");
   
   /** The Constant USERID_EXISTS. */
   public static final ErrorId USERID_EXISTS = new ErrorId("E5111","User Id Already Exist");
   
   /** The Constant SHORTID_USERID_EXISTS. */
   public static final ErrorId SHORTID_USERID_EXISTS = new ErrorId("E7111","Short Id & User Id Already Exist");
   
   /** The Constant NO_LOGO_FOUND. */
   public static final ErrorId NO_LOGO_FOUND = new ErrorId("E7112", "No Logo Available");
   
   /** The Constant INVALID_MAX_VALUE. */
   public static final ErrorId INVALID_MAX_VALUE = new ErrorId("E7113", "Please Enter the Maximum Amount Greater than the Minimum Amount");
   
   /** The Constant MAPPING_TABLE_NOT_FOUND. */
   public static final ErrorId MAPPING_TABLE_NOT_FOUND = new ErrorId("E7114", "Bulk Import Mapping table not found");
   
   /** The Constant CLAIM_ALREADY_EXIST. */
   public static final ErrorId CLAIM_ALREADY_EXIST = new ErrorId("E7115", "Claim already exist");
   
   /** The Constant CLAIM_NOT_EXIST. */
   public static final ErrorId CLAIM_NOT_EXIST = new ErrorId("E7116", "Claim Not exist");
   
   /** The Constant INSURANCE_COMPANY_NOT_EXIST. */
   public static final ErrorId INSURANCE_COMPANY_NOT_EXIST = new ErrorId("E5114", "Insurance company Not exist");
   
   /** The Constant TP_COMPANY_NOT_EXIST. */
   public static final ErrorId TP_COMPANY_NOT_EXIST = new ErrorId("E5115", "Third party company Not exist");

   /** The Constant INVALID_STOCKID. */
   public static final ErrorId INVALID_STOCKID = new ErrorId("E7120", "Invalid stock id");

   /** The Constant UPDATE_FAILED. */
   public static final ErrorId UPDATE_FAILED = new ErrorId("E5118", "Update Failed");

   /** The Constant INVALID_REQUEST. */
   public static final ErrorId INVALID_REQUEST = new ErrorId("E7122", "Invalid Request");

   /** The Constant INSUFFICIENT_STOCK. */
   public static final ErrorId INSUFFICIENT_STOCK = new ErrorId("E5120", "Insufficient Stock");

   /** The Constant INVALID_REALLOCATION_POOL. */
   public static final ErrorId INVALID_REALLOCATION_POOL = new ErrorId("E5123", "Invalid Reallocation Data");

   /** The Constant INVALID_STOCK. */
   public static final ErrorId INVALID_STOCK = new ErrorId("E5127", "Invalid stock");

   /** The Constant INVALID_STOCK_POOL. */
   public static final ErrorId INVALID_STOCK_POOL = new ErrorId("E5129", "Invalid Stock pool");

   /** The Constant NO_STOCK_POOL. */
   public static final ErrorId NO_STOCK_POOL = new ErrorId("E5131", "No Allocation Pool Found");
   
   /** The Constant INVALID_SELECTION. */
   public static final ErrorId INVALID_SELECTION = new ErrorId("E5121", "No Companies were selected");
   
   /** The Constant INVALID_POLCIY_NUMBER. */
   public static final ErrorId INVALID_POLCIY_NUMBER = new ErrorId("E5125", "Active Paper Exists for given Policy Number with Digital Paper ID : DIGITAL_PAPER");
   
   /** The Constant INVALID_CHASSIS_NUMBER. */
   public static final ErrorId INVALID_CHASSIS_NUMBER = new ErrorId("E7125", "Active Paper Exists for given Chassis Number with Digital Paper ID : DIGITAL_PAPER");


   /** The Constant MAXIMUM_LENGTH_VALIDATION. */
   public static final ErrorId MAXIMUM_LENGTH_VALIDATION = new ErrorId("E7126", "Exceeded The Maximum Length For The Field : FIELD_NAME");
   
   /** The Constant MANDATORY_FIELDS. */
   public static final ErrorId MANDATORY_FIELDS = new ErrorId("E5132", "Mandatory Details Yet To Be Filled");
   
   /** The Constant MAX_LENGTH. */
   public static final ErrorId MAX_LENGTH = new ErrorId("E7128", "Exceeded the Maximum length for the field : FIELD_NAME");
   
   /** The Constant MIN_LENGTH. */
   public static final ErrorId MIN_LENGTH = new ErrorId("E5137", "Minimum length should be: MIN_LENGTH for ALIAS_NAME");
   
   /** The Constant INVALID_FORMAT. */
   public static final ErrorId INVALID_FORMAT = new ErrorId("E5138", "Invalid FIELD_FORMAT");
   
   /** The Constant INVALID_REGISTRATION_NUMBER. */
   public static final ErrorId INVALID_REGISTRATION_NUMBER = new ErrorId("E7124", "Active Paper Exists for given Register Number with Digital Paper ID : DIGITAL_PAPER");


   /** The Constant EMPTY_VALUE. */
   public static final ErrorId EMPTY_VALUE = new ErrorId("E5133", "value is Empty");
   
   /** The Constant ERR_MIN_LENGTH. */
   public static final ErrorId ERR_MIN_LENGTH = new ErrorId("E5136", "Min length should be:");
   
   /** The Constant ERR_MAX_LENGTH. */
   public static final ErrorId ERR_MAX_LENGTH = new ErrorId("E5140", "Max length should be:");
   
   /** The Constant ERR_POLICY_EXIST. */
   public static final ErrorId ERR_POLICY_EXIST = new ErrorId("E5144", "Policy number already exist");
   
   /** The Constant ERR_INTEGER_TYPE. */
   public static final ErrorId ERR_INTEGER_TYPE = new ErrorId("E5147", "Value should be Number");
   
   /** The Constant ERR_DATE_TYPE. */
   public static final ErrorId ERR_DATE_TYPE = new ErrorId("E7132", "Invalid Date");
   
   /** The Constant ERR_SAVING. */
   public static final ErrorId ERR_SAVING = new ErrorId("E5150", "Error saving paper details");

   /** The Constant INVALID_BULK_UPLOAD_ID. */
   public static final ErrorId INVALID_BULK_UPLOAD_ID = new ErrorId("E5139","Invalid Bulk Id");
   
   /** The Constant INVALID_STATUS. */
   public static final ErrorId INVALID_STATUS = new ErrorId("E5142", "Invalid Status");


   /** The Constant INVALID_FILE_SELECTION. */
   public static final ErrorId INVALID_FILE_SELECTION = new ErrorId("E5146", "Upload the necessary documents to proceed payment");
   
   /** The Constant INVALID_ID. */
   public static final ErrorId INVALID_ID = new ErrorId("E5148","Invalid id");

   /** The Constant INVALID_SYSTEM_PROPERTY. */
   public static final ErrorId INVALID_SYSTEM_PROPERTY = new ErrorId("E7134","Invalid System Property Value");
   
   /** The Constant EMAIL_NAME_NOT_MATCH. */
   public static final ErrorId EMAIL_NAME_NOT_MATCH = new ErrorId("E7133", " Paper Was Not Generated This Email Id And Name");
   
   /** The Constant SAVE_FAILED. */
   public static final ErrorId SAVE_FAILED = new ErrorId("E7135", "Digital paper not saved");
   
   /** The Constant INVALID_OLD_PASSWORD. */
   public static final ErrorId INVALID_OLD_PASSWORD = new ErrorId("E5126", "InCorrect Old Password");
   
   /** The Constant NO_DATA_FOUND. */
   public static final ErrorId NO_DATA_FOUND = new ErrorId("E5151", "No Data Found");
   
   /** The Constant NO_COMPANY_DATA_FOUND. */
   public static final ErrorId NO_COMPANY_DATA_FOUND = new ErrorId("E5152","No Companies were found");
   
   /** The Constant INVALID_STOCK_COUNT. */
   public static final ErrorId INVALID_STOCK_COUNT = new ErrorId("E7139", "Invalid stock Count");
   
   /** The Constant INACTIVE_STOCK_POOL. */
   public static final ErrorId INACTIVE_STOCK_POOL = new ErrorId("E7140", "Stock pool is inactive");
   
   /** The Constant INVALID_CUSTOMER. */
   public static final ErrorId INVALID_CUSTOMER = new ErrorId("E7141", "No customer is found");
   
   /** The Constant INVALID_PURCHASE_ID. */
   public static final ErrorId INVALID_PURCHASE_ID = new ErrorId("E7142", "Invalid Purchase Id");
   
   /** The Constant OLD_NEW_PASSWORD_ERR. */
   public static final ErrorId OLD_NEW_PASSWORD_ERR = new ErrorId("E5143", "New password should not be same as Old Password");
   
   /** The Constant UPDATE_MANDATORY_FIELDS. */
   public static final ErrorId UPDATE_MANDATORY_FIELDS = new ErrorId("E5153", "Update the mandatory * fields");

   /** The Constant INVALID_ALLOCATION_USER_TYPE. */
   public static final ErrorId INVALID_ALLOCATION_USER_TYPE = new ErrorId("E7144", "User Type Doesnot Exist");

   /** The Constant PAPER_GENERATION_FAILED. */
   public static final ErrorId PAPER_GENERATION_FAILED = new ErrorId("E7145", "DIgital paper generation failed");


   /** The Constant EXP_DATE_GRTR_EFFECTIVE_DATE. */
   public static final ErrorId EXP_DATE_GRTR_EFFECTIVE_DATE = new ErrorId("E7146", "Expiry date should be greater than Effective From date");
   
   /** The Constant POLICY_NUMBER_NOT_VALID. */
   public static final ErrorId POLICY_NUMBER_NOT_VALID = new ErrorId("E7147", "Invalid Policy Number");
   
   /** The Constant PURCHASE_ALREADY_DONE. */
   public static final ErrorId PURCHASE_ALREADY_DONE = new ErrorId("E7148", "Purchase already completed");
   
   /** The Constant ALLOCATE_STOCK_FAILED. */
   public static final ErrorId ALLOCATE_STOCK_FAILED = new ErrorId("E7153", "Stock allocation failed");
   
   /** The Constant NO_USER_ASSOCIATED_POOL. */
   public static final ErrorId NO_USER_ASSOCIATED_POOL= new ErrorId("E7152","There is No User Associated with POOL");
   
   /** The Constant COMPLAINTS_ALREADY_REGISTERED. */
   public static final ErrorId COMPLAINTS_ALREADY_REGISTERED = new ErrorId("E7154","Complaint already registered for Registration Number");

   /** The Constant UNKNOWN_PAPER. */
   public static final ErrorId UNKNOWN_PAPER= new ErrorId("E7156","Entered Vehicle Number Is Not Valid");

   /** The Constant PAPER_NOT_FOUND. */
   public static final ErrorId PAPER_NOT_FOUND = new ErrorId("E7157","Digital Paper Image Is Not Found");
   
   /** The Constant INVALID_INPUT. */
   public static final ErrorId INVALID_INPUT = new ErrorId("E7158","Invalid Input Data");
   
   /** The Constant INVALID_MASTER_DATA. */
   public static final ErrorId INVALID_MASTER_DATA= new ErrorId("E7167","Master Data Not Found.");
   
   


    /**
     * Instantiates a new error codes.
     */
    private ErrorCodes() {
	}
}
