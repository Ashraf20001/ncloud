package com.digitalpaper.transfer.object.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The Class ComplaintSequenceGenerator.
 */
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Table(name = "complaintid_sequence_generator")
public class ComplaintSequenceGenerator {

	
	/** The complaint id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="complaint_id")
    private int complaintId;
}
