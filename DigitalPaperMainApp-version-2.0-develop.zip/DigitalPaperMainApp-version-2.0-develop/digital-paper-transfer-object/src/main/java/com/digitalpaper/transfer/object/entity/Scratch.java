package com.digitalpaper.transfer.object.entity; 
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor; 

/**
 * The Class Scratch.
 */
@Data
@Entity
@Table(name = "dp_scratch")
@AllArgsConstructor
@NoArgsConstructor
public class Scratch { 
	
	/** The scratch id. */
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name = "scratch_id") 
	private int scratchId; 
	
	/** The policy holder. */
	@Column(name = "policy_holder") 
	private String policyHolder;
	
	/** The pd policy number. */
	@Column(name = "policy_no")
	private String pdPolicyNumber;
	
	/** The vd registration number. */
	@Column(name = "registration_no") 
	private String vdRegistrationNumber;
	
	/** The vd chassis. */
	@Column(name = "chassis_no")
	private String vdChassis;
	
	/** The pd insured name. */
	@Column(name = "insurer_name") 
	private String pdInsuredName; 
	
	/** The vd usage. */
	@Column(name = "[usage]") 
	private String vdUsage;
	
	/** The vd licensed to carry. */
	@Column(name = "license_to_carry")
	private String vdLicensedToCarry; 
	
	/** The vd make. */
	@Column(name = "make_type")
	private String vdMake;
	
	/** The company id. */
	@Column(name = "company_id")
	private String companyId; 
	
	/** The status. */
	@Column(name = "status") 
	private Boolean status; 
	
	/** The identity. */
	@Column(name = "identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private String identity;
	
	/** The is deleted. */
	@Column(name = "is_deleted") 
	private Boolean isDeleted = false; 
	
	/** The created date. */
	@Column(name = "created_date") 
	private LocalDateTime createdDate;
	
	/** The created by. */
	@Column(name = "created_by") 
	private Integer createdBy; 
	
	/** The modified date. */
	@Column(name = "modified_date")
	private LocalDateTime modifiedDate; 
	
	/** The modified by. */
	@Column(name = "modified_by") 
	private Integer modifiedBy;
	
	/** The bulk upload id. */
	@Column(name = "bulk_upload_id")
	private Integer bulkUploadId;
	
	/** The vd model. */
	@Column(name = "model_type")
	private String vdModel; 
	
	/** The pd phone number. */
	@Column(name = "phone_number") 
	private String pdPhoneNumber;
	
	/** The pd email id. */
	@Column(name = "email_id")
	private String pdEmailId; 
	
	/** The pd effective from. */
	@Column(name = "effective_from")
	private String pdEffectiveFrom;
	
	/** The pd expire date. */
	@Column(name = "expiry_date") 
	private String pdExpireDate;
	
	/** The bulk import error table. */
	@OneToMany(mappedBy = "scratchId",fetch = FetchType.EAGER)
	private List<BulkImportErrorTable> bulkImportErrorTable;
	
}