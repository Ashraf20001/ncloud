package com.digitalpaper.transfer.object.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class MetaDataViewDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class MetaDataViewDto {
	
	/** The page id. */
	private String pageId;
    
    /** The page name. */
    private String pageName;
    
    /** The is enabled. */
    private boolean isEnabled;
    
    /** The section list. */
    private List<SectionDto> sectionList;
}
