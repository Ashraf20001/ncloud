package com.digitalpaper.transfer.object.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class StockDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class StockDto {
	
	 /** The stock id. */
 	private Integer stockId;
	 
 	/** The stock count. */
 	private Integer stockCount;
	 
 	/** The used count. */
 	private Integer usedCount;
	 
 	/** The company id. */
 	private Integer companyId;
	 
 	/** The created date. */
 	private LocalDateTime createdDate;
	 
 	/** The identity. */
 	private String identity;
	 
 	/** The user type id. */
 	private Integer userTypeId;
	 
 	/** The user type name. */
 	private String userTypeName;
	 
 	/** The user type identity. */
 	private String userTypeIdentity;
	 
 	/** The is active. */
 	private Boolean isActive;
	 
 	/** The available count. */
 	private Integer availableCount;

}
