package com.digitalpaper.transfer.object.dto;

import lombok.Data;

/**
 * The Class ExternalApiDigitalPaperDto.
 */
@Data
public class ExternalApiDigitalPaperDto {
	
	/** The pd digital paper id. */
	private String pdDigitalPaperId;
	
	/** The pd policy number. */
	private String pdPolicyNumber;
	
	/** The pd insured name. */
	private String pdInsuredName;
	
	/** The pd phone number. */
	private String pdPhoneNumber;
	
	/** The pd email id. */
	private String pdEmailId;
	
	/** The pd effective from. */
	private String pdEffectiveFrom;
	
	/** The pd expire date. */
	private String pdExpireDate;
	
	/** The vd registration number. */
	private String vdRegistrationNumber;
	
	/** The vd chassis. */
	private String vdChassis;
	
	/** The vd licensed to carry. */
	private String vdLicensedToCarry;
	
	/** The vd make. */
	private String vdMake;
	
	/** The vd model. */
	private String vdModel;
	
	/** The vd usage. */
	private String vdUsage;
	
	/** The status. */
	private String status;
	
	/** The digital paper url. */
	private String digitalPaperUrl;
	
	/** The identity. */
	private String identity;
}
