package com.digitalpaper.transfer.object.enums;

/**
 * The Enum PaperDetailsStatusEnum.
 */
public enum PaperDetailsStatusEnum {
	
	/** The active. */
	ACTIVE(1, "Active"), /** The expired. */
 EXPIRED(2, "Expired"), /** The revoked. */
 REVOKED(3, "Revoked"), /** The rejected. */
 REJECTED(4, "Rejected");

	/**
	 * statusNameById
	 */
	private Integer statusNameById;
	
	/**
	 * statusIdByName
	 */
	private String statusIdByName;

	/**
	 * @param enumValue
	 * @return
	 */
	public static Integer getNameById(String enumValue) {
		for (PaperDetailsStatusEnum enums : PaperDetailsStatusEnum.values()) {
			if (enums.getStatusIdByName().equals(enumValue)) {
				return enums.getStatusNameById();
			}
		}
		return null;
	}

	/**
	 * @param enumId
	 * @return
	 */
	public static String getIdByName(Integer enumId) {
		for (PaperDetailsStatusEnum enums : PaperDetailsStatusEnum.values()) {
			if (enums.getStatusNameById().equals(enumId)) {
				return enums.getStatusIdByName();
			}
		}
		return null;
	}

	/**
	 * Gets the status name by id.
	 *
	 * @return the status name by id
	 */
	public Integer getStatusNameById() {
		return statusNameById;
	}

	/**
	 * Sets the status name by id.
	 *
	 * @param statusNameById the new status name by id
	 */
	public void setStatusNameById(Integer statusNameById) {
		this.statusNameById = statusNameById;
	}

	/**
	 * Gets the status id by name.
	 *
	 * @return the status id by name
	 */
	public String getStatusIdByName() {
		return statusIdByName;
	}

	/**
	 * Sets the status id by name.
	 *
	 * @param statusIdByName the new status id by name
	 */
	public void setStatusIdByName(String statusIdByName) {
		this.statusIdByName = statusIdByName;
	}

	/**
	 * Instantiates a new paper details status enum.
	 *
	 * @param statusNameById the status name by id
	 * @param statusIdByName the status id by name
	 */
	private PaperDetailsStatusEnum(Integer statusNameById, String statusIdByName) {
		this.statusNameById = statusNameById;
		this.statusIdByName = statusIdByName;
	}
	
}
