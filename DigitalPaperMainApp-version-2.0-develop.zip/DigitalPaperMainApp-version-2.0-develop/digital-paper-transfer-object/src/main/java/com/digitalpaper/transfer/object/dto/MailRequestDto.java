package com.digitalpaper.transfer.object.dto;

import java.io.File;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class MailRequestDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MailRequestDto {
	
	/** The name. */
	private String name;
	
	/** The to. */
	private String to;
	
	/** The from. */
	private String from;
	
	/** The subject. */
	private String subject;
	
	/** The file URL. */
	private File fileURL;
	
	/** The Attachment name. */
	private String AttachmentName;
	
	/** The company id. */
	private Integer companyId;
	
	/** The paper details dto. */
	private PaperDetailsDto paperDetailsDto;
	
	/** The model. */
	private Map<String, Object> model;
	
	/** The template name. */
	private String templateName;
}
