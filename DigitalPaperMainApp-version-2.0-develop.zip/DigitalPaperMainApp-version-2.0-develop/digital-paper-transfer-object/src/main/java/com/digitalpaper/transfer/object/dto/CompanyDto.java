package com.digitalpaper.transfer.object.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CompanyDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CompanyDto {
	
	/** The company id. */
	private int companyId;
	
	/** The name. */
	private String name;
	
	/** The short name. */
	private String shortName;
	
	/** The identity. */
	private String identity;
	
	/** The created date. */
	private Date createdDate;
	
	/** The created by. */
	private Integer createdBy;
	
	/** The modified date. */
	private Date modifiedDate;
	
	/** The modified by. */
	private Integer modifiedBy;
	
	/** The email. */
	private String email;
	
	/** The phone. */
	private String phone;
	
	/** The location. */
	private String location;
	
	/** The password. */
	private String password;
	
	/** The address. */
	private String address;
	
	/** The logo. */
	private String logo;
	
	/** The is deleted. */
	private Boolean isDeleted;
}
