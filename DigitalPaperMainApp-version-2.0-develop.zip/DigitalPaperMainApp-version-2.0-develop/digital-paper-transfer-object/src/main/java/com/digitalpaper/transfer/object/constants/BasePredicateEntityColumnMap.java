package com.digitalpaper.transfer.object.constants;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.transfer.object.entity.PaymentDetails;
import com.digitalpaper.transfer.object.entity.StockTransactionHistory;

/**
 * The Class BasePredicateEntityColumnMap.
 */
@Component
public class BasePredicateEntityColumnMap {
	
	/** The Constant basePredicateEntityColumnMap. */
	public static final Map<Class<?>,String> basePredicateEntityColumnMap = new HashMap<>();
	
	/**
	 * Sets the base predicate map.
	 */
	@PostConstruct
	public void setBasePredicateMap() {
		basePredicateEntityColumnMap.put(StockTransactionHistory.class, TableConstants.STOCK_POOL_ID);
		basePredicateEntityColumnMap.put(PaymentDetails.class, TableConstants.ORDER_ID);
	}
}
