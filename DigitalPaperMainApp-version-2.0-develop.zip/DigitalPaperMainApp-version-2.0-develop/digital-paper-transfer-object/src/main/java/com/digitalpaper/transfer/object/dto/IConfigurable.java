package com.digitalpaper.transfer.object.dto;

/**
 * The Interface IConfigurable.
 */
public interface IConfigurable {

}
