package com.digitalpaper.transfer.object.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ViewHistoryDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ViewHistoryDto {
	
	/** The order id. */
	private Integer orderId;
	
	/** The purchase id. */
	private String purchaseId;
	
	/** The company name. */
	private String companyName;
	
	/** The stock count. */
	private Integer stockCount;
	
	/** The transaction id. */
	private String transactionId;
	
	/** The purchase date. */
	private String purchaseDate;
	
	/** The payment method. */
	private String paymentMethod;
	
	/** The purchase amount. */
	private Double purchaseAmount;
	
	/** The payment status. */
	private String paymentStatus;
	
	/** The file mapping id. */
	private Integer fileMappingId;
	
	/** The order status. */
	private Integer orderStatus;
	
	/** The currency type. */
	private String currencyType;

}
