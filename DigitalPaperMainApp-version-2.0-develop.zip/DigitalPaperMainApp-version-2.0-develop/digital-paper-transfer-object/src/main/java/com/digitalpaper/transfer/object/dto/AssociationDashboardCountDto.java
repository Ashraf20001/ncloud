package com.digitalpaper.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AssociationDashboardCountDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AssociationDashboardCountDto {

	/** The status. */
	private int status;
	
	/** The count. */
	private long count;
}
