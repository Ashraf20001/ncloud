package com.digitalpaper.transfer.object.enums;

/**
 * The Enum PoolActionTypeEnum.
 */
public enum PoolActionTypeEnum {
	
	/** The allocate. */
	ALLOCATE(1, "ALLOCATE"), /** The reallocate. */
 REALLOCATE(2, "REALLOCATE"), /** The deallocate. */
 DEALLOCATE(3, "DEALLOCATE"), /** The bonus. */
 BONUS(4, "Bonus"), /** The paid. */
 PAID(5, "Paid");

	/**
	 * 
	 */
	Integer id;
	
	/**
	 * 
	 */
	String poolAtion;

	/**
	 * Instantiates a new pool action type enum.
	 *
	 * @param id the id
	 * @param poolAtion the pool ation
	 */
	private PoolActionTypeEnum(Integer id, String poolAtion) {
		this.id = id;
		this.poolAtion = poolAtion;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * Gets the pool ation status.
	 *
	 * @return the pool ation status
	 */
	public String getPoolAtionStatus() {
		return poolAtion;
	}

	/**
	 * Sets the pool ation status.
	 *
	 * @param poolAtion the new pool ation status
	 */
	public void setPoolAtionStatus(String poolAtion) {
		this.poolAtion = poolAtion;
	}

	/**
	 * @param paymentStatusEnum
	 * @return
	 */
	public static PoolActionTypeEnum getPaperStatusIdByName(String poolActionEnum) {
		for (PoolActionTypeEnum onePoolActionStatusEnum : PoolActionTypeEnum.values()) {
			if (onePoolActionStatusEnum.name().equalsIgnoreCase(poolActionEnum)) {
				return onePoolActionStatusEnum;
			}
		}
		return null;
	}
	/**
	 * @param paymentStatusId
	 * @return
	 */
	public static PoolActionTypeEnum getPaperStatusById(Integer poolActionId) {
		for (PoolActionTypeEnum onePoolActionStatusEnum : PoolActionTypeEnum.values()) {
			if (onePoolActionStatusEnum.getId().equals(poolActionId)) {
				return onePoolActionStatusEnum;
			}
		}
		return null;
	}

}
