package com.digitalpaper.transfer.object.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ReportColumnMapping.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "reports_column_mapping")
public class ReportColumnMapping {

	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "reports_column_mapping_id")
	private Integer id;
	
	/** The report id. */
	@ManyToOne
	@JoinColumn(name = "report_id")
	private Reports reportId;
	
	/** The column name. */
	@Column(name = "column_name")
	private String columnName;
	
	/** The order. */
	@Column(name = "column_order")
	private Integer order;
	
	/** The is deleted. */
	@Column(name = "is_deleted")
	private Boolean isDeleted = false;
	
	/** The created date. */
	@Column(name = "created_date")
	private LocalDateTime createdDate;
	
	/** The created by. */
	@Column(name = "created_by")
	private Integer createdBy;
	
	/** The modified date. */
	@Column(name = "modified_date")
	private LocalDateTime modifiedDate;
	
	/** The modified by. */
	@Column(name = "modified_by")
	private Integer modifiedBy;
	
	/** The identity. */
	@Column(name = "identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;
	
	
}
