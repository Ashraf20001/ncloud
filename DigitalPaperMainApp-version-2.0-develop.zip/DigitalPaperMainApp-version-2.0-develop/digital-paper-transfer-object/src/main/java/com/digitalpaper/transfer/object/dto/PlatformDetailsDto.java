package com.digitalpaper.transfer.object.dto;

import lombok.Data;

/**
 * The Class PlatformDetailsDto.
 */
@Data
public class PlatformDetailsDto {

/** The platform id. */
private Integer platformId;
	
	/** The platform name. */
	private String platformName;
	
	/** The platform identity. */
	private String platformIdentity;

}
