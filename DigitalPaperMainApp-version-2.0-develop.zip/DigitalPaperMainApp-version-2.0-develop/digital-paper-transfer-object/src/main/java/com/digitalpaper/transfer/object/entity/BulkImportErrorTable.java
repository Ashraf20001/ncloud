package com.digitalpaper.transfer.object.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BulkImportErrorTable.
 */
@Data
@NoArgsConstructor
@Entity
@Table(name="error_table")
public class BulkImportErrorTable {

	/** The error id. */
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name="error_id") 
	private Integer errorId;
	
	/** The scratch id. */
	@ManyToOne
	@JoinColumn(name="scratch_id")
	private Scratch scratchId;
	
	/** The field name. */
	@Column(name="field_name") 
	private String fieldName;
	
	/** The error message. */
	@Column(name="error_message") 
	private String errorMessage;
	
	/** The is error cleared. */
	@Column(name="is_err_cleared") 
	private boolean isErrorCleared;
	
	/** The identity. */
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name="identity") 
	private String identity;
	
	/** The is deleted. */
	@Column(name="is_deleted") 
	private boolean isDeleted;
	
	/** The created date. */
	@Column(name = "created_date") 
	private LocalDateTime createdDate;
	
	/** The created by. */
	@Column(name = "created_by") 
	private Integer createdBy;
	
	/** The modified date. */
	@Column(name = "modified_date") 
	private LocalDateTime modifiedDate;
	
	/** The modified by. */
	@Column(name = "modified_by")
	private Integer modifiedBy;
	
	
}
