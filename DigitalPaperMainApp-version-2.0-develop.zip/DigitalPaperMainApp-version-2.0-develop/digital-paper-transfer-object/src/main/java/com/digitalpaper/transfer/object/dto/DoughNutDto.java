package com.digitalpaper.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class DoughNutDto.
 */
@Data
@NoArgsConstructor
public class DoughNutDto 
{

    /** The Active. */
    private Long Active;
    
    /** The Expired. */
    private Long Expired;
    
    /** The Revoked. */
    private Long Revoked;
    
    
    /**
     * Instantiates a new dough nut dto.
     *
     * @param active the active
     * @param expired the expired
     * @param revoked the revoked
     */
    public DoughNutDto(long active, long expired, long revoked) {
        Active = active;
        Expired = expired;
        Revoked = revoked;
    }
    
}
