package com.digitalpaper.transfer.object.dto;

import com.digitalpaper.transfer.object.entity.Customer;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * The Class CustomerWithPassword.
 */
@Data
@AllArgsConstructor
public class CustomerWithPassword {

	/** The customer. */
	private Customer customer;
	
	/** The auto password. */
	private String autoPassword;
	
}
