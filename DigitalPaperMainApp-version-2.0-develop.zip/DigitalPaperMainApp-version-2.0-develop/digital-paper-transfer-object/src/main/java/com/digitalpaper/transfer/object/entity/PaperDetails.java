package com.digitalpaper.transfer.object.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class PaperDetails.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "paper_details")
@Audited
public class PaperDetails extends Auditable implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3427912595891965606L;

	/** The paper id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "paper_id")
	private Integer paperId;
	
	/** The pd digital paper id. */
	@Column(name = "paper_number")
	private String pdDigitalPaperId;
	
	/** The policy holder. */
	@Column(name = "policy_holder")
	private String policyHolder;
	
	/** The pd policy number. */
	@Column(name = "policy_number")
	private String pdPolicyNumber;
	
	/** The vd registration number. */
	@Column(name = "registration_number")
	private String vdRegistrationNumber;
	
	/** The vd chassis. */
	@Column(name = "chassis_number")
	private String vdChassis;
	
	/** The pd insured name. */
	@Column(name = "insured_name")
	private String pdInsuredName;
	
	/** The vd usage. */
	@Column(name = "usage_type")
	private String vdUsage;
	
	/** The vd licensed to carry. */
	@Column(name = "license_to_carry")
	private String vdLicensedToCarry;
	
	/** The vd make. */
	@Column(name = "make")
	private String vdMake;
	
	/** The status. */
	@Column(name = "status")
	private Integer status;
	
	/** The is deleted. */
	@Column(name = "is_deleted")
	private Boolean isDeleted = false;
	
	/** The created date. */
	@Column(name = "created_date")
	private LocalDateTime createdDate;
	
	/** The created by. */
	@Column(name = "created_by")
	private Integer createdBy;
	
	/** The modified date. */
	@Column(name = "modified_date")
	private LocalDateTime modifiedDate;
	
	/** The modified by. */
	@Column(name = "modified_by")
	private Integer modifiedBy;
	
	/** The identity. */
	@Column(name = "identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;
	
	/** The vd model. */
	@Column(name = "model")
	private String vdModel;
	
	/** The pd phone number. */
	@Column(name = "phone_number")
	private String pdPhoneNumber;
	
	/** The pd email id. */
	@Column(name = "email_id")
	private String pdEmailId;
	
	/** The company id. */
	@Column(name = "company_id")
	private Integer companyId;
	
	/** The stock pool id. */
	@Column(name = "stock_pool_id")
	private Integer stockPoolId;
	
	/** The paper pool id. */
	@Column(name = "paper_pool_id")
	private Integer paperPoolId;
	
	/** The pd effective from. */
	@Column(name = "effective_start_date")
	private LocalDateTime pdEffectiveFrom;
	
	/** The pd expire date. */
	@Column(name = "expiry_date")
	private LocalDateTime pdExpireDate;
	
	/** The cancelled date. */
	@Column(name = "cancelled_date")
	private LocalDateTime cancelledDate;
	
	/** The storage id. */
	@Column(name = "storage_id")
	private String storageId;
	
	/** The customer. */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="customer_id")
	@NotAudited
	private Customer customer;
	
	/** The allocation user type id. */
	@Column(name="allocation_type_id")
	private Integer allocationUserTypeId;
	
	/** The paper type. */
	@Column(name="type")
	private Integer paperType;
}