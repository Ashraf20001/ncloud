package com.digitalpaper.transfer.object.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AccessMappingSectionDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccessMappingSectionDto {
	
	/** The section id. */
	private Integer sectionId;
	
	/** The section name. */
	private String sectionName;
	
	/** The parent section. */
	private Integer parentSection;
	
	/** The page id. */
	private Integer pageId;
	
	/** The is view. */
	private Boolean isView = true;
	
	/** The is edit. */
	private Boolean isEdit = true;
	
	/** The is download. */
	private Boolean isDownload = true;
	
	/** The is notification. */
	private Boolean isNotification = true;
	
	/** The section data. */
	private List<AccessMappingSectionDto> sectionData;
}
