package com.digitalpaper.transfer.object.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class PaymentDetails.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "payment_details")
@Audited
public class PaymentDetails extends Auditable implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3776842661615766758L;

	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "payment_id")
	private Integer id;

	/** The order id. */
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "order_id")
	@NotAudited
	private PurchaseOrderEntity orderId;

	/** The payment date. */
	@Column(name = "payment_date")
	private LocalDateTime paymentDate;

	/** The payment mode. */
	@Column(name = "payment_mode")
	private Integer paymentMode;
	
	/** The currency type. */
	@Column(name="payment_currency")
	private String currencyType;

	/** The paid amount. */
	@Column(name = "paid_amount")
	private Double paidAmount;

	/** The payment status. */
	@Column(name = "payment_status")
	private Integer paymentStatus;

	/** The transaction id. */
	@Column(name = "transaction_id")
	private String transactionId;

	/** The identity. */
	@Column(name = "identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;

	/** The is deleted. */
	@Column(name = "is_deleted")
	private Boolean isDeleted = false;
	
	/** The allocation user type id. */
	@Column(name= "allocation_type_id")
	private Integer allocationUserTypeId;
}
