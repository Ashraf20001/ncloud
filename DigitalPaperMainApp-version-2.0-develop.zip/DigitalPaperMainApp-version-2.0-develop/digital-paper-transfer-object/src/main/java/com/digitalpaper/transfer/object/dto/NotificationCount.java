package com.digitalpaper.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class NotificationCount.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class NotificationCount {

	/** The notification count. */
	private Long notificationCount;
	
	/** The company id. */
	private Integer companyId;
}
