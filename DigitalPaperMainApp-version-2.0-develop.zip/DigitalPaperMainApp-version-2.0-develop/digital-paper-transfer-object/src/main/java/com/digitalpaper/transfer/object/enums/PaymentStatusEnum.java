package com.digitalpaper.transfer.object.enums;

/**
 * The Enum PaymentStatusEnum.
 */
public enum PaymentStatusEnum {
	
	/** The failed. */
	FAILED(1,"FAILED"),
	
	/** The submitted. */
	SUBMITTED(2,"SUBMITTED"),
	
	/** The success. */
	SUCCESS(3,"SUCCESS"),
	
	/** The rejected. */
	REJECTED(4,"REJECTED");
	
	/** The id. */
	Integer id;
	
	/** The payment status. */
	String paymentStatus;

	/**
	 * Instantiates a new payment status enum.
	 *
	 * @param id the id
	 * @param paymentStatus the payment status
	 */
	private PaymentStatusEnum(Integer id, String paymentStatus) {
		this.id = id;
		this.paymentStatus = paymentStatus;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * Gets the payment status.
	 *
	 * @return the payment status
	 */
	public String getPaymentStatus() {
		return paymentStatus;
	}

	/**
	 * Gets the payment status enum.
	 *
	 * @param paymentStatusEnum the payment status enum
	 * @return the payment status enum
	 */
	public static PaymentStatusEnum getPaymentStatusEnum(String paymentStatusEnum) {
		for (PaymentStatusEnum onePaymentStatusEnum : PaymentStatusEnum.values()) {
			if (onePaymentStatusEnum.name().equalsIgnoreCase(paymentStatusEnum)) {
				return onePaymentStatusEnum;
			}
		}

		return null;
	}


		/**
		 * Gets the payment status enum by id.
		 *
		 * @param id the id
		 * @return the payment status enum by id
		 */
		public static PaymentStatusEnum getPaymentStatusEnumById(Integer id) {
			for (PaymentStatusEnum onePaymentStatusEnum : PaymentStatusEnum.values()) {
				if (onePaymentStatusEnum.ordinal() + 1 == id) {
					return onePaymentStatusEnum;
				}
			}
				return null;
		}



}
