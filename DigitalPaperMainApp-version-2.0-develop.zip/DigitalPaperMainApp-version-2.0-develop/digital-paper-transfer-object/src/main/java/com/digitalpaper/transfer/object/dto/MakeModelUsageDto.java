package com.digitalpaper.transfer.object.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class MakeModelUsageDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MakeModelUsageDto {
		
		/** The make. */
		private List<String> make;
		
		/** The model. */
		private List<String> model;
		
		/** The usage. */
		private List<String> usage;
}
