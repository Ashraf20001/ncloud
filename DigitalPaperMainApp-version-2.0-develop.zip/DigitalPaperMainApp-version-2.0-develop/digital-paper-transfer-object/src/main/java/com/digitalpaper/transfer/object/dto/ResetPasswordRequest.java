package com.digitalpaper.transfer.object.dto;

import lombok.Data;

/**
 * The Class ResetPasswordRequest.
 */
@Data
public class ResetPasswordRequest {
		
	/** The to. */
	private String to;
	
	/** The subject. */
	private String subject;
	
	/** The template. */
	private String template;
	
	/** The name. */
	private String name;
}
