package com.digitalpaper.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class MailResponse.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MailResponse {

	/** The message. */
	private String message;
	
	/** The status. */
	private boolean status;
}
