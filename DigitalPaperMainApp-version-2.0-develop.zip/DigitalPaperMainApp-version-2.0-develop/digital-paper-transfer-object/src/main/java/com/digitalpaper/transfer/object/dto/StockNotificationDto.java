package com.digitalpaper.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class StockNotificationDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class StockNotificationDto {
	
	/** The notification msg. */
	private String notificationMsg;
	
	/** The acted by. */
	private Integer actedBy;
	
	/** The to notify. */
	private Integer toNotify;
	
	/** The order id. */
	private Integer orderId;
	
	/** The created date. */
	private String createdDate;
	
	/** The image url. */
	private String imageUrl;
	
	/** The notification id. */
	private Integer notificationId;
	
	/** The replaceable data. */
	private String replaceableData;
	
	/** The action. */
	private String action;

}
