package com.digitalpaper.transfer.object.dto;

/**
 * The Class PaperDetailsDownloadDto.
 */
public class PaperDetailsDownloadDto {

}
