package com.digitalpaper.transfer.object.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BulkRevokeErrorTable.
 */
@Data
@NoArgsConstructor
@Entity
@Table(name = "bulk_revoke_success_error_table")
public class BulkRevokeErrorTable {
	
	/** The error id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "success_error_id")
	private Integer errorId;
	
	/** The error message. */
	@Column(name = "success_error_message")
	private String errorMessage;
	
	/** The digital paper id. */
	@Column(name = "paper_id")
	private String digitalPaperId;
	
	/** The policy number. */
	@Column(name = "policy_number")
	private String policyNumber;
	
	/** The bulk import history id. */
	@Column(name = "bulk_import_history_id")
	private Integer bulkImportHistoryId;
	
	/** The status. */
	@Column(name = "status")
	private Boolean status;
	
	/** The identity. */
	@Column(name = "identity")
	private String identity;
	
	/** The created date. */
	@Column(name = "created_date")
	private LocalDateTime createdDate;
	
	/** The created by. */
	@Column(name = "created_by")
	private Integer createdBy;
	
	/** The modified date. */
	@Column(name = "modified_date")
	private LocalDateTime modifiedDate;
	
	/** The modified by. */
	@Column(name = "modified_by")
	private Integer modifiedBy;
	
	/** The is deleted. */
	@Column(name = "is_deleted")
	private Boolean isDeleted = false;
}
