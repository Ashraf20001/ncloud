package com.digitalpaper.transfer.object.dto;
import java.util.List;

import com.digitalpaper.config.model.FilterOrSortingVo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class DownloadListVo.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor

public class DownloadListVo {
	
	/** The filter vo. */
	private List<FilterOrSortingVo> filterVo;
	
	/** The column list. */
	private List<String> columnList;
	
	/** The company id. */
	private List <Integer> companyId;
	 
 	/** The max. */
 	private Integer max;
	 
 	/** The min. */
 	private Integer min;


}
