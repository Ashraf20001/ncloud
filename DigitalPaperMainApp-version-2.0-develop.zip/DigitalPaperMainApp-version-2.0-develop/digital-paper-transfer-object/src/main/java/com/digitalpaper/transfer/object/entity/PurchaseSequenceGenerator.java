package com.digitalpaper.transfer.object.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class PurchaseSequenceGenerator.
 */
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Table(name = "purchase_sequence_generator")
public class PurchaseSequenceGenerator {
	
	/** The purchase sequence id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="purchase_sequesnce_id")
    private int purchaseSequenceId;

}
