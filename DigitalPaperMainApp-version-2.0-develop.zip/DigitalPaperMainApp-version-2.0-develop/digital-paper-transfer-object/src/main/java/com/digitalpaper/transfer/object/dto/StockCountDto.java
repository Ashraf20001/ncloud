package com.digitalpaper.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class StockCountDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class StockCountDto {

	/** The total count. */
	private Integer totalCount;
	
	/** The available count. */
	private Integer availableCount;
}
