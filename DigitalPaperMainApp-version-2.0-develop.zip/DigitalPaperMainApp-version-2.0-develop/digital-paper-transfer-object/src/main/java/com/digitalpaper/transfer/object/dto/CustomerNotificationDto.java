package com.digitalpaper.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class CustomerNotificationDto.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CustomerNotificationDto {

    /** The notification id. */
    private Integer notificationId;
	
	/** The notification msg. */
	private String notificationMsg;
	
	/** The acted by. */
	private Integer actedBy;
	
	/** The to notify. */
	private Integer toNotify;
	
	/** The is read. */
	private boolean isRead;	

    /** The created date. */
    private String createdDate;
	
    /** The created by. */
    private Integer createdBy;
    
    /** The modified date. */
    private String modifiedDate;
    
    /** The modified by. */
    private Integer modifiedBy;
    
    /** The identity. */
    private String identity;
    
    /** The is deleted. */
    private Boolean isDeleted = false; 
}
