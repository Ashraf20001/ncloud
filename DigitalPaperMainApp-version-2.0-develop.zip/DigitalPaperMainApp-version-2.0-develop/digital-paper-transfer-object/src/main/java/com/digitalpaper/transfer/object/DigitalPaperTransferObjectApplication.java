package com.digitalpaper.transfer.object;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * The Class DigitalPaperTransferObjectApplication.
 */
@SpringBootApplication
@ComponentScan("com.digitalpaper.*")
public class DigitalPaperTransferObjectApplication {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		
	}

}
