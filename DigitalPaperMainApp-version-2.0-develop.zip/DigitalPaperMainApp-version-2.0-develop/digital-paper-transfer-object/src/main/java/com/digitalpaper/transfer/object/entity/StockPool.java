package com.digitalpaper.transfer.object.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class StockPool.
 */
@Data
@Entity
@Table(name="stock_pool")
@NoArgsConstructor
@AllArgsConstructor
@Audited
public class StockPool extends Auditable implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6970606804693117731L;

	/** The stock pool id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="stock_pool_id")
	private Integer stockPoolId;
	
	/** The stock count. */
	@Column(name="stock_count")
	private Integer stockCount;
	
	/** The used count. */
	@Column(name="used_count")
	private Integer usedCount;
	
	/** The company id. */
	@Column(name="company_id")
	private Integer companyId;
	
	/** The is deleted. */
	@Column(name="is_deleted")
	private boolean isDeleted;
	
	/** The stock id. */
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="stock_id")
	@NotAudited
	private Stock stockId;
	
	/** The identity. */
	@Column(name = "identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;
	
	/** The user type id. */
	@Column(name="user_type_id")
	private Integer userTypeId;
	
	/** The is active. */
	@Column(name="is_active")
	private Boolean isActive;
	

}
