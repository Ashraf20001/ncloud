package com.digitalpaper.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserTypeDto.
 */
@Data
@NoArgsConstructor
public class UserTypeDto {
	
	/** The user type id. */
	private Integer userTypeId;
	
	/** The user type name. */
	private String userTypeName;
}
