package com.digitalpaper.transfer.object.dto;

import lombok.Data;

/**
 * The Class ScratchDto.
 */
@Data
public class ScratchDto implements IConfigurable{
	
	/** The pd policy number. */
	private String pdPolicyNumber;
	
	/** The vd registration number. */
	private String vdRegistrationNumber;
	
	/** The vd chassis. */
	private String vdChassis;
	
	/** The pd insured name. */
	private String pdInsuredName;
	
	/** The vd usage. */
	private String vdUsage;
	
	/** The vd licensed to carry. */
	private String vdLicensedToCarry;
	
	/** The vd make. */
	private String vdMake;
	
	/** The vd model. */
	private String vdModel;
	
	/** The pd phone number. */
	private String pdPhoneNumber;
	
	/** The pd email id. */
	private String pdEmailId;
	
	/** The pd effective from. */
	private String pdEffectiveFrom;
	
	/** The pd expire date. */
	private String pdExpireDate;
	
	/** The company id. */
	private String companyId;
	
	/** The status. */
	private Boolean status;
	
	/** The identity. */
	private String identity;
	
	/** The bulk upload id. */
	private Integer bulkUploadId;

}



