package com.digitalpaper.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SystemPropertyValueDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SystemPropertyValueDto {

	 /** The property value id. */
 	private Integer propertyValueId;
	 
 	/** The property value. */
 	private String propertyValue;
	 
 	/** The property id. */
 	private Integer propertyId;
	 
 	/** The association id. */
 	private Integer associationId;
}
