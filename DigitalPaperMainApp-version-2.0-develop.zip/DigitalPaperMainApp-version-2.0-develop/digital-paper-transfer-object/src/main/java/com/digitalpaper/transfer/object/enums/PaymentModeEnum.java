package com.digitalpaper.transfer.object.enums;

/**
 * The Enum PaymentModeEnum.
 */
public enum PaymentModeEnum {
	
	/** The cash. */
	CASH(1,"CASH"),
	
	/** The cheque. */
	CHEQUE(2,"CHEQUE"),
	
	/** The creditcard. */
	CREDITCARD(3,"CREDIT CARD"),
	
	/** The netbanking. */
	NETBANKING(4,"NET BANKING"),
	
	/** The upi. */
	UPI(5,"UPI"),
	
	/** The bonus. */
	BONUS(6,"BONUS"),
	
	/** The paid. */
	PAID(7,"PAID"),
	
	/** The airtelmoney. */
	AIRTELMONEY(8,"AIRTEL MONEY"),
	
	/** The debitcard. */
	DEBITCARD(9,"DEBIT CARD");



	/** The id. */
	Integer id;
	
	/** The payment mode. */
	String paymentMode;

	/**
	 * Instantiates a new payment mode enum.
	 *
	 * @param id the id
	 * @param paymentMode the payment mode
	 */
	private PaymentModeEnum(Integer id, String paymentMode) {
		this.id = id;
		this.paymentMode = paymentMode;
	}


	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}


	/**
	 * Gets the payment mode.
	 *
	 * @return the payment mode
	 */
	public String getPaymentMode() {
		return paymentMode;
	}


	/**
	 * Gets the payment mode by value.
	 *
	 * @param value the value
	 * @return the payment mode by value
	 */
	public static PaymentModeEnum getPaymentModeByValue(String value){

		for (PaymentModeEnum paymentMode : PaymentModeEnum.values()) {
			if (paymentMode.name().equalsIgnoreCase(value)) {
				return paymentMode;
			}
		}
		return null;
	}

	/**
	 * Gets the payment mode by id.
	 *
	 * @param value the value
	 * @return the payment mode by id
	 */
	public static PaymentModeEnum getPaymentModeById(Integer value){

			for (PaymentModeEnum paymentMode : PaymentModeEnum.values()) {
				if (paymentMode.ordinal() + 1 == value) {
					return paymentMode;
				}
			}
			return null;
		}
	
	/**
	 * Gets the payment mode by values.
	 *
	 * @param value the value
	 * @return the payment mode by values
	 */
	public static PaymentModeEnum getPaymentModeByValues(String value){

		for (PaymentModeEnum paymentMode : PaymentModeEnum.values()) {
			if (paymentMode.paymentMode.equalsIgnoreCase(value)) {
				return paymentMode;
			}
		}
		return null;
	}
}
