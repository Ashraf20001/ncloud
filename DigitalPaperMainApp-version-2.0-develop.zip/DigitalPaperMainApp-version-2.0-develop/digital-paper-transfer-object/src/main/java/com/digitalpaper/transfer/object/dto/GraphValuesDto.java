package com.digitalpaper.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class GraphValuesDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class GraphValuesDto {
	
	/** The x axis. */
	private String xAxis;
	
	/** The y axis. */
	private Long yAxis;

}
