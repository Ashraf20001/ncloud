package com.digitalpaper.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The Class PaperDetailsDto.
 */
@Data
@NoArgsConstructor
public class PaperDetailsDto implements IConfigurable {


	/** The pd digilta paper id. */
	private String pdDigiltaPaperId;

	/** The pd policy number. */
	private String pdPolicyNumber;

	/** The vd registration number. */
	private String vdRegistrationNumber;

	/** The vd chassis. */
	private String vdChassis;

	/** The pd insured name. */
	private String pdInsuredName;

	/** The vd usage. */
	private String vdUsage;

	/** The vd licensed to carry. */
	private String vdLicensedToCarry;

	/** The vd make. */
	private String vdMake;

	/** The vd model. */
	private String vdModel;

	/** The pd phone number. */
	private String pdPhoneNumber;

	/** The pd email id. */
	private String pdEmailId;

	/** The pd effective from. */
	private String pdEffectiveFrom;

	/** The pd expire date. */
	private String pdExpireDate;
	
	/** The identity. */
	private String identity;
	
	/** The status. */
	private String status;
	
	/** The insurer. */
	private String insurer;
	
	/** The created date. */
	private String createdDate;
	
	/** The file URL. */
	private String fileURL;
	
	/** The digital paper id. */
	private Integer digitalPaperId;

	/** The company name. */
	private String companyName;

	/** The company id. */
	private Integer companyId;
	
	/** The paper type. */
	private Integer paperType;
}
