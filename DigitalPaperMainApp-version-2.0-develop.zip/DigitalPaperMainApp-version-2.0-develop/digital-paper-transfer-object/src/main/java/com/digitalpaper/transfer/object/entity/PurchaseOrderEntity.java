package com.digitalpaper.transfer.object.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class PurchaseOrderEntity.
 */
@Entity
@Table(name = "purchase_order")
@Data
@NoArgsConstructor
@Audited
public class PurchaseOrderEntity extends Auditable implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1510256762252959532L;

	/** The order id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "order_id")
    private Integer orderId;
	
	/** The stock count. */
	@Column(name = "stock_count")
	private Integer stockCount;
	
	
	/** The purchase date. */
	@Column(name = "purchase_date")
	private LocalDateTime purchaseDate;
	
	/** The company id. */
	@Column(name = "company_id")
	private Integer companyId;	

	/** The order status. */
	@Column(name="order_status")
    private Integer orderStatus;
	
	/** The purchase id. */
	@Column(name = "purchase_id")
	private String purchaseId;
	
    /** The order amt. */
    @Column(name="order_amt")
    private String orderAmt;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The payment method. */
    @Column(name="payment_method")
    private Integer paymentMethod;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private Boolean isDeleted = false;
    
    /** The association id. */
    @Column(name="association_id")
    private Integer associationId;

}
