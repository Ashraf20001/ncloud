package com.digitalpaper.transfer.object.entity;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class Customer.
 */
@Data
@Entity
@Table(name="customer")
@AllArgsConstructor
@NoArgsConstructor
@Audited
public class Customer extends Auditable implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2016008281795135389L;

	/** The customer id. */
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="customer_id")
	private Integer customerId;
	
	/** The username. */
	@Column(name="insurer_name")
	private String username;
	
	/** The email. */
	@Column(name="email_id")
	private String email;
	
	/** The phone number. */
	@Column(name="phone_number")
	private String phoneNumber;
	
	/** The added date. */
	@Column(name="added_date")
	private LocalDateTime addedDate;	
	
	/** The password. */
	@Column(name="password")
	private String password;
	
	/** The identity. */
	@Column(name = "identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;
	
	/** The is deleted. */
	@Column(name = "is_deleted")
	private Boolean isDeleted = false;
	 
	
	/** The company id. */
	@Column(name="company_id")
	private Integer companyId;
	
	/** The status. */
	@Column(name="status")
	private Boolean status;
	
	/** The is first time login. */
	@Column(name="first_time_login")
	private Boolean isFirstTimeLogin = false;
	
	/** The profile url. */
	@Column(name="profile_url")
    private Integer profileUrl;
	
	/** The paper details set. */
	@OneToMany(mappedBy = "customer",fetch = FetchType.LAZY)
	private Set<PaperDetails> paperDetailsSet;
	
}
