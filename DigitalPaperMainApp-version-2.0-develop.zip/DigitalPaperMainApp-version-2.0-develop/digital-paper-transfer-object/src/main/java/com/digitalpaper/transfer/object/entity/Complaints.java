package com.digitalpaper.transfer.object.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class Complaints.
 */
@Data
@Entity
@Table(name="complaints")
@NoArgsConstructor
@Audited
public class Complaints extends Auditable implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 9106101739663438600L;

	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Integer id;
	
	/** The name. */
	@Column(name="name")
	private String name;
	
	/** The email id. */
	@Column(name="email_id")
	private String email_id;
	
	/** The date of incident. */
	@Column(name="date_of_incident")
	private LocalDateTime dateOfIncident;
	
	/** The complaint type. */
	@Column(name="compliant_type")
	private String complaintType;
	
	/** The remarks. */
	@Column(name="remarks")
	private String remarks;
	
	/** The is deleted. */
	@Column(name="is_deleted")
	private boolean isDeleted;
	
	/** The identity. */
	@Column(name = "identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;
	
	/** The complaints id. */
	@Column(name="complaint_id")
	private String complaintsId;
	
}
