package com.digitalpaper.transfer.object.dto;

import lombok.Data;

/**
 * The Class PoolDto.
 */
@Data
public class PoolDto {

	/** The pool action. */
	private String poolAction;
	
	/** The stock count. */
	private Integer stockCount;
	
	/** The re allocate to id. */
	private Integer reAllocateToId;
	
	/** The pool id. */
	private Integer poolId;
	
	/** The pool name. */
	private String poolName;
	
	/** The user type id. */
	private Integer userTypeId;
}
