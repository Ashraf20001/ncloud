package com.digitalpaper.transfer.object.dto;

import java.util.List;

import com.digitalpaper.config.model.FilterOrSortingVo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AllSearchFilterDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AllSearchFilterDto {

		/** The filter or sorting vos. */
		private List<FilterOrSortingVo> filterOrSortingVos;
		
		/** The digital paper ids. */
		private List<String> digitalPaperIds;
}
