package com.digitalpaper.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CustomerDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerDto {
	
	/** The customer id. */
	private Integer customerId;
	
	/** The username. */
	private String username;
	
	/** The email. */
	private String email;
	
	/** The phone number. */
	private String phoneNumber;
	
	/** The added date. */
	private String addedDate;
	
	/** The status. */
	private Boolean status;
	
	/** The password. */
	private String password;
	
	/** The is first time login. */
	private Boolean isFirstTimeLogin;
	
	/** The identity. */
	private String identity;
	
	/** The company id. */
	private Integer companyId;
	
	/** The customer url. */
	private String customerUrl;
}
