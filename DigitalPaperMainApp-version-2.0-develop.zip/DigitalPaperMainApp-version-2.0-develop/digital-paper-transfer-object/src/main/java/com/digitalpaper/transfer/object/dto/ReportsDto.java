package com.digitalpaper.transfer.object.dto;

import java.time.LocalDateTime;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ReportsDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReportsDto {

	/** The insured name. */
	private String insuredName;
	
	/** The from date. */
	private LocalDateTime fromDate;
	
	/** The to date. */
	private LocalDateTime toDate;
	
	/** The report type. */
	private Integer reportType;
	
	/** The file type. */
	private Integer fileType;
	
	/** The report name. */
	private String reportName;
	
	/** The insured company id. */
	private Integer insuredCompanyId;
	
	/** The selected column. */
	private List<String> selectedColumn;
	
	/** The selected column count. */
	private Long selectedColumnCount;
	
	/** The status. */
	private List<String> status;
	
	/** The period. */
	private String period;
	
	/** The identity. */
	private String identity;
	
	/** The purchase order total count. */
	private Long purchaseOrderTotalCount;
	
	/** The purchase order pending count. */
	private Long purchaseOrderPendingCount;
	
	/** The purchase order success count. */
	private Long purchaseOrderSuccessCount;
	
	/** The paper details total count. */
	private Long paperDetailsTotalCount;
	
	/** The paper details active count. */
	private Long paperDetailsActiveCount;
	
	/** The paper details expired count. */
	private Long paperDetailsExpiredCount;
}
