package com.digitalpaper.transfer.object.entity;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class StockNotification.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "stock_notification")
public class StockNotification {
	
	/** The notification id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "notification_id")
    private Integer notificationId;
	
	/** The notification msg. */
	@Column(name = "notification_message")
	private String notificationMsg;
	
	/** The acted by. */
	@Column(name = "acted_by")
	private Integer actedBy;
	
	/** The to notify. */
	@Column(name = "to_notify")
	private Integer toNotify;
	
	/** The is read. */
	@Column(name = "is_read")
	private boolean isRead;	

	/** The created date. */
	@Column(name="created_date")
    private LocalDateTime createdDate;
	
    /** The created by. */
    @Column(name="created_by")
    private Integer createdBy;
    
    /** The modified date. */
    @Column(name="modified_date")
    private LocalDateTime modifiedDate;
    
    /** The modified by. */
    @Column(name="modified_by")
    private Integer modifiedBy;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private Boolean isDeleted = false; 
    
/** The order id. */
    @OneToOne(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	@JoinColumn(name = "order_id")
    private PurchaseOrderEntity orderId;
    
    /** The is association. */
    @Column(name="is_association")
    private Boolean isAssociation;
    
    /** The action status. */
    @Column(name="action_status")
    private String actionStatus;
    
    /** The replace data. */
    @Column(name="replace_data")
    private String replaceData;
    
}
