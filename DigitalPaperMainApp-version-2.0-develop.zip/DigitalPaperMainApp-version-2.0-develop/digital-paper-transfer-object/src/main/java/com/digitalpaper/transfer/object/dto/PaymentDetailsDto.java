package com.digitalpaper.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class PaymentDetailsDto.
 */
@Data
@NoArgsConstructor
public class PaymentDetailsDto {

	/** The company name. */
	private String companyName;
	
	/** The purchase id. */
	private String purchaseId;
	
	/** The transaction id. */
	private String transactionId;
	
	/** The payment type. */
	private String paymentType;
	
	/** The no of papers. */
	private String noOfPapers;
	
	/** The purchase amount. */
	private String purchaseAmount;
	
	/** The payment status. */
	private String paymentStatus;
	
	/** The action button. */
	private String actionButton;

}
