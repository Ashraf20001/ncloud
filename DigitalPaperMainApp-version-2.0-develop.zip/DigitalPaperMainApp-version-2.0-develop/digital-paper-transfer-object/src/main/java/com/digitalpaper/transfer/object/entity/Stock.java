package com.digitalpaper.transfer.object.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.envers.Audited;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class Stock.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "stock")
@Audited
public class Stock extends Auditable implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1495238571834204636L;

	/** The stock id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "stock_id")
    private Integer stockId;
	
	/** The stock count. */
	@Column(name = "stock_count")
	private Integer stockCount;
	
	/** The used count. */
	@Column(name = "used_count")
	private Integer usedCount;
	
	/** The company id. */
	@Column(name = "company_id")
	private Integer companyId;
    
    /** The identity. */
    @Column(name = "identity")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String identity;
    
    /** The is deleted. */
    @Column(name = "is_deleted")
    private Boolean isDeleted = false; 
    

}
