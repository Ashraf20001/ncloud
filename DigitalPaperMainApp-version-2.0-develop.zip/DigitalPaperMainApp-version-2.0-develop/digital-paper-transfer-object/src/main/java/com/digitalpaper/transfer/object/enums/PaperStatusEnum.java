package com.digitalpaper.transfer.object.enums;

/**
 * The Enum PaperStatusEnum.
 */
public enum PaperStatusEnum {

	/** The active. */
	ACTIVE(1, "ACTIVE"), /** The expired. */
 EXPIRED(2, "EXPIRED"), /** The revoke. */
 REVOKE(3, "REVOKE");

	/**
	 * 
	 */
	Integer id;
	
	/**
	 * 
	 */
	String paperStatus;

	/**
	 * Instantiates a new paper status enum.
	 *
	 * @param id the id
	 * @param paperStatus the paper status
	 */
	private PaperStatusEnum(Integer id, String paperStatus) {
		this.id = id;
		this.paperStatus = paperStatus;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * Gets the paper status.
	 *
	 * @return the paper status
	 */
	public String getPaperStatus() {
		return paperStatus;
	}

	/**
	 * Sets the paper status.
	 *
	 * @param paperStatus the new paper status
	 */
	public void setPaperStatus(String paperStatus) {
		this.paperStatus = paperStatus;
	}

	/**
	 * @param paymentStatusEnum
	 * @return
	 */
	public static PaperStatusEnum getPaperStatusIdByName(String paymentStatusEnum) {
		for (PaperStatusEnum onePaymentStatusEnum : PaperStatusEnum.values()) {
			if (onePaymentStatusEnum.name().equalsIgnoreCase(paymentStatusEnum)) {
				return onePaymentStatusEnum;
			}
		}
		return null;
	}
	/**
	 * @param paymentStatusId
	 * @return
	 */
	public static PaperStatusEnum getPaperStatusById(Integer paymentStatusId) {
		for (PaperStatusEnum onePaymentStatusEnum : PaperStatusEnum.values()) {
			if (onePaymentStatusEnum.getId().equals(paymentStatusId)) {
				return onePaymentStatusEnum;
			}
		}
		return null;
	}

}
