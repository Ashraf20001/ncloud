package com.digitalpaper.transfer.object.dto;

import java.util.List;

import com.digitalpaper.config.model.FilterOrSortingVo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CompanyTransactionDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CompanyTransactionDto {
	
	/** The company id. */
	private List<Integer> companyId;
	
	/** The min. */
	private Integer min;
	
	/** The max. */
	private Integer max;
	
	/** The filter. */
	private List<FilterOrSortingVo> filter;
	
	/** The selected column. */
	private List<String> selectedColumn;
	
	/** The is notification. */
	private Boolean isNotification;
	
	/** The view. */
	private String view;
}
