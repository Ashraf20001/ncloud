package com.digitalpaper.transfer.object.dto;

import lombok.Data;

/**
 * The Class TopCompanyPurchaseDto.
 */
@Data
public class TopCompanyPurchaseDto {
	
	/** The stock count. */
	private Long stockCount;
	
	/** The companies. */
	private String companies;
}
