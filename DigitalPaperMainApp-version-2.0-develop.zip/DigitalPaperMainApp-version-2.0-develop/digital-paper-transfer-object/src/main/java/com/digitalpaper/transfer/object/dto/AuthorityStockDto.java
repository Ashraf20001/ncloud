package com.digitalpaper.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AuthorityStockDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuthorityStockDto {
	
	/** The company id. */
	private Integer companyId;
	
	/** The insured comapny. */
	private String insuredComapny;
	
	/** The stock count. */
	private Integer stockCount;
	
	/** The available stock. */
	private Integer availableStock;
	
	/** The paper issued. */
	private Integer paperIssued;

}
