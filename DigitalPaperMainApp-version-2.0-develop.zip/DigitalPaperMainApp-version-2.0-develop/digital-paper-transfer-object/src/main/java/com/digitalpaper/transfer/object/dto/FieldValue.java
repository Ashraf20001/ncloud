package com.digitalpaper.transfer.object.dto;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FieldValue.
 */
@Data
@NoArgsConstructor
public class FieldValue {
	
	/** The field. */
	private Field field;
	
	/** The value. */
	private JsonNode value;
	
	/**
	 * Gets the string value.
	 *
	 * @return the string value
	 */
	public String getStringValue() {
	    if (value != null) {
	        if (value.isTextual()) {
	            return value.textValue();
	        } else if (value.isArray() && value.size() > 0) {
	            List<String> getValue = new ArrayList<>();
	            for (JsonNode valueNode : value) {
	                if (valueNode.isTextual()) {
	                    getValue.add(valueNode.asText());
	                } else {
	                    getValue.add(valueNode.toString());
	                }
	            }
	            return getValue.toString();
	        }
	    }
	    return null;
	}


	    /**
    	 * Gets the json value.
    	 *
    	 * @return the json value
    	 */
    	// Custom method to get the 'value' as a JsonNode (if needed)
	    public JsonNode getJsonValue() {
	        return value;
	    }
	
}
