package com.digitalpaper.transfer.object.dto;

import lombok.Data;

/**
 * The Class RolePrivilegeDto.
 */
@Data
public class RolePrivilegeDto {

/** The role id. */
private Integer roleId;

/** The apis. */
private String apis;
}
