package com.digitalpaper.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class MonthCountDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MonthCountDto {
	
	/** The month. */
	private int month;
	
	/** The count. */
	private Long count;

}
