package com.digitalpaper.transfer.object.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class Reports.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "reports")
public class Reports {

	/** The reports id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "report_id")
	private Integer reportsId;
	
	/** The insured name. */
	@Column(name = "insured_name")
	private String insuredName;
	
	/** The report name. */
	@Column(name = "report_name")
	private String reportName;
	
	/** The from date. */
	@Column(name = "from_date")
	private LocalDateTime fromDate;
	
	/** The to date. */
	@Column(name = "to_date")
	private LocalDateTime toDate;
	
	/** The report type. */
	@Column(name = "report_type")
	private Integer reportType;
	
	/** The file type. */
	@Column(name = "file_type")
	private Integer fileType;
	
	/** The company id. */
	@Column(name = "insurence_company_id")
	private Integer companyId;
	
	/** The status. */
	@Column(name = "status")
	private String status;
	
	/** The period. */
	@Column(name = "period")
	private String period;
	
	/** The is deleted. */
	@Column(name = "is_deleted")
	private Boolean isDeleted = false;
	
	/** The created date. */
	@Column(name = "created_date")
	private LocalDateTime createdDate;
	
	/** The created by. */
	@Column(name = "created_by")
	private Integer createdBy;
	
	/** The modified date. */
	@Column(name = "modified_date")
	private LocalDateTime modifiedDate;
	
	/** The modified by. */
	@Column(name = "modified_by")
	private Integer modifiedBy;
	
	/** The identity. */
	@Column(name = "identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;
}
