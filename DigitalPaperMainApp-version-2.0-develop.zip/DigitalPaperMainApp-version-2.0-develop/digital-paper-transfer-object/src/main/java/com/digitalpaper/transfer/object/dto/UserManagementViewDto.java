package com.digitalpaper.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserManagementViewDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserManagementViewDto {
	
	/** The is active. */
	private Boolean isActive;
    
    /** The user details. */
    private MetaDataViewDto userDetails;
    
    /** The enable notification. */
    private EnableNotificationDto enableNotification;
}
