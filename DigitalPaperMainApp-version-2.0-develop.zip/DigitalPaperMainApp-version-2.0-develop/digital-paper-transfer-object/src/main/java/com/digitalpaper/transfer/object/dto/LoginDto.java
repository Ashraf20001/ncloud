package com.digitalpaper.transfer.object.dto;
import lombok.Data;

/**
 * The Class LoginDto.
 */
@Data
public class LoginDto {
	
	/** The username. */
	private String username;

	/** The password. */
	private String password;

}
