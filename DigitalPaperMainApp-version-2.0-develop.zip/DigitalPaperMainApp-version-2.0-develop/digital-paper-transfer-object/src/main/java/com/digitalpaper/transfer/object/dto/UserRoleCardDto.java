package com.digitalpaper.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserRoleCardDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserRoleCardDto {

	 /** The role id. */
 	private Integer roleId;
	    
    	/** The role name. */
    	private String roleName;
	    
    	/** The description. */
    	private String description;
	    
    	/** The user count. */
    	private Integer userCount;
	    
    	/** The is active. */
    	private Boolean isActive;
	    
    	/** The in active date. */
    	private String inActiveDate;
	    
    	/** The is mapped. */
    	private Boolean isMapped;
	    
    	/** The role identity. */
    	private String roleIdentity;
	    
    	/** The allocation user type. */
    	private String allocationUserType;
	    
    	/** The allocation user id. */
    	private Integer allocationUserId;
}
