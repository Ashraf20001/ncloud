package com.digitalpaper.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AuthorityBarChartDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuthorityBarChartDto {

	/** The company id. */
	private Integer companyId;
	
	/** The insured comapny. */
	private String insuredComapny;
	
	/** The short name. */
	private String shortName;
	
	/** The digital paper allocated. */
	private Integer digitalPaperAllocated;
	
	/** The digital paper purchased. */
	private Integer digitalPaperPurchased;
}
