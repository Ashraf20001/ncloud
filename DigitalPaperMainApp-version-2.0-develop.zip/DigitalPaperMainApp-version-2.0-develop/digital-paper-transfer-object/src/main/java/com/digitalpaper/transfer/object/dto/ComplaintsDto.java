package com.digitalpaper.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ComplaintsDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ComplaintsDto {

	/** The company id. */
	private Integer companyId;
	
	/** The name. */
	private  String name;
	
	/** The email id. */
	private String emailId;
	
	/** The date of incident. */
	private String dateOfIncident;
	
	/** The compliants type. */
	private String compliantsType;
	
	/** The remarks. */
	private String remarks;
	
	/** The digital paper id. */
	private String digitalPaperId;
	
	/** The complaints id. */
	private String complaintsId;
}
