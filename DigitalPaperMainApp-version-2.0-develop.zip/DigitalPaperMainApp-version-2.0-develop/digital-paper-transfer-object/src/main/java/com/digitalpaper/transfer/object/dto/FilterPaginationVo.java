package com.digitalpaper.transfer.object.dto;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FilterPaginationVo.
 */
@Data
@NoArgsConstructor
public class FilterPaginationVo {
	
	/** The filter or sorting vo. */
	private List<FilterOrSortingVo> filterOrSortingVo;
	
	/** The min. */
	private Integer min;
	
	/** The max. */
	private Integer max;
	
	/** The identity. */
	private String identity;

}
