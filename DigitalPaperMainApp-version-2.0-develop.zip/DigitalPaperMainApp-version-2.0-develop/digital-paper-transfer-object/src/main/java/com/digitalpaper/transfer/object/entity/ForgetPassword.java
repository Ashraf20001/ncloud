package com.digitalpaper.transfer.object.entity;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ForgetPassword.
 */
@Data
@Entity
@Table(name="forget_email")
@AllArgsConstructor
@NoArgsConstructor
public class ForgetPassword {
	
	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	/** The identity. */
	@Column(name = "identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;
	
	/** The customer identity. */
	@Column(name = "customer_identity")
	private String customerIdentity;
	
	/** The email id. */
	@Column(name = "email_id")
	private String emailId;
	
	/** The created at. */
	@Column(name = "created_at")
	private LocalDate createdAt;
	
	/** The expire time. */
	@Column(name = "expire_at")
	private Date expireTime;
	
	/** The customer details. */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="customer_id")
	private Customer customerDetails;
}
