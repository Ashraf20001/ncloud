package com.digitalpaper.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AccessMappingPrivilegeDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccessMappingPrivilegeDto {
	
	/** The privilege id. */
	private Integer privilegeId;
    
    /** The privilege name. */
    private String privilegeName;
    
    /** The page id. */
    private Integer pageId;
    
    /** The is enabled. */
    private Boolean isEnabled = true;
}
