package com.digitalpaper.transfer.object.dto;

import java.util.List;

import com.digitalpaper.transfer.object.entity.UserType;

/**
 * The Class JwtResponse.
 */
public class JwtResponse {
	
	/** The token. */
	private String token;
	
	/** The type. */
	private String type = "Bearer";
	
	/** The id. */
	private Integer id;
	
	/** The username. */
	private String username;
	
	/** The email. */
	private String email;
	
	/** The first time login. */
	private boolean firstTimeLogin;
	
	/** The user type id. */
	private UserType userTypeId;
	
	/** The roles. */
	private List<String> roles;
	
	/** The identity. */
	private String identity;
	
	/** The company name. */
	private String companyName;
	
	/** The refresh token. */
	private String refreshToken;
	
	/** The platform id. */
	private Integer platformId;
	
	/** The association id. */
	private Integer associationId;


	/**
	 * Instantiates a new jwt response.
	 *
	 * @param accessToken the access token
	 * @param id the id
	 * @param username the username
	 * @param identity the identity
	 * @param email the email
	 * @param firstTimeLogin the first time login
	 * @param userTypeId the user type id
	 * @param roles the roles
	 * @param companyName the company name
	 * @param refreshToken the refresh token
	 * @param platformId the platform id
	 * @param associationId the association id
	 */
	public JwtResponse(String accessToken, Integer id, String username, String identity, String email,
			boolean firstTimeLogin, UserType userTypeId, List<String> roles, String companyName,String refreshToken,Integer platformId,Integer associationId ) {
		this.token = accessToken;
		this.id = id;
		this.username = username;
		this.email = email;
		this.roles = roles;
		this.firstTimeLogin = firstTimeLogin;
		this.userTypeId = userTypeId;
		this.identity = identity;
		this.companyName = companyName;
		this.refreshToken = refreshToken;
		this.platformId = platformId;
		this.associationId = associationId;
	}

	/**
	 * Gets the platform id.
	 *
	 * @return the platform id
	 */
	public Integer getPlatformId() {
		return platformId;
	}

	/**
	 * Sets the platform id.
	 *
	 * @param platformId the new platform id
	 */
	public void setPlatformId(Integer platformId) {
		this.platformId = platformId;
	}

	/**
	 * Gets the association id.
	 *
	 * @return the association id
	 */
	public Integer getAssociationId() {
		return associationId;
	}

	/**
	 * Sets the association id.
	 *
	 * @param associationId the new association id
	 */
	public void setAssociationId(Integer associationId) {
		this.associationId = associationId;
	}

	/**
	 * Gets the refresh token.
	 *
	 * @return the refresh token
	 */
	public String getRefreshToken() {
		return refreshToken;
	}

	/**
	 * Sets the refresh token.
	 *
	 * @param refreshToken the new refresh token
	 */
	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}

	/**
	 * Instantiates a new jwt response.
	 */
	public JwtResponse() {
	}

	/**
	 * Gets the access token.
	 *
	 * @return the access token
	 */
	public String getAccessToken() {
		return token;
	}

	/**
	 * Sets the access token.
	 *
	 * @param accessToken the new access token
	 */
	public void setAccessToken(String accessToken) {
		this.token = accessToken;
	}

	/**
	 * Gets the token type.
	 *
	 * @return the token type
	 */
	public String getTokenType() {
		return type;
	}

	/**
	 * Sets the token type.
	 *
	 * @param tokenType the new token type
	 */
	public void setTokenType(String tokenType) {
		this.type = tokenType;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Gets the username.
	 *
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * Sets the username.
	 *
	 * @param username the new username
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * Gets the roles.
	 *
	 * @return the roles
	 */
	public List<String> getRoles() {
		return roles;
	}

	/**
	 * Checks if is first time login.
	 *
	 * @return true, if is first time login
	 */
	public boolean isFirstTimeLogin() {
		return firstTimeLogin;
	}

	/**
	 * Sets the first time login.
	 *
	 * @param firstTimeLogin the new first time login
	 */
	public void setFirstTimeLogin(boolean firstTimeLogin) {
		this.firstTimeLogin = firstTimeLogin;
	}

	/**
	 * Gets the user type id.
	 *
	 * @return the user type id
	 */
	public UserType getUserTypeId() {
		return userTypeId;
	}

	/**
	 * Sets the user type id.
	 *
	 * @param userTypeId the new user type id
	 */
	public void setUserTypeId(UserType userTypeId) {
		this.userTypeId = userTypeId;
	}

	/**
	 * Gets the identity.
	 *
	 * @return the identity
	 */
	public String getIdentity() {
		return identity;
	}

	/**
	 * Sets the identity.
	 *
	 * @param identity the new identity
	 */
	public void setIdentity(String identity) {
		this.identity = identity;
	}

	/**
	 * Gets the company name.
	 *
	 * @return the company name
	 */
	public String getCompanyName() {
		return this.companyName;
	}
	
	/**
	 * Sets the company name.
	 *
	 * @param companyName the new company name
	 */
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
}
