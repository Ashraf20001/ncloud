package com.digitalpaper.transfer.object.dto;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * The Class SaveStockDataVo.
 */
@Data
@NoArgsConstructor
@Getter
public class SaveStockDataVo {
	
	/** The number of papers. */
	private String numberOfPapers;
	
	/** The total cost value. */
	private String totalCostValue;
	
	/** The payment method. */
	private String  paymentMethod;
	
	/** The upload file name. */
	private boolean  uploadFileName;
	
	/** The currency type. */
	private String currencyType;
}
