package com.digitalpaper.transfer.object.dto;

import java.util.List;

import lombok.Data;

/**
 * The Class DashBoardOutputDto.
 */
@Data
public class DashBoardOutputDto {
	
	/** The dash board values. */
	private List<GraphValuesDto> dashBoardValues;

}
