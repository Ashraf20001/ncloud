package com.digitalpaper.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class PurchaseOrderDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PurchaseOrderDto {

	 /**
 	 * Instantiates a new purchase order dto.
 	 *
 	 * @param object the object
 	 */
 	public PurchaseOrderDto(Object[] object) {
		 this.purchaseId=(String)object[0];
		 this.transactionId=(String) object[1];
		 this.stockCount=(Integer) object[2];
		 this.purchaseDate=(String) object[3].toString();
		 this.companyId=(Integer) object[4];
		 this.purchaseAmount=(Double) object[5];
		 this.paymentMethod=(String) object[6];
		 this.paymentStatus=(String) object[7];
		 this.currencyType = (String)object[8];
		 this.orderId=(Integer) object[9];
	}
	
	/** The purchase id. */
	private String purchaseId;
	 
 	/** The transaction id. */
 	private String transactionId;
	 
 	/** The stock count. */
 	private Integer stockCount;
	 
 	/** The purchase date. */
 	private String purchaseDate;
	 
 	/** The company id. */
 	private Integer companyId;	
	 
 	/** The purchase amount. */
 	private Double purchaseAmount;
	 
 	/** The payment method. */
 	private String paymentMethod;
	 
 	/** The payment status. */
 	private String paymentStatus;
	 
 	/** The order id. */
 	private Integer orderId;
	 
 	/** The currency type. */
 	private String currencyType;

}
