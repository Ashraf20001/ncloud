package com.digitalpaper.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ChangePasswordDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ChangePasswordDto {
	
	/** The old password. */
	private String oldPassword;
	
	/** The new password. */
	private String newPassword;
	
	/** The confirm password. */
	private String confirmPassword;
}
