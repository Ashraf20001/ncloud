package com.digitalpaper.transfer.object.dto;

import lombok.Data;

/**
 * The Class BulkImportMapping.
 */
@Data
public class BulkImportMapping {

	/** The id. */
	private Integer id;

	/** The bulk import field name. */
	private String bulkImportFieldName;

	/** The bulk import alias name. */
	private String bulkImportAliasName;

	/** The platform id. */
	private String platformId;

}
