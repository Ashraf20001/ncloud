package com.digitalpaper.transfer.object.dto;

import com.digitalpaper.transfer.object.entity.Stock;
import com.digitalpaper.transfer.object.entity.StockPool;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AllPoolDto.
 */
@Data
@NoArgsConstructor
public class AllPoolDto {
	
	/** The stock. */
	private Stock stock;
	
	/** The stock pool. */
	private StockPool stockPool;
	
	/** The re allocate stock pool. */
	private StockPool reAllocateStockPool;

}
