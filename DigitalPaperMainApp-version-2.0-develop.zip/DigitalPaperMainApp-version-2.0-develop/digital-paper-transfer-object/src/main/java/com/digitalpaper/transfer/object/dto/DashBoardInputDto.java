package com.digitalpaper.transfer.object.dto;

import java.time.LocalDateTime;

import lombok.Data;

/**
 * The Class DashBoardInputDto.
 */
@Data
public class DashBoardInputDto {
	
	/** The from date. */
	private LocalDateTime fromDate;
	
	/** The to date. */
	private LocalDateTime toDate;
	
	/** The filter type. */
	private String filterType;

}
