package com.digitalpaper.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BulkImportHistoryDto.
 */
@Data
@NoArgsConstructor
public class BulkImportHistoryDto {

    /** The upload id. */
    private Integer uploadId;
    
    /** The success count. */
    private Integer successCount;
    
    /** The failure count. */
    private Integer failureCount;
    
    /** The total count. */
    private Integer totalCount;
    
    /** The status. */
    private String status;
    
    /** The page id. */
    private Integer pageId;
    
    /** The created by. */
    private String createdBy;
    
    /** The created date. */
    private String createdDate;
    
    /** The identity. */
    private String identity;
    
    /** The platform id. */
    private Integer platformId;
    
    /** The pool id. */
    private Integer poolId;
    
    /** The upload type. */
    private Integer uploadType;
}