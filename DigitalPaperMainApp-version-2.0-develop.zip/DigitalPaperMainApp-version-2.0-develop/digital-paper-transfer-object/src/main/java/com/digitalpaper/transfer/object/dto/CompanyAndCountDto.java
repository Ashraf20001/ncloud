package com.digitalpaper.transfer.object.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class CompanyAndCountDto.
 */
@Getter
@Setter
@NoArgsConstructor
public class CompanyAndCountDto {

	/** The company id. */
	private Integer companyId;
	
	/** The comapany name. */
	private String comapanyName;
	
	/** The total count. */
	private Long totalCount;
	
	/** The pending count. */
	private Long pendingCount=0l;
	
	/** The notification. */
	private Long notification=0l;
	
	
	/**
	 * Instantiates a new company and count dto.
	 *
	 * @param companyId the company id
	 * @param comapanyName the comapany name
	 * @param totalCount the total count
	 * @param pendingCount the pending count
	 */
	public CompanyAndCountDto(Integer companyId, String comapanyName, Long totalCount, Long pendingCount) {
		super();
		this.companyId = companyId;
		this.comapanyName = comapanyName;
		this.totalCount = totalCount;
		this.pendingCount = pendingCount;
	}
	

}
