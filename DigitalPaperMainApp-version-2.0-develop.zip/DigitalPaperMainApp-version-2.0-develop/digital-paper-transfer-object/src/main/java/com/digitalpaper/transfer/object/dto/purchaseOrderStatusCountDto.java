package com.digitalpaper.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class purchaseOrderStatusCountDto.
 */
@Data
@NoArgsConstructor
public class purchaseOrderStatusCountDto {

	/** The total count. */
	private Long totalCount;
	
	/** The faild count. */
	private Long faildCount = 0l;
	
	/** The success count. */
	private Long successCount = 0l;
	
	/** The sumited count. */
	private Long sumitedCount = 0l;

	/**
	 * Instantiates a new purchase order status count dto.
	 *
	 * @param totalCount the total count
	 * @param faildCount the faild count
	 * @param successCount the success count
	 * @param sumitedCount the sumited count
	 */
	public purchaseOrderStatusCountDto(Long totalCount, Long faildCount, Long successCount, Long sumitedCount) {
		super();

		this.totalCount = totalCount;
		this.faildCount = faildCount;
		this.successCount = successCount;
		this.sumitedCount = sumitedCount;
	}
}
