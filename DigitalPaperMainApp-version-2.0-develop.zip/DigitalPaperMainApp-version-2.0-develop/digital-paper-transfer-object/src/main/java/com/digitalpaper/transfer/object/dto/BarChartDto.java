package com.digitalpaper.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BarChartDto.
 */
@Data
@NoArgsConstructor
public class BarChartDto {

	/** The month. */
	private String month;
	
	/** The stock allocated. */
	private Long stockAllocated;
	
	/** The certificate issued. */
	private Long certificateIssued;
}
