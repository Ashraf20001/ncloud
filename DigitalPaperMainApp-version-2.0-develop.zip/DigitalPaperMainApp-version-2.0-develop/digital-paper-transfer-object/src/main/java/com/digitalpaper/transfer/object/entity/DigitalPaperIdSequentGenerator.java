package com.digitalpaper.transfer.object.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class DigitalPaperIdSequentGenerator.
 */
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Table(name = "digital_paperid_sequence_generator")
public class DigitalPaperIdSequentGenerator {
	
	/** The digital paper id. */
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="digital_paper_id")
    private int digitalPaperId;

}
