package com.digitalpaper.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AllocationStockDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AllocationStockDto {
	
	/** The number of paper. */
	private int numberOfPaper;
	
	/** The allocatepaper type. */
	private String allocatepaperType;
	
	/** The company id. */
	private int companyId;
	

}
