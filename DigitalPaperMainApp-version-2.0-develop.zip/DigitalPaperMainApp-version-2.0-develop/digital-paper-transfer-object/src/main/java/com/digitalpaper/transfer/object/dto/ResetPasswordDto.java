package com.digitalpaper.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ResetPasswordDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResetPasswordDto {
		
		/** The identity. */
		private String identity;
		
		/** The new password. */
		private String newPassword;
		
		/** The confirm password. */
		private String confirmPassword;

}
