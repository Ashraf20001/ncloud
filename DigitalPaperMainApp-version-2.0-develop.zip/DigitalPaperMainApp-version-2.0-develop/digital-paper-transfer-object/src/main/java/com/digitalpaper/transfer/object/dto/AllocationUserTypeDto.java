package com.digitalpaper.transfer.object.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AllocationUserTypeDto.
 */
@Data
@NoArgsConstructor
public class AllocationUserTypeDto {
	
	/** The user type name. */
	private String userTypeName;
	
	/** The identity. */
	private String identity;
	
	/** The id. */
	private Integer id;

}

