package com.digitalpaper.transfer.object.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class StockTransactionHistory.
 */
@Entity
@Table(name="stock_trans_his")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class StockTransactionHistory {
	
	/** The stock transaction history id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "trans_id")
	private Integer stockTransactionHistoryId;
	
	/** The pool action type. */
	@Column(name="pool_action_type")
	private Integer poolActionType;
	
	/** The debited stock. */
	@Column(name="debit_stock")
	private Integer debitedStock;
	
	/** The credited stock. */
	@Column(name="credit_stock")
	private Integer creditedStock;
	
	/** The stock pool id. */
	@OneToOne
	@JoinColumn(name="pool_id")
	private StockPool stockPoolId;
	
	/** The stock id. */
	@OneToOne
	@JoinColumn(name="stock_id")
	private Stock stockId;
	
	/** The created by. */
	@Column(name="created_by")
	private Integer createdBy;
	
	/** The created date. */
	@Column(name="created_date")
	private LocalDateTime createdDate;
	
	/** The identity. */
	@Column(name = "identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;

}
