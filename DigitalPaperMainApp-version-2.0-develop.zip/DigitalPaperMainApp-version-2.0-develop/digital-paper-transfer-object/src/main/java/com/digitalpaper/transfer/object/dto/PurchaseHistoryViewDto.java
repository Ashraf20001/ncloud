package com.digitalpaper.transfer.object.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class PurchaseHistoryViewDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class PurchaseHistoryViewDto {

	/** The company name. */
	private String companyName;
	
	/** The total transactions. */
	private Long totalTransactions;
	
	/** The pending transactions. */
	private Long pendingTransactions;
}
