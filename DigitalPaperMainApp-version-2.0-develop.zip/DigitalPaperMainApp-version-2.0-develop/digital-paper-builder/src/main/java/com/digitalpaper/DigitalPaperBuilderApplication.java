package com.digitalpaper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DigitalPaperBuilderApplication {

	public static void main(String[] args) {
		SpringApplication.run(DigitalPaperBuilderApplication.class, args);
	}

}
