/*
 * @author codeboard
 */
package com.digitalpaper.config.model;

/**
 * The Interface CommonVo.
 */
public interface CommonVo {

}
