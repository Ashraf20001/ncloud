/*
 * @author codeboard
 */
package com.digitalpaper.config.property;

/**
 * The Enum DbType.
 */
public enum DbType {
	/**
	 * The master & TEST .
	 */
	MASTER, 
 /** The test. */
 TEST
}