/*
 * @author codeboard
 */
package com.digitalpaper.config.base.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * The Class BaseService.
 */
@Service
@Transactional(value = "transactionManager")
public class BaseService {

}
