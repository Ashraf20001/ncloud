package com.digitalpaper.config.property;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.digitalpaper.constants.core.PropertyConstants;
import com.digitalpaper.constants.serverproperties.PropertyValueProvider;
import com.digitalpaper.crypto.core.TwoWayEncryption;



/**
 * The Class EnvironmentProperties.
 */
@Configuration
public class EnvironmentProperties {

	
	/** The enc. */
	@Autowired
	private TwoWayEncryption enc;
	
	/** The configuration properties. */
	@Autowired
	private PropertyValueProvider configurationProperties;
	
	/** The data base name. */
	private String dataBaseName = "";

	/**
	 * Gets the data source url.
	 *
	 * @return the data source url
	 */
	public String getDataSourceUrl() {
		return configurationProperties.getMysqlDataSourceUrl();
	}
	
	/**
	 * Gets the driver name.
	 *
	 * @return the driver name
	 */
	public String getDriverName() {
		return configurationProperties.getMysqlDriver();
	}

	/**
	 * Gets the jdbc password.
	 *
	 * @return the jdbc password
	 */
	public String getJdbcPassword() {
		return enc.doDecryption(configurationProperties.getMysqlPassword());
	}
	
	/**
	 * Gets the jdbc url.
	 *
	 * @return the jdbc url
	 */
	public String getJdbcUrl() {
		String url = replaceDateBaseName(configurationProperties.getMysqlDataSourceUrl());
		System.out.println(url);
		url = url.replace(PropertyConstants.MAIN_APP_MYSQL_IP,
				configurationProperties.getMysqlIp());
		url = url.replace(PropertyConstants.MAIN_APP_MYSQL_PORT,
				configurationProperties.getMysqlPort());
		return url;
	}
	
	/**
	 * Gets the jdbc user.
	 *
	 * @return the jdbc user
	 */
	public String getJdbcUser() {
		return enc.doDecryption(configurationProperties.getMysqlUsername());
	}
	
	/**
	 * Gets the my sql date base.
	 *
	 * @return the my sql date base
	 */
	public String getMySqlDateBase() {
		if (dataBaseName.isEmpty()) {
			dataBaseName =configurationProperties.getMysqlDataBase();
		}
		return dataBaseName;
	}
	
	/**
	 * Gets the sql ip.
	 *
	 * @return the sql ip
	 */
	public String getSqlIp() {
		return enc.doDecryption(configurationProperties.getMysqlIp());
	}

	/**
	 * Gets the sql port.
	 *
	 * @return the sql port
	 */
	public String getSqlPort() {
		return  enc.doDecryption(configurationProperties.getMysqlPort());
	}

	/**
	 * Replace date base name.
	 *
	 * @param data the data
	 * @return the string
	 */
	public String replaceDateBaseName(String data) {
		data = data.replace(PropertyConstants.DB_NAME, getMySqlDateBase());
		return data;
	}
	
	/**
	 * Gets the jdbc driver.
	 *
	 * @return the jdbc driver
	 */
	public String getJdbcDriver() {
		return configurationProperties.getMysqlDriver();
	}
	
	/**
	 * Gets the time zone.
	 *
	 * @return the time zone
	 */
	public String getTimeZone() {
		return configurationProperties.getTimeZone();
	}
	
	/**
	 * Gets the date format.
	 *
	 * @return the date format
	 */
	public String getDateFormat() {
		return configurationProperties.getDateFormat();
	}
	
	/**
	 * Gets the time format.
	 *
	 * @return the time format
	 */
	public String getTimeFormat() {
		return configurationProperties.getTimeFormat();
	}
	
	/**
	 * Gets the currency format.
	 *
	 * @return the currency format
	 */
	public String getCurrencyFormat() {
		return configurationProperties.getCurrencyFormat();
	}
	
	/**
	 * Gets the number format.
	 *
	 * @return the number format
	 */
	public String getNumberFormat() {
		return configurationProperties.getNumberFormat();
	}
	
	/**
	 * Gets the country code.
	 *
	 * @return the country code
	 */
	public String getCountryCode() {
		return configurationProperties.getCountryCode();
	}
	
	/**
	 * Gets the file download url.
	 *
	 * @return the file download url
	 */
	public String getFileDownloadUrl() {
		return configurationProperties.getFileDownloadUrl();
	}

    /**
     * Gets the from E mail.
     *
     * @return the from E mail
     */
    public String getFromEMail() {
		return configurationProperties.getSpringMailUsername();
    }

    /**
     * Gets the file upload path.
     *
     * @return the file upload path
     */
    public String getFileUploadPath() {
		return configurationProperties.getFileUploadPath();
    }
    
    /**
     * Gets the send email name.
     *
     * @return the send email name
     */
    public String getSendEmailName() {
		return configurationProperties.getSendEmailName();
    }

	/**
	 * Gets the common service path.
	 *
	 * @return the common service path
	 */
	public String getCommonServicePath() {
		return configurationProperties.getCommonServicePath();
	}

	/**
	 * Gets the url.
	 *
	 * @return the url
	 */
	public String getUrl() {
		return configurationProperties.getFrontendUrl();
	}
	
	/**
	 * Gets the digital paper file path.
	 *
	 * @return the digital paper file path
	 */
	public String getDigitalPaperFilePath() {
		return configurationProperties.getDpDownloadUrl();
	}
	
	/**
	 * Gets the digital paper email template.
	 *
	 * @return the digital paper email template
	 */
	public String getDigitalPaperEmailTemplate() {
		return configurationProperties.getDigitalEmailTemplate();
	}
	
	/**
	 * Gets the customer email template.
	 *
	 * @return the customer email template
	 */
	public String getCustomerEmailTemplate() {
		return configurationProperties.getCustomerEmailTemplate();
	}
	
	/**
	 * Gets the gate way path.
	 *
	 * @return the gate way path
	 */
	public String getGateWayPath() {
		return configurationProperties.getGatewayPath();
	}
	
	/**
	 * Gets the customer portal url.
	 *
	 * @return the customer portal url
	 */
	public String getCustomerPortalUrl() {
		return configurationProperties.getCustomerPortalUrl();
	}
	
	/**
	 * Gets the og template url.
	 *
	 * @return the og template url
	 */
	public String getOgTemplateUrl() {
		return configurationProperties.getDpOgTemplatePath();
	}
	
	 /**
 	 * Gets the mysql max idle timeout.
 	 *
 	 * @return the mysql max idle timeout
 	 */
 	public String getMysqlMaxIdleTimeout() {
			return configurationProperties.getMysqlMaxIdleTimeout();
		}

		/**
		 * Gets the mysql max idle time excess connections.
		 *
		 * @return the mysql max idle time excess connections
		 */
		public String getMysqlMaxIdleTimeExcessConnections() {
			return configurationProperties.getMysqlMaxIdleExcessConnections();
		}

		/**
		 * Gets the mater connection on checkout.
		 *
		 * @return the mater connection on checkout
		 */
		public Boolean getMaterConnectionOnCheckout() {
			return Boolean.valueOf(configurationProperties.getMysqlConnectionCheckout());
		}

		/**
		 * Gets the mysql min pool size.
		 *
		 * @return the mysql min pool size
		 */
		public String getMysqlMinPoolSize() {
			return configurationProperties.getMysqlMinPoolsize();
		}

		/**
		 * Gets the mysql max pool size.
		 *
		 * @return the mysql max pool size
		 */
		public String getMysqlMaxPoolSize() {
			return configurationProperties.getMysqlMaxPoolSize();
		}
		
		/**
		 * Gets the mysql idle connection test period.
		 *
		 * @return the mysql idle connection test period
		 */
		public String getMysqlIdleConnectionTestPeriod() {
			return configurationProperties.getMysqlIdleConnectionTestperiod();
		}
}