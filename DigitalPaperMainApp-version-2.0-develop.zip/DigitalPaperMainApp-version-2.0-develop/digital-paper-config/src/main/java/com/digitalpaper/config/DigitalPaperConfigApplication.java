package com.digitalpaper.config;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * The Class DigitalPaperConfigApplication.
 */
@SpringBootApplication
@ComponentScan("com.digitalpaper.*")
public class DigitalPaperConfigApplication {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {

	}

}
