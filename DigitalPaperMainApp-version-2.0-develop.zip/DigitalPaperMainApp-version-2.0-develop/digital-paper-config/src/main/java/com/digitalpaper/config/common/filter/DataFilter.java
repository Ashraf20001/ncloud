/*
 * @author codeboard
 */
package com.digitalpaper.config.common.filter;

import java.util.List; 

import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.utils.core.ApplicationUtils;




/**
 * The Interface DataFilter.
 */
public interface DataFilter {

	/**
	 * Gets the filter.
	 *
	 * @param root the root
	 * @param key  the key
	 * @return the filter
	 */
	Predicate getFilter(Root<?> root, Object key);

	/**
	 * Gets the predicate.
	 *
	 * @param dataFilterRegisty object to get filter column name
	 * @param root              Root for the entity class do we want to add filters
	 * @param filterNameEnum    which filter to get from data filter registry map
	 * @param args              profile id's to add filters
	 * @param key               entity class object for we want to add filters
	 * @return Predicate to add some restrictions in profile.
	 */
	default Predicate getPredicate(DataFilterRegistry dataFilterRegisty, Root<?> root, FilterNameEnum filterNameEnum,
			List<?> args, Object key) {
		String[] referenceNames = dataFilterRegisty.getDataFilters(key).get(filterNameEnum)
				.split(ApplicationConstants.DOT_REGEX);
		Path<String> expression = root.get(referenceNames[0]);
		if (referenceNames.length > 1) {
			expression = expression.get(referenceNames[1]);
		}
		Predicate predicate = null;
		if (ApplicationUtils.isValidList(args)) {
			predicate = expression.in(args);
		} else {
			predicate = expression.in(ApplicationConstants.MINUS_ONE);
		}
		return predicate;
	}

}
