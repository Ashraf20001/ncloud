/*
 * @author codeboard
 */
package com.digitalpaper.config.property;

import java.util.Properties; 

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * The Class HibernateProperties.
 */
@Component
@ConfigurationProperties(prefix = "mainapp.hibernate")
public class HibernateProperties {

	/**
	 * The acquire increment.
	 */
	@Value("${hibernate.c3p0.acquire_increment}")
	private int acquireIncrement;

	/**
	 * The c 3 p 0 idle test period.
	 */
	@Value("${hibernate.c3p0.idle_test_period}")
	private int c3p0IdleTestPeriod;

	/**
	 * The c 3 p 0 max size.
	 */
	@Value("${hibernate.c3p0.max_size}")
	private int c3p0MaxSize;

	/**
	 * The c 3 p 0 max statements.
	 */
	@Value("${hibernate.c3p0.max_statements}")
	private int c3p0MaxStatements;

	/**
	 * The c 3 p 0 min size.
	 */
	@Value("${hibernate.c3p0.min_size}")
	private int c3p0MinSize;

	/**
	 * The c 3 p 0 time out.
	 */
	@Value("${hibernate.c3p0.timeout}")
	private int c3p0TimeOut;

	/**
	 * The connection provider.
	 */
	@Value("${connection.provider_class}")
	private String connectionProvider;

	/**
	 * The my sql dialect.
	 */
	@Value("${hibernate.dialect}")
	private String mySqlDialect;

	/**
	 * The show sql.
	 */
	@Value("${hibernate.show_sql}")
	private String showSql;

	/**
	 * Gets the hibernate properties.
	 *
	 * @return the hibernate properties
	 */
	public Properties getHibernateProperties() {
		Properties properties = new Properties();
		properties.put("hibernate.show_sql", showSql);
		properties.put("hibernate.dialect", mySqlDialect);
		properties.put("connection.provider_class", connectionProvider);
		properties.put("hibernate.c3p0.min_size", c3p0MinSize);
		properties.put("hibernate.c3p0.max_size", c3p0MaxSize);
		properties.put("hibernate.c3p0.acquire_increment", acquireIncrement);
		properties.put("hibernate.c3p0.idle_test_period", c3p0IdleTestPeriod);
		properties.put("hibernate.c3p0.max_statements", c3p0MaxStatements);
		properties.put("hibernate.c3p0.timeout", c3p0TimeOut);
		return properties;
	}

	/**
	 * Sets the acquire increment.
	 *
	 * @param acquireIncrement the new acquire increment
	 */
	public void setAcquireIncrement(int acquireIncrement) {
		this.acquireIncrement = acquireIncrement;
	}

	/**
	 * Sets the c 3 p 0 idle test period.
	 *
	 * @param c3p0IdleTestPeriod the new c 3 p 0 idle test period
	 */
	public void setC3p0IdleTestPeriod(int c3p0IdleTestPeriod) {
		this.c3p0IdleTestPeriod = c3p0IdleTestPeriod;
	}

	/**
	 * Sets the c 3 p 0 max size.
	 *
	 * @param c3p0MaxSize the new c 3 p 0 max size
	 */
	public void setC3p0MaxSize(int c3p0MaxSize) {
		this.c3p0MaxSize = c3p0MaxSize;
	}

	/**
	 * Sets the c 3 p 0 max statements.
	 *
	 * @param c3p0MaxStatements the new c 3 p 0 max statements
	 */
	public void setC3p0MaxStatements(int c3p0MaxStatements) {
		this.c3p0MaxStatements = c3p0MaxStatements;
	}

	/**
	 * Sets the c 3 p 0 min size.
	 *
	 * @param c3p0MinSize the new c 3 p 0 min size
	 */
	public void setC3p0MinSize(int c3p0MinSize) {
		this.c3p0MinSize = c3p0MinSize;
	}

	/**
	 * Sets the c 3 p 0 time out.
	 *
	 * @param c3p0TimeOut the new c 3 p 0 time out
	 */
	public void setC3p0TimeOut(int c3p0TimeOut) {
		this.c3p0TimeOut = c3p0TimeOut;
	}

	/**
	 * Sets the connection provider.
	 *
	 * @param connectionProvider the new connection provider
	 */
	public void setConnectionProvider(String connectionProvider) {
		this.connectionProvider = connectionProvider;
	}

	/**
	 * Sets the my sql dialect.
	 *
	 * @param mySqlDialect the new my sql dialect
	 */
	public void setMySqlDialect(String mySqlDialect) {
		this.mySqlDialect = mySqlDialect;
	}

	/**
	 * Sets the show sql.
	 *
	 * @param showSql the new show sql
	 */
	public void setShowSql(String showSql) {
		this.showSql = showSql;
	}

}
