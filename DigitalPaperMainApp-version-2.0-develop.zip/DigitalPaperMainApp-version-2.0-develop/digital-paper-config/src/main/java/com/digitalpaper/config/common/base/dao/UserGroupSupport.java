/*
 * @author codeboard
 */
package com.digitalpaper.config.common.base.dao;

/**
 * The Class UserGroupSupport.
 */
public abstract interface UserGroupSupport {


}
