/*
 * @author codeboard
 */
package com.digitalpaper.config.property;

import java.util.HashMap; 
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

/**
 * The Class RoutingDataSource.
 */
@Configuration
@Qualifier("dataSource")
public class RoutingDataSource extends AbstractRoutingDataSource {

	/**
	 * The Constant log.
	 */
	private static final Logger log = LoggerFactory.getLogger(RoutingDataSource.class);

	/**
	 * The master data source.
	 */
	@Autowired
	@Qualifier("masterDataSource")
	private DataSource masterDataSource;

	/**
	 * Determine current lookup key.
	 *
	 * @return the object
	 */
	@Override
	protected Object determineCurrentLookupKey() {
		log.info(">>> determineCurrentLookupKey thread: {}", Thread.currentThread().getName());
		log.info(">>> RoutingDataSource: {}", DbContextHolder.getDbType());
		return DbContextHolder.getDbType();
	}

	/**
	 * Ser data sources.
	 */
	@PostConstruct
	public void serDataSources() {
		Map<Object, Object> targetDataSources = new HashMap<>();
		targetDataSources.put(DbType.MASTER, masterDataSource);
		setTargetDataSources(targetDataSources);
		setDefaultTargetDataSource(masterDataSource);
	}

}
