/*
 * @author codeboard
 */
package com.digitalpaper.config.model;

import java.util.List;

import com.digitalpaper.constants.core.ApplicationConstants;
import com.fasterxml.jackson.annotation.JsonProperty;


import lombok.Data;

/**
 * Instantiates a new filter or sorting vo.
 */
@Data
public class FilterOrSortingVo {

	/**
	 * The column name.
	 */
	private String columnName;

	/**
	 * The condition.
	 */
	private String condition;

	/**
	 * The filter or sorting type.
	 */
	private String filterOrSortingType = ApplicationConstants.FILTER; // or SORTING

	/**
	 * The intger value list.
	 */
	private List<Integer> intgerValueList; // for status multiset

	/**
	 * The is ascending.
	 */
	/* sorting purpose below to two fields */
	@JsonProperty("isAscending")
	private boolean isAscending;

	/**
	 * The type.
	 */
	private String type;

	/**
	 * The value.
	 */
	private String value;

	/**
	 * The value 2.
	 */
	private String value2;
	
	/**
	 * Value list
	 */
	private List<String> valueList;
}
