package com.digitalpaper.constants.core;

import java.util.ArrayList;

/**
 * The Class NegativeFlowList.
 */
public class NegativeFlowList {

/** The Constant negativeStatusList. */
public static final ArrayList<String> negativeStatusList=new ArrayList<>();

static {
	negativeStatusList.add(RecoveryStatusConstant.NEEDMOREDETAIL);
	negativeStatusList.add(RecoveryStatusConstant.DISPUTE);
	
}

}
