package com.digitalpaper.constants.externalApi.core;

/**
 * The Class ExternalDocumentTypeConstant.
 */
public class ExternalDocumentTypeConstant {
	
	/** The Constant POLICE_REPORT. */
	public static final String POLICE_REPORT="Police report";
	
	/** The Constant GARAGE_INVOICE. */
	public static final String GARAGE_INVOICE="Garage Invoice";
	
	/** The Constant DEBIT_NOTE. */
	public static final String DEBIT_NOTE="Debit Note";
	
	/** The Constant CREDIT_NOTE. */
	public static final String CREDIT_NOTE="Credit Note";
	
	/** The Constant SURVEY_REPORT. */
	public static final String SURVEY_REPORT="Survey Report Upload";

}
