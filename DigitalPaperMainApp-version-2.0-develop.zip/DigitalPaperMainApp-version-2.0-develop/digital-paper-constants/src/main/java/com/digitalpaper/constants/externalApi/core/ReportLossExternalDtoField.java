package com.digitalpaper.constants.externalApi.core;


/**
 * The Class ReportLossExternalDtoField.
 */
public class ReportLossExternalDtoField {
	
	/** The Constant STATUS. */
	//claimDetails
	public static final String STATUS= "status";

	/** The Constant POLICYNUMBER. */
	//InsurerInfo AND ThirdPartyInfoExternalDto
	public static final String POLICYNUMBER="policyNumber";
	
	/** The Constant COMPANYID. */
	//companyExternalDto
	public static final String COMPANYID = "companyId";
	
	/** The Constant NAME. */
	public static final String NAME = "name";
	
	/** The Constant SHORTNAME. */
	public static final String SHORTNAME = "shortName";

	/** The Constant REGISTRATION_NO. */
	//Vechile External dto
	public static final String REGISTRATION_NO ="registrationNo";

	/** The Constant MODEL. */
	public static final String MODEL="model";

	/** The Constant MAKE. */
	public static final String MAKE="make";

	/** The Constant REGISTRATION_TYPE. */
	public static final String REGISTRATION_TYPE="registrationType";

	/** The Constant PURCHASE_DATE. */
	public static final String PURCHASE_DATE="purchaseDate";

	/** The Constant SUM_INSURED. */
	public static final String SUM_INSURED="sumInsured";
      
	/** The Constant ID. */
	public static final String ID= "id";

	/** The Constant FNOL_NO. */
	public static final String FNOL_NO = "fnolNo";

	/** The Constant CLAIM_REF_NO. */
	public static final String CLAIM_REF_NO = "claimRefNo";

	/** The Constant RECOVERY_LETTER. */
	public static final String RECOVERY_LETTER = "recoveryLetter";

	/** The Constant DATE_OF_LOSS. */
	public static final String DATE_OF_LOSS = "dateOfloss";

	/** The Constant DATE_OF_REPORTED. */
	public static final String DATE_OF_REPORTED = "dateOfReported";

	/** The Constant POLICE_REPORT_NO. */
	public static final String POLICE_REPORT_NO = "policeReportNo";

	/** The Constant INSURED_CLAIM_NO. */
	public static final String INSURED_CLAIM_NO = "insuredClaimNo";

	/** The Constant THIRD_PARTY_CLAIM_NO. */
	public static final String THIRD_PARTY_CLAIM_NO = "thirdPartyClaimNo";
	  
	/** The Constant NATURE_OF_LOSS. */
	public static final String NATURE_OF_LOSS ="natureOfLoss";

	/** The Constant RESERVE_AMOUNT. */
	public static final String RESERVE_AMOUNT="reserveAmount";

	/** The Constant TOTAL_RESERVE_AMOUNT. */
	public static final String TOTAL_RESERVE_AMOUNT="totalReserveAmount";

	/** The Constant THIRD_PARTY_RESERVE_AMOUNT. */
	public static final String THIRD_PARTY_RESERVE_AMOUNT="thirdPartyReserveAmount";

	/** The Constant ESTIMATED_TOTALLOSS. */
	public static final String ESTIMATED_TOTALLOSS="estimatedTotalLossAmount";

	/** The Constant SURVEY_ESTIMATED_AMOUNT. */
	public static final String SURVEY_ESTIMATED_AMOUNT="surveyEstimatedAmount";

	/** The Constant CLAIM_AMOUNT. */
	public static final String CLAIM_AMOUNT="claimAmount";

	/** The Constant SETTLE_AMOUNT. */
	public static final String SETTLE_AMOUNT="settleAmount";

	/** The Constant THIRD_PARTY_SETTLES_AMOUNT. */
	public static final String THIRD_PARTY_SETTLES_AMOUNT="thirdPartySettleAmount";	
	
	/** The Constant SPARE_PARTS. */
	public static final String SPARE_PARTS="sparePartCost";	
	
	/** The Constant LABOUR_COSR. */
	public static final String LABOUR_COSR="labourCost";	
	
	//garage
	

	/** The Constant TYPE. */
	public static final String TYPE="type";

	/** The Constant ADDRESS_LOCATION. */
	public static final String ADDRESS_LOCATION="addressLocation";

	/** The Constant SURVEY_ALLOCATION_DATE. */
	public static final String SURVEY_ALLOCATION_DATE="surveyAllocationDate";

	/** The Constant SURVEY_DUE_DATE. */
	public static final String SURVEY_DUE_DATE="surveyDueDate";
	
	/** The Constant CONTACT_NAME. */
	public static final String CONTACT_NAME="contactName";

	/** The Constant CONTACT_PHONE. */
	public static final String CONTACT_PHONE="contactPhone";

	/** The Constant EMAIL_ADDRESS. */
	public static final String EMAIL_ADDRESS="emailAddress";
	
	
	
	
	/** The Constant DOCUMENT_ID. */
	//Document List
	public static final String DOCUMENT_ID="documentId";
	
	/** The Constant CATEGORY. */
	public static final String CATEGORY="category";
	
	/** The Constant CONTENT_TYPE. */
	public static final String CONTENT_TYPE="contentType";
	
	/** The Constant DOCUMENT. */
	public static final String DOCUMENT="document";
	
	/** The Constant DOC_REF_NO. */
	public static final String DOC_REF_NO="docRefNo";
	
	/** The Constant DOCUMENT_URL. */
	public static final String DOCUMENT_URL="documentUrl";
	
	/** The Constant UPLOADED_DATE_TIME. */
	public static final String UPLOADED_DATE_TIME="uploadedDateTime";

	
	
	
	/** The Constant INSURED_INFO. */
	//entity variable name
	public static final String  INSURED_INFO= "insuredInfo";
	
	/** The Constant THIRD_PARTY_INFO. */
	public static final String  THIRD_PARTY_INFO= "thirdPartyInfo";
	
	/** The Constant GARAGE_INFO. */
	public static final String  GARAGE_INFO= "garageInfo";
	
	/** The Constant COMPANY. */
	public static final String  COMPANY= "company";
	
	/** The Constant VECHILE_INFO. */
	public static final String  VECHILE_INFO= "vehicleDetails";
	
	/** The Constant TOTALLOSSDETAILS. */
	public static final String  TOTALLOSSDETAILS= "totalLossDetails";

	
	//TotalLoss External fields
	
	/** The Constant CLAIM_ID. */
	public static final String  CLAIM_ID= "claimId";
	
	/** The Constant SEQUENCE_NO. */
	public static final String  SEQUENCE_NO= "sequenceNo";
	
	/** The Constant ADJUSTORNAMEONE. */
	public static final String  ADJUSTORNAMEONE= "adjustorNameOne";
	
	/** The Constant ADJUSTORNAMETWO. */
	public static final String  ADJUSTORNAMETWO= "adjustorNameTwo";
	
	/** The Constant SURVEYDATEONE. */
	public static final String  SURVEYDATEONE= "surveyDateOne";
	
	/** The Constant SURVEYDATETWO. */
	public static final String  SURVEYDATETWO= "surveyDateTwo";
	
	/** The Constant TOTALOSSAMOUNTONE. */
	public static final String  TOTALOSSAMOUNTONE= "totalLossAmountOne";
	
	/** The Constant TOTALLOSSAMOUNTTWO. */
	public static final String  TOTALLOSSAMOUNTTWO= "totalLossAmountTwo";
	
	/** The Constant REASONFORTOTALLOSS. */
	public static final String  REASONFORTOTALLOSS= "reasonForTotalLoss";
	
	/** The Constant ESTIMATEDTOTALLOSS. */
	public static final String  ESTIMATEDTOTALLOSS= "estimatedTotalLossAmount";
	
	/** The Constant SLAVAGESELLERNAME. */
	public static final String  SLAVAGESELLERNAME= "salvageSellerName";
	
	/** The Constant SALVAGEAMOUNT. */
	public static final String  SALVAGEAMOUNT= "salvageAmount";
	
	/** The Constant SALVAGEBUYERNAME. */
	public static final String  SALVAGEBUYERNAME= "salvageBuyerName";
	
	
	



}
