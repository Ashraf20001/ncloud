/*
\ * @author codeboard
 */
package com.digitalpaper.constants.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * The Class ApplicationConstants.
 */
public class ApplicationConstants {

	/** The Constant FORCE_DOWNLOAD. */
	public static final String FORCE_DOWNLOAD = "force-download";
	
	/** The Constant APPLICATION. */
	public static final String APPLICATION = "application";
	
	/** The Constant ALL. */
	public static final String ALL = "ALL";
	
	/** The Constant PDF_FORMATE. */
	public static final String PDF_FORMATE = "attachment; filename=ProductTemplate.pdf";

	/** The Constant APPLICATION_VND_MS_EXCEL. */
	public static final String APPLICATION_VND_MS_EXCEL = "application/vnd.ms-excel";

	/** The Constant UNDERSCORE. */
	public static final String UNDERSCORE = "_";


	/** The Constant AUTHORIZATION. */
	public static final String AUTHORIZATION = "Authorization";

	/** The Constant BEARER. */
	public static final String BEARER = "Bearer ";

	/**
	 * The Constant BETWEEN.
	 */
	public static final String BETWEEN = "BW";
	
	/** The Constant USER_ROLE_MAPPING. */
	public static final String USER_ROLE_MAPPING  = "UserRoleMapping";

	/**
	 * The Constant DOT_REGEX.
	 */
	public static final String DOT_REGEX = "\\.";

	/**
	 * The Constant EMPTY_STRING.
	 */
	public static final String EMPTY_STRING = " ";

	/**
	 * The Constant EQUAL.
	 */
	public static final String EQUAL = "Equal";

	/**
	 * The Constant FILTER.
	 */
	public static final String FILTER = "FILTER";

	/**
	 * The Constant FILTER_TYPE_BOOLEAN.
	 */
	public static final String FILTER_TYPE_BOOLEAN = "Boolean";

	/**
	 * The Constant FILTER_TYPE_DATE.
	 */
	public static final String FILTER_TYPE_DATE = "Date";

	/**
	 * The Constant FILTER_TYPE_DOUBLE.
	 */
	public static final String FILTER_TYPE_DOUBLE = "Double";

	/**
	 * The Constant FILTER_TYPE_INTEGER.
	 */
	// ******* for common filter constants start
	public static final String FILTER_TYPE_INTEGER = "Integer";

	/**
	 * The Constant FILTER_TYPE_TEXT.
	 */
	public static final String FILTER_TYPE_TEXT = "String";


	/**
	 * The Constant GT.
	 */
	public static final String GT = "Gt";

	/**
	 * The Constant GTE.
	 */
	public static final String GTE = "Ge";

	/**
	 * The Constant IDENTITY.
	 */
	public static final String IDENTITY = "Identity";

	/**
	 * The Constant IDENTITY_CONSTANT.
	 */
	public static final String IDENTITY_CONSTANT = "identity";

	/** The Constant INACTIVE. */
	public static final String INACTIVE = "InActive";

	/** The Constant INSTITUTION_ID. */
	public static final String INSTITUTION_ID = "InstitutionId";

	/**
	 * The Constant LIKE.
	 */
	public static final String LIKE = "Like";


	/** The Constant IN. */
	public static final String IN = "IN";

	/**
	 * The Constant LT.
	 */
	public static final String LT = "Lt";

	/**
	 * The Constant LTE.
	 */
	public static final String LTE = "Le";

	/**
	 * The Constant MINUS_ONE.
	 */
	public static final String MINUS_ONE = "-1";

	/**
	 * The Constant ONE.
	 */
	public static final int ONE = 1;

	/**
	 * The Constant ORDERBY.
	 */
	public static final String ORDERBY = "orderBy";

	/** The Constant RLE_ACTIVE. */
	public static final String RLE_ACTIVE = "Active";
	
	/** The Constant SAVED_SUCCESS. */
	public static final String SAVED_SUCCESS = "Saved Successfully.";
	
	/** The Constant STOCK_SAVED_SUCCESS. */
	public static final String STOCK_SAVED_SUCCESS = "Approved Successfully";
	
	/** The Constant STOCK_REQUEST_SUCCESS. */
	public static final String STOCK_REQUEST_SUCCESS = "Request Declined";
	/**
	 * The Constant ROUNDOFF.
	 */
	public static final String ROUNDOFF = "ROUNDOFF";

	/** The Constant SET_IDENTITY. */
	public static final String SET_IDENTITY = "setIdentity";

	/**
	 * The Constant SLASH.
	 */
	public static final String SLASH = "/";

	/**
	 * The Constant SORTING.
	 */
	public static final String SORTING = "SORTING";

	/**
	 * The Constant TOO_MANY_REQUEST_FOUND.
	 */
	public static final String TOO_MANY_REQUEST_FOUND = "Too Many Request found for the input URL : ";

	/**
	 * The Constant SEMI_COLON.
	 */
	public static final String WITHOUT_SPACE = "";

	/**
	 * The Constant ZERO.
	 */
	public static final int ZERO = 0;

	/** The Constant valid. */
	public static final String valid = "valid Email Id";

	/** The Constant UPDATE_SUCCESS. */
	public static final String UPDATE_SUCCESS = "Update password successfull";

	/** The Constant NULL. */
	public static final String NULL = "null";

	/** The Constant AUTHORITY_LOGIN. */
	public static final String AUTHORITY_LOGIN = "ADMIN";
	
	/** The Constant PNG. */
	public static final String PNG = ".png";
	
	/** The Constant JPG. */
	public static final String JPG = ".jpg";
	
	/** The Constant PDF. */
	public static final String PDF = ".pdf";

	/**
	 * WEBSOCKET ENDPOINT
	 */
	public static final String WEBSOCKET_ENDPOINT = "/topic/notification/";

	/** The Constant DEFAULT_DATE_FORMAT. */
	/*
	 * Date formate contant.
	 */
	public static final String DEFAULT_DATE_FORMAT = "MM/dd/yyyy";

	/**
	 * COMPANY_NAME
	 */
	public static final String COMPANY_NAME = "COMPANY_NAME";

	/**
	 * STOCK_NUMBER
	 */
	public static final String STOCK_COUNT = "STOCK_COUNT";

	/** The Constant REPORTS. */
	public static final String REPORTS = "REPORT";

	/** The Constant PURCHASE_STOCK. */
	public static final String PURCHASE_STOCK = "PURCHASE STOCK";

	/** The Constant INSURANCE_COMPANY_CAP. */
	public static final String INSURANCE_COMPANY_CAP = "INSURANCE_COMPANY";

	/** The Constant ASSOCIATION. */
	public static final String ASSOCIATION = "ASSOCIATION";

	/** The Constant REJECTED. */
	public static final String REJECTED ="Rejected";

	/** The Constant STOCK_PURCHASE. */
	public static final String STOCK_PURCHASE= "purchase_stock";
	
	/** The Constant PAPER_EXPIRE. */
	public static final String PAPER_EXPIRE= "paper_expiration";
	
	
	/** The Constant REST_CALL_URL. */
	public static final String REST_CALL_URL ="/auth/getLoginUserDetails";
	
	/** The Constant ID. */
	public static final String ID = "id";

	/** The Constant USER_NAME. */
	public static final String USER_NAME = "user_name";

	/** The Constant EMAIL. */
	public static final String EMAIL = "email";

	/** The Constant USER_TYPE. */
	public static final String USER_TYPE = "user_type";

	/** The Constant ROLES. */
	public static final String ROLES = "roles";

	/** The Constant PLATFORM_IDENTITY. */
	public static final String PLATFORM_IDENTITY = "platform_identity";

	/** The Constant PLATFORM_DETAILS. */
	public static final String PLATFORM_DETAILS = "platform_details";

	/** The Constant ALL_COMPANY_NAME. */
	public static final String ALL_COMPANY_NAME = "All Companies";

	/** The Constant COMPANY_ID. */
	public static final String COMPANY_ID = "company_id";

	/** The Constant PAYMENT_METHOD_COLUMN. */
	public static final String PAYMENT_METHOD_COLUMN ="paymentMethod";

	/** The Constant COMPANY_FILTER_COLUMN_NAME. */
	public static final String COMPANY_FILTER_COLUMN_NAME ="orderId.companyId";
	
	/** The Constant FILTER_COLUMN_NAME. */
	public static final String FILTER_COLUMN_NAME = "companyId";
	/**
	 * Puchase order Status
	 */
	public static final String SUBMITTED ="SUBMITTED";
	
	/** The Constant SUCCESS. */
	public static final String SUCCESS ="SUCCESS";
	
	/** The Constant FAILED. */
	public static final String FAILED ="FAILED";
	
	/** The Constant UPDATE_SUCESS. */
	public static final String UPDATE_SUCESS  = "Updated Successfully!!";

	/** The Constant COMPANY_COUNT. */
	public static final String COMPANY_COUNT="/api/entitymanagement/getInsuranceDataCount";

	/** The Constant COMPANY_LIST. */
	public static final String COMPANY_LIST = "/api/entitymanagement/get-all-company";

	/** The Constant ALLOCATE. */
	public static final String ALLOCATE = "ALLOCATE";
	
	/** The Constant DEALLOCATE. */
	public static final String DEALLOCATE = "DEALLOCATE";
	
	/** The Constant REALLOCATE. */
	public static final String REALLOCATE = "REALLOCATE";

	/** The Constant USER_TYPE_PATH. */
	public static final String USER_TYPE_PATH = "/user-role/get-user-type";

	/** The Constant USER_TYPE_NAME. */
	public static final String USER_TYPE_NAME = "userTypeName";

	/** The Constant COMPANY_LOGO. */
	public static final String COMPANY_LOGO = "/api/getCompanyLog";
	
	/** The Constant TOTAL_TRANSACTIONS. */
	public static final String TOTAL_TRANSACTIONS = "Total Transactions";
	
	/** The Constant PENDING_TRANSACTIONS. */
	public static final String PENDING_TRANSACTIONS = "Pending Transactions";
	
	/** The Constant PD_STATUS. */
	public static final String PD_STATUS = "status";

	/** The Constant SUFFIX. */
	public static final String SUFFIX = "Suffix";
	
	/** The Constant PREFIX. */
	public static final String PREFIX = "Prefix";
	
	/** The Constant OFFLINE_PAYMENT. */
	public static final List<String> OFFLINE_PAYMENT = new ArrayList<>(Arrays.asList("CHEQUE","CASH"));
	
	/** The Constant STR_ERR_START. */
	public static final String STR_ERR_START = "errorMessage\":";
	
	/** The Constant STR_ERR_END. */
	public static final String STR_ERR_END = ",\"hints";
	
	/** The Constant ERR_INVALID. */
	public static final String ERR_INVALID = "Invalid";
	
	/** The Constant UPDATE_BULK_HISTORY_PATH. */
	public static final String UPDATE_BULK_HISTORY_PATH = "/auth/paper-details/bulk-import/update-import-history";
	
	/** The Constant DIGITALPAPER_DTO_TO_FIELDGROUP. */
	public static final String DIGITALPAPER_DTO_TO_FIELDGROUP = "/didgitalPaper-dto-to-fieldGroup";

	/** The Constant GET_SYSTEM_PROPERTY_URL. */
	public static final String GET_SYSTEM_PROPERTY_URL = "/get-systemproperty-value";
	
	/** The Constant COMMON_SYSTEM_PROPERTY_URL. */
	public static final String COMMON_SYSTEM_PROPERTY_URL="/api/get-systemproperty-value";
	
	/** The Constant GET_ALL_COMPANY. */
	public static final String GET_ALL_COMPANY = "/get-allCompanyList";
	
	/** The Constant ALL_API_PRIVILEGE. */
	public static final String ALL_API_PRIVILEGE = "/allApiPrivilege";
	
	/** The Constant CLEAR_CACHE_URLS. */
	public static final List<String> CLEAR_CACHE_URLS = Arrays.asList("/digital-paper/clear-cache","/digital-paper/clear-cache-system-property"
																		,"/digital-paper/clear-cache-companyList","/digital-paper/clear-make-model-usage-cache");
																	
	/** The Constant SWAGGER_API_URLS. */
	public static final List<String> SWAGGER_API_URLS = Arrays.asList("/digital-paper/webjars/springfox-swagger-ui/swagger-ui-bundle.js","/digital-paper/webjars/springfox-swagger-ui/springfox.js",
			"/digital-paper/error","/digital-paper/webjars/springfox-swagger-ui/favicon-32x32.png","/digital-paper/webjars/springfox-swagger-ui/favicon-16x16.png","/digital-paper/swagger-resources/configuration/security"
			,"/digital-paper/swagger-resources");
	
	/** The Constant SWAGGER. */
	public static final String SWAGGER="swagger";
	
	/** The Constant ALLOCATION_USER_TYPE. */
	public static final String ALLOCATION_USER_TYPE="allocationUserType";
	
	/** The Constant NORMAL. */
	public static final String NORMAL="NORMAL";
	
	/** The Constant YEAR. */
	public static final String YEAR="Year";
	
	/** The Constant FLEET. */
	public static final String FLEET="FLEET";
	
	/** The Constant UPLOAD. */
	public static final String UPLOAD= "UPLOAD";
	
	/** The Constant NO_PAPER_FOUND. */
	public static final String NO_PAPER_FOUND= "No digital paper found";
	
	/** The Constant PAPER_REVOKED. */
	public static final String PAPER_REVOKED= "Digital paper Revoked";
	
	/** The Constant PAPER_ALREADY_IN. */
	public static final String PAPER_ALREADY_IN= "Digital paper already in ";
	
	/** The Constant CONDITION. */
	public static final String CONDITION= " condition";
	
	/** The Constant INVALID_FLEET_UPLOAD. */
	public static final String INVALID_FLEET_UPLOAD= "Invalid Fleet upload, Fleet Policy number should be: ";

	/** The Constant REPORT_LOSS. */
	public static final String REPORT_LOSS = "reportloss";
	
	/** The Constant FIELD_DATA_LIST. */
	public static final String FIELD_DATA_LIST = "/api/paper-details/get-field-data";
	
	/** The Constant ALLOCATION_TYPE_URL. */
	public static final String ALLOCATION_TYPE_URL = "/api/system-property/get-property-value";
	
	/** The Constant UPD_TYPE. */
	public static final String UPD_TYPE = "PPR_GEN";
	
	/** The Constant RP_TYPE. */
	public static final String RP_TYPE = "digital-paper";
	
	/** The Constant FLEET_POL_NO_MISMATCH. */
	public static final String FLEET_POL_NO_MISMATCH = "Policy number mismatch  in fleet upload" ;
	
	/** The Constant POL_NO_MISMATCH. */
	public static final String POL_NO_MISMATCH = "Policy number mismatch" ;
	
	/** The Constant PAPER_CREATION_FAILED. */
	public static final String PAPER_CREATION_FAILED = "paper creation failed" ;
	
	/** The Constant ERROR_MESSAGE. */
	public static final String ERROR_MESSAGE="Error Message";
	
	/** The Constant ERROR_FIELDS. */
	public static final String ERROR_FIELDS="Error Fields";
	
	/** The Constant BULK_IMPORT_HISTORY_ID. */
	public static final String BULK_IMPORT_HISTORY_ID = "Bulk Import History Id";

	/** The Constant DIGITAL_PAPER_NUMBER. */
	public static final String DIGITAL_PAPER_NUMBER = "Digital Paper Number";
	
	/** The Constant POLICY_NUMBER. */
	public static final String POLICY_NUMBER = "Policy Number";
	
	/** The Constant INSURED_COMPANY. */
	public static final String INSURED_COMPANY = "Insurance Company";
	
	/** The Constant AVAILABLE_STOCK. */
	public static final String AVAILABLE_STOCK = "Available Stock";

	/** The Constant COMPANYNAME. */
	public static final String COMPANYNAME = "Company Name";
	
	/** The Constant TAB_DIGITAL_PAPER_NO. */
	public static final String TAB_DIGITAL_PAPER_NO="Digital Paper No";
	
    /**
     * Instantiates a new application constants.
     */
    private ApplicationConstants() {
		}

	/** The Constant BULK_REVOKE. */
	public static final String BULK_REVOKE = "Bulk Revoke";

	/** The Constant ASSOCIATION_ID. */
	public static final String ASSOCIATION_ID = "associationId";
	
	/** The Constant ALLOCATION_TYPE. */
	public static final String ALLOCATION_TYPE = "allocation_type";
	
	/** The Constant ATTACHMENT_TEMPLATE. */
	public static final String ATTACHMENT_TEMPLATE="Digital Paper.png";
	
	/** The Constant CUSTOMER_EMAIL_TEMPLATE. */
	public static final String CUSTOMER_EMAIL_TEMPLATE="emal-template.ftl";
	
	/** The Constant EMAIL_CHANGES_TEMPLATE. */
	public static final String EMAIL_CHANGES_TEMPLATE="email-changes-template.ftl";  
	
	/** The Constant DIGITAL_EMAIL_TEMPLATE. */
	public static final String DIGITAL_EMAIL_TEMPLATE="digital-email-template.ftl"; 
	
	/** The Constant DP_FEELT_TEMPLATE. */
	public static final String DP_FEELT_TEMPLATE="Dp-Feelt-template.ftl";
	
	/** The Constant EMAIL_SUB. */
	public static final String EMAIL_SUB="Your Policy Number For Fleet:";

	/** The Constant MAIL_SENT_SUCCESS. */
	public static final String MAIL_SENT_SUCCESS = "Mail Sent Successfully";
	
	/** The Constant MAIL_SENT_FAILED. */
	public static final String MAIL_SENT_FAILED = "Mail Sent Failed";
	
	
	/** The Constant EMAIL_NAME. */
//template variables
	public static final String EMAIL_NAME = "Name";
	
	/** The Constant OLD_EMAIL_ID. */
	public static final String OLD_EMAIL_ID = "oldEmailID";
	
	/** The Constant NEW_EMAIL_ID. */
	public static final String NEW_EMAIL_ID = "newEmailID";
	
	/** The Constant EMAIL_COMPANY_NAME. */
	public static final String EMAIL_COMPANY_NAME = "CompanyName";
	
	/** The Constant CUSTOMER_URL. */
	public static final String CUSTOMER_URL = "customerUrl";

	/** The Constant EMAIL_SUBJECT. */
	public static final String EMAIL_SUBJECT = "Email ID Changed";

	/** The Constant COMPLAINTS_ALREADY_REGISTERED. */
	public static final String COMPLAINTS_ALREADY_REGISTERED = "Complaint already registered on this Date ";
	
	/** The Constant COMPLAINTS_ALREADY_REGISTERED_2. */
	public static final String COMPLAINTS_ALREADY_REGISTERED_2 = "Complaint already registered for this Registration Number ";
	
	/** The Constant ON_THIS. */
	public static final String ON_THIS = "on this Date ";

	/** The Constant UPLOAD_TYPE. */
	public static final String UPLOAD_TYPE = "PPR_TEM_GEN";
	
	/** The Constant REPORT_TYPE. */
	public static final String REPORT_TYPE = "digital-paper";
	
	/** The Constant STORAGE_TYPE. */
	public static final String STORAGE_TYPE = "LOCAL";
	
/** The Constant FILE_NAME. */
	public static final String FILE_NAME = "dp_template";
	
	/** The Constant CUSTOMER_PROFILE_URL. */
	public static final String CUSTOMER_PROFILE_URL="/getProfileUrl";

	/** The Constant CUSTOMER_RP_TYPE. */
	public static final String CUSTOMER_RP_TYPE = "CUSTOMER_PROFILE";
	
	public static final String NONE = "None";
	
	/** The Constant MIN_LENGTH_HINT. */
public static final String MIN_LENGTH_HINT = "MIN_LENGTH";
	
	/** The Constant ALIAS_NAME_HINT. */
	public static final String ALIAS_NAME_HINT = "ALIAS_NAME";
	
	/** The Constant FIELD_NAME_HINT. */
	public static final String FIELD_NAME_HINT = "FIELD_NAME";
	
	/** The Constant FIELD_FORMAT_HINT. */
	public static final String FIELD_FORMAT_HINT = "FIELD_FORMAT";
	
	/** The Constant DIGITAL_PAPER_HINT. */
	public static final String DIGITAL_PAPER_HINT = "DIGITAL_PAPER";
		
	/** The Constant SORT_COMPANY. */
	public static final String SORT_COMPANY = "Insurance Company";
	
	/** The Constant ALLOCATION_TYPE_1. */
	public static final String ALLOCATION_TYPE_1 = "User Type";
	
	/** The Constant ALLOCATION_TYPE_2. */
	public static final String ALLOCATION_TYPE_2 = "None";
	
	/** The Constant VALUE_EMPTY. */
	public static final String VALUE_EMPTY = " is Empty";

	/** The Constant POOL. */
	public static final String POOL = "POOL";
	
	/** The Constant SINGLE_COMPANY_OBJECT_DTO. */
	public static final String SINGLE_COMPANY_OBJECT_DTO="/get-company-object";
	
	/** The Constant STOCK_REMINDER_TEMPLATE. */
	public static final String STOCK_REMINDER_TEMPLATE="stock-remainder-template.ftl";

	/** The Constant ERROR_DATA. */
	public static final String ERROR_DATA = "Error Data";

	/** The Constant MAKE_MODEL_USAGE_LIST_URL. */
	public static final String MAKE_MODEL_USAGE_LIST_URL = "/report/get-make-model-usage-list";

	/** The Constant PAPER_DETAILS. */
	public static final String PAPER_DETAILS = "Paper Details";
	
	/**
	 * The Constant KAFKA_TOPIC
	 */
	public static final String KAFKA_TOPIC="dpaper_audit";
}