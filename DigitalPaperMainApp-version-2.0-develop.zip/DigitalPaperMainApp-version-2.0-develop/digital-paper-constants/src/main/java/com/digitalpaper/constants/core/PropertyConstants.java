package com.digitalpaper.constants.core;

/**
 * The Class PropertyConstants.
 */
public class PropertyConstants {

	/** The Constant MAIN_APP_MYSQL_IP. */
	public static final String MAIN_APP_MYSQL_IP = "[MAIN_APP_MYSQL_IP]";
	
	/** The Constant MAIN_APP_MYSQL_PORT. */
	public static final String MAIN_APP_MYSQL_PORT = "[MAIN_APP_MYSQL_PORT]";
	
	/** The Constant DB_NAME. */
	public static final String DB_NAME = "[DB_NAME]";
}
