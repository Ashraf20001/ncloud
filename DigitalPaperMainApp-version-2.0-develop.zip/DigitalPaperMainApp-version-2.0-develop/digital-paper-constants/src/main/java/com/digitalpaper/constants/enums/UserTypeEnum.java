package com.digitalpaper.constants.enums;


/**
 * The Enum UserTypeEnum.
 */
public enum UserTypeEnum {
	
	/** The association. */
	ASSOCIATION(1,"ASSOCIATION"),
	
	/** The insurance company. */
	INSURANCE_COMPANY(2,"INSURANCE_COMPANY"),
	
	/** The traffic authority. */
	TRAFFIC_AUTHORITY(3,"TRAFFIC_AUTHORITY");
	
	/**
	 * Gets the user type id.
	 *
	 * @return the user type id
	 */
	public Integer getUserTypeId() {
		return userTypeId;
	}

	/**
	 * Sets the user type id.
	 *
	 * @param userTypeId the new user type id
	 */
	public void setUserTypeId(Integer userTypeId) {
		this.userTypeId = userTypeId;
	}

	/**
	 * Gets the user type name.
	 *
	 * @return the user type name
	 */
	public String getUserTypeName() {
		return userTypeName;
	}

	/**
	 * Sets the user type name.
	 *
	 * @param userTypeName the new user type name
	 */
	public void setUserTypeName(String userTypeName) {
		this.userTypeName = userTypeName;
	}

	/** The user type id. */
	Integer userTypeId;
	
	/** The user type name. */
	String userTypeName;
	
	/**
	 * Instantiates a new user type enum.
	 *
	 * @param userTypeId the user type id
	 * @param userTypeName the user type name
	 */
	private UserTypeEnum(Integer userTypeId, String userTypeName) {
		this.userTypeId = userTypeId;
		this.userTypeName = userTypeName;
	}
	
	/**
	 * Gets the paper status by id.
	 *
	 * @param userTypeId the user type id
	 * @return the paper status by id
	 */
	public static UserTypeEnum getPaperStatusById(Integer userTypeId) {
		for (UserTypeEnum enums : UserTypeEnum.values()) {
			if (enums.getUserTypeId() == userTypeId) {
				return enums;
			}
		}
		return null;
	}
	
}

