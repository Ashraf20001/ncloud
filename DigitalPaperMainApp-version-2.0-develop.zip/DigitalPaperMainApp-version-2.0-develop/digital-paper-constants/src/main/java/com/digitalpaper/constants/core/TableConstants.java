package com.digitalpaper.constants.core;

import java.util.Arrays;
import java.util.List;

/**
 * The Class TableConstants.
 */
public class TableConstants {
	
	/** The Constant IS_DELETED. */
	public static final String IS_DELETED = "isDeleted";
	
	/** The Constant CUSTOMER_ID. */
	public static final String CUSTOMER_ID = "customerId";

	/** The Constant PURCHASE_ORDER. */
	public static final String PURCHASE_ORDER = "purchase_order";
	
	/** The Constant PAYMENT_DETAILS. */
	public static final String PAYMENT_DETAILS = "payment_details";
	
	/** The Constant STOCK. */
	public static final String STOCK = "stock";
	
	/** The Constant REPORT. */
	public static final String REPORT = "reports";
	
	/** The Constant REPORT_COLUMN_MAPPING. */
	public static final String REPORT_COLUMN_MAPPING = "reports_column_mapping";

	/** The Constant IDENTITY. */
	public static final String IDENTITY = "identity";
	
	/** The Constant NOTIFICATION_ID. */
	public static final String NOTIFICATION_ID = "notificationId";
	
	/** The Constant REF_ID. */
	public static final String REF_ID="referenceId";
	
	/** The Constant RP_TYPE. */
	public static final String RP_TYPE="reportType";
	
	/** The Constant STOCKID. */
	public static final String STOCKID = "stock_id";
	
	/** The Constant STOCK_EVENT_NAME. */
	public static final String STOCK_EVENT_NAME = "eventName";
	
	/** The Constant ISDELETED. */
	public static final String ISDELETED = "isDeleted";
    
    /** The Constant COMPANY_ID. */
    public static final String COMPANY_ID = "companyId";
	
	/** The Constant ORDER_ID. */
	public static final String ORDER_ID = "orderId";
	
	/** The Constant MODIFIED_DATE. */
	public static final String MODIFIED_DATE = "modifiedDate";
	
	/** The Constant COMPANY_NAME. */
	public static final String COMPANY_NAME = "name";
	
	/** The Constant STOCK_NOTIFICATION. */
	public static final String STOCK_NOTIFICATION = "stock_notification";
	
	/** The Constant COMPLAINTS. */
	public static final String COMPLAINTS = "complaints";


	/** The Constant LAST_STATUS. */
	public static final String LAST_STATUS = "lastStatus";
	
	/** The Constant REFERENCE_ID. */
	public static final String REFERENCE_ID = "referenceId";
	
	/** The Constant REPORT_TYPE. */
	public static final String REPORT_TYPE = "reportType";
	
	/** The Constant UPLOAD_TYPE. */
	public static final String UPLOAD_TYPE = "uploadType";

	/** The Constant USER_NAME. */
	public static final String USER_NAME = "username";
	
	/** The Constant EMAIL. */
	public static final String EMAIL="email";
	
	/** The Constant IS_DLT_STS. */
	public static final String IS_DLT_STS = "isDeleted";
	
	/** The Constant STATUS. */
	public static final String STATUS = "status";
	
	/** The Constant STATUS_REPORT. */
	public static final String STATUS_REPORT = "Status";
	
	/** The Constant CREATEDATE. */
	public static final String CREATEDATE = "created_date";
	
	/** The Constant TO_NOTIFY. */
	public static final String TO_NOTIFY = "toNotify";
	
	/** The Constant IS_READ. */
	public static final String IS_READ = "isRead";
	
	/** The Constant MAX_DATA_LIMIT. */
	public static final int MAX_DATA_LIMIT = 4;
	
	/** The Constant MAX_DATA_LIMIT_BAR_CHART. */
	public static final int MAX_DATA_LIMIT_BAR_CHART = 12;

	/** The Constant ACTION. */
	public static final String ACTION = "action";
	
	/** The Constant EVENTID. */
	public static final String EVENTID = "eventId";
	
	/** The Constant ACTEDBY. */
	public static final String ACTEDBY = "actedBy";

	/** The Constant AP_IS_DELETED. */
	public static final String AP_IS_DELETED="isDeleted";
	
	/** The Constant PURCHASE_ID. */
	/*
	 * Stock Excel File Download Header
	 */
	public static final String PURCHASE_ID = "Purchase ID";
	
	/** The Constant TRANSACTION_ID. */
	public static final String TRANSACTION_ID = "Transaction ID";
	
	/** The Constant DATEOF_PURCHASE. */
	public static final String DATEOF_PURCHASE = "Date of Purchase";
	
	/** The Constant NO_OF_PAPER. */
	public static final String NO_OF_PAPER = "NO.of Papers";
	
	/** The Constant PURCHASE_AMT. */
	public static final String PURCHASE_AMT = "Purchase Amount";
	
	/** The Constant PAYMENT_METHOD. */
	public static final String PAYMENT_METHOD = "Payment Method";
	
	/** The Constant PAYMENT_DATE. */
	public static final String PAYMENT_DATE = "Payment Date";
	
	/** The Constant PAYMENT_TYPE. */
	public static final String PAYMENT_TYPE = "Payment Type";
	
	/** The Constant PAYMENT_STATUS. */
	public static final String PAYMENT_STATUS = "Payment Status";

	/** The Constant TAB_DIGITAL_NUMBER. */
	/*
	 * Generate Paper Excel Download Header
	 */
	public static final String TAB_DIGITAL_NUMBER="Digital Paper No";
	
	/** The Constant TAB_POLICY_NUMBER. */
	public static final String TAB_POLICY_NUMBER="Policy Number";
	
	/** The Constant TAB_POLICY_NO. */
	public static final String TAB_POLICY_NO="Policy No";
	
	/** The Constant TAB_INSURED_NAME. */
	public static final String TAB_INSURED_NAME="Insured Name";
	
	/** The Constant TAB_EFFECTIVE_FROM. */
	public static final String TAB_EFFECTIVE_FROM="Effective From";
	
	/** The Constant TAB_EFFECTIVE_TO. */
	public static final String TAB_EFFECTIVE_TO="Effective to";
	
	/** The Constant TAB_EXPIRY_DATE. */
	public static final String TAB_EXPIRY_DATE="Expiry Date";
	
	/** The Constant TAB_REGISTRATION_NO. */
	public static final String TAB_REGISTRATION_NO="Registration No";
	
	/** The Constant TAB_USAGE. */
	public static final String TAB_USAGE="Usage";
	
	/** The Constant TAB_STATUS. */
	public static final String TAB_STATUS="Status";





	/** The Constant STOCK_FILE_MAPPING. */
	public static final String STOCK_FILE_MAPPING = "stock_file_mapping";

	/** The Constant DP_TRANSACTION_ID. */
	public static final String DP_TRANSACTION_ID = "transactionId";
	
	/** The Constant DP_PURCHASE_DATE. */
	public static final String DP_PURCHASE_DATE="purchaseDate";

	/** The Constant AMOUNT. */
	public static final String AMOUNT = "Amount";
	
	/** The Constant COMPANYNAME. */
	public static final String COMPANYNAME = "Company Name";
	
	/** The Constant DP_PURCHASE_ID. */
	public static final String DP_PURCHASE_ID = "purchaseId";
	
	/** The Constant ORDER_STATUS. */
	public static final String ORDER_STATUS = "orderStatus";
	
	/** The Constant DP_PAYMENT_STATUS. */
	public static final String DP_PAYMENT_STATUS="paymentStatus";
	
	/** The Constant DP_PAYMENT_METHOD. */
	public static final String DP_PAYMENT_METHOD = "paymentMethod";
	
	/** The Constant DP_PAYMENT_MODE. */
	public static final String DP_PAYMENT_MODE = "paymentMode";
	
	/** The Constant DP_PAYMENT_AMOUNT. */
	public static final String DP_PAYMENT_AMOUNT = "paidAmount";
	
	/** The Constant DP_CURRENCY_TYPE. */
	public static final String DP_CURRENCY_TYPE = "currencyType";



	/** The Constant USER_TYPE_ID. */
	public static final String USER_TYPE_ID = "userTypeId";
	
	/** The Constant STOCK_POOL_ID. */
	public static final String STOCK_POOL_ID = "stockPoolId";

	/** The Constant INSURED_COMPANY. */
	public static final String INSURED_COMPANY = "Insurance Company";
	
	/** The Constant TOTAL_TRANSACTION. */
	public static final String TOTAL_TRANSACTION = "Total Transactions";
	
	/** The Constant PENDING_TRANSACTION. */
	public static final String PENDING_TRANSACTION = "Pending Transactions";
	
	/** The Constant STOCK_COUNT. */
	public static final String STOCK_COUNT = "stockCount";

	/** The Constant SCRATCH_TABLE_NAME. */
	public static final String SCRATCH_TABLE_NAME = "dp_scratch";
	
	/** The Constant PD_POLICY_NUMBER. */
	public static final String PD_POLICY_NUMBER = "pdPolicyNumber";
	
	/** The Constant ERROR_TABLE. */
	public static final String ERROR_TABLE = "error_table";
	
	/** The Constant PAPER_DETAILS. */
	public static final String PAPER_DETAILS = "paper_details";

	/** The Constant PAPER_ID. */
	public static final String PAPER_ID = "paperId";

	/** The Constant POLICY_NUMBER. */
	public static final String POLICY_NUMBER = "pdPolicyNumber";
	
	/** The Constant REGISTRATION_NUMBER. */
	public static final String REGISTRATION_NUMBER = "vdRegistrationNumber";
	
	/** The Constant CHASIS_NUMBER. */
	public static final String CHASIS_NUMBER = "vdChassis";
	
	/** The Constant PD_INSURED_NAME. */
	public static final String PD_INSURED_NAME = "pdInsuredName";
	
	/** The Constant PD_USAGE. */
	public static final String PD_USAGE = "vdUsage";
	
	/** The Constant PD_LICENCE_TO_CARRY. */
	public static final String PD_LICENCE_TO_CARRY = "vdLicensedToCarry";
	
	/** The Constant PD_MAKE. */
	public static final String PD_MAKE = "vdMake";

	/** The Constant PD_STATUS. */
	public static final String PD_STATUS = "status";
	
	/** The Constant CREATED_DATE. */
	public static final String CREATED_DATE = "createdDate";
	
	/** The Constant CREATED_BY. */
	public static final String CREATED_BY = "createdBy";
	
	/** The Constant PD_MODEL. */
	public static final String PD_MODEL = "vdModel";
	
	/** The Constant EFFECTIVE_START_DATE. */
	public static final String EFFECTIVE_START_DATE = "pdEffectiveFrom";
	
	/** The Constant EXPIRY_DATE. */
	public static final String EXPIRY_DATE = "pdExpireDate";
	
	/** The Constant PHONE_NUMBER. */
	public static final String PHONE_NUMBER = "phoneNumber";
	
	/** The Constant PD_PHONE_NUMBER. */
	public static final String PD_PHONE_NUMBER = "pdPhoneNumber";
	
	/** The Constant PD_EMAIL_ID. */
	public static final String PD_EMAIL_ID = "pdEmailId";

	/** The Constant BR_IDENTITY. */
	public static final String BR_IDENTITY = "identity";
	
	/** The Constant BR_DIGITAL_PAPER_ID. */
	public static final String BR_DIGITAL_PAPER_ID = "digitalPaperId";
	
	/** The Constant BR_POLICY_NUMBER. */
	public static final String BR_POLICY_NUMBER = "policyNumber";
	
	/** The Constant BR_STATUS. */
	public static final String BR_STATUS ="status";
	
	/** The Constant BR_BULKIMPORTHISTORYID. */
	public static final String BR_BULKIMPORTHISTORYID = "bulkImportHistoryId";

	/** The Constant FILE_STORAGE. */
	public static final String FILE_STORAGE = "dp_storage_data";

	/** The Constant CUSTOMER_TABLE. */
	public static final String CUSTOMER_TABLE = "customer";
	
	/** The Constant BULK_UPLOAD_ID. */
	public static final String BULK_UPLOAD_ID = "bulkUploadId";
	
	/** The Constant SCRATCH_ID. */
	public static final String SCRATCH_ID = "scratchId";
	
	/** The Constant IS_ERROR_CLEARED. */
	public static final String  IS_ERROR_CLEARED = "isErrorCleared";
	
	/** The Constant ERROR_MESSAGE. */
	public static final String ERROR_MESSAGE="errorMessage";


	/** The Constant PD_DIGITAL_PAPER_ID. */
	public static final String PD_DIGITAL_PAPER_ID = "pdDigitalPaperId";
	
	/** The Constant USED_COUNT. */
	public static final String USED_COUNT = "usedCount";
	
	/** The Constant BULK_REVOKE_ERROR_TABLE. */
	public static final String BULK_REVOKE_ERROR_TABLE = "bulk_revoke_error_table";
	
	/** The Constant STOCK_POOL. */
	public static final String STOCK_POOL = "stock_pool";

	/** The Constant STOCK_ID. */
	public static final String STOCK_ID = "stockId";
	
	/** The Constant REPORT_ID. */
	public static final String REPORT_ID = "reportId";


	/** The Constant BULK_IMPORT_HISTORY_ID. */
	public static final String BULK_IMPORT_HISTORY_ID = "bulkImportHistoryId";

/** The Constant COLUMN_NAME. */
	public static final String COLUMN_NAME = "columnName";


	/** The Constant TAB_INSURED_COMAPNY. */
	public static final String TAB_INSURED_COMAPNY= "Insured Company";
    
    /** The Constant TAB_STOCK_COUNT. */
    public static final String TAB_STOCK_COUNT = "Stock Count";
    
    /** The Constant TAB_AVAILABLE_STOCK. */
    public static final String TAB_AVAILABLE_STOCK ="Available Stock";
	
	/** The Constant TAB_PAPERS_ISSUED. */
	public static final String TAB_PAPERS_ISSUED = "Papers Issued";
	
	/** The Constant FORGET_EMAIL. */
	public static final String FORGET_EMAIL="forget_email";
	
	/** The Constant CUSTOMER. */
	public static final String CUSTOMER="customer";
	
	/** The Constant PAYMENTDATE. */
	public static final String PAYMENTDATE="paymentDate";

	/** The Constant DIGITAL_PAPER_NUMBER. */
	public static final String DIGITAL_PAPER_NUMBER="Digital Paper Number";
	
	/** The Constant POLICY_NO. */
	public static final String POLICY_NO="Policy Number";
	
	/** The Constant INSURED_NAME. */
	public static final String INSURED_NAME="Insured Name";
	
	/** The Constant REGISTRATION_NO. */
	public static final String REGISTRATION_NO="Registration Number";
	
	/** The Constant EFFECTIVE_FROM. */
	public static final String EFFECTIVE_FROM="Effective From";
	
	/** The Constant EFFECTIVE_TO. */
	public static final String EFFECTIVE_TO="Effective to";
	
	/** The Constant MAKE. */
	public static final String MAKE="Make";
	
	/** The Constant MODEL. */
	public static final String MODEL="Model";
	
	/** The Constant CHASSIS_NUMBER. */
	public static final String CHASSIS_NUMBER="Chassis Number";
	
	/** The Constant USAGE_TYPE. */
	public static final String USAGE_TYPE="Usage Type";
	
	/** The Constant LICENSE_TO_CARRY. */
	public static final String LICENSE_TO_CARRY="Licensed to carry";
	
	/** The Constant PHONE_NO. */
	public static final String PHONE_NO="Phone Number";
	
	/** The Constant EMAIL_ID. */
	public static final String EMAIL_ID="Email Id"; // status also common 
	
	/** The Constant STOCKCOUNT. */
	public static final String STOCKCOUNT="Stock Count";
	
	/** The Constant PURCHASE_DATE. */
	public static final String PURCHASE_DATE="Purchase Date";
	
	/** The Constant PURCHASR_ID. */
	public static final String PURCHASR_ID="Purchase ID";
	
	/** The Constant PD_PURCHASR_ID. */
	public static final String PD_PURCHASR_ID="pdDigitalPaperId";
	
	/** The Constant ORDER_AMT. */
	public static final String ORDER_AMT="Order Amount";
	
	/** The Constant ORDER_STS. */
	public static final String ORDER_STS="Order Status";
	
	/** The Constant PAPMENT_METHOD. */
	public static final String PAPMENT_METHOD="Payment Method";
	
	/** The Constant ALLOCATION_TYPE_ID. */
	public static final String ALLOCATION_TYPE_ID="allocationUserTypeId";
	
	/** The Constant IS_ASSOCIATION. */
	public static final String IS_ASSOCIATION="isAssociation";
	
	/** The Constant PAPERS_COUNT. */
	public static final String PAPERS_COUNT="No.of Papers";
	
	/** The Constant ADDED_DATE. */
	public static final String ADDED_DATE="Added Date";
	
	/** The Constant INSURER_NAME. */
	public static final String INSURER_NAME="Insurer Name";
	
	/** The Constant CUSTOMER_NOTIFICATION. */
	public static final String CUSTOMER_NOTIFICATION="customer_notification";

	/** The Constant STOCK_TRANS_HIST. */
	public static final String STOCK_TRANS_HIST="stock_trans_his";
	
	/** The Constant COMPLAINTS_EMAILID. */
	public static final String COMPLAINTS_EMAILID="email_id";
	
	/** The Constant CREDITED_STOCK. */
	public static final String CREDITED_STOCK="creditedStock";
	
	/** The Constant DEBITED_STOCK. */
	public static final String DEBITED_STOCK="debitedStock";
	
	/** The Constant TB_ADDED_DATE. */
	public static final String TB_ADDED_DATE="addedDate";
	
	/** The Constant PASSWORD. */
	public static final String PASSWORD="password";
	
	/** The Constant IS_FIRST_TIME_LOGIN. */
	public static final String IS_FIRST_TIME_LOGIN="isFirstTimeLogin";
	
	/** The Constant PROFILE_URL. */
	public static final String PROFILE_URL="profileUrl";
	
	/** The Constant CUSTOMER_URL. */
	public static final String CUSTOMER_URL="customerUrl";
	
	/** The Constant VDMAKE_AND_VDMODEL. */
	public static final List<String> VDMAKE_AND_VDMODEL= Arrays.asList("vdMake","vdModel","vdUsage");
	
	/** The Constant MODIF_DATE. */
	public static final String MODIF_DATE = "modified_date";
	
    /**
     * Instantiates a new table constants.
     */
    private TableConstants() {

		}

}
