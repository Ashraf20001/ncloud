package com.digitalpaper.constants.externalApi.core;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * The Class ReportlossExternalToDtoMap.
 */
public class ReportlossExternalToDtoMap {
	
	/** The Constant reportlossDtoFieldMap. */
	public static final Map<String,String> reportlossDtoFieldMap=new LinkedHashMap<>();
	static {
		reportlossDtoFieldMap.put(ReportLossDtoField.STATE, ReportLossExternalDtoField.STATUS);
		reportlossDtoFieldMap.put(ReportLossDtoField.IN_SUM_INSURED, ReportLossExternalDtoField.SUM_INSURED);
		reportlossDtoFieldMap.put(ReportLossDtoField.IN_PURCHASE_DATE, ReportLossExternalDtoField.PURCHASE_DATE);
		reportlossDtoFieldMap.put(ReportLossDtoField.LD_CLAIM_NUMBER, ReportLossExternalDtoField.INSURED_CLAIM_NO);
		reportlossDtoFieldMap.put(ReportLossDtoField.TP_REGISTRATION_TYPE, ReportLossExternalDtoField.REGISTRATION_TYPE);
		reportlossDtoFieldMap.put(ReportLossDtoField.TP_CLAIM_NO, ReportLossExternalDtoField.THIRD_PARTY_CLAIM_NO);
		
		reportlossDtoFieldMap.put(ReportLossDtoField.LD_REPORTED_DATE, ReportLossExternalDtoField.DATE_OF_REPORTED);
		reportlossDtoFieldMap.put(ReportLossDtoField.LD_RESERVE_AMOUNT, ReportLossExternalDtoField.RESERVE_AMOUNT);
		reportlossDtoFieldMap.put(ReportLossDtoField.LD_POLICE_REPORT_NUMBER, ReportLossExternalDtoField.POLICE_REPORT_NO);
		reportlossDtoFieldMap.put(ReportLossDtoField.LD_DATE_OF_LOSS, ReportLossExternalDtoField.DATE_OF_LOSS);
		
		
		//GARAGE INFO
		reportlossDtoFieldMap.put(ReportLossDtoField.GARAGE_TYPE, ReportLossExternalDtoField.TYPE);
		reportlossDtoFieldMap.put(ReportLossDtoField.GARAGE_LOCATION, ReportLossExternalDtoField.ADDRESS_LOCATION);

       //SURVEY DEATIALS
		reportlossDtoFieldMap.put(ReportLossDtoField.SD_SURVEY_DUE_DATE, ReportLossExternalDtoField.SURVEY_DUE_DATE);
		reportlossDtoFieldMap.put(ReportLossDtoField.SD_SURVEY_ALLOCATION_DATE, ReportLossExternalDtoField.SURVEY_ALLOCATION_DATE);

		reportlossDtoFieldMap.put(ReportLossDtoField.LD_RESERVE_AMOUNT, ReportLossExternalDtoField.RESERVE_AMOUNT);
		reportlossDtoFieldMap.put(ReportLossDtoField.RR_RESERVE_AMOUNT, ReportLossExternalDtoField.TOTAL_RESERVE_AMOUNT);

		reportlossDtoFieldMap.put(ReportLossDtoField.RD_CLAIM_AMOUNT, ReportLossExternalDtoField.CLAIM_AMOUNT);
		reportlossDtoFieldMap.put(ReportLossDtoField.RR_TOTAL_CLAIM_AMOUNT, ReportLossExternalDtoField.THIRD_PARTY_SETTLES_AMOUNT);
		reportlossDtoFieldMap.put(ReportLossDtoField.CLAIM_SEQUENCE_ID, ReportLossExternalDtoField.FNOL_NO);
		reportlossDtoFieldMap.put(ReportLossDtoField.SR_SPARE_PARTS, ReportLossExternalDtoField.SPARE_PARTS);
		reportlossDtoFieldMap.put(ReportLossDtoField.SR_LABOUR_COSR, ReportLossExternalDtoField.LABOUR_COSR);

	}

}
