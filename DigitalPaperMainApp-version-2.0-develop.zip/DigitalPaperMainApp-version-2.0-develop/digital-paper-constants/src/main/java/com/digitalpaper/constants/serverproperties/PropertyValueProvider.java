package com.digitalpaper.constants.serverproperties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

/**
 * The Class PropertyValueProvider.
 */
@Component
@ConfigurationProperties(prefix = "dpmainapp")
@Data
public class PropertyValueProvider {
				
		/** The mysql data source url. */
		private String mysqlDataSourceUrl;
		
		/** The mysql ip. */
		private String mysqlIp;
		
		/** The mysql port. */
		private String mysqlPort;
		
		/** The mysql username. */
		private String mysqlUsername;
		
		/** The mysql password. */
		private String mysqlPassword;
		
		/** The mysql data base. */
		private String mysqlDataBase;
		
		/** The mysql driver. */
		private String mysqlDriver;
		
		/** The time zone. */
		private String timeZone;
		
		/** The number format. */
		private String numberFormat;
		
		/** The country code. */
		private String countryCode;
		
		/** The currency format. */
		private String currencyFormat;
		
		/** The time format. */
		private String timeFormat;
		
		/** The date format. */
		private String dateFormat;
		
		/** The bulk upload consumer path. */
		private String bulkUploadConsumerPath;
		
		/** The common service path. */
		private String commonServicePath;
		
		/** The file download url. */
		private String fileDownloadUrl;
		
		/** The spring mail username. */
		private String springMailUsername;
		
		/** The file upload path. */
		private String fileUploadPath;
		
		/** The send email name. */
		private String sendEmailName;		
		
		/** The frontend url. */
		private String frontendUrl;	
		
		/** The dp download url. */
		private String dpDownloadUrl;
		
		/** The digital email template. */
		private String digitalEmailTemplate;
		
		/** The customer email template. */
		private String customerEmailTemplate;
		
		/** The gateway path. */
		private String gatewayPath;
		
		/** The customer portal url. */
		private String customerPortalUrl;
		
		/** The dp og template path. */
		private String dpOgTemplatePath;
		
		/** The mysql max idle timeout. */
		private String mysqlMaxIdleTimeout;
		
		/** The mysql max idle excess connections. */
		private String mysqlMaxIdleExcessConnections;
		
		/** The mysql connection checkout. */
		private String mysqlConnectionCheckout;
		
		/** The mysql min poolsize. */
		private String mysqlMinPoolsize;
		
		/** The mysql max pool size. */
		private String mysqlMaxPoolSize;
		
		/** The mysql idle connection testperiod. */
		private String mysqlIdleConnectionTestperiod;
}
