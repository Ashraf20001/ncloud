package com.digitalpaper.constants.externalApi.core;

/**
 * The Class ExternalDataTypeConstant.
 */
public class ExternalDataTypeConstant {
	
	/** The Constant STRING. */
	public static final String STRING="class java.lang.String";
	
	/** The Constant LOCALDATETIME. */
	public static final String LOCALDATETIME="class java.time.LocalDateTime";
	
	/** The Constant DOUBLE. */
	public static final String DOUBLE="class java.lang.Double";
	
	/** The Constant INTEGER. */
	public static final String INTEGER="class java.lang.Integer";
	
	/** The Constant LONG. */
	public static final String LONG="class java.lang.Long";
	
	/** The Constant BOOLEAN. */
	public static final String BOOLEAN="class java.lang.Boolean";
	
	/** The Constant LOCALDATE. */
	public static final String LOCALDATE="Class java.time.LocalDate";
	

}
