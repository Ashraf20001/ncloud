package com.digitalpaper.constants.core;

/**
 * The Class FileUploadTypeConstant.
 */
public class FileUploadTypeConstant {
	 
 	/** The Constant CLAIM. */
 	public static final String CLAIM="CLAIM";
	 
 	/** The Constant USER. */
 	public static final String USER="USER";
	
}
