package com.digitalpaper.constants.core;

/**
 * The Class FlowMapType.
 */
public class FlowMapType {

/** The Constant NEXTSTATUSMAP. */
public static final String NEXTSTATUSMAP="nextStatusMap";

/** The Constant TOTALLOSS_STATUSMAP. */
public static final String TOTALLOSS_STATUSMAP="totalLossStatusMap";

/** The Constant TOTALLOSS_SURVEYOR_STATUSMAP. */
public static final String TOTALLOSS_SURVEYOR_STATUSMAP="totalLossSurveyorStatusMap";
}
