package com.digitalpaper.constants.core;

/**
 * The Class LoginUserType.
 */
public class LoginUserType {

/** The Constant RECEIVABLE. */
public static final boolean RECEIVABLE=true;

/** The Constant PAYABLE. */
public static final boolean PAYABLE=false;

}
