package com.digitalpaper.constants.externalApi.core;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * The Class DocumentFieldMap.
 */
public class DocumentFieldMap {
	
	/** The Constant documentMap. */
	public static final Map<String,String> documentMap=new LinkedHashMap<>();
	static {
		documentMap.put(ReportLossDtoField.PR_DOCUMENT_UPLOAD, ExternalDocumentTypeConstant.POLICE_REPORT);
		documentMap.put(ReportLossDtoField.GI_GARAGE_INVOICE_ID, ExternalDocumentTypeConstant.GARAGE_INVOICE);
		documentMap.put(ReportLossDtoField.DN_DEBITNOTE_DOCUMENT, ExternalDocumentTypeConstant.DEBIT_NOTE);
		documentMap.put(ReportLossDtoField.CN_CREDITNOTE_DOCUMENT, ExternalDocumentTypeConstant.CREDIT_NOTE);
		documentMap.put(ReportLossDtoField.SR_SURVEY_REPORT_UPLOAD, ExternalDocumentTypeConstant.SURVEY_REPORT);
	}

}
