package com.digitalpaper.constants.externalApi.core;

import java.util.HashMap;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.digitalpaper.constants.core.RecoveryStatusConstant;


/**
 * The Class GetActionButtonFromStatus.
 */
@Component
public class GetActionButtonFromStatus {
	
	/** The colon. */
	final String COLON = ":";
	
	/** The accept. */
	final String ACCEPT = "accept";
	
	/** The reject. */
	final String REJECT = "reject";
	
	/** The dispute. */
	final String DISPUTE = "dispute";
	
	/** The dispute reopen. */
	final String DISPUTE_REOPEN = "reopen";
	
	/** The t1. */
	final String T1 = "type1";
	
	/** The t2. */
	final String T2 = "type2";
	
	/** The need info. */
	final String NEED_INFO = "seek-clarification";
	
	/** The details provided. */
	final String DETAILS_PROVIDED = "provide-clarification";
	
	/** The true. */
	final boolean TRUE = true;
	
	/** The false. */
	final boolean FALSE = false;
	
	/** The view. */
	final String VIEW = "VIEW";
	
	/** The save. */
	final String SAVE = "SAVE";
	
	/** The approved. */
	final String APPROVED = "APPROVED";
	
	/** The accepted. */
	final String ACCEPTED = "ACCEPTED";
	
	/** The need more details. */
	final String NEED_MORE_DETAILS = "NEED_MORE_DETAILS";
	
	/** The details provided. */
	final String DETAILS_PROVIDED_ = "DETAILS_PROVIDED";
	
	/** The rejected. */
	final String REJECTED = "REJECTED";
	
	/** The reopen. */
	final String REOPEN = "REOPEN";
	
	/** The dispute. */
	final String DISPUTE_ = "DISPUTE";
	
	/** The dispute reopend. */
	final String DISPUTE_REOPEND = "DISPUTE_REOPEND";
	
	/** The get action button. */
	HashMap<String, String> getActionButton = new HashMap<>();
	
	/**
	 * Construct action button map.
	 */
	@PostConstruct
	void constructActionButtonMap() {

		getActionButton.put(RecoveryStatusConstant.DRAFT+COLON+TRUE+COLON+ACCEPT, SAVE);

		getActionButton.put(RecoveryStatusConstant.NOTIFICATION_OPEN+COLON+FALSE+COLON+ACCEPT, VIEW);

		getActionButton.put(RecoveryStatusConstant.NOTIFICATION_RECEIVED+COLON+FALSE+COLON+ACCEPT, ACCEPTED);

		getActionButton.put(RecoveryStatusConstant.NOTIFICATION_ACCEPTED +COLON+TRUE+COLON+ACCEPT, SAVE);

		getActionButton.put(RecoveryStatusConstant.GS_DETAILS_UPDATED+COLON+FALSE+COLON+ACCEPT , VIEW);
		getActionButton.put(RecoveryStatusConstant.TOTALLOSS_INITITED+COLON+FALSE+COLON+ACCEPT, VIEW);
		getActionButton.put(RecoveryStatusConstant.NOTIFICATION_RECEIVED+COLON+FALSE+COLON+NEED_INFO , NEED_MORE_DETAILS);
		getActionButton.put(RecoveryStatusConstant.DETAILS_PROVIDED+COLON+FALSE+COLON+DETAILS_PROVIDED , ACCEPTED);
		getActionButton.put(RecoveryStatusConstant.MOVED_INSPECTION+COLON+FALSE+COLON+ACCEPT , VIEW);
		getActionButton.put(RecoveryStatusConstant.UNDER_INSPECTION+COLON+FALSE+COLON+ACCEPT, SAVE);
		getActionButton.put(RecoveryStatusConstant.EXPENSES_AND_DOCUMENT_UPDATED+COLON+TRUE+COLON+ACCEPT , VIEW);
		getActionButton.put(RecoveryStatusConstant.RECEIVED_LIABILITY+COLON+TRUE+COLON+ACCEPT , SAVE);
		getActionButton.put(RecoveryStatusConstant.LIABLITY_REVIEW+COLON+FALSE+COLON+ACCEPT, ACCEPTED);
		getActionButton.put(RecoveryStatusConstant.LIABLITY_ACCEPTED+COLON+TRUE+COLON+ACCEPT , SAVE);
		getActionButton.put(RecoveryStatusConstant.CONFIRM_LIABLITY+COLON+FALSE+COLON+ACCEPT , APPROVED);
		getActionButton.put(RecoveryStatusConstant.NOTIFICATION_RECEIVED+COLON+FALSE+COLON+REJECT , REJECTED);

		getActionButton.put(RecoveryStatusConstant.NOTIFICATION_REJECTED+COLON+TRUE+COLON+ACCEPT , VIEW);

		getActionButton.put(RecoveryStatusConstant.RECEIVED_REJECTED_NOTIFICATION+COLON+TRUE+COLON+ACCEPT , REOPEN);

		getActionButton.put(RecoveryStatusConstant.REOPEN+COLON+FALSE+COLON+ACCEPT , VIEW);

		getActionButton.put(RecoveryStatusConstant.NOTIFICATION_RECEIVED+COLON+FALSE+COLON+NEED_INFO , NEED_MORE_DETAILS);

		getActionButton.put(RecoveryStatusConstant.NEEDMOREDETAIL+COLON+TRUE+COLON+DETAILS_PROVIDED , DETAILS_PROVIDED_);

		getActionButton.put(RecoveryStatusConstant.DETAILS_PROVIDED+COLON+FALSE+COLON+NEED_INFO , NEED_MORE_DETAILS);

		getActionButton.put(RecoveryStatusConstant.NEEDMOREDETAIL+COLON+TRUE+COLON+DETAILS_PROVIDED , DETAILS_PROVIDED_);

		getActionButton.put(RecoveryStatusConstant.DETAILS_PROVIDED+COLON+FALSE+COLON+ACCEPT , ACCEPTED);

		getActionButton.put(RecoveryStatusConstant.DETAILS_PROVIDED+COLON+FALSE+COLON+REJECT , REJECTED);

		getActionButton.put(RecoveryStatusConstant.RECEIVED_LIABILITY+COLON+TRUE+COLON+NEED_INFO , NEED_MORE_DETAILS);

		getActionButton.put(RecoveryStatusConstant.NEEDMOREDETAIL+COLON+FALSE+COLON+DETAILS_PROVIDED , DETAILS_PROVIDED_);

		getActionButton.put(RecoveryStatusConstant.DETAILS_PROVIDED+COLON+TRUE+COLON+ACCEPT , VIEW);

		getActionButton.put(RecoveryStatusConstant.LIABLITY_REVIEW+COLON+FALSE+COLON+NEED_INFO , NEED_MORE_DETAILS);

		getActionButton.put(RecoveryStatusConstant.NEEDMOREDETAIL+COLON+TRUE+COLON+DETAILS_PROVIDED , DETAILS_PROVIDED_);

		getActionButton.put(RecoveryStatusConstant.DETAILS_PROVIDED+COLON+FALSE+COLON+ACCEPT , VIEW);

		getActionButton.put(RecoveryStatusConstant.CONFIRM_LIABLITY+COLON+FALSE+COLON+NEED_INFO , NEED_MORE_DETAILS);

		getActionButton.put(RecoveryStatusConstant.NEEDMOREDETAIL+COLON+TRUE+COLON+DETAILS_PROVIDED , DETAILS_PROVIDED_);

		getActionButton.put(RecoveryStatusConstant.DETAILS_PROVIDED+COLON+FALSE+COLON+NEED_INFO , NEED_MORE_DETAILS);

		getActionButton.put(RecoveryStatusConstant.NEEDMOREDETAIL+COLON+TRUE+COLON+DETAILS_PROVIDED , DETAILS_PROVIDED_);

		getActionButton.put(RecoveryStatusConstant.DETAILS_PROVIDED+COLON+FALSE+COLON+ACCEPT , APPROVED);

		getActionButton.put(RecoveryStatusConstant.MOVED_INSPECTION+COLON+FALSE+COLON+NEED_INFO , NEED_MORE_DETAILS);

		getActionButton.put(RecoveryStatusConstant.NEEDMOREDETAIL+COLON+TRUE+COLON+DETAILS_PROVIDED , DETAILS_PROVIDED_);

		getActionButton.put(RecoveryStatusConstant.DETAILS_PROVIDED+COLON+FALSE+COLON+ACCEPT , VIEW);

		getActionButton.put(RecoveryStatusConstant.DEBIT_NOTE_GENERATED+COLON+FALSE+COLON+NEED_INFO , NEED_MORE_DETAILS);

		getActionButton.put(RecoveryStatusConstant.NEEDMOREDETAIL+COLON+TRUE+COLON+DETAILS_PROVIDED , DETAILS_PROVIDED_);

		getActionButton.put(RecoveryStatusConstant.DETAILS_PROVIDED+COLON+FALSE+COLON+NEED_INFO , NEED_MORE_DETAILS);

		getActionButton.put(RecoveryStatusConstant.NEEDMOREDETAIL+COLON+TRUE+COLON+DETAILS_PROVIDED , DETAILS_PROVIDED_);

		getActionButton.put(RecoveryStatusConstant.DETAILS_PROVIDED+COLON+FALSE+COLON+ACCEPT , APPROVED);

		getActionButton.put(RecoveryStatusConstant.RECEIVED_LIABILITY+COLON+TRUE+COLON+DISPUTE , DISPUTE_);

		getActionButton.put(RecoveryStatusConstant.DISPUTE+COLON+TRUE+COLON+DISPUTE_REOPEN , DISPUTE_REOPEND);

		getActionButton.put(RecoveryStatusConstant.DISPUTE_REOPEN+COLON+FALSE+COLON+ACCEPT , VIEW);

		getActionButton.put(RecoveryStatusConstant.LIABLITY_REVIEW+COLON+FALSE+COLON+DISPUTE , DISPUTE_);

		getActionButton.put(RecoveryStatusConstant.DISPUTE+COLON+FALSE+COLON+DISPUTE_REOPEN , DISPUTE_REOPEND);

		getActionButton.put(RecoveryStatusConstant.DISPUTE_REOPEN+COLON+TRUE+COLON+ACCEPT , VIEW);

		getActionButton.put(RecoveryStatusConstant.DEBIT_NOTE_GENERATED+COLON+FALSE+COLON+DISPUTE , DISPUTE_);

		getActionButton.put(RecoveryStatusConstant.DISPUTE+COLON+FALSE+COLON+DISPUTE_REOPEN , DISPUTE_REOPEND);

		getActionButton.put(RecoveryStatusConstant.DISPUTE_REOPEN+COLON+TRUE+COLON+ACCEPT , VIEW);

		getActionButton.put(RecoveryStatusConstant.CONFIRM_LIABLITY+COLON+FALSE+COLON+DISPUTE , DISPUTE_);

		getActionButton.put(RecoveryStatusConstant.DISPUTE+COLON+FALSE+COLON+DISPUTE_REOPEN , DISPUTE_REOPEND);

		getActionButton.put(RecoveryStatusConstant.DISPUTE_REOPEN+COLON+TRUE+COLON+ACCEPT , VIEW);

		getActionButton.put(RecoveryStatusConstant.UNDER_INSPECTION+COLON+TRUE+COLON+ACCEPT , SAVE);

		getActionButton.put(RecoveryStatusConstant.MOVED_INSPECTION+COLON+FALSE+COLON+ACCEPT , SAVE);

		getActionButton.put(RecoveryStatusConstant.UNDER_INSPECTION+COLON+FALSE+COLON+ACCEPT+T1 , SAVE);

		getActionButton.put(RecoveryStatusConstant.MOVED_INSPECTION+COLON+FALSE+COLON+ACCEPT+T1 , SAVE);

		getActionButton.put(RecoveryStatusConstant.MOVED_INSPECTION+COLON+FALSE+COLON+ACCEPT+T1 , VIEW);

		getActionButton.put(RecoveryStatusConstant.TOTALLOSS_INITITED+COLON+TRUE+COLON+ACCEPT+T1 , ACCEPTED);

		getActionButton.put(RecoveryStatusConstant.TOTALLOSS_ACCEPTED+COLON+FALSE+COLON+ACCEPT+T1 , ACCEPTED);

		getActionButton.put(RecoveryStatusConstant.LIABLITY_REVIEW+COLON+TRUE+COLON+ACCEPT+T1 , VIEW);

		getActionButton.put(RecoveryStatusConstant.DEBIT_NOTE_GENERATED+COLON+FALSE+COLON+ACCEPT+T1 , APPROVED);

		getActionButton.put(RecoveryStatusConstant.UNDER_INSPECTION+COLON+FALSE+COLON+ACCEPT+T2 , SAVE);

		getActionButton.put(RecoveryStatusConstant.MOVED_INSPECTION+COLON+FALSE+COLON+ACCEPT+T2 , SAVE);

		getActionButton.put(RecoveryStatusConstant.MOVED_INSPECTION+COLON+FALSE+COLON+ACCEPT+T2, VIEW);

		getActionButton.put(RecoveryStatusConstant.TOTALLOSS_INITITED+COLON+TRUE+COLON+ACCEPT+T2 , VIEW);

		getActionButton.put(RecoveryStatusConstant.SURVEYOR_ASSIGNED+COLON+FALSE+COLON+ACCEPT+T2 , ACCEPTED);

		getActionButton.put(RecoveryStatusConstant.LIABLITY_REVIEW+COLON+TRUE+COLON+ACCEPT+T2 , VIEW);

		getActionButton.put(RecoveryStatusConstant.DEBIT_NOTE_GENERATED+COLON+FALSE+COLON+ACCEPT+T2 , APPROVED);

	}
	
	/**
	 * Gets the status.
	 *
	 * @param status the status
	 * @return the status
	 */
	public String getStatus(String status){
		return getActionButton.get(status);
	}

}
