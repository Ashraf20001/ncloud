package com.digitalpaper.constants.core;

/**
 * The Enum ApprovalLimitDropdown.
 */
public enum ApprovalLimitDropdown{
	
	/** The Total loss estimated amount. */
	TotalLossEstimatedAmount(0,"TotalLossEstimatedAmount","Loss Details","Notification Stage"),
	
	/** The Sum insured. */
	SumInsured(1,"SumInsured","Insured Details","Notification Stage"),
	
	/** The Reserve amount. */
	ReserveAmount(2,"ReserveAmount","Loss Details","Notification Stage"),
	
	/** The Survey amount. */
	SurveyAmount(3,"SurveyAmount","Survey Report","Claim Inspection Stage"),
	
	/** The Claim amount. */
	ClaimAmount(4,"ClaimAmount","Recovery Details","Liability Confirmation Stage"),
	
	/** The Claim reserve amount. */
	ClaimReserveAmount(5,"ClaimReserveAmount","Reserve Review","Liability Confirmation Stage"),
	
	/** The TP survey amount. */
	TPSurveyAmount(6,"TPSurveyAmount","Reserve Review","Liability Confirmation Stage"),
	
	/** The Total claim amount. */
	TotalClaimAmount(7,"TotalClaimAmount","Reserve Review","Liability Confirmation Stage");
	


	/** The id. */
	private int id;
	
	/** The field. */
	private String field;
	
	/** The section. */
	private String section;
	
	/** The stage name. */
	private String stageName;
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * Gets the field.
	 *
	 * @return the field
	 */
	public String getField() {
		return field;
	}

	/**
	 * Gets the section.
	 *
	 * @return the section
	 */
	public String getSection() {
		return section;
	}
	
	/**
	 * Gets the stage name.
	 *
	 * @return the stage name
	 */
	public String getStageName() {
		return stageName;
	}

	
	/**
	 * Instantiates a new approval limit dropdown.
	 *
	 * @param id the id
	 * @param Field the field
	 * @param section the section
	 * @param stageName the stage name
	 */
	private	ApprovalLimitDropdown(Integer id,String Field,String section,String stageName) {
		this.id=id;
		this.field=Field;
		this.section=section;
		this.stageName=stageName;
		
	}
	
	/**
	 * Gets the approval limit dropdown.
	 *
	 * @param approvalLimitStr the approval limit str
	 * @return the approval limit dropdown
	 */
	public static ApprovalLimitDropdown getApprovalLimitDropdown(String approvalLimitStr) {
		for (ApprovalLimitDropdown ApprovalLimitDropdownEnum : ApprovalLimitDropdown.values()) {
			if(ApprovalLimitDropdownEnum.name().equalsIgnoreCase(approvalLimitStr)) {
				return ApprovalLimitDropdownEnum;
			}
		}
		return null;
	}
	
	/**
	 * Gets the approval limit dropdown.
	 *
	 * @param enumId the enum id
	 * @return the approval limit dropdown
	 */
	public static ApprovalLimitDropdown getApprovalLimitDropdown(Integer enumId) {
		for(ApprovalLimitDropdown ApprovalLimitDropdownEnum : ApprovalLimitDropdown.values()) {
			if(ApprovalLimitDropdownEnum.ordinal()==enumId) {
				return ApprovalLimitDropdownEnum;
			}
		}
		return null;

	}
	
		
}
