package com.digitalpaper.utils.core;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

import org.springframework.stereotype.Component;

import com.digitalpaper.constants.core.ApplicationConstants;



/**
 * The Class TimeZoneProvider.
 */
@Component
public class TimeZoneProvider {
	
	/**
	 * Instantiates a new time zone provider.
	 */
	private TimeZoneProvider() {
		/**/}

	/** The time zone. */
	private static Map<String, String> timeZone = new HashMap<>();

	static {
		timeZone.put("IST", "Asia/Calcutta");
		timeZone.put("UTC", "UTC");
		timeZone.put("EST", "America/New_York");
		timeZone.put("CST", "America/Havana");
		timeZone.put("GMT", "Asia/Bahrain");
		timeZone.put("GST", "Asia/Dubai");
	}

	/**
	 * Gets the conventional time zone.
	 *
	 * @param timeZoneStr the time zone str
	 * @return the conventional time zone
	 */
	public static String getConventionalTimeZone(String timeZoneStr) {
		return timeZone.get(timeZoneStr) == null ? timeZoneStr : timeZone.get(timeZoneStr);
	}

	/**
	 * Convert ist to utc.
	 *
	 * @param date the date
	 * @return the string
	 * @throws Exception the exception
	 */
	public static String convertIstToUtc(String date) throws Exception {
		Date date1 = convertStringToDate(date,ApplicationConstants.DEFAULT_DATE_FORMAT);
		SimpleDateFormat Formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		Formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
		String utcTime = Formatter.format(date1);
		return utcTime;

	}	

	
	
	/**
	 * Convert utc to ist.
	 *
	 * @param date the date
	 * @return the string
	 * @throws Exception the exception
	 */
	public static String convertUtcToIst(String date) throws Exception {
		Date date1 = convertStringToDate(date,ApplicationConstants.DEFAULT_DATE_FORMAT);
		SimpleDateFormat Formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		Formatter.setTimeZone(TimeZone.getTimeZone("IST"));
		String IstTime = Formatter.format(date1);
		return IstTime;

	}

	/**
	 * Convert string to date.
	 *
	 * @param date the date
	 * @param format the format
	 * @return the date
	 * @throws Exception the exception
	 */
	public static Date convertStringToDate(String date,String format) throws Exception {
		  SimpleDateFormat formatter=new SimpleDateFormat(format);  
		Date date1 = formatter.parse(date);
		return date1;
	}
	
	/**
	 * Convert string to local date time.
	 *
	 * @param date the date
	 * @param format the format
	 * @return the local date time
	 * @throws Exception the exception
	 */
	public static LocalDateTime convertStringToLocalDateTime(String date,String format) throws Exception{
	DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format); 
	LocalDateTime dateTime = LocalDateTime.parse(date, formatter);
	return dateTime;
	}
	
	/**
	 * Convert date to string.
	 *
	 * @param date the date
	 * @param format the format
	 * @return the string
	 * @throws Exception the exception
	 */
	public static String convertDateToString(Date date,String format)throws Exception{
		DateFormat dateFormat = new SimpleDateFormat(format);  
		String strDate = dateFormat.format(date); 
		return strDate;
		
	}
}
