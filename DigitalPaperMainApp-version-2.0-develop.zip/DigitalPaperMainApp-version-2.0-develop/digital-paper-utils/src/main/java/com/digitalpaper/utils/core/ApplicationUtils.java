/*
 * @author codeboard
 */
package com.digitalpaper.utils.core;

import java.lang.reflect.Field;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import org.apache.poi.ss.formula.functions.T;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

/**
 * The Class ApplicationUtils.
 */
@Component
public class ApplicationUtils {

	/** The Constant RANGE. */
	private static final String RANGE = "0123456789";
	
	/** The Constant OBJECT_MAPPER. */
	@Autowired
	private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper().registerModule(new JavaTimeModule());

	/**
	 * Gets the unique id.
	 *
	 * @return the unique id
	 */
	public static String getUniqueId() {
		return UUID.randomUUID().toString();
	}

	/**
	 * Checks if is blank.
	 *
	 * @param input the input
	 * @return true, if is blank
	 */
	public static boolean isBlank(String input) {
		return input == null || input.trim().isEmpty();
	}

	/**
	 * Checks if is not blank.
	 *
	 * @param input the input
	 * @return true, if is not blank
	 */
	public static boolean isNotBlank(String input) {
		return !isBlank(input);
	}

	/**
	 * Checks if is not valid id.
	 *
	 * @param id the id
	 * @return true, if is not valid id
	 */
	public static boolean isNotValidId(Integer id) {
		return !isValidId(id);
	}

	/**
	 * Checks if is validate object.
	 *
	 * @param obj the obj
	 * @return true, if is validate object
	 */
	@SuppressWarnings("rawtypes")
	public static boolean isValidateObject(Object obj) {
		if (obj == null) {
			return false;
		}

		if (obj instanceof List<?> && ((Collection<?>) obj).isEmpty()) {
			return false;
		}

		if (obj instanceof Map<?, ?> && ((Map) obj).isEmpty()) {
			return false;
		}

		if (obj instanceof Set<?>) {
			return !((Set) obj).isEmpty();
		}

		return true;
	}

	/**
	 * Checks if is valid string.
	 *
	 * @param value the value
	 * @return true, if is valid string
	 */
	public static boolean isValidString(String value) {
		return value != null && !value.trim().isBlank();
	}

	/**
	 * Checks if is valid id.
	 *
	 * @param id the id
	 * @return true, if is valid id
	 */
	public static boolean isValidId(Integer id) {
		return id != null && id >= 1;

	}
	/**
	 * Checks if is valid identity.
	 *
	 * @param identity the identity
	 * @return true, if is valid identity
	 */
	public static boolean isValidIdentity(String identity) {
		return !isBlank(identity) && !identity.trim().equals("-1") && !identity.equalsIgnoreCase("undefined")
				&& !identity.equalsIgnoreCase("null");
	}

	/**
	 * Checks if is valid list.
	 *
	 * @param list the list
	 * @return true, if is valid list
	 */
	public static boolean isValidList(List<?> list) {
		return list != null && !list.isEmpty();

	}

	/**
	 * Checks if is valid long.
	 *
	 * @param value the value
	 * @return true, if is valid long
	 */
	public static boolean isValidLong(Long value) {
		return value != null && value >= 0;
	}


	/**
	 * Checks if is valid object.
	 *
	 * @param input the input
	 * @return true, if is valid object
	 */
	public static boolean isValidObject(Object input) {
		return (input != null);
	}

	/**
	 * To Generate otp
	 *
	 * @throws
	 */
	public String generateOtp(Integer otpLength) {
		String numbers = RANGE;
		char[] otp = new char[otpLength];
		for (int i = 0; i < otpLength; i++) {
			otp[i] = numbers.charAt(ThreadLocalRandom.current().nextInt(numbers.length()));
		}
		return new String(otp);
	}

	/**
	 * Convert map to object.
	 *
	 * @param classEntity the class entity
	 * @param singleEntity the single entity
	 * @return the object
	 * @throws JsonProcessingException the json processing exception
	 */
	public static Object convertMapToObject(Class<T> classEntity, Object singleEntity) throws JsonProcessingException {
		String jsonString = OBJECT_MAPPER.writeValueAsString(singleEntity);
		Object entityObject = OBJECT_MAPPER.readValue(jsonString, classEntity);
		return entityObject;
	}

	/**
	 * Gets the column name reflect.
	 *
	 * @param field the field
	 * @return the column name reflect
	 */
	public static String getColumnNameReflect(Field field) {
		Column columnName = field.getAnnotation(Column.class);
		return columnName.name();
	}

	/**
	 * Gets the join column name reflect.
	 *
	 * @param field the field
	 * @return the join column name reflect
	 */
	public static String getJoinColumnNameReflect(Field field) {
		JoinColumn columnName = field.getAnnotation(JoinColumn.class);
		return columnName.name();
	}

	/**
	 * Gets the entity name.
	 *
	 * @param entityClass the entity class
	 * @return the entity name
	 */
	public static String getEntityName(Class<?> entityClass) {
		Entity entityAnnotation = entityClass.getAnnotation(Entity.class);
		Table tableAnnotation = entityClass.getAnnotation(Table.class);

		if (tableAnnotation != null && !tableAnnotation.name().isEmpty()) {
			return tableAnnotation.name();
		} else if (entityAnnotation != null && !entityAnnotation.name().isEmpty()) {
			return entityAnnotation.name();
		} else {
			return entityClass.getSimpleName();
		}
	}

	/**
	 * Gets the primary id column.
	 *
	 * @param entityClass the entity class
	 * @return the primary id column
	 */
	public static String getPrimaryIdColumn(Class<?> entityClass) {
		for (Field field : entityClass.getDeclaredFields()) {
			if (field.isAnnotationPresent(Column.class)) {
				Column childColumnName = field.getAnnotation(Column.class);
				return childColumnName.name();
			}
		}
		return null;
	}

}
