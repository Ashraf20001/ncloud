package com.digitalpaper.utils.core;

import java.util.Arrays;
import javax.servlet.http.HttpServletRequest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import com.digitalpaper.constants.core.ApplicationConstants;

/**
 * The Class RestTemplateUtils.
 */
@Component
public class RestTemplateUtils {

	/**
	 * @return HttpHeaders
	 */
	public HttpHeaders getPOSTHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON.toString() + ";charset=UTF-8");
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		return headers;
	}

	/**
	 * @return HttpHeaders
	 */
	public HttpHeaders getGETHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON.toString() + ";charset=UTF-8");
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		return headers;
	}

	/**
	 * @param request
	 * @return
	 */
	public HttpHeaders configureRestTemplate(HttpServletRequest request) {
		HttpHeaders httpHeaders = null;
		String authorizationHeader = request.getHeader(ApplicationConstants.AUTHORIZATION);
		String authToken = "";
		if (ApplicationUtils.isValidateObject(authorizationHeader)) {
			 authToken = authorizationHeader.replace(ApplicationConstants.BEARER, ApplicationConstants.EMPTY_STRING)
					.trim();
		}
		if(HttpMethod.GET.toString().equals(request.getMethod())) {
			httpHeaders = getGETHeaders();
		}else {
			httpHeaders = getPOSTHeaders();
		}
		httpHeaders.setBearerAuth(authToken);
		return httpHeaders;
	}
}
