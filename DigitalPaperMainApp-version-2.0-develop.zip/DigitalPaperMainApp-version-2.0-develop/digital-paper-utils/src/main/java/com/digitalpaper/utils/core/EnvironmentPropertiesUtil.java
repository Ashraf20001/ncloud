package com.digitalpaper.utils.core;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.digitalpaper.constants.serverproperties.PropertyValueProvider;






/**
 * The Class EnvironmentPropertiesUtil.
 */
@Configuration
public class EnvironmentPropertiesUtil {
	
	
	/** The configuration properties. */
	@Autowired
	private PropertyValueProvider configurationProperties;
	
		
	/**
	 * Gets the time zone.
	 *
	 * @return the time zone
	 */
	public String getTimeZone() {
		return configurationProperties.getTimeZone();
	}
	
	/**
	 * Gets the date format.
	 *
	 * @return the date format
	 */
	public String getDateFormat() {
		return configurationProperties.getDateFormat();
	}
	
	/**
	 * Gets the currency format.
	 *
	 * @return the currency format
	 */
	public String getCurrencyFormat() {
		return configurationProperties.getCurrencyFormat();
	}
	
	/**
	 * Gets the number format.
	 *
	 * @return the number format
	 */
	public String getNumberFormat() {
		return configurationProperties.getNumberFormat();
	}
	
	/**
	 * Gets the country code.
	 *
	 * @return the country code
	 */
	public String getCountryCode() {
		return configurationProperties.getCountryCode();
	}
}