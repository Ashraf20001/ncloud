package com.digitalpaper.utils;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * The Class DigitalPaperUtilsApplication.
 */
@SpringBootApplication
@ComponentScan("com.digitalpaper.*")
public class DigitalPaperUtilsApplication {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		
	}

}
