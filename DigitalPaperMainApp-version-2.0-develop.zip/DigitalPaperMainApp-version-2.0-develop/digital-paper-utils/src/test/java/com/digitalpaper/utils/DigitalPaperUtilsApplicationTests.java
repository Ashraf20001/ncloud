package com.digitalpaper.utils;
//package com.digitalpaper.utils;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class RecoveryPortalUtilsApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
