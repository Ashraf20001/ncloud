package com.digitalpaper.aop.consumer;

import com.digitalpaper.aop.dao.AuditMongoRepository;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.transfer.object.entity.DPAuditEntity;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class AuditConsumer {

    private final ObjectMapper objectMapper;

    private final AuditMongoRepository mongoRepository;

    private static final Logger LOGGER = LoggerFactory.getLogger(AuditConsumer.class);

    @KafkaListener(topics = ApplicationConstants.KAFKA_TOPIC)
    public void getKafkaAuditDetails(String obj, Acknowledgment acknowledgment) throws JsonMappingException, JsonProcessingException {
        LOGGER.info("====> Drop of audit consumer received");
        acknowledgment.acknowledge();
        try {
            DPAuditEntity auditData = objectMapper.readValue(obj, DPAuditEntity.class);
            mongoRepository.save(auditData);
        } catch (Exception e) {
            LOGGER.error(e.getLocalizedMessage());
        }
    }
}