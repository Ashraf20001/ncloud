package com.digitalpaper.aop;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;


@SpringBootApplication
@ComponentScan("com.digitalpaper.*")
public class DigitalPaperAopApplication {

	public static void main(String[] args) {
	}
	

}
