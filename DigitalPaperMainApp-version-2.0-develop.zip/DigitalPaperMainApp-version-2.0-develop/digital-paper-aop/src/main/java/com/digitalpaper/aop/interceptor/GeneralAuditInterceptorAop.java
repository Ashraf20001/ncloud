package com.digitalpaper.aop.interceptor;
import java.time.LocalDateTime;

import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.exception.core.ApplicationException;
import com.digitalpaper.transfer.object.core.ApplicationResponse;
import com.digitalpaper.transfer.object.entity.DPAuditEntity;
import com.digitalpaper.transfer.object.utils.LoggedInUserContextHolder;
import com.digitalpaper.utils.core.ApplicationUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.ContentCachingRequestWrapper;

@Aspect
@Component
@RequiredArgsConstructor
public class GeneralAuditInterceptorAop {

    private static final Logger LOGGER = LoggerFactory.getLogger(GeneralAuditInterceptorAop.class);

    /**
     * LoggedInUserContextHolder
     */
    private final LoggedInUserContextHolder loggedInUserContextHolder;

    /**
     * kafka
     */
    private final KafkaTemplate<String, String> kafkaTemplate;

    /**
     * ObjectMapper
     */
    private final ObjectMapper objectMapper;



    /**
     * @param joinPoint
     * @return
     * @throws Throwable
     */
    @Around("com.digitalpaper.aop.interceptor.CommonAopAspects.auditAnnotation()")
    public Object audit(ProceedingJoinPoint joinPoint) throws Throwable {
        Integer userId= ApplicationUtils.isValidateObject(loggedInUserContextHolder.getLoggedInUser())? loggedInUserContextHolder.getLoggedInUser().getId() : null;
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        ContentCachingRequestWrapper wrapper = new ContentCachingRequestWrapper(attributes.getRequest());
        String requestURI = wrapper.getRequestURI();
        Object result = null;
        if(ApplicationUtils.isValidId(userId)) {
        	try {
    			result=joinPoint.proceed();
    			auditDataThroughKafka(joinPoint,result,requestURI,userId);
    		}catch(Exception e) {
    			result=e;
    			auditDataThroughKafka(joinPoint,result,requestURI,userId);
    			throw e;
    		}
        }else {
        	result=joinPoint.proceed();
        }
        return result;
    }




    /**
     * @param result
     * @param requestURI
     * @param userId
     * @throws JsonProcessingException
     */
    private void auditDataThroughKafka(ProceedingJoinPoint joinPoint,Object result, String requestURI,
                                       Integer userId) throws JsonProcessingException {
        DPAuditEntity auditEntity=null;
        
        if(ApplicationUtils.isValidateObject(result)) {
        	  if(result instanceof ApplicationResponse) {
                  ApplicationResponse obj=(ApplicationResponse)result;
                  LOGGER.info("======> AOP Method {} executed and returned {} ",joinPoint.getSignature(),obj.getContent().toString());
                  auditEntity=setAuditEntityData(obj.getContent(), requestURI, userId);
              }
              else if (result instanceof ApplicationException) {
                  ApplicationException obj=(ApplicationException)result;
                  LOGGER.info("======> AOP Method {} executed and returned {} ",joinPoint.getSignature(),obj.getLocalizedMessage());
                  auditEntity=setAuditEntityData(obj.getLocalizedMessage(), requestURI,userId);
              }
              else if(result instanceof Exception) {
                  Exception obj=(Exception) result;
                  LOGGER.info("======> AOP Method {} executed and returned {} ",joinPoint.getSignature(),obj.getLocalizedMessage());
                  auditEntity=setAuditEntityData(obj.getLocalizedMessage(), requestURI,userId);
              }
              else {
                  auditEntity=setAuditEntityData(result.toString(), requestURI, userId);
                  LOGGER.info("======> AOP Method {} executed and returned {} ",joinPoint.getSignature(),result.toString());
              }
              String auditedValueString = objectMapper.writeValueAsString(auditEntity);
              kafkaTemplate.send(ApplicationConstants.KAFKA_TOPIC, auditedValueString);

        }
        
     }




    private DPAuditEntity setAuditEntityData(Object result, String requestURI,
                                                 Integer userId) {
        return new DPAuditEntity()
                .setAuditDate(LocalDateTime.now())
                .setRequestUrl(requestURI)
                .setResponse(result.toString())
                .setUserId(userId.toString());
    }


}
