package com.digitalpaper.aop.dao;



import com.digitalpaper.transfer.object.entity.DPAuditEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuditMongoRepository extends MongoRepository<DPAuditEntity,String> {
}

