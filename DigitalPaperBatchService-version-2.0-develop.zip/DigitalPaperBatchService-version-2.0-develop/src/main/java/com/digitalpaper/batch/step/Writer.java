package com.digitalpaper.batch.step;

import java.util.List;
import java.util.UUID;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.digitalpaper.batch.dao.CustomerNotificationDao;
import com.digitalpaper.transfer.object.entity.CustomerNotification;

public class Writer implements ItemWriter<List<CustomerNotification>>{
	
	@Autowired
	private CustomerNotificationDao customerNotificationDao;
	

	@Override
	public void write(List<? extends List<CustomerNotification>> customerNotification) throws Exception {
		
		for (CustomerNotification notification : customerNotification.get(0)) {
			notification.setIdentity(UUID.randomUUID().toString().replace("-", ""));
			customerNotificationDao.saveCustomerNotification(notification);
		}
		
		System.out.println("the end");
		
	}



}
