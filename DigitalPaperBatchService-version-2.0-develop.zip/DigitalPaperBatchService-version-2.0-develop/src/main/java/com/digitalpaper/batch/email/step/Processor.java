package com.digitalpaper.batch.email.step;

import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.transfer.object.entity.Stock;

/**
 * The Class Processor.
 */
public class Processor implements ItemProcessor<List<Stock>, List<Stock>> {

	/** The rest template. */
	@Autowired
	private RestTemplate restTemplate;
	
	/** The gateway url. */
	@Value("${gateway.url}")
	private String gatewayUrl;
	
	/**
	 * Process.
	 *
	 * @param stocks the stocks
	 * @return the list
	 * @throws Exception the exception
	 */
	@Override
	public List<Stock> process(List<Stock> stocks) throws Exception {
		HashMap<String, String> systemPropertiesValue = getSystemPropertiesValue();
		System.out.println("process2 triggered");
		List<Stock> filteredStocks = stocks.stream().filter(x->(x.getStockCount()-x.getUsedCount())< Integer.parseInt(systemPropertiesValue.get("Minimum Paper Limit"))).collect(Collectors.toList());
		return filteredStocks;
	}
	
	/**
	 * Gets the system properties value.
	 *
	 * @return the system properties value
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public HashMap<String, String> getSystemPropertiesValue(){
		ResponseEntity<HashMap> forEntity = restTemplate.getForEntity(gatewayUrl+ApplicationConstants.COMMON_SYSTEM_PROPERTY_URL, HashMap.class);
		return forEntity.getBody();
	}

}
