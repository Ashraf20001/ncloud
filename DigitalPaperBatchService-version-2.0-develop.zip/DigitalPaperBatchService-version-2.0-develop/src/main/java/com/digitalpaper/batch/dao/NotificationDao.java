package com.digitalpaper.batch.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.transfer.object.entity.NotificationEvent;
import com.digitalpaper.transfer.object.entity.NotificationTemplate;

/**
 * The Class NotificationDao.
 */
@Repository
public class NotificationDao {

	/** The entity manager. */
	@PersistenceContext
	@Autowired
	private EntityManager entityManager;
	
	/**
	 * Gets the notification template.
	 *
	 * @param eventId the event id
	 * @param action the action
	 * @return the notification template
	 */
	public NotificationTemplate getNotificationTemplate(Integer eventId,String action) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<NotificationTemplate> query = builder.createQuery(NotificationTemplate.class);
		Root<NotificationTemplate> root = query.from(NotificationTemplate.class);
		query.select(root);
		Predicate isDeleted = builder.and(builder.equal(root.get(TableConstants.IS_DELETED), false));
		Predicate eventPredicate = builder.and(builder.equal(root.get(TableConstants.EVENTID), eventId));
		Predicate actionPredicate = builder.and(builder.equal(root.get(TableConstants.ACTION), action));
		Predicate finalPredicate = builder.and(isDeleted,eventPredicate,actionPredicate);
		query.where(finalPredicate);
		return entityManager.createQuery(query).getSingleResult();
		
	}
	
	/**
	 * Gets the notificationevent.
	 *
	 * @param eventName the event name
	 * @return the notificationevent
	 */
	public NotificationEvent getNotificationevent(String eventName) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<NotificationEvent> query = builder.createQuery(NotificationEvent.class);
		Root<NotificationEvent> root = query.from(NotificationEvent.class);
		query.select(root);
		Predicate isDeleted = builder.and(builder.equal(root.get(TableConstants.IS_DELETED), false));
		Predicate eventPredicate = builder.and(builder.equal(root.get(TableConstants.STOCK_EVENT_NAME), eventName));
		Predicate finalPredicate = builder.and(isDeleted,eventPredicate);
		query.where(finalPredicate);
		return entityManager.createQuery(query).getSingleResult();
		
	}
	

}
