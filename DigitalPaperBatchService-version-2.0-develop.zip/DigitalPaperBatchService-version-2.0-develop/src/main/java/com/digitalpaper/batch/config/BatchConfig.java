package com.digitalpaper.batch.config;

import java.util.List;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.web.client.RestTemplate;

import com.digitalpaper.batch.dao.PaperDetailsDao;
import com.digitalpaper.batch.listner.JobCompletionListener;
import com.digitalpaper.batch.listner.JobCompletionListenerForEmail;
import com.digitalpaper.batch.step.Processor;
import com.digitalpaper.batch.step.Reader;
import com.digitalpaper.batch.step.Writer;
import com.digitalpaper.transfer.object.entity.CustomerNotification;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.entity.Stock;

/**
 * The Class BatchConfig.
 */
@Configuration
@EnableKafka
public class BatchConfig {

	/**
	 * jobBuilderFactory
	 */
	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	/**
	 * stepBuilderFactory
	 */
	@Autowired
	public StepBuilderFactory stepBuilderFactory;


	/**
	 * Process job.
	 *
	 * @return the job
	 */
	@Bean
	public Job processJob() {
		return jobBuilderFactory.get("processJob").incrementer(new RunIdIncrementer()).listener(listener())
				.flow(orderStep()).end().build();
	}


	/**
	 * Order step.
	 *
	 * @return the step
	 */
	@Bean
	public Step orderStep() {
		return stepBuilderFactory.get("orderStep").<List<PaperDetails>, List<CustomerNotification>> chunk(1)
				.reader(getReader()).processor(getProcessor())
				.writer(getWriter()).build();
	}

	
	/**
	 * Listener.
	 *
	 * @return the job execution listener
	 */
	@Bean
	public JobExecutionListener listener() {
		return new JobCompletionListener();
	}
	

	/**
	 * Gets the paper details dao.
	 *
	 * @return the paper details dao
	 */
	@Autowired
	@Bean(name="paperDetailsDao")
	public PaperDetailsDao getPaperDetailsDao() {
		return new PaperDetailsDao();
	}
	
	/**
	 * Gets the rest template.
	 *
	 * @return the rest template
	 */
	@Autowired
	@Bean(name="restTemplate")
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}
	
	
	/**
	 * Gets the reader.
	 *
	 * @return the reader
	 */
	@Bean
	public ItemReader<List<PaperDetails>> getReader() {
		return new Reader();
	}
	
	/**
	 * Gets the processor.
	 *
	 * @return the processor
	 */
	@Bean
	public ItemProcessor<List<PaperDetails>, List<CustomerNotification>> getProcessor() {
		return new Processor();
	}
	
	/**
	 * Gets the writer.
	 *
	 * @return the writer
	 */
	@Bean
	public ItemWriter<List<CustomerNotification>> getWriter() {
		return new Writer();
	}

	
	/**
	 * Stock email topic.
	 *
	 * @return the new topic
	 */
	@Bean
    public NewTopic stockEmailTopic() {
        return new NewTopic("stock-email-topic", 1, (short) 1);
    }
	
	// second job
	

	/**
	 * Process jobfor email.
	 *
	 * @return the job
	 */
	@Bean
	public Job processJobforEmail() {
		return jobBuilderFactory.get("processJobforEmail").incrementer(new RunIdIncrementer()).listener(listener())
				.flow(orderStep2()).end().build();
	}

	
	/**
	 * Order step for second job.
	 *
	 * @return the step
	 */
	@Bean
	public Step orderStep2() {
		return stepBuilderFactory.get("orderStep2").<List<Stock>, List<Stock>> chunk(1)
				.reader(getReader2()).processor(getProcessor2())
				.writer(getWriter2()).build();
	}
	
	
	/**
	 * Gets the reader for second job.
	 *
	 * @return the reader for second job
	 */
	@Bean
	public ItemReader<List<Stock>> getReader2() {
		return new com.digitalpaper.batch.email.step.Reader();
	}
	
	/**
	 * Gets the processor for second job.
	 *
	 * @return the processor for second job
	 */
	@Bean
	public ItemProcessor<List<Stock>, List<Stock>> getProcessor2() {
		return new com.digitalpaper.batch.email.step.Processor();
	}
	
	/**
	 * Gets the writer for second job.
	 *
	 * @return the writer for second job
	 */
	@Bean
	public ItemWriter<List<Stock>> getWriter2() {
		return new com.digitalpaper.batch.email.step.Writer();
	}


	/**
	 * Job completion listener for email.
	 *
	 * @return the job completion listener for email
	 */
	@Bean
	public JobCompletionListenerForEmail jobCompletionListenerForEmail() {
		return new JobCompletionListenerForEmail();
	}


}
