package com.digitalpaper.batch.controller;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 
/**
 * The Class JobInvokerController.
 */
@RestController
@EnableScheduling
public class JobInvokerController {
 
    /** The job launcher. */
    @Autowired
    JobLauncher jobLauncher;
 
    /** The process job. */
    @Autowired
    Job processJob;
    
    /** The process jobfor email. */
    @Autowired
    Job processJobforEmail;
    
    /**
     * Handle two job execution by multi-threading.
     *
     * @return the string
     * @throws Exception the exception
     */
    @RequestMapping("/invokejob")
    public String handle() throws Exception {
    	
    	JobParameters jobParameters1 = new JobParametersBuilder().addLong("time", System.currentTimeMillis()).toJobParameters();
        JobParameters jobParameters2 = new JobParametersBuilder().addLong("time", System.currentTimeMillis()).toJobParameters();

        new Thread(() -> {
            try {
                JobExecution execution = jobLauncher.run(processJob, jobParameters1);
                System.out.println("Job 1 execution status: " + execution.getStatus());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
        
        new Thread(() -> {
            try {
                JobExecution execution = jobLauncher.run(processJobforEmail, jobParameters2);
                System.out.println("Job 2 execution status: " + execution.getStatus());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
 
        return "Batch job has been invoked";
    }
    

    
    /**
     * Schedule method invocation.
     *
     * @throws Exception the exception
     */
    @Scheduled(cron = "${batch.job.cron}") 
    public void scheduleMethodInvocation() throws Exception {
    	handle();
    }
}