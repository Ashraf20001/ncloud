package com.digitalpaper.batch.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.digitalpaper.constants.core.TableConstants;
import com.digitalpaper.transfer.object.entity.PaperDetails;
import com.digitalpaper.transfer.object.entity.Stock;

/**
 * The Class PaperDetailsDao.
 */
@Repository
public class PaperDetailsDao {
	
	/** The entity manager. */
	@PersistenceContext
	@Autowired
	private EntityManager entityManager;
	
	/**
	 * Gets the all paper details.
	 *
	 * @return the all paper details
	 */
	public List<PaperDetails> getAllPaperDetails() {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<PaperDetails> query = builder.createQuery(PaperDetails.class);
		Root<PaperDetails> root = query.from(PaperDetails.class);
		query.select(root);
		Predicate isDeleted = builder.and(builder.equal(root.get(TableConstants.IS_DELETED), false));
		Predicate status = builder.and(builder.equal(root.get(TableConstants.STATUS), 1));
		Predicate finalPredicate = builder.and(isDeleted,status);
		query.where(finalPredicate);
		return entityManager.createQuery(query).getResultList();
	}

	
	/**
	 * Gets the all stock.
	 *
	 * @return the all stock
	 */
	public List<Stock> getAllStock() {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Stock> query = builder.createQuery(Stock.class);
		Root<Stock> root = query.from(Stock.class);
		query.select(root);
		Predicate isDeleted = builder.and(builder.equal(root.get(TableConstants.ISDELETED), false));
		Predicate finalPredicate = builder.and(isDeleted);
		query.where(finalPredicate);
		return entityManager.createQuery(query).getResultList();
	}



	/**
	 * Update paper details.
	 *
	 * @param paperDetails the paper details
	 */
	public void updatePaperDetails(PaperDetails paperDetails) {
		entityManager.persist(paperDetails);
		
	}

}
