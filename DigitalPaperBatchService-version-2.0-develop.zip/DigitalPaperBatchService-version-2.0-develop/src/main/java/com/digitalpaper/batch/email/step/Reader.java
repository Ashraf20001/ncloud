package com.digitalpaper.batch.email.step;

import java.util.List;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Autowired;

import com.digitalpaper.batch.dao.PaperDetailsDao;
import com.digitalpaper.transfer.object.entity.Stock;

/**
 * The Class Reader.
 */
public class Reader implements ItemReader<List<Stock>> {

	/** The paper details dao. */
	@Autowired
	private PaperDetailsDao paperDetailsDao;  

	/** The count. */
	private int count = 0;
	
	/**
	 * Read.
	 *
	 * @return the list
	 * @throws Exception the exception
	 * @throws UnexpectedInputException the unexpected input exception
	 * @throws ParseException the parse exception
	 * @throws NonTransientResourceException the non transient resource exception
	 */
	@Override
	public List<Stock> read()
			throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		System.out.println("process2 triggered");
		List<Stock> allStock = null;
		if (count==0) {
			allStock = paperDetailsDao.getAllStock();	
			count++;
		} else {
			count = 0;
			return null;
		}
		return allStock;

	}

}
