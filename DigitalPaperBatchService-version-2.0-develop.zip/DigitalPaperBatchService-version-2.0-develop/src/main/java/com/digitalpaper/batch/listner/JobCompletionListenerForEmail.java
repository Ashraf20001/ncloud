package com.digitalpaper.batch.listner;

import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.digitalpaper.exception.core.ApplicationException;

/**
 * The Class JobCompletionListenerForEmail.
 */
@Configuration
public class JobCompletionListenerForEmail extends JobExecutionListenerSupport{

	/** The bootstrap server. */
	@Value("${spring.kafka.consumer.bootstrap-servers}")
    private String bootstrapServer;
	
	/** The Constant TOPIC. */
	private static final String TOPIC = "stock-email-topic";
	
	/** The Constant Logger. */
	private static final Logger Logger= LoggerFactory.getLogger(JobCompletionListenerForEmail.class);
	
	/**
	 * Stock email send.
	 *
	 * @param emailMessage the email message
	 * @throws ApplicationException the application exception
	 */
	public void stockEmailSend(String emailMessage) throws ApplicationException {
		try (KafkaProducer<String, String> producer = new KafkaProducer<>(getKafkaProducerConfig())) {
			ProducerRecord<String, String> record = new ProducerRecord<>(TOPIC, emailMessage);
			producer.send(record);
			Logger.info("Data sent to Kafka topic {} successfully.",TOPIC);
		} catch (Exception e) {
			Logger.info(e.getLocalizedMessage());
			throw new ApplicationException(e.getLocalizedMessage());
		}

	}
	
	/**
	 * kafka configuration
	 * @return producerConfiguration
	 */
	private Properties getKafkaProducerConfig() {
	    Properties props = new Properties();
	    props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServer);
	    props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
	    props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
	    return props;
	}


}
