package com.digitalpaper.batch.dao;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.digitalpaper.transfer.object.entity.CustomerNotification;


/**
 * The Class CustomerNotificationDao.
 */
@Repository
public class CustomerNotificationDao{
	
	/** The entity manager. */
	@PersistenceContext
	@Autowired
	private EntityManager entityManager;
	
	/**
	 * Save customer notification.
	 *
	 * @param customerNotification the customer notification
	 */
	public void saveCustomerNotification(CustomerNotification customerNotification) {
		entityManager.persist(customerNotification);
	}


}
