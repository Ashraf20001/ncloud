package com.digitalpaper.batch.step;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.digitalpaper.batch.dao.PaperDetailsDao;
import com.digitalpaper.batch.service.NotificationService;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.transfer.object.entity.CustomerNotification;
import com.digitalpaper.transfer.object.entity.PaperDetails;

public class Processor implements ItemProcessor<List<PaperDetails>, List<CustomerNotification>>{
	
	@Autowired
	NotificationService notificationService;
	@Autowired
	PaperDetailsDao paperDetailsDao;
	@Autowired
	private RestTemplate restTemplate;
	
	@Value("${gateway.url}")
	private String gatewayUrl;


	@Override
	public List<CustomerNotification> process(List<PaperDetails> listOfPaperDetails) throws Exception {
		HashMap<String, String> systemPropertiesValue = getSystemPropertiesValue();
		String value = systemPropertiesValue.get("Paper expiration mail trigger days");
		Integer days = (value!=null || !value.equals(""))?Integer.parseInt(value):0;
		
		List<CustomerNotification> customerNotificationList = new ArrayList<>();
		for (PaperDetails paperDetails : listOfPaperDetails) {
			if ((ChronoUnit.MINUTES.between(LocalDateTime.now(),paperDetails.getPdExpireDate())) <days) {
				// trigger notification
				paperDetails.setStatus(2);
				paperDetailsDao.updatePaperDetails(paperDetails);
			}
			else if ((ChronoUnit.DAYS.between(LocalDateTime.now(),paperDetails.getPdExpireDate()))<=3) {
				try {
					CustomerNotification saveNotification = notificationService.saveNotification(paperDetails, (ChronoUnit.DAYS.between(LocalDateTime.now(),paperDetails.getPdExpireDate())));
					customerNotificationList.add(saveNotification);
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
			
		}
		return customerNotificationList;
	}
	
	public HashMap<String, String> getSystemPropertiesValue(){
		ResponseEntity<HashMap> forEntity = restTemplate.getForEntity(gatewayUrl+ApplicationConstants.COMMON_SYSTEM_PROPERTY_URL, HashMap.class);
		return forEntity.getBody();
	}


}
