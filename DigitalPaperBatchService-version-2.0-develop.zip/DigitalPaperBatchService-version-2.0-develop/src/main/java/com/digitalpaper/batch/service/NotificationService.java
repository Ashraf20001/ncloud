package com.digitalpaper.batch.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.digitalpaper.batch.dao.CustomerNotificationDao;
import com.digitalpaper.batch.dao.NotificationDao;
import com.digitalpaper.constants.core.ApplicationConstants;
import com.digitalpaper.transfer.object.entity.CustomerNotification;
import com.digitalpaper.transfer.object.entity.NotificationEvent;
import com.digitalpaper.transfer.object.entity.NotificationTemplate;
import com.digitalpaper.transfer.object.entity.PaperDetails;

/**
 * The Class NotificationService.
 */
@Service
public class NotificationService {
	
	/** The notification dao. */
	@Autowired
	NotificationDao notificationDao;
	
	/** The customer notification dao. */
	@Autowired
	CustomerNotificationDao customerNotificationDao;
	
	/**
	 * Save notification.
	 *
	 * @param paperDetails the paper details
	 * @param days the days
	 * @return the customer notification
	 */
	public CustomerNotification saveNotification(PaperDetails paperDetails,Long days) {
		NotificationEvent notificationevent = notificationDao.getNotificationevent(ApplicationConstants.PAPER_EXPIRE);
		NotificationTemplate notificationTemplate = notificationDao.getNotificationTemplate(notificationevent.getEventId(), "EXPIRY");
		StringBuilder finalNotificationMessage = new StringBuilder();
		finalNotificationMessage.append(notificationTemplate.getContent().replaceAll("DIGITAL_PAPER_NO","<b>"+paperDetails.getPdDigitalPaperId()+"</b>")
				.replaceAll("NO_DAYS","<b>"+ days.toString()+"</b>"));
		CustomerNotification savedCustomerNotification = saveCustomerNotification(paperDetails,finalNotificationMessage);
		return savedCustomerNotification;
		
	}

	/**
	 * Save customer notification.
	 *
	 * @param paperDetails the paper details
	 * @param finalNotificationMessage the final notification message
	 * @return the customer notification
	 */
	private CustomerNotification saveCustomerNotification(PaperDetails paperDetails, StringBuilder finalNotificationMessage) {
		CustomerNotification customerNotification = new CustomerNotification();
		customerNotification.setIsDeleted(false);
		customerNotification.setActedBy(paperDetails.getCustomer().getCompanyId());
		customerNotification.setCreatedDate(LocalDateTime.now());
		customerNotification.setNotificationMsg(finalNotificationMessage.toString());
		customerNotification.setRead(false);
		customerNotification.setToNotify(paperDetails.getCustomer().getCustomerId());
		return customerNotification;
	}

	

}
