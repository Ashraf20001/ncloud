package com.digitalpaper.batch.step;

import java.util.List;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

import com.digitalpaper.batch.dao.PaperDetailsDao;
import com.digitalpaper.transfer.object.entity.PaperDetails;


public class Reader implements ItemReader<List<PaperDetails>> {
	
	@Autowired
	PaperDetailsDao paperDetailsDao;
	
	@Autowired
	RestTemplate restTemplate;
	
	private int count = 0;
	

	@Override
	public List<PaperDetails> read()
			throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		
		List<PaperDetails> allPaperDetails = null;
		if (count==0) {
		 allPaperDetails = paperDetailsDao.getAllPaperDetails();	
			count++;
		} else {
			count = 0;
			return null;
		}
		return allPaperDetails;
	}


	
	


}
