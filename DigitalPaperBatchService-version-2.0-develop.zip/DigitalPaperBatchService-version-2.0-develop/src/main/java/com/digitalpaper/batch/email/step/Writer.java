package com.digitalpaper.batch.email.step;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.digitalpaper.batch.listner.JobCompletionListenerForEmail;
import com.digitalpaper.transfer.object.dto.StockDto;
import com.digitalpaper.transfer.object.entity.Stock;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * The Class Writer.
 */
public class Writer implements ItemWriter<List<Stock>> {

	/** The kafka template. */
	@Autowired
    private JobCompletionListenerForEmail kafkaTemplate;
	
	/**
	 * Write will drop stock details in Kafka template.
	 *
	 * @param items the items
	 * @throws Exception the exception
	 */
	@Override
	public void write(List<? extends List<Stock>> items) throws Exception {
		for (Stock list : items.get(0)) {
		
			StockDto stock = new StockDto();
			stock.setCompanyId(list.getCompanyId());
			stock.setAvailableCount(list.getUsedCount());
			stock.setStockCount(list.getStockCount());
			
			ObjectMapper mapper = new ObjectMapper();
			String reqJson = mapper.writeValueAsString(stock);
			
			kafkaTemplate.stockEmailSend(reqJson);
		}


	}

}
