package com.digitalpaper.batch.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.client.RestTemplate;

import com.digitalpaper.batch.DigitalPaperNotificationBatchApplication;
import com.digitalpaper.batch.dao.PaperDetailsDao;
import com.digitalpaper.batch.mockdata.MockData;
import com.digitalpaper.batch.step.Reader;
import com.digitalpaper.transfer.object.entity.PaperDetails;


@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = DigitalPaperNotificationBatchApplication.class)
public class NotificationBatchReaderTest {
	
	@Mock
	PaperDetailsDao paperDetailsDao;
	
	@Mock
	RestTemplate restTemplate;
	
	@InjectMocks
	Reader reader;
	
	@Test
	public void read_happy_flow() {
		try {
			
			when(paperDetailsDao.getAllPaperDetails()).thenReturn(MockData.getListOfPaperDetails());
			List<PaperDetails> read = reader.read();
			assertEquals(read.get(0).getCompanyId(), MockData.getListOfPaperDetails().get(0).getCompanyId());
			
		} catch (Exception e) {
			Assertions.fail();
		}
	}

}
