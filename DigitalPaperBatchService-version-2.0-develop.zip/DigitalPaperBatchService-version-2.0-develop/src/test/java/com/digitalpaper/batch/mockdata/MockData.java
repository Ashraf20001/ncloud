package com.digitalpaper.batch.mockdata;

import java.util.ArrayList;
import java.util.List;

import com.digitalpaper.transfer.object.entity.Customer;
import com.digitalpaper.transfer.object.entity.PaperDetails;

public class MockData {
	
	public static List<PaperDetails> getListOfPaperDetails(){
		List<PaperDetails> list = new ArrayList<>();
		PaperDetails details = new PaperDetails();
		details.setCompanyId(1);
		details.setIdentity("identity");
		details.setIsDeleted(false);
		details.setPaperId(1);
		details.setPaperPoolId(1);
		details.setPdDigitalPaperId("1");
		details.setPdEmailId("email.com");
		details.setCustomer(getCustomer());
		
		list.add(details);
		return list;
	}
	
	public static Customer getCustomer() {
		Customer customer = new Customer();
		customer.setCompanyId(1);
		customer.setCustomerId(1);
		return customer;
	}

}
