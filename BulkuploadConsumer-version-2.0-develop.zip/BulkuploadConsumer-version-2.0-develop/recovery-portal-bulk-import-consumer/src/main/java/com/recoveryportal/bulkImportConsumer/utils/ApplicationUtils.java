package com.recoveryportal.bulkImportConsumer.utils;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ApplicationUtils {
    public static boolean isValidateObject(Object obj) {
        if (obj == null) {
            return false;
        }

        if (obj instanceof List<?> && ((Collection<?>) obj).isEmpty()) {
            return false;
        }

        if (obj instanceof Map<?, ?> && ((Map) obj).isEmpty()) {
            return false;
        }

        if (obj instanceof Set<?>) {
            return !((Set) obj).isEmpty();
        }

        return true;
    }
}
