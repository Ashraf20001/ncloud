package com.recoveryportal.bulkImportConsumer.helper;

import org.springframework.web.multipart.MultipartFile;

public class ExcelHelper {
    public static String TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    public static String[] HEADERs = { "Id", "Title", "Description", "Published" };
    public static String SHEET = "reportloss";

    public static boolean hasExcelFormat(String file) {

        if (!TYPE.equals(file)) {
            return false;
        }

        return true;
    }
}
