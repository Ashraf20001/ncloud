package com.recoveryportal.bulkImportConsumer;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

/**
 * The Class RecoveryPortalBulkImportConsumerApplication.
 */
@SpringBootApplication
public class RecoveryPortalBulkImportConsumerApplication {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		SpringApplication.run(RecoveryPortalBulkImportConsumerApplication.class, args);
	}

	/**
	 * Register a Bean for rest template.
	 *
	 * @return the rest template
	 */
	@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}
	
	/**
	 * Model mapper.
	 *
	 * @return the model mapper
	 */
	@Bean
	public ModelMapper modelMapper(){
		return new ModelMapper();
	}
}
