package com.recoveryportal.bulkImportConsumer.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BulkImportFieldValidationDto {
    private String userId;
    private String insurerName;
    private Integer initialRowNumber;
    private BulkImportHistoryDto bulkImportHistoryDto;
    private List<Map<String,String>> mapList;
    private List<FieldDto> fieldList;
    private List<FieldDto> mandatoryFieldList;


}
