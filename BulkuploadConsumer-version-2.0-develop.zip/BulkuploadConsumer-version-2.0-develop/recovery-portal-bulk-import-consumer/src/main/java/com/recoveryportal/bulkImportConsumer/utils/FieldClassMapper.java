package com.recoveryportal.bulkImportConsumer.utils;

import com.recoveryportal.bulkImportConsumer.dto.DataTypeConstantsDto;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashMap;

@Component
public class FieldClassMapper {
	
	HashMap<String, Class<?>> classMap = new HashMap<>();
	
	
	
	@PostConstruct
	void constructClassMap() {
		classMap.put(DataTypeConstantsDto.STRING, String.class);
		classMap.put(DataTypeConstantsDto.TEXT, String.class);
		classMap.put(DataTypeConstantsDto.FILE, String.class);
		classMap.put(DataTypeConstantsDto.BOOLEAN, boolean.class);
		classMap.put(DataTypeConstantsDto.INTEGER, Integer.class);
		classMap.put(DataTypeConstantsDto.DOUBLE, Double.class);
		classMap.put(DataTypeConstantsDto.FDATE, Date.class);
		classMap.put(DataTypeConstantsDto.PDATE, Date.class);
		classMap.put(DataTypeConstantsDto.LOCAL_DATE_TIME, LocalDateTime.class);
		classMap.put(DataTypeConstantsDto.LONG, Long.class);
	}
	
	
	
	public Class<?> getClass(String className){
		return classMap.get(className);
	}
	
	

}
