package com.recoveryportal.bulkImportConsumer.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FieldDto {
    private String fieldId;
    private String fieldName;
    private String fieldType;
    private String aliasName;
    private boolean isMandatory;
    private Boolean isCoreData;
    private String defaultValues;
    private String entityName;
    private String columnName;
    private String value;
    private Integer minLength;
    private Integer maxLength;
    private String regex;
}
