package com.recoveryportal.bulkImportConsumer.constants;

/**
 * The Class PropertyConstants.
 */
public class PropertyConstants {
    
    /** The Constant GET_FILE_PATH_REPORTLOSS. */
    public static final String GET_FILE_PATH_REPORTLOSS = "bulk-upload-reportloss-file-path";

    /** The Constant GET_FILE_DOWNLOAD_URL. */
    public static final String GET_FILE_DOWNLOAD_URL = "file-download-url";
    
    /** The Constant PROCESS_LIMIT_VALUE. */
    public static final String PROCESS_LIMIT_VALUE = "process-limit-value";
}
