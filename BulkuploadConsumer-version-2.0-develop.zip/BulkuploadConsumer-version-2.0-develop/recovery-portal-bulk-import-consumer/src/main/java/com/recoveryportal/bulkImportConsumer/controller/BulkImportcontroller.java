package com.recoveryportal.bulkImportConsumer.controller;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.recoveryportal.bulkImportConsumer.dto.BulkImportHistoryDto;
import com.recoveryportal.bulkImportConsumer.dto.BulkImportTriggerConsumerDto;
import com.recoveryportal.bulkImportConsumer.exception.ApplicationException;
import com.recoveryportal.bulkImportConsumer.service.BulkImportConsumerService;

/**
 * The Class BulkImportcontroller.
 */
@RestController
public class BulkImportcontroller {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(BulkImportcontroller.class);
	
    /** The bulk import consumer service. */
    @Autowired
    private BulkImportConsumerService bulkImportConsumerService;
    
    /** The object mapper. */
    @Autowired
    private ObjectMapper objectMapper;
    
    /**
     * Update Bulk Upload status.
     *
     * @param bulkImportHistoryDto the bulk import history dto
     * @param pageId the page id
     * @param insurer the insurer
     * @param userId the user id
     * @throws ApplicationException the application exception
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws InvalidFormatException the invalid format exception
     */
    @PostMapping("/api/auth/process-upload/bulk-upload")
    public void updateBulkUploadStatus(@RequestBody BulkImportHistoryDto bulkImportHistoryDto,
                                       @RequestParam("page_id") String pageId,
                                       @RequestParam("insurer") String insurer,
                                       @RequestParam("user_id") String userId) throws ApplicationException, IOException, InvalidFormatException {
        bulkImportConsumerService.updateStatusOfBulkImportHistory(bulkImportHistoryDto,pageId,insurer,userId);
    }

    /**
     * Consumer method to process bulk upload messages received from Kafka.
     * 
     * This method acknowledges the Kafka message, parses the received bulk import message, 
     * and updates the status of the bulk import history.
     *
     * @param bulkImportTriggerMessage the bulk import trigger message
     * @param acknowledgment the acknowledgment
     * @throws ApplicationException the application exception
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws InvalidFormatException the invalid format exception
     */
    @KafkaListener(topics = "recoverez-bulk-import-consumer", groupId = "myGroup")
    public void updateBulkUpload(String bulkImportTriggerMessage, Acknowledgment acknowledgment) throws ApplicationException, IOException, InvalidFormatException {
    	
    	LOGGER.info("===> Drop of recoverez_bulk-import-consumer is received");
    	acknowledgment.acknowledge();   	
    	BulkImportTriggerConsumerDto bulkImportTriggerConsumerDto = objectMapper.readValue(bulkImportTriggerMessage, BulkImportTriggerConsumerDto.class);
        bulkImportConsumerService.updateStatusOfBulkImportHistory(
                bulkImportTriggerConsumerDto.getBulkImportHistoryDto(),bulkImportTriggerConsumerDto.getPageIdentity(),
                bulkImportTriggerConsumerDto.getInsurer(),bulkImportTriggerConsumerDto.getUserId().toString());
    }
}
