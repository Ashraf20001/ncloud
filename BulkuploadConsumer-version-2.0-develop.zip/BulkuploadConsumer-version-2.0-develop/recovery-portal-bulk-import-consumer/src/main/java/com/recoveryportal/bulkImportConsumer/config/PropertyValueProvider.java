package com.recoveryportal.bulkImportConsumer.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class PropertyValueProvider.
 */
@ConfigurationProperties(prefix = "rpbulk")
@Getter
@Setter
@Component
public class PropertyValueProvider {
	
	/** The file path. */
	private String filePath;
	
	/** The file download url. */
	private String fileDownloadUrl;
	
	/** The process limit value. */
	private String processLimitValue;
	
}
