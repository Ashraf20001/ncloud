package com.recoveryportal.bulkImportConsumer.constants;

/**
 * The Class TableConstants.
 */
public class TableConstants {
    
    /** The Constant STATUS_IN_PROGRESS. */
    public static final String STATUS_IN_PROGRESS = "IN PROGRESS";
    
    /** The Constant STATUS_COMPLETED. */
    public static final String STATUS_COMPLETED = "COMPLETED";

    /** The Constant UPDATE_IMPORT_HISTORY. */
    public static final String UPDATE_IMPORT_HISTORY = "/recovery/auth/report-loss/bulk-import/update-import-history";
    
    /** The Constant BULK_IMPORT_GET_FILE_PATH. */
    public static final String BULK_IMPORT_GET_FILE_PATH = "/recovery/auth/report-loss/bulk-import/get-file-path";
    
    /** The Constant GET_FIELD_LIST. */
    public static final String GET_FIELD_LIST = "/recovery/auth/reportloss/get-field-list";
    
    /** The Constant SAVE_SUCCESS_ERROR_DATA. */
    public static final String SAVE_SUCCESS_ERROR_DATA = "/recovery/auth/report-loss/bulk-import/save-success-error-data";
    
    /** The Constant ERMSG_PARSE_EXCEL. */
    //validation message
    public static final String ERMSG_PARSE_EXCEL = "fail to parse Excel file: ";
    
    /** The Constant ERROR_FAILED. */
    public static final String ERROR_FAILED = "FAILED";
    
    /** The Constant ERROR_NO_DATA. */
    public static final String ERROR_NO_DATA = "No Data";
    
    /** The Constant BULK_IMPORT_VALIDATE_FIELDS. */
    public static final String BULK_IMPORT_VALIDATE_FIELDS = "/recovery/auth/report-loss/bulk-import/validate-fields";
}
