package com.recoveryportal.bulkImportConsumer.service.Impl;

import com.recoveryportal.bulkImportConsumer.config.EnvironmentProperties;
import com.recoveryportal.bulkImportConsumer.constants.ErrorCodes;
import com.recoveryportal.bulkImportConsumer.controller.BulkImportcontroller;
import com.recoveryportal.bulkImportConsumer.dto.*;
import com.recoveryportal.bulkImportConsumer.exception.ApplicationException;
import com.recoveryportal.bulkImportConsumer.helper.ExcelHelper;
import com.recoveryportal.bulkImportConsumer.utils.ApplicationUtils;
import com.recoveryportal.bulkImportConsumer.utils.RestTemplateUtils;
import com.recoveryportal.bulkImportConsumer.service.BulkImportConsumerService;
import com.recoveryportal.bulkImportConsumer.constants.TableConstants;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.*;
import java.util.*;

@Service
public class BulkImportConsumerServiceImpl implements BulkImportConsumerService {
	@Autowired
	EnvironmentProperties environmentProperties;
	@Autowired
	RestTemplateUtils restTemplateUtils;
	@Autowired
	RestTemplate restTemplate;

	@Value("${base-url}")
	private String baseUrl;

	private static final Logger logger = LoggerFactory.getLogger(BulkImportcontroller.class);

	@Override
	public void updateStatusOfBulkImportHistory(BulkImportHistoryDto bulkImportHistoryDto, String pageId, String insurer,String userId) throws ApplicationException, IOException, InvalidFormatException {

		if (!ApplicationUtils.isValidateObject(bulkImportHistoryDto)){
			throw new ApplicationException(ErrorCodes.INVALID_BULK_IMPORT_HISTORY);
		}
		logger.info(bulkImportHistoryDto.getFileName().concat(" in progress"));
		//update initial history count
		bulkImportHistoryDto.setStatus(TableConstants.STATUS_IN_PROGRESS);
		updateImportHistory(bulkImportHistoryDto);
		try{
			//get file location
			Resource fileResource = getFileLocationByUploadId(bulkImportHistoryDto);
			insurer = insurer!=null?insurer.replace("%20"," "):null;
			processFileFromPath(fileResource, bulkImportHistoryDto, pageId,insurer,userId);
		} catch (Exception e){
			logger.error(e.getMessage());
			bulkImportHistoryDto.setStatus(TableConstants.ERROR_FAILED);
			updateImportHistory(bulkImportHistoryDto);
		}

	}

	public void updateImportHistory(BulkImportHistoryDto bulkImportHistoryDto){
		logger.info("Updating Import History Status");

		HttpEntity<BulkImportHistoryDto> entity = new HttpEntity<BulkImportHistoryDto>(bulkImportHistoryDto,restTemplateUtils.getPOSTHeaders());

		String url = baseUrl + TableConstants.UPDATE_IMPORT_HISTORY;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);

		restTemplate.exchange(
				builder.toUriString(), HttpMethod.POST, entity, BulkImportHistoryDto.class).getBody();
	}

	private Resource getFileLocationByUploadId(BulkImportHistoryDto bulkImportHistoryDto) {

		HttpEntity <String> entity2 = new HttpEntity<String>(restTemplateUtils.getGETHeaders());

		Map<String, Integer> params = new HashMap<>();
		params.put("upload_id", bulkImportHistoryDto.getUploadId());
		String url2 = baseUrl + TableConstants.BULK_IMPORT_GET_FILE_PATH;
		UriComponentsBuilder builder2 = UriComponentsBuilder.fromHttpUrl(url2);
		for (Map.Entry<String, Integer> entry : params.entrySet()) {
			builder2.queryParam(entry.getKey(), entry.getValue());
		}

		Resource x2 = restTemplate.exchange(
				builder2.toUriString(), HttpMethod.GET, entity2, Resource.class).getBody();
		logger.info("file downloaded");
		return x2;
	}

	private void processFileFromPath(Resource file, BulkImportHistoryDto bulkImportHistoryDto, String pageId, String insurer,String userId) throws ApplicationException, IOException, InvalidFormatException {
		if(!ApplicationUtils.isValidateObject(file)){
			throw new ApplicationException(ErrorCodes.INVALID_PATH);
		}

		logger.info("file downloaded successfully");
		BulkImportFieldList metaDataFieldsByPageId = getMetaDataFieldsByPageId(pageId);
		List<FieldDto> fieldList = metaDataFieldsByPageId.getListOfField();
		List<BulkImportMappingDto> bulkImportMapping = metaDataFieldsByPageId.getBulkImportMapping();
		// looping
		ConvertExcelIntoMap(fieldList,file,bulkImportHistoryDto,pageId,insurer,userId,bulkImportMapping);

	}

	private BulkImportFieldList getMetaDataFieldsByPageId(String pageId) {

		HttpEntity <String> entity3= new HttpEntity<String>(restTemplateUtils.getGETHeaders());

		Map<String, String> params = new HashMap<>();
		params.put("page_id",pageId);
		String url3 =  baseUrl + TableConstants.GET_FIELD_LIST;
		UriComponentsBuilder builder3 = UriComponentsBuilder.fromHttpUrl(url3);
		for (Map.Entry<String, String> entry : params.entrySet()) {
			builder3.queryParam(entry.getKey(), entry.getValue());
		}

		ResponseEntity<BulkImportFieldList> res = restTemplate.exchange(
				builder3.toUriString(), HttpMethod.GET, entity3, BulkImportFieldList.class);
		BulkImportFieldList x3 = res.getBody();
		return x3;
	}

	private void ConvertExcelIntoMap(List<FieldDto> fieldDtoList, Resource file,
			BulkImportHistoryDto bulkImportHistoryDto, String fileName, String insurer, String userId,List<BulkImportMappingDto> bulkImportMapping) {
		logger.info("Converting excel into map");
		Map<String, String> bulkImportMap = new HashMap<>();
		List<FieldDto> mandatoryFieldList = new ArrayList<>();
		for (BulkImportMappingDto bulkImportMappingDto : bulkImportMapping) {
			bulkImportMap.put(bulkImportMappingDto.getBulkImportAliasName(), bulkImportMappingDto.getBulkImportFieldName());
			if(bulkImportMappingDto.getIsMandatory()){
				Optional<FieldDto> field = fieldDtoList.stream().filter(x -> x.getFieldName().equals(bulkImportMappingDto.getBulkImportFieldName())).findFirst();
				field.ifPresent(mandatoryFieldList::add);
			}
		}
		try {
			logger.info("Reading Excel");

			InputStream fis = file.getInputStream();
			Workbook workbook = WorkbookFactory.create(fis);

			if(workbook==null){
				throw new ApplicationException(ErrorCodes.INVALID_PATH);
			}

			Sheet sheet = workbook.getSheet(ExcelHelper.SHEET);

			Integer lastRowNumber = sheet.getLastRowNum();
			Iterator<Row> rows = sheet.iterator();
			int rowNumber = 0;
			List<Map<String,String>> listOfMap = new ArrayList<>();


			Row row = sheet.getRow(0);

			int minColIx = row.getFirstCellNum();
			int maxColIx = row.getLastCellNum();

			int processLimit = 0;
			int initialRowOfEachProcess = 0;
			int successCount = 0;
			int failureCount = 0;
			int totalCount =0;
			processLimit=0;
			while ( rows.hasNext() && rowNumber <= (lastRowNumber+1)) {
				Map<String, String> map = new HashMap<String,String>();
				if (rowNumber == 0) {
					rowNumber++;
					continue;
				}
				Row row1 = sheet.getRow(rowNumber);
				
				if (row1==null || processLimit == environmentProperties.getProcessLimit()){
					BulkUploadSuccessErrorList bulkUploadSuccessErrorList
					= validateFieldValue(userId, bulkImportHistoryDto, listOfMap, fieldDtoList, initialRowOfEachProcess,
							insurer, mandatoryFieldList);
					initialRowOfEachProcess = rowNumber;

					////                    saveReportLoss();
					saveReportLossSuccessAndErrorData(bulkUploadSuccessErrorList,userId,bulkImportHistoryDto.getUploadId());

					//                    update count
					totalCount = totalCount+processLimit;
					successCount+=bulkUploadSuccessErrorList.getReportLossList().size();
					failureCount=totalCount - successCount;
					bulkImportHistoryDto.setSuccessCount(successCount);
					bulkImportHistoryDto.setFailureCount(failureCount);
					bulkImportHistoryDto.setTotalCount(totalCount);

					listOfMap.clear();
					if (row1==null) {
						if(totalCount == 0) {
							bulkImportHistoryDto.setStatus(TableConstants.ERROR_NO_DATA);
							logger.info(bulkImportHistoryDto.getFileName().concat(" ").concat(TableConstants.ERROR_NO_DATA));
						} else {
							bulkImportHistoryDto.setStatus(TableConstants.STATUS_COMPLETED);
							logger.info(bulkImportHistoryDto.getFileName().concat(" Status Completed"));
						}
						updateImportHistory(bulkImportHistoryDto);
						return;
					}else {
						updateImportHistory(bulkImportHistoryDto);
					}
					processLimit=0;
				}

				

				for(int colIx=minColIx; colIx<maxColIx; colIx++) {

					Cell cell = row.getCell(colIx);
					Cell cell1 = row1.getCell(colIx);
					if(cell1 != null) {
						cell.setCellType(CellType.STRING);
						cell1.setCellType(CellType.STRING);
						map.put(bulkImportMap.get(cell.getStringCellValue()),cell1.getStringCellValue());
					}
				}
				
				if(map.size() > 1) {
					listOfMap.add(map);
					processLimit++;	
				}
				rowNumber++;
			}

			workbook.close();
		} catch (Exception e) {
			throw new RuntimeException(TableConstants.ERMSG_PARSE_EXCEL + e.getMessage());
		}
	}

	private void saveReportLossSuccessAndErrorData(BulkUploadSuccessErrorList bulkUploadSuccessErrorList,String userId, Integer uploadId) {

		logger.info("Saving Success Error Record");
		HttpEntity<BulkUploadSuccessErrorList> entity = new HttpEntity<BulkUploadSuccessErrorList>(bulkUploadSuccessErrorList,restTemplateUtils.getPOSTHeaders());

		String url =  baseUrl + TableConstants.SAVE_SUCCESS_ERROR_DATA;

		Map<String, String> params = new HashMap<>();
		params.put("user_id",userId);
		params.put("upload_id",uploadId.toString());
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		for (Map.Entry<String, String> entry : params.entrySet()) {
			builder.queryParam(entry.getKey(), entry.getValue());
		}
		restTemplate.exchange(
				builder.toUriString(), HttpMethod.POST, entity, BulkImportHistoryDto.class).getBody();


	}

	BulkUploadSuccessErrorList validateFieldValue(String userId, BulkImportHistoryDto bulkImportHistoryDto, List<Map<String,String>> mapList,
			List<FieldDto> fieldList, Integer initialRowNumber,String insurerName, List<FieldDto> mandatoryFieldList) throws Exception {

		logger.info("Validating 100 fields");
		BulkImportFieldValidationDto validationDto = new BulkImportFieldValidationDto();
		validationDto.setUserId(userId);
		validationDto.setBulkImportHistoryDto(bulkImportHistoryDto);
		validationDto.setMapList(mapList);
		validationDto.setFieldList(fieldList);
		validationDto.setInitialRowNumber(initialRowNumber);
		validationDto.setInsurerName(insurerName);
		validationDto.setMandatoryFieldList(mandatoryFieldList);

		//rest call for field validation
		HttpEntity<BulkImportFieldValidationDto> entity5 = new HttpEntity<BulkImportFieldValidationDto>(validationDto,restTemplateUtils.getPOSTHeaders());

		String url5 =  baseUrl + TableConstants.BULK_IMPORT_VALIDATE_FIELDS;

		UriComponentsBuilder builder5 = UriComponentsBuilder.fromHttpUrl(url5);

		ResponseEntity<BulkUploadSuccessErrorList> response = restTemplate.exchange(
				builder5.toUriString(), HttpMethod.POST, entity5, BulkUploadSuccessErrorList.class);

		logger.info("Validation completed");
		return response.getBody();
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}
}
