package com.recoveryportal.bulkImportConsumer.core;


import java.util.HashMap;
import java.util.Map;

public class ApplicationResponse {

    /**
     * The Constant CONTENT.
     */
    private static final String CONTENT = "content";

    /**
     * The Constant EMPTY.
     */
    private static final String EMPTY = "";

    /**
     * The Constant STATUS.
     */
    private static final String STATUS = "status";

    /**
     * The Constant SUCCESS.
     */
    private static final String SUCCESS = "Success!";

    /**
     * The res.
     */
    private final Map<String, Object> res;

    public ApplicationResponse() {
        res = new HashMap<>();
        res.put(CONTENT, EMPTY);
        res.put(STATUS, SUCCESS);
    }

    /**
     * Gets the content.
     *
     * @param <T> the generic type
     * @return the content
     */
    public <T> T getContent() {
        return (T) res.get(CONTENT);
    }

    /**
     * Sets the content.
     *
     * @param <T> the generic type
     * @param obj the new content
     */
    public <T> void setContent(T obj) {
        res.put(CONTENT, obj);
    }

    /**
     * Sets the status.
     *
     * @param <T> the generic type
     * @param obj the new status
     */
    //gg
    public <T> void setStatus(T obj) {
        res.put(STATUS, obj);
    }
}
