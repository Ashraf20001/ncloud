package com.recoveryportal.bulkImportConsumer.config;

import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * The Class EnvironmentProperties.
 */
@Configuration
@RequiredArgsConstructor
public class EnvironmentProperties {

	/** The property value provider. */
	private final PropertyValueProvider propertyValueProvider;

    /**
     * Gets the file path of report loss.
     *
     * @return the file path of report loss
     */
    public String getFilePathOfReportLoss() {
        return propertyValueProvider.getFilePath();
    }
    
    /**
     * Gets the file download url.
     *
     * @return the file download url
     */
    public String getFileDownloadUrl() {
        return propertyValueProvider.getFileDownloadUrl();
    }
    
    /**
     * Gets the process limit.
     *
     * @return the process limit
     */
    public Integer getProcessLimit() {
    	String limit = propertyValueProvider.getProcessLimitValue();
    	return limit != null && limit.isBlank() ? Integer.parseInt(limit) : 100;
    }
}
