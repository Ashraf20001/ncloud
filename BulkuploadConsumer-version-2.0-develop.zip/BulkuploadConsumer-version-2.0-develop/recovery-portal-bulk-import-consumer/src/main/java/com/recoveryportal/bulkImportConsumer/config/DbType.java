/*
 * @author codeboard
 */
package com.recoveryportal.bulkImportConsumer.config;

/**
 * The Enum DbType.
 */
public enum DbType {
	/**
	 * The master & TEST .
	 */
	MASTER, TEST
}