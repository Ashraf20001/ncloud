package com.recoveryportal.bulkImportConsumer.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BulkImportTriggerConsumerDto {
    private BulkImportHistoryDto bulkImportHistoryDto;
    private String pageIdentity;
    private String insurer;
    private Integer userId;
}
