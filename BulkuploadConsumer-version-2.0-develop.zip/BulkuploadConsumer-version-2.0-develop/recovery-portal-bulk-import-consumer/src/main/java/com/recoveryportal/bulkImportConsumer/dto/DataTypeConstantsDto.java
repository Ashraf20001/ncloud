package com.recoveryportal.bulkImportConsumer.dto;

public class DataTypeConstantsDto {

    public static final String STRING = "String";
    public static final String TEXT = "text";

    public static final String INTEGER = "Integer";
    public static final String BOOLEAN = "Boolean";
    public static final String LONG = "Long";
    public static final String DOUBLE = "Double";
    public static final String PDATE = "pDate";
    public static final String FDATE = "fDate";
    public static final String DROPDOWN = "Dropdown";
    public static final String DOWNLOAD = "download";
    public static final String LOCAL_DATE_TIME = "LocalDateTime";
    public static final String CHECKBOX = "checkbox";
    public static final String FILE = "file";
    public static final String RADIO_BUTTON = "RadioButton";
    public static final String MULTI_SELECT = "MultiSelect";
    public static final String TOGGLE = "toggle";

}
