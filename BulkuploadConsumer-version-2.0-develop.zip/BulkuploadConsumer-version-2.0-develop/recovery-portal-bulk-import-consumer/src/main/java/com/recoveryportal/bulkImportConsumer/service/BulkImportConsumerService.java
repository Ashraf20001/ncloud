package com.recoveryportal.bulkImportConsumer.service;

import com.recoveryportal.bulkImportConsumer.dto.BulkImportHistoryDto;
import com.recoveryportal.bulkImportConsumer.exception.ApplicationException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.ResponseEntity;

import java.io.IOException;

public interface BulkImportConsumerService {
    void updateStatusOfBulkImportHistory(BulkImportHistoryDto bulkImportHistoryDto, String pageId,String insurer,String userId) throws ApplicationException, IOException, InvalidFormatException;
}
