package com.recoveryportal.bulkImportConsumer.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BulkImportHistoryDto {
    private Integer uploadId;
    private Integer successCount=0;
    private Integer failureCount=0;
    private Integer totalCount=0;
    private String status;
    private Integer pageId;
    private String fileName;
    private String createdBy;
    private String createdDate;
    private String identity;
}
