package com.recoveryportal.bulkImportConsumer.constants;

/**
 * The Class ApplicationConstants.
 */
public class ApplicationConstants {
    
    /** The Constant REPORTLOSS. */
    public static final String REPORTLOSS = "RerportLoss";
    
    /** The Constant ZERO. */
    public static final int ZERO = 0;
}
