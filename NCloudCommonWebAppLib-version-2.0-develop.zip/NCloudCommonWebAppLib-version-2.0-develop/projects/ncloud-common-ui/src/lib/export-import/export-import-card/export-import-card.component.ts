import { Component, OnInit } from '@angular/core';

import { ToastrService } from 'ngx-toastr';

import { UserListService } from '../../service/user-list.service';
import { ErrorHandlerDirective } from '../../directive/errorHandler.directive';
import { HttpParams } from '@angular/common/http';

@Component({
  selector: 'app-export-import-card',
  templateUrl: './export-import-card.component.html',
  styleUrls: ['./export-import-card.component.scss']
})
export class ExportImportCardComponent implements OnInit {
  platformId: any;
  file: File;
  errorMessage: any;
  spinner: boolean=false;
  constructor(private toaster: ToastrService, private dashboardService: UserListService, private errorHandler: ErrorHandlerDirective) { }
  RelationMappingTable: RelationMappingTable[] = [];
  finalRelationMappingTable: RelationMappingTable[] = [];
  importErrorTable: boolean = false;
  isOverride: boolean = false;
  ngOnInit(): void {
    debugger;
    const platformDetails = JSON.parse(sessionStorage.getItem("platformDetails") ?? "{}");
    this.platformId = platformDetails.platformId;
    this.getExportList()
  }
  getExportList() {
    let params = new HttpParams()
    .set("platformId", this.platformId);
    this.dashboardService.getExport(params).subscribe((data) => {
      const result = data['content'];
      if (result) {
        this.RelationMappingTable = result.map((mainTable) => ({
          ...mainTable,
          relationMappingTables: mainTable?.relationMappingTables?.length ? mainTable.relationMappingTables : null
        }));
      }
    }, (error: Response) => {
      this.errorHandler.getMessage(error);

    })
  }



  // toggleParentSelection(parentIndex: number) {
  //   // Toggle selection
  //   if (this.RelationMappingTable[parentIndex]?.relationMappingTables) {
  //     const selectedChild = this.RelationMappingTable[parentIndex]
  //     const isSelected = !selectedChild.isSelected; // Toggle selection
  //     this.RelationMappingTable[parentIndex]?.relationMappingTables?.forEach((child) => {
  //       this.RelationMappingTable?.forEach((mainParent) => {
  //         if (mainParent?.relationMappingTables?.some(rt => rt.tableName === child.tableName) || mainParent.tableName == child.tableName) {
  //           mainParent.isSelected = isSelected
  //           mainParent?.relationMappingTables?.forEach((mainchild) => {
  //             mainchild.isSelected = isSelected;
  //           })
  //         }
  //       })
  //     })
  //   } else {
  //     const selectedChild = this.RelationMappingTable[parentIndex]
  //     const isSelected = !selectedChild.isSelected;
  //     selectedChild.isSelected = isSelected;

  //     let child = this.RelationMappingTable[parentIndex]

  //     this.RelationMappingTable?.forEach((mainParent) => {
  //       if (mainParent?.relationMappingTables?.some(rt => rt.tableName === child.tableName || mainParent.tableName == child.tableName)) {
  //         mainParent.isSelected = isSelected
  //         mainParent?.relationMappingTables?.forEach((mainchild) => {
  //           mainchild.isSelected = isSelected;
  //         })
  //       }
  //     })

  //   }
  // }

  // toggleChildSelection(parentIndex: number, childIndex: number) {
  //   const selectedChild = this.RelationMappingTable[parentIndex]
  //   const isSelected = !selectedChild.isSelected; // Toggle selection
  //   this.RelationMappingTable[parentIndex]?.relationMappingTables?.forEach((child) => {
  //     this.RelationMappingTable?.forEach((mainParent) => {
  //       if (mainParent?.relationMappingTables?.some(rt => rt.tableName === child.tableName) || mainParent.tableName == child.tableName) {
  //         mainParent.isSelected = isSelected
  //         mainParent?.relationMappingTables?.forEach((mainchild) => {
  //           mainchild.isSelected = isSelected;
  //         })
  //       }
  //     })
  //   })

  // }
  toggleParentSelection(parentIndex: number) {
    // Toggle selection
    const selectedTable = this.RelationMappingTable[parentIndex];
    const isSelected = !selectedTable.isSelected;
   

    let queue = new Set<string>(); // Use Set to avoid duplicates
    queue.add(selectedTable.tableName); // Initialize queue with selected table

   
    const processTables = (tableName: string) => {
        this.RelationMappingTable.forEach((parent) => {
            if (parent.tableName === tableName || parent.relationMappingTables?.some(child => queue.has(child.tableName))) {
                if (!queue.has(parent.tableName)) {
                    queue.add(parent.tableName);
                    processTables(parent.tableName); // Recursively check parent
                }

                parent.relationMappingTables?.forEach((child) => {
                    if (!queue.has(child.tableName)) {
                        queue.add(child.tableName);
                        processTables(child.tableName); // Recursively check child
                    }
                });
            }
        });
    };

    processTables(selectedTable.tableName); // Start recursion

    console.log([...queue]); // Output unique parent-child table names
    [...queue].forEach((tableName) => {
      this.RelationMappingTable.forEach((parent) => {
          if (parent.tableName === tableName || parent?.relationMappingTables?.some(rt => rt.tableName ===tableName)) {
              parent.isSelected = isSelected; // Select parent

              parent?.relationMappingTables?.forEach((child) => {
                  child.isSelected = isSelected; // Select child
              });
          }
      });
  });
}




  toggleChildSelection(parentIndex: number) {
  this.toggleParentSelection(parentIndex)
   

  }




  toggleExpand(parentIndex: number) {
    this.RelationMappingTable[parentIndex].isExpanded = !this.RelationMappingTable[parentIndex].isExpanded;
  }

  AllTables(data) {
    if (data) {
      this.RelationMappingTable?.forEach(parent => {
        parent.isSelected = true;
        parent.relationMappingTables?.forEach(child => {
          child.isSelected = true;
        });
      });
    } else {
      this.RelationMappingTable?.forEach(parent => {
        parent.isSelected = false;
        parent.relationMappingTables?.forEach(child => {
          child.isSelected = false;
        });
      });
    }
  }
  export() {
    debugger;

    this.finalRelationMappingTable = this.RelationMappingTable.filter(table => table.isSelected);

    // if(selectedTableNames.length==0)
    // {
    //   this.toaster.error('Please Select the Table');
    //    return
    // }
if(this.finalRelationMappingTable?.length ===0)
{
  this.toaster.error("Please Select the Fields")
  return
}
    let params = new HttpParams()
      .set("platformId", this.platformId)


    this.dashboardService.download(params, this.finalRelationMappingTable).subscribe((res: any) => {

      // Generate the current timestamp in the local time format YYYYMMDD_HHMMSS
      const now = new Date();

      const year = now.getFullYear();
      const month = ('0' + (now.getMonth() + 1)).slice(-2); // Months are 0-based, so we add 1
      const day = ('0' + now.getDate()).slice(-2);
      const hours = ('0' + now.getHours()).slice(-2);
      const minutes = ('0' + now.getMinutes()).slice(-2);
      const seconds = ('0' + now.getSeconds()).slice(-2);

      //  Format the timestamp as _YYYY_MM_DD_HH_MM_SS
      const timestamp = `_${year}_${month}_${day}_${hours}_${minutes}_${seconds}.json`;
      const jsonString = JSON.stringify(res, null, 2);
      const blob = new Blob([jsonString], { type: 'application/json' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `Export${timestamp}`;;
      link.click();
      URL.revokeObjectURL(link.href);
      this.toaster.success("Master Data Export Sucessfully.")
    }, (error: Response) => {
      this.errorHandler.getMessage(error);

    });
  }
  fileName: string = '';

  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {

      this.file= input.files[0]

      // Check if the file is a JSON file
      if (this.file.type === 'application/json' || this.file.name.endsWith('.json')) {
        this.fileName = this.file.name; // Display selected file name

      

      } else {
        this.toaster.error('Only JSON files are allowed!');
        this.fileName = ''; // Clear the file name if invalid
        input.value = ''; // Reset file input
      }
      input.value = '';
    }
  }
  importData()
  {
   
    const formdata: FormData = new FormData();
    if (this.file) {
      formdata.append("file", this.file);
    }
    else{
      this.toaster.error("Please Import the File")
      return 
    }

    this.spinner=true;
    this.importErrorTable=false;
    let params = new HttpParams()
      .set("platformId", this.platformId).set("isOverride", this.isOverride)
    this.dashboardService.import(params, formdata).subscribe((res: any) => { 
     let result=res
    //  console.log(res)
    //   if(result)
    //   {
    this.spinner=false;
        this.importErrorTable=true;
        this.errorMessage="Master Data Import Sucessfully.";
        this.toaster.success("Master Data Import Sucessfully.")
      // }
    }, (error: Response) => {
      this.spinner=false;
      this.errorHandler.getMessage(error);

    })
  }
  closeFile()
  {
    this.file=null;
    this.fileName =""
    this.importErrorTable=false;
  }
}

export class RelationMappingTable {
  tableName: string;
  disPlayName: string;
  platFormId: number;
  isSelected: boolean = false;
  isExpanded: boolean = false;
  relationMappingTables: RelationMappingTable[];
}
