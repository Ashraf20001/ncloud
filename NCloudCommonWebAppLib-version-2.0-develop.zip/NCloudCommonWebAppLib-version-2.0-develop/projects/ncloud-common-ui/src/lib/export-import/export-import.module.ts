import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ExportImportRoutingModule } from './export-import-routing.module';
import { ExportImportComponent } from './export-import.component';
import { ExportImportCardComponent } from './export-import-card/export-import-card.component';
import { FormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { DemoMaterialModule } from '../common-components/angularMaterialModules/material-module';


@NgModule({
  declarations: [
    ExportImportComponent,
    ExportImportCardComponent
  ],
  imports: [
    CommonModule,DemoMaterialModule,
    ExportImportRoutingModule,FormsModule,TranslateModule
  ]
})

export class ExportImportModule{
  public static forRoot(environment: any): ModuleWithProviders<ExportImportModule> {
    return {
      ngModule: ExportImportModule,
      providers: [
        {
          provide: 'env', // you can also use InjectionToken
          useValue: environment
        }
      ]
    };
  }
}

