import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ExportImportComponent } from './export-import.component';
import { ExportImportCardComponent } from './export-import-card/export-import-card.component';

const routes: Routes = [{ path: '', component: ExportImportComponent,
   children : [
        {
          path: 'export-import-card',  component: ExportImportCardComponent
        },
        
        {
          path: '',  redirectTo: 'export-import-card', pathMatch: "full"
        },
      ]
 }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ExportImportRoutingModule { }
