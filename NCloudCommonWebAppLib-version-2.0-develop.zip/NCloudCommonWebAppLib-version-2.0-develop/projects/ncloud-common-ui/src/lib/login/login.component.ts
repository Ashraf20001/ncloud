/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component } from '@angular/core';
import { FormControl, ValidationErrors } from '@angular/forms';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

}

export function noSpaceAllowed(control:FormControl): ValidationErrors | null {
  if (control.value!= null && control.value.indexOf(' ')!= -1) {
    return { noSpaceAllowed: true };
  }
  return null;
}
