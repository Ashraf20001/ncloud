import { OnInit } from '@angular/core';
/* eslint-disable no-useless-escape */
/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {  ToastrService } from 'ngx-toastr';
import { Component } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../service/auth.service';
import { noSpaceAllowed } from '../login.component';
import Validation from '../../service/validation';
import { ResetPasswordRequest } from '../../dto/reset-password-request-dto';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit{

  passwordRegex = /^(?=[^A-Z]*[A-Z])(?=[^a-z]*[a-z])(?=\D*\d)[A-Za-z\d!$%@#£€*?&]{8,20}$/;

  constructor(private fb: FormBuilder,private toaster:ToastrService,
    private router:Router,private route: ActivatedRoute,private service:AuthService, private translate:TranslateService){}

  submitted = false;
  ResetPassword!: FormGroup;

  userIdentity = localStorage.getItem('identity');
  userName = sessionStorage.getItem('username');
  showPassword=true;
  showPassword2=true;

  ngOnInit(): void {
    this.ResetPassword = this.fb.group({
      identity: new FormControl(this.userIdentity),
      newPassword: new FormControl("", [Validators.required, noSpaceAllowed, Validators.pattern(this.passwordRegex)]),
      confirmPassword: new FormControl("", [Validators.required]),
    },
    {
      validators: [Validation.match('newPassword', 'confirmPassword')]

    })
  }

  get f(): { [key: string]: AbstractControl } {
    return this.ResetPassword.controls;
  }

  resetPassword(): void {
    this.submitted = true;
    if (this.ResetPassword.invalid) {
      return;
    }
    const resetPasswordRequest: ResetPasswordRequest = {
      identity: this.userIdentity ?? '',
      newPassword: this.ResetPassword.value.newPassword ?? '',
      confirmPassword: this.ResetPassword.value.confirmPassword ?? ''
    };
    if(this.ResetPassword.valid){
      this.service.resetFirstTimePassword(resetPasswordRequest).subscribe(
        (response) => {
          if (response) {
            this.toaster.success(this.translate.instant('Toaster_success.reset_password'));
            setTimeout(() => {
              this.router.navigate(['']);
            }, 500);
          }
        }
      );
    }
  }

  togglePasswordVisibility(): void {
    this.showPassword = !this.showPassword;
  }

  togglePasswordVisibility2(): void {
    this.showPassword2 = !this.showPassword2;
  }

  goToLogin(): void {
    this.router.navigateByUrl('')
  }

}
