import { ActivatedRoute, Router } from '@angular/router';
/* eslint-disable @typescript-eslint/no-empty-function */
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from '../../service/auth.service';
import { CaptchaService } from '../../service/captcha.service';
import { ToasterMessage } from '../../enum/common-enum';
import { VerifyCaptchaDetailsDto } from '../../dto/captcha-dto';
import { TranslateService } from '@ngx-translate/core';
// import * as CryptoJS from 'crypto-js';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {

  submitted = false;

  // emailRegex =  /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+[@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)]*$/;

  emailRegex  = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+[@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.(?:[a-zA-Z0-9]{2,})+]*$/;

  emailDto = new  EmailDto();

  encodedMailId!: string;

  show:boolean=true;
  captchaImage!:string;
  captchaValue:string="";
  fc_captchaCode:string="";
  showCaptcha:boolean=false;
  inButtonDissable:boolean = true;
  captchaCode: string ="";
  res!: string; 
  ForgotPassword!: FormGroup;

  constructor(private fb: FormBuilder,private toaster:ToastrService,
    private router:Router,private route: ActivatedRoute,private service:AuthService,private captchaService:CaptchaService
    ,private translate:TranslateService){}

  ngOnInit(): void {
    this.ForgotPassword = this.fb.group({
      emailId: new FormControl("", [Validators.required,Validators.pattern(this.emailRegex)]),
      captcha: new FormGroup({
        fc_captchaCode: new FormControl("")
      })
    });
  }

  proceedForgetpwd(): void {
    this.submitted = true;
    this.encodedMailId = btoa(this.ForgotPassword.value.emailId)
    console.log(this.encodedMailId);
    const emailDto: EmailDto = {
      emailId: this.encodedMailId
    };
    // this.emailDto.emailId = this.encodedMailId;
    if (this.ForgotPassword.invalid) {
      return;
    }
    const emailIdString: string = emailDto.emailId; 
    const platformDetails = JSON.parse(sessionStorage.getItem("platformDetails") ?? "{}");
    this.service.sendMailToResetPassword(emailIdString,platformDetails.platformName).subscribe(
      (response: any) => {
        this.res = response['content'];
        this.toaster.success(this.translate.instant('Toaster_success.forget_email'));
        setTimeout(() => {
          this.router.navigate(['']);
        }, 500);
      }, (error: Response) => {
        if (ToasterMessage.tooManyAttempts == this.toaster.previousToastMessage) {
          console.log(this.toaster.previousToastMessage);
          this.showCaptcha = true;
          this.getCaptachaData();
        }
      }
    );
  }

  enableButton(){
  this.inButtonDissable = false; 
 }

    
  forgotPassword(): void {
    this.inButtonDissable = true;
    if(this.showCaptcha) {
      this.validateCaptachaData();
    } else {  
      this.proceedForgetpwd();
    }
  }

  goToLogin(): void {
    this.router.navigateByUrl('')
  }

  getCaptachaData(): void {
    this.captchaService.generateCaptcha().subscribe((response: any) => {
      const data = response['content'];
      this.captchaValue=data.captchaValue;
      this.captchaCode=data.compareCaptchaDataValue;
      this.captchaImage="data:image/png;base64,"+data.captcha;
    });
  }

  validateCaptachaData(): void {
    const data: VerifyCaptchaDetailsDto = {
      captchaValue: this.ForgotPassword.value.captcha.fc_captchaCode,
      compareCaptchaDataValue: this.captchaCode,
      clear: false
    };   
    this.captchaService.validateCaptcha(data).subscribe((response: any)=>{
      const data = response;
      this.show=data.success;
      console.log(data);
      console.log(this.show);
      if(!this.show){
        this.toaster.error(this.translate.instant('Toaster_error.captcha_error'));
      }else{
        this.showCaptcha=false;
        this.ForgotPassword.get("captcha")?.get("fc_captchaCode")?.setValue("")
        // this.login()
      }   
    });
  }

}

export class EmailDto{
  emailId: string;
}
