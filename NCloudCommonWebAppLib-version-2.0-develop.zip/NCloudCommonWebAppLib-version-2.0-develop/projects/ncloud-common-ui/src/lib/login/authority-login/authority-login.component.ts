/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-empty-function */
import { Component, ElementRef, Inject, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NavigationEnd, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { AuthService } from '../../service/auth.service';
import { AppService } from '../../service/app.service';
import { CaptchaService } from '../../service/captcha.service';
import { ToasterMessage } from '../../enum/common-enum';
import { commonConst } from '../../const/common.const';
import { VerifyCaptchaDetailsDto } from '../../dto/captcha-dto';
// import { ErrorHandlerDirective } from '../../directive/errorHandler.directive';
import { noSpaceAllowed } from '../login.component';
import { PlatformDetailsDto } from '../../dto/platform-details-dto';
import { map } from 'rxjs';

@Component({
  selector: 'app-authority-login',
  templateUrl: './authority-login.component.html',
  styleUrls: ['./authority-login.component.scss']
})

export class AuthorityLoginComponent implements OnInit {
  responsedata: any;
  captchaCode = '';
  captchaValue = '';
  fc_captchaCode = '';
  name = 'sads';
  show = true;
  servicenotended:boolean=false;
  captchaImage!: string;
  showCaptcha = false;
  showPassword=true;

  platformDetails!: PlatformDetailsDto[];
  field!: PlatformDetailsDto;

  imageList = [
    {
      aliasName:"Recover EZ",
      image:"assets/portal1.svg",
      title:"Recovery EZ"
    },
    {
      aliasName:"Digital Certificate",
      image:"assets/icons/authority_details.svg",
      title:"Digital Certificate"
    },
    {
      aliasName:"Data Lake",
      image:"assets/portal2.svg",
      title:"Data Lake"
    }
  ];
  userRoleStatus: any;
  platformlogo: any;
  menuname: string;
  currentUrl = '';
  @ViewChild('lastDiv', { static: false }) lastDiv: ElementRef;
  routerURL: any;
  value: number;
  constructor(private service:AuthService, public router:Router, public translate: TranslateService ,private tosterservice:ToastrService,
    private appService:AppService, private captchaService:CaptchaService, @Inject('env') private environment: any){
    // if(service.isSessionExpired()) {
    // }
    sessionStorage.removeItem('userTypeId');
    sessionStorage.removeItem('associationId');
    sessionStorage.removeItem('userIdentity');
    sessionStorage.removeItem('username');
    sessionStorage.removeItem('token');
    sessionStorage.removeItem('platformDetails');
    sessionStorage.removeItem('menuname');
    sessionStorage.removeItem('userTypeId');
    sessionStorage.removeItem('role');
    sessionStorage.removeItem('userRoleStatus');
    localStorage.removeItem('identity');


    translate.addLangs(['English','French']);
    translate.setDefaultLang('English');
    this.getCurrentUrl();
    // document.documentElement.style.setProperty('--wbCol','red');
  }
  ngOnInit(): void {
    // this.getCaptachaData();
    
      this.service.getPlatformDetails().subscribe((data)=>{
      this.platformDetails=data;

      if(this.currentUrl && this.platformDetails){
        const currentPlatform = this.platformDetails.find((value:PlatformDetailsDto) => {
      
          
      
          return this.currentUrl.includes(value.platformUrl);
        });
      
        if(currentPlatform) {
          this.passPlatformDetails(currentPlatform);
        }
      }
    })
   this.getPlatform()
  }

  public getCurrentUrl() {
    this.currentUrl = window.location.href;
    this.router.events.pipe(map((event: any) => {
      if (event instanceof NavigationEnd) {
        this.currentUrl = event.url
      }
    }));
  }

  title = 'AUTHORITY LOGIN'

  Login = new FormGroup({
    username: new FormControl('', [Validators.required, noSpaceAllowed]),

    password: new FormControl('', [Validators.required, noSpaceAllowed]),
    captcha: new FormGroup({
     fc_captchaCode: new FormControl("")
    })
  });

  getUrl(title:string): string {
    let image = '';
    const data = this.imageList.find((element)=> element.aliasName===title);
    image = data?.image ?? '';
    return image;
  }

  ProceedLogin(): void {
    if(!this.field) {
    this.scrollToLastDiv();
    }
    this.servicenotended=true;
    if(this.showCaptcha) {
      this.validateCaptachaData();
    } else {
      this.login();
    }
  }
  scrollToLastDiv() {
    if (this.lastDiv && this.lastDiv.nativeElement) {
      this.lastDiv.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'end', inline: 'nearest' });
    }
  }
  
  
 login(): void {
    if(this.Login.valid&&this.show) {
      const username = this.Login.value.username ?? '';
      const password = this.Login.value.password ?? '';
      this.service.ProceedLogin(username,password, true).subscribe((result) => {
        if (result) {
          this.responsedata = result;
          this.service.loginResponse = result;
          sessionStorage.setItem('token',this.responsedata.accessToken);
          localStorage.setItem('identity',this.responsedata.identity);
          sessionStorage.setItem('username',this.responsedata.username);
          sessionStorage.setItem('userIdentity',this.responsedata.identity);
          sessionStorage.setItem('associationId',this.responsedata.associationId);
          sessionStorage.setItem('userTypeId',this.responsedata.userTypeId.userTypeId);

          this.menuRoleMapping();
            
        }
      },(error:Response)=>{
        // this.errorHandler.getMessage(error);
      
        if(ToasterMessage.tooManyAttempts==this.tosterservice.previousToastMessage){
        
          this.showCaptcha=true;
          this.getCaptachaData();
        }
        this.servicenotended=false;
        // console.log(this.errorHandler.getErrorCode(error) ,"asdad");
        // this.getCaptachaData();
      });
    }
  }

  dataLakeSpecific() {
    this.service.getUserRolePrivillege().subscribe((data: any) => {
      this.userRoleStatus = data.content;
      sessionStorage.setItem('userRoleStatus', this.userRoleStatus);
    
      if (this.responsedata.userTypeId != null && this.responsedata.userTypeId.userTypeId === 1) {
        sessionStorage.setItem('role', 'TRUE');
      }
      if(this.responsedata.associationId === null){
        this.menuname = "Settings"
        sessionStorage.setItem('menuname', this.menuname);
        sessionStorage.setItem('associationId',"1")
      }
      this.service.autoLogout();
      if (this.responsedata.firstTimeLogin == true) {
        this.router.navigate(['login/reset-password']);
      } else if (this.responsedata.userTypeId.userTypeId) {
        this.menuRoleMethod();
      } else {
        this.router.navigate(['']);
        this.tosterservice.error(this.translate.instant('Toaster_error.invalid_user'));
        this.servicenotended=false;
      }
    });

  }


  menuRoleMethod() {
    if (this.responsedata.userTypeId.userTypeId === 1) {
      this.appService.getMenuDetails().subscribe((data: any) => {
        this.routerURL = data.menuDetails[0].routeUrl;
        this.router.navigate([this.routerURL]);

        if (this.responsedata['platformDetailsDto']['platformId']==3) {
        this.service.getUserRolePrivillege().subscribe((data: any) => {
          this.userRoleStatus = data.content;
          console.log("user role status for data lake ::-------------->", this.userRoleStatus)
          sessionStorage.setItem('userRoleStatus', this.userRoleStatus);

              if(this.responsedata.associationId === null){
                    this.menuname = "Settings"
                    sessionStorage.setItem('menuname', this.menuname);
                  sessionStorage.setItem('associationId',"1")
              }
            });
          }

        this.tosterservice.success(
          this.translate.instant('Toaster_success.login')
        );
      });

    }
    else {
      this.getMenuRoleData();
    }
  }

  menuRoleMapping(){
    if (this.responsedata.userTypeId != null && this.responsedata.userTypeId.userTypeId === 1) {
      sessionStorage.setItem('role', 'TRUE');
    }
    this.service.autoLogout();
    if (this.responsedata.firstTimeLogin == true) {
      this.router.navigate(['login/reset-password']);
    }else if(this.responsedata.userTypeId.userTypeId) {
      this.menuRoleMethod();
    }
    else{
      this.router.navigate(['']);
      this.tosterservice.error(this.translate.instant('Toaster_error.invalid_user'));
    }
  }

  getMenuRoleData(): void {
    this.appService.getMenubyRole().subscribe((response: any) => {
      if (response) {

        let menuName = '';
        if (response['content'] && response['content'].length !== 0) {
          menuName = response['content'][0].menuName
        }
        this.tosterservice.success(
          this.translate.instant('Toaster_success.login'),
          '',
          {timeOut:1600},
        );
        this.router.navigate([this.getUrlToNavigate(menuName)]);
        //after login it will redirect to given url
        // this.tosterservice.success( 'Login successfully');
        setTimeout(() => {
       
        }, 500);
      }
    });
  }

  getUrlToNavigate(menuName:string): string {
    switch (menuName) {
      case commonConst.MENU_CONSTANTS.MENUNAME.DASHBOARD.NAME:
        return commonConst.MENU_CONSTANTS.MENUNAME.DASHBOARD.URL;

      case commonConst.MENU_CONSTANTS.MENUNAME.PAGECONFIGURATOR.NAME:
        return commonConst.MENU_CONSTANTS.MENUNAME.PAGECONFIGURATOR.URL;

      case commonConst.MENU_CONSTANTS.MENUNAME.RECEIVABLE.NAME:
        return commonConst.MENU_CONSTANTS.MENUNAME.RECEIVABLE.URL;

      case commonConst.MENU_CONSTANTS.MENUNAME.PAYABLE.NAME:
        return commonConst.MENU_CONSTANTS.MENUNAME.PAYABLE.URL;

      case commonConst.MENU_CONSTANTS.MENUNAME.ENTITYMANAGEMENT.NAME:
        return commonConst.MENU_CONSTANTS.MENUNAME.ENTITYMANAGEMENT.URL;

      case commonConst.MENU_CONSTANTS.MENUNAME.REPORTS.NAME:
        return commonConst.MENU_CONSTANTS.MENUNAME.REPORTS.URL;

      case commonConst.MENU_CONSTANTS.MENUNAME.USERMANAGEMENT.NAME:
        return commonConst.MENU_CONSTANTS.MENUNAME.USERMANAGEMENT.URL;

      case commonConst.MENU_CONSTANTS.MENUNAME.AUTHORITYPAPERDETAILS.NAME:
        return commonConst.MENU_CONSTANTS.MENUNAME.AUTHORITYPAPERDETAILS.URL;
      default:
        return 'page-not-found';
    }
  }

  openForgotPassword(): void {
    this.router.navigateByUrl('login/forgot-password');
  }

  giveInsurence(): void {
    // this.router.navigate(['..', 'insurance-company']).then(() => console.log("success"));
    this.router.navigateByUrl('login/insurance-company');
  }

  togglePasswordVisibility(): void {
    this.showPassword = !this.showPassword;
  }

  getCaptachaData(): void {
    this.captchaService.generateCaptcha().subscribe((response: any) => {
      const data = response['content'];
      this.captchaValue=data.captchaValue;
      this.captchaCode=data.compareCaptchaDataValue;
      this.captchaImage="data:image/png;base64,"+data.captcha;
    });
  }

  validateCaptachaData(): void {
    let data: VerifyCaptchaDetailsDto = {
      clear: false,
      captchaValue: this.Login.value.captcha?.fc_captchaCode ?? '',
      compareCaptchaDataValue: this.captchaCode
    };
    this.captchaService.validateCaptcha(data).subscribe((response: any) => {
      const data = response;
      this.show=data.success;
    
      if(!this.show) {
        this.tosterservice.error(this.translate.instant('Toaster_error.captcha_error'));
      } else {
        this.showCaptcha=false;
        this.Login.get("captcha")?.get("fc_captchaCode")?.setValue("");
        this.login();
      }
      this.servicenotended=false;
    }, (error) => {
      this.servicenotended=false;
    });
    console.log("catch check............")
  }

  onNameChange(value: string): void {
    this.name = value;
   
  }

  passPlatformDetails(details:PlatformDetailsDto) {
    this.field=details;
    const arr = JSON.stringify(details);
    sessionStorage.setItem("platformDetails", arr);

    const platformDetails = JSON.parse(sessionStorage.getItem('platformDetails') ?? '{}');
    if(platformDetails) {
      if(platformDetails.platformId === 1) {
        window.location.href = platformDetails.platformUrl + '/#/login/authority';
      }
      else if(platformDetails.platformId === 2){
        window.location.href = platformDetails.platformUrl + '/#/login/authority';
      }
      else{
        window.location.href = platformDetails.platformUrl + '/#/login/authority';
      }
    }else{
      console.error(this.translate.instant('Toaster_error.invalid_platform'))
    }

  }

getImageUrl(){
const platformDetails = JSON.parse(sessionStorage.getItem('platformDetails') ?? '{}');
if(platformDetails){
if(platformDetails.platformId !== undefined)
{
//  this.dl_platform_image=true;
 return this.platformlogo=platformDetails.platformLogoPath;
}
return this.platformlogo;
}
}
getPlatform(){
const platformDetails = JSON.parse(sessionStorage.getItem('platformDetails') ?? '{}');
if(platformDetails){
if(platformDetails.platformId !== undefined)
{
// this.dl_platform_image=true
}
} 
}
}