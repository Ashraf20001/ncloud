import { commonConst } from '../const/common.const';

export enum ErrorCode {
    serverDown = 0,
    unauthorised = 403,
    unauthenticated = 401,
}

export enum ExpireTime {
    expirationTime = 12 * 60 * 60 * 1000,
}

export enum StageNameReportLoss {
    insuredDetails = 'Insured Details',
    tpDetails = 'TP Details',
    lossDetails = 'Loss Details',
    policeDetails = 'Police Report',
    garageDetails = 'Garage Details',
    surveyDetails = 'Survey Details',
    surveyReport = 'Survey Report',
    recoveryDetails = 'Recovery Details',
    reserveReview = 'Reserve Review',
    contact = 'Contact',
    garageInvoice = 'Garage Invoice',
    debitNote = 'Debit Note',
    creditNote = 'Credit Note',
}

export enum ReportLossStatus {
    draft = 'Draft',
    notificationOpen = 'Notification Open',
    notificationReceived = 'Notification Received',
    notificationAccepted = 'Notification Accepted',
    garageAndSurveyDetails = 'Garage And Survey Details Updated',
    movedToInspection = 'Moved To Inspection',
    underInspection = 'Under Inspection',
    expensesAndDocumentUpdated = 'Expenses And Document Updated',
    receivedLiabality = 'Received Liability',
    liabilityAccepted = 'Liability Accepted',
    liabilityReview = 'Liability Review',
    confirmLiability = 'Confirmed Liability',
    debitNoteGenerated = 'Debit Note Generated',
    claimSettled = 'Claim Settled',
    notificationRejected = 'Notification Rejected',
    receiveRejectedNotification = 'Received Rejected Notification',
    needMoreDetails = 'Need More Details',
    detailsProvided = 'Details Provided',
    reopen = 'Reopen',
    dispute = 'Dispute',
    disputeReopen = 'Dispute Reopen',
    totalLossInitiated = 'TotalLoss Initiated',
    totalLossAccepted = 'TotalLoss Accepted',
    surveyAssigned = 'Surveyor Assigned',
}

export enum ReportLossStatusValue {
    draft = 100,
    notificationOpen = 101,
    notificationReceived = 102,
    notificationAccepted = 103,
    garageAndSurveyDetails = 104,
    movedToInspection = 105,
    underInspection = 106,
    expensesAndDocumentUpdated = 107,
    receivedLiabality = 108,
    liabilityReview = 109,
    liabilityAccepted = 110,
    confirmLiability = 111,
    debitNoteGenerated = 112,
    claimSettled = 113,
    //fail flow
    // notificationRejected = 'NOTIFICATION REJECTED',
    // receiveRejectedNotification = 'RECEIVED REJECTED NOTIFICATION',
    // needMoreDetails = 'NEED MORE DETAIL',
    // detailsProvided = 'DETAILS PROVIDED',
    // reopen = 'REOPEN',
    // dispute = 'DISPUTE',
    // disputeReopen = 'DISPUTE REOPEN',
    // totalLossInitiated = 'TOTALLOSS INITITED',
    // totalLossAccepted = 'TOTALLOSS ACCEPTED',
    // surveyAssigned = 'SURVEYOR ASSIGNED'
}

export enum ReportLossStageEnum {
    notificationStage = 'Notification Stage',
    claimInspectionStage = 'Claim Inspection Stage',
    liabilityConfirmationStage = 'Liability Confirmation Stage',
    settlementStage = 'Settlement Stage',
}

export enum MimeTypeEnum {
    IMAGE = 'image',
    PDF = 'pdf',
}

export enum EntityName {
    insuredDetails = 'InsuredDetails',
    tpDetails = 'ThirdPartyDetails',
    lossDetails = 'LossDetails',
    policeDetails = 'PoliceReport',
    garageDetails = 'GarageInfo',
    surveyDetails = 'SurveyDetails',
    surveyReport = 'SurveyReport',
    recoveryDetails = 'RecoveryDetails',
    reserveReview = 'ReserveReview',
    contact = 'Contact',
    garageInvoice = 'GarageInvoice',
    debitNote = 'DebitNote',
    creditNote = 'CreditNote',
}

export enum REPORTHEADER {
    accepted = 'ACCEPTED',
    rejected = 'REJECTED',
    need_more_details = 'NEED_MORE_DETAILS',
    save = 'SAVE',
    assign_surveyor = 'ASSIGN_SURVEYOR',
    dispute = 'DISPUTE',
    details_provuded = 'DETAILS_PROVIDED',
    approved = 'APPROVED',
    reopen = 'REOPEN',
    dispute_repon = 'DISPUTE_REOPEN',
}

export enum ErrorCodeToIgnore {
    companyLogoError = 'E7112',
}

export enum File_ref_tupe {
    ref_type = 'stock',
}

export enum DateTime {
    startingTime = ' 00:00:00',
    endingTime = ' 23:59:00',
}

export const rzUserManagementRoleRestriction = [
    {
        menuName: commonConst.MENU_CONSTANTS.MENUNAME.DASHBOARD.NAME,
        isEdit: false,
        isNotification: false,
        isDownload: true,
        isView: true,
    },
    {
        menuName: commonConst.MENU_CONSTANTS.MENUNAME.RECEIVABLE.NAME,
        isEdit: true,
        isNotification: true,
        isDownload: false,
        isView: true,
    },
    {
        menuName: commonConst.MENU_CONSTANTS.MENUNAME.PAYABLE.NAME,
        isEdit: true,
        isNotification: true,
        isDownload: false,
        isView: true,
    },
    {
        menuName: commonConst.MENU_CONSTANTS.MENUNAME.REPORTS.NAME,
        isEdit: true,
        isNotification: false,
        isDownload: true,
        isView: true,
    },
    {
        menuName: commonConst.MENU_CONSTANTS.MENUNAME.USERMANAGEMENT.NAME,
        isEdit: true,
        isNotification: false,
        isDownload: false,
        isView: true,
    },
    {
        menuName: commonConst.MENU_CONSTANTS.MENUNAME.ENTITYMANAGEMENT.NAME,
        isEdit: true,
        isNotification: false,
        isDownload: false,
        isView: true,
    },
];

export const UserManagementRoleRestriction = [
    {
        menuName: commonConst.MENU_CONSTANTS.MENUNAME.DASHBOARD.NAME,
        sectionName: [
            {
                name: commonConst.MENU_CONSTANTS.MENUNAME.DASHBOARD.NAME,

                subSection: [
                    {
                        name: 'Digital Paper Taken',
                        isView: true,
                        isEdit: true,
                        isClone: false,
                        isDisable: false,
                        isDownload: true,
                    },
                    {
                        name: 'Digital Paper Status',
                        isView: true,
                        isEdit: true,
                        isClone: false,
                        isDisable: false,
                        isDownload: true,
                    },
                    {
                        name: 'Prediction',
                        isView: true,
                        isEdit: true,
                        isClone: false,
                        isDisable: false,
                        isDownload: true,
                    },
                    {
                        name: 'Recent Digital Papers',
                        isView: true,
                        isEdit: true,
                        isClone: false,
                        isDisable: false,
                        isDownload: false,
                    },
                    {
                        name: 'Upcoming Expire Digital Papers',
                        isView: true,
                        isEdit: true,
                        isClone: false,
                        isDisable: false,
                        isDownload: false,
                    },
                    {
                        name: 'Quick Links',
                        isView: true,
                        isEdit: true,
                        isClone: false,
                        isDisable: false,
                        isDownload: false,
                    },
                ],
            },
        ],
    },
    {
        menuName: commonConst.MENU_CONSTANTS.MENUNAME.REPORTS.NAME,
        sectionName: [
            {
                name: commonConst.MENU_CONSTANTS.MENUNAME.REPORTS.NAME,

                subSection: [
                    {
                    name: 'Reports',
                    isView: true,
                    isEdit: true,
                    isClone: false,
                    isDisable: false,
                    isDownload: true,
                    },
                    {
                        name: 'Generate Reports',
                        isView: true,
                        isEdit: true,
                        isClone: false,
                        isDisable: false,
                        isDownload: false,
                    },
                ],
            },
        ],
    },
    {
        menuName: commonConst.MENU_CONSTANTS.MENUNAME.USERMANAGEMENT.NAME,
        sectionName: [
            {
                name: 'Allocation Pool',
                subSection: [
                    {
                        name: 'Pool List',
                        isView: true,
                        isEdit: true,
                        isClone: false,
                        isDisable: false,
                        isDownload: true,
                    },
                    {
                        name: 'Allocate Stock',
                        isView: true,
                        isEdit: true,
                        isClone: false,
                        isDisable: false,
                        isDownload: false,
                    },
                    {
                        name: 'Reallocate',
                        isView: true,
                        isEdit: true,
                        isClone: false,
                        isDisable: false,
                        isDownload: false,
                    },
                    {
                        name: 'Deallocate',
                        isView: true,
                        isEdit: true,
                        isClone: false,
                        isDisable: false,
                        isDownload: false,
                    },
                ],
            },
            {
                name: 'User Role',
                subSection: [
                    {
                        name: 'User Role List',
                        isView: true,
                        isEdit: true,
                        isClone: true,
                        isDisable: true,
                        isDownload: true,
                    },
                    {
                        name: 'Add New Role',
                        isView: true,
                        isEdit: true,
                        isClone: false,
                        isDisable: false,
                        isDownload: false,
                    },
                ],
            },
            {
                name: 'User Management',
                subSection: [
                    {
                        name: 'User List',
                        isView: true,
                        isEdit: true,
                        isClone: true,
                        isDisable: true,
                        isDownload: true,
                    },
                    {
                        name: 'Add New User',
                        isView: true,
                        isEdit: true,
                        isClone: false,
                        isDisable: false,
                        isDownload: false,
                    },
                ],
            },
        ],
    },
    {
        name: commonConst.MENU_CONSTANTS.MENUNAME.ENTITYMANAGEMENT.NAME,
        sectionName: [
            {
                name: commonConst.MENU_CONSTANTS.MENUNAME.ENTITYMANAGEMENT.NAME,

                subSection: [
                    {
                        name: 'Company List',
                        isView: true,
                        isEdit: true,
                        isClone: false,
                        isDisable: false,
                        isDownload: true,
                    },
                    {
                        name: 'Add New Company',
                        isView: true,
                        isEdit: true,
                        isClone: false,
                        isDisable: false,
                        isDownload: false,
                    },
                ],
            },
        ],
    },
    {
        menuName: commonConst.MENU_CONSTANTS.MENUNAME.PURCHASESTOCK.NAME,
        sectionName: [
            {
                name: commonConst.MENU_CONSTANTS.MENUNAME.PURCHASESTOCK.NAME,

                subSection: [
                    {
                        name: 'Purchase List',
                        isView: true,
                        isEdit: true,
                        isClone: false,
                        isDisable: false,
                        isDownload: true,
                    },
                    {
                        name: 'New Purchase',
                        isView: true,
                        isEdit: true,
                        isClone: false,
                        isDisable: false,
                        isDownload: false,
                    },
                ],
            },
        ],
    },
    {
        menuName: commonConst.MENU_CONSTANTS.MENUNAME.PAPERDETAILS.NAME,
        sectionName: [
            {
                name: commonConst.MENU_CONSTANTS.MENUNAME.PAPERDETAILS.NAME,

                subSection: [
                    {
                        name: 'Paper List',
                        isView: true,
                        isEdit: true,
                        isClone: false,
                        isDisable: false,
                        isDownload: true,
                    },
                    {
                        name: 'Generate Paper (Manual)',
                        isView: true,
                        isEdit: true,
                        isClone: false,
                        isDisable: false,
                        isDownload: false,
                    },
                    {
                        name: 'Generate Paper (Bulk)',
                        isView: true,
                        isEdit: true,
                        isClone: false,
                        isDisable: false,
                        isDownload: false,
                    },
                    {
                        name: 'Revoke (Manual)',
                        isView: true,
                        isEdit: true,
                        isClone: false,
                        isDisable: false,
                        isDownload: false,
                    },
                    {
                        name: 'Revoke (Bulk)',
                        isView: true,
                        isEdit: true,
                        isClone: false,
                        isDisable: false,
                        isDownload: false,
                    },
                    {
                        name: 'Print',
                        isView: true,
                        isEdit: true,
                        isClone: false,
                        isDisable: false,
                        isDownload: false,
                    },
                ],
            },
        ],
    },
];


export enum ToasterMessage {
  claimAccepted = 'Claim Accepted',
  claimRejected = 'Claim Rejected',
  moreDetailsRequired = 'More Details Required',
  claimInitiatedSuccessfully = 'Claim Initiated Successfully',
  claimSubmitted = 'Claim Submitted',
  surveyorAssigned = 'Surveyor Assigned',
  disputeRaised = 'Dispute Raised',
  detailsProvided = 'Details Provided',
  claimApproved = 'Claim Approved',
  claimReponed = 'Claim Reopened',
  disputeReopened = 'Dispute Reopened',
  tooManyAttempts ='Too Many Attempts'
}

export enum AllocationPool {
    pollName = 'Pool Name',
    description = 'Description',
    no_of_paper_allocated = 'No.of paper allocated',
    no_of_paper_Issued = 'No.of.paper Issued',
    no_of_paper_available = 'No.of.paper available',
    allocate_and_Revoke = 'Allocate and Revoke',
    status = 'Status',
}

export enum componentName {
    Purchase_History = 'purchase-history',
    Purchase_Stock = 'purchase-stock',
    TRANSACTION_LIST = 'trasaction-list',
    PAPER_DETAILS = 'paper_details',
    PAPER_DETAILS_TRANSACTION_LIST = 'paper_details_transaction_list',
}

export enum PaymentChoice {
    CHEQUE = 'CHEQUE',
    CASH = 'CASH',
    CREDIDCARD = 'CREDIT CARD',
    UPI = 'UPI',
    AIRTELMONEY = 'AIRTEL MONEY',
    DEBITCARD = 'DEBIT CARD',
}

export enum AllocationPoolSortingColumn {
    USERTYPENAME = 'userTypeName',
    IDENTITY = 'identity',
    STOCKCOUNT = 'stockCount',
    USEDCOUNT = 'usedCount',
    NULL = 'null',
    ISACTIVE = 'isActive',
}

export enum BulkUpload {
    ERRORFIELDS = 'Error Fields',
}
