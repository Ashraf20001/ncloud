export enum PlatFormTypeEnum{
    DIGITAL_PAPER = 2,
    DATA_LAKE = 3
}