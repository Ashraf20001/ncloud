import { Component,Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import {DisablePopupInUserComponent} from '../../user-management/disable-popup-user/disable-popup-user.component';

@Component({
  selector: 'app-popup',
  templateUrl: './popup.component.html',
  styleUrls: ['./popup.component.scss']
})

export class PopupComponent implements OnInit{

  deleteText = '';
  roles:boolean;
  name='';

  constructor(public dialogRef: MatDialogRef<PopupComponent>,private dialog:MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any) { 
     if(data.delete) {
      this.deleteText = data.delete;
      this.roles=data.role;
      this.name = data?.name;
     }
     
     }
     ngOnInit(): void {
     }
     
  cancel(value:boolean){
  this.dialogRef.close(value);
  }
  submit(value:boolean){
    if(this.deleteText == 'approvalLimit'){
      this.dialogRef.close(value);
    }else{
      this.deleteRoleInCard();
    }
  }

deleteRoleInCard(){
    const dialogRef = this.dialog.open(DisablePopupInUserComponent, {
      width: '456px',
      height: '250px',
      data:{
        isUser:this.data.isUser,
        name : this.data.name,
        status : this.data.status
      }
    });
      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          this.dialogRef.close(result);
          }else{
            this.dialogRef.close(false);

          }
       });
    }
}



export interface Data{
  name: string;
  status: string;
}