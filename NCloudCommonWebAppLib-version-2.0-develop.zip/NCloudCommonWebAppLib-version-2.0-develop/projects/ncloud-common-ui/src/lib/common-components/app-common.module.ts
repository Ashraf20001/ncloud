import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {MatCardModule} from '@angular/material/card';
import { MatSlideToggleModule } from '@angular/material/slide-toggle'
import {MatDividerModule} from '@angular/material/divider';
import {  TranslateModule } from '@ngx-translate/core';
import { PopupComponent } from "./popup/popup.component";
import { PagenotfoundComponent } from "./pagenotfound/pagenotfound.component";
import{BreadcrumbComponent} from './breadcrumb/breadcrumb.component'
import{BreadcrumbService,BreadcrumbModule} from 'xng-breadcrumb'
import {RouterModule} from '@angular/router';
import {MatDialogModule} from '@angular/material/dialog';
import { DisablePopupComponent } from './disable-popup/disable-popup.component';
import { AppService } from "../service/app.service";
import { DemoMaterialModule } from "./angularMaterialModules/material-module";


import { CommonDownloadComponent } from "./common-download/common-download.component";
import { NgbPopoverModule } from "@ng-bootstrap/ng-bootstrap";
import { ClickOutsideDirective } from "../directive/directives/Click-outside.directive";
import { SearchBarComponent } from "./search-bar/search-bar.component";
@NgModule({
  declarations:[
    PagenotfoundComponent,
    PopupComponent,
    BreadcrumbComponent,
    DisablePopupComponent,
    SearchBarComponent,
    CommonDownloadComponent,
    ClickOutsideDirective
  ],
  imports:[
    CommonModule,MatDialogModule,
    FormsModule,
    MatCardModule,
    MatSlideToggleModule,
    MatDividerModule,
    TranslateModule,
    BreadcrumbModule,
    RouterModule,
    ReactiveFormsModule,
    DemoMaterialModule,
    NgbPopoverModule,

  ],
  exports:[
    PagenotfoundComponent,
    PopupComponent,
    BreadcrumbComponent,
    DisablePopupComponent,
    SearchBarComponent,
    CommonDownloadComponent,
    DemoMaterialModule
  ],
  providers:[
    BreadcrumbService,
    AppService
  ]
})

export class AppCommonModule{

}
