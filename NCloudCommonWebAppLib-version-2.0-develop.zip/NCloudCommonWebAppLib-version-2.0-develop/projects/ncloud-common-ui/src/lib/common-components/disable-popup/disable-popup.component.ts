import { Component, Inject, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import * as moment from 'moment';
import { DisableDto } from '../../dto/disable-dto';

@Component({
  selector: 'app-disable-popup',
  templateUrl: './disable-popup.component.html',
  styleUrls: ['./disable-popup.component.css']
})
export class DisablePopupComponent implements OnInit{
    
  effectiveDate = new FormControl();
  disableDto = new DisableDto();
  minimumDate = new Date();
  constructor(public dialogRef: MatDialogRef<DisablePopupComponent>, @Inject(MAT_DIALOG_DATA) public data: Data) { }
 
  ngOnInit(): void {
    
  }
  /*
  * Cancel
  */
  cancel(value: boolean) {
    this.dialogRef.close(value);
  }
  /*
  * Submit
  */
  submit() {
    this.disableDto.effectiveDate = this.effectiveDate.value;
    this.dialogRef.close(this.disableDto);
  }
  /*
  * CloseTab
  */
  closeTab(){
    this.dialogRef.close(false);
  }

}

export interface Data {
  status: string;
  name:string;
  effectiveDate: string;
}
