export interface Menu{
  menuId:number;
  menuName:string;
  routeUrl:string;
  logoPath:string
}
