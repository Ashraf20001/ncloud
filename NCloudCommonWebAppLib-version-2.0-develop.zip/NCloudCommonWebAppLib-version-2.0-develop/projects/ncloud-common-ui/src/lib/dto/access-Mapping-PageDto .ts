import { AccessMappingSectionDto } from './Filter-dto/section-dto';
import { PrevilageDto } from './previlage-dto';
export class AccessMappingPageDto {
  pageId?:number;
  isEnabled?:boolean;
  sectionData?:AccessMappingSectionDto[];
  privilegeData?:PrevilageDto[];
  pageName?:string;
  displayName?: string;
}
