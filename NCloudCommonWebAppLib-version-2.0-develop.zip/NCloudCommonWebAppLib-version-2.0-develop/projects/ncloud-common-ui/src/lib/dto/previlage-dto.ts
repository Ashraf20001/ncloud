export class PrevilageDto{
    privilegeId?:number;
    isEnabled?:boolean;
    pageId?:number;
    privilegeName?:string;
  }
  