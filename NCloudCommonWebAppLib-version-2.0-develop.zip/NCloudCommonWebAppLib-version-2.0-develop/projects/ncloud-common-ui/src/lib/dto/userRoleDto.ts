import { RoleDto } from './role-dto';
//import { MetaDataDto } from 'src/app/models/report-loss-dto/meta-data-dto';
import { MetaDataDto } from './entity-management/meta-data-dto';
export class UserRoleDto{
  roleDetails:MetaDataDto;
  accessMapping:RoleDto;
}
