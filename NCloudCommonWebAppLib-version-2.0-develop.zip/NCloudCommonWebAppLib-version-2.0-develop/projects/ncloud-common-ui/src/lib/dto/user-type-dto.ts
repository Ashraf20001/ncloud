export interface UserTypeDto {
    userTypeId: number;
    userTypeName: string;
}