export class BarChartDto {
  fromDate: Date;
  toDate: Date;
  filterType: string;
}
