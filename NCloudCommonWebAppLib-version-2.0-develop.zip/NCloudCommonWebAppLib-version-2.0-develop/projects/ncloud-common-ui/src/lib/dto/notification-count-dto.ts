export interface NotificationCountDTO {
    companyName: string;
    readCount: number;
    unReadCount: number;
    totalCount: number;
}
