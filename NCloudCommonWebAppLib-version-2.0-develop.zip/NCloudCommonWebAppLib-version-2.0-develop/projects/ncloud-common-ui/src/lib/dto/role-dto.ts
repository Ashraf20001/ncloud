import { UserMenuDto } from "./user-menu-dto";

export class RoleDto{
  roleId?:number;
  menuData?:UserMenuDto[];
}

export class UserDto{
  menuData?:UserMenuDto[];
}