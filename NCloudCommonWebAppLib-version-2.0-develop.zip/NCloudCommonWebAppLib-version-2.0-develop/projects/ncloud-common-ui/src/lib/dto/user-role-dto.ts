export class UserRole{
    roleId?:number;
    roleName?:string;
  }
  