import { AccessMappingPageDto } from './access-Mapping-PageDto ';
export class UserMenuDto{
  menuId?:number;
  isEnabled?:boolean;
  pageData?:AccessMappingPageDto[];
  menuName?:string;
}