export interface VerifyCaptchaDetailsDto {
    clear: boolean;
    captchaValue: string;
    compareCaptchaDataValue: string;
}

export interface CaptchaDto {
    captcha: string;
    captchaValue: string;
    compareCaptchaDataValue: string;
}

export interface CaptchaResultDto {
    success: boolean;
    code: string;
    msg: string;
    errorMsg: string;
}
