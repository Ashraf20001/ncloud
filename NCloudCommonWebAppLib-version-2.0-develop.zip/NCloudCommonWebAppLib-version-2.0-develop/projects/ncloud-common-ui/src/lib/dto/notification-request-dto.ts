export interface NotificationRequestDto {
    claimId: number;
    status: string;
    companyName: string;
    isReceivable: string;
    logoUrl: string;
    lastActed: string;
    platformId : any;
}

export class NotificationDetailsDto{
    reportLossDto : any;
	userId : number; 
	loginUserCompanyName : string;
	insurerName : string;
	thirdPartyTpname : string;
	logoByCompanyId :string;
	state : string;
	minAmount : number;
	maxAmount : number;
	roleName : string;
	period : string;
	associationName : string;
	paymentId : number;
	repositoryIdentity : string;
}