export interface FieldDTO {
    fieldId?: string;
    aliasName?:string;
    fieldName?: string;
    fieldType?: string;
    fieldDefault?:string;
    minlength?:number;
    maxlength?:number;
    regex?:string;
    mandatory?:boolean;
}
