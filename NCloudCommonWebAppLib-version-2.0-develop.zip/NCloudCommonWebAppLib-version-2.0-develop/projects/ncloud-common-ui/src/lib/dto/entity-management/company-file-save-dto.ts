export class CompanyFileSaveDto{
    referenceId:string;
    fileUrl:string;
    pageId:string;
    isEdit:boolean;
    password:string;
}