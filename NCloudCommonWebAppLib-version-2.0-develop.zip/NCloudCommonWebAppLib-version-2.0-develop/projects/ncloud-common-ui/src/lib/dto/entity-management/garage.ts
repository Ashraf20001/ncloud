export class GarageDto{
    emGarageId?:number;
    emGarageShortId?:string;
    emGarageName?:string;
    emGarageEmail?:string;
    emGarageLocation? : string;
    emGarageAddress? :string;
    emGaragePassword? : string;
    emGarageUserId? : string;
    emGarageLogo? : string;
    emGaragePhone? : string;
    emGarageIsActive?: string;
    loading:boolean=true;
    isDisableGarage :string;
}