import { FieldValueDTO } from "./field-value-dto";

export interface FieldGroupDTO {
    groupName?: string;
    fieldValues?: FieldValueDTO[];
    fieldGroups?: FieldGroupDTO[];
}

export class PurchaseStockData {
    numberOfPapers?: string;
    totalCostValue?: string;
    paymentMethod?: string;
    uploadFileName?: boolean;
}

export class AllocateStockVo {
    numberOfPaper?: number;
    allocatepaperType?: string;
    companyId?:number;
}
