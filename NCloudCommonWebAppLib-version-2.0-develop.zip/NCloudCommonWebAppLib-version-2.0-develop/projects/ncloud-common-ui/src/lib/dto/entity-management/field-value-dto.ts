import { FieldDTO } from "./field-dto";

export interface FieldValueDTO {
    field?: FieldDTO;
    value?: string;
}
