import { PlatformDetailsDto } from "./platform-details-dto";
import { Menu } from "./menu-dto";

export interface HeaderDto {
  menuDetails:Menu[];
  platformDetails:PlatformDetailsDto
  companyLogoPath:string;

}
