export class PaymentDetailsDto{
    companyName?:string;
    purchaseId?:string;
    transactionId?:string;
    paymentType?:string;
    noOfPapers?:number;
    purchaseAmount?:number;
    paymentStatus?:string;
    actionButton?:string;
}