import { FieldGroupDTO } from './entity-management/field-group-dto';
import { UserDto } from './role-dto';
export class userPageDto{
  isActive?:boolean;
  userDetails?:FieldGroupDTO;
  enableNotification?:UserDto;
}
