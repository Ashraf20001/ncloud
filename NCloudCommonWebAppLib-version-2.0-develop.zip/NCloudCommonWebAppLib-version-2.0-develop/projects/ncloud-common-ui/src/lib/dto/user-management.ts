import { UserRole } from "./user-role-dto";




export class userManagement{
  userName:string;
  emailId:string;
  userId:number;
  addedDate:string;
  status:boolean;
  userIdentity:string;
  userSeqId:string;
  phoneNumber:string;
  userRoleList:UserRole[];
  isDisable: boolean;
}

