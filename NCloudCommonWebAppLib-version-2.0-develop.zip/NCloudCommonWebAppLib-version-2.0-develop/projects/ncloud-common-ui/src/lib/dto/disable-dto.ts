export class DisableDto {
    effectiveDate? : string;
    identity? : string;
  }
export class userDissableDto{
  expiredDate: Date;
  identity:string;
  userId:number;
  isMapped?:boolean;
}