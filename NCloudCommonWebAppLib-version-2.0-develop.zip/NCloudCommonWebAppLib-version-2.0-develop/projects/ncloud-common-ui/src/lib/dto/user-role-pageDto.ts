import { FieldGroupDTO } from './entity-management/field-group-dto';
import { RoleDto } from './role-dto';
export class UserRolePage{
  isActive?:boolean;
  roleDetails?:FieldGroupDTO;
  accessMapping?:RoleDto;
}
