export class AccessMappingSectionDto {
    sectionName?:string;
    isView?:boolean;
    isEdit?:boolean;
    isDownload?:boolean;
    isNotification?:boolean;
    isEmail?:boolean;
    sectionData?:AccessMappingSectionDto[];
    sectionId?:number;
    pageId?:number;
    isClone?:boolean;
    isDisable?:boolean;
  }