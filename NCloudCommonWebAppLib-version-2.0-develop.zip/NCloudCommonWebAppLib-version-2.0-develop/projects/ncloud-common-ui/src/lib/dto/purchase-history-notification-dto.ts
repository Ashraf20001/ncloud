export class PurchaseHistoryNotificationDTO {
    notificationMsg!: any;
    actedBy: any;
    orderId: any;
    createdDate!:any;
    imageUrl:any;
    logoUrl:string;
    notificationId:any;
    identity:any;
    repoIdentity:any;
    isRepoCmts:any;
    status!:string;
    notificationJson:any;
}
