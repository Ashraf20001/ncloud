export interface ResetPasswordRequest{
    identity: string;
    newPassword: string;
    confirmPassword: string;
}
