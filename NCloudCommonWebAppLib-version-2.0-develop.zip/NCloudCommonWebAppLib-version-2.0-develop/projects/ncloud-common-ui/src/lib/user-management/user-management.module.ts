import { CommonModule } from "@angular/common";
import { ModuleWithProviders, NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { UserManagementRoutingModule } from "./user-management-routing.module";
import { UserManagementComponent } from "./user-management.component";
import { TranslateModule } from '@ngx-translate/core';
import { MatListModule} from '@angular/material/list';
import { DemoMaterialModule } from "../common-components/angularMaterialModules/material-module";
import { AppCommonModule } from "../common-components/app-common.module";
import {DisablePopupInUserComponent} from "./disable-popup-user/disable-popup-user.component";


@NgModule({
  declarations:[
    UserManagementComponent,
   DisablePopupInUserComponent,
  
  ],
  imports:[
    CommonModule,
    FormsModule,
    UserManagementRoutingModule,
    TranslateModule,
    MatListModule,
    DemoMaterialModule,
    AppCommonModule
  ],
  exports:[
    UserManagementComponent,
    
  ]
})

export class UserManagementModule{
  public static forRoot(environment: any): ModuleWithProviders<UserManagementModule> {
    return {
      ngModule: UserManagementModule,
      providers: [
        {
          provide: 'env', // you can also use InjectionToken
          useValue: environment
        }
      ]
    };
  }
}


