import { Component, OnDestroy, OnInit } from '@angular/core';
import { zip } from 'rxjs';
import { UserListService } from '../../service/user-list.service';
import { AppService } from '../../service/app.service';
import { appConst } from '../../const/app.const';
import { AccessMappingPageDto } from '../../dto/access-Mapping-PageDto ';

@Component({
  selector: 'app-approval-limit',
  templateUrl: './approval-limit.component.html',
  styleUrls: ['./approval-limit.component.scss']
})

export class ApprovalLimitComponent implements OnInit, OnDestroy {

  listshow = true;

  addshow = false;



  approvalLimitCardPageAccessMap: AccessMappingPageDto;

  approvalLimitListPageAccessMap: AccessMappingPageDto;

  approvalLimitAddPageAccessMap: AccessMappingPageDto;

  approvalLimitCardPrivillegeInfo: any;

  approvalLimitListPrivillegeInfo: any;

  approvalLimitAddPrivillegeInfo: any;

  isApprovalLimitListPageEnabled = true;

  isApprovalLimitCardPageEnabled = true;

  isApprovalLimitAddPageEnabled = true;



  constructor(private service: UserListService, private appService: AppService) { }



  ngOnInit() {

    this.getPageAccessData();

    this.getPrivillege();

    this.getSessionStorageLastPageValue()

    this.service.cardShow.subscribe((value) => {

      this.listshow = value;

      this.addshow = true

      this.setSessionLastShowPage();

    })

  }

  listmethod(event: any) {

    this.listshow = event.listpage;

    this.addshow = event.addpage;

    this.setSessionLastShowPage();

  }

  addmethod(event: any) {

    this.listshow = event.listpage;

    this.addshow = event.addpage;

    this.setSessionLastShowPage();

  }



  resetPage() {

    this.listshow = true;

    this.addshow = false;

  }



  getPageAccessData(): void {

    zip(

      this.appService.getPageAccess(appConst.PAGE_NAME.USERMANAGEMENT.USERMANAGEMENT_APPROVALLIMIT.USERMANAGEMENT_APPROVALLIMIT_CARD.PAGE_IDENTITY),

      this.appService.getPageAccess(appConst.PAGE_NAME.USERMANAGEMENT.USERMANAGEMENT_APPROVALLIMIT.USERMANAGEMENT_APPROVALLIMIT_LIST.PAGE_IDENTITY),

      this.appService.getPageAccess(appConst.PAGE_NAME.USERMANAGEMENT.USERMANAGEMENT_APPROVALLIMIT.USERMANAGEMENT_APPROVALLIMIT_ADD.PAGE_IDENTITY)

    ).subscribe((responseList: any[]) => {

      if (responseList && responseList.length > 0) {

        this.approvalLimitCardPageAccessMap = responseList[0].content;

        this.isApprovalLimitCardPageEnabled = this.approvalLimitCardPageAccessMap?.isEnabled;

        this.approvalLimitListPageAccessMap = responseList[1].content;

        this.isApprovalLimitListPageEnabled = this.approvalLimitListPageAccessMap?.isEnabled;

        this.approvalLimitAddPageAccessMap = responseList[2].content;

        this.isApprovalLimitAddPageEnabled = this.approvalLimitAddPageAccessMap?.isEnabled;

      }

    });

  }



  getPrivillege(): void {

    zip(

      this.appService.getPrivilegeForPage(appConst.PAGE_NAME.USERMANAGEMENT.USERMANAGEMENT_APPROVALLIMIT.USERMANAGEMENT_APPROVALLIMIT_CARD.PAGEID),

      this.appService.getPrivilegeForPage(appConst.PAGE_NAME.USERMANAGEMENT.USERMANAGEMENT_APPROVALLIMIT.USERMANAGEMENT_APPROVALLIMIT_LIST.PAGEID),

      this.appService.getPrivilegeForPage(appConst.PAGE_NAME.USERMANAGEMENT.USERMANAGEMENT_APPROVALLIMIT.USERMANAGEMENT_APPROVALLIMIT_ADD.PAGEID)

    ).subscribe((responseList: any[]) => {

      this.approvalLimitCardPrivillegeInfo = responseList[0].content;

      this.approvalLimitListPrivillegeInfo = responseList[1].content;

      this.approvalLimitAddPrivillegeInfo = responseList[2].content;

    });

  }



  private setSessionLastShowPage() {

    sessionStorage.setItem('AddApprovalLimitPageIsEnabled', JSON.stringify(this.addshow));

    sessionStorage.setItem('AddApprovalLimitListPageIsEnabled', JSON.stringify(this.listshow));

  }



  private getSessionStorageLastPageValue() {

    if (sessionStorage?.getItem('AddApprovalLimitPageIsEnabled') && sessionStorage?.getItem('AddApprovalLimitListPageIsEnabled')) {

      this.addshow = sessionStorage.getItem('AddApprovalLimitPageIsEnabled') == "true";

      this.listshow = sessionStorage.getItem('AddApprovalLimitListPageIsEnabled') == "true";

    }

  }



  ngOnDestroy(): void {

    sessionStorage.removeItem('AddApprovalLimitPageIsEnabled');

    sessionStorage.removeItem('AddApprovalLimitListPageIsEnabled');

  }
}
