import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { appConst } from '../../../const/app.const';
import { UserListService } from '../../../service/user-list.service';
import { TranslateService } from '@ngx-translate/core';
import { ErrorHandlerDirective } from '../../../directive/directives/errorHandler.directive';

@Component({
  selector: 'app-add-approval-limit',
  templateUrl: './add-approval-limit.component.html',
  styleUrls: ['./add-approval-limit.component.scss']
})
export class AddApprovalLimitComponent implements OnInit {
  @Input() usermanageshow:any;
  @Input() isApprovalLimitAddPageEnabled = true;
  @Input() approvalLimitAddPrivillegeInfo: any;
  @Output() usermanageshowplayback = new EventEmitter<any>();
  /** MOCK DATA OBJECT HERE */
  fieldList:any =[];
  RoleList:any=[];
  compIdList :number[]=[];
  selectedValue: string;
  selectedOptions : any;
  ApprovalLimitDto:FormGroup;
  fieldListIndex:any=1;
  selectfield='';
  approvalLimitId:number;
  approvalLimit;
  fieldname:string;
  isactive:boolean=true;
  clone:boolean=false;
  knockboolean:boolean=false;
  companyMap:companyrole[]=[];
  companyMapEdit:companyrole[]=[];
  appConst = appConst;
  selectAllOption = true;
  tempApprovalLimit: any;
  newApprovaleLimit: boolean;
  selectedOption = new FormControl('');
  searchTerm: string = '';
  selectedCurrency: string;
  currencyType: string[] =[]


  constructor(private router: Router, private fb: FormBuilder, private userservice: UserListService, private activateRoute: ActivatedRoute, private tosterservice: ToastrService,
    private errorHandler: ErrorHandlerDirective,private translate: TranslateService) {
  
    this.ApprovalLimitDto = this.fb.group({
      fieldName: ['', [Validators.required]],
      approvalLimitId: [null],
      stageName: [''],
      role: this.fb.array([]),
      approvalLevel: this.fb.array([], [Validators.required]),
      isActive: [true, [Validators.required]],
      approvalLimitIdentity: [''],
    });
    (<FormArray>this.ApprovalLimitDto.get('approvalLevel')).push(this.addNewRule())

    this.activateRoute.queryParams.subscribe(((queryParams: any) => {
      this.approvalLimitId = queryParams['approvalLimitId'];
      this.newApprovaleLimit = queryParams['newApprovaleLimit'];
      
      if (this.approvalLimitId != null || this.approvalLimitId != undefined) {
        this.getData(); //edit 
      }
      this.approvalLimitId = queryParams['approvalId'];
       if (this.approvalLimitId != null || this.approvalLimitId != undefined) { 
        this.getData(); // clone
      }else if (this.newApprovaleLimit) {
        this.clearFieldValue(); //new
      }
    }))


  }

  ngOnInit() {
    this.userservice.getFieldList().subscribe(data => {
      this.fieldList = data;
    });
    this.userservice.getRoleList().subscribe(data => {
      data.forEach(element => {
        this.RoleList.push(element);
      });
    });
    this.getCompanyList('ADD');
    this.getCurrencyValue();
  }

  get filteredFieldList() {
    const searchTerms = this.searchTerm.toLowerCase().split(' '); // Split the search term into words
      return this.fieldList.filter(item => {
      return searchTerms.every(term => item.toLowerCase().includes(term));
    });
  }
  clearSearch() {
    if (this.searchTerm === '') {
      this.selectedOption.setValue(null);
    }
  }
  
/**
* GET CURRENCY VALUE
*/
  private getCurrencyValue() {
    this.userservice.getCurrencyTypeList().subscribe((res) => {
      if (res && res['content']) {
        this.currencyType = [];
        res['content'].forEach((currency) => {
          this.currencyType.push(currency.optionName);
        });
      }
    });
  }

  getCompanyList(action){
  this.userservice.getCompanyList(action).subscribe(data=>{
    // this.companyMap = data;
    this.companyMap = [];
    Object.keys(data).forEach(key => {
    const compname=new companyrole();
    compname.id=parseInt(key);
    compname.name=data[key]

      this.companyMap.push(compname);
    });
    const ls = this.userservice.sharedCompanyList;
    this.companyMap= this.companyMap.filter((value: companyrole) => !ls.includes(value.name));
  });



}
  getData() {
    this.userservice.getAppprovalLimitByIdentity(this.approvalLimitId).subscribe((data) => {
      this.approvalLimitId = data.approvalLimitId;
      this.approvalLimit = data;
      this.tempApprovalLimit = data;
      this.ApprovalLimitDto.controls['fieldName'].setValue(this.approvalLimit.fieldName);
      this.setFormName(this.approvalLimit.fieldName, "EDIT")

      this.fieldname = this.approvalLimit.fieldName;
      this.fetchApprovalLimitValue(false);

      this.userservice.isClone.subscribe((value) => {
        this.clone = value;
      })
      if (this.clone === true) {
        this.ApprovalLimitDto.controls['approvalLimitId'].setValue(null);
      }

    });

  }
  /**
   *  Fetch ApprovalLimit Value
   * @param value 
   */

  private fetchApprovalLimitValue(value:boolean) {
    if(value){
      this.approvalLimit = this.tempApprovalLimit;
    }
    for (let i = 0; i < this.approvalLimit.approvalLevel.length; i++) {
      if (i !== 0) {
        (<FormArray>this.ApprovalLimitDto.get('approvalLevel')).push(this.addNewRule());
      }
      (<FormArray>this.ApprovalLimitDto.get('approvalLevel')).at(i).setValue({
        minValue: this.approvalLimit.approvalLevel[i].minValue,
        maxValue: this.approvalLimit.approvalLevel[i].maxValue,
        currency: this.approvalLimit.approvalLevel[i].currency,
        roleId: this.approvalLimit.fieldName == 'KnockForKnock' ? this.approvalLimit.approvalLevel[i].roleId : this.approvalLimit.approvalLevel[i].roleId[0],
      });

    }
    this.ApprovalLimitDto.controls['approvalLimitIdentity'].setValue(this.approvalLimit.approvalLimitIdentity);
    this.ApprovalLimitDto.controls['isActive'].setValue(this.approvalLimit.isActive);
    this.fieldname = this.ApprovalLimitDto.get('fieldName').value;
    this.ApprovalLimitDto.controls['approvalLimitId'].setValue(this.approvalLimitId);
    this.isactive = this.ApprovalLimitDto.get('isActive').value;
  }

  cloneData(){
    this.userservice.getAppprovalLimitByIdentity(this.approvalLimitId).subscribe((data)=>{
      data.approvalLimitId=null;
      this.approvalLimitId=data.approvalLimitId;
      this.approvalLimit=data;
      for(let i=0;i<this.approvalLimit.approvalLevel.length;i++){
        if(i !== 0) {
           (<FormArray>this.ApprovalLimitDto.get('approvalLevel')).push(this.addNewRule());
          }
           if(this.approvalLimit.fieldName == "KnockForKnock"){
            (<FormArray>this.ApprovalLimitDto.get('approvalLevel')).at(i).setValue({
              roleId:  this.approvalLimit.fieldName == 'KnockForKnock' ? this.approvalLimit.approvalLevel[i].roleId : this.approvalLimit.approvalLevel[i].roleId[0],
               minValue: this.approvalLimit.approvalLevel[i].minValue,
                maxValue: this.approvalLimit.approvalLevel[i].maxValue,});
                this.knockboolean=true;
           }else{
            this.knockboolean=false;
           (<FormArray>this.ApprovalLimitDto.get('approvalLevel')).at(i).setValue({
             roleId:  this.approvalLimit.fieldName == 'KnockForKnock' ? this.approvalLimit.approvalLevel[i].roleId : this.approvalLimit.approvalLevel[i].roleId[0],
              minValue: this.approvalLimit.approvalLevel[i].minValue,
               maxValue: this.approvalLimit.approvalLevel[i].maxValue,});

           }
          }

     this.ApprovalLimitDto.controls['approvalLimitIdentity'].setValue(this.approvalLimit.approvalLimitIdentity);
     this.ApprovalLimitDto.controls['isActive'].setValue(this.approvalLimit.isActive);
     this.ApprovalLimitDto.controls['fieldName'].setValue(this.approvalLimit.fieldName);
      this.fieldname=this.ApprovalLimitDto.get('fieldName').value;
      this.ApprovalLimitDto.controls['approvalLimitId'].setValue(this.approvalLimitId);
      this.isactive=this.ApprovalLimitDto.get('isActive').value;
    });
  }



  save() {
    var roleName = true;
    if (this.ApprovalLimitDto.valid) {

      if (this.ApprovalLimitDto.value.fieldName == "KnockForKnock") {
        for (let index = 0; index < this.ApprovalLimitDto.value.approvalLevel.length; index++) {
          if (this.ApprovalLimitDto.value.approvalLevel[index].roleId.includes("select-all")) {
            const roleIdArray = this.ApprovalLimitDto.value.approvalLevel[index].roleId.map(level => level.roleId);
            const selectedindex = roleIdArray.indexOf("select-all");
            this.ApprovalLimitDto.value.approvalLevel[index].roleId.splice(selectedindex, 1)
            for (let index = 0; index < this.companyMap.length; index++) {
              this.compIdList.push(this.companyMap[index].id);
            }
          }
          else {
            if (this.ApprovalLimitDto.value.approvalLevel[index].roleId != '') {
              this.compIdList = this.ApprovalLimitDto.value.approvalLevel[index].roleId;
              this.ApprovalLimitDto.value.approvalLevel[index].roleId = null;
              this.ApprovalLimitDto.value.approvalLevel[index].roleId = this.compIdList;
            } else {
              roleName = false;
            }

          }

        }
        if (roleName) {
          this.userservice.saveApprovalLimit(this.ApprovalLimitDto.value).subscribe((id) => {
            this.userservice.setAddNew(true);

            this.tosterservice.success(this.translate.instant("Toaster_Message.Saved"), "", {
              timeOut: 3000,

            });
            const obj = {
              listpage: true,
              addpage: false,
            }
            this.usermanageshowplayback.emit(obj);
            this.router.navigateByUrl('/usermanagement/approval-limit');
            this.clearFieldValue()
          });
        } else {
          this.tosterservice.error(this.translate.instant("Toaster_Message.Ins_company"));
        }
      }
      else {
        if (this.ApprovalLimitDto.valid) {
          this.compIdList = [];
          for (let index = 0; index < this.ApprovalLimitDto.value.approvalLevel.length; index++) {

            if (this.ApprovalLimitDto.value.approvalLevel[index].roleId[0]) {
              if (this.ApprovalLimitDto.value.approvalLevel[index].roleId[0] != '') {
                this.compIdList.push(this.ApprovalLimitDto.value.approvalLevel[index].roleId[0]);
                this.ApprovalLimitDto.value.approvalLevel[index].roleId = null;
                this.ApprovalLimitDto.value.approvalLevel[index].roleId = this.compIdList;
                this.compIdList = [];
              } else {
                roleName = false;
              }

            } else {
              if (this.ApprovalLimitDto.value.approvalLevel[index].roleId != '') {
                this.compIdList.push(this.ApprovalLimitDto.value.approvalLevel[index].roleId);
                this.ApprovalLimitDto.value.approvalLevel[index].roleId = null;
                this.ApprovalLimitDto.value.approvalLevel[index].roleId = this.compIdList;
                this.compIdList = [];
              } else {
                roleName = false;
              }
            }
          }
          if (roleName) {
            if (this.approvalLimit) {
              if (this.approvalLimit.fieldName == 'KnockForKnock') {
                this.ApprovalLimitDto.value.approvalLimitId = null;
              }
            }
            this.userservice.saveApprovalLimit(this.ApprovalLimitDto.value).subscribe((id) => {
              this.userservice.setAddNew(true);

              this.tosterservice.success(this.translate.instant("Toaster_Message.Saved"), "", {
                timeOut: 3000,
              });
              const obj = {
                listpage: true,
                addpage: false,
              }
              this.usermanageshowplayback.emit(obj);
              this.router.navigateByUrl('/usermanagement/approval-limit');
              this.clearFieldValue()
            }, (error: Response) => {
              this.errorHandler.getMessage(error);

            });
          } else {
            this.tosterservice.error(this.translate.instant("Toaster_Message.Role_name"));
          }
        }
      }
    } else {
      this.tosterservice.error(this.translate.instant("Toaster_Message.Fill_detail"));
    }

  }
  /**
   *  Save approval Limit After clear TheFieldValues
   */
  clearFieldValue(){
    this.ApprovalLimitDto.reset();
    (<FormArray>this.ApprovalLimitDto.get('approvalLevel')).clear();
    (<FormArray>this.ApprovalLimitDto.get('approvalLevel')).push(this.addNewRule())
    this.fieldname = "";
    this.ApprovalLimitDto.controls['isActive'].setValue(true);
    this.knockboolean = false;
  }

  setFormName(name, action) {
    this.ApprovalLimitDto.controls['fieldName'].setValue(name);
    this.selectfield = name;
    if (name == "KnockForKnock") {
      this.knockboolean = true;
      this.clearApprovalLevel();
      this.getCompanyList(action);
      if (name == this.approvalLimit.fieldName){
      if (action == 'ADD') {
        if(this.newApprovaleLimit === undefined){
        this.fetchApprovalLimitValue(true);
      }
      }
    }
    }
    else {
      this.knockboolean = false;
      if (name == this.approvalLimit.fieldName)
        if (action == 'ADD') {
          if(this.newApprovaleLimit === undefined){
            this.fetchApprovalLimitValue(true);
          }
        }
    }
  }
  private clearApprovalLevel() {
    (<FormArray>this.ApprovalLimitDto.get('approvalLevel')).clear();
    (<FormArray>this.ApprovalLimitDto.get('approvalLevel')).push(this.addNewRule());
  }

  isActive(event:any){
    this.ApprovalLimitDto.controls['isActive'].setValue(event.checked)
  }


  addNewRule():FormGroup{
    return this.fb.group({
      roleId:[''],
      minValue:['',[Validators.required]],
      maxValue:['',[Validators.required]],
      currency:['',Validators.required]
    })
  }
  /**
   *
   * @returns GET FORM GROUP CONTROLS
   */
  getApprovalLevel():any{
    return (<FormArray> this.ApprovalLimitDto.get('approvalLevel')).controls;
  }
  /**
   * ADD ROW INDEX METHOD
   */
  addField(){
    this.fieldListIndex = this.fieldListIndex+1;
    (<FormArray>this.ApprovalLimitDto.get('approvalLevel')).insert(this.fieldListIndex,this.addNewRule());
  }
  /**
   * REMOVE INDEX METHOD
   * @param i
   */
  removeField(i:number){
    if((<FormArray>this.ApprovalLimitDto.get('approvalLevel')).length>1){
      (<FormArray>this.ApprovalLimitDto.value.approvalLevel.splice(i,1));
      (<FormArray>this.ApprovalLimitDto.get('approvalLevel')).removeAt(i)
    }
  }
  /**
   * POPUP CLOSE
   */
  closePopup(){
    const obj={
      listpage:true,
      addpage:false,
    }
      this.usermanageshowplayback.emit(obj);
      this.router.navigateByUrl('/usermanagement/approval-limit');
  }
  /**
   * BACK BUTTON
   */
  backbtn(){
    this.clearFieldValue();
    const obj={
      listpage:true,
      addpage:false,
    }
      this.usermanageshowplayback.emit(obj);
      this.router.navigateByUrl('/usermanagement/approval-limit');
  }
  cancel(){
    this.clearFieldValue();
    const obj={
      listpage:true,
      addpage:false,
    }
      this.usermanageshowplayback.emit(obj);
      this.router.navigateByUrl('/usermanagement/approval-limit');
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.approvalLimitAddPrivillegeInfo && this.approvalLimitAddPrivillegeInfo.length > 0) {
      const privillege = this.approvalLimitAddPrivillegeInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege ? privillege.isEnabled : false;
    }
    return isEnabled;
  }
  getCompanyMap(index:any,array:any[]){
    let companymap:any[]=[];
    let tempCompanyList:any[]=[];
    
    // Pushing all the company names to it
    companymap.push(...this.companyMap);

    // create temp list with existing company ids map with currency
    for (let i=0;i<array.length;i++){
      if(index>i && array[i].controls.roleId.value){
      array[i].controls.roleId.value.forEach((x)=>{
        let ab:any={};
        ab.id = x;
        ab.currency = array[i].controls.currency.value
        tempCompanyList.push(ab);
      })
      }
    }
    
    // create temp list with existing role ids map with currency
    for (let i=0;i<array.length;i++){
      if(index>i && array[i].controls.roleId.value){
        let ab:any={};
        ab.id = array[i].controls.roleId.value
        ab.currency = array[i].controls.currency.value
        tempCompanyList.push(ab);    
      
      }
    }
    const filteredIds:any = [];
        // filtered role Ids which is having all currency types
      for (let j=0;j<tempCompanyList.length;j++){
        const roleList = tempCompanyList.filter(item => item.id === tempCompanyList[j].id);
        const mappedCurrencies = Array.from(new Set(roleList.map(item => item.currency)));
        if (this.currencyType.every(currency => mappedCurrencies.includes(currency))) {
          filteredIds.push(tempCompanyList[j].id);
        }
      }      

      companymap = companymap.filter(obj => !filteredIds.includes(obj.id))

    if(companymap.length == 0){
     this.selectAllOption = false;
    }
    companymap.sort((a, b) => a.name.localeCompare(b.name));
    return companymap;
  }

  getRoleList(index:any,array:any[]){
    
    let rolemap:any[]=[];
    let temprolelist:any[]=[];
    
    // Pushing all the roles to it
    rolemap.push(...this.RoleList);

    // create temp list with existing role ids map with currency
    for (let i=0;i<array.length;i++){
      if(index>i && array[i].controls.roleId.value){
        let ab:any={};
        ab.roleId = array[i].controls.roleId.value
        ab.currency = array[i].controls.currency.value
        temprolelist.push(ab);    
      
      }
    }
    const filteredIds:any = [];
        // filtered role Ids which is having all currency types
      for (let j=0;j<temprolelist.length;j++){
        const roleList = temprolelist.filter(item => item.roleId === temprolelist[j].roleId);
        const uniqueCurrencies = Array.from(new Set(roleList.map(item => item.currency)));
        const hasAllCurrencies = this.currencyType.every(currency => uniqueCurrencies.includes(currency));
        if (hasAllCurrencies) {
          filteredIds.push(temprolelist[j].roleId);
        }
      }
    rolemap = rolemap.filter(obj => !filteredIds.includes(obj.roleId))

    return rolemap;
  }

  toggleSelectAll(index: number) {
    const selectedOptions = this.ApprovalLimitDto.value.approvalLevel[index].roleId;

    if (selectedOptions.includes('select-all')) {
      // "Select All" option is selected
      const allCompanyIds = this.getCompanyMap(index, this.getApprovalLevel()).map(comp => comp.id);
      (this.ApprovalLimitDto.controls['approvalLevel'] as FormArray).at(index).get('roleId').setValue([...allCompanyIds, 'select-all']);
      // console.log(this.ApprovalLimitDto.controls['approvalLevel'].value);
      // this.ApprovalLimitDto.controls['approvalLevel']['roleId'].setValue([...allCompanyIds, 'select-all']);
    } else {
      // Other options are selected
      const remainingOptions = selectedOptions.filter(option => option !== 'select-all');
      (this.ApprovalLimitDto.controls['approvalLevel'] as FormArray).at(index).get('roleId').setValue([]);
      // console.log(this.ApprovalLimitDto.controls['approvalLevel'].value);
      // this.ApprovalLimitDto.controls['approvalLevel']['roleId'].setValue([...remainingOptions]);
    }

  }






}
export class companyrole{
  id:number;
  name:string;
}

