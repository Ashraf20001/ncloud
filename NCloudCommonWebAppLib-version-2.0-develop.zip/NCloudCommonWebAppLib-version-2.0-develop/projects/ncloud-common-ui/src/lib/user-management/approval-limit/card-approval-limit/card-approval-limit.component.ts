import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { UserListService } from '../../../service/user-list.service';
import { appConst } from '../../../const/app.const';
import { ApprovalLimitDto } from '../../../dto/approval-limit-dto';
import { PopupComponent } from '../../../common-components/popup/popup.component';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-card-approval-limit',
  templateUrl: './card-approval-limit.component.html',
  styleUrls: ['./card-approval-limit.component.scss']
})
export class CardApprovalLimitComponent implements OnInit {
/** Mock data Object */
userListData:ApprovalLimitDto[];
approvalLimitId:number;
dataNotFound=false;
  @Input() isApprovalLimitCardPageEnabled = true;
  @Input() approvalLimitCardPrivillegeInfo: any;
  @Output() userlistshowplayback = new EventEmitter<any>();
  minLength: number;
  maxLength: number;
  appConst = appConst;

  constructor(private userservice: UserListService, private route: Router,private dialog:MatDialog, private translate: TranslateService) { }

  ngOnInit() {
    this.getTotalCount();
  }

  getTotalCount(){
    this.userservice.getApprovalLimitCount().subscribe(((res:any)=>{
      this.minLength =0;
      this.maxLength = res;
      this.getApprovalList(this.minLength, this.maxLength);
    }));
  }

  getApprovalList(min:number,max:number){
    this.userservice.getApprovalLimitList(min,max).subscribe(data=>{
      this.userListData=data;
      if (this.userListData===null || this.userListData.length===0) {
        this.dataNotFound = true;
      }
     });
    }

    imageSectionList = [
      {
        image:"assets/reportloss/stage/Notification Stage.svg",
        title:"Insured Details"
      },
      {
        image:"assets/reportloss/stage/Notification Stage.svg",
        title:"Loss Details"
      },
      {
        image:"assets/reportloss/stage/Claim Inspection Stage.svg",
        title:"Survey Report"
      },
      {
        image:"assets/reportloss/stage/Liability Confirmation Stage.svg",
        title:"Recovery Details"
      },
      {
        image:"assets/reportloss/stage/Liability Confirmation Stage.svg",
        title:"Reserve Review"
      }
    ]

    getUrl(item: string): string {
      let src = '';
      if(item){
      const img = this.imageSectionList.find((img) => img.title === item);
      if(img) {
        src = img.image;
      }
    }
      return src;
  }
  deleteId(approvalLimitIdentity){  const dialogRef = this.dialog.open(PopupComponent, {
    width: 'auto',
    height:'auto',
        data: {
        message: this.translate.instant("DisablePopUp.deletepopup"),
         okButton: "Ok",
          cancelButton: "Cancel",
          name: "approvalLimit",
          delete:"approvalLimit"
        }
    });
    dialogRef.afterClosed().subscribe(result => {
     if (result) {

    this.userservice.DeleteApprovalimit(approvalLimitIdentity).subscribe(
      res=>{
          this.getApprovalList(this.minLength,this.maxLength);
      }
    );

     }
    });
    return false;
   }

  edit(approvalLimitIdentity){
    this.userservice.showCard(false);
    this.userservice.clone(false);
    this.userservice.sharedCompanyList=[]
   for(let i=0;i<this.userListData.length;i++){
    if(approvalLimitIdentity != this.userListData[i].approvalLimitIdentity ){
    for(let j =0 ;j<this.userListData[i].role.length;j++){
    this.userservice.sharedCompanyList.push(this.userListData[i].role[j]);
    }
  }
   }
    this.route.navigate(["/usermanagement/approval-limit/edit-approval-limit"],{ queryParams: {approvalLimitId : approvalLimitIdentity}});
  }

  cloneApprovalLimit(approvalLimitIdentity): void {
    this.userservice.showCard(false);
    this.userservice.clone(true);
    this.route.navigate(["/usermanagement/approval-limit/clone-approval-limit"],{ queryParams: {approvalId : approvalLimitIdentity}});
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = false;
    const privillegeInfo = this.approvalLimitCardPrivillegeInfo;
    if(privillegeInfo && privillegeInfo.length > 0) {
      const privillege = privillegeInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege ? privillege.isEnabled : false;
    }
    return isEnabled;
  }

}

