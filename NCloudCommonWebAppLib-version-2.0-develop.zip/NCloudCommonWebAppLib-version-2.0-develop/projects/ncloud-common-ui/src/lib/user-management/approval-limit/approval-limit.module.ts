import { TranslateModule } from '@ngx-translate/core';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BreadcrumbService } from 'xng-breadcrumb';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { CustomDirectiveModule } from '../../directive/directives/custom-directive.module';
import { CommaseperatorPipe } from '../../pipes/custom-pipe/commaseperator.pipe';
import { ApprovalLimitRoutingModule } from './approval-limit-routing.module';
import { AddApprovalLimitComponent } from './add-approval-limit/add-approval-limit.component';
import { ApprovalLimitComponent } from './approval-limit.component';
import { CardApprovalLimitComponent } from './card-approval-limit/card-approval-limit.component';
import { ManageApprovalLimitComponent } from './manage-approval-limit/manage-approval-limit.component';
import { DemoMaterialModule } from '../../common-components/angularMaterialModules/material-module';
import { AppCommonModule } from '../../common-components/app-common.module';
import { CamelCasePipe } from '../../pipes/custom-pipe/camel-case.pipe';
import { ErrorHandlerDirective } from '../../directive/directives/errorHandler.directive';

@NgModule({
  imports: [
    CommonModule,
    ApprovalLimitRoutingModule,
    TranslateModule,
    FormsModule,
    ReactiveFormsModule,
    CustomDirectiveModule,
    DemoMaterialModule,
    AppCommonModule
  ],
  declarations: [    
    AddApprovalLimitComponent,
    ManageApprovalLimitComponent,
    CardApprovalLimitComponent,
    ApprovalLimitComponent,
    CommaseperatorPipe,
    CamelCasePipe
  ],
  providers:[
    BreadcrumbService,
    ErrorHandlerDirective
  ]
})
export class ApprovalLimitModule { }
