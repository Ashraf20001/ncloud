import { AddApprovalLimitComponent } from './add-approval-limit/add-approval-limit.component';
import { ManageApprovalLimitComponent } from './manage-approval-limit/manage-approval-limit.component';
import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { ApprovalLimitComponent } from './approval-limit.component';



const routes: Routes = [
  {
    path: '',
    component: ApprovalLimitComponent,
    data: {
      breadcrumb: {
        label: 'bread_crump.approval_limit_list',
        info: 'Approval Limit List',
      },
    },
    children: [
      {
        path: 'add-approval-limit',
        component: AddApprovalLimitComponent,
        data: {
          breadcrumb: {
            label: 'bread_crump.add_approval_limit',
            info: 'Add Approval Limit',
          },
        }
      },

      {

        path: 'edit-approval-limit',

        component: ManageApprovalLimitComponent,

        data: {

          breadcrumb: {

            label: 'bread_crump.edit_approval_limit',

            info: 'Edit Approval Limit',

            skipParent: true

          },

        }

      },

      {

        path: 'clone-approval-limit',

        component: ManageApprovalLimitComponent,

        data: {

          breadcrumb: {

            label: 'bread_crump.clone_approval_limit',

            info: 'Clone Approval Limit',

            skipParent: true

          },

        }
      }
    ]
  }

]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class ApprovalLimitRoutingModule { }
