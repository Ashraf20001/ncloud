import { AfterViewInit, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { BreadcrumbService } from 'xng-breadcrumb';
import { I18nServiceService } from '../../../service/i18n-service.service';
import { ApprovalLimitDto } from '../../../dto/approval-limit-dto';
import { appConst } from '../../../const/app.const';
import { UserListService } from '../../../service/user-list.service';
import { PopupComponent } from '../../../common-components/popup/popup.component';
import { debounceTime, Subject } from 'rxjs';

@Component({
  selector: 'app-manage-approval-limit',
  templateUrl: './manage-approval-limit.component.html',
  styleUrls: ['./manage-approval-limit.component.scss']
})
export class ManageApprovalLimitComponent implements OnInit,AfterViewInit {
  @Input() userlistshow:any;
  @Input() isApprovalLimitListPageEnabled = true;
  @Input() isApprovalLimitCardPageEnabled = true;
  @Input() approvalLimitCardPrivillegeInfo: any;
  @Input() approvalLimitListPrivillegeInfo: any;
  @Output() userlistshowplayback = new EventEmitter<any>();
  show :boolean=false;
  showAddUser=true;
  addScreen:boolean;
  userId: any;
  currentLang = 'English';
  approvalLimitData:ApprovalLimitDto;
  ZERO=0;
  TEN=10;
  showtabledata:ApprovalLimitDto[];
  pageCount: number;
  dataNotFound=false;

  appConst = appConst;
  tableList: any;
  minLength: number;
  maxLength: number;
  totalLength: any;
  endingIndex: number=10;
  customPageIndex: number = 0;
  currentPageIndex: number;
  pageIndex=1;
  pageChangedEvent = new Subject<number>();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor(private service:UserListService, private router:Router, public i18Service:I18nServiceService,private dialog:MatDialog,
    public translate: TranslateService,private breadcrumbService:BreadcrumbService,private paginatorName: MatPaginatorIntl,
    private detector: ChangeDetectorRef,private toaster:ToastrService){
      this.breadcrumbService.set('usermanagement', { skip: true });
      this.breadcrumbService.set('user-role', { skip: true });
      this.translateLabels();
      this.service.ClickAdd$.subscribe((value)=>{
        if(value===true){
          this.getTableList(this.ZERO,this.TEN);
        }
      })
      if(this.paginatorName) {
        this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
      }
      if(sessionStorage?.getItem('ApprovalLimitTableIsEnabled')){
        this.show = sessionStorage.getItem('ApprovalLimitTableIsEnabled') === "true";
      }
  }

  ngOnInit() {
    this.getTotalCount();
    this.translate.onLangChange.subscribe(() => {
      this.translateLabels();
    });
    this.pageChangedEvent.pipe(debounceTime(300)).subscribe((data: number) => {
      this.changePageIndex();
    });
  }
  displayedColumns: string[] = ['Field Name', 'Stage and Section', 'User Roles', 'Approval Levels' ,'Status','Clone','Edit','Delete'];
  dataSource = new MatTableDataSource<ApprovalLimitDto>();


  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    if(this.paginatorName) {
        this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
      }
  }

  shoeCardorList(){
    this.show=!this.show;
    sessionStorage.setItem('ApprovalLimitTableIsEnabled',JSON.stringify(this.show));
    this.service.setAddNew(true);
  }

  goBack(){
    this.show=!this.show;
    sessionStorage.setItem('ApprovalLimitTableIsEnabled',JSON.stringify(this.show));
    this.service.setAddNew(true);
  }

  getTotalCount(){
    this.service.getApprovalLimitCount().subscribe(((res:any)=>{
      this.minLength =0;
      this.maxLength = 10;
      this.totalLength = res;
      this.getTableList(this.minLength, this.maxLength);
    }));
  }

  getTableList(min:number,max:number){
      this.service.getApprovalLimitList(min,max).subscribe(data=>{
      const limitData=data;
      if (limitData===null || limitData.length===0) {
        if(limitData.length >= 9){
          this.dataNotFound = true;
        }
      }else{
        this.dataNotFound=false;
      }

      this.showtabledata=[];
      for(const res of limitData){
        this.getEmptyApprovalLimitList();
        this.approvalLimitData.approvalLimitId=res.approvalLimitId;
        this.approvalLimitData.fieldName=res.fieldName;
        this.approvalLimitData.approvalLevel=res.approvalLevel;
        this.approvalLimitData.role=res.role;
        this.approvalLimitData.stageName=res.stageName;
        this.approvalLimitData.sectionName=res.sectionName;
        this.approvalLimitData.isActive=res.isActive?'Active':'Inactive';
        this.approvalLimitData.approvalLimitIdentity =res.approvalLimitIdentity;
        this.showtabledata.push(this.approvalLimitData);
      }
      this.dataSource = new MatTableDataSource<ApprovalLimitDto>(this.showtabledata);
      if (this.showtabledata.length != 0) {
        this.dataNotFound = false;
      } else {
        this.dataNotFound = true;
      }

    })
  }

  getEmptyApprovalLimitList(){
    this.approvalLimitData= {
      approvalLimitId:null,
      fieldName:"",
      approvalLevel:[],
      isActive:"",
      stageName:"",
      role:[],
      sectionName:"",
      approvalLimitIdentity:""
    }
  }

  changePage(event){
    if(event.pageIndex > event.previousPageIndex ){
      //previous
      this.customPageIndex = event.pageIndex+1;
    }else{
     // next
     this.customPageIndex =  this.customPageIndex-1;
    }
    if(event.pageIndex != this.ZERO){
      this.maxLength= event.pageSize;
      this.minLength = event.pageSize *event.pageIndex;
      this.endingIndex = event.pageSize;
      this.pageIndex = this.customPageIndex;
    }else{
      this.maxLength= event.pageSize;
      this.minLength = event.pageIndex;
      this.endingIndex = event.pageSize;
      this.pageIndex = this.customPageIndex+1;
    }
    this.getTableList(this.minLength,this.maxLength);
  }

  pageindex(): void {
    this.pageChangedEvent.next(this.pageIndex);
  }

  changePageIndex(): void {
    if(this.pageIndex > 0) {
      const totalPageIndex = this.totalLength / this.endingIndex + 1;
      if(this.pageIndex > totalPageIndex) {
        this.pageIndex = this.customPageIndex === 0 ? 1 : this.customPageIndex;
        return;
      }
      this.customPageIndex = this.pageIndex;
      this.currentPageIndex = this.pageIndex-1;
      this.maxLength= this.endingIndex;
      this.minLength = this.endingIndex *this.currentPageIndex;
      this.getTableList(this.minLength,this.maxLength);
    }
  }

  onKeyDown(event: KeyboardEvent) {
    if (event.keyCode === 190) {
      event.preventDefault();
    }
  }

  addNewUser(){
    const obj={
      listpage:false,
      addpage:true
    }
    this.userlistshowplayback.emit(obj);
    this.router.navigate(["/usermanagement/approval-limit/add-approval-limit"],{ queryParams: {newApprovaleLimit : true }});
  }

  backbtn(){
    const obj={
      listpage:true,
      addpage:false
    }
    this.userlistshowplayback.emit(obj);
    this.router.navigateByUrl('/usermanagement/approval-limit/approval-list');
  }

  imageSectionList = [
    {
      image:"assets/reportloss/stage/Notification Stage.svg",
      title:"Insured Details"
    },
    {
      image:"assets/reportloss/stage/Notification Stage.svg",
      title:"Loss Details"
    },
    {
      image:"assets/reportloss/stage/Claim Inspection Stage.svg",
      title:"Survey Report"
    },
    {
      image:"assets/reportloss/stage/Liability Confirmation Stage.svg",
      title:"Recovery Details"
    },
    {
      image:"assets/reportloss/stage/Liability Confirmation Stage.svg",
      title:"Reserve Review"
    }
  ]

  getUrl(item: string): string {
    let src = '';
    if(item){
    const img = this.imageSectionList.find((img) => img.title === item);
    if(img) {
      src = img.image;
    }
  }
    return src;
}
  Edit(approvalLimitIdentity){
    this.service.showCard(false);
    this.service.clone(false);
    this.router.navigate(["/usermanagement/approval-limit/add-approval-limit"],{ queryParams: {approvalLimitId : approvalLimitIdentity}});
  }
  Delete(approvalLimitIdentity){
  const dialogRef = this.dialog.open(PopupComponent, {
      width: 'auto',
      height:'auto',
          data: {
          message: this.translate.instant("DisablePopUp.deletepopup"),
           okButton: "Ok",
            cancelButton: "Cancel",
            name: "approvalLimit",
            delete:"approvalLimit"
          }
      });
      dialogRef.afterClosed().subscribe(result => {
       if (result) {

      this.service.DeleteApprovalimit(approvalLimitIdentity).subscribe(res =>{
        this.getTotalCount();
      });

       }
      });
  }
  Clone(approvalLimitIdentity){
    this.service.showCard(false);
    this.service.clone(true);
    this.router.navigate(["/usermanagement/approval-limit/clone-approval-limit"],{ queryParams: {approvalId : approvalLimitIdentity}});
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    const privillegeInfo = this.show ? this.approvalLimitListPrivillegeInfo : this.approvalLimitCardPrivillegeInfo;
    if(privillegeInfo && privillegeInfo.length > 0) {
      const privillege = privillegeInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege ? privillege.isEnabled : false;
    }
    return isEnabled;
  }
  /*
  * DownloadApprovalLimitList
  */
  downloadApprovalLimitList(){
    this.service.downloadApprovalLimitListExcelList().subscribe((response)=>{
      if (response) {
        const blob = new Blob([response],
          { type: 'application/vnd.ms-excel' });
        const file = new File([blob], 'ApprovalLimit_List.xlsx',
          { type: 'application/vnd.ms-excel' });
        const fileURL = URL.createObjectURL(file);
        const a         = document.createElement('a');
        a.href        = fileURL;
        a.target      = '_blank';
        a.download    = "ApprovalLimit_List"+'.xlsx';
        document.body.appendChild(a);
        a.click();
        this.toaster.success(this.translate.instant("Toaster_Message.Approval_list"));
      }
    })
  }

  translateLabels() {
    if (this.paginatorName) {
      this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
      this.paginatorName.firstPageLabel = this.translate.instant('Paginator.FirstPage');
      this.paginatorName.lastPageLabel = this.translate.instant('Paginator.LastPage');
      this.paginatorName.nextPageLabel = this.translate.instant('Paginator.NextPage');
      this.paginatorName.previousPageLabel = this.translate.instant('Paginator.PreviousPage');
    }
    if (this.paginator) {
      this.paginator._intl.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
      this.paginator._changePageSize(this.paginator.pageSize);
      this.detector.detectChanges();
    }
  }

   /*
  * ngOnDestroy
  */
   ngOnDestroy(): void {
    sessionStorage.removeItem('ApprovalLimitTableIsEnabled');
  }
}

