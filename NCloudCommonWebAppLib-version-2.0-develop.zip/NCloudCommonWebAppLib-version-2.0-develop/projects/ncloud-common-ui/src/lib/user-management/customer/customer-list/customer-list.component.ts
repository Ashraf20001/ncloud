import { AfterViewInit, ChangeDetectorRef, Component, EventEmitter, Input, OnDestroy, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Subject, Subscription, debounceTime } from 'rxjs';

import { FilterObject } from '../../../dto/Filter-dto/filter-object';
import { FilterOrSortingVo } from '../../../dto/Filter-dto/filter-object-backend';
import { FilterOrSortingFilter } from '../../../dto/filter-or-sorting';
import { AccessMappingSectionDto } from '../../../dto/Filter-dto/section-dto';
import { AuthorityPaperService } from '../../../service/authority-paper.service';

import { PaperService } from '../../../service/paper-service.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.scss']
})
export class CustomerListComponent implements OnInit,AfterViewInit,OnDestroy{

  @Input() isDownloded: boolean;
  @Input() customerListPageAccessFromParent:AccessMappingSectionDto;
  @Output() isDownloadDisableValueEmit= new EventEmitter<boolean>();
  @Input() searchvalue:string;

  filterVoObject: FilterOrSortingVo[]=[];
  Insurer_Name = false;
  Email_ID = false;
  Phone_Number = false;
  Added_Date = false;
  Status = false;
  customerDataList :customerData[]=[];
  displayedColumns: string[] = ['Insurer Name', 'Email ID', 'Phone Number', 'Added Date', 'Status', 'Edit'];
  isShowPageIndex=false;
  pageIndex = 1;
  totalLength: number;
  dataSource = new MatTableDataSource<customerData>();
  endingIndex=10;
  Purchase_ID = false;
  pagesize: number;
  remainder: number;
  isNoDataFound=false;
  private searchSubject = new Subject<number>();
  maximumCount: number;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  rowPerPageSubscription: Subscription;
  constructor(private paginatorName: MatPaginatorIntl,private translate: TranslateService,
    private detector: ChangeDetectorRef, private paperService: PaperService,private authorityPaperService:AuthorityPaperService) {
      if(this.paginatorName) {
        this.rowPerPageSubscription=this.translate.get('Paginator.ItemsPerPageLabel').subscribe((translation: string) => {
          this.paginatorName.itemsPerPageLabel = translation;
        });
  
      }


    
  this.searchSubject .pipe(debounceTime(300)).subscribe((pageIndex: number) => {
    this.changePageIndex();
  });
  }
  ngOnDestroy(): void {
    this.rowPerPageSubscription.unsubscribe();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['searchvalue'].currentValue!== undefined) {
      this.getCustomerCount(this.filterVoObject);
    }

  }
  ngAfterViewInit(): void {

    if(this.paginatorName) {
     this.rowPerPageSubscription= this.translate.get('Paginator.ItemsPerPageLabel').subscribe((translation: string) => {
        this.paginatorName.itemsPerPageLabel = translation;
      });

    }
  }

  ngOnInit(): void {
   this.getCustomerCount(this.filterVoObject);
  this.authorityPaperService.emitFilterVoObject.subscribe(value => {
    if (value) {
      this.filterVoObject = value;

      this.filterVoObject.forEach((filter)=>{
        if(filter.columnName==='createdDate'){
          if(!filter.value2){
            filter.condition='Ge'
          }
          else if(!filter.value){
            filter.value=filter.value2;
            filter.value2=null;
            filter.condition='Le'
          }
        }
    });

      this.passingFilterVo(this.filterVoObject);
    }
  });
  this.authorityPaperService.passFilterObject(this.filterObjectArray);
  this.translate.onLangChange.subscribe(() => {
    if (this.paginator) {
      this.paginator._intl.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
      this.paginator._intl.firstPageLabel=this.translate.instant('Paginator.FirstPage');
      this.paginator._intl.lastPageLabel=this.translate.instant('Paginator.LastPage');
      this.paginator._intl.nextPageLabel=this.translate.instant('Paginator.NextPage');
      this.paginator._intl.previousPageLabel=this.translate.instant('Paginator.PreviousPage');
      this.paginator._changePageSize(this.paginator.pageSize);
      this.detector.detectChanges();
    }
  });
  if(this.paginatorName) {
    this.rowPerPageSubscription=this.translate.get('Paginator.ItemsPerPageLabel').subscribe((translation: string) => {
      this.paginatorName.itemsPerPageLabel = translation;
    });

  }
  }

  passingFilterVo(filterData: FilterOrSortingFilter[]) {
    this.columnAndIDSettingMethod(filterData);
    this.getCustomerCount(filterData);
  }

  columnAndIDSettingMethod(filterData: FilterOrSortingFilter[]) {
    if (filterData != null && filterData != undefined) {
      const filterFromSearch: FilterOrSortingVo[] = filterData;
      for (const vo of filterFromSearch) {
        let type;
         // eslint-disable-next-line prefer-const
         type = this.idFindingMethod(vo.columnName)
        vo.type=type;

      }
      this.filterVoObject = filterFromSearch;
      this.getCustomerCount(this.filterVoObject);
    }
  }

  idFindingMethod(value: string): number {
    let type;
    if (value) {
      const data = this.sortingEntityArray.find((element) => element.entityColumnName === value);
      if(data) {
        type = data.type;
      }

    }
    return type;
  }
  getCustomerCount(filterVo: FilterOrSortingVo[]){

    if(this.customerListPageAccessFromParent.isView===false){
      return;
    }
    this.pageIndex=1;
    this.paperService.getCustomerCount(filterVo,this.searchvalue).subscribe((data:any)=>{
      this.totalLength = data.content;
      if( this.totalLength === 0 || this.totalLength === undefined){
        this.isShowPageIndex=true;
        this.isNoDataFound=true;
          this.isDownloadDisableValueEmit.emit(true);
       }else{
        this.isShowPageIndex=false;
        this.isNoDataFound=false;
        this.isDownloadDisableValueEmit.emit(false);
       }
      const totalNUmber = this.totalLength / 10;
      if (this.isFloat(totalNUmber)) {
        this.maximumCount =  Math.floor(totalNUmber+1);
      }else{
        this.maximumCount = totalNUmber;
      }
      this.maximum = 10;
      this.minimum = 0;
      this.getcustomerData(this.minimum,this.maximum,this.searchvalue,filterVo);
    });
  }

  isFloat(n: number): boolean {
    return Number(n) === n && n % 1 !== 0;
  }

  getcustomerData(minimum: number, maximum: number,searchValue:string, filterVo: FilterOrSortingVo[]) {
    this.paperService.getAllCustomerData(minimum,maximum,this.searchvalue, filterVo).subscribe((data:any)=>{
      this.customerDataList = [];
      this.customerDataList = data.content;
      if( this.customerDataList === null || this.customerDataList === undefined || this.customerDataList.length===0){
        this.isShowPageIndex=true;
          this.isDownloadDisableValueEmit.emit(true);
          this.isNoDataFound=true;
       }
       else{
        this.isShowPageIndex=false;
        this.isNoDataFound=false;
       }
      this.dataSource = new MatTableDataSource<customerData>(this.customerDataList);
    })
  }
  changePage(event) {

    if(event.pageIndex != 0){
      this.pageIndex = event.pageIndex +1;
      this.maximum= event.pageSize;
      this.minimum = event.pageSize *event.pageIndex;
      this.endingIndex = event.pageSize;
      // if(this.pagesize !=  event.pageSize){
      // this.maximumcount(event.pageSize);

      // }
    }else{
      this.pageIndex=1;
      this.maximum= event.pageSize;
      this.minimum = event.pageIndex;
      this.endingIndex = event.pageSize;
      // if(this.pagesize !=  event.pageSize){
      // this.maximumcount(event.pageSize);

      // }
    }
    this.getcustomerData(this.minimum,this.maximum,this.searchvalue,this.filterVoObject);
  }

  maximumcount(event){
    this.pagesize = event;
    this.maximumCount = this.totalLength/this.pagesize
    this.remainder = this.totalLength%this.pagesize;
    if(this.remainder != 0){
      this.maximumCount =  Math.floor(this.maximum + 1);
    }

  }

  pageindex() {
    this.searchSubject.next(this.pageIndex);
  }

  changePageIndex(){
    if(this.pageIndex > 0) {
      if(this.pageIndex > this.maximumCount) {
        const numbDigit = this.maximumCount.toString().length;
        let numString =this.pageIndex.toString();
        numString = numString.substring(0, numbDigit);
        if(Number(numString) >= this.maximumCount ){
          numString = this.maximumCount.toString();
        }
        this.pageIndex = this.maximumCount === 0 ? 1 : Number(numString);
      }
      this.maximum = this.endingIndex;
      this.minimum = this.endingIndex * (this.pageIndex - 1);
      this.getcustomerData(this.minimum, this.maximum,this.searchvalue,this.filterVoObject);
      // if(!this.pageIndex){
      // }else{
      //   this.getcustomerData(this.minimum, this.maximum,this.searchvalue,this.filterVoObject);
      // }
    }else{
      // this.pageIndex = 1;
      this.minimum = 0;
      this.maximum = 10;
      this.getcustomerData(this.minimum, this.maximum,this.searchvalue,this.filterVoObject);
    }
  }
  onKeyDown(event: KeyboardEvent) {
    if (event.keyCode === 190) {
      event.preventDefault();
    }
  }

  maximum =10;
  minimum=0;

  @Output() ListToEDit = new EventEmitter<boolean>();

  editCustomer(data:any) {
    this.ListToEDit.emit(data);
  }

  filterObjectArray: FilterObject[]=[
    {
      columnName: 'pdInsuredName',
      condition: 'Like',
      aliasName: 'Customer_table.insurer_name',
      type: 'field',
      value: [],
      dropdown: [],
      radio: [],
      dataType: null
    },
    {
      columnName: 'customer.email',
      condition: 'Like',
      aliasName: 'Customer_table.email_id',
      type: 'field',
      value: [],
      dropdown: [],
      radio: [],
      dataType: null
    },
    {
      columnName: 'customer.phoneNumber',
      condition: 'Like',
      aliasName: 'Customer_table.phone_number',
      type: 'field',
      value: [],
      dropdown: [],
      radio: [],
      dataType: null
    },
    {
      columnName:'createdDate',
      condition:'BW',
      aliasName: 'Customer_table.added_date',
      type: 'dates',
      value: [],
      dropdown: [],
      radio: [],
      dataType:null
    },
    {
      columnName: 'customer.status',
      condition: 'Equal',
      aliasName: 'Customer_table.status',
      type: 'radio',
      value: [],
      dropdown: [],
      radio: [
        {
          name: 'Customer_table.Active',
          value: false,
        },
        {
          name: 'Customer_table.InActive',
          value: false,
        },
      ],
      dataType:"Boolean"
    }
  ];

  // sorting filter vo
  sortingFilterVo: FilterOrSortingVo = {
    columnName: "",
    condition: "",
    filterOrSortingType: "SORTING",
    intgerValueList: [],
    valueList: [],
    isAscending: false,
    type: "",
    value: "",
    value2: "",
  }

  sortingEntityArray = [{
    tableColumnName: "Insurer Name",
    entityColumnName: "pdInsuredName",
    type: "String"
  },
  {
    tableColumnName: "Email ID",
    entityColumnName: "customer.email",
    type: "String"
  },

  {
    tableColumnName: "Phone Number",
    entityColumnName: "customer.phoneNumber",
    type: "String"
  },
  {
    tableColumnName: "Added Date",
    entityColumnName: "createdDate",
    type: "Date"
  },

  {
    tableColumnName: "Status",
    entityColumnName: "customer.status",
    type: "Boolean"
  }
]
isAscending = false;

shortingmethod(data: any) {
  const value=data;


  if (value === "Insurer Name") {
    this.Insurer_Name =!this.Insurer_Name;
    this.Email_ID = false;
    this.Phone_Number = false;
    this.Added_Date = false;
    this.Status=false;
  }
  else if(value === "Email ID"){
    this.Insurer_Name=false;
    this.Email_ID =  !this.Email_ID;
    this.Phone_Number = false;
    this.Added_Date = false;
    this.Status=false;

  }
  else if(value === "Phone Number"){
    this.Insurer_Name=false;
    this.Email_ID = false;
    this.Phone_Number = !this.Phone_Number;
    this.Added_Date = false;
    this.Status=false;
  }
  else if(value === "Status"){
    this.Insurer_Name=false;
    this.Email_ID = false;
    this.Phone_Number = false;
    this.Added_Date = false;
    this.Status=!this.Status;
  }
  else if(value === "Added Date"){
    this.Insurer_Name=false;
    this.Email_ID = false;
    this.Phone_Number = false;
    this.Added_Date = !this.Added_Date;
    this.Status=false;
  }
  this.displayedColumns.forEach(element => {
    if (element === value) {
      this.isAscending = !this.isAscending;
      if (this.isAscending) {
        const columnName = this.getEntityColumnName(value);
        this.setSortingVO(columnName, this.isAscending);
        this.getcustomerData(this.minimum, this.maximum,this.searchvalue,this.filterVoObject);
      } else {
        const columnName = this.getEntityColumnName(value);
        this.setSortingVO(columnName, this.isAscending);
        this.getcustomerData(this.minimum, this.maximum,this.searchvalue,this.filterVoObject);
      }
    }
  });
}

setSortingVO(value: string, condition: boolean) {

  const sortArray: FilterOrSortingVo[] = [];
  if (value != null && condition != null) {
    this.sortingFilterVo.columnName = value;
    this.sortingFilterVo.isAscending = condition;
    this.filterVoObject = [];
    this.filterVoObject.push(this.sortingFilterVo);
  }

}

getEntityColumnName(item: string): string {
  let value = ''; if (item) {
    const data = this.sortingEntityArray.find((column) => column.tableColumnName === item);
    if (data) {
      value = data.entityColumnName;
    }
  }
  return value;
}


}
export class customerData {
  username: string;
  email: string;
  password: string;
  identity: string;
  phoneNumber: number;
  addedDate: string;
  status: boolean;

}

