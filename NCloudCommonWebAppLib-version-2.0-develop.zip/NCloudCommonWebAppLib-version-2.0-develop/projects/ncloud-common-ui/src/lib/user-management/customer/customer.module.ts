
import { CustomDirectiveModule } from '../../directive/directives/custom-directive.module';

import { DemoMaterialModule } from '../../common-components/angularMaterialModules/material-module';
import { BreadcrumbService } from 'xng-breadcrumb';
import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {  TranslateModule } from '@ngx-translate/core';

import {CdkAccordionModule} from '@angular/cdk/accordion';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatTabsModule} from '@angular/material/tabs';
import {MatSelectModule} from '@angular/material/select';
import {MatTooltipModule} from '@angular/material/tooltip';

import { CustomerRoutingModule } from './customer-routing.module';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { EditCustomerComponent } from './edit-customer/edit-customer.component';
import { AppCommonModule } from "../../common-components/app-common.module";
import { CustomerComponent } from './customer.component';

@NgModule({
    declarations: [
        CustomerComponent,
        
        CustomerListComponent,
        EditCustomerComponent
    ],
    exports: [
        CustomerComponent
    ],
    providers: [
        BreadcrumbService,
    ],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        CustomerRoutingModule,
        TranslateModule,
        DemoMaterialModule,
        CdkAccordionModule, MatSlideToggleModule, MatTabsModule, MatSelectModule, MatTooltipModule, CustomDirectiveModule,
        AppCommonModule
    ]
})

export class CustomerModule{
}
