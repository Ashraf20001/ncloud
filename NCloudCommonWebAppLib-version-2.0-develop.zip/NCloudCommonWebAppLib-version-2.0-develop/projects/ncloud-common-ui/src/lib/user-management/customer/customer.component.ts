import { Component, OnInit } from '@angular/core';

import { MenuSectionNames } from '../../const/enum';

import { FilterObject } from '../../dto/Filter-dto/filter-object';
import { FilterOrSortingVo ,DownloadVo} from '../../dto/Filter-dto/filter-object-backend';
import { CompanyTransaction } from '../../dto/transaction-dto';

import { FileTypeEnum } from '../../dto/FileTypeEnum';
import { AccessMappingSectionDto } from '../../dto/Filter-dto/section-dto';
import { AccessMappingPageDto } from '../../dto/access-Mapping-PageDto ';
import { appConst } from '../../const/app.const';
import { AuthorityPaperService } from '../../service/authority-paper.service';
import { PaperService } from '../../service/paper-service.service';
import { AppService } from '../../service/app.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss']
})
export class CustomerComponent implements OnInit{
  dataLoaded: boolean;

  constructor(private authorityPaperDetailsService:AuthorityPaperService, private paperService: PaperService, private appService:AppService){}
  
  isDownloaded = false;
  showList = true;
  editcustomer = false;
  searchdisable=false;
  editData:any;
  excelDownloadVo = new CompanyTransaction();
  filterObjectArray:FilterObject[];
  filterVoObject: FilterOrSortingVo[];
  searchData="";
  isDownloadDisable=false;
  customerPageAccessDto: AccessMappingPageDto;
  customerListPageAccessDto: AccessMappingSectionDto;

  ngOnInit(): void {
      this.getPageAccess();
  }

  getPageAccess() {
    this.appService.getPageAccess(appConst.PAGE_NAME.CUSTOMER.PAGE_IDENTITY).subscribe(response=>{
      if (response) {
        this.customerListPageAccessDto = response['content'];
        this.customerListPageAccessDto.sectionData=this.getEnabledPrivilegeFromMultipleRoles(this.customerListPageAccessDto?.sectionData);
        this.customerListPageAccessDto = this.customerListPageAccessDto?.sectionData.find(x => x.sectionName===MenuSectionNames.Customer);
        this.dataLoaded=true;
      }
    })
  }


  customerList(data: any) {
    this.editData = data;
    this.showList = false;
    this.editcustomer = true;

  }
  search(event){
    this.searchData = event;
  }

  Download(){
    this.isDownloaded = !this.isDownloaded;
    const Columns= ['Insurer Name', 'Email Id', 'Phone Number', 'Added Date', 'Status', 'Edit'];
    this.excelDownloadVo.selectedColumn = Columns;
    this.excelDownloadVo.filter = this.filterVoObject; 
    this.paperService.customExcelDownload(this.excelDownloadVo,this.searchData).subscribe((data)=>{
      this.donwloadFile(data)
    })
  }

   donwloadFile(value: any) {
    const blob = new Blob([value], { type: 'application/vnd.ms-excel' });
    const file = new File([blob], 'report.xlsx', {
      type: 'application/vnd.ms-excel',
    });
    const fileURL = URL.createObjectURL(file);
    const a = document.createElement('a');
    a.href = fileURL;
    a.target = '_blank';
    a.download = 'Customer-list' + '.xlsx';
    document.body.appendChild(a);
    a.click();
  }
  customer(data: any) {
    this.showList = true;
    this.editcustomer = false;
  }

  emitFilterValue(event: any) {
    this.searchData="";
    this.filterVoObject = event;
      this.authorityPaperDetailsService.passFilterVoObject(this.filterVoObject);

  }

  getDisableDownloadEmitValue(event:any){
    this.isDownloadDisable=event;
  }

  getEnabledPrivilegeFromMultipleRoles(sectionDataArray:AccessMappingSectionDto[]):AccessMappingSectionDto[]{
    const result: AccessMappingSectionDto[] = Object.values(
      sectionDataArray.reduce((accumulator, obj) => {
        let accessMappingAccumulator:AccessMappingSectionDto= null;
        if (!accumulator[obj.sectionName]) {
          accumulator[obj.sectionName] = obj;
        }
        accessMappingAccumulator=accumulator[obj.sectionName];
        if(obj.isView){          
          accessMappingAccumulator.isView=obj.isView;
        }
        if(obj.isClone){
          accessMappingAccumulator.isClone=obj.isClone;
        }
        if(obj.isDisable){
          accessMappingAccumulator.isClone=obj.isDisable;
        }
        if(obj.isDownload){
          accessMappingAccumulator.isDownload=obj.isDownload;
        }
        if(obj.isEdit){
          accessMappingAccumulator.isEdit=obj.isEdit;
        }
        if(obj.isNotification){
          accessMappingAccumulator.isNotification=obj.isNotification;
        }
        accumulator[obj.sectionName]=accessMappingAccumulator;
        return accumulator;
      }, {} as Record<string, AccessMappingSectionDto>)
    );
    
    return result
  }

}
