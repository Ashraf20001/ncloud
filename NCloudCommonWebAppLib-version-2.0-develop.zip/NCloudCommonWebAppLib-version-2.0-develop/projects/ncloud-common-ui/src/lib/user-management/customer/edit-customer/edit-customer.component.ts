import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { customerData } from '../customer-list/customer-list.component';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { PaperService } from '../../../service/paper-service.service';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-edit-customer',
  templateUrl: './edit-customer.component.html',
  styleUrls: ['./edit-customer.component.scss']
})
export class EditCustomerComponent implements OnChanges{

  @Output() backTOCustomer = new EventEmitter<boolean>();
  @Input() editDataList: customerData;
  updatData= new customerData();
  isShowSaveButton=false;
  customerFormData: FormGroup;
  constructor(private formBuilder: FormBuilder,private paperService: PaperService, private toster:ToastrService,private translate:TranslateService){
    this.customerFormData = this.formBuilder.group({

      insurerCompany: [{ value: '', disabled: true }, [Validators.required]],
      isActive: [[Validators.required]],
      emailId: [{ value: '', disabled: true }, [Validators.required]],
      phoneNumber: [{ value: '', disabled: true }, [Validators.required]],
      addedDate: [{ value: '', disabled: true }, [Validators.required]]
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['editDataList'].currentValue!== undefined && changes['editDataList'].currentValue !=="") {
     this.updatData.identity = this.editDataList.identity;
      this.customerFormData.controls["insurerCompany"].setValue(this.editDataList.username);
      this.customerFormData.controls["isActive"].setValue(this.editDataList.status);
      this.customerFormData.controls["emailId"].setValue(this.editDataList.email );
      this.customerFormData.controls["phoneNumber"].setValue(this.editDataList.phoneNumber);
      if(this.editDataList.addedDate != null){
      const dateParts = this.editDataList.addedDate.split('T');
      this.customerFormData.controls["addedDate"].setValue(dateParts[0]);
    }
    }
  }


  backCustomer() {
    this.backTOCustomer.emit();
  }

  updateCustomer(){
    if(this.customerFormData.valid){
     
      this.updatData.email = this.customerFormData.get('emailId').value;
      this.updatData.addedDate = this.customerFormData.get('addedDate').value;
      this.updatData.phoneNumber = this.customerFormData.get('phoneNumber').value;
      this.updatData.status = this.customerFormData.get('isActive').value;
      this.updatData.username =  this.customerFormData.get('insurerCompany').value;

      this.isShowSaveButton =true;
      this.paperService.updateCustomerData(this.updatData).subscribe((data)=>{
        this.toster.success(this.translate.instant('Toaster_success.update'))
        this.backTOCustomer.emit();
      })
    }
}

email(){
  this.isShowSaveButton =false;
}

}
