import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { UserManagementComponent } from "./user-management.component";
const routes : Routes =  [
  {
    path: '', component: UserManagementComponent,
    data: { breadcrumb: { skip: true } },
    children : [
      {
        path : 'user-role',
        loadChildren: ()=> import('./user-role/user-role.module').then(m=> m.UserRoleModule),
        data: {
                    breadcrumb: {
                      label: 'User Role List',
                       info: 'User Role List'
                    },
              }
      },
      {
        path:'user',
        loadChildren: ()=> import('./user/user.module').then(m=> m.UserModule)
      },
      {
        path:'allocation-pool',
        loadChildren: ()=> import('./allocation-pool/allocation-pool.module').then(m=> m.AllocationPoolModule)

      },
      {
        path:'approval-limit',
        loadChildren: ()=> import('./approval-limit/approval-limit.module').then(m=> m.ApprovalLimitModule)
      },
      {
        path:'customer',
        loadChildren: ()=> import('./customer/customer.module').then(m=> m.CustomerModule)
      }
    ]
  }
]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class UserManagementRoutingModule { }
