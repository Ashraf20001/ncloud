import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-disable-popup',
  templateUrl: './disable-popup-user.component.html',
  styleUrls: ['./disable-popup-user.component.css']
})
export class DisablePopupInUserComponent {
  todayDate = new Date();
  expiryDate:any;
  isUser:boolean;
  content: string;
  name = '';
  constructor(public dialogRef: MatDialogRef<DisablePopupInUserComponent>,private toaster:ToastrService, @Inject(MAT_DIALOG_DATA) public data: Data, public translate: TranslateService){
      this.isUser=this.data['isUser'];
      this.name = this.data?.name;
      this.content = this.translate.instant("Dissable_Popup.popup_content").replace('TYPE',this.data.name).replace('STATUS',this.data.status);
  }

  cancel(){
    this.dialogRef.close(false);
  }

  summited(){
    if(this.expiryDate !== undefined && this.expiryDate !== null){
    this.dialogRef.close(this.expiryDate);
  }else{
    const errorMsg = this.translate.instant("DisablePopUp.selectExceedDate")
    this.toaster.error(errorMsg.replace('USER',this.data.name));
  }
}
  /*
  * Clear Date Field
  */
  clearDateField(){
    this.expiryDate = null;
  }
}
export interface Data{
  isUser: boolean;
  name : string;
  status : string;
}
