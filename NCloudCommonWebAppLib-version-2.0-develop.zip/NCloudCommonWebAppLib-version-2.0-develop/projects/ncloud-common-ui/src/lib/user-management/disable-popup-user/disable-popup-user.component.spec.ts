import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisablePopupInUserComponent } from './disable-popup-user.component';

describe('DisablePopupComponent', () => {
  let component: DisablePopupInUserComponent;
  let fixture: ComponentFixture<DisablePopupInUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisablePopupInUserComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DisablePopupInUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
