import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { AllocationPoolComponent } from "./allocation-pool.component";




const routes : Routes =  [
  {
    path: '',
    component: AllocationPoolComponent,

  }
];

@NgModule({
  imports: [RouterModule.forChild(routes),
    // RouterModule.forRoot(appRoutes, { relativeLinkResolution: 'legacy' }),
  ],

  exports: [RouterModule]
})

export class AllocationPoolRoutingModule { }
