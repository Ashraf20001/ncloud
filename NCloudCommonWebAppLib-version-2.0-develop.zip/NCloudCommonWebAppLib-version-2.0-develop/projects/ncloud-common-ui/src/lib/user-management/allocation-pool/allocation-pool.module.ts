
import { CustomDirectiveModule } from '../../directive/directives/custom-directive.module';
import { DemoMaterialModule } from '../../common-components/angularMaterialModules/material-module';
import { BreadcrumbService } from 'xng-breadcrumb';
import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";


import {  TranslateModule } from '@ngx-translate/core';


import {CdkAccordionModule} from '@angular/cdk/accordion';
import { AllocationPoolRoutingModule } from './allocation-pool-routing.module';
import { AllocationPoolComponent } from './allocation-pool.component';
import { AllocationPoolcardComponent } from './allocation-poolcard/allocation-poolcard.component';

import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { AllocateStockPopupComponent } from './allocation-poolcard/allocate-stock-popup/allocate-stock-popup.component';
import {MatTabsModule} from '@angular/material/tabs';
import {MatSelectModule} from '@angular/material/select';
import {MatTooltipModule} from '@angular/material/tooltip';
import { AppCommonModule } from "../../common-components/app-common.module";
import { AllocationPoolListComponent } from './allocation-pool-list/allocation-pool-list.component';

@NgModule({
    declarations: [
        AllocationPoolComponent,
        AllocationPoolcardComponent,
   
        AllocateStockPopupComponent,
        AllocationPoolListComponent,
    ],
    exports: [
        AllocationPoolComponent
    ],
    providers: [
        BreadcrumbService,
    ],
    imports: [
        CommonModule,
        FormsModule,
        AllocationPoolRoutingModule,
        TranslateModule,
        DemoMaterialModule,
        CdkAccordionModule, MatSlideToggleModule, MatTabsModule, MatSelectModule, MatTooltipModule, CustomDirectiveModule,
        AppCommonModule
    ]
})

export class AllocationPoolModule{
}
