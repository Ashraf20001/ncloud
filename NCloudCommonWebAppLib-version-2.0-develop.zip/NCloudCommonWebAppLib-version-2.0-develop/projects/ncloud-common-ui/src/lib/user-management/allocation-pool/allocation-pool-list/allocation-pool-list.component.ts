import { AfterViewInit, OnChanges, OnDestroy, SimpleChanges, ViewChild } from '@angular/core';
import { Input } from '@angular/core';
import { ChangeDetectorRef, OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

import { stockDto } from '../../../service/allocation-pool-dto';
import { AllocateStockPopupComponent } from '../allocation-poolcard/allocate-stock-popup/allocate-stock-popup.component';

import { UserManagementService } from '../../../service/user-management.service';
import { MatTableDataSource } from '@angular/material/table';

import { ToastrServiceService } from '../../../service/toastr-service.service';

import { FilterOrSortingVo } from '../../../dto/Filter-dto/filter-object-backend';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';

import { AllocationPoolSortingColumn } from '../../../enum/common-enum';

import { AppService } from '../../../service/app.service';

import { AccessMappingSectionDto } from '../../../dto/Filter-dto/section-dto';
import { Subject, Subscription, debounceTime } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-allocation-pool-list',
  templateUrl: './allocation-pool-list.component.html',
  styleUrls: ['./allocation-pool-list.component.scss']
})

export class AllocationPoolListComponent implements OnInit,OnChanges, AfterViewInit, OnDestroy{

  @Input() filterObjectFromParent:FilterOrSortingVo[];

  totalLength: number;
  pagesize = 10;
  pageIndex = 0;
  minLength = 0;
  maxLength = 10;
  endingIndex = 10;
  ZERO = 0;
  TEN = 10;
 poolName:string;
 description:string;
 allocatedCount:number;
 issuedCount:number;
 availableCount:number;
 status:boolean;
 identity:string;
 stockId:number;
 maximum: number;
 remainder: number;
 ispoolNameSorting = false;
 isDescriptionSorting = false;
 isAllocationCountSorting = false;
 isIssuedCountSorting = false;
 isAvailableCountSorting = false;
 isStatusSorting = false;
 poolList:stockDto[]
 dataNotFound=false;
 private searchSubject = new Subject<number>();

  displayedColumns: string[] = ['Pool Name', 'No.of paper allocated', 'No.of.paper Issued', 'No.of.paper available', 'Allocate and Revoke', 'Status'];
  dataSource = new MatTableDataSource<TableData>();
  tableList: TableData[]=[]
  stockPoolDto: stockDto;
  ascendingIcon=false;
  ascendingIcon1=false;
  ascendingIcon2=false;
  ascendingIcon3=false;
  ascendingIcon4=false;
  @Input() poolListPageAccessDto: AccessMappingSectionDto;
  @Input() searchValue: string;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  rowPerPageSubscription: Subscription;
  constructor(public dialog: MatDialog,private userService:UserManagementService,
              private changeDetectorRef: ChangeDetectorRef, private toaster:ToastrServiceService,private paginatorName: MatPaginatorIntl,
              private detector: ChangeDetectorRef,private appService:AppService,
              private translate : TranslateService)
  {
    if(this.paginatorName) {
      this.rowPerPageSubscription=this.translate.get('Paginator.ItemsPerPageLabel').subscribe((translation: string) => {
        this.paginatorName.itemsPerPageLabel = translation;
      });

    }


    this.searchSubject .pipe(debounceTime(300)).subscribe((pageIndex: number) => {
      this.changePageIndex();
    });
    
  }
  ngOnDestroy(): void {
    this.rowPerPageSubscription.unsubscribe();
  }
  ngAfterViewInit(): void {

    if(this.paginatorName) {
  
      this.rowPerPageSubscription=this.translate.get('Paginator.ItemsPerPageLabel').subscribe((translation: string) => {
        this.paginatorName.itemsPerPageLabel = translation;
      });

    }
  }
  ngOnInit(): void {

    this.getTotalCount();
    this.pageIndex = 1;
    this.translate.onLangChange.subscribe(() => {
      if (this.paginator) {
        this.paginator._intl.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
        this.paginator._intl.firstPageLabel=this.translate.instant('Paginator.FirstPage');
        this.paginator._intl.lastPageLabel=this.translate.instant('Paginator.LastPage');
        this.paginator._intl.nextPageLabel=this.translate.instant('Paginator.NextPage');
        this.paginator._intl.previousPageLabel=this.translate.instant('Paginator.PreviousPage');
        this.paginator._changePageSize(this.paginator.pageSize);
        this.detector.detectChanges();
      }
    });
    if(this.paginatorName) {
      this.rowPerPageSubscription=this.translate.get('Paginator.ItemsPerPageLabel').subscribe((translation: string) => {
        this.paginatorName.itemsPerPageLabel = translation;
      });

    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['filterObjectFromParent']?.currentValue!== undefined) {
      this.getTotalCount();
    }
    if(changes['searchValue'].currentValue!== undefined) {
      const filterFromSearch:FilterOrSortingVo[]= [];
      this.subTableDetails(filterFromSearch,null,this.minLength,this.maxLength , this.searchValue);
    }

  }



  openDialog(identity:string, id:number,statusChange:boolean,activeStatus:boolean, poolName:string,
            userTypeId:number){   
    
     if(activeStatus){
      const dialogRef = this.dialog.open(AllocateStockPopupComponent, {
        width: '855px',
        // height: '525px',
        data: { identityOfStockPool:identity,
                idOfStockPool:id,
                statusChange:statusChange ,
                poolName:poolName,
                userTypeId:userTypeId},
      });
  
      dialogRef.afterClosed().subscribe((result) => {
        this.ngOnInit();
      });
    }else{
      this.toaster.showError(this.translate.instant('Toaster_error.inactive_status_error'));
    }
 }

 changePage(event){
  if(event.pageIndex != this.ZERO){
    this.maxLength= event.pageSize;
    this.minLength = event.pageSize *event.pageIndex;
    this.endingIndex = event.pageSize;
    this.maximumcount(event.pageSize);
  }else{
    this.maxLength= event.pageSize;
    this.minLength = event.pageIndex;
    this.endingIndex = event.pageSize;
    this.maximumcount(event.pageSize);
  }
  const filterFromSearch:FilterOrSortingVo[]= [];
  this.subTableDetails(filterFromSearch,null,this.minLength,this.maxLength, this.searchValue);
}

maximumcount(event) {
  this.pagesize = event;
  this.maximum = this.totalLength / this.pagesize
  this.remainder = this.totalLength % this.pagesize;
  if (this.remainder != 0) {
    this.maximum =  Math.floor(this.maximum + 1);
  }
}
pageindex(){
  this.searchSubject.next(this.pageIndex);
//   if(this.pageIndex > 0){
//     if(this.pageIndex != null){
//     this.maxLength= this.endingIndex;
//     this.minLength = this.endingIndex * (this.pageIndex -1);
//     const filterFromSearch:FilterOrSortingVo[]= [];
//     this.subTableDetails(filterFromSearch,null,this.minLength, this.maxLength);
//   }
// }
}

changePageIndex(){
  const filterFromSearch:FilterOrSortingVo[]= [];
  if(this.pageIndex > 0) {
    if(this.pageIndex > this.maximum) {
      const numbDigit = this.maximum.toString().length;
      let numString =this.pageIndex.toString();
      numString = numString.substring(0, numbDigit);
      if(Number(numString) >= this.maximum ){
        numString = this.maximum.toString();
      }
      this.pageIndex = this.maximum === 0 ? 1 : Number(numString);
    }
    this.maxLength = this.endingIndex;
    this.minLength = this.endingIndex * (this.pageIndex - 1);
    this.subTableDetails(filterFromSearch,null,this.minLength, this.maxLength, this.searchValue);
    // if(!this.pageIndex){
    // }else{
    //   this.subTableDetails(filterFromSearch,null,this.minLength, this.maxLength, this.searchValue);
    // }
  }else{
    // this.pageIndex = 1;
    this.minLength = 0;
    this.maxLength = 10;
    this.subTableDetails(filterFromSearch,null,this.minLength, this.maxLength, this.searchValue);
  }
}

onKeyDown(event: KeyboardEvent) {
  if (event.keyCode === 190) {
    event.preventDefault();
  }
}

  getTotalCount(){

    if(this.poolListPageAccessDto.isView===false){
      return;
    }

    this.pageIndex=null;
    this.userService.getTotalCountForUserType().subscribe(((res)=>{
      if (res) {
      this.minLength =0;
      this.maxLength = 10;
      this.totalLength = res['content'];
      const totalNUmber = this.totalLength / 10;
      if (this.isFloat(totalNUmber)) {
        this.maximum =  Math.floor(totalNUmber+1);
      }else{
        this.maximum = totalNUmber;
      }
      const filterFromSearch:FilterOrSortingVo[]= [];
      this.subTableDetails(filterFromSearch,null,this.minLength, this.maxLength, this.searchValue);
      this.maximumcount(this.TEN);
    }
    }));
  }
  isFloat(n: number): boolean {
    return Number(n) === n && n % 1 !== 0;
  }

  subTableDetails(filterObject:FilterOrSortingVo[],identity1:string,min:number, max:number, searchValue:string){
    if (this.filterObjectFromParent !== undefined) {
      filterObject = this.filterObjectFromParent
    }
    // this.dataSource = null;
    this.tableList = [];
    this.poolList=[];
    // this.dataNotFound = true;
    this.userService.getAllStockPool(filterObject,identity1,min,max, searchValue).subscribe((response)=>{
      this.tableList = [];
      if (response) {
        this.poolList = response['content'];
        this.poolList = this.poolList.slice(min,max+min);
        if (this.poolList===null || this.poolList.length===0) {
          this.dataNotFound = true;
        }else {
          this.dataNotFound = false;
        }

        this.poolList.forEach(element => {
           this.poolName = element.userTypeName;
           this.description = element.identity;
           this.identity = element.identity;
           this.allocatedCount = element.stockCount;
           this.status = element.isActive;
           this.issuedCount = element.usedCount;
           this.availableCount = element.stockCount - element.usedCount;
           this.stockId = element.stockId
           this.tableList.push({
            poolName:this.poolName,
            description:this.description,
            allocatedCount:this.allocatedCount,
            issuedCount:this.issuedCount,
            availableCount:this.availableCount,
            status:this.status,
            identity:this.identity,
            stockId:this.stockId,
            isActive:element.isActive,
            userTypeName:element.userTypeName,
            userTypeId:element.userTypeId
           });
        });
        this.dataSource = new MatTableDataSource<TableData>(this.tableList);
        // this.changeDetectorRef.detectChanges();
      }
    })
  }

  changeStatus(identity:string,status:boolean, id:number, userTypeId:number){
    this.getStockCount(identity,status,id,userTypeId);
  }

  getStockCount(identity:string,status:boolean, id:number,userTypeId:number){
    this.userService.getOneStockPoolCount(identity).subscribe((response)=>{
      if (response) {
        this.stockPoolDto = response['content'];
        if ((this.stockPoolDto.stockCount - this.stockPoolDto.usedCount) === 0 || status) {
          this.statusChange(identity,status);
          }else {
          this.toaster.showError(this.translate.instant('Toaster_error.status_change_error'));
          this.openDialog(identity,id,true,true,this.stockPoolDto.userTypeName,userTypeId);
        }
      }
    })
  }

  statusChange(identity:string,status:boolean){
    this.userService.getStatusChange(identity,status).subscribe((response)=>{
      if (response) {
        this.toaster.showSuccess(this.translate.instant('Toaster_success.status_change'))
      }
    })
  }

  getSortedData(columnName:string,value:boolean){
    if(columnName === AllocationPoolSortingColumn.USERTYPENAME){
      this.ascendingIcon = !value;
      this.ascendingIcon1 = false;
      this.ascendingIcon2 = false;
      this.ascendingIcon3 = false;
      this.ascendingIcon4 = false;
    }else if(columnName === AllocationPoolSortingColumn.IDENTITY){
      this.ascendingIcon1 = !value;
      this.ascendingIcon = false;
      this.ascendingIcon2 = false;
      this.ascendingIcon3 = false;
      this.ascendingIcon4 = false;
    }else if(columnName === AllocationPoolSortingColumn.STOCKCOUNT){
      this.ascendingIcon2 = !value;
      this.ascendingIcon = false;
      this.ascendingIcon1 = false;
      this.ascendingIcon3 = false;
      this.ascendingIcon4 = false;
    }else if(columnName === AllocationPoolSortingColumn.USEDCOUNT){
      this.ascendingIcon3 = !value;
      this.ascendingIcon = false;
      this.ascendingIcon1 = false;
      this.ascendingIcon2 = false;
      this.ascendingIcon4 = false;
    }else if(columnName === AllocationPoolSortingColumn.NULL){
      this.ascendingIcon4 = !value;
      this.ascendingIcon = false;
      this.ascendingIcon1 = false;
      this.ascendingIcon2 = false;
      this.ascendingIcon3 = false;
    }
    let filterObject:FilterOrSortingVo[] = []
    if (this.filterObjectFromParent!== undefined) {
      this.filterObjectFromParent.forEach(element => {
        if (element.filterOrSortingType==='SORTING') {
          this.filterObjectFromParent.splice(this.filterObjectFromParent.indexOf(element),1);
        }
      });
    }

    if (this.filterObjectFromParent !== undefined) {
       filterObject = this.filterObjectFromParent
    }
    const sortingObject = new FilterOrSortingVo();
    sortingObject.columnName = columnName;
    sortingObject.filterOrSortingType = "SORTING";
    sortingObject.isAscending = !value

    filterObject.push(sortingObject);
    this.subTableDetails(filterObject,null,this.minLength, this.maxLength, this.searchValue);
    this.changeSortingvalue(columnName);
  }

  refreshSorting(name:string){

   if (name!==AllocationPoolSortingColumn.USERTYPENAME) {
    this.ispoolNameSorting = !this.ispoolNameSorting;
   }
   if (name!==AllocationPoolSortingColumn.IDENTITY) {
    this.isDescriptionSorting = !this.isDescriptionSorting;
   }
   if (name!==AllocationPoolSortingColumn.STOCKCOUNT) {
    this.isAllocationCountSorting = !this.isAllocationCountSorting;
   }
   if (name!==AllocationPoolSortingColumn.USEDCOUNT) {
    this.isIssuedCountSorting = !this.isIssuedCountSorting;
   }
   if (name!==AllocationPoolSortingColumn.NULL) {
    this.isAvailableCountSorting = !this.isAvailableCountSorting;
   }
   if (name!==AllocationPoolSortingColumn.ISACTIVE) {
    this.isStatusSorting = !this.isStatusSorting;
   }
  }

  changeSortingvalue(name:string){

    if (name===AllocationPoolSortingColumn.USERTYPENAME) {
     this.ispoolNameSorting = !this.ispoolNameSorting;
    }
    if (name===AllocationPoolSortingColumn.IDENTITY) {
     this.isDescriptionSorting = !this.isDescriptionSorting;
    }
    if (name===AllocationPoolSortingColumn.STOCKCOUNT) {
     this.isAllocationCountSorting = !this.isAllocationCountSorting;
    }
    if (name===AllocationPoolSortingColumn.USEDCOUNT) {
     this.isIssuedCountSorting = !this.isIssuedCountSorting;
    }
    if (name===AllocationPoolSortingColumn.NULL) {
     this.isAvailableCountSorting = !this.isAvailableCountSorting;
    }
    if (name===AllocationPoolSortingColumn.ISACTIVE) {
     this.isStatusSorting = !this.isStatusSorting;
    }
   }


}

export class TableData{
  poolName:string;
  description:string;
  allocatedCount:number;
  issuedCount:number;
  availableCount:number;
  status:boolean;
  identity:string;
  stockId:number;
  isActive?:boolean;
  userTypeName?:string;
  userTypeId?:number;
}
