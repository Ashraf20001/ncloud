import { EventEmitter, OnDestroy, OnInit } from '@angular/core';
import { Output } from '@angular/core';
import { Component } from '@angular/core';

import { MenuSectionNames } from '../../const/enum';
import { FilterObject } from '../../dto/Filter-dto/filter-object';
import { FilterOrSortingVo } from '../../dto/Filter-dto/filter-object-backend';
import { AccessMappingPageDto } from '../../dto/access-Mapping-PageDto ';
import { AccessMappingSectionDto } from '../../dto/Filter-dto/section-dto';

import { appConst } from '../../const/app.const';
import { AppService } from '../../service/app.service';
import { UserManagementService } from '../../service/user-management.service';

@Component({
  selector: 'app-allocation-pool',
  templateUrl: './allocation-pool.component.html',
  styleUrls: ['./allocation-pool.component.scss'],
})
export class AllocationPoolComponent implements OnInit, OnDestroy {
  cardlistview = true;
  showDownload = false;
  cardList = true;
  searchdisable = true;
  filterFromSearch:FilterOrSortingVo[];
  searchData:string;
  allocationPoolPageAccessDto: AccessMappingPageDto;
  poolListPageAccessDto: AccessMappingSectionDto;
  allocateStockPageAccessDto:AccessMappingSectionDto;
  reallocatePageAccessDto: AccessMappingSectionDto;
  deallocatePageAccessDto: AccessMappingSectionDto;
  dataLoaded: boolean;
  searchValue="";
  cardviewopen() {
    this.cardlistview = !this.cardlistview;
    this.cardList = !this.cardList;
    if(this.cardList==false){
      sessionStorage.setItem('Allocation','list');
    }
    else{
      sessionStorage.setItem('Allocation','');
    }
    this.searchdisable = !this.searchdisable;
  }
  constructor(private appService:AppService, private userService:UserManagementService){}
  ngOnDestroy(): void {
    sessionStorage.removeItem('Allocation');
  }

  ngOnInit(): void {
    this.getPageAccess();
    
  }

  searchItem(event) {
    this.searchValue = event;
    if (event === "" && this.cardList) {
      this.userService.emptyCardEvent.emit(true);
    }
  }

  open() {
    this.showDownload = true;
  }

  search(event){
    this.searchData = event.target.value;
  }
  filterObjectArray: FilterObject[] = [
    {
      columnName: 'userTypeName',
      condition: 'Like',
      aliasName: 'Allocation_Pool_table.poolName',
      type: 'field',
      value: [],
      dropdown: [],
      radio: [],
      dataType:"String"
    },
    // {
    //   columnName: 'identity',
    //   condition: 'Like',
    //   aliasName: 'Allocation_Pool_table.description',
    //   type: 'field',
    //   value: [],
    //   dropdown: [],
    //   radio: [],
    //   dataType:"String"
    // },
    {
      columnName: 'stockCount',
      condition: 'BW',
      aliasName: 'Allocation_Pool_table.no_of_paper_allocated',
      type: 'fields',
      value: [],
      dropdown: [],
      radio: [],
      dataType:"Integer",
      isMax :false
    },
    {
      columnName: 'usedCount',
      condition: 'BW',
      aliasName: 'Allocation_Pool_table.no_of_paper_Issued',
      type: 'fields',
      value: [],
      dropdown: [],
      radio: [],
      dataType:"Integer",
      isMax :false
    },
    {
      columnName: 'null',
      condition: 'BW',
      aliasName: 'Allocation_Pool_table.no_of_paper_available',
      type: 'fields',
      value: [],
      dropdown: [],
      radio: [],
      dataType:"Integer",
      isMax :false
    },
    {
      columnName: 'isActive',
      condition: 'Equal',
      aliasName: 'Allocation_Pool_table.status',
      type: 'radio',
      value: [],
      dropdown: [],
      radio: [
        {
          name: 'Customer_table.Active',
          value: false,
        },
        {
          name: 'Customer_table.InActive',
          value: false,
        },
      ],
      dataType:"Boolean"
    },
  ];

  getPageAccess() {
    this.appService.getPageAccess(appConst.PAGE_NAME.ALLOCATION_POOL.PAGE_IDENTITY).subscribe(response=>{
      if (response) {
        this.allocationPoolPageAccessDto = response['content'];
        this.allocationPoolPageAccessDto.sectionData= this.getEnabledPrivilegeFromMultipleRoles(this.allocationPoolPageAccessDto?.sectionData);

        this.poolListPageAccessDto = this.allocationPoolPageAccessDto?.sectionData.find(x => x.sectionName===MenuSectionNames.Pool_List);
        this.allocateStockPageAccessDto = this.allocationPoolPageAccessDto?.sectionData.find(x => x.sectionName===MenuSectionNames.Allocate_Stock);
        this.reallocatePageAccessDto = this.allocationPoolPageAccessDto?.sectionData.find(x => x.sectionName===MenuSectionNames.Reallocate);
        this.deallocatePageAccessDto = this.allocationPoolPageAccessDto?.sectionData.find(x => x.sectionName===MenuSectionNames.Deallocate);
        this.dataLoaded = true;
        const isList = sessionStorage.getItem('Allocation')
        if (isList != null && isList!=undefined && isList!='') {
          this.cardList = false;
          this.searchdisable = false;
          this.cardlistview = false;
        }
      }
    })
  }

  collectFilterValue(event:FilterOrSortingVo[]){
    this.searchValue ="";
    this.filterFromSearch=event;
  }

  getEnabledPrivilegeFromMultipleRoles(sectionDataArray:AccessMappingSectionDto[]):AccessMappingSectionDto[]{
    const result: AccessMappingSectionDto[] = Object.values(
      sectionDataArray.reduce((accumulator, obj) => {
        let accessMappingAccumulator:AccessMappingSectionDto= null;
        if (!accumulator[obj.sectionName]) {
          accumulator[obj.sectionName] = obj;
        }
        accessMappingAccumulator=accumulator[obj.sectionName];
        if(obj.isView){          
          accessMappingAccumulator.isView=obj.isView;
        }
        if(obj.isClone){
          accessMappingAccumulator.isClone=obj.isClone;
        }
        if(obj.isDisable){
          accessMappingAccumulator.isClone=obj.isDisable;
        }
        if(obj.isDownload){
          accessMappingAccumulator.isDownload=obj.isDownload;
        }
        if(obj.isEdit){
          accessMappingAccumulator.isEdit=obj.isEdit;
        }
        if(obj.isNotification){
          accessMappingAccumulator.isNotification=obj.isNotification;
        }
        accumulator[obj.sectionName]=accessMappingAccumulator;
        return accumulator;
      }, {} as Record<string, AccessMappingSectionDto>)
    );
    
    return result
  }
}
