import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllocationPoolcardComponent } from './allocation-poolcard.component';

describe('AllocationPoolcardComponent', () => {
  let component: AllocationPoolcardComponent;
  let fixture: ComponentFixture<AllocationPoolcardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllocationPoolcardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AllocationPoolcardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
