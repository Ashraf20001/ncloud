import { Input, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AllocateStockPopupComponent } from './allocate-stock-popup/allocate-stock-popup.component';

import { UserManagementService } from '../../../service/user-management.service';

import { ToastrServiceService } from '../../../service/toastr-service.service';


import { FilterOrSortingVo } from '../../../dto/Filter-dto/filter-object-backend';


import { AccessMappingSectionDto } from '../../../dto/Filter-dto/section-dto';
import { TranslateService } from '@ngx-translate/core';
import { stockDto } from '../../../service/allocation-pool-dto';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-allocation-poolcard',
  templateUrl: './allocation-poolcard.component.html',
  styleUrls: ['./allocation-poolcard.component.scss'],
})
export class AllocationPoolcardComponent implements OnInit,OnChanges,OnDestroy {
  isActive: boolean;
  stockPoolDto: stockDto;
  pool: stockDto[];
  dataNotFound=false;
  poolCardVoCopy:stockDto[];
  @Input() searchValue :string;

  @Input() poolListPageAccessDtoFromParent: AccessMappingSectionDto;
  @Input() allocationStockAccessDtoFromParent: AccessMappingSectionDto;
  emptyCardSubscription: Subscription;
  constructor(
    public dialog: MatDialog,
    private userService: UserManagementService,
    private toaster: ToastrServiceService,
    private translate:TranslateService
  ) {

    this.emptyCardSubscription=  this.userService.emptyCardEvent.subscribe((value)=>{
      if(value){
        this.pool = this.poolCardVoCopy;
      }
    })
  }
  ngOnDestroy(): void {
    this.emptyCardSubscription.unsubscribe();
  }
ngOnChanges(changes: SimpleChanges): void {
  if (changes['searchValue'].currentValue!== undefined) {
      this.pool = this.poolCardVoCopy.filter((m) => String(m.userTypeName.toUpperCase()).includes(this.searchValue.toUpperCase()));
    }else{
      this.pool = this.poolCardVoCopy;
    }
    this.dataNotFound = (this.pool?.length>0)?false:true;
}
  ngOnInit(): void {
  //  this.dataNotFound = true;
   this.allocationPoolCardList();
  }


  allocationPoolCardList() {

    if(this.poolListPageAccessDtoFromParent.isView===false){
      return;
    }

    this.userService.getTotalCountForUserType().subscribe((res) => {
      if (res) {
        const filterFromSearch: FilterOrSortingVo[] = [];
        this.userService.getAllStockPool(filterFromSearch, null, 0, res['content'],"").subscribe((response) => {
          if (response) {
            if (response['content'].length === 0 || response['content'] === null) {
              this.dataNotFound = true;
            } else {
              this.dataNotFound = false;
            }
            this.pool = response['content'];
            this.poolCardVoCopy = response['content'];
          }
        });
      }
    });
  }

  openDialog(identity:string, id:number,statusChange:boolean,activeStatus:boolean, poolName:string
            ,usertypeId:number) {
    if(activeStatus){
    const dialogRef = this.dialog.open(AllocateStockPopupComponent, {
      width: '740px',
      // height: '525px',
      data: { identityOfStockPool:identity,
              idOfStockPool:id,
              statusChange:statusChange ,
              poolName:poolName,
              userTypeId:usertypeId},
    });

    dialogRef.afterClosed().subscribe((result) => {
      this.ngOnInit();
    });
  }else{
    this.toaster.showError(this.translate.instant('Toaster_error.inactive_status_error'));
  }
  }

  changeStatus(identity:string,status:boolean, id:number,userTypeId:number){
    this.getStockCount(identity,status,id,userTypeId);
  }

  getStockCount(identity:string,status:boolean, id:number,userTypeId:number){
    this.userService.getOneStockPoolCount(identity).subscribe((response)=>{
      if (response) {
        this.stockPoolDto = response['content'];
        if ((this.stockPoolDto.stockCount - this.stockPoolDto.usedCount) === 0 || status) {
          this.statusChange(identity,status);
          }else {
          this.toaster.showError(this.translate.instant('Toaster_error.status_inactive_change_error'));
          this.openDialog(identity,id,true,true,this.stockPoolDto.userTypeName,userTypeId);
        }
      }
    })
  }

  statusChange(identity:string,status:boolean){
    this.userService.getStatusChange(identity,status).subscribe((response)=>{
      if (response) {
        this.toaster.showSuccess(this.translate.instant('Toaster_success.status_change'));
      }
    })
  }
}
