import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllocationPoolComponent } from './allocation-pool.component';

describe('AllocationPoolComponent', () => {
  let component: AllocationPoolComponent;
  let fixture: ComponentFixture<AllocationPoolComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllocationPoolComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AllocationPoolComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
