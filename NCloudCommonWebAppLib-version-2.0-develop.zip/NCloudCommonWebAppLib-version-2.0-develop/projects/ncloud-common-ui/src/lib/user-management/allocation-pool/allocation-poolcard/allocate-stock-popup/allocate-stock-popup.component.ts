import { ToastrServiceService } from './../../../../service/toastr-service.service';
import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Data } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';

import { PoolDto, stockDto } from '../../../../service/allocation-pool-dto';
import { AccessMappingPageDto } from '../../../../dto/access-Mapping-PageDto ';
import { AccessMappingSectionDto } from '../../../../dto/Filter-dto/section-dto';
import { UserManagementService } from '../../../../service/user-management.service';
import { AppService } from '../../../../service/app.service';
import { appConst } from '../../../../const/app.const';
import { MaxInt, MenuSectionNames } from '../../../../const/enum';
import { FilterOrSortingVo } from '../../../../dto/Filter-dto/filter-object-backend';
import { JsonService } from '../../../../service/json.service';



@Component({
  selector: 'app-allocate-stock-popup',
  templateUrl: './allocate-stock-popup.component.html',
  styleUrls: ['./allocate-stock-popup.component.scss'],
})
export class AllocateStockPopupComponent implements OnInit {
  active = true;
  inactive = false;
  Amount: string;
  reallocate = true;
  allocatedStockCount = 0;
  availableStockCount = 0;
  issuedStockCount = 0;
  stockPoolDto: stockDto;
  reAllocateStockPoolId: stockDto;
  enableFunc = false;
  englishJson: any;
  allocationPoolPageAccessDto: AccessMappingPageDto;
  reallocatePageAccessDto: AccessMappingSectionDto;
  deallocatePageAccessDto: AccessMappingSectionDto;

  constructor(
    public dialogRef: MatDialogRef<AllocateStockPopupComponent>,
    private userService: UserManagementService,
    private toaster: ToastrServiceService,
    @Inject(MAT_DIALOG_DATA) public data: Data,
    private json: JsonService,
    private translate: TranslateService,
    private appService: AppService
  ) {
    dialogRef.disableClose = true;

    this.loadTranslatedNavigationTabs();
    this.translate.onLangChange.subscribe(() => {
      this.loadTranslatedNavigationTabs();
    });

    this.json.getEnglishJson().subscribe((response) => {
      if (response) {
        this.englishJson = response;
      }
    });
  }

  ngOnInit() {
    this.ReallocateOrDeallocate[0].check = true;
    if (this.data['statusChange']) {
      this.Revoke();
    }
    this.getPageAccess();
  }

  getPageAccess() {
    this.appService
      .getPageAccess(appConst.PAGE_NAME.ALLOCATION_POOL.PAGE_IDENTITY)
      .subscribe((response) => {
        if (response) {
          this.allocationPoolPageAccessDto = response['content'];
          this.reallocatePageAccessDto =
            this.allocationPoolPageAccessDto?.sectionData.find(
              (x) => x.sectionName === MenuSectionNames.Reallocate
            );
          this.deallocatePageAccessDto =
            this.allocationPoolPageAccessDto?.sectionData.find(
              (x) => x.sectionName === MenuSectionNames.Deallocate
            );
          this.getStockCount();
          this.getStockPoolDropDown();
        }
      });
  }

  closeDialog() {
    this.dialogRef.close('Sandwich!');
  }

  allocate() {
    this.active = true;
    this.inactive = false;
  }

  Revoke() {
    this.active = false;
    this.inactive = true;
  }

  NumberOfPaper: number[] = [100, 500, 1000];
  Paper: number;
  // Papers :number;
  Papers: number | null = null;
  NumberOfPapers: number[] = [100, 500, 1000];

  matcher(event) {
    const allowedRegex = /[0-9]/g;

    if (!event.key.match(allowedRegex)) {
      event.preventDefault();
    }
  }

  Numberofpaper(event: any) {
    this.Paper = event.target.innerText; //use is code in backend
  }

  Numberofpapers(event: any) {
    this.Papers = event.target.innerText; //use is code in backend
  }
  ReallocateOrDeallocate: any[] = [];
  loadTranslatedNavigationTabs() {
    this.ReallocateOrDeallocate = [
      {
        name: this.translate.instant('Allocatio_Pool_Popup.Reallocate'),
        check: false,
      },
      {
        name: this.translate.instant('Allocatio_Pool_Popup.Deallocate'),
        check: false,
      },
    ];
  }

  Reallocateordeallocate(event: any) {
    this.Amount = event; //use is code in backend
    if (event === 'Reallocate' || event === 'Réaffecter') {
      this.ReallocateOrDeallocate[0].check = true;
      this.ReallocateOrDeallocate[1].check = false;
      this.reallocate = true;
    } else if (event === 'Deallocate' || event === 'Libérer') {
      this.ReallocateOrDeallocate[0].check = false;
      this.ReallocateOrDeallocate[1].check = true;
      this.reallocate = false;
    }
  }

  Pool: stockDto[];

  getStockCount() {
    this.userService
      .getOneStockPoolCount(this.data['identityOfStockPool'])
      .subscribe((response) => {
        if (response) {
          this.stockPoolDto = response['content'];
          this.allocatedStockCount = this.stockPoolDto.stockCount;
          this.availableStockCount =
            this.stockPoolDto.stockCount - this.stockPoolDto.usedCount;
          this.issuedStockCount = this.stockPoolDto.usedCount;
        }
      });
  }

  poolAction(poolDto: PoolDto, action: string) {
    this.enableFunc = true;
    this.userService.poolAction(poolDto).subscribe((response) => {
      if (response) {
        this.closeDialog();
        if (action === 'Reallocate') {
          const successMsg1=this.translate.instant('Allocation_Pool_Success.message1');
          const actionMessage=this.translate.instant('Toaster_success.'+action.toLowerCase());
          const successMsg2=this.translate.instant('Allocation_Pool_Success.message3');
          const poolName=this.translate.instant('pool_names.'+poolDto.poolName)+' '+this.translate.instant('Toaster_success.pool')

          this.toaster.showSuccess(
            successMsg1+
             actionMessage +
              successMsg2 +
              poolName
          );
        }
        if (action === 'Deallocate') {
          const successMsg1=this.translate.instant('Allocation_Pool_Success.message1');
          const actionMessage=this.translate.instant('Toaster_success.'+action.toLowerCase());
          const successMsg2=this.translate.instant('Allocation_Pool_Success.message2')+' '+this.translate.instant('Managment.InsuranceCompany');
          this.toaster.showSuccess(
            successMsg1 +
            actionMessage +
            successMsg2 
          );
        }

        if (action === 'Allocate') {

          const successMsg1=this.translate.instant('Allocation_Pool_Success.message1');
          const actionMessage=this.translate.instant('Toaster_success.'+action.toLowerCase());
          const successMsg2=this.translate.instant('Allocation_Pool_Success.message2');
          const poolName=this.translate.instant('pool_names.'+this.data['poolName']) +' '+ this.translate.instant('Toaster_success.pool');
          this.toaster.showSuccess(
            successMsg1 +
            actionMessage +
            successMsg2 +
            poolName 
          );
        }

        this.userService
          .getOneStockPoolCount(this.data['identityOfStockPool'])
          .subscribe((response) => {
            if (response && this.data['statusChange']) {
              this.stockPoolDto = response['content'];
              if (
                this.stockPoolDto.stockCount - this.stockPoolDto.usedCount ===
                0
              ) {
                this.userService
                  .getStatusChange(this.data['identityOfStockPool'], false)
                  .subscribe((response) => {
                    this.toaster.showSuccess(this.translate.instant('Toaster_success.status_change'));
                  });
              }
            }
          });
      }
    });
  }

  allocateStock() {
      
    const poolDto = new PoolDto();
    poolDto.poolAction = 'ALLOCATE';
    let stockCount=this.Paper;
    if(stockCount === null || stockCount === undefined)
    {
      this.toaster.showError(this.translate.instant('Toaster_error.mandatory_fields'));
    }

    if(typeof this.Paper==='string'){
        stockCount=Number(this.Paper);
    }
    poolDto.stockCount = stockCount;
    const value = poolDto.stockCount;
    if (poolDto.stockCount != undefined || poolDto.stockCount != null) {
      if (poolDto.stockCount > MaxInt.INT) {
        this.Paper = null;
        this.toaster.showError(this.translate.instant('Toaster_error.exceed_allocation_limit'));
      } else if (value === 0 || poolDto.stockCount < 100) {
        this.Paper = null;
        this.toaster.showError(this.translate.instant('Toaster_error.minimum_allocation_limit'))
      } else {
        poolDto.poolId = this.data['idOfStockPool'];
        poolDto.poolName = this.data['poolName'];
        poolDto.userTypeId=this.data['userTypeId'];
        this.poolAction(poolDto, 'Allocate');
      }
    }
  }

  reAllocate() {
    const poolDto = new PoolDto();
    poolDto.poolAction = 'REALLOCATE';
    let stockCount = this.Papers;
    if (stockCount === null) {
      this.toaster.showError(this.translate.instant('Toaster_error.mandatory_fields'));
    }

    if (typeof this.Paper === 'string') {
      stockCount = Number(this.Papers);
    }
    poolDto.stockCount = stockCount;
    const value = poolDto.stockCount;
    if (poolDto.stockCount != undefined || poolDto.stockCount != null) {
      if (poolDto.stockCount > MaxInt.INT) {
        this.Papers = null;
        this.toaster.showError(this.translate.instant('Toaster_error.exceed_allocation_limit'));
      }else if (value === 0 || poolDto.stockCount < 100) {
        this.Papers = null;
        this.toaster.showError(this.translate.instant('Toaster_error.minimum_reallocation_limit'));
      } else {
        if(this.reAllocateStockPoolId){
          poolDto.poolId = this.data['idOfStockPool'];
          poolDto.reAllocateToId = this.reAllocateStockPoolId.userTypeId;
          poolDto.poolName = this.reAllocateStockPoolId.userTypeName;
          poolDto.userTypeId=this.data['userTypeId'];
          this.poolAction(poolDto, 'Reallocate');
        }else{
          this.toaster.showError(this.translate.instant('Toaster_error.Please_select_user_type'));
        }
      }
    }
  }

  deAllocate() {
    const poolDto = new PoolDto();
    poolDto.poolAction = 'DEALLOCATE';
    let stockCount = this.Papers;
    if (stockCount === null || stockCount  === undefined) {
      this.toaster.showError(this.translate.instant('Toaster_error.mandatory_fields'));
    }
    if (typeof this.Paper === 'string') {
      stockCount = Number(this.Papers);
    }
    poolDto.stockCount = stockCount;
    const value = poolDto.stockCount;
    if (poolDto.stockCount != undefined || poolDto.stockCount != null) {
      if (poolDto.stockCount > MaxInt.INT) {
        this.Papers = null;
        this.toaster.showError(this.translate.instant('Toaster_error.exceed_allocation_limit'));
      } else if (value === 0 || poolDto.stockCount < 100) {
        this.Papers = null;
        this.toaster.showError(this.translate.instant('Toaster_error.minimum_deallocation_limit'));
      } else {
        poolDto.poolId = this.data['idOfStockPool'];
        poolDto.userTypeId=this.data['userTypeId'];
        this.poolAction(poolDto, 'Deallocate');
      }
    }
  }

  getStockPoolDropDown() {

    this.userService.getTotalCountForUserType().subscribe((res) => {
      if (res) {
        const filterFromSearch: FilterOrSortingVo[] = [];
        this.userService
          .getAllStockPool(filterFromSearch,this.data['identityOfStockPool'],0,res['content'],"")
          .subscribe((response) => {
            if (response) {
              this.Pool = response['content'];
              const nameList = this.Pool.filter((e) => e.isActive === true);
              this.Pool = nameList.filter(name => name.userTypeName !== this.data['poolName']);
            }
          });
      }
    });
  }

  enable() {
    this.enableFunc = false;
  }

  isDisabled(): boolean {

    return this.Paper === null || this.Paper === undefined;
  }
}
