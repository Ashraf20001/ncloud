import { ManageUserComponent } from './manage-user/manage-user.component';
import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { UserComponent } from './user.component';
import { UserListComponent } from './user-list/user-list.component';


const routes : Routes =  [
  {
    path: '',
    component: UserComponent,
    data:{
      breadcrumb: {
        label: '',
        skip: true
      },
    },
    children: [
      {
        path:'list',
        component: UserListComponent,
        data: {
          breadcrumb: {
            skip: true
          }
        }
      },
      {
        path:'manage/:isClone/:identity',
        component: ManageUserComponent,
        data: {
          breadcrumb: {
            label: 'BREADCRUMB.Add New User'
          }
        }
      },
      {
        path:'Edit/:isClone/:identity',
        component: ManageUserComponent,
        data: {
          breadcrumb: {
            label: 'BREADCRUMB.User List / Edit User'
          }
        }
      },
      {
        path:'Clone/:isClone/:identity',
        component: ManageUserComponent,
        data: {
          breadcrumb: {
            label: 'BREADCRUMB.User List / Clone User'
          }
        }
      },
      {
        path: '',
        redirectTo: 'list',
        pathMatch: 'full'
      }
    ]
  }
]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class UserRoutingModule { }
