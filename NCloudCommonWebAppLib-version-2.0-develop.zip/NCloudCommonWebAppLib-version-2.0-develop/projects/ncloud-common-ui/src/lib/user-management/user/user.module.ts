import { CustomDirectiveModule } from './../../directive/directives/custom-directive.module';
import { ManageUserComponent } from './manage-user/manage-user.component';
import { UserListComponent } from './user-list/user-list.component';

import { DemoMaterialModule } from '../../common-components/angularMaterialModules/material-module';
import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { UserComponent } from "./user.component";
import { UserRoutingModule } from "./user-routing.module";

import { TranslateModule } from '@ngx-translate/core';
import { AppCommonModule } from "../../common-components/app-common.module";
import { ErrorHandlerDirective } from '../../directive/errorHandler.directive';



@NgModule({
    declarations: [
        UserComponent,
        UserListComponent,
        ManageUserComponent,
        ErrorHandlerDirective
    ],
    exports: [
        UserComponent,
        UserListComponent,
        ManageUserComponent
    ],
    imports: [
        CommonModule,
        FormsModule,
        UserRoutingModule,
        DemoMaterialModule,
        TranslateModule,
        AppCommonModule,
        CustomDirectiveModule
    ]
})

export class UserModule{
}
