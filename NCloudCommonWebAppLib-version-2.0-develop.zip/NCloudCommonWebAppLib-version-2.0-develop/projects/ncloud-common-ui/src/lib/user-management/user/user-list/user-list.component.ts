
import { MetaDataDto } from '../../../dto/entity-management/meta-data-dto';
import { UserMenuDto } from '../../../dto/user-menu-dto';
import { userDissableDto } from '../../../dto/disable-dto';
import { Field } from '../../../dto/entity-management/field';
import { userManagement } from './../../../dto/user-management';
import { UserManagementService } from './../../../service/user-management.service';
import { Router } from '@angular/router';
import { Component, ViewChild, Input, Output, EventEmitter, OnInit, AfterViewInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ToastrService } from 'ngx-toastr';
import { MatDialog } from '@angular/material/dialog';

import { PopupComponent } from '../../../common-components/popup/popup.component';
import { appConst } from '../../../const/app.const';
import { AccessMappingPageDto } from '../../../dto/access-Mapping-PageDto ';
import { AppService } from '../../../service/app.service';
import { MenuSectionNames ,UserList} from '../../../const/enum';
import { FilterOrSortingVo } from '../../../dto/Filter-dto/filter-object-backend';
import { FilterObject } from '../../../dto/Filter-dto/filter-object';
import { FileTypeEnum } from '../../../dto/FileTypeEnum';
import { AdminService } from '../../../service/admin.service';
import { AccessMappingSectionDto } from '../../../dto/Filter-dto/section-dto';
import { Subject, Subscription, debounceTime } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss']
})

export class UserListComponent implements OnInit, AfterViewInit, OnDestroy {
  show = true;
  searchDisable=false;
  tableList: UserDetailsList[] = [];
  previewReportPageAccessDto: AccessMappingSectionDto;
  addNewUserPageAccessDto: AccessMappingSectionDto;
  ZERO = 0;
  TEN = 10;

  displayedColumns: string[] = ['RoleId', 'RoleName', 'Description', 'PhoneNumber', 'AddedData', 'Mapped', 'Status', 'Clone', 'Edit', 'Delete'];
  dataSource = new MatTableDataSource<UserDetailsList>();


  showtabledata: UserDetailsList[];
  userDetailsList: userManagement[];
  userName: string;
  addedDate: string;
  status: string;
  userIdentity: string;
  userRoleName = [];
  emailId: string;
  phoneNumber: string;
  sequenceUserId: string
  userId: number;
  totalLength: number;
  pagesize: number;
  dataNotFound = false;
  isDownloadDisable=false;

  appConst = appConst;
  userListPageAccessMap: AccessMappingPageDto;
  isUserListPageEnabled = true;
  userListPrivillegeInfo: any;
  minLength: number=0;
  maxLength: number = 10;
  maximum: number;
  remainder: number;
  endingIndex = 10;
  allUserRoleName=[];
  roleId = false;
  roleName = false;
  description = false;
  phonenumber = false;
  addedData = false;
  mapped = false;
  isAdmin=false
  Status = false;
  userListDissabelDto = new userDissableDto();
  private searchSubject = new Subject<number>();
  filterVoObject: FilterOrSortingVo[] = [];
  filterObject:FilterObject[]=[];
  searchValue="";
  platformId: any;
  pageChangedEvent: any;
  roleNameList:string[]=[];
  userListSubscription: Subscription;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  rowPerPageSubscription: Subscription;
  constructor(private service: UserManagementService, private router: Router, private toaster: ToastrService,
    private paginatorName: MatPaginatorIntl,
    private detector: ChangeDetectorRef, private appService: AppService,
    private dialog: MatDialog, private adminService:AdminService, private translate: TranslateService) {
      
    this.userListSubscription=this.service.getUserSubscription().subscribe(value => {
      if (value == true) {
        this.getTableList(this.ZERO, this.TEN, this.filterVoObject, this.searchValue);
      }
    });
   
  if(this.paginatorName) {
    this.rowPerPageSubscription=this.translate.get('Paginator.ItemsPerPageLabel').subscribe((translation: string) => {
      this.paginatorName.itemsPerPageLabel = translation;
    });
  }
    this.filterObject=this.getFilterObjectArrayBasedOnLoginType();
    this.getRoleNamesForChips()

    this.searchSubject .pipe(debounceTime(300)).subscribe((pageIndex: number) => {
      this.changePageIndex();
    });
  }
  ngOnDestroy(): void {
    this.userListSubscription.unsubscribe();
    this.rowPerPageSubscription.unsubscribe();
  }

  ngOnInit(): void {
    this.getPageAccessData();
    const platformDetails = JSON.parse(sessionStorage.getItem("platformDetails") ?? "{}");
    this.platformId = platformDetails.platformId;
    // this.getTotalUserManagementList();
    this.translate.onLangChange.subscribe(() => {
      if (this.paginator) {
        this.paginator._intl.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
        this.paginator._intl.firstPageLabel=this.translate.instant('Paginator.FirstPage');
        this.paginator._intl.lastPageLabel=this.translate.instant('Paginator.LastPage');
        this.paginator._intl.nextPageLabel=this.translate.instant('Paginator.NextPage');
        this.paginator._intl.previousPageLabel=this.translate.instant('Paginator.PreviousPage');
        this.paginator._changePageSize(this.paginator.pageSize);
        this.detector.detectChanges();
      }
    });
    if(this.paginatorName) {
      this.rowPerPageSubscription=this.translate.get('Paginator.ItemsPerPageLabel').subscribe((translation: string) => {
        this.paginatorName.itemsPerPageLabel = translation;
      });
    }
  }
  getRoleNamesForChips() {
    this.service.getCardDetails(0,0,[],"").subscribe((response)=>{
      if (response) {
            const rolesData= response['content'];
            this.roleNameList=rolesData.map(roles=>roles.roleName);
        }

        this.filterObject.forEach((filter)=>{
            if(filter.columnName==='roles'){
                filter.dropdown=this.roleNameList;
            }
        })
      });
  }

  doProcess(): void {
    this.getPrivillege();
    // this.getTotalUserManagementList();
  }

  ngAfterViewInit() {
    if (this.dataSource !== undefined && this.dataSource !== null) {
      this.dataSource.paginator = this.paginator;
    }
    if(this.paginatorName) {
      this.rowPerPageSubscription=this.translate.get('Paginator.ItemsPerPageLabel').subscribe((translation: string) => {
        this.paginatorName.itemsPerPageLabel = translation;
      });
    }
  }
  shortingmethod(data: any) {
    const user = data;

    if (user === UserList.userID) {
      this.roleId = !this.roleId;
      this.roleName = false;
      this.description = false;
      this.phonenumber = false;
      this.addedData = false;
      this.mapped = false;
      this.Status = false;
      if (this.roleId) {
        const columnName = this.getEntityColumnName(user);
        this.setSortingVO(columnName, this.roleId);
        this.getTotalUserManagementList(this.filterVoObject,this.searchValue);
      } else {
        const columnName = this.getEntityColumnName(user);
        this.setSortingVO(columnName, this.roleId);
        this.getTotalUserManagementList(this.filterVoObject,this.searchValue);
      }
    }
    else if (user === UserList.userName) {
      this.roleId = false;
      this.roleName = !this.roleName;
      this.description = false;
      this.phonenumber = false;
      this.addedData = false;
      this.mapped = false;
      this.Status = false;
      if (this.roleName) {
        const columnName = this.getEntityColumnName(user);
        this.setSortingVO(columnName, this.roleName);
        this.getTotalUserManagementList(this.filterVoObject,this.searchValue);
      } else {
        const columnName = this.getEntityColumnName(user);
        this.setSortingVO(columnName, this.roleName);
        this.getTotalUserManagementList(this.filterVoObject,this.searchValue);
      }
    }
    else if (user === UserList.emailId) {
      this.roleId = false;
      this.roleName = false;
      this.description = !this.description;
      this.phonenumber = false;
      this.addedData = false;
      this.mapped = false;
      this.Status = false;
      if (this.description) {
        const columnName = this.getEntityColumnName(user);
        this.setSortingVO(columnName, this.description);
        this.getTotalUserManagementList(this.filterVoObject,this.searchValue);
      } else {
        const columnName = this.getEntityColumnName(user);
        this.setSortingVO(columnName, this.description);
        this.getTotalUserManagementList(this.filterVoObject,this.searchValue);
      }
    }
    else if (user === UserList.phoneNumber) {
      this.roleId = false;
      this.roleName = false;
      this.description = false;
      this.phonenumber = !this.phonenumber;
      this.addedData = false;
      this.mapped = false;
      this.Status = false;
      if (this.phonenumber) {
        const columnName = this.getEntityColumnName(user);
        this.setSortingVO(columnName, this.phonenumber);
        this.getTotalUserManagementList(this.filterVoObject,this.searchValue);
      } else {
        const columnName = this.getEntityColumnName(user);
        this.setSortingVO(columnName, this.phonenumber);
        this.getTotalUserManagementList(this.filterVoObject,this.searchValue);
      }
    }
    else if (user === UserList.userRole) {
      this.roleId = false;
      this.roleName = false;
      this.description = false;
      this.phonenumber = false;
      this.addedData = false;
      this.mapped = !this.mapped;
      this.Status = false;
      if (this.mapped) {
        const columnName = this.getEntityColumnName(user);
        this.setSortingVO(columnName, this.mapped);
        this.getTotalUserManagementList(this.filterVoObject,this.searchValue);
      } else {
        const columnName = this.getEntityColumnName(user);
        this.setSortingVO(columnName, this.mapped);
        this.getTotalUserManagementList(this.filterVoObject,this.searchValue);
      }
    }
    else if (user === UserList.addedDate) {
      this.roleId = false;
      this.roleName = false;
      this.description = false;
      this.phonenumber = false;
      this.addedData = !this.addedData;
      this.mapped = false;
      this.Status = false;
      if (this.addedData) {
        const columnName = this.getEntityColumnName(user);
        this.setSortingVO(columnName, this.addedData);
        this.getTotalUserManagementList(this.filterVoObject,this.searchValue);
      } else {
        const columnName = this.getEntityColumnName(user);
        this.setSortingVO(columnName, this.addedData);
        this.getTotalUserManagementList(this.filterVoObject,this.searchValue);
      }
    }
    else if (user === UserList.status) {
      this.roleId = false;
      this.roleName = false;
      this.description = false;
      this.phonenumber = false;
      this.addedData = false;
      this.mapped = false;
      this.Status = !this.Status;
      if (this.Status) {
        const columnName = this.getEntityColumnName(user);
        this.setSortingVO(columnName, this.Status);
        this.getTotalUserManagementList(this.filterVoObject,this.searchValue);
      } else {
        const columnName = this.getEntityColumnName(user);
        this.setSortingVO(columnName, this.Status);
        this.getTotalUserManagementList(this.filterVoObject,this.searchValue);
      }
    }

  }

  // method for getting corresponding entitiy name
  getEntityColumnName(item: string): string {
    let value = '';
    if (item) {
      let data =null
      if(!this.isAdmin){
        data= this.sortingEntityArray.find((column) => column.tableColumnName === item);
      }
      else{
        data= this.sortingEntityAuthorityArray.find((column) => column.tableColumnName === item);
      }
      if (data) {
        value = data.entityColumnName;
      }
    }
    return value;
  }

  sortingEntityArray = [
    {
      tableColumnName: "User ID",
      entityColumnName: "userId.userSequenceId",
      type: "String"
    },
    {
      tableColumnName: "User Name",
      entityColumnName: "userId.username",
      type: "String"
    },
    {
      tableColumnName: "Email Id",
      entityColumnName: "userId.email",
      type: "String"
    },
    {
      tableColumnName: "Phone Number",
      entityColumnName: "userId.mobileno",
      type: "String"
    },
    {
      tableColumnName: "User Role",
      entityColumnName: "roles",
      type: "String"
    },
    {
      tableColumnName: "Added Date",
      entityColumnName: "userId.createdDate",
      type: "Date"
    },
    {
      tableColumnName: "Status",
      entityColumnName: "userId.status",
      type: "Boolean"
    },

  ];

  sortingEntityAuthorityArray = [
    {
      tableColumnName: "User ID",
      entityColumnName: "userSequenceId",
      type: "String"
    },
    {
      tableColumnName: "User Name",
      entityColumnName: "username",
      type: "String"
    },
    {
      tableColumnName: "Email Id",
      entityColumnName: "email",
      type: "String"
    },
    {
      tableColumnName: "Phone Number",
      entityColumnName: "mobileno",
      type: "String"
    },
    {
      tableColumnName: "User Role",
      entityColumnName: "roles",
      type: "String"
    },
    {
      tableColumnName: "Added Date",
      entityColumnName: "createdDate",
      type: "Date"
    },
    {
      tableColumnName: "Status",
      entityColumnName: "status",
      type: "Boolean"
    },

  ];


  getFilterObjectArrayBasedOnLoginType():FilterObject[] {
    this.isAdmin=this.adminService.isAssociationUser();
    let filterObject: FilterObject[] = [];
    if (!this.isAdmin) {
      filterObject = [
        {
          columnName: 'userId.userSequenceId',
          condition: 'Like',
          aliasName: 'ManageUserList.User_ID',
          type: 'field',
          value: null,
          dropdown: [],
          radio: [],
          dataType: null
        },
        {
          columnName: 'userId.username',
          condition: 'Like',
          aliasName: 'ManageUserList.User_Name',
          type: 'field',
          value: [],
          dropdown: [],
          radio: [],
          dataType: null,
          isMax: false
        },
        {
          columnName: 'userId.email',
          condition: 'Like',
          aliasName: 'ManageUserList.Email_Id',
          type: 'field',
          value: [],
          dropdown: [],
          radio: [],
          dataType: null,
          isMax: false
        },
        {
          columnName: 'userId.mobileno',
          condition: 'Like',
          aliasName: 'ManageUserList.PHONE_NUMBER',
          type: 'field',
          value: [],
          dropdown: [],
          radio: [],
          dataType: null,
          isMax: false
        },
        {
          columnName: 'roles',
          condition: 'IN',
          aliasName: 'ManageUserList.User_Role',
          type: 'chips',
          value: [],
          dropdown: [],
          radio: [],
          dataType: null,
          isMax: false
        },
        {
          columnName: 'userId.createdDate',
          condition: 'BW',
          aliasName: 'ManageUserList.Added_Date',
          type: 'dates',
          value: [],
          dropdown: [],
          radio: [],
          dataType: null,
          isMax: false
        },
        {
          columnName: 'userId.status',
          condition: 'Equal',
          aliasName: 'ManageUserList.Status',
          type: 'radio',
          value: [],
          dropdown: [],
          radio: [
            {
              name: 'Customer_table.Active',
              value: false,
            },
            {
              name: 'Customer_table.InActive',
              value: false,
            },
          ],
          dataType: null,
          isMax: false
        },
      ];
    }
    else {
      filterObject = [
        {
          columnName: 'userSequenceId',
          condition: 'Like',
          aliasName: 'ManageUserList.User_ID',
          type: 'field',
          value: null,
          dropdown: [],
          radio: [],
          dataType: null
        },
        {
          columnName: 'username',
          condition: 'Like',
          aliasName: 'ManageUserList.User_Name',
          type: 'field',
          value: [],
          dropdown: [],
          radio: [],
          dataType: null,
          isMax: false
        },
        {
          columnName: 'email',
          condition: 'Like',
          aliasName: 'ManageUserList.Email_Id',
          type: 'field',
          value: [],
          dropdown: [],
          radio: [],
          dataType: null,
          isMax: false
        },
        {
          columnName: 'mobileno',
          condition: 'Like',
          aliasName: 'ManageUserList.PHONE_NUMBER',
          type: 'field',
          value: [],
          dropdown: [],
          radio: [],
          dataType: null,
          isMax: false
        },
        {
          columnName: 'roles',
          condition: 'IN',
          aliasName: 'ManageUserList.User_Role',
          type: 'chips',
          value: [],
          dropdown: [],
          radio: [],
          dataType: null,
          isMax: false
        },
        {
          columnName: 'createdDate',
          condition: 'BW',
          aliasName: 'ManageUserList.Added_Date',
          type: 'dates',
          value: [],
          dropdown: [],
          radio: [],
          dataType: null,
          isMax: false
        },
        {
          columnName: 'status',
          condition: 'Equal',
          aliasName: 'ManageUserList.Status',
          type: 'radio',
          value: [],
          dropdown: [],
          radio: [
            {
              name: 'Customer_table.Active',
              value: false,
            },
            {
              name: 'Customer_table.InActive',
              value: false,
            },
          ],
          dataType: null,
          isMax: false
        },
      ];
    }

    return filterObject;
  }

  // sorting condition method
  setSortingVO(value: string, condition: boolean) {
    if (value != null && condition != null) {
      this.sortingFilterVo.columnName = value;
      this.sortingFilterVo.isAscending = condition;
      this.sortingFilterVo.filterOrSortingType = "SORTING";
      this.filterVoObject = this.filterVoObject.filter((obj) => obj.filterOrSortingType !== 'SORTING');
    }
    this.filterVoObject.push(this.sortingFilterVo);
  }

  // sorting filter vo
  sortingFilterVo: FilterOrSortingVo =
    {
      columnName: "",
      condition: "",
      filterOrSortingType: "SORTING",
      intgerValueList: [],
      valueList: [],
      isAscending: false,
      type: "",
      value: "",
      value2: "",
    }


    // getting filterOrSortingVo List from Search Bar
    getfilterVoArray(event:any){
      this.searchValue="";
      if(event){
        const filterFromSearch: FilterOrSortingVo[] = event;
        filterFromSearch.forEach(element=>{
          if((element.columnName==="createdDate" || element.columnName==='userId.createdDate')
            && element.filterOrSortingType==='FILTER'){
                if(element.value && element.value2===null){
                    element.condition='Ge'
                }
                else if(element.value===null && element.value2){
                    element.value=element.value2;
                    element.value2=null;
                    element.condition='Le'
                }
          }
        })
        filterFromSearch.forEach(filter => {
          const type = this.filterTypeFinder(filter);
          filter.type=type;
        });
        this.filterVoObject = filterFromSearch;
        this.getTotalUserManagementList(this.filterVoObject, this.searchValue);
      }
    }

    filterTypeFinder(filter: FilterOrSortingVo) : string{
      let type='';
     if(filter){
        let data= null;
        if(!this.isAdmin){
          data = this.sortingEntityArray.find((m)=>m.entityColumnName===filter.columnName);
        }
        else{
          data=this.sortingEntityAuthorityArray.find((column) => column.entityColumnName === filter.columnName);
        }
        if(data){
          type=data.type;
          return type;
        }
     }
     return type;
  }

  searchItem(event){
    this.searchValue =event;
    this.getTotalUserManagementList(this.filterVoObject ,this.searchValue);
  }
  getTotalUserManagementList(filterVo: FilterOrSortingVo[], searchValue:string) {
    this.pageIndex=1;
      this.service.getUserManagementTableCount(filterVo, searchValue).subscribe((data)=>{
        this.totalLength = data['content'];
        const totalNUmber = this.totalLength / 10;
        if (this.isFloat(totalNUmber)) {
          this.maximum =  Math.floor(totalNUmber+1);
        }else{
          this.maximum = totalNUmber;
        }
        this.minLength =0;
        this.getTableList(this.minLength, this.maxLength, filterVo, this.searchValue);
        this.maximumcount(this.TEN);
      })
  }

    isFloat(n: number): boolean {
    return Number(n) === n && n % 1 !== 0;
  }

  onpagebackward() {

    if (this.userDetailsList != null) {
      this.dataNotFound = false;
    }


  }

  onKeyDown(event: KeyboardEvent) {
    if (event.keyCode === 190) {
      event.preventDefault();
    }
  }

  downloadUser(){
    const min =this.ZERO;
    const max = this.totalLength;
    this.service.userDownloadMethoad(min, max,  this.filterVoObject, this.searchValue).subscribe((response) =>{
      if (response.size === 0) {
        this.toaster.error(this.translate.instant('Toaster_error.invalid_report_generate_download'));
      } else {
        this.donwloadFile(response);
      }
    });
  }

  private donwloadFile(value: any) {
    const blob = new Blob([value], { type: 'application/vnd.ms-excel' });
    const file = new File([blob], 'report.xlsx', {
      type: 'application/vnd.ms-excel',
    });
    const fileURL = URL.createObjectURL(file);
    const a = document.createElement('a');
    a.href = fileURL;
    a.target = '_blank';
    a.download = 'User Management' + '.xlsx';
    document.body.appendChild(a);
    a.click();
  }

  getTableList(min: number, max: number, filterVo: FilterOrSortingVo[], searchValu:string) {
    this.service.getUserManagementTableList(min, max, filterVo, searchValu).subscribe((data) => {
      this.dataSource = null;
      this.tableList = []
      this.userDetailsList = data['content'];

      if (this.userDetailsList === null || this.userDetailsList.length === 0) {
        this.dataNotFound = true;
        this.isDownloadDisable=true;
      }else{
        this.dataNotFound = false;
        this.isDownloadDisable=false;
      }
      this.userDetailsList.forEach(element => {
        this.userName = element.userName;
        this.addedDate = element.addedDate;
        this.status = element.status ? 'Active' : 'InActive';
       if(element.isDisable){
        this.status = 'Disabled'
       }
        this.userIdentity = element.userIdentity;
        this.userRoleName = [];
        this.allUserRoleName = [];
        let index = 0;
        element.userRoleList.forEach((val) => {
          if (index <= 3) {
            this.userRoleName.push(val.roleName);
            index++;
          }
          this.allUserRoleName.push(val.roleName);
        });
        this.emailId = element.emailId;
        this.userId = element.userId;
        this.phoneNumber = element.phoneNumber;
        this.sequenceUserId = element.userSeqId;
        this.tableList.push({
          userName: this.userName,
          addedDate: this.addedDate,
          phoneNumber: this.phoneNumber,
          userSeqId: this.sequenceUserId,
          status: this.status,
          userRoleName: this.userRoleName,
          emailId: this.emailId,
          userId: this.userId,
          allUserRoleName: this.allUserRoleName,
          userIdentity:this.userIdentity,
          isDisable: element.isDisable,
                  });
      });
      this.dataSource = new MatTableDataSource<UserDetailsList>(this.tableList);

    });
  }
  adduser() {
    const obj = {
      listpage: false,
      addpage: true
    }
    this.service.setAddNew(true);
    this.router.navigateByUrl('/usermanagement/user/manage/0/' + null);
  }
  backbtn() {
    this.router.navigateByUrl('/usermanagement/user');
  }

  changePage(event) {
    if (event.pageIndex != this.ZERO) {
      this.maxLength = event.pageSize;
      this.pageIndex = event.pageIndex + 1;
      this.minLength = event.pageSize * event.pageIndex;
      this.endingIndex = event.pageSize;
      if (this.pagesize != event.pageSize) {
        this.maximumcount(event.pageSize);

      }
    } else {
      this.pageIndex = 1;
      this.maxLength = event.pageSize;
      this.minLength = event.pageIndex;
      this.endingIndex = event.pageSize;
      if (this.pagesize != event.pageSize) {
        this.maximumcount(event.pageSize);
      }
    }
    this.getTableList(this.minLength, this.maxLength, this.filterVoObject, this.searchValue);
  }


  maximumcount(event) {
    this.pagesize = event;
    this.maximum = this.totalLength / this.pagesize
    this.remainder = this.totalLength % this.pagesize;
    if (this.remainder != 0) {
      this.maximum =  Math.floor(this.maximum + 1);
    }
  }


  pageIndex = 1;
  pageindex() {
    this.searchSubject.next(this.pageIndex);
  }

  changePageIndex(){
    if(this.pageIndex > 0) {
      if(this.pageIndex > this.maximum) {
        const numbDigit = this.maximum.toString().length;
        let numString =this.pageIndex.toString();
        numString = numString.substring(0, numbDigit);
        if(Number(numString) >= this.maximum ){
          numString = this.maximum.toString();
        }
        this.pageIndex = this.maximum === 0 ? 1 : Number(numString);
      }
      this.maxLength = this.endingIndex;
      this.minLength = this.endingIndex * (this.pageIndex - 1);
      this.getTableList(this.minLength, this.maxLength, this.filterVoObject , this.searchValue);
      // if(!this.pageIndex){
      // }else{
      //   this.getTableList(this.minLength, this.maxLength, this.filterVoObject, this.searchValue);
      // }
    }else{
      // this.pageIndex = 1;
      this.minLength = 0;
      this.maxLength = 10;
      this.getTableList(this.minLength, this.maxLength, this.filterVoObject, this.searchValue);
    }
  }

  onEditUser(data: any) {
    if(!data.isDisable){
      this.router.navigateByUrl('/usermanagement/user/Edit/0/' + data.userIdentity);
    }
  }

  onDeleteUser(data:any) {
    if(!data.isDisable){
    const dialogRef = this.dialog.open(PopupComponent, {
      width: '300px',
      height: 'auto',
      data: {
        message: "Are you sure you want to delete?",
        okButton: "Ok",
        cancelButton: "Cancel",
        isUser:true,
        role:true,
        delete:"deleteText",
        name : 'User',
        status : data.status
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const inputDate = new Date(result);
        const timeZoneOffsetMinutes:number = new Date().getTimezoneOffset();
        inputDate.setMinutes((inputDate.getMinutes() - timeZoneOffsetMinutes) + 1439 );
        this.userListDissabelDto.expiredDate = inputDate;
        this.userListDissabelDto.identity = data.identity;
        this.userListDissabelDto.userId = data.userId;
        this.userListDissabelDto.isMapped = data.Mapped === "UnMapped"?false:true;
        this.service.deleteUserDetails(this.userListDissabelDto).subscribe((response) => {
          if (response) {
            this.toaster.success(this.translate.instant('Toaster_success.user_deleted'));
            this.ngOnInit()
          }
        })
      }
    });
  }
  }

  userRoleFieldList: Field[];
  menuListDto: UserMenuDto[];
  metaDataDto: MetaDataDto;

  cloneUser(data: any) {
    if(!data.isDisable){
    this.router.navigateByUrl('/usermanagement/user/Clone/1/' + data.userIdentity);
    }
  }

  downloadUserList() {
    this.service.downloadUserExcelList().subscribe((response) => {
      if (response) {
        this.toaster.success(this.translate.instant('Toaster_success.download_excel'));
        const blob = new Blob([response],
          { type: 'application/vnd.ms-excel' });
        const file = new File([blob], 'report.xlsx',
          { type: 'application/vnd.ms-excel' });
        const fileURL = URL.createObjectURL(file);
        const a = document.createElement('a');
        a.href = fileURL;
        a.target = '_blank';
        a.download = "Users_List" + '.xlsx';
        document.body.appendChild(a);
        a.click();
      }
    })
  }

  getEnabledPrivilegeFromMultipleRoles(sectionDataArray:AccessMappingSectionDto[]):AccessMappingSectionDto[]{
    const result: AccessMappingSectionDto[] = Object.values(
      sectionDataArray?.reduce((accumulator, obj) => {
        let accessMappingAccumulator:AccessMappingSectionDto= null;
        if (!accumulator[obj.sectionName]) {
          accumulator[obj.sectionName] = obj;
        }
        accessMappingAccumulator=accumulator[obj.sectionName];
        if(obj.isView){          
          accessMappingAccumulator.isView=obj.isView;
        }
        if(obj.isClone){
          accessMappingAccumulator.isClone=obj.isClone;
        }
        if(obj.isDisable){
          accessMappingAccumulator.isClone=obj.isDisable;
        }
        if(obj.isDownload){
          accessMappingAccumulator.isDownload=obj.isDownload;
        }
        if(obj.isEdit){
          accessMappingAccumulator.isEdit=obj.isEdit;
        }
        if(obj.isNotification){
          accessMappingAccumulator.isNotification=obj.isNotification;
        }
        accumulator[obj.sectionName]=accessMappingAccumulator;
        return accumulator;
      }, {} as Record<string, AccessMappingSectionDto>)
    );
    
    return result
  }


  getPageAccessData(): void {
    this.appService.getPageAccess(this.appConst.PAGE_NAME.USERMANAGEMENT.USERMANAGEMENT_USER.USERMANAGEMENT_USER_LIST.PAGE_IDENTITY)
      .subscribe((response: any) => {
        if (response) {
          this.userListPageAccessMap = response.content;
          this.userListPageAccessMap.sectionData=this.getEnabledPrivilegeFromMultipleRoles(this.userListPageAccessMap?.sectionData);
          this.isUserListPageEnabled = this.userListPageAccessMap?.isEnabled;
          this.previewReportPageAccessDto =  this.userListPageAccessMap.sectionData.find(x => x.sectionName ===MenuSectionNames.User_List);
          this.addNewUserPageAccessDto =  this.userListPageAccessMap.sectionData.find(x => x.sectionName ===MenuSectionNames.Add_New_User);
          if (this.isUserListPageEnabled) {
            this.doProcess();
          }
        }
        this.getTotalUserManagementList(this.filterVoObject,this.searchValue);
      });
  }

  getPrivillege(): void {
    this.appService.getPrivilegeForPage(this.appConst.PAGE_NAME.USERMANAGEMENT.USERMANAGEMENT_USER.USERMANAGEMENT_USER_LIST.PAGEID)
    .subscribe((response: any) => {
        if (response) {
          this.userListPrivillegeInfo = response.content;
        }
    });
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if (this.userListPrivillegeInfo && this.userListPrivillegeInfo.length > 0) {
      const privillege = this.userListPrivillegeInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege.isEnabled;
    }
    return isEnabled;
  }
}

export class UserDetailsList {
  userName: string;
  addedDate: string;
  status: string;
  userRoleName: string[];
  phoneNumber: string;
  userSeqId: string;
  emailId: string;
  userId: number;
  allUserRoleName: string[];
  userIdentity:string;
  isDisable: boolean;
  }
