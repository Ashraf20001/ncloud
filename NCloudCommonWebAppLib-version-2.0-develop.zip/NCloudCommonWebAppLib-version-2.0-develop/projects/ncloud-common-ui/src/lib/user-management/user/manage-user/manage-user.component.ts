import { ToastrService } from 'ngx-toastr';

import { MetaDataDto } from '../../../dto/entity-management/meta-data-dto';
import { AccessMappingSectionDto } from '../../../dto/Filter-dto/section-dto';
// import { MenuDto } from './../../../models/user-role-management/menu-dto';
import { UserMenuDto } from '../../../dto/user-menu-dto';

import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';

import { Field } from '../../../dto/entity-management/field';
import { FieldGroupDTO } from '../../../dto/entity-management/field-group-dto';
import { UserManagementService, CardDetails } from './../../../service/user-management.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';

import { appConst } from '../../../const/app.const';
import { AccessMappingPageDto } from '../../../dto/access-Mapping-PageDto ';
import { AppService } from '../../../service/app.service';
import { AdminService } from '../../../service/admin.service';


import { MenuSectionNames } from '../../../const/enum';
import { TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs';
import { ErrorHandlerDirective } from '../../../directive/errorHandler.directive';

@Component({
  selector: 'app-manage-user',
  templateUrl: './manage-user.component.html',
  styleUrls: ['./manage-user.component.scss']
})

export class ManageUserComponent implements OnInit,OnDestroy{
  reportdata: FormGroup;
  isEditUser = false;
  roleNameList: (string|number)[]=[];
  editId: any = null;
  isClone = 0;
  isNew = true;
  inputValue:any;
  appConst = appConst;
  addUserPageAccessMap: AccessMappingPageDto;
  appUserPrivillegeInfo: any;
  isAddUserPageEnabled = true;
  minLength = 0;
  maxLength = 10;
  userSectionData: AccessMappingSectionDto;
  isAssociationUser:boolean;
  dropdownData = [{"identity": "1","userTypeName": "Employee"},{"identity": "2","userTypeName": "Traffic Authority"}]
  addNewUserPageAccessDto: AccessMappingSectionDto;
  platformId: any;
  isAllowedToSave= false;
  addNewSubscription: Subscription;
  value: boolean;
  platformIdentity: string;
  constructor(private router: Router,private toaster:ToastrService,private managementService:UserManagementService,
    private appService: AppService, private formBuilder: FormBuilder,private route : ActivatedRoute, private errorHandlerDirective: ErrorHandlerDirective, private adminService: AdminService
    ,private translate : TranslateService){
      this.isAssociationUser = this.adminService.isAssociationUser();
    this.reportdata = this.formBuilder.group({
      selectedInsuredCompany: ["", [Validators.required]],
      selectedTpCompany: ["", [Validators.required]]
    });
   this.addNewSubscription=this.managementService.ClickAdd$.subscribe(value=>{
      if(value==true){
        this.roleOfCompany=[];
        this.roleOfCompany=[];
        this.hashmap.clear();
        this.stringOfId=''
      }
    })

    this.route.params.subscribe((params: any) => {
      this.editId = params['identity'];
      this.isClone = params['isClone'] !== undefined ? JSON.parse(params['isClone']) : false;
      if(this.editId && this.editId !== 'null') {
        this.isNew = false;
        this.cloneuserheader=false;

        if(this.isClone === 0) {
          this.callAllMethodsInOninit(this.editId);
        } else {
          this.cloneuserheader=true;
          this.cloneUser(this.editId);
        }
      } else {
        this.isNew = true;
        this.cloneuserheader=false;

      }
    });
  }
  ngOnDestroy(): void {
    this.addNewSubscription.unsubscribe();
  }

  panelOpenState = false;
   isdisabled=true;
  cloneuserheader=false;

  ngOnInit(): void {
   
    
     const platformDetails = JSON.parse(sessionStorage.getItem("platformDetails") ?? "{}");
    this.platformId = platformDetails.platformId;
    this.platformIdentity = platformDetails.platformIdentity;

    this.getPageAccessData();
    // this.callAllMethodsInOninit(null);
    // this.getUserDetail(this.editId);
    if(this.editId == 'null'){
      this.getAllRoles(this.minLength, this.maxLength);
    }

  }

  doProcess(): void {
    this.getPrivillege();
    this.getTotalUserRoleList();
    this.roleNameList=[];
    this.roleOfCompany = null;
   this.convertIdToCompany = [];
  }

  callAllMethodsInOninit(id:string){
    this.hashmap.clear();
    this.getAllRoles(this.minLength,this.maxLength)
    // this.getUserDetail(id);

  }


  cloneUser(id:string){
    this.hashmap.clear();
    this.getAllRoles(this.minLength,this.maxLength)

  }

  userRoleFieldList:Field[];
  menuListDto:UserMenuDto[];
  metaDataDto:MetaDataDto;
  userId :any = null;


  selectedCompanyFromDb:string[] = [];
  convertIdToCompany:string[] = [];
  companyName:string;
  isActive:boolean;
  roleIdList:string[] = [];

  setRolesInMap(){
    this.userRoleFieldList.forEach(element => {
      if (element.fieldType==='MultiSelect' && element.value!== null && element.value!== undefined) {
       this.selectedCompanyFromDb = element.value.split(',',5)
      }
    });
    if (this.selectedCompanyFromDb!==undefined) {
       this.stringOfId  = ",";
      this.convertIdToCompany = []
      this.selectedCompanyFromDb.forEach(element => {
       this.companyName = this.hashmap1.get(Number(element.trim()));
        if( this.companyName !== undefined){
          this.stringOfId = this.stringOfId +Number(element.trim())
        this.convertIdToCompany.push(this.companyName);
        this.hashmap.set(this.companyName,element.trim());
        this.getRoleName(this.selectedCompanyFromDb);
        }
          // this.roleOfCompany.push(this.companyName);
      });

      this.stringOfId = this.selectedCompanyFromDb.join(',');
    }
    this.roleOfCompany = null;
    this.roleOfCompany = this.convertIdToCompany;
  }

  getDropdownInput(items: Field) {

  if (items.fieldType === 'Dropdown') {
 return true;
  } else {
    return false;
   }

  }


  getUserDetail(id:string){
    this.roleNameList=[];
    const pageId = "8b891619527447b38b2090890cf14cc8";
    if (id!==undefined) {
      this.userId = id;
    }
    this.metaDataDto = null;
    this.menuListDto = null;
    this.currentSection = null;
    this.managementService.getUserDetails(pageId,this.userId).subscribe((response)=>{
      if (response) {
        this.isActive = response['content']['isActive'];
        this.metaDataDto = response['content']['userDetails'];
        this.userRoleFieldList = response['content']['userDetails'].sectionList[0].fieldList;
        this.menuListDto = response.content.enableNotification?.menuData;
        // this.currentSection = this.menuListDto[0].pageData[0].sectionData
        if (!this.isAssociationUser) {
          this.userRoleFieldList.forEach(element => {
            if (element.columnName === 'umAssociationUserType') {
              const index = this.userRoleFieldList.indexOf(element);
              this.userRoleFieldList.splice(index, 1);
            }
          });
        }
        this.userRoleFieldList.forEach(element => {
          if(this.isClone !== 0){
            if (element.columnName === 'umUserName' || element.columnName === 'umPassword' || element.columnName === 'umEmailId') {
              element.value ="";
            }
          }
        });

        this.setRolesInMap();
        if(this.isClone === 1){
          this.metaDataDto.sectionList[0].fieldList.forEach(element => {
            if(element.fieldName === 'umUserId') {
              element.value = null;
            }
          });
        }
      }
    })

  }

cloneUserDetails(id:string){
  const pageId = "8b891619527447b38b2090890cf14cc8";
  if (id!==undefined) {
    this.userId = id;
  }
  this.metaDataDto = null;
  this.menuListDto = null;
  this.currentSection = null;
  this.managementService.getUserDetails(pageId,this.userId).subscribe((response)=>{
    if (response) {
      this.isActive = response['content']['isActive'];
      this.metaDataDto = response['content']['userDetails'];
      this.userRoleFieldList = response['content']['userDetails'].sectionList[0].fieldList;
      this.menuListDto = response['content']['enableNotification'];
      // this.currentSection = this.menuListDto[0]?.pageData[0].sectionData
      this.setRolesInMap();
      this.metaDataDto.sectionList[0].fieldList.forEach(element => {
        if(element.fieldName !== 'umUserId') {
          element.value = null;
        }
      });
    }
  })
}




  closeicon(){
    this.router.navigateByUrl('/usermanagement/user');
  }
  backbtn(){
    this.managementService.setUserSubscription(true);
    this.router.navigateByUrl('/usermanagement/user');
    // location.reload();
  }



  getStringInput(items: Field) {
    if (items.fieldType === 'String') {
      return true;
    }
    return false;
  }

  getTextInput(items: Field) {
    if (items.fieldType === 'text') {
      return true;
    }
    return false;
  }

  getEmailInput(items: Field) {
    if (items.fieldType === 'Email') {
      return true;
    }
    return false;
  }
  getNumberInput(items: Field) {
    if (items.fieldType === 'Integer') {
      if(items.value !== null){
        this.isEditUser = true;
      }
      return true;
    }
    return false;
  }
  getPasswordInput(items: Field) {
    if (items.fieldType === 'Password') {
      if(items.value !== null){
        this.isEditUser = true;
      }
      return true;
    }
    return false;
  }
  getMultiSelectInput(items: Field) {
    if (items.fieldType === 'MultiSelect') {
      return true;
    }
    return false;
  }
test = ['admin,tests']
  menuDataDetails = [
    {
      menuName:'payable'
    },
    {
      menuName:'Receivable'
    }
  ]

  roleOfCompany: string[] = [];
  totalRole: string;

  selectedRole: string[]=[];


   hashmap = new Map<string, string>();
   hashmap1 = new Map<number, string>();

  separatorKeysCodes: number[] = [];

  isReceivableShow = false;
  isPayableShow = false;
  rolesList:number[] = [];


  selectedRoleName(event: MatAutocompleteSelectedEvent): void {
    this.isAllowedToSave= false;
    // this.InsuredCompany.push(event.option.viewValue);
    if ((event.option.viewValue || '').trim()) {
      if(!this.roleOfCompany.includes(event.option.viewValue.trim().split(",")[1])) {
        this.roleOfCompany.push(event.option.viewValue.trim().split(",")[1]);
         this.hashmap.set(event.option.viewValue.trim().split(",")[1],event.option.viewValue.trim().split(",")[0])
      }
    }
    this.roleIdList =  Array.from(this.hashmap.values());
    this.stringOfId = this.roleIdList.join(",");
    this.reportdata.controls['selectedInsuredCompany'].setValue(this.roleOfCompany);
    this.selectedRole = this.roleOfCompany;
    this.totalRole = this.roleOfCompany.length.toString();
    // this.stringOfId ="";
    // this.selectedRole.forEach(element => {
    //  this.stringOfId = this.stringOfId+ ',' + this.hashmap.get(element)
    // });
    this.rolesList =[];
    const itr = this.hashmap.values();
    for (const value of itr) {
      this.rolesList.push(Number(value?.trim()));
     }
    this.getRoleName(this.rolesList);

  }

  getRoleName(rolesList:any){

    let roleNameList = rolesList.map(Number);
         this.managementService.getPageBasedOnRoles(roleNameList).subscribe((response)=>{
      if (response) {
        this.isReceivableShow = response['content'].receivable;
        this.isPayableShow = response['content'].payable;
      }
     })
  }

  stringOfId:string;
  // enableSave(){
  //   this.isAllowedToSave= false;
  // }

  removeRoleName(ListName: string): void {
    const index = this.roleOfCompany.indexOf(ListName);
    this.hashmap.delete(ListName);
    if (index >= 0) {
      this.roleOfCompany.splice(index, 1);
    }
    // this.stringOfId = ",";
    // this.selectedRole.forEach(element => {
    //   this.stringOfId = this.stringOfId+ ',' + this.hashmap.get(element)
    // });
    this.roleIdList = Array.from(this.hashmap.values())
    this.stringOfId = this.roleIdList.join(',');
    this.rolesList =[];
    const itr = this.hashmap.values();
    for (const value of itr) {
      this.rolesList.push(Number(value.trim()));
     }

     this.managementService.getPageBasedOnRoles(this.rolesList).subscribe((response)=>{
      if (response) {
        this.isReceivableShow = response['content'].receivable;
        this.isPayableShow = response['content'].payable;
      }
     })
  }
  typedvalue:string;

  search(event){
    this.typedvalue=event.target.value.toLowerCase();
   
    
    const filterValue =event.target.value.toLowerCase();
    if(filterValue != null && filterValue != undefined && filterValue !==""){
      let SearchList= this.allRolesCopy.filter(data => data.roleName.toLocaleLowerCase().includes(filterValue));
      this.allRoles =SearchList;
    }else{
      this.allRoles = this.allRolesCopy;
    }
  }

  allRoles:CardDetails[];
  allRolesCopy:CardDetails[];

  getTotalUserRoleList(){
    this.minLength =0;
    this.maxLength = 0;
    this.getAllRoles(this.minLength, this.maxLength);
  }

  getAllRoles(min:number,max:number){
    const platformIdentity = sessionStorage.getItem("platformIdentity");
      this.managementService.getCardDetails(min,max,[],"").subscribe((response)=>{
        if (response) {
          this.allRoles = response['content'].filter(x => x.isDisableRole === false);
          this.allRolesCopy =  this.allRoles;
          this.getUserDetail(this.editId);
          this.allRoles.forEach(element => {
            this.hashmap1.set(element.roleId,element.roleName);
          });

          // this.route.params.subscribe((params: any) => {
          //   this.editId = params['identity'];
          //   this.isClone = params['isClone'] !== undefined ? JSON.parse(params['isClone']) : false;
          //   if(this.editId && this.editId !== 'null') {
          //     this.isNew = false;
          //     if(this.isClone === 0) {
          //       this.callAllMethodsInOninit(this.editId);
          //     } else {
          //       this.cloneUser(this.editId);
          //     }
          //   } else {
          //     this.isNew = true;
          //   }
          // });
        }
      })


  }

  multiSelect:any;
  saveUser(){


    this.metaDataDto.sectionList[0].fieldList.forEach(element => {
      if (element.fieldType==="MultiSelect" && element.value!== undefined && this.stringOfId!== undefined && this.stringOfId !== null) {
        element.value = this.stringOfId.substring(0,100);
        let SearchListData= this.allRolesCopy.filter(data => data.roleName.toLocaleLowerCase().includes(element.value));
       if(SearchListData !== null && SearchListData.length !== 0){
        this.toaster.error(this.translate.instant('Toaster_error.Please_select_the_valid_user_role'));
       }else{
        this.isAllowedToSave= true;
        this.managementService.sendUserData(this.metaDataDto,this.menuListDto,this.isActive,this.platformIdentity).subscribe((response)=>{
          if (response) {
            this.toaster.success(this.translate.instant('Toaster_success.save'));
            this.isAllowedToSave= false;
            this.backbtn();
          }
        },(error:Response)=>{
          this.isAllowedToSave= false;
          this.errorHandlerDirective.getMessage(error);
       })
       }
       
      }
    })
   
  // }



  }

  currentSection:AccessMappingSectionDto[];
  menuDataName:string;


  selectedSection(sectionData:UserMenuDto,name:string){
    this.currentSection = null;
    this.currentSection = sectionData.pageData[0].sectionData
    this.menuDataName = name;
    // this.isAllowedToSave= true;
  }

  imageAssetList = [
    {
      image:"assets/reportloss/stage-icons/Insured Details.svg",
      title:"Insured Details"
    },
    {
      image:"assets/reportloss/stage-icons/TP Details.svg",
      title:"TP Details"
    },
    {
      image:"assets/reportloss/stage-icons/Loss Details.svg",
      title:"Loss Details"
    },
    {
      image:"assets/reportloss/stage-icons/Police Report.svg",
      title:"Police Report"
    },
    {
      image:"assets/reportloss/stage-icons/Garage Details.svg",
      title:"Garage Details"
    },
    {
      image:"assets/reportloss/stage-icons/Survey Details.svg",
      title:"Survey Details"
    },
    {
      image:"assets/reportloss/stage-icons/Survey Report.svg",
      title:"Survey Report"

    },
    {
      image:"assets/reportloss/stage-icons/Recovery Details.svg",
      title:"Recovery Details"
    },
    {
      image:"assets/reportloss/stage-icons/Reserve Review.svg",
      title:"Reserve Review"
    },
    {
      image:"assets/reportloss/stage-icons/Garage Invoice.svg",
      title:"Garage Invoice"
    },
    {
      image:"assets/reportloss/stage-icons/Debit Note.svg",
      title:"Debit Note"
    },
    {
      image:"assets/reportloss/stage-icons/Credit Note.svg",
      title:"Credit Note"
    },
    {
      image:"assets/reportloss/stage/Notification Stage.svg",
      title:"Notification Stage"
    },
    {
      image:"assets/reportloss/stage/Claim Inspection Stage.svg",
      title:"Claim Inspection Stage"
    },
    {
      image:"assets/reportloss/stage/Liability Confirmation Stage.svg",
      title:"Liability Confirmation Stage"
    },
    {
      image:"assets/reportloss/stage/Settlement Stage.svg",
      title:"Settlement Stage"
    }
    ,
    {
      image:"/assets/user_m_receivables.svg",
      title:"Receivable"
    },
    {
      image:"assets/user_m_payables.svg",
      title:"Payable"
    }
  ]


  getImgs(iteam:UserMenuDto)
  {
    let src='';
    const img = this.imageAssetList.find((img) => img.title === iteam.menuName);
    if(img) {
          src = img.image;
        }
        return src;
  }

  getImg(item:AccessMappingSectionDto){
    // this.isAllowedToSave= true;
    let src = '';
    const img = this.imageAssetList.find((img) => img.title === item.sectionName);
    if(img) {
          src = img.image;
        }
        return src;
  }

  getStageImg(item:UserMenuDto){
    let src = '';
    const img = this.imageAssetList.find((img) => img.title === item.menuName);
    if(img) {
          src = img.image;
        }
        return src;
  }

  checkBoxSection(section:AccessMappingSectionDto){
    if (section.sectionData!==null) {
      section.sectionData.forEach(element => {
        element.isNotification = !section.isNotification;
    });
    }
  }
  allSelected=false;

checkAll(allSelected:boolean){
  this.currentSection.forEach(element => {
    element.isNotification = allSelected

    element.sectionData.forEach(element1 => {
      element1.isNotification = allSelected
    });
  });

}
checkisOpenreturn:boolean
checkIsOpen(name:string){
  if (name==='Receivable') {
    this.checkisOpenreturn=this.isReceivableShow;
    return this.isReceivableShow;
  }
  if (name==='Payable') {
    this.checkisOpenreturn=this.isPayableShow;
    return this.isPayableShow;
  }
  return this.checkisOpenreturn
}

makePassword:boolean
makePasswordReadOnly(aliasName:string){
  if(aliasName==="Password" && this.isEditUser === true)
    this.makePassword=true;
  return this.makePassword=true;

}


getEnabledPrivilegeFromMultipleRoles(sectionDataArray:AccessMappingSectionDto[]):AccessMappingSectionDto[]{
  const result: AccessMappingSectionDto[] = Object.values(
    sectionDataArray?.reduce((accumulator, obj) => {
      let accessMappingAccumulator:AccessMappingSectionDto= null;
      if (!accumulator[obj.sectionName]) {
        accumulator[obj.sectionName] = obj;
      }
      accessMappingAccumulator=accumulator[obj.sectionName];
      if(obj.isView){          
        accessMappingAccumulator.isView=obj.isView;
      }
      if(obj.isClone){
        accessMappingAccumulator.isClone=obj.isClone;
      }
      if(obj.isDisable){
        accessMappingAccumulator.isClone=obj.isDisable;
      }
      if(obj.isDownload){
        accessMappingAccumulator.isDownload=obj.isDownload;
      }
      if(obj.isEdit){
        accessMappingAccumulator.isEdit=obj.isEdit;
      }
      if(obj.isNotification){
        accessMappingAccumulator.isNotification=obj.isNotification;
      }
      accumulator[obj.sectionName]=accessMappingAccumulator;
      return accumulator;
    }, {} as Record<string, AccessMappingSectionDto>)
  );
  
  return result
}



  getPageAccessData(): void {
    this.appService.getPageAccess(this.appConst.PAGE_NAME.USERMANAGEMENT.USERMANAGEMENT_USER.USERMANAGEMENT_USER_LIST.PAGE_IDENTITY)
    .subscribe((response: any) => {
      if(response) {
        this.addUserPageAccessMap = response.content;
        this.userSectionData = this.addUserPageAccessMap.sectionData ? this.addUserPageAccessMap.sectionData[0] : undefined;
        this.addUserPageAccessMap.sectionData=this.getEnabledPrivilegeFromMultipleRoles(this.addUserPageAccessMap?.sectionData);
        this.addNewUserPageAccessDto =  this.addUserPageAccessMap.sectionData.find(x => x.sectionName ==="Add New User");
        this.isAddUserPageEnabled = this.addUserPageAccessMap?.isEnabled;
        if(this.isAddUserPageEnabled) {
          this.doProcess();
        }
      }
    });
  }

  getPrivillege(): void {
    this.appService.getPrivilegeForPage(this.appConst.PAGE_NAME.USERMANAGEMENT.USERMANAGEMENT_USER.USERMANAGEMENT_USER_ADD.PAGEID)
    .subscribe((response: any) => {
      this.appUserPrivillegeInfo = response?.content;
    });
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.appUserPrivillegeInfo && this.appUserPrivillegeInfo.length > 0) {
      const privillege = this.appUserPrivillegeInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege.isEnabled;
    }
    return isEnabled;
  }
}
