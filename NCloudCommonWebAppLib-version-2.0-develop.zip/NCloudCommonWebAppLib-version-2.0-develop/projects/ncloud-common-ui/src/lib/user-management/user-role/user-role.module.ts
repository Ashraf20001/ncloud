
import { DemoMaterialModule } from '../../common-components/angularMaterialModules/material-module';
import { BreadcrumbService } from 'xng-breadcrumb';
import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { UserRoleComponent } from "./user-role.component";
import { UserRoleRoutingModule } from "./user-role-routing.module";
import {  UserRoleListComponent } from "./user-role-list/user-role-list.component";
import { ManageUserRoleComponent } from "./manage-user-role/manage-user-role.component";
import {  TranslateModule } from '@ngx-translate/core';


import {CdkAccordionModule} from '@angular/cdk/accordion';
import { RoleCardComponent } from './card-component/role-card.component';
import { AppCommonModule } from "../../common-components/app-common.module";


@NgModule({
    declarations: [
        UserRoleComponent,
        UserRoleListComponent,
        ManageUserRoleComponent,
        RoleCardComponent
    ],
    exports: [
        UserRoleComponent,
        UserRoleListComponent,
        ManageUserRoleComponent,
        RoleCardComponent
    ],
    providers: [
        BreadcrumbService,
    ],
    imports: [
        CommonModule,
        FormsModule,
        UserRoleRoutingModule,
        TranslateModule,
        DemoMaterialModule,
        CdkAccordionModule,
        AppCommonModule
    ]
})

export class UserRoleModule{
}
