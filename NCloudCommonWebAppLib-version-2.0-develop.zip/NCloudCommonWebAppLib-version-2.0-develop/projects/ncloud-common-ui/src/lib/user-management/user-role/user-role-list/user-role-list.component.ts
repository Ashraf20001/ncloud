import { AfterViewInit, ChangeDetectorRef, Component, OnDestroy, ViewChild } from '@angular/core';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { TranslateService } from '@ngx-translate/core';
import { UserDataDTO } from '../../../dto/user-data-dto';
import { I18nServiceService } from '../../../service/i18n-service.service';
import { CardDetails, UserManagementService } from './../../../service/user-management.service';
//import { UserListService } from 'src/app/service/user-list.service';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subject, Subscription, debounceTime, zip } from 'rxjs';
import { BreadcrumbService } from "xng-breadcrumb";
import { PopupComponent } from '../../../common-components/popup/popup.component';
import { appConst } from '../../../const/app.const';
import { MenuSectionNames } from '../../../const/enum';
import { FilterObject } from '../../../dto/Filter-dto/filter-object';
import { FilterOrSortingVo } from '../../../dto/Filter-dto/filter-object-backend';
import { AccessMappingSectionDto } from '../../../dto/Filter-dto/section-dto';
import { AccessMappingPageDto } from '../../../dto/access-Mapping-PageDto ';
import { userDissableDto } from '../../../dto/disable-dto';
import { AppService } from '../../../service/app.service';
@Component({
  selector: 'app-user-role-list',
  templateUrl: './user-role-list.component.html',
  styleUrls: ['./user-role-list.component.scss']
})

export class UserRoleListComponent implements OnDestroy,AfterViewInit{
  show = true;
  showAddUser = true;
  addScreen: boolean;
  tableList: UserDataDTO[] = [];
  userId: any;
  currentLang = 'English';
  totalLength: number;
  showtabledata: UserDataDTO[];
  ZERO = 0;
  TEN = 10;
  cardList: CardDetails[];
  previewReportPageAccessDto: AccessMappingSectionDto;
 addNewRolePageAccessDto: AccessMappingSectionDto;
  RoleName: string;
  Description: string;
  AddedData: string;
  Mapped: string;
  Status: string;
  roleId: number;
  pagesize: number;
  maximum: number;
  remainder: number;
  roleIdentity:string;
  searchDisable=true;
  private searchSubject = new Subject<number>();

  displayedColumns: string[] = ['Role Name', 'Description', 'Added Date', 'Mapped/UnMapped', 'Status','Clone', 'Edit', 'Delete'];
  dataSource = new MatTableDataSource<UserDataDTO>();
  dataNotFound = false;

  appConst = appConst;
  userRoleCardPageAccessMap: AccessMappingPageDto;
  userRoleListPageAccessMap: AccessMappingPageDto;
  userRoleCardPrivillegeInfo: any;
  userRoleListPrivillegeInfo: any;
  isUserRoleCardPageEnabled = true;
  isUserRoleListPageEnabled = true;


  minLength: number;
  maxLength: number;
  endingIndex = 10;
  filterVoObject: FilterOrSortingVo[]=[];
  isAscending: boolean;
  isDownloadDisable=false;
  searchValue="";
  userListDissabelDto = new userDissableDto();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  rowPerPageSubscription: Subscription;
  constructor(private paginatorName: MatPaginatorIntl,
    private detector: ChangeDetectorRef, private router: Router, public i18Service: I18nServiceService, private route: ActivatedRoute,
    public translate: TranslateService, private toaster: ToastrService, private changeDetectorRef: ChangeDetectorRef,
    private breadcrumbService: BreadcrumbService, private userCard: UserManagementService, private dialog: MatDialog,
    private appService: AppService) {

      this.searchSubject .pipe(debounceTime(300)).subscribe((pageIndex: number) => {
        this.changePageIndex();
      });
    // this.breadcrumbService.set('usermanagement', { skip: true });
    // this.breadcrumbService.set('user-role', { skip: false });
    if(this.paginatorName) {
      this.rowPerPageSubscription=this.translate.get('Paginator.ItemsPerPageLabel').subscribe((translation: string) => {
        this.paginatorName.itemsPerPageLabel = translation;
      });
    }
  }
  ngOnDestroy(): void {
    sessionStorage.removeItem('UserRole');
    this.rowPerPageSubscription.unsubscribe();
  }

  ngOnInit() {
    this.getPageAccess();
    if(this.show){
      if (this.isUserRoleCardPageEnabled || this.isUserRoleListPageEnabled) {
        this.doProcess();
      }
    }
    const isList=sessionStorage.getItem('UserRole');
    if(isList){
      this.show=false;
      this.searchDisable=false;
      if (this.isUserRoleCardPageEnabled || this.isUserRoleListPageEnabled) {
        this.doProcess();
      }
    }
    else{
      this.show=true;
      this.searchDisable=true;
    }
    this.translate.onLangChange.subscribe(() => {
      if (this.paginator) {
        this.paginator._intl.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
        this.paginator._intl.firstPageLabel=this.translate.instant('Paginator.FirstPage');
        this.paginator._intl.lastPageLabel=this.translate.instant('Paginator.LastPage');
        this.paginator._intl.nextPageLabel=this.translate.instant('Paginator.NextPage');
        this.paginator._intl.previousPageLabel=this.translate.instant('Paginator.PreviousPage');
        this.paginator._changePageSize(this.paginator.pageSize);
        this.detector.detectChanges();
      }
    });
    if(this.paginatorName) {
      this.rowPerPageSubscription=this.translate.get('Paginator.ItemsPerPageLabel').subscribe((translation: string) => {
        this.paginatorName.itemsPerPageLabel = translation;
      });
    }
  }

  doProcess(): void {
    this.getPrivilege();
    this.getTotalUserRoleList(this.filterVoObject, this.searchValue);
  }

  getTotalUserRoleList(filter:FilterOrSortingVo[],searchValue:string) {
    this.minLength = 0;
    this.maxLength = 10;
    this.pageIndex=1;
    this.userCard.getTotalCountForUserRole(this.filterVoObject, searchValue).subscribe((data:any)=>{
      this.totalLength = data['content'];
      const totalNUmber = this.totalLength / 10;
      if (this.isFloat(totalNUmber)) {
        this.maximum =  Math.floor(totalNUmber+1);
      }else{
        this.maximum = totalNUmber;
      }
      this.maximumcount(this.TEN);
      this.subscribeCardDetails(this.minLength, this.maxLength, filter,this.searchValue);
      const isList=sessionStorage.getItem('UserRole');
      if(isList!=undefined && isList!=null && isList!=''){
        //this.show=true;
        //this.searchDisable=false;
      }
    })

  }

  isFloat(n: number): boolean {
    return Number(n) === n && n % 1 !== 0;
  }

  subscribeCardDetails(min: number, max: number,filter:FilterOrSortingVo[], searchValue:string) {
    const platformIdentity = sessionStorage.getItem("platformIdentity");
    this.userCard.getCardDetails(min, max,filter,searchValue).subscribe((response) => {
      if (response) {
        this.tableList = [];
        this.dataSource = null;
        this.cardList = response['content'];
        if (this.cardList === null || this.cardList.length === 0) {
          this.dataNotFound = true;
          this.isDownloadDisable=true;
        }else{
          this.dataNotFound = false;
          this.isDownloadDisable=false;
        }
        this.cardList.forEach(element => {
          this.RoleName = element.roleName;
          this.Description = element.description;
          this.AddedData = element.inActiveDate;
          this.Mapped = element.isMapped ? 'Mapped' : 'UnMapped';
          this.Status = element.isActive ? 'Active' : 'InActive';
          this.roleId = element.roleId;
          this.roleIdentity = element.roleIdentity;
          if(element.isDisableRole){
            this.Status = "Disabled";
          }
          this.tableList.push({
            RoleName: this.RoleName,
            Description: this.Description,
            AddedData: this.AddedData,
            Mapped: this.Mapped,
            Status: this.Status,
            RoleId: this.roleId,
            RoleIdentity:this.roleIdentity,
            isDisableRole: element.isDisableRole,
          });
        });
                this.dataSource = new MatTableDataSource<UserDataDTO>(this.tableList);
        this.changeDetectorRef.detectChanges();

      }
    })
  }

  userRoleDownload(){
    const min = this.ZERO;
    const max =  this.totalLength;
    this.userCard.userRoleDownload(min, max, this.filterVoObject).subscribe((response) =>{
      if (response.size === 0 ) {
        this.toaster.error(this.translate.instant('Toaster_error.invalid_report_generate_download'));
      } else {
        this.donwloadFile(response);
      }
    });
  }

  private donwloadFile(value: any) {
    const blob = new Blob([value], { type: 'application/vnd.ms-excel' });
      const file = new File([blob], 'report.xlsx', {
        type: 'application/vnd.ms-excel',
      });
      const fileURL = URL.createObjectURL(file);
      const a = document.createElement('a');
      a.href = fileURL;
      a.target = '_blank';
      a.download = 'User Role' + '.xlsx';
      document.body.appendChild(a);
      a.click();
  }

  ngAfterViewInit() {
    if (this.dataSource !== undefined && this.dataSource !== null) {
      this.dataSource.paginator = this.paginator;
    }
    if(this.paginatorName) {
     this.rowPerPageSubscription = this.translate.get('Paginator.ItemsPerPageLabel').subscribe((translation: string) => {
        this.paginatorName.itemsPerPageLabel = translation;
      });
    }
  }

  showCardOrList(): void {
    this.show = !this.show;
    this.dataNotFound=false;

    this.searchDisable=!this.searchDisable;
    const emptyQueryParams={};
    const navigationExtras: NavigationExtras = {
      queryParams: emptyQueryParams,
    };
    this.router.navigateByUrl('/usermanagement/user-role/list',navigationExtras);
    if(this.show){
      sessionStorage.setItem('UserRole','');   
    }
    else{
      
      sessionStorage.setItem('UserRole','list');
      if (this.isUserRoleCardPageEnabled || this.isUserRoleListPageEnabled) {
        this.doProcess();
      }
    }
  }
  onpagebackward() {

    if (this.cardList != null) {
      this.dataNotFound = false;
    }


  }
  addNewUser() {
    this.router.navigate(['..', 'add'], { relativeTo: this.route });
  }
  backbtn() {
    this.router.navigateByUrl("/usermanagement/user-role/list");
    this.dataNotFound = false;
    this.show=true;
    this.searchDisable=true;
    sessionStorage.setItem('UserRole','');
  }

  collectRoleId(event) {
    this.router.navigateByUrl('usermanagement/user-role/edit/0/' + event);
  }

  editUserRole(role: any) {
    if(!role.isDisableRole){
    this.router.navigateByUrl('usermanagement/user-role/edit/0/' + role.RoleIdentity);
    }
  }

  deleteUserRole(data:any) {
    if(!data.isDisableRole){
    const dialogRef = this.dialog.open(PopupComponent, {
      width: '300px',
      height: 'auto',
      data: {
        message: "Are you sure you want to delete?",
        okButton: "Ok",
        cancelButton: "Cancel",
        isUser:false,
        name : 'User Role',
        status : data.Status
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const inputDate = new Date(result);
        const timeZoneOffsetMinutes:number = new Date().getTimezoneOffset();
        inputDate.setMinutes((inputDate.getMinutes() - timeZoneOffsetMinutes) + 1439 );
        this.userListDissabelDto.expiredDate = inputDate;
        this.userListDissabelDto.identity = data.RoleIdentity;
        this.userListDissabelDto.userId = data.RoleId;
        this.userListDissabelDto.isMapped = data.Mapped === "UnMapped"?false:true;
        this.userCard.deleteUserRoleDetails(this.userListDissabelDto).subscribe((response) => {
          if (response) {
            this.toaster.success(this.translate.instant('Toaster_success.role_disable'));
            // this.getTotalUserRoleList(this.filterVoObject, this.searchValue);
            this.ngOnInit();
          }
        });
      }
    });
  }
  }

  cloneUserRole(role: any) {
    if(!role.isDisableRole){
      this.router.navigateByUrl('usermanagement/user-role/isClone/1/' + role.RoleIdentity);
    }
  }

  cloneRoleFromCard(event) {
    this.router.navigateByUrl('usermanagement/user-role/isClone/1/' + event);
  }
roleName=false;
description=false;
addedDate=false;
mappedUnmapped=false;
status=false;
changePage(event) {
  if (event.pageIndex != this.ZERO) {
    this.maxLength = event.pageSize;
    this.minLength = event.pageSize * event.pageIndex;
      this.endingIndex = event.pageSize;
      this.pageIndex =  this.pageIndex+1;
      if (this.pagesize != event.pageSize) {
        this.maximumcount(event.pageSize);
        this.pageIndex = 1;
      }
    } else {
      this.maxLength = event.pageSize;
      this.minLength = event.pageIndex;
      this.endingIndex = event.pageSize;
      this.pageIndex = this.pageIndex-1;
      if (this.pagesize != event.pageSize) {
        this.maximumcount(event.pageSize);
        this.pageIndex = 1;
      }
    }
    this.subscribeCardDetails(this.minLength, this.maxLength,this.filterVoObject,this.searchValue);
  }
  maximumcount(event) {
    this.pagesize = event;
    this.maximum = this.totalLength / this.pagesize
    this.remainder = this.totalLength % this.pagesize;
    if (this.remainder != 0) {
      this.maximum =  Math.floor(this.maximum + 1);
    }
  }

  searchItem(event){
    this.searchValue =event;
    if(event==="" && this.show){
      this.userCard.emptyCardEvent.emit(true);
    }
    this.getTotalUserRoleList(this.filterVoObject, this.searchValue);
}

  pageIndex = 1;
  pageindex() {
    this.searchSubject.next(this.pageIndex);
  }

  changePageIndex(){
    if(this.pageIndex > 0) {
      if(this.pageIndex > this.maximum) {
        const numbDigit = this.maximum.toString().length;
        let numString =this.pageIndex.toString();
        numString = numString.substring(0, numbDigit);
        if(Number(numString) >= this.maximum ){
          numString = this.maximum.toString();
        }
        this.pageIndex = this.maximum === 0 ? 1 : Number(numString);
      }
      this.maxLength = this.endingIndex;
      this.minLength = this.endingIndex * (this.pageIndex - 1);
      this.subscribeCardDetails(this.minLength, this.maxLength,this.filterVoObject,this.searchValue);
      // if(!this.pageIndex){
      // }else{
      //   this.subscribeCardDetails(this.minLength, this.maxLength,this.filterVoObject,this.searchValue);
      // }
    }else{
      // this.pageIndex = 1;
      this.minLength = 0;
      this.maxLength = 10;
      this.subscribeCardDetails(this.minLength, this.maxLength,this.filterVoObject,this.searchValue);
    }
  }

  onKeyDown(event: KeyboardEvent) {
    if (event.keyCode === 190) {
      event.preventDefault();
    }
  }

  downloadRoleList() {
    this.userCard.downloadRoleExcelList().subscribe((response) => {
      if (response) {
        this.toaster.success(this.translate.instant('Toaster_success.download_excel'));
        const blob = new Blob([response],
          { type: 'application/vnd.ms-excel' });
        const file = new File([blob], 'Roles_List.xlsx',
          { type: 'application/vnd.ms-excel' });
        const fileURL = URL.createObjectURL(file);
        const a = document.createElement('a');
        a.href = fileURL;
        a.target = '_blank';
        a.download = "Roles_List" + '.xlsx';
        document.body.appendChild(a);
        a.click();
      }
    })
  }

  getPrivilege(): void {
    zip(
      this.appService.getPrivilegeForPage(appConst.PAGE_NAME.USERMANAGEMENT.USERMANAGEMENT_USERROLE.USERMANAGEMENT_USERROLE_CARD.PAGEID),
      this.appService.getPrivilegeForPage(appConst.PAGE_NAME.USERMANAGEMENT.USERMANAGEMENT_USERROLE.USERMANAGEMENT_USERROLE_LIST.PAGEID)
    ).subscribe((responseList: any[]) => {
      this.userRoleCardPrivillegeInfo = responseList[0].content;
      this.userRoleListPrivillegeInfo = responseList[1]?.content;
    });
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    const privillegeInfo = this.show ? this.userRoleCardPrivillegeInfo : this.userRoleListPrivillegeInfo;
    if (privillegeInfo && privillegeInfo.length > 0) {
      const privillege = privillegeInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege.isEnabled;
    }
    return isEnabled;
  }

  getPageAccess(): void {
    zip(
      this.appService.getPageAccess(appConst.PAGE_NAME.USERMANAGEMENT.USERMANAGEMENT_USERROLE.USERMANAGEMENT_USERROLE_LIST.PAGE_IDENTITY)
    ).subscribe((responseList: any[]) => {
      if (responseList && responseList.length > 0) {
        this.userRoleCardPageAccessMap = responseList[0].content;
        this.userRoleCardPageAccessMap.sectionData=this.getEnabledPrivilegeFromMultipleRoles(this.userRoleCardPageAccessMap?.sectionData);
        this.previewReportPageAccessDto = this.userRoleCardPageAccessMap?.sectionData?.find(x => x.sectionName ===MenuSectionNames.User_Role_List);
        this.addNewRolePageAccessDto = this.userRoleCardPageAccessMap?.sectionData?.find(x => x.sectionName ===MenuSectionNames.Add_New_Role);
        this.isUserRoleCardPageEnabled = this.userRoleCardPageAccessMap?.isEnabled;
        this.userRoleListPageAccessMap = responseList[1]?.content;
        this.isUserRoleListPageEnabled = this.userRoleListPageAccessMap?.isEnabled;
      }
    });
  }


  getEnabledPrivilegeFromMultipleRoles(sectionDataArray:AccessMappingSectionDto[]):AccessMappingSectionDto[]{
    const result: AccessMappingSectionDto[] = Object.values(
      sectionDataArray?.reduce((accumulator, obj) => {
        let accessMappingAccumulator:AccessMappingSectionDto= null;
        if (!accumulator[obj.sectionName]) {
          accumulator[obj.sectionName] = obj;
        }
        accessMappingAccumulator=accumulator[obj.sectionName];
        if(obj.isView){          
          accessMappingAccumulator.isView=obj.isView;
        }
        if(obj.isClone){
          accessMappingAccumulator.isClone=obj.isClone;
        }
        if(obj.isDisable){
          accessMappingAccumulator.isClone=obj.isDisable;
        }
        if(obj.isDownload){
          accessMappingAccumulator.isDownload=obj.isDownload;
        }
        if(obj.isEdit){
          accessMappingAccumulator.isEdit=obj.isEdit;
        }
        if(obj.isNotification){
          accessMappingAccumulator.isNotification=obj.isNotification;
        }
        accumulator[obj.sectionName]=accessMappingAccumulator;
        return accumulator;
      }, {} as Record<string, AccessMappingSectionDto>)
    );
    
    return result
  }

  // sorting filter vo
  sortingFilterVo: FilterOrSortingVo =
    {
      columnName: "",
      condition: "",
      filterOrSortingType: "SORTING",
      intgerValueList: [],
      valueList: [],
      isAscending: false,
      type: "",
      value: "",
      value2: "",
    }


    shortingmethod(data: any) {
      const userRole = data;

      if(userRole==='Role Name')
      {
        this.roleName=!this.roleName;
        this.description=false;
        this.addedDate=false;
        this.mappedUnmapped=false;
        this.status=false;
      }
      else if(userRole==='Description')
      {
        this.roleName=false;
        this.description=!this.description;
        this.addedDate=false;
        this.mappedUnmapped=false;
        this.status=false;
      }
      else if(userRole==='Added Date')
      {
        this.roleName=false;
        this.description=false;
        this.addedDate=!this.addedDate;
        this.mappedUnmapped=false;
        this.status=false;
      }
      else if(userRole==='Mapped/UnMapped')
      {
        this.roleName=false;
        this.description=false;
        this.addedDate=false;
        this.mappedUnmapped=!this.mappedUnmapped;
        this.status=false;
      }
      else if(userRole==='Status')
      {
        this.roleName=false;
        this.description=false;
        this.addedDate=false;
        this.mappedUnmapped=false;
        this.status=!this.status;
      }

      this.displayedColumns.forEach(element => {
        if (element === userRole) {
          this.isAscending = !this.isAscending;
          if (this.isAscending) {
            const columnName = this.getEntityColumnName(userRole);
            if(userRole=='Mapped/UnMapped'){
              this.setSortingVO(userRole, this.isAscending);
            }
            else{
              this.setSortingVO(columnName, this.isAscending);
            }
            this.getTotalUserRoleList(this.filterVoObject, this.searchValue);
          }
          else {
            const columnName = this.getEntityColumnName(userRole);
            if(userRole=='Mapped/UnMapped'){
              this.setSortingVO(userRole, this.isAscending);
            }
            else{
              this.setSortingVO(columnName, this.isAscending);
            }
            this.getTotalUserRoleList(this.filterVoObject, this.searchValue);
          }
        }
      });
    }

    // Array for chossing Backend column name corresponding to frontend column name
  sortingEntityArray = [
    {
      tableColumnName: "Role Name",
      entityColumnName: "name",
      type: "String"
    },
    {
      tableColumnName: "Description",
      entityColumnName: "description",
      type: "String"
    },
    {
      tableColumnName: "Added Date",
      entityColumnName: "createdDate",
      type: "Date"
    },
    {
      tableColumnName: "Status",
      entityColumnName: "isActive",
      type: "Boolean"
    }
  ]

  filterObjectArray: FilterObject[] = [
    {
      columnName: 'name',
      condition: 'Like',
      aliasName: 'userRoleManag.RoleName',
      type: 'field',
      value:null,
      dropdown: [],
      radio: [],
      dataType: null
    },
    {
      columnName: 'description',
      condition: 'Like',
      aliasName: 'userRoleManag.Description',
      type: 'field',
      value: [],
      dropdown: [],
      radio: [],
      dataType: null,
      isMax :false
    },
    {
      columnName: 'createdDate',
      condition: 'BW',
      aliasName: 'userRoleManag.Added_Date',
      type: 'dates',
      value: [],
      dropdown: [],
      radio: [],
      dataType: null,
      isMax :false
    },
    {
      columnName: 'Mapped/UnMapped',
      condition: 'Equal',
      aliasName: 'userRoleManag.Mapped_Status',
      type: 'radio',
      value: [],
      dropdown: [],
      radio: [
        {
          name: 'userRoleManag.Mapped',
          value: false,
        },
        {
          name: 'userRoleManag.UnMapped',
          value: false,
        },
      ],
      dataType: null,
      isMax :false
    },
    {
      columnName: 'isActive',
      condition: 'Equal',
      aliasName: 'userRoleManag.Status',
      type: 'radio',
      value: [],
      dropdown: [],
      radio: [
        {
          name: 'Customer_table.Active',
          value: false,
        },
        {
          name: 'Customer_table.InActive',
          value: false,
        },
      ],
      dataType: null,
      isMax :false
    },
  ];

  getEntityColumnName(item: string): string {
    let value = ''; if (item) {
      const data = this.sortingEntityArray.find((column) => column.tableColumnName === item);
      if (data) {
        value = data.entityColumnName;
      }
    }
    return value;
  }

  setSortingVO(value: string, condition: boolean) {

    if (value != null && condition != null) {
      this.sortingFilterVo.columnName = value;
      this.sortingFilterVo.isAscending = condition;
      this.filterVoObject.push(this.sortingFilterVo);
    }

  }

  emitFilterValue(event:any){
    this.searchValue= "";
      if(event){
        const filterFromSearch: FilterOrSortingVo[] = event;

        filterFromSearch.forEach(element=>{
          if((element.columnName==="createdDate" || element.columnName==='userId.createdDate')
            && element.filterOrSortingType==='FILTER'){
                if(element.value && element.value2===null){
                    element.condition='Ge'
                }
                else if(element.value===null && element.value2){

                    element.value=element.value2;
                    element.value2=null;
                    element.condition='Le'
                }
          }
        })



        filterFromSearch.forEach(filter => {
          const type = this.filterTypeFinder(filter);
          filter.type=type;
        });
        this.filterVoObject = filterFromSearch;
        this.getTotalUserRoleList(this.filterVoObject, this.searchValue);
      }
  }

  filterTypeFinder(filter: FilterOrSortingVo) : string{
    let type='';
   if(filter){
      const data=  this.sortingEntityArray.find((m)=>m.entityColumnName===filter.columnName);
      if(data){
        type=data.type;
        return type;
      }
   }
   return type;
  }

}
function pageindex() {
  throw new Error('Function not implemented.');
}



