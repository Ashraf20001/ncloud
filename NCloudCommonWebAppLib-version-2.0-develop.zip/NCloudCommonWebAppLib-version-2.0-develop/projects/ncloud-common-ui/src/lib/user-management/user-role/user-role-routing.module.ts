import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { ManageUserRoleComponent } from "./manage-user-role/manage-user-role.component";
import { UserRoleListComponent } from "./user-role-list/user-role-list.component";
import { UserRoleComponent } from "./user-role.component";



const routes : Routes =  [
  {
    path: '',
    component: UserRoleComponent,
    data: {
      breadcrumb: {
        skip: true
      }
    },
    children: [
      {
        path: 'list',
        component: UserRoleListComponent,
        data: {
          breadcrumb: {
            skip: true
          }
        }
      },
      {
        path: 'add',  component:ManageUserRoleComponent,
        data: {
          breadcrumb: {
            label: 'BREADCRUMB.Add New Role',
            info: 'Add New Role',
            skipParent: true
          },
        }
      },
      {
        path: 'edit/:isClone/:identity',  component:ManageUserRoleComponent,
        data: {
          breadcrumb: {
            label: 'BREADCRUMB.Edit User Role',
            info: 'Edit User Role',
            skipParent: true
          },
        }
      },
      {
        path: 'isClone/:edit/:identity',  component:ManageUserRoleComponent,
        data: {
          breadcrumb: {
            label: 'BREADCRUMB.Clone User',
            info: 'Clone User',
            skipParent: true
          },
        }
      },
      {
        path: '',
        redirectTo: 'list',
        pathMatch: 'full'
      } 
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes),
    // RouterModule.forRoot(appRoutes, { relativeLinkResolution: 'legacy' }),
  ],

  exports: [RouterModule]
})

export class UserRoleRoutingModule { }
