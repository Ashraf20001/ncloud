import { ToastrService } from 'ngx-toastr';
import { MenuSectionNames, UserManagementRoleRestriction, UserManagementRoleRestrictionForRecoverEZ } from '../../../const/enum';
//import { MenuDto } from './../../../models/user-role-management/menu-dto';
import { UserManagementService, CardDetails, AllocationUserTypeDto } from './../../../service/user-management.service';
/* eslint-disable @angular-eslint/no-empty-lifecycle-method */
/* eslint-disable @typescript-eslint/no-empty-function */
import { Component, EventEmitter, Input, OnInit, Output,  } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { UserMenuDto } from '../../../dto/user-menu-dto';
import { RoleDto } from '../../../dto/role-dto';
import { Section } from '../../../dto/entity-management/section';
import { MetaDataDto } from '../../../dto/entity-management/meta-data-dto';
import { appConst } from '../../../const/app.const';
import { AccessMappingPageDto } from '../../../dto/access-Mapping-PageDto ';
import { AccessMappingSectionDto } from '../../../dto/Filter-dto/section-dto';
import { AppService } from '../../../service/app.service';
import { AdminService } from '../../../service/admin.service';
import { Field } from '../../../dto/entity-management/field';
import { PrevilageDto } from '../../../dto/previlage-dto';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-manage-user-role',
  templateUrl: './manage-user-role.component.html',
  styleUrls: ['./manage-user-role.component.scss']
})

export class ManageUserRoleComponent implements OnInit{
  roleDataDetails: RoleDto;
  menuDataDetails:UserMenuDto[];

  subSectionVisible = false;
  userRoleDetails:Section[];
  metaDataDto:MetaDataDto;
  userRoleId:string = null;
  isClone = 0;
  heighlight=false;
  isActive:boolean;
  isShowBtn=false;
  appConst = appConst;
  userRoleAddPageAccessMap: AccessMappingPageDto;
  userRoleAddPrivillegeInfo: any;
  isUserRoleAddPageEnabled = true;
  currentSection: AccessMappingSectionDto;
  dropdownData:AllocationUserTypeDto[];
  manageUserRolePageAccessDto: AccessMappingSectionDto;
  isEdit: boolean=false;
  platformId: any;
  cmpanyStatus: boolean;
  isReadOnly: Field[];
  value: boolean;

  constructor(private router: Router,private route: ActivatedRoute, private managementService:UserManagementService,
    private appService: AppService, private toaster:ToastrService, private adminService: AdminService, private translate:TranslateService) {
    this.menuImageDetails = [];

    this.cmpanyStatus = sessionStorage.getItem('companyId') ? true : false
  }

  ngOnInit(): void {
    
     const platformDetails = JSON.parse(sessionStorage.getItem("platformDetails") ?? "{}");
    this.platformId = platformDetails.platformId;
    this.getPageAccessData();
    
  }

  doProcess(): void {
    // this.getPrivillege();
    this.route.params.subscribe((params: any) => {
      this.userRoleId = params['identity'];
      this.isClone = params['isClone'] !== undefined ? JSON.parse(params['isClone']) : false;
      if(this.userRoleId) {
        if(this.isClone === 0) {
          this.getUserCreationMetaData(this.userRoleId);
        } else {
          this.cloneUserRole(this.userRoleId);
        }
      } else {
        this.getUserCreationMetaData(null);
      }
    });
  }

  onInputChange(roleId:string){
    this.isShowBtn = false;
    this.userRoleId = roleId;
  }


  getUserCreationMetaData(roleId:string){
    
    if(roleId!=null){
      this.isEdit=true;
    }
    this.userRoleId = roleId;
    this.metaDataDto = null;
    this.roleDataDetails = null;
    this.menuDataDetails = null;
    this.pageDataDetails = null;
    this.subSectionDetails = null;
    this.sectionDetails = null;
    this.selectedPageDetails = null;
    this.managementService.getAccessMappingDetails(appConst.PAGE_NAME.USERMANAGEMENT.USERMANAGEMENT_USERROLE.USERMANAGEMENT_USERROLE_ADD.PAGE_IDENTITY,this.userRoleId).subscribe((response)=>{
      if (response) {
        this.isActive = response['content']['isActive']
        this.metaDataDto = response['content']['roleDetails']
        this.roleDataDetails = response['content']['accessMapping'];
        this.menuDataDetails = this.roleDataDetails.menuData;
        this.currentMenuName = this.menuDataDetails[0].menuName;
        this.heighlight_menu = this.menuDataDetails[0].menuId;
        this.pageDataDetails = response['content']['accessMapping'].menuData[0].pageData;
        this.heighlight_menuitem = this.pageDataDetails[0].pageName;
        this.sectionDetails = response['content']['accessMapping'].menuData[0].pageData[0].sectionData;
        this.selectedPageDetails =  response['content']['accessMapping'].menuData[0].pageData[0].privilegeData;
        this.changeMainToggle();
        this.getDropDownData();
      }
      this.isReadOnly = this.metaDataDto?.sectionList[0].fieldList;
      this.value = this.isReadOnly[1].value == 'ADMIN'
    })


  }


  cloneUserRole(roleId:string){
    this.userRoleId = roleId;
    this.metaDataDto = null;
    this.roleDataDetails = null;
    this.menuDataDetails = null;
    this.pageDataDetails = null;
    this.subSectionDetails = null;
    this.sectionDetails = null;
    this.selectedPageDetails = null;
    this.managementService.getAccessMappingDetails(appConst.PAGE_NAME.USERMANAGEMENT.USERMANAGEMENT_USERROLE.USERMANAGEMENT_USERROLE_ADD.PAGE_IDENTITY,this.userRoleId).subscribe((response)=>{
      if (response) {
        this.isActive = response['content']['isActive']
        this.metaDataDto = response['content']['roleDetails']
        this.roleDataDetails = response['content']['accessMapping'];
        this.menuDataDetails = this.roleDataDetails.menuData;
        this.currentMenuName = this.menuDataDetails[0].menuName;
        this.heighlight_menu = this.menuDataDetails[0].menuId;
        this.pageDataDetails = response['content']['accessMapping'].menuData[0].pageData;
        this.heighlight_menuitem = this.pageDataDetails[0].pageName;
        this.sectionDetails = response['content']['accessMapping'].menuData[0].pageData[0].sectionData;
        this.selectedPageDetails =  response['content']['accessMapping'].menuData[0].pageData[0].privilegeData;
        this.metaDataDto.sectionList[0].fieldList[0].value = null;
        this.changeMainToggle();
        this.getDropDownData();
      }
    })
  }

  closePopup(){
    this.router.navigateByUrl('/usermanagement/user-role');
  }
  backbtn(){
    this.router.navigateByUrl('/usermanagement/user-role');
  }

  imageAssetList = [
    {
      image:"/assets/user_dashboard.svg",
      title:'Dashboard'
    },
    {
      image:"/assets/user_receivable.svg",
      title:'Receivable'
    },
    {
      image:"/assets/user_payales.svg",
      title:'Payable'
    },
    {
      image:"/assets/user_report.svg",
      title:'Reports'
    },
    {
      image:"/assets/user_mange.svg",
      title:'User Management'
    },
    {
      image:"/assets/user_entitymanagement.svg",
      title:'Entity Management'
    },
    {
      image:"/assets/icons/page-configurator.svg",
      title:'Page Configurator'
    },
    {
      image:"assets/user-role/purchase-stock.svg",
      title:"Purchase Stock"
    },
    {
      image:"assets/user-role/paper-details.svg",
      title:"Paper Details"
    },
    {
      image:"assets/user-role/paper-details.svg",
      title:"Authority Paper Details"
    },
    {
      image:"assets/headericon/menuicon/Folder.svg",
      title:"Manage Repository"
    },
    {
      image:"assets/headericon/menuicon/Search_1.svg",
      title:"Search"
    },
     {
      image:"assets/headericon/menuicon/Upload_1.svg",
      title:"Upload"
    },
    {
      image:"assets/wallet/payment-um.svg",
      title:"Payment"
    }

  ]


  menuImageDetails:any[];


getImg(item:UserMenuDto){
  let src = '';
  const img = this.imageAssetList.find((img) => img.title === item.menuName);
  if(img) {
        src = img.image;
      }
      return src;
}

getImgStage(subSection:AccessMappingSectionDto){
  let src = '';
  const img = this.imageAssetList.find((img) => img.title === subSection.sectionName);
  if(img) {
        src = img.image;
      }
      return src;
}







pageDataDetails:AccessMappingPageDto[];
heighlight_menu:number;
currentMenuName :string;
onMenuSelect(pageDetails:UserMenuDto){

  this.selectedPageDetails =pageDetails.pageData[0].privilegeData;
  this.sectionDetails = pageDetails.pageData[0].sectionData;
  this.pageDataDetails = pageDetails.pageData;
  this.heighlight_menu=pageDetails.menuId;
  this.heighlight_menuitem = this.pageDataDetails[0].pageName;
  this.currentMenuName = pageDetails.menuName;
}

saveUserRole(){
  this.isShowBtn = true;
  this.managementService.sendUserRoleData(this.metaDataDto,this.roleDataDetails,this.isActive).subscribe((response)=>{
    if (response) {
      // this.managementService.getCardDetails().subscribe((response)=>{
      //   if (response) {
      //     this.cardDetails.emit(response['content'])
      //   }
      // })
      this.isShowBtn = false;
      this.backbtn();
      this.toaster.success(this.translate.instant('Toaster_success.save'));
      this.managementService.setDashBoardHeaderRefresh(true);
      setTimeout(() => {
        window.location.reload();
      }, 500);
    }
  });
}
inputvalid:boolean
inputValidation(event:any,name:string){
  this.isShowBtn = false;
  if(name==="Role Name"){
  const charCode = (event.which) ? event.which : event.keyCode;
    let k;
    if (!/[0-9\+\-\ ]/.test(event.key)) {
      this.inputvalid=true;
      return true;
    } else {
      event.preventDefault();
      this.inputvalid=false;
      return false;
    }
  }
  return this.inputvalid;
}

sectionDetails:AccessMappingSectionDto[];

selectedPageDetails:PrevilageDto[];
heighlight_menuitem:string;
openSectionData(pageDto:AccessMappingPageDto){
  this.selectedPageDetails = pageDto.privilegeData;
  this.sectionDetails = null;
  this.pageDataDetails.forEach(element => {
    if (element.pageName===pageDto.pageName) {
      this.sectionDetails = element.sectionData;
      this.heighlight_menuitem=pageDto.pageName;
    }
  });

}

subSectionDetails:AccessMappingSectionDto[];

subSectionIndex:number;

showSubSection(i:number){
  this.subSectionDetails = this.sectionDetails[i].sectionData
  this.subSectionIndex = i;
  this.subSectionVisible = !this.subSectionVisible;
}

allSelected=true;

singleCheckboxFalse = false;

checkAll(allSelected:boolean){
  this.isShowBtn = false;
  this.menuDataDetails.forEach(menuData => {
    menuData.isEnabled = allSelected;
    menuData.pageData.forEach(pageData => {
      pageData.isEnabled = allSelected;
      pageData.privilegeData.forEach(privilegeData => {
        privilegeData.isEnabled = allSelected;
      });
      pageData.sectionData.forEach(secionData => {
        secionData.isDownload = allSelected;
        secionData.isEdit = allSelected;
        secionData.isNotification = allSelected;
        secionData.isView = allSelected;
        secionData.isClone = allSelected;
        secionData.isDisable = allSelected;
        if(secionData.sectionData!==null || secionData.sectionData!=undefined){
          secionData.sectionData.forEach(subSectionData => {
            subSectionData.isDownload = allSelected;
            subSectionData.isEdit = allSelected;
            subSectionData.isNotification = allSelected;
            subSectionData.isView = allSelected;
            subSectionData.isClone = allSelected;
            subSectionData.isDisable = allSelected;
          });
        }
      });
    });
  });
}

changeMainToggle(){
  this.allSelected = true;
this.isShowBtn = false;
  this.menuDataDetails.forEach(menuData => {
    if(!menuData.isEnabled){
      this.allSelected = false;
      return;
    }

    menuData.pageData.forEach(pageData => {
      if(!pageData.isEnabled){
        this.allSelected = false;
        return;
      }
      pageData.privilegeData.forEach(privilegeData => {
        if(!privilegeData.isEnabled){
        this.allSelected = false;
        return;
        }
      });
      pageData.sectionData.forEach(secionData => {
        if(!secionData.isDownload || !secionData.isEdit || !secionData.isNotification || !secionData.isView || !secionData.isClone || !secionData.isDisable){
          this.allSelected = false;
          return;
        }
        if(secionData.sectionData!==null || secionData.sectionData!=undefined){
          secionData.sectionData.forEach(subSectionData => {
            if(!subSectionData.isDownload || !subSectionData.isEdit || !subSectionData.isNotification || !subSectionData.isView || !subSectionData.isClone || !subSectionData.isDisable ){
              this.allSelected = false;
              return;
            }
          });
        }
      });
    });
  });
}

checkIsView(section:AccessMappingSectionDto, isMasterCheck : boolean){
  let isPartialSelect = false;
  if (section.sectionData!==null) {
    section.sectionData.forEach(element => {
      if(!isMasterCheck){
        element.isView !== section.isView ?  isPartialSelect = true : isPartialSelect = false;
      }
      if(!isPartialSelect){
        element.isView = section.isView;
      }
  });
  }

}

checkIsEdit(section:AccessMappingSectionDto, isMasterCheck : boolean){
  let isPartialSelect = false;
  if (section.sectionData!==null) {
    section.sectionData.forEach(element => {
      if(!isMasterCheck){
        element.isEdit !== section.isEdit ?  isPartialSelect = true : isPartialSelect = false;
      }
      if(!isPartialSelect){
        element.isEdit = section.isEdit;
      }
  });
  }

}

checkIsDownload(section:AccessMappingSectionDto, isMasterCheck : boolean){
  let isPartialSelect = false;
  if (section.sectionData!==null) {
    section.sectionData.forEach(element => {
      if(!isMasterCheck){
        element.isDownload !== section.isDownload ?  isPartialSelect = true : isPartialSelect = false;
      }
      if(!isPartialSelect){
        element.isDownload = section.isDownload;
      }
  });
  }

}



checkIsDisable(section:AccessMappingSectionDto, isMasterCheck : boolean){
  let isPartialSelect = false;
  if (section.sectionData!==null) {
    section.sectionData.forEach(element => {
      if(!isMasterCheck){
        element.isDisable !== section.isDisable ?  isPartialSelect = true : isPartialSelect = false;
      }
      if(!isPartialSelect){
        element.isDisable = section.isDisable;
      }
  });
  }

}

checkIsClone(section:AccessMappingSectionDto, isMasterCheck : boolean){
  let isPartialSelect = false;
  if (section.sectionData!==null) {
    section.sectionData.forEach(element => {
      if(!isMasterCheck){
        element.isClone !== section.isClone ?  isPartialSelect = true : isPartialSelect = false;
      }
      if(!isPartialSelect){
        element.isClone = section.isClone;
      }
  });
  }

}

checkBoxSection(section:AccessMappingSectionDto){
  this.checkIsView(section, false);
  this.checkIsEdit(section, false);
  this.checkIsNotification(section, false);
  this.checkIsDownload(section, false);
  this.checkIsDisable(section, false);
  this.checkIsClone(section, false);
  this.isShowBtn = false;
}

checkIsNotification(section:AccessMappingSectionDto, isMasterCheck : boolean){
  let isPartialSelect = false;
  if (section.sectionData!==null) {
    section.sectionData.forEach(element => {
      if(!isMasterCheck){
        element.isNotification !== section.isNotification ?  isPartialSelect = true : isPartialSelect = false;
      }
      if(!isPartialSelect){
        element.isNotification = section.isNotification;
      }
  });
  }
}

/**
 * UPDATE SECTION STATUS BASED ON SUB-SECTION STATUS
 */
updateStatus(checkBoxName : string){
  let isPartialSelected = false;
  this.subSectionDetails.forEach(ele=>{
    if(ele[checkBoxName] === false){
      isPartialSelected = true;
      return;
    }
  })
  if(isPartialSelected === false){
    this.sectionDetails[this.subSectionIndex][checkBoxName] = true;
  }else{
    this.sectionDetails[this.subSectionIndex][checkBoxName] = false;
  }
}

checkHighlightedArea(name:string){
  if (this.heighlight_menuitem!== undefined) {
if (name===this.heighlight_menuitem) {
  return true;
}
  }
return false;
}

getEnabledPrivilegeFromMultipleRoles(sectionDataArray:AccessMappingSectionDto[]):AccessMappingSectionDto[]{
  const result: AccessMappingSectionDto[] = Object.values(
    sectionDataArray?.reduce((accumulator, obj) => {
      let accessMappingAccumulator:AccessMappingSectionDto= null;
      if (!accumulator[obj.sectionName]) {
        accumulator[obj.sectionName] = obj;
      }
      accessMappingAccumulator=accumulator[obj.sectionName];
      if(obj.isView){          
        accessMappingAccumulator.isView=obj.isView;
      }
      if(obj.isClone){
        accessMappingAccumulator.isClone=obj.isClone;
      }
      if(obj.isDisable){
        accessMappingAccumulator.isClone=obj.isDisable;
      }
      if(obj.isDownload){
        accessMappingAccumulator.isDownload=obj.isDownload;
      }
      if(obj.isEdit){
        accessMappingAccumulator.isEdit=obj.isEdit;
      }
      if(obj.isNotification){
        accessMappingAccumulator.isNotification=obj.isNotification;
      }
      accumulator[obj.sectionName]=accessMappingAccumulator;
      return accumulator;
    }, {} as Record<string, AccessMappingSectionDto>)
  );
  
  return result
}


  getPageAccessData(): void {
    this.appService.getPageAccess(this.appConst.PAGE_NAME.USERMANAGEMENT.USERMANAGEMENT_USERROLE.USERMANAGEMENT_USERROLE_ADD.PAGE_IDENTITY)
    .subscribe((response: any) => {
      if(response) {
        this.userRoleAddPageAccessMap = response.content;
        if(this.userRoleAddPageAccessMap && this.userRoleAddPageAccessMap.sectionData && this.userRoleAddPageAccessMap.sectionData.length > 0) {
          this.currentSection = this.userRoleAddPageAccessMap.sectionData[0];
          this.userRoleAddPageAccessMap.sectionData=this.getEnabledPrivilegeFromMultipleRoles(this.userRoleAddPageAccessMap?.sectionData);
          this.manageUserRolePageAccessDto = this.userRoleAddPageAccessMap.sectionData.find(x => x.sectionName ===MenuSectionNames.Add_New_Role);
        }
        this.isUserRoleAddPageEnabled = this.userRoleAddPageAccessMap?.isEnabled;
      }
      if(this.isUserRoleAddPageEnabled) {
        this.doProcess();
      }
    });
    this.doProcess();
  }

  getPrivillege(): void {
    this.appService.getPrivilegeForPage(this.appConst.PAGE_NAME.USERMANAGEMENT.USERMANAGEMENT_USERROLE.USERMANAGEMENT_USERROLE_ADD.PAGEID)
    .subscribe((response: any) => {
      if(response) {
        this.userRoleAddPrivillegeInfo = response.content;
      }
    });
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.userRoleAddPrivillegeInfo && this.userRoleAddPrivillegeInfo.length > 0) {
      const privillege = this.userRoleAddPrivillegeInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege.isEnabled;
    }
    return isEnabled;
  }

  checkCheckboxToIsView(sectionName:string){
    let value = true;
    if(this.platformId == 1){
      UserManagementRoleRestrictionForRecoverEZ.forEach(element => {
        if (this.currentMenuName=== element.menuName) {
          element.sectionName.forEach(element1 =>{
            element1.subSection.forEach(element2=>{
              if (sectionName === element2.name) {
                value = element2.isView
              }
            })
          })
        }
      });
    }else{
      UserManagementRoleRestriction.forEach(element => {
        if (this.currentMenuName=== element.menuName) {
          element.sectionName.forEach(element1 =>{
            element1.subSection.forEach(element2=>{
              if (sectionName === element2.name) {
                value = element2.isView
              }
            })
          })
        }
      });
    }
   
    return value;
  }

  checkCheckboxToIsEdit(sectionName:string){
    let value = true;
    if(this.platformId == 1){
      UserManagementRoleRestrictionForRecoverEZ.forEach(element => {
        if (this.currentMenuName=== element.menuName) {
          element.sectionName.forEach(element1 =>{
            element1.subSection.forEach(element2=>{
              if (sectionName === element2.name) {
                value = element2.isEdit
              }
            })
          })
        }
      });
    }else{
      UserManagementRoleRestriction.forEach(element => {
        if (this.currentMenuName=== element.menuName) {
          element.sectionName.forEach(element1 =>{
            element1.subSection.forEach(element2=>{
              if (sectionName === element2.name) {
                value = element2.isEdit
              }
            })
          })
        }
      });
    }
    return value;
  }

  checkCheckboxToIsDownload(sectionName:string){
    let value = true;
   if(this.platformId == 1){
    UserManagementRoleRestrictionForRecoverEZ.forEach(element => {
      if (this.currentMenuName=== element.menuName) {
        element.sectionName.forEach(element1 =>{
          element1.subSection.forEach(element2=>{
            if (sectionName === element2.name) {
              value = element2.isDownload
            }
          })
        })
      }
    });

   }else{
    UserManagementRoleRestriction.forEach(element => {
      if (this.currentMenuName=== element.menuName) {
        element.sectionName.forEach(element1 =>{
          element1.subSection.forEach(element2=>{
            if (sectionName === element2.name) {
              value = element2.isDownload
            }
          })
        })
      }
    });
   }
    return value;
  }

  checkCheckboxToIsNotification(sectionName:string){
    let value = true;
    UserManagementRoleRestrictionForRecoverEZ.forEach(element => {
      if (this.currentMenuName=== element.menuName) {
        element.sectionName.forEach(element1 =>{
          element1.subSection.forEach(element2=>{
            if (sectionName === element2.name) {
              value = element2.isNotification;
            }
          })
        })
      }
    });
    return value;
  }
  checkCheckboxToIsClone(sectionName:string){
    let value = true;
   if(this.platformId == 1){
    UserManagementRoleRestrictionForRecoverEZ.forEach(element => {
      if (this.currentMenuName=== element.menuName) {
        element.sectionName.forEach(element1 =>{
          element1.subSection.forEach(element2=>{
            if (sectionName === element2.name) {
              value = element2.isClone
            }
          })
        })
      }
    });
   }else{
    UserManagementRoleRestriction.forEach(element => {
      if (this.currentMenuName=== element.menuName) {
        element.sectionName.forEach(element1 =>{
          element1.subSection.forEach(element2=>{
            if (sectionName === element2.name) {
              value = element2.isClone
            }
          })
        })
      }
    });
   }
    return value;
  }

  checkCheckboxToIsDisable(sectionName:string){
    let value = true;
    if(this.platformId == 1){
      UserManagementRoleRestrictionForRecoverEZ.forEach(element => {
        if (this.currentMenuName=== element.menuName) {
          element.sectionName.forEach(element1 =>{
            element1.subSection.forEach(element2=>{
              if (sectionName === element2.name) {
                value = element2.isDisable
              }
            })
          })
        }
      });
    }else{
      UserManagementRoleRestriction.forEach(element => {
        if (this.currentMenuName=== element.menuName) {
          element.sectionName.forEach(element1 =>{
            element1.subSection.forEach(element2=>{
              if (sectionName === element2.name) {
                value = element2.isDisable
              }
            })
          })
        }
      });
    }
    return value;
  }

  getNumberInput(items: Field) {
    if (items.fieldType === 'Long' || items.fieldType === 'Double') {
      return true;
    }
    return false;
  }

  getDropdownInput(items: Field) {
    if (items.fieldType === 'Dropdown') {
      return true;
    } else {
      return false;
    }
  }

  getStringInput(items: Field) {
    if (items.fieldType === 'String' || items.fieldType === 'Integer') {
      return true;
    }
    return false;
  }

  getDropDownData(){
    this.managementService.getDropdownData().subscribe((response)=>{
      if (response) {
        this.dropdownData = response['allocationUserTypeList']
      }
    })
  }

  onClickingDropdown(event:any){
      this.isEdit=false;
      this.isShowBtn = false;
  }


  checkUserIsAdmin(){
    return this.adminService.isAssociationUser();
  }

  changeChildrenStatusByMenuStatus(item:UserMenuDto){
 
    this.isShowBtn = false;
    const toggleStatus = item?.isEnabled;
    item?.pageData.forEach(onePageData => {
      onePageData.isEnabled = toggleStatus;
      const sectionDataObj = onePageData?.sectionData;
     this.changeSectionDataStatus(sectionDataObj,toggleStatus);
     onePageData?.privilegeData?.map((prv) => {
       prv.isEnabled = toggleStatus;
     });
    });

  }

  changeSectionDataStatus(sectionDataObj:AccessMappingSectionDto[], toggleStatus:boolean){
    this.isShowBtn = false;
    sectionDataObj.forEach(oneSectionData => {
      oneSectionData.isClone = toggleStatus;
      oneSectionData.isDisable = toggleStatus;
      oneSectionData.isDownload = toggleStatus;
      oneSectionData.isEdit = toggleStatus;
      oneSectionData.isNotification = toggleStatus;
      oneSectionData.isView = toggleStatus;
      if (oneSectionData.sectionData!=null) {
        this.changeSectionDataStatus(oneSectionData.sectionData,toggleStatus)
      }
    });
  }


}

