import { AppService } from '../../../service/app.service';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Router } from '@angular/router';
import { UserManagementService, CardDetails } from '../../../service/user-management.service';
import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges, OnChanges, OnDestroy } from '@angular/core';
import { UserTotalDTO } from '../../../dto/user-data-dto';
import { PopupComponent } from '../../../common-components/popup/popup.component';
import { MatDialog } from '@angular/material/dialog';
import { appConst } from '../../../const/app.const';
import { MenuSectionNames } from '../../../const/enum';
import { AccessMappingSectionDto } from '../../../dto/Filter-dto/section-dto';
import { AccessMappingPageDto } from '../../../dto/access-Mapping-PageDto ';
import { Subscription} from 'rxjs';
import { GenerateReportService } from '../../../service/generate-report.service';
import {userDissableDto} from '../../../dto/disable-dto';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-role-card',
  templateUrl: './role-card.component.html',
  styleUrls: ['./role-card.component.scss']
})
export class RoleCardComponent implements OnInit,OnDestroy{

  @Input() userRoleCardPrivillegeInfo: any;

  @Output() sendRoleId = new EventEmitter<string>();
  @Output() cloneRole = new EventEmitter<string>();
  userTotalLength: any;
  minLength: number;
  maxLength: number;
  cardListCopy: CardDetails[];
  cardList:CardDetails[];
  searchValue:string='';
  generateReportPageAccessDto: AccessMappingSectionDto;
  previewReportPageAccessDto: AccessMappingSectionDto;
  reportPageAccessDto: AccessMappingPageDto;
  isGenerateReportEnabled = true;
  allCompanyNameListCopy;
  userListDissabelDto = new userDissableDto();
  emptyCardSubscription: Subscription;
  constructor(private userCard:UserManagementService,private route:Router,private toaster:ToastrService,private dialog:MatDialog,private appService: AppService,
    private activatedRoute:ActivatedRoute, private getreportservice: GenerateReportService,private translate: TranslateService){
        this.queryParamsCatchMethod();
        this.emptyCardSubscription=  this.userCard.emptyCardEvent.subscribe((value)=>{
            if(value){
                  this.dataNotFound=false;
                  this.cardList=this.cardListCopy;
            }
          })
  }
  ngOnDestroy(): void {
    this.emptyCardSubscription.unsubscribe();
  }

  userTotal:UserTotalDTO[]=[];

  appConst = appConst;
  dataNotFound=false;

  private queryParamsCatchMethod() {
    this.activatedRoute.queryParams.subscribe((value) => {
      this.searchValue = value['recSearchQuery'];

      if (this.searchValue != '' && this.searchValue != undefined) {
        this.cardList = this.cardListCopy.filter((m) => String(m.roleName.toUpperCase()).includes(String(this.searchValue.toUpperCase())));
        if(this.cardList.length === 0){
          this.dataNotFound=true
        }
        else{
          this.dataNotFound=false
        }
      }
      else {
        this.cardList = this.cardListCopy;
        this.dataNotFound=false
      }
    });
  }

ngOnInit(): void {
  this.getPageAccess();
}

getTotalUserRoleCardList(){
  this.minLength =0;
  this.maxLength =0;
  this.getCardList(this.minLength, this.maxLength);
}

getCardList(min:number,max:number){
  const platformIdentity = sessionStorage.getItem("platformIdentity");
  this.userCard.getCardDetails(min,max,[],"").subscribe((response)=>{
    if (response) {
      this.cardList = response['content'];
      this.cardListCopy=response['content'];
      if (this.cardList===null || this.cardList.length===0) {
        this.dataNotFound = true;
      }else{
        this.dataNotFound = false;
      }
    }
  })
}

getOneUserRole(role:any){

  // this.route.navigateByUrl('usermanagement/user-role/Edit-User-Role/'+role);
  if(!role.isDisableRole){
  this.sendRoleId.emit(role.roleIdentity.toString());
  }
}

cloneUserRole(role:any){
  if(!role.isDisableRole){
  this.cloneRole.emit(role.roleIdentity.toString());
  }
}

deleteRoleInCard(data:any){
  if(!data.isDisableRole){
  const dialogRef = this.dialog.open(PopupComponent, {
    width: '300px',
    height:'auto',
        data: {
        message: "Are you sure you want to delete?",
         okButton: "Ok",
          cancelButton: "Cancel",
          isUser:false,
          name : 'User Role',
          status : data.isActive ? "Active" : "InActive"
        }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const inputDate = new Date(result);
        const timeZoneOffsetMinutes:number = new Date().getTimezoneOffset();
        inputDate.setMinutes((inputDate.getMinutes() - timeZoneOffsetMinutes) + 1439 );
        this.userListDissabelDto.expiredDate = inputDate;
        this.userListDissabelDto.identity = data.roleIdentity;
        this.userListDissabelDto.userId = data.roleId;
        this.userListDissabelDto.isMapped=data.isMapped;
        this.userCard.deleteUserRoleDetails( this.userListDissabelDto).subscribe((response)=>{
          if (response) {
            this.toaster.success(this.translate.instant('Toaster_success.role_disable'))
            this.ngOnInit()
          }
        })
        }
     });
    }
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.userRoleCardPrivillegeInfo && this.userRoleCardPrivillegeInfo.length > 0) {
      const privillege = this.userRoleCardPrivillegeInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege?.isEnabled;
    }
    return isEnabled;
  }

  getEnabledPrivilegeFromMultipleRoles(sectionDataArray:AccessMappingSectionDto[]):AccessMappingSectionDto[]{
    const result: AccessMappingSectionDto[] = Object?.values(
      sectionDataArray?.reduce((accumulator, obj) => {
        let accessMappingAccumulator:AccessMappingSectionDto= null;
        if (!accumulator[obj?.sectionName]) {
          accumulator[obj?.sectionName] = obj;
        }
        accessMappingAccumulator=accumulator[obj.sectionName];
        if(obj.isView){          
          accessMappingAccumulator.isView=obj.isView;
        }
        if(obj.isClone){
          accessMappingAccumulator.isClone=obj.isClone;
        }
        if(obj.isDisable){
          accessMappingAccumulator.isClone=obj.isDisable;
        }
        if(obj.isDownload){
          accessMappingAccumulator.isDownload=obj.isDownload;
        }
        if(obj.isEdit){
          accessMappingAccumulator.isEdit=obj.isEdit;
        }
        if(obj.isNotification){
          accessMappingAccumulator.isNotification=obj.isNotification;
        }
        accumulator[obj.sectionName]=accessMappingAccumulator;
        return accumulator;
      }, {} as Record<string, AccessMappingSectionDto>)
    );
    
    return result
  }



  getPageAccess(): void {
    this.appService.getPageAccess(appConst.PAGE_NAME.USERMANAGEMENT.USERMANAGEMENT_USERROLE.USERMANAGEMENT_USERROLE_CARD.PAGE_IDENTITY).subscribe((response: any) => {
      this.reportPageAccessDto = response.content;
      this.reportPageAccessDto.sectionData=this.getEnabledPrivilegeFromMultipleRoles(this.reportPageAccessDto?.sectionData);
      this.generateReportPageAccessDto = this.reportPageAccessDto?.sectionData?.find(x => x.sectionName ===MenuSectionNames.User_Role_Card);
      this.previewReportPageAccessDto = this.reportPageAccessDto?.sectionData?.find(x => x.sectionName ===MenuSectionNames.Add_New_Role);

      this.isGenerateReportEnabled = this.reportPageAccessDto?.isEnabled;
      if (this.isGenerateReportEnabled) {
        this.doProcess();
      }
    });
  }
  doProcess(): void {
    this.getTotalUserRoleCardList();
  }

 }
