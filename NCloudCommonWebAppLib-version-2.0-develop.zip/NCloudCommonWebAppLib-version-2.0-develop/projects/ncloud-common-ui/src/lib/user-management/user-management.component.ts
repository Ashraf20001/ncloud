import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Subject, takeUntil } from 'rxjs';
import { AdminService } from '../service/admin.service';
import { I18nServiceService } from '../service/i18n-service.service';
import { UserManagementService } from '../service/user-management.service';

@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.scss']
})

export class UserManagementComponent implements OnInit,OnDestroy{

  transactionTabIndex= 0;
  isEdit = false;
  currentRoute = "";
  isAdmin = false;

  navigationTabs: TabData[];
  untilThenSubject = new  Subject();


  loadTranslatedNavigationTabs(){
    this.navigationTabs= [
      {
        label:  this.translate.instant('userMangement.User_Role'),
        url: 'user-role',
        labelClass: 'userroleTab'
      },
      {
        label: this.translate.instant('userMangement.User_Management'),
        url: 'user',
        labelClass: 'userTab'
      },
      
     
    ];
  }

  allocationRoute: TabData = {
    label: this.translate.instant('UserManagement.Allocation_Pool'),
    url: 'allocation-pool',
    labelClass: 'allcoationTab'
  }

  customerRoute:TabData ={
      label: this.translate.instant('UserManagement.Customer'),
      url: 'customer',
      labelClass: 'customerTab'
  }

  // approvalLimitRoute:TabData = {
  //   label:'Approval Limit', 
  //   url: 'approval-limit',
  //   labelClass: 'approvalTab'
  // }

  isPoolBasedAllocation= false;


  constructor(public i18Service: I18nServiceService, public translate: TranslateService, private router: Router,
    public route: ActivatedRoute, private adminService: AdminService, private service: UserManagementService) {
      this.getCurrentUrl();
  }
  ngOnDestroy(): void {
   this. untilThenSubject.complete();
  }

  ngOnInit(): void {
    this.isAdmin = this.adminService.isAssociationUser();
    this.loadTranslatedNavigationTabs();
    this.translate.onLangChange.subscribe(() => {
      this.loadTranslatedNavigationTabs();
      this.tabTransitionBasedOnPlatormsChanges();
    });
    this.tabTransitionBasedOnPlatormsChanges(); 
  }


  private tabTransitionBasedOnPlatormsChanges() {
    const platformDetails = JSON.parse(sessionStorage.getItem('platformDetails') ?? '{}');
    if (platformDetails) {
      if (platformDetails.platformId === 1) {
        if (!this.isAdmin) {
          let approvalLimit={
            
              label:this.translate.instant('userMangement.Approval_Limit'), 
               url: 'approval-limit',
              labelClass: 'approvalLimitTab'
            
          }
            this.navigationTabs.push(approvalLimit);
            // this.navigationTabs.splice(this.navigationTabs.length - 1, 1);
        }
        // else {
        //   this.navigationTabs.pop();
        // }
        // this.navigationTabs.splice(this.navigationTabs.length - 1, 1);
        if (this.currentRoute.includes('usermanagement/')) {
          this.router.navigateByUrl(this.currentRoute)
        }else{
          this.router.navigate([this.navigationTabs[0].url], { relativeTo: this.route });
        }
      }
      else if (platformDetails.platformId === 2) {
        if (!this.isAdmin) {
          const customerLabel=this.translate.instant('UserManagement.Customer')
          this.customerRoute.label=customerLabel;
          this.navigationTabs.push(this.customerRoute);           
          this.getDigitalPaperTabs();
        }
        else {
          this.navigationTabs.splice(this.navigationTabs.length, 1);
          if (this.currentRoute.includes('usermanagement/')) {
            this.router.navigateByUrl(this.currentRoute)
          }else{
            this.router.navigate([this.navigationTabs[0].url], { relativeTo: this.route });
          }
        }
      }
      else {
        this.navigationTabs.splice(this.navigationTabs.length, 1);
        if (this.currentRoute.includes('usermanagement/')) {
          this.router.navigateByUrl(this.currentRoute)
        }else{
          this.router.navigate([this.navigationTabs[0].url], { relativeTo: this.route });
        }
      }
    }
  }

  getDigitalPaperTabs(){
    this.service.getAllocationType()
    .pipe(takeUntil(this.untilThenSubject))
    .subscribe((response: any) => {   
      this.isPoolBasedAllocation = response.content === "User Type"
      this.untilThenSubject.next(true);
      if (this.isPoolBasedAllocation && !(this.isAdmin)) {
        const allocationTable=this.translate.instant('UserManagement.Allocation_Pool')
        this.allocationRoute.label=allocationTable;
        this.navigationTabs.splice(0, 0,this.allocationRoute);
      }
      if (this.isAdmin) {
        this.navigationTabs.pop();
      }
      this.navigationTabs.splice(this.navigationTabs.length, 1);
      if (this.currentRoute.includes('usermanagement/')) {
        this.router.navigateByUrl(this.currentRoute)
      }else{
        this.router.navigate([this.navigationTabs[0].url], { relativeTo: this.route });
      }
    });
  }


  getCurrentUrl() {
    this.currentRoute = window.location.href;
    this.router.events.subscribe((event: any) => {
      if (event instanceof NavigationEnd) {
        this.currentRoute = event.url
      }
    });
  }

}

export interface TabData {
  label?: string;
  url?: string;
  labelClass?: string;
}
