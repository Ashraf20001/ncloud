import { Directive, HostListener, ElementRef } from '@angular/core';

@Directive({
  selector: '[phoneNumerOnly]'
})
export class PhoneNumberOnly {

  constructor(private el: ElementRef) {}

  @HostListener('input', ['$event']) onInput(event: Event): void {
    const inputElement = this.el.nativeElement as HTMLInputElement;
    const initialValue = inputElement.value;
    const numericValue = initialValue.replace(/[^0-9+()\s]/g, ''); // Allow only numeric characters

    if (initialValue !== numericValue) {
      inputElement.value = numericValue;
      event.stopPropagation();
    }
  }
}
