import { CommonModule } from "@angular/common";
import { ModuleWithProviders, NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatSlideToggleModule } from "@angular/material/slide-toggle";
import { AppCommonModule } from "../common-components/app-common.module";
import { MatDialogModule } from "@angular/material/dialog";
import { MatChipsModule } from "@angular/material/chips";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatAutocompleteModule } from "@angular/material/autocomplete";
import { MatIconModule } from "@angular/material/icon";
import { MatTooltipModule } from "@angular/material/tooltip";

import { MatMenuModule } from "@angular/material/menu";
import { MatDatepickerModule } from "@angular/material/datepicker";
import { MatButtonModule } from "@angular/material/button";

import { PasswordChangedPopupComponent } from "./change-password-popup/password-changed-popup/password-changed-popup.component";
import { TranslateModule } from "@ngx-translate/core";
import { ProfileRoutingModule } from "./profile-routing.module";
import { ProfileComponent } from "./profile.component";
import { ChangePasswordPopupComponent } from "./change-password-popup/change-password-popup.component";
@NgModule({
  declarations: [
    PasswordChangedPopupComponent,
    ProfileComponent,
    ChangePasswordPopupComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    ProfileRoutingModule,
    AppCommonModule,
    MatSlideToggleModule,
    MatDialogModule,
    MatChipsModule,
    MatFormFieldModule,
    MatAutocompleteModule,
    MatIconModule,
    ReactiveFormsModule,
    MatTooltipModule,
    MatMenuModule,
    MatDatepickerModule,
    MatButtonModule,
    TranslateModule,
  ],
  exports: [ProfileComponent],
})
export class ProfileModule {
  public static forRoot(environment: any): ModuleWithProviders<ProfileModule> {
    return {
      ngModule: ProfileModule,
      providers: [
        {
          provide: "env", // you can also use InjectionToken
          useValue: environment,
        },
      ],
    };
  }
}
