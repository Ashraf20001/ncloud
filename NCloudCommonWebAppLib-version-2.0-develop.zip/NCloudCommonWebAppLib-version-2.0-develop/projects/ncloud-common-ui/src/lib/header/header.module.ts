import { ModuleWithProviders, NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatIconModule } from "@angular/material/icon";
import { TranslateModule } from "@ngx-translate/core";
import { HeaderComponent } from "./header.component";
import { RouterModule } from "@angular/router";
import {MatDialogModule} from '@angular/material/dialog';
import { DemoMaterialModule } from "../common-components/angularMaterialModules/material-module";

@NgModule({
  declarations:[
   HeaderComponent
  ],
  imports:[
    CommonModule,
    FormsModule,
    TranslateModule,
    RouterModule,
    MatFormFieldModule,
    MatIconModule,
    MatDialogModule,
    DemoMaterialModule
  ],
  exports: [
    HeaderComponent
  ]
})
export class HeaderModule{
  public static forRoot(environment: any, commentPop:any,notificationPop:any): ModuleWithProviders<HeaderModule> {
    return {
      ngModule: HeaderModule,
      providers: [
        {
          provide: 'env', // you can also use InjectionToken
          useValue: environment
        },{
          provide:'comment',
          useValue: commentPop
        },
        {
          provide:'notifications',
          useValue: notificationPop
        }
      ]
    };
  }
}