
import { EventEmitter, Inject, OnDestroy, OnInit, Output } from '@angular/core';
import { Component } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { Menu } from '../dto/menu-dto';
import { AppService } from '../service/app.service';
import { MatDialog } from '@angular/material/dialog';
import { PlatFormTypeEnum } from '../enum/platformtype.enum';
import { HttpParams } from '@angular/common/http';
import { PurchaseHistoryNotificationDTO } from '../dto/purchase-history-notification-dto';
import { AuthService } from '../service/auth.service';
import { AdminService } from '../service/admin.service';
import { NotificationDetailsDto, NotificationRequestDto } from '../dto/notification-request-dto';
import { NotificationDTO } from '../dto/notification-dto';
import { NotificationCountDTO } from '../dto/notification-count-dto';
import {FileUploadService} from '../service/file-upload.service';
import {ProfileService} from '../service/profile-service.service';
import { TranslateService } from '@ngx-translate/core';
import * as Stomp from 'stompjs';
import  SockJS from 'sockjs-client';



@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})


export class HeaderComponent implements OnInit {

 

  // MENU
  menuList: Menu[] = [];
  platformName: any;
  platformLogo: any;
  companyLogo: any; 
  

  // NOTIFCATION
  notificationCount:number = 0;
  totalCount: any;
  notifications : any[] = [];
  noNotification = false;
  @Output() fullViewNotification = new EventEmitter<boolean>();
  platForm: any;

  stompClient: any;
  socket: any;

  // COMMON
  currentRoute: string = '';
  platFormId: any;
  platformlogo="";
  showmessage?: boolean;
  notificationRequestData!: NotificationRequestDto;
  companyNotificationList: NotificationDTO[] = [];
  isAssociation = false;
   profileImage: any;
  userId: any;
  profileImages: any;
  allNotifications: any[] =[];
  /**
   * 
   * @param appService 
   * @param activatedRoute 
   * @param route 
   */
  constructor(private appService : AppService, private activatedRoute: ActivatedRoute,
     private route: Router, public dialog: MatDialog, @Inject('comment') private commentPop:any, 
     @Inject('notifications') private notificationPop:any, private authService : AuthService,public translate:TranslateService,
     private adminService: AdminService ,private fileService:FileUploadService,private userProfileService:ProfileService,@Inject('env') private environment: any) {    
      this.connectWebSocket();
    this.userProfileService.getValue().subscribe(value=>{
      if(value){
        this.getProfilePic();
        //this.currentCompanyName = sessionStorage.getItem("username");
      }
    });
  }
   baseUrl = this.environment.API_BASE_URL+'/api/downloadFile/'

  ngOnInit(): void {
    
    const platformDetails = JSON.parse(sessionStorage.getItem('platformDetails') ?? '{}');
    // this.platFormId = sessionStorage.getItem('platFormDetails');
    
    this.platFormId = platformDetails.platformId;
    this.notificationRequestData = {
      claimId: -1,
      companyName: sessionStorage.getItem('companyName'),
      status: '',
      isReceivable: '',
      lastActed: '',
      logoUrl: '',
      platformId:this.platFormId
    };
    this.isAssociation = this.isAssociation;
    this.getCurrentUrl();
    this.getProfilePic();
    this.getheaderlist();
    
    this.notificationGET();
    this.getNotificationCountForDataLake();
    this.translate.onLangChange.subscribe(() => {
      this.notificationGET();
    });

  }

  getNotificationCountForDataLake(){
    if(sessionStorage.getItem('companyId') != null)  {
      this.appService.getNotificationCountIC(this.notificationRequestData).subscribe((notificationCount: NotificationCountDTO) => {
        this.notificationCount = notificationCount.unReadCount;
        if(this.notificationCount > 99) {
          this.notificationCount = 99;
          this.totalCount = this.notificationCount + "+";
        }      
        else {
          this.totalCount = this.notificationCount;
        }
      });
    } else {
      this.appService.getNotificationCount().subscribe((data: any) => {
        if (data) {
          this.notificationCount=data.content;
          if(this.notificationCount>100) {
            this.notificationCount=99;
            this.totalCount = this.notificationCount + "+";
          }      
          else {
            this.totalCount = this.notificationCount;
          }
        }
      });
    }
  }
getImageUrl(){
const platformDetails = JSON.parse(sessionStorage.getItem('platformDetails') ?? '{}');
if(platformDetails){
if(platformDetails.platformId===3){
 return this.platformlogo=platformDetails.platformLogoPath;
}
return this.platformlogo;
}
}
dlcomplogo
getImageUrlForCompanyLoggo(){
const platformDetails = JSON.parse(sessionStorage.getItem('platformDetails') ?? '{}');
const role=sessionStorage.getItem('role');
if(platformDetails){
if(platformDetails.platformId===3 && role===null){
  return this.dlcomplogo= this.companyLogo?this.companyLogo:"/assets/headericon/menuicon/insurance-company-logo.svg"
}
}
}

all_img_Notifications:[]=[];
  notificationGET() {
    if(this.platFormId == PlatFormTypeEnum.DATA_LAKE){
      if(sessionStorage.getItem('companyId')) {
        this.appService.getNotificationListForDataLakeIC(this.notificationRequestData).subscribe((res: NotificationDTO[]) => {
          this.companyNotificationList = res;
         });

         if(this.companyNotificationList.length > 0){
          // this.allNotifications = res.content;
          this.companyNotificationList.map(x => {
            if (x.status) {
              var notificationTemplate = this.translate.instant(`NotificationTemplate.${x.status.toLowerCase()}`);
              const parsedObject = JSON.parse(x.notificationJson);
              const keyValueList = [];
              for (const key in parsedObject) {
                if (parsedObject.hasOwnProperty(key)) {
                  keyValueList.push({ key, value: parsedObject[key] });
                }
              }
              keyValueList.forEach(({ key, value }) => {
                const regex = new RegExp(key, "g");
                notificationTemplate = notificationTemplate.replace(regex, value);
              });
              if (!notificationTemplate.includes('NotificationTemplate')) {
                x.template = notificationTemplate; 
                // this.all_img_Notifications=notificationTemplate;
              }
            }
          });
          this.companyNotificationList = [];
          this.companyNotificationList = this.notifications;
     
        }


      } else if(sessionStorage.getItem('companyId') === null|| sessionStorage.getItem('companyId') === undefined || sessionStorage.getItem('userRoleStatus') != null){
        this.companyNotificationList = [];
        const param = new HttpParams().set('isViewAllNotifications', false)
        this.appService.getNotificationListForDataLake(param).subscribe((res:any)=>{
          if(res.content){
            let tempArr: PurchaseHistoryNotificationDTO[] = []
            res.content.forEach((result:any) => {
              let purchaseHstryDetailsList : PurchaseHistoryNotificationDTO = {
                notificationMsg: result.notificationContent,
                actedBy: 0,
                orderId: 0,
                imageUrl: '',
                notificationId: 0,
                identity: result.identity,
                createdDate: result.createdDate,
                repoIdentity: result.repositoryIdentity,
                status: result.status,
                isRepoCmts: result.isRepoCmts,
                logoUrl: result.logoUrl,
                notificationJson: result.notificationJson
              }
              tempArr.push(purchaseHstryDetailsList);
            });
            this.notifications = tempArr;
            if (this.notifications.length > 0) {                    
               this.notifications=this.notifications.map(notification => ({
                ...notification,
                imageUrl: notification.logoUrl
                  ? `${this.baseUrl}/${notification.logoUrl}`
                  : 'assets/no-logo.svg'
              }));
              // this.allNotifications=this.notifications;
            }

          
            if(this.notifications.length > 0){
            // this.allNotifications = res.content;
            this.notifications.map(x => {
              if (x.status) {
                var notificationTemplate = this.translate.instant(`NotificationTemplate.${x.status.toLowerCase()}`);
                const parsedObject = JSON.parse(x.notificationJson);
                const keyValueList = [];
                for (const key in parsedObject) {
                  if (parsedObject.hasOwnProperty(key)) {
                    keyValueList.push({ key, value: parsedObject[key] });
                  }
                }
                keyValueList.forEach(({ key, value }) => {
                  const regex = new RegExp(key, "g");
                  notificationTemplate = notificationTemplate.replace(regex, value);
                });
                if (!notificationTemplate.includes('NotificationTemplate')) {
                  x.template = notificationTemplate; 
                  // this.all_img_Notifications=notificationTemplate;
                }
              }
            });
       
          }
        
       
        }
        });
      }
       
 
      }
    
  //   else {
  //     this.notificationSubscribtion = this.notificationService.getNotificationList().subscribe((res: any) => {
  //     if (res) {
  //       this.notificationDetailsList = res;
  //     }
  //   }, (error: Response) => {
  //     this.errorHandler.getMessage(error);
  //   })
  // }
  }

  /**
   * WEBSCKET CONNECTION & SUBSCRIPTION
   */
  connectWebSocket() {
   const companyName =  sessionStorage.getItem('companyName')
   if(companyName != null){
    this.socket = new SockJS(this.environment.NOTIFY_SOCKET_URL);
   }else{
    this.socket = new SockJS(this.environment.WEB_SOCKET_URL);
   }
    this.stompClient = Stomp.over(this.socket);
    const _this = this;
    _this.stompClient.connect({}, function (frame: any) {
      _this.stompClient.subscribe(
        '/topic/notification/'+companyName,
        function (response: any) {
          _this.onMessageReceived(response);
        }
      );
    });
  }

  /**
   * NOTIFICATION COUNT ADDITION - WEBSOCKET
   * @param response
   */
  onMessageReceived(response: any) {
    console.log("response obj : "+response);
    const socketResponse = JSON.parse(response.body);
      this.notificationGET();
      this.getNotificationCountForDataLake();
  }


  getNotificationCount(){
    // if(this.platFormId == PlatFormTypeEnum.DATA_LAKE){
    //   this.baseUrl = this.baseUrl+"/data-lake";
    // } else if(this.platFormId === PlatFormTypeEnum.DIGITAL_PAPER){
    //   this.baseUrl = this.baseUrl+"/digital-paper"
    // }
    if(sessionStorage.getItem('companyId') != null) {
      this.appService.getNotificationCountIC(this.notificationRequestData).subscribe((data: NotificationCountDTO) => {
        if (data) {
          this.notificationCount = data.unReadCount;
        }
      });
    } else {
      this.appService.getNotificationCount().subscribe((data: any) => {
        if(data) {
          this.notificationCount = data.content;
        }

      });
    }
  }

  /**
   * MONITOR CURRENT URL
   */
  public getCurrentUrl() {
    console.log("currentUrl")
    this.currentRoute = window.location.href;
    this.route.events.subscribe((event: any) => {
      if (event instanceof NavigationEnd) {
        this.currentRoute = event.url
      }
    });
  }

  /**
   * MENU DETAILS
   */
  public getheaderlist(){
    this.appService.getMenuDetails().subscribe((reponse:any) =>{
      if(reponse){
        this.menuList = [];
        this.menuList = reponse.menuDetails;
        this.platformName = reponse.platformDetails.platformName;
        this.platformLogo = reponse.platformDetails.platformLogoPath;
        // this.companyLogo = this.profilePreview(reponse.companyLogoPath);
        this.companyPreview(reponse.companyLogoPath);
      }
    })
  }

  
  /**
   * 
   * @param companyLogoPath 
   */
  companyPreview(companyLogoPath: any) {
    this.fileService.downloadImageByImageName(companyLogoPath).subscribe((response:Blob)=>{
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.companyLogo = e.target.result;
      };
     reader.readAsDataURL(response);
     })
  }


  /**
   * @param notifications
   * @summary VIEW MORE - NOTIFICATIONS
   */
  public viewMoreNotifications(notifications:any){
     this.showmessage = true;
     const dialogRef = this.dialog.open(this.notificationPop, {
       width: '600px', height: '700px',
       data: {
         notificationData:notifications
       },
     });
     dialogRef.afterClosed().subscribe((result :any) => {
       if (result) {
          //this.showClaim(result, result.index); 
       }
     });
  }

  openDialog(data:any):void{
    const dialog = this.dialog.open(this.commentPop, {
      width: '70vw', height: '75vh',
      data:{
        repositoryIdentity: data.repoIdentity,
        action: 'Request to modify'
      } 

    });
    dialog.afterClosed().subscribe(result => {
    });
  }

  public routeThroughNotification(notification: any) {
    if (notification.isRepoCmts == true) {
      this.repositoryRedirectionInAssociation(notification);
      this.openDialog(notification);
    } else if (!notification.isRepoCmts) {
      // const queryParams = { repositoryStatus: notification.status }
      // this.route.navigate(['/repository/edit-repository/' + notification.repoIdentity]);
      if(this.adminService.isAssociationUser()){
        this.repositoryRedirectionInAssociation(notification);
      }
      else{
        const params =  new HttpParams().set('repositoryIdentity', notification.repositoryIdentity);
        this.appService.getRepositoryDetails(params).subscribe((data:any)=>{
          let response= data;
         if(response){
            this.route.navigate(['/upload/upload-file'],{queryParams: { identity : notification.repositoryIdentity ,  
            repoName : response.repositoryName , status : response.repositoryStatus}})
            const notificationRequestDetails = new NotificationDetailsDto();
            notificationRequestDetails.repositoryIdentity= notification.repositoryIdentity;
            notificationRequestDetails.loginUserCompanyName=sessionStorage.getItem('companyName') || '';
            this.appService.updateNotificationListForDataLakeIC(notificationRequestDetails).subscribe((data)=>{
              this.notificationGET();
              this.getNotificationCountForDataLake();
            })
         }
              
        })
      }
    }
  }

  private repositoryRedirectionInAssociation(notification: any) {
    const params = new HttpParams().set('identity', notification.repoIdentity);
    this.appService.getRepositoryStatus(params).subscribe((data: any) => {
      let response = data.content;
      this.route.navigate(['/repository/edit-repository/' + notification.repoIdentity], { queryParams: { status: response.status, isDisabled: response.isDisabled } });
      this.appService.updateNotification(params).subscribe((data: any) => {
        console.log("Notifiication Read Updated " + data.content);
        if (data.content) {
          this.notificationGET();
          this.getNotificationCountForDataLake();
        }
      });
    });
  }

  logout(){
    this.authService.logout();
  }
  notification_fullview() {
   console.log("notificationfullview");
   
    this.fullViewNotification.emit();


  }
  popup_fullscreen(value:any ) {

    this.showmessage = true;
    const dialogRef = this.dialog.open(this.notificationPop, {
      width: '600px', height: '731px',
      data: {
        notificationData:value
      },

    });
 console.log(value);
  }
//profile picture
      getProfilePic(){
            let userIdentity=sessionStorage.getItem('userIdentity');
            this.userProfileService.getUserProfilePicture(userIdentity).subscribe((data)=>{
              if(data){
                const profilePicture=data['content'];
                if(profilePicture===null || profilePicture===""){
                  this.profileImage='/assets/ProfilePic.png'
                }
                else{
                    this.profilePreview(profilePicture); // fileReader call
                }
              }
            });
      }

     profilePreview(profilePicture:string) {
         this.fileService.downloadImageByImageName(profilePicture).subscribe((response:Blob)=>{
          const reader = new FileReader();
          reader.onload = (e: any) => {
            this.profileImage = e.target.result;
          };
         reader.readAsDataURL(response);
         })
    }
}
