import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EntityManagementComponent } from './entity-management.component';
import { FormsModule } from '@angular/forms';
import { EntityManagementRoutingModule } from './entity-management-routing.module';
import { MatTabsModule } from '@angular/material/tabs';
import { TranslateModule } from '@ngx-translate/core';
import { DemoMaterialModule } from '../common-components/angularMaterialModules/material-module';
import {CompanyModule} from './company/company.module';


@NgModule({
  declarations: [
    EntityManagementComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    EntityManagementRoutingModule,
    DemoMaterialModule,
    MatTabsModule,
    TranslateModule,CompanyModule,
  ],
  exports:[
    EntityManagementRoutingModule
  ]
})
export class EntityManagementModule {
  public static forRoot(environment: any): ModuleWithProviders<EntityManagementModule> {
    return {
      ngModule: EntityManagementModule,
      providers: [
        {
          provide: 'env', // you can also use InjectionToken
          useValue: environment
        }
      ]
    };
  }
 }
