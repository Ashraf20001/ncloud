import { Component, OnInit, ViewChild } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { TranslateService } from "@ngx-translate/core";
import { I18nServiceService } from "../service/i18n-service.service";
import { EntityManagementService } from "../service/entitymanagement-service";
import { TabData } from "../user-management/user-management.component";
import { CompanyListComponent } from "../../public-api";

@Component({
  selector: "app-entity-management",
  templateUrl: "./entity-management.component.html",
  styleUrls: ["./entity-management.component.scss"],
})
export class EntityManagementComponent implements OnInit {
  links = ["Insurance Company", "Garage"];
  activeLink = this.links[0];
  selectedIndex: any;
  searchValue: any;
  navigationTabs?: TabData[];
  platformId: any;
  listShow=false;
  addShow=false;
  editShow=false;
  cloneShow=false;
  currentPath: string;
  loadTranslatedNavigationTabs() {
    this.navigationTabs = [
      {
        label: this.translate.instant("Managment.InsuranceCompany"),
        url: "insuranceCompany",
        labelClass: "insuranceCompanyTab",
      },
      {
        label: this.translate.instant("Managment.Garage"),
        url: "garage",
        labelClass: "garageTab",
      },
    ];
  }

  constructor(
    public i18Service: I18nServiceService,
    private route: ActivatedRoute,
    public translate: TranslateService,
    public router: Router,
    private entityService: EntityManagementService
  ) {}

  ngOnInit(): void {
        const platformDetails = JSON.parse(sessionStorage.getItem("platformDetails") ?? "{}");

    this.platformId = platformDetails.platformId;
    const t = this.route.snapshot.queryParamMap.get("tab") ?? "-1";
    this.selectedIndex = parseInt(t, 10);
    const indexcheck = sessionStorage.getItem("activeIndex");
    const activeIndex = Number(indexcheck);
    if (activeIndex > 0) {
      this.selectedIndex = activeIndex;
    } else {
      this.selectedIndex = 0;
    }

    this.loadTranslatedNavigationTabs();
    this.translate.onLangChange.subscribe(() => {
      this.loadTranslatedNavigationTabs();
    });
  }
  tabChange(selectedTabIndex: any) {
    if (selectedTabIndex === 0) {
      this.setTabIndexInSessionStorage(selectedTabIndex);
      this.entityService.listShow(true);
      this.searchValue = selectedTabIndex;
      this.router.navigate(["/entitymanagement/insuranceCompany/companyList"]);
    } else if (selectedTabIndex === 1) {
      this.setTabIndexInSessionStorage(selectedTabIndex);
      this.entityService.listShow(true);
      this.searchValue = selectedTabIndex;
      this.router.navigate(["/entitymanagement/garage/garageList"]);
    }
  }
  /**
   * Set TabIndex In SessionStorage
   * @param selectedTabIndex
   */
  private setTabIndexInSessionStorage(selectedTabIndex: any) {
    sessionStorage.setItem("activeIndex", selectedTabIndex);
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: {
        tab: selectedTabIndex,
      },
    });
    this.selectedIndex = selectedTabIndex;
  }

  goToCard(){
    this.entityService.setBackToCard(true);
    this.currentPath=window.location.href;
    if(this.currentPath.includes('/companyList')){
        this.entityService.cardViewShowOnBackButtonFromList.emit(true);
    }
    else{
      this.router.navigateByUrl('/entitymanagement/insuranceCompany/companyList') // To show card view
    }
    sessionStorage.setItem('CompanyList','');
    this.listShow=false;
    this.addShow=false;
    this.cloneShow=false;
    this.editShow=false;

  }



  listPage(event:any){
    if(event){
      if(event.listHeaderShow==false){
        this.listShow=true;
        this.addShow=event.addHeaderShow;
        this.editShow=event.editHeaderShow;
        this.cloneShow=event.cloneHeaderShow;
      }
      else if (event.listHeaderShow==true){
        this.listShow=false;
        this.addShow=event.addHeaderShow;
        this.editShow=event.editHeaderShow;
        this.cloneShow=event.cloneHeaderShow;
      }
      else{
        this.listShow=false
        this.addShow=event.addHeaderShow;
        this.editShow=event.editHeaderShow;
        this.cloneShow=event.cloneHeaderShow;
      }
    }
  }
  triggerBack(){
    this.goToCard();
  }
}
