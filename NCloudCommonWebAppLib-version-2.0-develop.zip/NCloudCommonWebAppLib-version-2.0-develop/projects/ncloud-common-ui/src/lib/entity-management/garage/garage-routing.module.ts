import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { GarageListComponent } from "./garage-list/garage-list.component";
import { GarageManageComponent } from "./garage-manage/garage-manage.component";
import { GarageComponent } from "./garage.component";


const routes : Routes = [
  {
    path: '',
    component: GarageComponent,
    children: [
      {
          path:'garageList',component:GarageListComponent,
          data:
          {
              breadcrumb:{
                  label : 'bread_crump.garage_list',
                  info: 'Garage List'
              }
          }
      },
      {
          path:'AddNewGarage', component:GarageManageComponent,
          data:
          {
            breadcrumb:{
                label : 'bread_crump.garage_list_or_add_new_garage',
                info: 'Garage List / Add New Garage'
            }
        }
      },
      {
        path:'cloneGarage', component:GarageManageComponent,
        data:
        {
          breadcrumb:{
              label : 'bread_crump.garage_list_or_clone_garage',
              info: 'Garage List / Clone Garage'
          }
      }
    },
    {
      path:'editGarage', component:GarageManageComponent,
      data:
      {
        breadcrumb:{
            label : 'bread_crump.garage_list_or_edit_garage',
            info: 'Garage List / Edit Garage'
        }
    }
  },

      {
          path:'',redirectTo:'garageList',pathMatch:'full'
      }
  ]
  }
]
@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })


export class GarageRoutingModule{

}
