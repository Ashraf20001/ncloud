import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { MatCardModule } from "@angular/material/card";
import { MatIconModule } from "@angular/material/icon";
import { MatPaginatorModule } from "@angular/material/paginator";
import { MatTableModule } from "@angular/material/table";
import { MatTabsModule } from "@angular/material/tabs";
import { TranslateModule } from "@ngx-translate/core";
import { BreadcrumbModule, BreadcrumbService } from "xng-breadcrumb";
import { GarageCardComponent } from "./garage-card/garage-card.component";
import { GarageListComponent } from "./garage-list/garage-list.component";
import { GarageManageComponent } from "./garage-manage/garage-manage.component";
import { GarageRoutingModule } from "./garage-routing.module";
import { GarageComponent } from "./garage.component";
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTooltipModule } from "@angular/material/tooltip";
import { MatProgressSpinnerModule } from "@angular/material/progress-spinner";
import { CustomDirectiveModule } from "../../directive/directives/custom-directive.module";
import { AppCommonModule } from "../../common-components/app-common.module";
import { ErrorHandlerDirective } from "../../directive/directives/errorHandler.directive";
@NgModule({

    declarations:[
        GarageComponent,
        GarageCardComponent,
        GarageListComponent,
        GarageManageComponent
    ],
    imports:[
        GarageRoutingModule,
        CommonModule,
        FormsModule,
        MatTabsModule,
        TranslateModule,
        MatTableModule,
        MatPaginatorModule,
        MatIconModule,
        MatCardModule,
        MatSlideToggleModule,
        CustomDirectiveModule,
        MatTooltipModule,
        MatProgressSpinnerModule,
        BreadcrumbModule,
        AppCommonModule
    ],
    exports:[
        GarageRoutingModule,
       GarageComponent
    ],
    providers:[
        BreadcrumbService,
        ErrorHandlerDirective
    ]

})

export class GarageModule{

}