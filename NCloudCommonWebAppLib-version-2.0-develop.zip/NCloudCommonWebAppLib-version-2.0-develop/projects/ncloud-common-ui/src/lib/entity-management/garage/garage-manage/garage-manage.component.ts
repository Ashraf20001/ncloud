import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { BreadcrumbService } from 'xng-breadcrumb';
import { Field } from '../../../dto/entity-management/field';
import { Section } from '../../../dto/entity-management/section';
import { MetaDataDto } from '../../../dto/entity-management/meta-data-dto';
import { appConst } from '../../../const/app.const';
import { AccessMappingPageDto } from '../../../dto/access-Mapping-PageDto ';
import { EntityManagementService } from '../../../service/entitymanagement-service';
import { FileUploadService } from '../../../service/file-upload.service';
import { AppService } from '../../../service/app.service';
import { FileUploadDTO } from '../../../dto/entity-management/insurance-company';
import { CompanyFileSaveDto } from '../../../dto/entity-management/company-file-save-dto';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-garage-manage',
  templateUrl: './garage-manage.component.html',
  styleUrls: ['./garage-manage.component.scss']
})
export class GarageManageComponent implements OnInit {
  @Input() garagemanageshow:any;
  @Output() garagemanageshowplayback = new EventEmitter<any>();
  fileField?:Field;
  fieldSectionData?:Section[];
  sectionField?: Field[];
  metaDataDto? : MetaDataDto;
  pageId:string="30";
  aliasName?:string;
  garageId=null;
  fileName? : string;
  isActive: boolean =true;
  entitymetadata?: any;
  fileUrl?:string;
  mandatory?:boolean;
  nameShow?:boolean;
  imageList=[];
  fileObject:any;
  fileType?: string;

  appConst = appConst;
  pageInfo: any;
  garageAddPageAccessMap?: AccessMappingPageDto;
  isGarageAddPageEnabled = false;
  imgValue?: string;
  uploadId: any;
  enablePassword: boolean = false;
  companyFileSaveDto= new CompanyFileSaveDto();
  password: string;
  isEdit: boolean = false;

  constructor(private activateRoute:ActivatedRoute, private router: Router,private breadcrumbService: BreadcrumbService,
    private service : EntityManagementService, private fileService : FileUploadService,
    private tosterservice:ToastrService, private appService: AppService,
   private translate:TranslateService) {
      this.service.ClickAdd$.subscribe(value=>{
        if(value==true) {
          this.garageId=null;
        this.getData();
      }
    });
  }

  ngOnInit(): void {
    this.getPageAccessData();
  }

  doProcess(): void {
    this.getPrivilege();
    this.isActive=true;
    this.nameShow=false;
    this.activateRoute.queryParams.subscribe((queryParams : any)=>{
      this.garageId=queryParams['garageId'];
      if(this.garageId!=null) {
        this.getData();
      }
      let value=queryParams['garageCloneId'];
      if(value!=null||value!=undefined) {
        this.cloneGarage(value);
      }
    });
    // this.service.cloneIdPass.subscribe(value=>{
    //    this.cloneGarage(value);
    // })

  }

  getData(){
    this.service.getInsuranceOrGarageCompanyMetaData(this.pageId,this.garageId || '').subscribe((data)=>{
        if (this.fileName != undefined || this.fileName != null) {
          this.fileName = '';
        }
        if (data) {
       this.entitymetadata=data;
                this.metaDataDto=this.entitymetadata.metaData;
                this.isActive=this.entitymetadata.isActive;
                if(this.metaDataDto && this.metaDataDto.sectionList && this.metaDataDto.sectionList.length>0){
                      this.metaDataDto.sectionList.forEach((value)=>{
                          this.sectionField=value.fieldList;
                  })
          }   
                this.enablePassword = false;
                if(this.garageId!=null||this.garageId!=undefined){
                  this.nameShow=true;
                  if(this.metaDataDto && this.metaDataDto.sectionList){
                    this.metaDataDto.sectionList.forEach((value)=>{
                      value.fieldList?.forEach((data)=>{
                         if(data.fieldName==="emGaragePassword"){
                          data.mandatory= true;
                          this.enablePassword = true;
                         }
                         if(data.fieldType==="file"){
                          this.imageList = [];
                          if(data.value == null || data.value == undefined){
                            this.imageList.push('assets/company_logo/no_company_logo.jpg');
                          }else{
                            this.imageList.push(data.value);
                          }
                         }
                });
              });
                  }
          }
        }
      });
  }
  backbtn(){
    const obj={
      listpage:true,
      addpage:false
    }
    this.garagemanageshowplayback.emit(obj);
    this.router.navigateByUrl('/entitymanagement/garage/garageList');
    this.nameShow=false;
  }

  getImage(imageUrl: string, index: number): void{
    this.fileService.downloadImageByImageName(imageUrl).subscribe((response: Blob) => {
        const reader = new FileReader();
        reader.onload = (e) => {
          // this.imageList[index] = e.target?.result;
        };
        reader.readAsDataURL(new Blob([response]));
      this.fileObject=new File([response],"blobimage.jpeg");
      });
  }


  getStringInput(items: Field) {
    if (items.fieldType === 'String') {
      return true;
    }
    return false;
  }

  getTextInput(items: Field) {
    if (items.fieldType === 'text') {
      return true;
    }
    return false;
  }

  getNumberInput(items: Field) {
    if (items.fieldType === 'Long' || items.fieldType === 'Double') {
      return true;
    }
    return false;
  }

  getFileUploadInput(items: Field) {
    if (items.fieldType === 'file') {
      this.fileField=items;
      return true;
    }
    return false;
  }

  backToList(){
    const obj={
      listpage:true,
      addpage:false

    }
    this.garagemanageshowplayback.emit(obj);
    this.router.navigateByUrl('/entitymanagement/garage/garageList');

  }

  file: File = null; // Variable to store file

  // On file Select
  onChange(event: any) {

    if (event!==undefined) {
      this.file = event.target.files[0];
      let file: File = event.target.files[0];
      this.fileName = file.name;
      this.fileType = file.type;
      if(this.fileType!=="image/png" && this.fileType!=="image/jpg" && this.fileType!=="image/jpeg") {
        this.tosterservice.error('Upload Valid Image');
        this.fileName ='';
        //  this.fileField.value ='';
      }
    }

  }

  saveData(fieldData : Field[]){
    this.mandatory=true;
    this.nameShow=false;
    //--------Creating fileupload variable
    // this.insuranceCompanyData.isActive=this.isActive!=true?false:this.isActive;
    const fileData: FileUploadDTO = {
      fileList: [this.file],
      referenceId: this.garageId!,
      fieldName: this.fileField.fieldName
    };

    if (this.garageId == null) {
      this.isEdit = false;
    } else {
      this.isEdit = true;
    }

    let invalidFileFormat = false;
    let fileList: File[] = fileData.fileList;
    if (JSON.stringify(fileList) != JSON.stringify([null])) {
      fileList.forEach((file) => {
        const isValidfileFormat = this.validateFile(file);
        invalidFileFormat = isValidfileFormat;
      });
    }

    if (invalidFileFormat) {
      return;
    }

    if(this.metaDataDto && this.metaDataDto.sectionList){
      this.metaDataDto.sectionList.forEach((value)=>{
        value.fieldList=fieldData
        value.fieldList.forEach((field)=>{
          if(field.aliasName==='Password'){
           this.password= field.value;
          }
        })
  });
    }

    if(this.metaDataDto && this.metaDataDto.sectionList){
      this.metaDataDto.sectionList.forEach((value)=>{
        value.fieldList?.forEach((data)=>{
           if(data.mandatory===true){
           if(data.value==null || data.value==undefined || data.value.trim()==""){
            this.mandatory=false;
            }
          }
        });
      });
    }

    if(this.mandatory==true){
      if((this.garageId===null || this.garageId===undefined) && JSON.stringify(fileData.fileList)===JSON.stringify([null])){
        fileData.fileList=[this.fileObject];
      }
     this.service.saveInsuranceCompany(this.metaDataDto!,this.garageId || '',this.pageId,this.isActive).subscribe((data:any)=>{
            this.garageId = data?.toString();
            // assumed as created company id
            this.fileService.upload(
              fileData?.fileList,
              this.garageId,
              fileData?.fieldName
              ).subscribe((response)=>{
                if(response) {
                  const downloadUrl = response.content;
                 this.fileUrl=downloadUrl
                }

                this.companyFileSaveDto.referenceId=this.garageId;
                this.companyFileSaveDto.password=btoa(this.password);
                this.companyFileSaveDto.pageId=this.pageId;
                this.companyFileSaveDto.isEdit=null
                this.companyFileSaveDto.fileUrl=this.fileUrl;

                this.service.saveFile(this.companyFileSaveDto).subscribe((res :any) =>{
                  if(res.content){
                    this.garageId = res.content;
                  }
                });

                    });
              if(this.garageId!=null||this.garageId!=undefined){
                this.tosterservice.success("Saved Successfully","",{
                  timeOut:1000,
                });
                setTimeout(()=>{
                  const obj={
                    listpage:true,
                    addpage:false
                  }
                      this.garagemanageshowplayback.emit(obj);
                  this.router.navigateByUrl('/entitymanagement/garage/garageList');
                 this.clearFieldValues(fieldData) ;
                      this.service.setAddNew(true);
                },1000);
                  }
                });


    }
  else{
    this.tosterservice.error("Mandatory Fields Is Yet to Fill","",{
      timeOut:3000,
    })
  }

     }

     toggleActive(event:any){
      this.isActive=event.checked;
  }
  /**
   * New garage-Field values clear After add
   * @param fieldData
   */
  clearFieldValues(fieldDataValue: any) {
      fieldDataValue.filter((ele: any) =>{
        ele.value = " ";
    });
     this.fileName = "";
  }

  cloneGarage(value: any){
            this.service.getInsuranceOrGarageCompanyMetaData(this.pageId,value).subscribe((data)=>{
        if (data) {
                          this.entitymetadata=data;
                         this.metaDataDto=this.entitymetadata.metaData;
                         this.isActive=this.entitymetadata.isActive;
                         if(this.metaDataDto && this.metaDataDto.sectionList && this.metaDataDto.sectionList.length>0){
                               this.metaDataDto.sectionList.forEach((value)=>{
                                   value.fieldList?.forEach(element=>{
                                      if(element.aliasName==="Garage ID"){
                                          element.value="";
                }
              });
                                   this.sectionField=value.fieldList;
                           })
          }
                         if(value!=null||value!=undefined){
                           this.nameShow=true;
                           if(this.metaDataDto && this.metaDataDto.sectionList){
                            this.metaDataDto.sectionList.forEach((value)=>{
                              value.fieldList?.forEach((data)=>{
                                 if(data.fieldName==="emGaragePassword"){
                                   data.value = "";
                                   data.mandatory = false;
                                   this.enablePassword = false;
                                
                 }
                                 if(data.fieldType==="file"){
                   this.imgValue = data.value;
                 }
               });
             });
                           }

          }
        }
            })
  }

  getPrivilege(){
    this.appService.getPrivilegeForPage(appConst.PAGE_NAME.ENTITYMANAGEMENT.GARAGE.GARAGE_ADD.PAGEID).subscribe((res: any)=>{
        this.pageInfo = res.content;
      });
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege.isEnabled;
    }
    return isEnabled;
  }

  validateFile(file: File) {
    const fileSize = file.size;
    const allowedFileSize = 1024 * 1024 * 5; // allowed size 5MB
    const fileExtensions = file.name.split(".").slice(1);

    if (fileSize > allowedFileSize) {
      this.tosterservice.error(this.translate.instant('File_errors.file_size_error'));
      return true;
    }
    const allowedMimeTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/svg+xml'];
    // if (fileExtensions.length > 1) {
    //   this.tosterservice.error(this.translate.instant('Toaster_error.invalid_phone_number'));
    //   return true;
    // }
    if (!allowedMimeTypes.includes(file.type)) {
      this.tosterservice.error(this.translate.instant('File_errors.invalid_type'));
      return true;
    }
    return false;
  }

  getPageAccessData(): void {
    this.appService.getPageAccess(appConst.PAGE_NAME.ENTITYMANAGEMENT.GARAGE.GARAGE_ADD.PAGE_IDENTITY).subscribe((response: any) => {
        this.garageAddPageAccessMap = response.content;
        this.isGarageAddPageEnabled = this.garageAddPageAccessMap?.isEnabled || false;
      if(this.isGarageAddPageEnabled) {
          this.doProcess();
        }
      });
  }

  showPassword=false;
  togglePasswordVisibility()
   {
     this.showPassword = !this.showPassword;
   }

   setDefaultLogoImage(){
    this.imageList[0]='assets/company_logo/no_company_logo.jpg';
  }
}
