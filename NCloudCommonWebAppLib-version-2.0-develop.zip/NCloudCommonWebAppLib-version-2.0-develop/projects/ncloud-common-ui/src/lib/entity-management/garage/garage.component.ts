import { Component, Input } from '@angular/core';
import { EntityManagementService } from '../../service/entitymanagement-service';

@Component({
  selector: 'app-garage',
  templateUrl: './garage.component.html',
  styleUrls: ['./garage.component.css']
})
export class GarageComponent {

  @Input() searchValueFromParent?:string;
  
  listshow = true;
  addshow = false;
  constructor(private service : EntityManagementService){

  }
  ngOnInit(): void {

    this.service.cardShow.subscribe(value=>{
          this.listshow=value;
          this.addshow=true;
    })

    this.service.listpage.subscribe((val)=>{
      this.listshow=val;
      this.addshow=false;
    })

  }
  listmethod(event:any){
    this.listshow = event.listpage;
    this.addshow = event.addpage;
  }
  addmethod(event:any){
    this.listshow = event.listpage;
    this.addshow = event.addpage;
  }

}
