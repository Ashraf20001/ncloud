import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { appConst } from '../../../const/app.const';
import { AccessMappingPageDto } from '../../../dto/access-Mapping-PageDto ';
import { EntityManagementService } from '../../../service/entitymanagement-service';
import { FileUploadService } from '../../../service/file-upload.service';
import { DashboardService } from '../../../service/dashboard.service';
import { AppService } from '../../../service/app.service';
import { DisablePopupComponent } from '../../../common-components/disable-popup/disable-popup.component';
import { PopupComponent } from '../../../common-components/popup/popup.component';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-garage-card',
  templateUrl: './garage-card.component.html',
  styleUrls: ['./garage-card.component.scss']
})
export class GarageCardComponent implements OnInit{


  garageListData?:any[];
  ActiveSts="Active";
  InActiveSts = "InActive";
  imageList=[];
  minLength= 0;
  maxLength= 0;

  appConst = appConst;
  pageInfo: any;
  garageCardPageAccessMap?: AccessMappingPageDto;
  isCardPageEnabled = false;
  searchvalue?: string;
  showCard?: boolean;
  filteredGarageCardList?: any[];
  garageDataList:any;
  dataNotFound: boolean;

  @Output() getGarageListFromParent:EventEmitter<any> = new EventEmitter<{listData: any}>;
  constructor(private service: EntityManagementService,private router: Router,private dialog:MatDialog,
    private fileService:FileUploadService,private dashboardService: DashboardService,private appService: AppService, private route: ActivatedRoute,private toaster:ToastrService,
  private translate: TranslateService) {

      this.route.queryParams.subscribe((queryParams: any) => {
        this.searchvalue = queryParams['garageSearchQuery'];
        this.searchvalue = queryParams['garageSearchQuery'];
         if(this.searchvalue === undefined || this.searchvalue === null || this.searchvalue ===""){
          this.showCard=true;
         }else{
          this.showCard=false;
         }
         this.filter(this.searchvalue || '');
      });

    }


  /**
   * GarageCard Search Filter
   *
   */
    filter(searchvalue: string) {
      if(searchvalue !== undefined){
       this.filteredGarageCardList =this.garageListData?.filter((m) => String(m.emGarageName.toUpperCase()).includes(searchvalue.toUpperCase()));
       this.dataNotFound = false; 
       if(this.filteredGarageCardList?.length === 0){
        this.dataNotFound = true;
       }
      }
    }

  ngOnInit(): void {
    this.searchvalue = null || '';
    this.getPageAccessData();
  }

  doProcess(): void {
    this.getPrivilege();
    this.getGarageList(this.minLength,this.maxLength);
  }

  // getTotalCount(){
  //   this.service.getGarageListCount().subscribe(((res:any)=>{
  //     this.minLength =0;
  //     this.maxLength = res;
  //     this.getGarageList(this.minLength, this.maxLength);
  //   }));
  // }

 /**
   * getGarageDetails
   */
 getGarageList(min:number,max:number){
  this.service.getGarageList(min,max).subscribe((data) => {
    this.garageListData = data;
    this.filteredGarageCardList = data;
    this.dataNotFound = false;
    if(this.garageListData.length == 0){
      this.dataNotFound = true;
    }
    this.searchvalue = null || '';
    this.getGarageListFromParent.emit({
      listData : data
    })
    this.garageListData.forEach(obj => {
      obj.loading = true;
    });
    //  for(let i=0;i<data.length;i++){
    //     if(this.garageListData.length>12) {
    //         this.garageListData = this.garageListData.slice(0,12)}
    //       }
  });

}
  onEdit(value: any){
    this.service.setAddNew(false);
    this.router.navigate(['entitymanagement/garage/editGarage'], {queryParams: {garageId : value?.emGarageId}});
    this.service.showCard(false);
  }
  /*
  * DeleteGarage Card
  */
  DeleteGarage(value: any) {
    const dialogRef = this.dialog.open(PopupComponent, {
      width: 'auto',
      height: 'auto',
      data: {
        status: value.emGarageIsActive ? 'Active' : 'InActive',
        name: "Garage",
        okButton: "Ok",
        cancelButton: "Cancel",
        delete:"deleteText",
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const inputDate = new Date(result);
        const timeZoneOffsetMinutes:number = new Date().getTimezoneOffset();
        inputDate.setMinutes((inputDate.getMinutes() - timeZoneOffsetMinutes) + 1439 );
        const garageDisableObj ={
          'expiredDate':inputDate,
          'identity':value?.emGarageIdentity,
          'garageId':value?.emGarageId
        }
        this.service.DeleteGarage(garageDisableObj).subscribe((data)=>{
          if(data){
            this.toaster.success(this.translate.instant('Toaster_success.garage_deleted'));
            this.getGarageList(this.minLength,this.maxLength);
          }
        })
        }
     });
    return false;
  }

  onClone(event:any){
    this.router.navigate(['entitymanagement/garage/cloneGarage'], {queryParams: {garageCloneId : event?.emGarageId}});
    this.service.showCard(false);
  }

  getPrivilege(){
    this.appService.getPrivilegeForPage(appConst.PAGE_NAME.ENTITYMANAGEMENT.GARAGE.GARAGE_CARD.PAGEID).subscribe((res: any)=>{
      this.pageInfo = res.content;
    });
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege?.isEnabled;
    }
    return isEnabled;
  }

  getPageAccessData(): void {
    this.appService.getPageAccess(appConst.PAGE_NAME.ENTITYMANAGEMENT.GARAGE.GARAGE_CARD.PAGE_IDENTITY).subscribe((response: any) => {
      this.garageCardPageAccessMap = response.content;
      this.isCardPageEnabled = this.garageCardPageAccessMap?.isEnabled || false;
      if(this.isCardPageEnabled) {
        this.doProcess();
      }
    });
  }

  setDefaultLogo(garage:any){
    garage.emGarageLogo = 'assets/company_logo/no_company_logo.jpg';
    garage.loading=false;

  }
  onImageLoad(garage:any){
    garage.loading = false;
  }

  loadingSpinner(garage: any){
    if(garage){
      return garage.loading;
    } else {
      return false;
    }
  }
}
