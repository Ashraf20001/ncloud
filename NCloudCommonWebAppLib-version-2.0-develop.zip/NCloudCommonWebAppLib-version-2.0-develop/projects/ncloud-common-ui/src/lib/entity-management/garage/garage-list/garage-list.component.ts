import { AfterViewInit, ChangeDetectorRef, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { NavigationEnd, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { GarageDto } from '../../../dto/garage-dto';
import { appConst } from '../../../const/app.const';
import { AccessMappingPageDto } from '../../../dto/access-Mapping-PageDto ';
import { I18nServiceService } from '../../../service/i18n-service.service';
import { EntityManagementService } from '../../../service/entitymanagement-service';
import { FileUploadService } from '../../../service/file-upload.service';
import { AppService } from '../../../service/app.service';
import { DisablePopupComponent } from '../../../common-components/disable-popup/disable-popup.component';
import { PopupComponent } from '../../../common-components/popup/popup.component';
import { debounceTime, Subject } from 'rxjs';
import { ErrorHandlerDirective } from '../../../directive/directives/errorHandler.directive';
@Component({
  selector: 'app-garage-list',
  templateUrl: './garage-list.component.html',
  styleUrls: ['./garage-list.component.scss']
})
export class GarageListComponent implements OnInit,OnChanges{
  @Input() garagelistshow:any;
  @Input() searchValueFromGarage?:string;

  @Output() garagelistshowplayback = new EventEmitter<any>();
  // @ViewChild(MatPaginator,{ static: true }) paginator: MatPaginator;
  @ViewChild(MatPaginator) page?:MatPaginator;
  @ViewChild('paginator') paginator?: MatPaginator;

  show=true;
  showAddGarage=true;
  addScreen?:boolean;
  tableList: any;
  currentLang = 'English';
  ZERO=0;
  TEN=10;
  showtabledata?: GarageDto[];
  getgaragelist:GarageDto[];
  GarageListElement? :GarageDto;
  is_download=false;
  pageCount?: number;
  imageList = [];
  minLength?: number = 0;
  maxLength?: number = 10;
  endingIndex=10;
  dataNotFound=false;

  appConst = appConst;
  pageInfo: any;
  garageListPageAccessMap?: AccessMappingPageDto;
  isListPageEnabled = false;
  searchValue: any;
  closeIcon:boolean = false;
  currentRoute?: string;

  garageListFromParent : any;
  pageChangedEvent = new Subject<number>();
  customPageIndex: number = 0;
  currentPageIndex: number;
  backButton: boolean = false;
  displayedColumns: string[] = ['Logo','GarageName', 'EmailAddress', 'PhoneNumber', 'Address' ,'Status','Edit','Disable'];

  constructor( private router:Router, public i18Service:I18nServiceService,private paginatorName: MatPaginatorIntl,
    public translate: TranslateService,private entityService:EntityManagementService,private dialog:MatDialog,
    private fileService : FileUploadService, private appService: AppService,private route:Router,private toaster:ToastrService,
    private detector: ChangeDetectorRef,private errorHandler: ErrorHandlerDirective){
      this.entityService.ClickAdd$.subscribe((value)=>{
        if(value===true){
          this.getTableList(this.minLength,this.maxLength);
        }
      })
      this.paginatorName.itemsPerPageLabel = this.translate.instant("Paginator.ItemsPerPageLabel");
      this.getCurrentUrl();
      this.translateLabels();
      this.getSessionValue();
  }

   /**
   * GetCurrentUrl
   */
  getCurrentUrl(){
    this.currentRoute = window.location.href;
    this.route.events.subscribe((event: any) => {
      if (event instanceof NavigationEnd) {
        this.currentRoute = event.url
      }
    });

  }
  ngOnInit() {
    debugger;
    this.getPageAccessData();
    this.translate.onLangChange.subscribe(() => {
      this.translateLabels();
    });
    this.pageChangedEvent.pipe(debounceTime(300)).subscribe((data: number) => {
      this.changePageIndex();
    });
  }

  doProcess(): void {
    this.getPrivilege();
    this.getTableList(this.minLength,this.maxLength);
    if(this.paginator) {
      this.paginatorName.itemsPerPageLabel = this.translate.instant("Paginator.ItemsPerPageLabel");
    }
  }
  dataSource = new MatTableDataSource<GarageDto>();


  // ngAfterViewInit() {
  //   this.dataSource.paginator = this.paginator;
  // }

  shoeCardorList(){
    // this.entityService.setAddNew(true);
    this.getTableList(this.minLength,this.maxLength);
    this.show=!this.show;
  }

  // getTotalCount(){
  //   this.entityService.getGarageListCount().subscribe(((res:any)=>{
  //     this.minLength =0;
  //     this.maxLength = 10;
  //     this.pageCount = res;
  //     this.getTableList(this.minLength, this.maxLength);
  //   }));
  // }


  getTableList(min:number,max:number){
    this.showtabledata =[];
    this.dataSource = null;
    this.getgaragelist = [];
    this.entityService.getGarageList(min,max).subscribe(res => {
      if(res){
        this.getgaragelist = res;
        if (this.getgaragelist===null || this.getgaragelist.length===0) {
          this.dataNotFound = true;
         }
         else{
          this.dataNotFound = false;
         }
         for(const res of this.getgaragelist){
          this.getEmptyGarageListElement();
          this.GarageListElement.emGarageId =res.emGarageId;
          this.GarageListElement.emGarageAddress = res.emGarageAddress;
          this.GarageListElement.emGarageEmail = res.emGarageEmail;
          this.GarageListElement.emGarageIsActive = res.emGarageIsActive?'Active':'InActive';
          this.GarageListElement.emGarageName = res.emGarageName;
          this.GarageListElement.emGaragePhone = res.emGaragePhone;
          this.GarageListElement.emGarageLogo = res.emGarageLogo;
          this.GarageListElement.emGarageIdentity = res.emGarageIdentity;
          this.GarageListElement.isDisableGarage = res.isDisableGarage ? 'Disabled': this.GarageListElement.emGarageIsActive;
          if(this.GarageListElement.isDisableGarage === 'Disabled'){
            this.GarageListElement.emGarageIsActive = this.GarageListElement.isDisableGarage;
          }
          this.showtabledata.push( this.GarageListElement);
          this.dataSource=new MatTableDataSource<GarageDto>(this.showtabledata);
        }
      }
    },(error: Response) => {
      this.errorHandler.getMessage(error);
    });
  }

  getEmptyGarageListElement(){
   this.GarageListElement={
    emGarageId:0,
    emGarageShortId:"",
    emGarageName:"",
    emGarageEmail:"",
    emGarageLocation : "",
    emGarageAddress :"",
    emGaragePassword : "",
    emGarageUserId : "",
    emGarageLogo : "",
    emGaragePhone : "",
    emGarageIsActive:"",
    emGarageIdentity:"",
    isDisableGarage :"",
    loading:true
  };
  }

  addNewGarage(){
    this.entityService.setAddNew(true);
    const obj={
      listpage:false,
      addpage:true
    }
    this.garagelistshowplayback.emit(obj);
    this.searchValue =null;
    this.router.navigateByUrl("/entitymanagement/garage/AddNewGarage");
  }
  backbtn(){
    const obj={
      listpage:true,
      addpage:false
    }
    this.searchValue =null;
    this.garagelistshowplayback.emit(obj);
    this.router.navigateByUrl("/entitymanagement/garage/garageList");
  }

  onEdit(value: any){
    if(value.isDisableGarage !== 'Disabled'){
    const obj={
      listpage:false,
      addpage:true
    }
    this.searchValue =null;
    this.garagelistshowplayback.emit(obj);
    this.router.navigate(["/entitymanagement/garage/editGarage"],{ queryParams: {garageId : value.emGarageId}});
  }
  }

  changePage(event){

    if(event.pageIndex > event.previousPageIndex ){
      //previous
      this.customPageIndex = event.pageIndex+1;
    }else{
     // next
     this.customPageIndex =  this.customPageIndex-1;
    }
    if(event.pageIndex != this.ZERO){
      this.maxLength= event.pageSize;
      this.minLength = event.pageSize * event.pageIndex;
      this.endingIndex = event.pageSize;
      this.pageIndex = this.customPageIndex;
    }else{
      this.maxLength= event.pageSize;
      this.minLength = event.pageIndex;
      this.endingIndex = event.pageSize;
      this.pageIndex = event.pageIndex+1;
    }
    this.getTableList(this.minLength,this.maxLength);
  }
  pageIndex = 1;


  pageindex()
  {
    this.pageChangedEvent.next(this.pageIndex);
  }

  changePageIndex(): void {
    if (this.pageIndex > 0) {
      const totalPageIndex = this.pageCount / this.endingIndex + 1;
      if(this.pageIndex > totalPageIndex) {
        this.pageIndex = this.customPageIndex === 0 ? 1 : this.customPageIndex;
        return;
      }
      this.customPageIndex = this.pageIndex;
      this.currentPageIndex = this.pageIndex - 1;
      this.maxLength = this.endingIndex;
      this.minLength = this.endingIndex * this.currentPageIndex;
      this.getTableList(this.minLength,this.maxLength);
    }
  }
  // getUrl(data:string){
  //     let img;
  //     this.fileService.downloadFile(data).subscribe(response=>{
  //         img=response;
  //     })
  //     return of(img);
  // }


 /*
  * DeleteGarage List By Identity
  */
 DeleteIdentiy(value:any) {
  if(value.isDisableGarage !== 'Disabled'){
  const dialogRef = this.dialog.open(PopupComponent, {
    width: 'auto',
    height: 'auto',
    data: {
      status: value.emGarageIsActive ? 'Active' : 'InActive',
      name: "Garage",
      okButton: "Ok",
      cancelButton: "Cancel",
      delete:"deleteText",
    }
  });
  dialogRef.afterClosed().subscribe(result => {
    if (result) {
      const inputDate = new Date(result);
      const timeZoneOffsetMinutes:number = new Date().getTimezoneOffset();
      inputDate.setMinutes((inputDate.getMinutes() - timeZoneOffsetMinutes) + 1439 );
      const garageDisableObj ={
        'expiredDate':inputDate,
        'identity':value?.emGarageIdentity,
        'garageId':value?.emGarageId
      }
      this.entityService.DeleteGarage(garageDisableObj).subscribe((data)=>{
        if(data){
          this.toaster.success(this.translate.instant('Toaster_success.garage_deleted'));
          this.getTableList(this.minLength,this.maxLength);
        }
      })
      }
   });
  return false;
  }
  return true;
}
  /*
  * DownloadGarageListExcel
  */
  download(){
    this.entityService.downloadGarageListExcel().subscribe((response: any)=>{
      if (response) {
        const blob = new Blob([response],
          { type: 'application/vnd.ms-excel' });
        const file = new File([blob], 'Garage_List.xlsx',
          { type: 'application/vnd.ms-excel' });
        const fileURL = URL.createObjectURL(file);
        const a         = document.createElement('a');
        a.href        = fileURL;
        a.target      = '_blank';
        a.download    = "Garage_List"+'.xlsx';
        document.body.appendChild(a);
        a.click();
        this.toaster.success(this.translate.instant("Toaster_Message.Garage_list_download"));
      }
    })
  }

  getPrivilege(){
    this.appService.getPrivilegeForPage(appConst.PAGE_NAME.ENTITYMANAGEMENT.GARAGE.GARAGE_CARD.PAGEID).subscribe((res: any)=>{
      this.pageInfo = res.content;
    });
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege?.isEnabled;
    }
    return isEnabled;
  }

  getPageAccessData(): void {
    this.appService.getPageAccess(appConst.PAGE_NAME.ENTITYMANAGEMENT.GARAGE.GARAGE_LIST.PAGE_IDENTITY).subscribe((response: any) => {
      this.garageListPageAccessMap = response.content;
      this.isListPageEnabled = this.garageListPageAccessMap?.isEnabled || false;
      if(this.isListPageEnabled) {
        this.searchValue='';
        this.doProcess();
      }
    });
  }

  trimLeadingSpace() {
    this.searchValue = this.searchValue.replace(/^\s+/g, '');
  }
  search(){
    this.trimLeadingSpace();
    this.closeIcon = true;
    this.route.navigate([], { queryParams: {garageSearchQuery: this.searchValue }, queryParamsHandling: 'merge' });
  }
   /*
  *Clear the value after tab change
  */
  ngOnChanges(changes: SimpleChanges): void {
    if(changes){
      if (changes['searchValueFromGarage'].currentValue) {
        this.searchValue=""
      }
    }    
  }

  getGarageListForTable(data: any){
    this.garageListFromParent = data;
  }

  setDefaultLogo(garage:any){
    garage.emGarageLogo = 'assets/company_logo/no_company_logo.jpg';
    garage.loading=false;

  }
  onImageLoad(garage:any){
    garage.loading = false;
  }

  loadingSpinner(garage: any){
    if(garage){
      return garage.loading;
    } else {
      return false;
    }
  }

  private translateLabels() {
    if(this.paginatorName) {
      this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
      this.paginatorName.firstPageLabel = this.translate.instant('Paginator.FirstPage');
      this.paginatorName.lastPageLabel = this.translate.instant('Paginator.LastPage');
      this.paginatorName.nextPageLabel = this.translate.instant('Paginator.NextPage');
      this.paginatorName.previousPageLabel = this.translate.instant('Paginator.PreviousPage');
    }
    if (this.paginator) {
      this.paginator._intl.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
      this.paginator._changePageSize(this.paginator.pageSize);
      this.detector.detectChanges();
    }
  }

 /* 
  * Get Session Value for Garage ShowCard Or List & Back Button
  */
 private getSessionValue() {
   if (sessionStorage?.getItem('garageShowCardOrList') && sessionStorage?.getItem('garageListBackBtn')) {
     this.show = sessionStorage.getItem('garageShowCardOrList') == "true";
     this.backButton = sessionStorage.getItem('garageListBackBtn') == "true";
   }
 }
 /*
  *  Remove Company button Status
  */
 ngOnDestroy(): void {
   sessionStorage.removeItem('showCompanyList');
   sessionStorage.removeItem('showBackBtn');
 }
 onKeyDown(event: KeyboardEvent) {
  if (event.keyCode === 190) {
    event.preventDefault();
  }
}
removeValue(){
  this.searchValue = '';
  this.closeIcon = false;
  this.route.navigate([], { queryParams: {garageSearchQuery: this.searchValue }, queryParamsHandling: 'merge' });
}

handleKeyup(event: KeyboardEvent) {
  if (event.key === 'Backspace' && this.searchValue === '' && this.closeIcon) {
    this.closeIcon = false;
  }
}

}
