import { AfterViewInit, ChangeDetectorRef, Component, EventEmitter, Input, OnChanges, OnDestroy, Output, SimpleChanges, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router, NavigationEnd } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import * as jspdf from 'jspdf';
import html2canvas from 'html2canvas';
import { InsuranceCompanyDto } from '../../../dto/entity-management/insurance-company';
import { appConst } from '../../../const/app.const';
import { AccessMappingPageDto } from '../../../dto/access-Mapping-PageDto ';
import { I18nServiceService } from '../../../service/i18n-service.service';
import { EntityManagementService } from '../../../service/entitymanagement-service';
import { FileUploadService } from '../../../service/file-upload.service';
import { AppService } from '../../../service/app.service';
import { PopupComponent } from '../../../common-components/popup/popup.component';
import {FilterObject} from '../../../dto/Filter-dto/filter-object';
import {FilterOrSortingVo} from '../../../dto/Filter-dto/filter-object-backend';
import { AccessMappingSectionDto } from '../../../dto/Filter-dto/section-dto';
import { MenuSectionNames } from '../../../const/enum';
import { ToastrService } from 'ngx-toastr';
import { FileTypeEnum } from '../../../dto/FileTypeEnum';
import { Subject, Subscription, debounceTime } from 'rxjs';

@Component({
  selector: 'app-company-list',
  templateUrl: './company-list.component.html',
  styleUrls: ['./company-list.component.scss']
})
export class CompanyListComponent implements OnChanges,OnDestroy,AfterViewInit{
  @Input() companylistshow: any;
  @Input() backToCardStatusFromParent:boolean
  @Output() companylistshowplayback = new EventEmitter<any>();
  @Output() isListShow = new EventEmitter<boolean>();
 
  @ViewChild(MatPaginator) page?: MatPaginator;
  show = true;
  showAddCompany = true;
  addScreen?: boolean;
  tableList: any;
  userId: any;
  currentLang = 'English';
  ZERO = 0;
  TEN = 10;
  dataNotFound = false;
  isGotToPageDissabel=false;
  showtabledata?: InsuranceCompanyDto[];
  getcompanylist?: InsuranceCompanyDto[];
  insCompanyListDto?: InsuranceCompanyDto;
  is_download = false;
  pageCount?: number;
  imageList = [];
  minLength?: number;
  maxLength?: number;
  endingIndex = 10;
  companyHeading = false;
  appConst = appConst;
  pageInfo: any;
  companyListPageAccessMap?: AccessMappingPageDto;
  isListPageEnabled = false;
  remainperiodSort:any;
  isAscOrder?: boolean;
  companyname?: boolean=true;
  Emailsort?: boolean=true;
  Addressot?: boolean=true;
  phonenumbersort?: boolean=true;
  cardsearch: any;
filterVoObject: FilterOrSortingVo[] = [];
  statussort?: boolean=true;
  maximum: number;
  pagesize: any;
  remainder: number;
  currentRoute: string;
  companyListPageAccessDto: AccessMappingSectionDto;
  companyCardPageAccessDto: AccessMappingSectionDto;
  addCompanyPageAccessDto: AccessMappingSectionDto;
  platformId: any;
  private searchSubject = new Subject<number>();
  searchValueForList="";
  companyListShowSubscription: Subscription;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  rowPerPageSubscription: Subscription;
  constructor(private router: Router, public i18Service: I18nServiceService,private paginatorName: MatPaginatorIntl,
    private detector: ChangeDetectorRef,
    public translate: TranslateService, private entityService: EntityManagementService, private dialog: MatDialog,
    private fileService: FileUploadService, private appService: AppService,
    private toaster: ToastrService) {
      this.getCurrentUrl();
    this.companyListShowSubscription=this.entityService.ClickAdd$.subscribe((value) => {
      if (value === true) {
        this.getTableList(this.ZERO, this.TEN,this.filterVoObject ,this.searchValueForList );
        this.show=true;
      }
    })
    if(this.paginatorName) {
      this.rowPerPageSubscription=this.translate.get('Paginator.ItemsPerPageLabel').subscribe((translation: string) => {
        this.paginatorName.itemsPerPageLabel = translation;
      });

    }

   
    this.searchSubject .pipe(debounceTime(300)).subscribe((pageIndex: number) => {
      this.changePageIndex();
    });

    this.entityService.cardViewShowOnBackButtonFromList.subscribe((value)=>{
      if(value){
        this.showCardViewOnListBackButtonTrigger();
      }
    })
  }
  ngOnDestroy(): void {
    sessionStorage.removeItem('CompanyList');
    this.companyListShowSubscription.unsubscribe();
    this.rowPerPageSubscription.unsubscribe();
  }

  ngAfterViewInit(): void {

    if(this.paginatorName) {
     this.rowPerPageSubscription= this.translate.get('Paginator.ItemsPerPageLabel').subscribe((translation: string) => {
        this.paginatorName.itemsPerPageLabel = translation;
      });

    }
  }
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['backToCardStatusFromParent']?.currentValue !== undefined) {
      this.show = this.backToCardStatusFromParent;
    }
  }
  searchItem(event){
    // this.searchValueForList =event.target.value;
    if(event instanceof Object){
      return;
    }
    this.searchValueForList =event;
    if(this.show){
      this.router.navigate([], { queryParams: { recSearchQuery: this.searchValueForList} });
    }
    else{
      this.getTotalCount(this.filterVoObject, this.searchValueForList);
    }
}
  
  ngOnInit() {
    const isList=sessionStorage.getItem('CompanyList');
    if (this.currentRoute.includes('AddnewCompany')) {
      this.addNewCompany();
      return;
    }
    this.getPageAccessData();
    if(this.show===false){
      if(this.isListPageEnabled) {
        this.doProcess();
      }
    }
    if(isList){
      this.show=false;
      this.doProcess();
      
    }
    else{
      this.show=true;
    }
    this.isListShow.emit(this.show);
    this.translate.onLangChange.subscribe(() => {
      if (this.paginator) {
        this.paginator._intl.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
        this.paginator._changePageSize(this.paginator.pageSize);
        this.detector.detectChanges();
      }
    });
    if(this.paginatorName) {
      this.rowPerPageSubscription=this.translate.get('Paginator.ItemsPerPageLabel').subscribe((translation: string) => {
        this.paginatorName.itemsPerPageLabel = translation;
      });

    }
  }

    doProcess(): void {
    // this.getPrivilege();
      this.getTotalCount(this.filterVoObject, this.searchValueForList);
    
    if (this.paginator) {
      this.rowPerPageSubscription=this.translate.get('Paginator.ItemsPerPageLabel').subscribe((translation: string) => {
        this.paginatorName.itemsPerPageLabel = translation;
      });

    }
  }
  displayedColumns: string[] = ['Logo', 'Company Name', 'Email Address', 'Phone Number', 'Address', 'Clone', 'Edit'];
  dataSource = new MatTableDataSource<InsuranceCompanyDto>();


  // ngAfterViewInit() {
  //   this.dataSource.paginator = this.paginator;
  // }

  shoeCardorList() {
    this.entityService.setAddNewSubscription(false);
    this.show = !this.show;
    if(this.show==false){
      sessionStorage.setItem('CompanyList','list');
      if(this.isListPageEnabled) {
        this.doProcess();
      }
    }
    else{
      sessionStorage.setItem('CompanyList','');
    }
    this.isListShow.emit(this.show)
    //this.companyHeading = !this.companyHeading;
  }
onpagebackward()
{
  if (this.getTotalCount.length == 0) {
      this.dataNotFound = false;
    }
}
  getTotalCount(filter:FilterOrSortingVo[], searchValue:string) {
    this.pageIndex=1;
    this.entityService.getInsuranceCount(filter, searchValue).subscribe(((res: any) => {
      this.minLength = 0;
      this.pageCount = res
      const totalNUmber = this.pageCount / 10;
      if (this.isFloat(totalNUmber)) {
        this.maximum =  Math.floor(totalNUmber+1);
      }else{
        this.maximum = totalNUmber;
      }
      this.maxLength = 10;
      this.getTableList(this.minLength, this.maxLength,filter, this.searchValueForList );
    }));
  }

  isFloat(n: number): boolean {
    return Number(n) === n && n % 1 !== 0;
  }

  getTableList(min: number, max: number,filter:FilterOrSortingVo[], searchValue:string) {
    this.entityService.getInsuranceList(min, max,filter, searchValue).subscribe((data: any) => {
      const companyListResponce = data;
      if(companyListResponce.length !==0){
       this.isGotToPageDissabel = false;

        this.getcompanylist = data;
        if (this.getcompanylist?.length === 0) {
          this.dataNotFound = true;
            this.showtabledata = [];
        } else {
          this.dataNotFound = false;
        }
        this.showtabledata = [];
        for (const res of companyListResponce) {
          this.getEmptyCompantList();
          if(this.insCompanyListDto){
            this.insCompanyListDto.emInsAddress = res.emInsAddress;
            this.insCompanyListDto.emInsCompanyId = res.emInsCompanyId;
            this.insCompanyListDto.emInsEmail = res.emInsEmail;
            this.insCompanyListDto.emInsIsActive = res.emInsIsActive ? 'Active' : 'InActive';
            this.insCompanyListDto.emInsName = res.emInsName;
            this.insCompanyListDto.emInsPhone = res.emInsPhone;
            this.insCompanyListDto.emInsLogo = res.emInsLogo;
            this.showtabledata.push(this.insCompanyListDto);
          }
        }
        this.dataSource = new MatTableDataSource<InsuranceCompanyDto>(this.showtabledata);
      }else{
        this.isGotToPageDissabel = true;
        this.dataNotFound=true;
        this.showtabledata=[];
       this.dataSource = new MatTableDataSource<InsuranceCompanyDto>(this.showtabledata);
      }

      const isList=sessionStorage.getItem('CompanyList');
      if(isList!=null && isList!=undefined && isList!=''){
        this.show=false;
        this.entityService.setAddNewSubscription(false);
        this.isListShow.emit(this.show)
      }

    })
    this.router.navigateByUrl("/entitymanagement/insuranceCompany/companyList");
  }
  getEmptyCompantList() {
    this.insCompanyListDto = {
      emInsCompanyId: 0,
      emInsName: "",
      emInsPhone: "",
      emInsEmail: "",
      emInsPassword: "",
      emInsLocation: "",
      emInsAddress: "",
      emInsMaxPayableAmount: 0,
      emMaxTime: 0,
      emInsLogo: "",
      emInsIsActive: "",
      emInsShortName: "",
      emInsExceedDate: new Date
    }
  }


  getEditCloneVisibilityData(event:any){
      const obj={
        listpage:false,
        addpage:true,
        addShow:false,
        editpage:event.editShow,
        clonepage:event.cloneShow
      }
      this.companylistshowplayback.emit(obj); 
  }

  addNewCompany() {
    this.entityService.setAddNewSubscription(true);
    this.show=true;
    const obj = {
      listpage: false,
      addpage: true,
      addShow:true,
      editpage:false,
      clonepage:false,
    }
    this.companylistshowplayback.emit(obj);
    this.router.navigateByUrl("/entitymanagement/insuranceCompany/AddnewCompany");
  }
  backbtn() {
    const obj = {
      listpage: true,
      addpage: false,
      addShow:false,
      editpage:false,
      clonepage:false
    }
    this.companylistshowplayback.emit(obj);
    this.router.navigateByUrl("/entitymanagement/insuranceCompany/companyList");
  }

  onEdit(event: any) {
    this.show=true;
    const obj = {
      listpage: false,
      addpage: true,
      addShow:false,
      editpage:true,
      clonepage:false
    }
    this.companylistshowplayback.emit(obj);
    this.entityService.setOnEdit(true);
    this.router.navigate(["/entitymanagement/insuranceCompany/AddnewCompany"], { queryParams: { companyId: event.emInsCompanyId } });
  }

  changePage(event: any) {
    if (event.pageIndex != this.ZERO) {
      this.pageIndex = event.pageIndex +1 ;
      this.maxLength = event.pageSize;
      this.minLength = event.pageSize * event.pageIndex;
      this.endingIndex = event.pageSize;
       if (this.pagesize != event.pageSize) {
        this.maximumcount(event.pageSize);
      }
    } else {
      this.pageIndex = 1;
      this.maxLength = event.pageSize;
      this.minLength = event.pageIndex;
      this.endingIndex = event.pageSize;
 if (this.pagesize != event.pageSize) {
        this.maximumcount(event.pageSize);
      }
    }
    this.getTableList(this.minLength, this.maxLength,this.filterVoObject, this.searchValueForList );
  }
  pageIndex = 1;


  pageindex() {
    this.searchSubject.next(this.pageIndex);
  }
  
  onKeyDown(event: KeyboardEvent) {
    if (event.keyCode === 190) {
      event.preventDefault();
    }
  }

  changePageIndex(){
    if(this.pageIndex > 0) {
      if(this.pageIndex > this.maximum) {
        const numbDigit = this.maximum.toString().length;
        let numString =this.pageIndex.toString();
        numString = numString.substring(0, numbDigit);
        if(Number(numString) >= this.maximum ){
          numString = this.maximum.toString();
        }
        this.pageIndex = this.maximum === 0 ? 1 : Number(numString);
      }
      this.maxLength = this.endingIndex;
      this.minLength =  this.endingIndex * (this.pageIndex - 1);
      this.getTableList(this.minLength,this.maxLength,this.filterVoObject, this.searchValueForList );
      // if(!this.pageIndex){
      // }else{
      //   this.getTableList(this.minLength,this.maxLength,this.filterVoObject, this.searchValueForList );
      // }
    }else{
      // this.pageIndex = 1;
      this.minLength = 0;
      this.maxLength = 10;
      this.getTableList(this.minLength,this.maxLength,this.filterVoObject, this.searchValueForList );
    }
  }
  maximumcount(event) {
    this.pagesize = event;
    this.maximum = this.pageCount / this.pagesize;
    this.remainder = this.pageCount % this.pagesize;
    if (this.remainder != 0) {
      this.maximum =  Math.floor(this.maximum + 1);
    }
  }
  visibility(event: any) {
    this.companylistshow = event;
  }
  download() {   
    this.entityService.entityDownoad(this.ZERO, this.pageCount,this.filterVoObject,this.searchValueForList).subscribe((response) =>{
      if (response.size === 0) {
        this.toaster.error(this.translate.instant('Toaster_error.Invalid_Excel'));
      } else {
        this.donwloadFile(response);
      }
    });
  }
  private donwloadFile(value: any) {
    const blob = new Blob([value], { type: 'application/vnd.ms-excel' });
    const file = new File([blob], 'report.xlsx', {
      type: 'application/vnd.ms-excel',
    });
    const fileURL = URL.createObjectURL(file);
    const a = document.createElement('a');
    a.href = fileURL;
    a.target = '_blank';
    a.download = 'Insurance Company List' + '.xlsx';
    document.body.appendChild(a);
    a.click();
  }

  DeleteIdentity(Id: any) {
    const dialogRef = this.dialog.open(PopupComponent, {
      width: 'auto',
      height: 'auto',
      data: {
        message: "Are you sure you want to delete?",
        okButton: "Ok",
        cancelButton: "Cancel"
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.entityService.DeleteCompany(Id).subscribe((data) => {
          this.getTableList(this.minLength = 0, this.maxLength || 0,this.filterVoObject,this.searchValueForList  );
        });
      }
    });
    return false;
  }

  getPrivilege() {
    this.appService.getPrivilegeForPage(appConst.PAGE_NAME.ENTITYMANAGEMENT.INSURANCECOMPANY.INSURANCECOMPANY_CARD.PAGEID).subscribe((res: any) => {
      this.pageInfo = res.content;
    });
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if (this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege?.isEnabled;
    }
    return isEnabled;
  }
filterObjectforlistview: FilterObject[] = [
     {

       columnName: 'name',
       condition: 'Like',
       aliasName: 'companyManag.CompanyName',
       type: 'field',
       value: [],
       dropdown: [],
       radio: [],
        dataType:'String'
     },
        {
       columnName: 'email',
       condition: 'Like',
       aliasName: 'companyManag.EmailAddress',
       type: 'field',
       value: [],
       dropdown: [],
       radio: [],
 dataType:'String'
     },
         {
       columnName: 'phone',
       condition: 'Like',
       aliasName: 'companyManag.PhoneNumber',
       type: 'field',
       value: [],
       dropdown: [],
       radio: [],
 dataType:'String'
     },
     {
       columnName: 'address',
       condition: 'Like',
       aliasName: 'companyManag.Address',
       type: 'field',
       value: [],
       dropdown: [],
       radio: [],
 dataType:'String'
     }
   ];
getfilter(event:any){
  this.searchValueForList ="";
this.filterVoObject=event;
this.getTotalCount(this.filterVoObject, this.searchValueForList);
}


  getEnabledPrivilegeFromMultipleRoles(sectionDataArray:AccessMappingSectionDto[]):AccessMappingSectionDto[]{
    const result: AccessMappingSectionDto[] = Object.values(
      sectionDataArray.reduce((accumulator, obj) => {
        let accessMappingAccumulator:AccessMappingSectionDto= null;
        if (!accumulator[obj.sectionName]) {
          accumulator[obj.sectionName] = obj;
        }
        accessMappingAccumulator=accumulator[obj.sectionName];
        if(obj.isView){
          accessMappingAccumulator.isView=obj.isView;
        }
        if(obj.isClone){
          accessMappingAccumulator.isClone=obj.isClone;
        }
        if(obj.isDisable){
          accessMappingAccumulator.isDisable=obj.isDisable;
        }
        if(obj.isDownload){
          accessMappingAccumulator.isDownload=obj.isDownload;
        }
        if(obj.isEdit){
          accessMappingAccumulator.isEdit=obj.isEdit;
        }
        if(obj.isNotification){
          accessMappingAccumulator.isNotification=obj.isNotification;
        }
        accumulator[obj.sectionName]=accessMappingAccumulator;
        return accumulator;
      }, {} as Record<string, AccessMappingSectionDto>)
    );

    return result
  }



  getPageAccessData(): void {
 const platformDetails = JSON.parse(sessionStorage.getItem("platformDetails") ?? "{}");
     this.platformId = platformDetails.platformId;
    this.appService.getPageAccess(appConst.PAGE_NAME.ENTITYMANAGEMENT.INSURANCECOMPANY.INSURANCECOMPANY_LIST.PAGE_IDENTITY).subscribe((response: any) => {
      this.companyListPageAccessMap = response.content;
      this.companyListPageAccessMap.sectionData=this.getEnabledPrivilegeFromMultipleRoles(this.companyListPageAccessMap?.sectionData);
      this.companyListPageAccessDto =  this.companyListPageAccessMap.sectionData.find(x => x.sectionName ===MenuSectionNames.Company_List);
      this.companyCardPageAccessDto =  this.companyListPageAccessMap.sectionData.find(x => x.sectionName ===MenuSectionNames.Company_Card);
      this.addCompanyPageAccessDto =  this.companyListPageAccessMap.sectionData.find(x => x.sectionName ===MenuSectionNames.Add_Company);
      this.isListPageEnabled = this.companyListPageAccessMap.isEnabled;
     
    });
  }
 sortingmethod(event:any) {
   const EntityColumnName = event;
   if (EntityColumnName === 'Company Name') {
     this.isAscOrder = !this.isAscOrder;
     this.companyname=!this.companyname;
          const columnName = this.getEntityColumnName(EntityColumnName);
     this.setSortingVO(columnName, this.isAscOrder);
     this.getTotalCount(this.filterVoObject, this.searchValueForList);
   }else if(EntityColumnName === 'Email Address'){
     this.isAscOrder = !this.isAscOrder;
     this.Emailsort=!this.Emailsort;
          const columnName = this.getEntityColumnName(EntityColumnName);
     this.setSortingVO(columnName, this.isAscOrder);
     this.getTotalCount(this.filterVoObject, this.searchValueForList);
   } else if(EntityColumnName === 'Phone Number'){
     this.isAscOrder = !this.isAscOrder;
     this.phonenumbersort=!this.phonenumbersort;
          const columnName = this.getEntityColumnName(EntityColumnName);
     this.setSortingVO(columnName, this.isAscOrder);
     this.getTotalCount(this.filterVoObject, this.searchValueForList);
   }
   else if (EntityColumnName === 'Address'){
     this.isAscOrder = !this.isAscOrder;
     this.Addressot=!this.Addressot;
          const columnName = this.getEntityColumnName(EntityColumnName);
     this.setSortingVO(columnName, this.isAscOrder);
     this.getTotalCount(this.filterVoObject, this.searchValueForList);
   }  else if (EntityColumnName === 'Status'){
     this.isAscOrder = !this.isAscOrder;
     this.statussort=!this.statussort
     const columnName = this.getEntityColumnName(EntityColumnName);
     this.setSortingVO(columnName, this.isAscOrder);
     this.getTotalCount(this.filterVoObject, this.searchValueForList);
   }
  }
  setSortingVO(columnName: string, isAscOrder: boolean) {
    if (columnName != null && isAscOrder != null) {
      this.sortingFilterVo.columnName = columnName;
      this.sortingFilterVo.isAscending = isAscOrder;
    }
    const data = this.filterVoObject.find((element) => element.filterOrSortingType === 'SORTING');
    if (data) {
      const index: number = this.filterVoObject.indexOf(data);
      this.filterVoObject.splice(index, 1);
    }
    this.filterVoObject.push(this.sortingFilterVo);
  }

  sortingFilterVo: FilterOrSortingVo =
    {
      columnName: "",
      condition: "",
      filterOrSortingType: "SORTING",
      intgerValueList: [],
      valueList: [],
      isAscending: false,
      type: "",
      value: "",
      value2: "",
    }
  Search(event: any) {
    this.cardsearch = event.target.value
    if (this.show) {
      this.router.navigate([], { queryParams: { recSearchQuery: this.cardsearch } });
    }
    else{
      this.getTotalCount(this.filterVoObject, this.cardsearch);
    }
  }
  getEntityColumnName(SchdedulerColumnName: string) {
    let value = '';
    if (SchdedulerColumnName) {
      const data = this.sortingEntityArray.find((column) => column.tableColumnName === SchdedulerColumnName);
      if (data) {
        value = data.entityColumnName;
      }
    }
    return value;

  }
   sortingEntityArray = [
    {
      tableColumnName: "Company Name",
      entityColumnName: "name",
      type: "String"
    },
    {
      tableColumnName: "Email Address",
      entityColumnName: "email",
      type: "String"
    },
    {
      tableColumnName: "Phone Number",
      entityColumnName: "phone",
      type: "String"
    },
    {
      tableColumnName: "Address",
      entityColumnName: "address",
      type: "String"
    },
    // {
    //   tableColumnName: "Status",
    //   entityColumnName: "isActive",
    //   type: "Boolean"
    // },
  
  ]

  onClone(event: any) {
    this.router.navigate(['entitymanagement/insuranceCompany/AddnewCompany'], { queryParams: { companyCloneId: event.emInsCompanyId } });
    this.entityService.showCard(false);
  }

  getCurrentUrl() {
    this.currentRoute = window.location.href;
    this.router.events.subscribe((event: any) => {
      if (event instanceof NavigationEnd) {
        this.currentRoute = event.url
      }
    });
  }

  showCardViewOnListBackButtonTrigger(){
    this.show=true;
  }
}

