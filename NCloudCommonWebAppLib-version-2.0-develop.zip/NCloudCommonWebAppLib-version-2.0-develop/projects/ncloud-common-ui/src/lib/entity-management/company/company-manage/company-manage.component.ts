import { Component, EventEmitter, Input, OnDestroy, Output } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { ToastrService } from "ngx-toastr";
import { BreadcrumbService } from "xng-breadcrumb";
import { Section } from "../../../dto/entity-management/section";
import { Field } from "../../../dto/entity-management/field";
import { MetaDataDto } from "../../../dto/entity-management/meta-data-dto";
import {
  FileUploadDTO,
  InsuranceCompanyDto,
} from "../../../dto/entity-management/insurance-company";
import { appConst } from "../../../const/app.const";
import { AccessMappingPageDto } from "../../../dto/access-Mapping-PageDto ";
import { EntityManagementService } from "../../../service/entitymanagement-service";
import { FileUploadService } from "../../../service/file-upload.service";
import { AppService } from "../../../service/app.service";
import { CompanyFileSaveDto } from "../../../dto/entity-management/company-file-save-dto";
import { AccessMappingSectionDto } from "../../../dto/Filter-dto/section-dto";
import { MenuSectionNames } from "../../../const/enum";
import { TranslateService } from "@ngx-translate/core";
import { Subscription } from "rxjs";
import { ErrorHandlerDirective } from "../../../directive/errorHandler.directive";

@Component({
  selector: "app-company-manage",
  templateUrl: "./company-manage.component.html",
  styleUrls: ["./company-manage.component.scss"],
})
export class CompanyManageComponent implements OnDestroy {
  @Input() companymanageshow: any;
  platformId: any;
  @Output() companymanageshowplayback = new EventEmitter<any>();

  pageId = "29";
  companyId?: string | null = null;
  paretSectionData?: Section[];
  parentSectionField?: Field[];
  subSectionField?: Field[];
  addCompanyPageAccessDto: AccessMappingSectionDto;
  subSectionData?: Section[];
  insuranceMetaData?: MetaDataDto;
  insuranceCompanyData?: InsuranceCompanyDto;
  edit = false;
  parentSectionName?: string;
  subSectionName?: string;
  aliasName?: string;
  fileName?: string;
  isBtnDissabel :boolean =false;
  fileField?: Field;
  isActive?: boolean;
  entityMetaData: any;
  mandatory?: boolean;
  fileUrl?: string;
  nameShow?: boolean;
  imageList?: string;
  fileObject: any;
  isClone = false;
  setMinDecimalPipeAmount1 = false;
  fileType?: string;

  appConst = appConst;
  pageInfo: any;
  companyManagePageAccessMap?: AccessMappingPageDto;
  isManagePageEnabled = false;
  imgValue?: string;
  minDate = new Date();
  addNew = false;
  clone = false;
  isEdit: boolean;
  companyFileSaveDto = new CompanyFileSaveDto();
  password: string;
  addNewSubscription: Subscription;
  isPasswordValid: boolean;
  editCloneSubscription: Subscription;

  constructor(
    private activateRoute: ActivatedRoute,
    private router: Router,
    private breadcrumbService: BreadcrumbService,
    private service: EntityManagementService,
    private fileService: FileUploadService,
    private tosterservice: ToastrService,
    private appService: AppService,
    private translate:TranslateService,
    private errorHandlerDirective: ErrorHandlerDirective,
  ) {
   this.addNewSubscription= this.service.getAddNewSubscription().subscribe((value) => {
      if (value == true) {
        this.companyId = null;
        this.addNew = true;
        this.edit = false;
        this.clone = false;
        this.service.setAddNewSubscription(false);
        this.getData();
      }
    });


    const platformDetails = JSON.parse(
      sessionStorage.getItem("platformDetails") ?? "{}"
    );
    this.platformId = platformDetails.platformId;

    this.editCloneSubscription = this.service.getOnEdit().subscribe((value: any) => {
      if (value == true &&  !this.addNew) {
        this.edit = true;
        this.clone = false;
        this.addNew = false;
        this.getData();
      } else if(!this.addNew) {
        this.edit = false;
        this.clone = true;
        this.addNew = false;
        this.getData();
      }
    });
  }
  ngOnDestroy(): void {
    this.addNewSubscription.unsubscribe();
    this.editCloneSubscription.unsubscribe();
  }

  ngOnInit(): void {
    this.getPageAccessData();
console.log("hhk");

    console.log(!this.addCompanyPageAccessDto?.isEdit);
    console.log(this.edit);
  }

  doProcess(): void {
    this.getPrivilege();
    this.isActive = true;
    this.nameShow = false;
    this.activateRoute.queryParams.subscribe((queryParams: any) => {
      this.companyId = queryParams["companyId"];
      if (this.companyId != null) {
        this.getData();
      }
      let value = queryParams["companyCloneId"];
      if (value != null || value != undefined) {
        this.isClone = true;
        this.cloneCompany(value);
      }
    });
  }

  getData() {
    this.service
      .getInsuranceOrGarageCompanyMetaData(this.pageId, this.companyId || "")
      .subscribe((data: any) => {
        if (this.fileName != undefined || this.fileName != null) {
          this.fileName = "";
        }
        this.nameShow = false;
        if (data) {
          this.entityMetaData = data;
          this.insuranceMetaData = this.entityMetaData.metaData;
          this.isActive = this.entityMetaData.isActive;
          if (this.insuranceMetaData && this.insuranceMetaData.sectionList) {
            this.insuranceMetaData?.sectionList.forEach((value) => {
             if(value?.sectionName == 'Company Details'){
              this.parentSectionName = value.sectionName;
              this.parentSectionField = value.fieldList;
              if (value.fieldList != null) {
                value.fieldList.forEach((field, index) => {
                  if (field.fieldType === "toggle") {
                    this.parentSectionField?.splice(index, 1);
                  }
                });
              }
             }
             else{
              this.subSectionName = value.sectionName;
              this.subSectionField = value.fieldList;
            }
            });
          }
          if (this.companyId != null || this.companyId != undefined) {
            this.nameShow = true;
            let index = 0;
            this.imageList = "";
            if (this.insuranceMetaData && this.insuranceMetaData.sectionList) {
              this.insuranceMetaData.sectionList.forEach((value: any) => {
                value.fieldList.forEach((data: any) => {
                  if (data.fieldName === "emInsPassword") {
                    data.mandatory = false;
                  }
                  if (data.fieldType === "file") {
                    //this.imageList.push(data.value);
                    this.getImage(data.value, index);
                    index++;
                  }

                  //   if(data.fieldType==="file"){
                  //    this.getImage(data.value || '',index);
                  //    index++;

                  // }
                });
              });
            }
          }
        }
      });
  }
  onToggling(event: any) {
    this.isActive = event.checked;
  }

  getImage(imageUrl: string, index: number): void {
    this.fileService
      .downloadImageByImageName(imageUrl)
      .subscribe((response: Blob) => {
        const reader = new FileReader();
        reader.onload = (e: any) => {
          //if(this.imageList || this.imageList === ''){
          this.imageList = e.target?.result;
          //}
        };
        reader.readAsDataURL(new Blob([response]));
        this.fileObject = new File([response], "blobimage.jpeg");
      });
  }

  backbtn() {
    this.nameShow = false;
    const obj = {
      listpage: true,
      addpage: false,
    };
    this.companymanageshowplayback.emit(obj);
    this.router.navigateByUrl("/entitymanagement/insuranceCompany/companyList");
  }

  getStringInput(items: Field) {
    if (items.fieldType === "String") {
      return true;
    }
    return false;
  }

  getTextInput(items: Field) {
    if (items.fieldType === "text") {
      return true;
    }
    return false;
  }

  getNumberInput(items: Field) {
    if (items.fieldType === "Long" || items.fieldType === "Double") {
      return true;
    }
    return false;
  }

  getFileUploadInput(items: Field) {
    if (items.fieldType === "file") {
      this.fileField = items;
      return true;
    }
    return false;
  }

  getDateInput(items: Field) {
    if (items.fieldType === "pDate" || items.fieldType === "fDate") {
      return true;
    }
    return false;
  }

  file!: File; // Variable to store file

  // On file Select
  onChange(event: any) {
    if (event !== undefined) {
      this.file = event.target.files[0];
      this.fileName = this.file?.name;
      this.fileType = this.file?.type;
      if (
        this.fileType !== "image/png" &&
        this.fileType !== "image/jpg" &&
        this.fileType !== "image/jpeg"
      ) {
        this.tosterservice.error(
          this.translate.instant('File_errors.invalid_type')
        );
        this.fileName = "";
        //  this.fileField.value = null;
      }
    }
  }
  //onChange(event:any) {

  //  if (event!==undefined) {
  //    this.file = event.target.files[0];
  //    this.fileName = this.file.name;
  //    this.fileType = this.file.type;
  //    if(this.fileType!=="image/png" && this.fileType!=="image/jpg" && this.fileType!=="image/jpeg") {
  //      this.tosterservice.error('Upload Valid Image');
  //      this.fileName ='';
  //      // this.fileField.value ='';
  //    }
  //  }
  //  // console.log(event.target.files[0]);
  //}

  backToList() {
    const obj = {
      listpage: true,
      addpage: false,
    };
    this.companymanageshowplayback.emit(obj);
  }
PhoneNumberValid
getPhonenumber(phoneNumber)
{
return this.PhoneNumberValid=phoneNumber
}
restrictOver(event)
{
if(this.PhoneNumberValid.length>21)
{
event.preventDefault();
}
}
  saveData(fieldData: Field[]) {
    this.isBtnDissabel = true;
    this.mandatory = true;
    this.nameShow = false;
    let errorMessage = "";
    //--------Creating fileupload variable
    //this.isActive=this.isActive!=true?false:this.isActive;
    const fileData: FileUploadDTO = {
      fileList: [this.file], // uncomment during development
      companyId: this.companyId!,
      fieldName: this.fileField?.fieldName,
    };

    if (this.companyId == null) {
      this.isEdit = false;
    } else {
      this.isEdit = true;
    }
    let invalidFileFormat = false;
    let fileList: File[] = fileData.fileList;
    if (JSON.stringify(fileList) != JSON.stringify([null])) {
      fileList.forEach((file) => {
        const isValidfileFormat = this.validateFile(file);
        invalidFileFormat = isValidfileFormat;
      });
    }

    if (invalidFileFormat) {
      return;
    }
    if (this.insuranceMetaData && this.insuranceMetaData.sectionList) {
      this.insuranceMetaData.sectionList.forEach((value) => {
        if (value.sectionName === "Company Details") {
          value.fieldList = fieldData;
          value.fieldList.forEach((field) => {
            if (field.aliasName === "Password") {
              this.password = field.value;
              const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+{}\[\]:;<>,.?~\\-]).{8,}$/;
              this.isPasswordValid = passwordRegex.test(this.password);
            }
          });
        }
      });
    }

    if (this.insuranceMetaData && this.insuranceMetaData.sectionList) {
      this.insuranceMetaData.sectionList.forEach((value: any) => {
        value.fieldList.forEach((data: any) => {
          if (this.mandatory && data.mandatory === true) {
            if (
              data.value == null ||
              data.value == undefined ||
              data.value.trim() == ""
            ) {
              this.mandatory = false;
              errorMessage = this.translate.instant('Toaster_error.mandatory_fields');
            } else if (
              data.fieldType === "Long" ||
              data.fieldType === "Double"
            ) {
              const value = parseFloat(data.value);
              this.mandatory = value !== 0;
              if (!this.mandatory) {
                errorMessage = "number field cannot be zero";
              }
            }
          }
        });
      });
    }
    if (this.mandatory == true ) {
      if (
        (this.companyId === null || this.companyId === undefined) &&
        JSON.stringify(fileData.fileList) === JSON.stringify([null])
      ) {
        fileData.fileList = [this.fileObject];
      }
      if(this.isPasswordValid){
    
      this.service
        .saveInsuranceCompany(this.insuranceMetaData!,this.companyId || "",this.pageId,this.isActive || false).subscribe((data: any) => {
          this.companyId = data.toString();
          // assumed as created company id
          this.fileService
            .upload(fileData?.fileList, this.companyId, fileData?.fieldName)
            .subscribe((response: any) => {
              if (response) {
                const downloadUrl = response.content;
                this.fileUrl = downloadUrl;
              }
              this.companyFileSaveDto.referenceId = this.companyId;
              this.companyFileSaveDto.password = btoa(this.password);
              this.companyFileSaveDto.pageId = this.pageId;
              this.companyFileSaveDto.isEdit = this.isEdit;
              this.companyFileSaveDto.fileUrl = this.fileUrl;
              this.service
                .saveFile(this.companyFileSaveDto)
                .subscribe((value) => {
                 
                  if (value) {
                    setTimeout(() => {
                      const obj = {
                        listpage: true,
                        addpage: false,
                      };

                      this.companymanageshowplayback.emit(obj);
                      this.router.navigateByUrl(
                        "/entitymanagement/insuranceCompany/companyList"
                      );
                      this.tosterservice.success(this.translate.instant('Toaster_success.save'), "", {
                        timeOut: 1000,
                      })
                      this.clearFieldValues(fieldData);
                      this.service.setAddNew(true);
                    }, 1000);
                  }
                },(error:Response)=>{
                  this.isBtnDissabel=false;
                  this.errorHandlerDirective.getMessage(error);
                });
            },(error:Response)=>{
              this.isBtnDissabel=false;
              this.errorHandlerDirective.getMessage(error);
            });
        },(error:Response)=>{
          this.isBtnDissabel=false;
          this.errorHandlerDirective.getMessage(error);
        })
      }
      else{
        this.isBtnDissabel=false;
        this.tosterservice.error(this.translate.instant('Password must contains 1-UpperCase, 1-LowerCase, 1-digit, 1-Special Character and minimum 8 characters'));
      }
    } else {
      this.isBtnDissabel=false;
      this.tosterservice.error(errorMessage, "", {
       timeOut: 3000,
      });
    }
  }
  validateFile(file: File) {
    const fileSize = file.size;
    const allowedFileSize = 1024 * 1024 * 5; // allowed size 5MB
    const fileExtensions = file.name.split(".").slice(1);

    if (fileSize > allowedFileSize) {
      this.tosterservice.error(this.translate.instant('File_errors.file_size_error'));
      return true;
    }
    const allowedMimeTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/svg+xml'];
    // if (fileExtensions.length > 1) {
    //   this.tosterservice.error(this.translate.instant('Toaster_error.invalid_phone_number'));
    //   return true;
    // }
    if (!allowedMimeTypes.includes(file.type)) {
      this.tosterservice.error(this.translate.instant('File_errors.invalid_type'));
      return true;
    }
    return false;
  }
  /**
   * New Company-Field values clear After add
   * @param fieldData
   */
  clearFieldValues(fieldDataValue: any) {
    fieldDataValue.filter((ele: any) => {
      ele.value = " ";
    });
  }
  cloneCompany(value: any) {
    this.service
      .getInsuranceOrGarageCompanyMetaData(this.pageId, value)
      .subscribe((data: any) => {
        if (data) {
          this.entityMetaData = data;
          this.insuranceMetaData = this.entityMetaData.metaData;
          this.isActive = this.entityMetaData.isActive;
          if (
            this.insuranceMetaData &&
            this.insuranceMetaData.sectionList &&
            this.insuranceMetaData.sectionList.length > 0
          ) {
            this.insuranceMetaData.sectionList.forEach((value: any) => {
              if (value.sectionName === "Company Details") {
                this.parentSectionName = value.sectionName;
                value.fieldList.forEach((element: any) => {
                  if (element.aliasName === "Company User ID") {
                    element.value = "";
                  }
                });
                this.parentSectionField = value.fieldList;
                if (value.fieldList != null) {
                  value.fieldList.forEach((field: any, index: number) => {
                    if (field.fieldType === "toggle") {
                      this.parentSectionField?.splice(index, 1);
                    }
                  });
                }
              } else {
                this.subSectionName = value.sectionName;
                this.subSectionField = value.fieldList;
              }
            });
          }
          if (value != null || value != undefined) {
            this.nameShow = true;
            if (this.insuranceMetaData && this.insuranceMetaData.sectionList) {
              this.insuranceMetaData.sectionList.forEach((value: any) => {
                value.fieldList.forEach((data: any) => {
                  if (data.fieldName === "emInsPassword" || data.fieldName === "emInsShortName" || data.fieldName === "emInsCompanyId" || data.fieldName === "emInsUserName" || data.fieldName === "emInsLogo") {
                    data.value = null;
                  }
                  if (data.fieldType === "file") {
                    this.imgValue = null;
                  }
                });
              });
            }
          }
        }
      });
  }

  removeCommas(value: string) {
    if (value !== undefined && value !== null && value !== "") {
      const num = Number(value.toString().replace(/,/g, ""));
      return num.toLocaleString("en", {
        useGrouping: false,
        minimumFractionDigits: 3,
      });
      // return num.toFixed(3);
    } else {
      return "";
    }
  }

  removeCommas2(value: any): number {
    if (value !== undefined && value !== null && value !== "") {
      var num = Number(value.toString().replace(/,/g, ""));
      return Number(
        num.toLocaleString("en", {
          useGrouping: false,
          minimumFractionDigits: 3,
        })
      );
      // return num.toFixed(3);
    } else {
      return null || 0;
    }
  }

  getPrivilege() {
    this.appService
      .getPrivilegeForPage(
        appConst.PAGE_NAME.ENTITYMANAGEMENT.INSURANCECOMPANY
          .INSURANCECOMPANY_ADD.PAGEID
      )
      .subscribe((res: any) => {
        this.pageInfo = res.content;
      });
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if (this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find(
        (prv: any) => prv.privilegeName === privillegeName
      );
      isEnabled = privillege?.isEnabled;
    }
    return isEnabled;
  }

  getPageAccessData(): void {
    const platformDetails = JSON.parse(
      sessionStorage.getItem("platformDetails") ?? "{}"
    );
    this.platformId = platformDetails.platformId;
    this.appService
      .getPageAccess(
        appConst.PAGE_NAME.ENTITYMANAGEMENT.INSURANCECOMPANY
          .INSURANCECOMPANY_ADD.PAGE_IDENTITY
      )
      .subscribe((response: any) => {
        this.companyManagePageAccessMap = response.content;
        if (this.platformId != 3) {
          this.companyManagePageAccessMap.sectionData=this.getEnabledPrivilegeFromMultipleRoles(this.companyManagePageAccessMap?.sectionData);
          this.addCompanyPageAccessDto =
            this.companyManagePageAccessMap.sectionData.find(
              (x) => x.sectionName === MenuSectionNames.Add_Company
            );
        }
        this.isManagePageEnabled =
          this.companyManagePageAccessMap?.isEnabled || false;
        if (this.isManagePageEnabled) {
          this.doProcess();
        }
      });
    this.doProcess();
  }


  getEnabledPrivilegeFromMultipleRoles(sectionDataArray:AccessMappingSectionDto[]):AccessMappingSectionDto[]{
    const result: AccessMappingSectionDto[] = Object.values(
      sectionDataArray.reduce((accumulator, obj) => {
        let accessMappingAccumulator:AccessMappingSectionDto= null;
        if (!accumulator[obj.sectionName]) {
          accumulator[obj.sectionName] = obj;
        }
        accessMappingAccumulator=accumulator[obj.sectionName];
        if(obj.isView){          
          accessMappingAccumulator.isView=obj.isView;
        }
        if(obj.isClone){
          accessMappingAccumulator.isClone=obj.isClone;
        }
        if(obj.isDisable){
          accessMappingAccumulator.isClone=obj.isDisable;
        }
        if(obj.isDownload){
          accessMappingAccumulator.isDownload=obj.isDownload;
        }
        if(obj.isEdit){
          accessMappingAccumulator.isEdit=obj.isEdit;
        }
        if(obj.isNotification){
          accessMappingAccumulator.isNotification=obj.isNotification;
        }
        accumulator[obj.sectionName]=accessMappingAccumulator;
        return accumulator;
      }, {} as Record<string, AccessMappingSectionDto>)
    );
    
    return result
  }
}
