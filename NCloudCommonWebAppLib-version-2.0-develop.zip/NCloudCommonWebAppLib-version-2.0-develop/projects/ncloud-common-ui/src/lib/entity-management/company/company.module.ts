import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { CompanyRoutingModule} from "./company-routing.module";
import { CompanyComponent } from "./company.component";
import { MatTabsModule } from '@angular/material/tabs';
import { TranslateModule } from "@ngx-translate/core";
import { CompanyCardComponent } from "./company-card/company-card.component";
import { CompanyListComponent } from "./company-list/company-list.component";
import { CompanyManageComponent } from './company-manage/company-manage.component';
import { MatTableModule } from "@angular/material/table";
import { MatPaginatorModule } from "@angular/material/paginator";
import { MatIconModule } from "@angular/material/icon";
import { BreadcrumbService } from "xng-breadcrumb";
import { MatCardModule } from "@angular/material/card";
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTooltipModule } from "@angular/material/tooltip";
import { MatProgressSpinnerModule } from "@angular/material/progress-spinner";
import { MatDatepickerModule } from '@angular/material/datepicker';
import { CustomDirectiveModule } from "../../directive/directives/custom-directive.module";
import { AppCommonModule } from "../../common-components/app-common.module";
import { ErrorHandlerDirective } from "../../directive/errorHandler.directive";
import { CustomPipeModule } from "../../pipes/custom-pipe/custom-pipe.module";
@NgModule(
    {
    declarations: [
        CompanyComponent,
        CompanyCardComponent,
        CompanyListComponent,
        CompanyManageComponent
    ],
    exports: [
        CompanyRoutingModule,
        CompanyComponent

    ],
    providers: [
        BreadcrumbService,
        ErrorHandlerDirective,
    ],
    imports: [
        CommonModule,
        FormsModule,
        CompanyRoutingModule,
        MatTabsModule,
        TranslateModule,
        MatTableModule,
        MatPaginatorModule,
        MatIconModule,
        MatCardModule,
        MatSlideToggleModule,
        CustomDirectiveModule,
        MatTooltipModule,
        MatDatepickerModule,
	    MatProgressSpinnerModule,
        AppCommonModule,
        CustomPipeModule
    ]
}
)

export class CompanyModule{

}
