import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import * as jspdf from 'jspdf';
import html2canvas from 'html2canvas';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { InsuranceCompanyDto } from '../../../dto/entity-management/insurance-company';
import { appConst } from '../../../const/app.const';
import { AccessMappingPageDto } from '../../../dto/access-Mapping-PageDto ';
import { EntityManagementService } from '../../../service/entitymanagement-service';
import { FileUploadService } from '../../../service/file-upload.service';
import { AppService } from '../../../service/app.service';
import { DashboardService } from '../../../service/dashboard.service';
import { PopupComponent } from '../../../common-components/popup/popup.component';
import { AccessMappingSectionDto } from '../../../dto/Filter-dto/section-dto';
import { MenuSectionNames } from '../../../const/enum';

@Component({
  selector: 'app-company-card',
  templateUrl: './company-card.component.html',
  styleUrls: ['./company-card.component.scss']
})
export class CompanyCardComponent implements OnInit{

  ActiveSts="Active";
  InActiveSts = "InActive";
  userTotalLength: any;
  minLength?: number;
  maxLength?: number;
  companyListData?:CompanyDetails[];
  status?:string;
  imageList=[];
  insCompanyListDto?:InsuranceCompanyDto;
  @Input() companyCardPageAccessDto: AccessMappingSectionDto;
  appConst = appConst;
  pageInfo: any
  companyCardPageAccessMap?: AccessMappingPageDto;
  isCardPageEnabled = false;
  @Input() searchCardName: any;
  @Output() editCloneVisibleDataPass= new EventEmitter<any>();
  companyCopyListData?: CompanyDetails[];
  platformId: any;
dataNotFound=false;
  searchValue: any;
  constructor(private service:EntityManagementService, private route: Router,private dialog:MatDialog,
    private fileService:FileUploadService, private appService: AppService,private dashboardService: DashboardService,private ngxLoader: NgxUiLoaderService,private activatedRoute:ActivatedRoute ){
    this.activatedRoute.queryParams.subscribe((value) => {
      this.searchValue = value['recSearchQuery'];
      if (!this.searchValue) {
        this.dataNotFound=false;
        this.companyListData = this.companyCopyListData;
      }
      else {
        this.companyListData = this.companyCopyListData?.filter((m) => String(m.emInsName?.toUpperCase()).includes(this.searchValue.toUpperCase()));
        if (this.companyListData.length == 0) {
          this.dataNotFound = true
        } else {
          this.dataNotFound = false
        }
      }
    });
     }


OnEdit(value :any){
  this.service.setOnEdit(true);
  this.service.showCard(false);
  this.route.navigate(["/entitymanagement/insuranceCompany/AddnewCompany"],{ queryParams: {companyId : value.emInsCompanyId}});
  const obj={
    editShow:true,
    cloneShow:false
  }

  this.editCloneVisibleDataPass.emit(obj);
}


ngOnInit() {
  // this.getInsCmpnyList(this.minLength, this.maxLength);
  console.log("entity managment");
  // this.getPageAccessData();
  this.getTotalCount();
}
ngOnChanges(changes: SimpleChanges): void {

    // if (changes['searchCardName'].currentValue!== undefined && changes['searchCardName'].currentValue !=="") {
    //     this.companyListData = this.companyCopyListData?.filter((m) => String(m.emInsName?.toUpperCase()).includes(this.searchCardName.toUpperCase()));
    //     if(this.companyListData.length==0)
    //    {
    //   this.dataNotFound=true
    //   }else{
    //  this.dataNotFound=false
    //     }
    //   }else{
    //     this.companyListData = this.companyCopyListData;
    //   }

  }



getTotalCount(){
  this.service.getInsuranceCount([],"").subscribe(((res:any)=>{
    this.minLength =0;
    this.maxLength =res;
    this.getInsCmpnyList(this.minLength = 0, this.maxLength || 0);
  }));
}

/**
 * getInsurance Company List
 */
  private getInsCmpnyList(min:number,max:number) {
    this.service.getInsuranceList(min,max,[],"").subscribe((data) => {
      this.companyListData = [];
      this.companyCopyListData = [];
      if(data){
      this.companyListData = data;
      this.companyCopyListData=this.companyListData;
    }
    });
  }

deleteIdentiy(Id: any){
  const dialogRef = this.dialog.open(PopupComponent, {
 width: 'auto',
 height:'auto',
     data: {
     message: "Are you sure you want to delete?",
      okButton: "Ok",
       cancelButton: "Cancel"
     }
 });
 dialogRef.afterClosed().subscribe(result => {
  if (result) {
    this.service.DeleteCompany(Id).subscribe(
      (data) =>{
        this.getInsCmpnyList(this.maxLength = 0,this.maxLength || 0);
      }),(err : any) => {
        console.error(err);
      };
     }
 });
 return false;
}

public captureScreen()
  {
    const data = document.getElementById('companylist')!;
    html2canvas(data).then(canvas => {
      // Few necessary setting options
      const imgWidth = 208;
      const pageHeight = 295;
      const imgHeight = canvas.height * imgWidth / canvas.width;
      const heightLeft = imgHeight;

      const contentDataURL = canvas.toDataURL('image/png')
      const pdf = new jspdf.jsPDF('p', 'mm', 'a4'); // A4 size page of PDF
      const position = 0;
      pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight)
      pdf.save('MYPdf.pdf'); // Generated PDF
    });
  }

  onClone(event:any){
    this.route.navigate(['entitymanagement/insuranceCompany/AddnewCompany'], {queryParams: {companyCloneId : event.emInsCompanyId}});
    this.service.showCard(false);
    this.service.setOnEdit(false);
    const obj={
      editShow:false,
      cloneShow:true
    }
    this.editCloneVisibleDataPass.emit(obj);
  }

  getPrivilege(){
  this.appService.getPrivilegeForPage(appConst.PAGE_NAME.ENTITYMANAGEMENT.INSURANCECOMPANY.INSURANCECOMPANY_CARD.PAGEID).subscribe((res: any)=>{
  this.pageInfo = res.content;
  });
  }

  checkPrivillege(privillegeName: string): boolean {
  let isEnabled = true;
  if(this.pageInfo && this.pageInfo.length > 0) {
  const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
  isEnabled = privillege?.isEnabled;
  }
    return isEnabled;
  }


  getEnabledPrivilegeFromMultipleRoles(sectionDataArray:AccessMappingSectionDto[]):AccessMappingSectionDto[]{
  const result: AccessMappingSectionDto[] = Object.values(
  sectionDataArray.reduce((accumulator, obj) => {
  let accessMappingAccumulator:AccessMappingSectionDto= null;
  if (!accumulator[obj.sectionName]) {
  accumulator[obj.sectionName] = obj;
  }
        accessMappingAccumulator=accumulator[obj.sectionName];
  if(obj.isView){          
  accessMappingAccumulator.isView=obj.isView;
  }
        if(obj.isClone){
  accessMappingAccumulator.isClone=obj.isClone;
  }
        if(obj.isDisable){
  accessMappingAccumulator.isClone=obj.isDisable;
  }
        if(obj.isDownload){
  accessMappingAccumulator.isDownload=obj.isDownload;
  }
        if(obj.isEdit){
  accessMappingAccumulator.isEdit=obj.isEdit;
  }
        if(obj.isNotification){
  accessMappingAccumulator.isNotification=obj.isNotification;
  }
        accumulator[obj.sectionName]=accessMappingAccumulator;
  return accumulator;
  }, {} as Record<string, AccessMappingSectionDto>)
  );
    
  return result
  }


  getPageAccessData(): void {
  console.log("entityconsole");
  const platformDetails = JSON.parse(sessionStorage.getItem("platformDetails") ?? "{}");
  this.platformId = platformDetails.platformId;
  this.appService.getPageAccess(appConst.PAGE_NAME.ENTITYMANAGEMENT.INSURANCECOMPANY.INSURANCECOMPANY_CARD.PAGE_IDENTITY).subscribe((response: any) => {
  this.companyCardPageAccessMap = response.content;
      if(this.platformId!=3)
      {
      this.companyCardPageAccessMap.sectionData=this.getEnabledPrivilegeFromMultipleRoles(this.companyCardPageAccessMap?.sectionData);
  this.companyCardPageAccessDto =  this.companyCardPageAccessMap.sectionData.find(x => x.sectionName ===MenuSectionNames.Company_Card);
  }
      this.isCardPageEnabled = this.companyCardPageAccessMap.isEnabled;
  if(this.isCardPageEnabled) {
  // this.doProcess();
  }
    });
  // this.doProcess();
  }
}

export class CompanyDetails{
  emInsAddress?:string;
  emInsCompanyId?:number;
  emInsEmail?:string;
  emInsIsActive?:boolean;
  emInsLocation?:string;
  emInsLogo?:string;
  emInsMaxPayableAmount?:string;
  emInsMaxTime?:string;
  emInsName?:string;
  emInsPassword?:string;
  emInsPhone?:string;
  emInsShortName?:string;
  companyLogo = 'assets/no-logo.svg';
}
