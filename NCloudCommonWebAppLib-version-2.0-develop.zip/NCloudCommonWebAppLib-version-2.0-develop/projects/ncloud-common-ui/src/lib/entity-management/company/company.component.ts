import { Component, EventEmitter, Output} from '@angular/core';
import { EntityManagementService } from '../../service/entitymanagement-service';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.scss']
})
export class CompanyComponent {

  listshow = true;
  addshow = false
  backToCardStatus: boolean;
  constructor(private service : EntityManagementService){
    this.service.getBackToCard().subscribe(value=>{
      if(value){
        this.listshow=true;
        this.addshow=false
        this.backToCardStatus=true;
      }
  })
  }

  // This Output() event is for Dynamic tab letters change in both Digital Paper and Data Lake
  @Output()
  isList= new EventEmitter<any>();

  @Output() triggerBack = new EventEmitter<any>();



  ngOnInit(): void {
        this.service.cardShow.subscribe((value)=>{
          this.listshow=value;
          this.addshow=true
        })

        this.service.listpage.subscribe((val)=>{
          this.listshow=val;
          this.addshow=false;
        })

  }

  listmethod(event:any){
    this.listshow = event.listpage;
    this.addshow = event.addpage;

    const obj={
      listHeaderShow:null,
      addHeaderShow:event.addShow,
      editHeaderShow:event.editpage,
      cloneHeaderShow:event.clonepage
    }
    this.isList.emit(obj);

  }
  addmethod(event:any){
    this.listshow = event.listpage;
    this.addshow = event.addpage;
    this.triggerBack.emit();
  }

  listShow(event:any){
    const obj={
      listHeaderShow:event,
      addHeaderShow:false,
      editHeaderShow:false,
      cloneHeaderShow:false
    }
    this.isList.emit(obj);
  }

}
