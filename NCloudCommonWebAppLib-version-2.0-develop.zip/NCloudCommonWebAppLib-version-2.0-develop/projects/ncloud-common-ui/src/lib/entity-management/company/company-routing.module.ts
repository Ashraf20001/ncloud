import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { CompanyListComponent } from "./company-list/company-list.component";
import { CompanyManageComponent } from "./company-manage/company-manage.component";
import { CompanyComponent } from "./company.component";


const routes:Routes = [
  {
    path: '',
    component: CompanyComponent,
    children: [
      {
          path:'companyList',component:CompanyListComponent,

          data:{
              breadcrumb: {
                  label:'Company List',
                  info : 'Company List',
              },
          }

      },
      {
           path:'AddnewCompany',component:CompanyManageComponent,
           data:{
              breadcrumb:{
                  label:'Company List/Add New Company',
                  info:'Company List/Add New Company'
              }
           }
      },
      {
          path:'', redirectTo:'companyList', pathMatch:'full'
      }
    ]
  }
];
@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })
export class CompanyRoutingModule{

}