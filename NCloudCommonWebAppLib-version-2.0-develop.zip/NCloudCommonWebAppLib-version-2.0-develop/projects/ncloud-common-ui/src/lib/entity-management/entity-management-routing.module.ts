import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { EntityManagementComponent } from "./entity-management.component";

const routes: Routes=[
    {
        path: '', component: EntityManagementComponent,
        data: { breadcrumb: { skip: true }},
        children:[
            {
                path:'', redirectTo:'insuranceCompany', pathMatch:'full',
                data: { breadcrumb: { skip: true } }
            },
            {
                path:'insuranceCompany', loadChildren:()=>import('./company/company.module').then(m=> m.CompanyModule),
                data: { breadcrumb: { skip: true } }

            },
            {
                path:'garage',loadChildren:()=> import('./garage/garage.module').then((m)=>m.GarageModule),
                data: { breadcrumb : { skip :true}}
            }
        ]
    }
]

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })
  
  export class EntityManagementRoutingModule { }