
export class ConstantService{
  public static readonly unknownError = 'Unknown error occured'
  public static readonly dashboard = 'Dashboard'
  public static readonly  reportList='/get-report-for-list'
  
  }