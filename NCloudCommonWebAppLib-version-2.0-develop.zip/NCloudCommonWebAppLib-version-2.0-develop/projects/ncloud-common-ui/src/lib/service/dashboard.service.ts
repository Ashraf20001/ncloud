import { HttpClient } from '@angular/common/http';
import { EventEmitter, Inject, Injectable, Output } from '@angular/core';
import { ConstantService } from './constants-service.service';

import { BehaviorSubject, Observable } from 'rxjs';
import { stockDto } from './allocation-pool-dto';
import {BarChartDto} from '../dto/barchart-dto';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor(private http:HttpClient,@Inject('env') private environment: any) { }
  private baseUrl = this.environment.API_BASE_URL+"/digital-paper";
  private logoUrl = this.environment.API_BASE_URL;
  @Output() isCheck= new EventEmitter<boolean>();
  private forDate = new BehaviorSubject<BarChartDto>(null);
  public isChecked$ = this.forDate.asObservable();
 reportForList(){
  return this.http.get(this.baseUrl+ConstantService.dashboard+ConstantService.reportList);
}

/**
 *
 * @param param
 * @returns
 */
  getLoggedInUserCompanyId(param: any){
    return this.http.get(this.environment.API_BASE_URL+'/api/company/get-company',{params : param});
  }
  toggleTrueOrNot(value:boolean){
    this.isCheck.emit(value);
}

getCompanyLogo(id:number){
  return this.http.get(this.logoUrl + '/api/company/get-logo?companyId='+ id)
}

getBarChartData(dashBoardInputDto:BarChartDto):any {
  return this.http.post<any>(this.baseUrl +'/dashboard/inscompany-barchart',dashBoardInputDto);
}

getAuthorityBarChart(dashBoardInputDtoForAuthority: BarChartDto):any {
  return this.http.post<any>(this.baseUrl + '/dashboard/association-barchart',dashBoardInputDtoForAuthority);
}

getAddNew():Observable<BarChartDto> {
  return this.forDate;

}
setAddNew(value:BarChartDto){
  return this.forDate.next(value);
}

getStockCount(isAdmin:boolean) {
  if (!isAdmin) {
    return this.http.get<stockDto>(this.baseUrl + '/get-stock-count');
  }{
  return null;
}
}

getAuthorityDashBoardCount(isAdmin:boolean){
if (isAdmin) {
  return this.http.get<DashboardCount[]>(this.baseUrl + '/authority/get-dashboard-count');
}else
{
  return null;
}
}

}

export class DashboardCount {
  status: number;
  count: number;
}
