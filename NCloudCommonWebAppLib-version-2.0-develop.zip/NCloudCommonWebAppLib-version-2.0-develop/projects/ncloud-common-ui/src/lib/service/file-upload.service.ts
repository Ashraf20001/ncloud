/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-inferrable-types */
import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FileUploadService {

  // API url
  baseApiUrl =  this.environment.API_BASE_URL+"/api";

  constructor(private http:HttpClient, @Inject('env') private environment: any) { }

  // Returns an observable
  upload(fileList: any,referenceId: any,referenceType: any):Observable<any> {

    if (JSON.stringify(fileList)!==JSON.stringify([null])) {
       // Create form data
       const formData = new FormData();

       // Store form name as "file" with file data
       for(let i=0; i<fileList.length; i++) {
        formData.append("file", fileList[i]);
       }

       // Make http post request over api
       // with formData as req
       return this.http.post(this.baseApiUrl + "/upload-file/" +referenceId+"/"+referenceType, formData)
    } else {
      return of(null);
    }
  }

  downloadFile(fileUrl: any) {
    return this.http.get(fileUrl, { responseType: 'blob' });
  }

  downloadImageByImageName(imageName: string): Observable<any> {
    return this.http.get(this.baseApiUrl + '/downloadFile/' + imageName, { responseType: 'blob' });
  }

  public getFileList(referenceId: number): Observable<any> {
    if (referenceId!== null) {
      return this.http.get<any>(this.baseApiUrl + '/getFileList/' + referenceId);
    }else{
      return of(null);
    }
  }

  public deleteFileList(fileIdList: number[]): Observable<any> {
    return this.http.post(this.baseApiUrl + '/deleteFileList', fileIdList);
  }

}
