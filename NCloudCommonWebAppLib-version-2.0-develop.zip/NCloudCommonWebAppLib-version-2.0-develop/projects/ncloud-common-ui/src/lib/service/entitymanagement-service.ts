import { HttpClient } from "@angular/common/http";
import { EventEmitter, Inject, Injectable, Output } from "@angular/core";
import { BehaviorSubject, of } from "rxjs";
import { Observable } from 'rxjs';
import { EntityMetaDataDto, MetaDataDto } from "../dto/entity-management/meta-data-dto";
import { FieldGroupDTO } from "../dto/entity-management/field-group-dto";
import { Section } from "../dto/entity-management/section";
import { Field } from "../dto/entity-management/field";
import { FieldDTO } from "../dto/entity-management/field-dto";
import { FieldValueDTO } from "../dto/entity-management/field-value-dto";
import { InsuranceCompanyDto } from "../dto/entity-management/insurance-company";
import { GarageDto } from "../dto/entity-management/garage";
import { CompanyDetails } from "../dto/company-details-dto";
import {FilterOrSortingVo} from "../dto/Filter-dto/filter-object-backend";
import { CompanyFileSaveDto } from "../dto/entity-management/company-file-save-dto";

@Injectable({
    providedIn: 'root'
})

export class EntityManagementService {
 
    private baseUrl = this.environment.API_BASE_URL + "/api/entitymanagement";
    private static INSURANCE_COMPANY__GROUP_NAME = 'Company Details';
    private static GARAGE_COMPANY_GROUP_NAME = "Garage Details";
    private ClickAddnew = new BehaviorSubject<boolean>(false);
    public ClickAdd$ = this.ClickAddnew.asObservable();
    private onEdit= new BehaviorSubject<boolean>(false);
    private backToCardSubject= new BehaviorSubject<boolean>(false);
    @Output() cardShow = new EventEmitter<boolean>();
    @Output() listpage = new EventEmitter<boolean>();
    @Output() cardViewShowOnBackButtonFromList= new EventEmitter<boolean>();
    @Output() companyCardEmptyEvent= new EventEmitter();

    private addNewCompanySubject=new BehaviorSubject<boolean>(false);


    constructor(private request: HttpClient, @Inject('env') private environment: any) { }

    getInsuranceOrGarageCompanyMetaData(pageId: string, companyId: string) {
        if (companyId === null || companyId === undefined) {
            return this.request.get<EntityMetaDataDto>(this.baseUrl + "/getpageinfo?page_id=" + pageId);
        }
        else {
            return this.request.get<EntityMetaDataDto>(this.baseUrl + "/getpageinfo?page_id=" + pageId + "&reference_id=" + companyId);
        }
    }

    public saveInsuranceCompany(insuranceCompany: MetaDataDto, companyId: string, pageId: string, isActive: boolean): Observable<any> {
        let fieldGroupDTO: FieldGroupDTO
        if (pageId === "29") {
            fieldGroupDTO = this.convertToFieldGroup(insuranceCompany);
        }
        else {
            fieldGroupDTO = this.convertToFieldGroupGarage(insuranceCompany);
        }
        if (!companyId) {
            return this.request.post(this.baseUrl + '/saveOrUpdate?page_id=' + pageId + "&is_active=" + isActive, fieldGroupDTO);
        } else {
            return this.request.post(this.baseUrl + '/saveOrUpdate?page_id=' + pageId + "&reference_id=" + companyId + "&is_active=" + isActive, fieldGroupDTO);
        }
    }

    private convertToFieldGroup(insuranceCompany: MetaDataDto): FieldGroupDTO {
        const fieldGroupDTO: FieldGroupDTO = {
            groupName: EntityManagementService.INSURANCE_COMPANY__GROUP_NAME,
            fieldValues: [],
            fieldGroups: []
        };

        const metaData = insuranceCompany;
        const sectionList = metaData.sectionList;
        sectionList?.forEach((section: Section) => {
            this.getFieldGroupDTO(section, fieldGroupDTO);
        });
        return fieldGroupDTO;
    }


    private convertToFieldGroupGarage(insuranceCompany: MetaDataDto): FieldGroupDTO {
        const fieldGroupDTO: FieldGroupDTO = {
            groupName: EntityManagementService.GARAGE_COMPANY_GROUP_NAME,
            fieldValues: [],
            fieldGroups: []
        };

        const metaData = insuranceCompany;
        const sectionList = metaData.sectionList;
        sectionList?.forEach((section: Section) => {
            this.getFieldGroupDTO(section, fieldGroupDTO);
        });
        return fieldGroupDTO;
    }

    private getFieldGroupDTO(section: Section, parentFieldGroup: FieldGroupDTO): FieldGroupDTO {
        if (section !== undefined && section !== null) {
            const fieldGroup: FieldGroupDTO = {
                groupName: section.sectionName || '',
                fieldValues: [],
                fieldGroups: []
            };
            if (section.fieldList && section.fieldList.length > 0) {
                section.fieldList.forEach((field: Field) => {
                    const fieldDTO: FieldDTO = {
                        fieldId: field.fieldId,
                        aliasName:field.aliasName,
                        fieldName: field.fieldName,
                        fieldType: field.fieldType,
                        fieldDefault: field.defaultValues,
                        minlength: field.minLength,
                        maxlength: field.maxLength,
                        regex:field.regex,
                        mandatory:field.mandatory
                    };
                    const fieldValueDTO: FieldValueDTO = {
                        field: fieldDTO,
                        value: field.value
                    };
                    fieldGroup?.fieldValues?.push(fieldValueDTO);
                });
            }
            if (section.sectionList && section.sectionList.length > 0) {
                section.sectionList.forEach((subSection: Section) => {
                    this.getFieldGroupDTO(subSection, fieldGroup);
                });
            }
            parentFieldGroup?.fieldGroups?.push(fieldGroup);
        }
        return parentFieldGroup;
    }

    public getInsuranceList(min: number, max: number,filter:FilterOrSortingVo[],searchValue:string) {
        return this.request.post<CompanyDetails[]>(this.baseUrl + "/getInsuranceData" + '?min=' + min + '&max=' + max + '&searchValue=' + searchValue,filter);
    }

    public excelDownload(PurchaseStockList: any) {
        return this.request.post(this.environment.API_BASE_URL + "/digital-paper/excel-download", PurchaseStockList, { responseType: 'blob' });
    }

    public getInsuranceCount(filter:FilterOrSortingVo[], searchValue:string) {
        return this.request.post<InsuranceCompanyDto[]>(this.baseUrl + "/getInsuranceDataCount" + '?searchValue=' + searchValue,filter);
    }

    public getGarageList(min: number, max: number) {
        return this.request.get<GarageDto[]>(this.baseUrl + "/getGarageData" + '?min=' + min + '&max=' + max);
    }

    entityDownoad(min: number, max: number,filter:FilterOrSortingVo[],searchValue:string) {
        return this.request.post(this.baseUrl + "/entityManagement-download" + '?min=' + min + '&max=' + max+ '&searchValue=' + searchValue,filter,  { responseType: 'blob' });
      }

    public getGarageListCount() {
        return this.request.get<GarageDto[]>(this.baseUrl + "/getGarageCount");
    }

    public showCard(value: any) {
        this.cardShow.emit(value);
    }
    public DeleteCompany(Id: any) {
        return this.request.get<any>(this.baseUrl + "/DeleteCompanyIdentiy" + '?companyId=' + Id);

    }

    public DeleteGarage(garageDisableDto: any) {
        return this.request.post<any>(this.baseUrl + "/DeleteGarageIdentiy",garageDisableDto);
    }

    public saveFile(companyFileSaveDto:CompanyFileSaveDto): Observable<any> {
        return this.request.post(this.baseUrl+ "/updateFileUrl",companyFileSaveDto);
    }

    getAddNew(): Observable<boolean> {
        return this.ClickAddnew;

    }
    setAddNew(value: boolean) {
        return this.ClickAddnew.next(value);

    }

    setOnEdit(value:boolean){
        this.onEdit.next(value);
    }

    setAddNewSubscription(value:boolean){
        this.addNewCompanySubject.next(value);
    }

    getAddNewSubscription(){
        return this.addNewCompanySubject.asObservable();
    }

    getOnEdit() {
        return this.onEdit.asObservable();
    }

    setBackToCard(value:boolean){
        this.backToCardSubject.next(value);
    }

    getBackToCard(){
        return this.backToCardSubject.asObservable();
    }

    public listShow(data: boolean) {
        this.listpage.emit(data)

    }

    /*
* DownloadGarageListExcel
*/
downloadGarageListExcel(){
    return this.request.get(this.baseUrl + "/garage/download-excel" , {responseType: 'blob'});
  }
}

