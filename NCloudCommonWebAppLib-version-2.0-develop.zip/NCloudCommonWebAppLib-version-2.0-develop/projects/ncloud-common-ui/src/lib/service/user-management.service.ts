//import { environment } from 'src/environments/environment';
//import { MenuDto } from './../models/user-role-management/menu-dto';
import { UserMenuDto } from '../dto/user-menu-dto';
//import { userPageDto } from './../models/user-role-management/user_pageDto';
import { userPageDto } from '../dto/user_pageDto';
//import { UserDataDTO } from '../dto/user-data-dto';
/* eslint-disable prefer-const */
import { HttpClient } from '@angular/common/http';
//import { environment } from 'src/environments/environment';
import { UserRoleDto } from '../dto/userRoleDto';
//import { UserRolePage } from './../models/user-role-management/user-role-pageDto';
import { UserRolePage } from '../dto/user-role-pageDto';
//import { UserRoleDto } from './../models/user-role-management/userRoleDto';
//import { MetaDataDto } from 'src/app/models/report-loss-dto/meta-data-dto';
import { MetaDataDto } from '../dto/entity-management/meta-data-dto';
//import { RoleDto, UserDto } from './../models/user-role-management/role-dto';
import { RoleDto,UserDto } from '../dto/role-dto';
/* eslint-disable @typescript-eslint/no-empty-function */
import { FieldGroupDTO } from '../dto/entity-management/field-group-dto';
//import { FieldGroupDTO } from './../models/field-group-dto';
//import { Field } from './../models/report-loss-dto/field';
import { Field } from '../dto/entity-management/field';
//import { FieldDTO } from './../models/field-dto';
import { FieldDTO } from '../dto/entity-management/field-dto';
//import { FieldValueDTO } from './../models/field-value-dto';
import { FieldValueDTO } from '../dto/entity-management/field-value-dto';
//import { Section } from './../models/report-loss-dto/section';
import { Section } from '../dto/entity-management/section';
import { BehaviorSubject, of } from 'rxjs';
import { EventEmitter, Inject, Injectable, Output } from '@angular/core';
//import { appConst } from './app.const';
import { appConst } from '../const/app.const';
//import { PoolDto } from '../models/allocation-pool-dto';
import { PoolDto } from './allocation-pool-dto';
//import { FilterOrSortingVo } from '../models/Filter-dto/filter-object-backend';
import { FilterOrSortingVo } from '../dto/Filter-dto/filter-object-backend';
import { userDissableDto } from '../dto/disable-dto';

@Injectable({
  providedIn: 'root'
})
export class UserManagementService {

  loaderData = new BehaviorSubject([]);
  editedField = new BehaviorSubject(Field);

  constructor(private http: HttpClient, @Inject('env') private environment: any) { }

  private baseUrl = this.environment.API_BASE_URL;

  private ClickAddnew = new BehaviorSubject<boolean>(false);
  private headerMenuRefresh =new BehaviorSubject<boolean>(false);
  private userListSubscription = new BehaviorSubject<boolean>(false);
  @Output() emptyCardEvent= new EventEmitter();


  public ClickAdd$ = this.ClickAddnew.asObservable();


  getAccessMappingDetails(pageid:string,userRoleId:string){
    if (userRoleId!==null) {
      return this.http.get<any>(this.baseUrl + "/api/get-role-page-info?page_id="+ pageid + "&role_id="+ userRoleId )
    }else{
      return this.http.get<any>(this.baseUrl + "/api/get-role-page-info?page_id="+ pageid )

    }
  }
  getFieldMetaData(pageId:string) {
    return this.http.get<any>(this.baseUrl + "/api/paper-details/get-metadata?pageId="+pageId);
  }

  saveFieldMetaData(data:MetaDataDto,uploadType:string,actionType:string) {

    const fieldGroupDTO: FieldGroupDTO = this.convertToFieldGroup(data.sectionList,UserManagementService.DIGITAL_PAPER_DTO);


    return this.http.post(this.baseUrl+"/digital-paper/save?uploadType="+uploadType+'&actionType='+actionType ,fieldGroupDTO);
  }

  sendUserRoleData(data:MetaDataDto,accessMap:RoleDto,isActive:boolean){
    const fieldGroupDTO: FieldGroupDTO = this.convertToFieldGroup(data.sectionList,UserManagementService.USER_MANAGEMENT_ROLE__GROUP_NAME);
    const sendUserRoleDetails = new UserRolePage();
    sendUserRoleDetails.roleDetails = fieldGroupDTO;
    sendUserRoleDetails.accessMapping = accessMap;
    sendUserRoleDetails.isActive = isActive;
    return this.http.post(this.baseUrl + "/api/user-role/saveOrUpdate",sendUserRoleDetails)
  }

  sendUserData(data:MetaDataDto,notification:UserMenuDto[],isActive:boolean,platformIdentity:string){
    const fieldGroupDTO: FieldGroupDTO = this.convertToFieldGroup(data.sectionList,UserManagementService.USER_MANAGEMENT_GROUP_NAME);
    const sendUserDetails = new userPageDto();
    const userDto = new UserDto()
    userDto.menuData = notification;
    sendUserDetails.isActive = isActive;
    sendUserDetails.userDetails = fieldGroupDTO;
    sendUserDetails.enableNotification = userDto;
    return this.http.post(this.baseUrl + "/api/user-management/saveOrUpdate" + "?platform_id=" + platformIdentity,sendUserDetails)


  }

  private static USER_MANAGEMENT_ROLE__GROUP_NAME = 'UserRoleManagementDto';
  private static DIGITAL_PAPER_DTO = 'DigitalPaperDto';
  private static USER_MANAGEMENT_GROUP_NAME = 'UserManagementDto';
  public convertToFieldGroup(sectionList: Section[],groupName:string): FieldGroupDTO {
    const fieldGroupDTO: FieldGroupDTO = {
      groupName: groupName,
      fieldValues: [],
      fieldGroups: []
    };

    sectionList.forEach((section: Section) => {
      this.getFieldGroupDTO(section, fieldGroupDTO);
    });
    return fieldGroupDTO;
  }

  private getFieldGroupDTO(section: Section, parentFieldGroup: FieldGroupDTO): FieldGroupDTO {
    if(section !== undefined && section !== null) {
      const fieldGroup: FieldGroupDTO = {
        groupName: section.sectionName,
        fieldValues: [],
        fieldGroups: []
      };
      if(section.fieldList && section.fieldList.length > 0) {
        section.fieldList.forEach((field: Field) => {
          const fieldDTO: FieldDTO = {
            fieldId: field.fieldId,
            aliasName:field.aliasName,
            fieldName: field.fieldName,
            fieldType: field.fieldType,
            fieldDefault: field.defaultValues,
            minlength:field.minLength,
            maxlength:field.maxLength,
            regex:field.regex,
            mandatory:field.mandatory

          };
          const fieldValueDTO: FieldValueDTO = {
            field: fieldDTO,
            value: field.value
          };
          fieldGroup.fieldValues.push(fieldValueDTO);
        });
      }
      if(section.sectionList && section.sectionList.length > 0) {
        section.sectionList.forEach((subSection: Section) => {
          this.getFieldGroupDTO(subSection, fieldGroup);
        });
      }
      parentFieldGroup.fieldGroups.push(fieldGroup);
    }
    return parentFieldGroup;
  }

  getCardDetails(min:number,max:number,filter:FilterOrSortingVo[],searchValue:string){
    return this.http.post<CardDetails>(this.baseUrl + "/api/get-role-card"+'?min=' + min+'&max='+max+'&searchValue='+searchValue,filter);
  }

  userRoleDownload(min:number,max:number, filter:FilterOrSortingVo[]){
    return this.http.post(this.baseUrl + "/api/download-role-card"+'?min=' + min+'&max='+max,filter, { responseType: 'blob' });

  }

  getTotalCountForUserRole(filter:FilterOrSortingVo[],searchValue:string){
    return this.http.post<CardDetails>(this.baseUrl + "/api/get-role-list-count"+'?searchValue=' + searchValue,filter);
  }


  getUserManagementTableCount(filterVo: FilterOrSortingVo[], searchValue:string){
    return this.http.post<any>(this.baseUrl + "/api/get-user-management-count?searchValue="+ searchValue,filterVo)
  }
   getUserDetails(pageId:string,userId:any){

    if (userId !== 'null' && userId !== null) {
      return this.http.get<any>(this.baseUrl + "/api/get-user-management-page-info?page_id="+ pageId +"&user_id=" + userId)
    }else{
      return this.http.get<any>(this.baseUrl + "/api/get-user-management-page-info?page_id="+ pageId)

    }
  }

  getUserManagementTableList(min:number,max:number,filterVo: FilterOrSortingVo[], searchvalue:string){

    return this.http.post<any>(this.baseUrl + "/api/get-user-management-list"+'?min=' + min+'&max='+max+'&searchValue='+searchvalue,filterVo)
  }
  deleteUserDetails(userDisabel:userDissableDto){
    return this.http.post(this.baseUrl + "/api/user-management/deleteUser",userDisabel,{})
  }

  userDownloadMethoad(min:number,max:number,filterVo: FilterOrSortingVo[],searchValue:string) {
    return this.http.post(this.baseUrl + "/api/download-user-management-list"+'?min=' + min+'&max='+max+'&searchValue='+searchValue,filterVo, { responseType: 'blob' })
  }

  deleteUserRoleDetails(userDisabel:userDissableDto){
    return this.http.post(this.baseUrl + "/api/user-role/deleteRole",userDisabel,{})
  }


  getPageBasedOnRoles(list:number[]){
    const listOfRole = new ListOfRoles();
    listOfRole.listOfRoles = list;
    return this.http.post<any>(this.baseUrl + "/api/user-management/showPages"  ,listOfRole)
  }


  downloadUserExcelList(){
   return this.http.get(this.baseUrl + "/api/user-management/download-excel" , {responseType: 'blob'})
  }


  downloadRoleExcelList(){
    return this.http.get(this.baseUrl + "/api/user-role/download-excel" , {responseType: 'blob'})
   }

   setAddNew(value:boolean){
      return this.ClickAddnew.next(value);
  }

  getDropdownData(){
    const filter:FilterOrSortingVo[] = [];
    return this.http.post<AllocationUserTypeDto[]>(this.baseUrl + "/api/user-role/get-user-type",filter)
  }

  getOneStockPoolCount(identity:string){
    return this.http.post(this.baseUrl + "/digital-paper/allocation-pool/get-stock-pool?id=" + identity,{})
  }

  poolAction(poolDto:PoolDto){
    return this.http.post(this.baseUrl + "/digital-paper/allocation-pool/pool-action", poolDto)
  }

  getAllStockPool(filterObject:FilterOrSortingVo[],identity:string,min:number, max:number, searchValue:string){
    if (identity!== null) {
      return this.http.post(this.baseUrl + "/digital-paper/allocation-pool/get-all-stockpool?id=" + identity + "&min=" + min + "&max="+ max+ "&searchValue="+ searchValue,filterObject)
    }else{
      return this.http.post(this.baseUrl + "/digital-paper/allocation-pool/get-all-stockpool?min=" + min + "&max="+ max +"&searchValue="+ searchValue,filterObject)
    }
  }

  // getAllStockPool(filterObject:FilterOrSortingVo[],identity:string,min:number, max:number,){
  //   if (identity!== null) {
  //     return this.http.post(this.baseUrl + "/digital-paper/allocation-pool/get-all-stockpool?id=" + identity + "&min=" + min + "&max="+ max,filterObject)
  //   }else{
  //     return this.http.post(this.baseUrl + "/digital-paper/allocation-pool/get-all-stockpool?min=" + min + "&max="+ max,filterObject)
  //   }
  // }

  getStatusChange(identity:string, status:boolean){
    return this.http.post(this.baseUrl + "/digital-paper/allocation-pool/change-stockpool-status?status=" + status +"&id="+ identity,{})
  }

  getTotalCountForUserType() {
    return this.http.get<any>(this.baseUrl + "/digital-paper/allocation-pool/get-stockpool-count")
  }

  getAllocationType() {
    return this.http.get<any>(this.baseUrl + "/digital-paper/allocation-pool/get-allocation-type");
  }

  setDashBoardHeaderRefresh(value:boolean) {
    this.headerMenuRefresh.next(value);
  }

  getDashboardHeaderRefresh(){
     return  this.headerMenuRefresh.asObservable();
  }

  setUserSubscription(value:boolean){
     this.userListSubscription.next(value);
  }

  getUserSubscription(){
    return this.userListSubscription.asObservable();
  }

}

export class CardDetails{
  roleId:number;
  roleName:string;
  description:string;
  userCount:number;
  isActive:boolean;
  inActiveDate:string;
  isMapped:boolean;
  roleIdentity:string;
  isDisableRole:boolean;
  isDeleted:boolean;
}

export class ListOfRoles{
  listOfRoles:number[];
}

export class AllocationUserTypeDto{
  userTypeName:string;
  identity:string;
}
