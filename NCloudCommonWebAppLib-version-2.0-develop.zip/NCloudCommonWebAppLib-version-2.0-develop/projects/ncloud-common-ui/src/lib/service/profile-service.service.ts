import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { UserProfileData } from '../dto/user-profile-dto';
import { ChangePasswordDto } from '../dto/change-passoword-dto';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
 
  constructor(private request:HttpClient,@Inject('env') private environment: any) { }
  private getProfilePicture = new BehaviorSubject<boolean>(false);
  baseUrl=this.environment.API_BASE_URL+"/api/user-profile";

  getUserProfileData(){
      return  this.request.get<UserProfileData>(this.baseUrl+"/get-user");
  }

  editUserProfileData(userData:UserProfileData){
    return this.request.post(this.baseUrl+"/update-user",userData);
  }

  changePassword(passwordDto: ChangePasswordDto) {
    return this.request.post(this.baseUrl+"/change-password",passwordDto);
  }

  saveUserProfileUrl(userId:number,profileUrl:string){
    return this.request.get(this.baseUrl+"/save-userProfileUrl?userId="+userId+"&url="+profileUrl);
  }

  getUserProfilePicture(userIdentity:string){
      return this.request.get(this.baseUrl+"/get-profilepic?user_identity="+userIdentity);
  }


  setValue(value: boolean) {
    this.getProfilePicture.next(value);
  }

  getValue() {
    return this.getProfilePicture.asObservable();
  }

}
