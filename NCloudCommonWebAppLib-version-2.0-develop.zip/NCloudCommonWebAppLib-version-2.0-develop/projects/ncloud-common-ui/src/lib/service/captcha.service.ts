import { HttpClient } from "@angular/common/http";
import { Inject, Injectable } from "@angular/core";
import { VerifyCaptchaDetailsDto } from "../dto/captcha-dto";

@Injectable({
    providedIn: 'root'
})
export class CaptchaService {

  constructor(private http: HttpClient, @Inject('env') private environment: any) { }

    generateCaptcha(): any {
        return this.http.post(this.environment.API_BASE_URL + '/auth-service/auth/generate-captcha',{});
    }

    validateCaptcha(verifyCaptchaDetailsDto:VerifyCaptchaDetailsDto): any {
        return this.http.post(this.environment.API_BASE_URL + '/auth-service/auth/validate-captcha',verifyCaptchaDetailsDto);
    }
}
