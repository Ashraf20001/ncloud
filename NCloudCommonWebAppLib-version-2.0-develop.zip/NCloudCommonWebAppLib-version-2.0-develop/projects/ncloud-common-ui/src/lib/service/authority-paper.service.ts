import { HttpClient } from '@angular/common/http';
import { EventEmitter, Inject, Injectable, Output } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, from, of } from 'rxjs';
import { CompanyDetails } from '../entity-management/company/company-card/company-card.component';
import { PaperDetailsListDto } from '../dto/paper-details-list-dto';
import { FilterObject } from '../dto/Filter-dto/filter-object';
import { FilterOrSortingVo } from '../dto/Filter-dto/filter-object-backend';
import { ExcelDownloadVo, PurchaseHistoryDto } from '../dto/purchase-history-dto';
import { CompanyDto } from '../dto/entity-management/insurance-company';
import { CompanyTransaction } from '../dto/transaction-dto';
import { TransactionsListDto } from '../dto/transaction-list-dto';
import { PaymentDetailsDto } from '../dto/payment-details-dto';

@Injectable({
  providedIn: 'root'
})
export class AuthorityPaperService {

  getDropdownDataList() {
    return this.http.get(this.baseUrl+"/get-dropdown-paperdetails");
  }
  sendEmail(paperDetailsDtoCopy:PaperDetailsListDto[]) {
    return this.http.post(this.baseUrl+"/email-send",paperDetailsDtoCopy)
  }

  private baseUrl = this.environment.API_BASE_URL+"/digital-paper";
  private commonbaseUrl= this.environment.API_BASE_URL+"/api";
  private ClickAddnew = new BehaviorSubject<boolean>(false);
  public ClickAdd$ = this.ClickAddnew.asObservable();

  @Output()
  emitFilterObject=new EventEmitter<FilterObject[]>();
  @Output()
  emitFilterVoObject=new EventEmitter<FilterOrSortingVo[]>();


  constructor(private http:HttpClient,private router:Router, @Inject('env') private environment: any) { }
  private selectedColumnForDownlod = new BehaviorSubject([]);
  public isChecked$ = this.selectedColumnForDownlod.asObservable();

  getPurchaseHistoryCount(filterVo: FilterOrSortingVo[]) {
    return this.http.post(this.baseUrl+"/getPurchaseOrderEntityCount",filterVo)
  }


  getPurchaseHistory(skip:number,limit:number,filterVo: FilterOrSortingVo[]) {
    return this.http.post<PurchaseHistoryDto[]>(this.baseUrl+"/purchaseHistory"+"?skip="+skip+"&limit="+limit,filterVo);
  }

  excelDownload(excelDownloadVo:ExcelDownloadVo): Observable<any> {
    return this.http.post(this.baseUrl+"/purchase-history-download",excelDownloadVo,{ responseType: 'blob' });
  }

  excelDownloadForPaperDetails(excelDownloadVo:ExcelDownloadVo): Observable<any> {
    return this.http.post(this.baseUrl+"/get-paperdetails-download",excelDownloadVo,{ responseType: 'blob' });
  }

  excelDownloadForPaperDetailsTransactionList(excelDownloadVo:ExcelDownloadVo): Observable<any> {
    return this.http.post(this.baseUrl+"/download-view-paper",excelDownloadVo,{ responseType: 'blob' });
  }

  excelDownloadForTransaction(excelDownloadVo:CompanyTransaction): Observable<any> {
    return this.http.post(this.baseUrl+"/transaction-download",excelDownloadVo,{ responseType: 'blob' });
  }

  excelDownloadForDigitalPaper(id:number){
    return this.http.get(this.baseUrl+"/get-paperExcel?bulkUploadId="+id+"&pageIdentity=c741ae6b5c3a49b888d2592a51c6bu8u",{ responseType: 'blob' });
  }

  getSelectedColumn():Observable<string[]> {
    return this.selectedColumnForDownlod;

  }
  setSelectedColumn(value:any){
    return this.selectedColumnForDownlod.next(value);
  }

  getAllPurchaseOrderCount(transactionVo:CompanyTransaction) {
    return this.http.post<number>(this.baseUrl+"/getAllCount",transactionVo);
  }

  getCompanyPurchaseTransaction(transactionVo:CompanyTransaction){
    return this.http.post<TransactionsListDto[]>(this.baseUrl+"/get-transactionDetails",transactionVo);
  }

  setApproveOrReject(paymentDetails:PaymentDetailsDto){
      return this.http.post<string>(this.baseUrl+"/purchase-details/status",paymentDetails);
  }

  getCompanyCount(){
    return this.http.get<number>(this.commonbaseUrl+"/entitymanagement/getInsuranceDataCount");
  }

  getCompanyList(min:number,max:number){
    return this.http.get<CompanyDetails[]>(this.commonbaseUrl+"/entitymanagement/getInsuranceData"+"?min="+min+"&max="+max);
  }

  getPaperDetailsCount(filterVo: FilterOrSortingVo[]) {
    return this.http.post(this.baseUrl+"/get-paperdetails-count",filterVo)
  }

  getPaperDetailsList(skip: number, limit: number, filterVo: FilterOrSortingVo[]) {
    return this.http.post<PaperDetailsListDto[]>(this.baseUrl+"/get-paperdetails-list"+"?skip="+skip+"&limit="+limit,filterVo);
  }

  updateRevokeStatusData(identity: string) {
    return this.http.post<string>(this.baseUrl+"/update-revoke-status?identity="+identity,{});
  }

  getPaperDetailsData(identity: string) {
    return this.http.get<PaperDetailsListDto>(this.baseUrl+"/get-revoke-data?identity="+identity,{});
  }

  downloadSampleExcel(sampleFileColumns: string[]) {
    return this.http.post(this.baseUrl+"/sample-file-download",sampleFileColumns,{responseType: 'blob'});
  }

  bulkUploadSampleExcelDownload(pageIdentity: string) : Observable<any> {
    return this.http.post(this.baseUrl+"/bulk-upload-excel-download?pageIdentity="+pageIdentity,{},{responseType: 'blob'});
  }

  getAuthorityPaperDetailsCount(filterVo: FilterOrSortingVo[]) {
    return this.http.post(this.baseUrl+"/authority/get-stock-count",filterVo);
  }

  getAuthorityPaperDetailsList(skip: number, limit: number, filterVo: FilterOrSortingVo[]) {
    return this.http.post(this.baseUrl+"/get-stock-data"+"?skip="+skip+"&limit="+limit,filterVo);
  }

  getAuthPaperDetailsCount(companyDetails: CompanyTransaction) {
   return this.http.post<number>(this.baseUrl+"/get-paperdetailscount-bycompany",companyDetails);
  }

  getAuthPaperDetailsList(companyDetails: CompanyTransaction) {
    return this.http.post<PaperDetailsListDto>(this.baseUrl+"/get-paperdetailslist-bycompany",companyDetails);
  }

  getAddNew():Observable<boolean> {
    return this.ClickAddnew;

  }
  setAddNew(value:boolean){
    return this.ClickAddnew.next(value);

  }

  passFilterObject(value:FilterObject[]){
      this.emitFilterObject.emit(value);
    }

  passFilterVoObject(value:FilterOrSortingVo[]){
    this.emitFilterVoObject.emit(value);
  }

  getCompanyDto() {
    return this.http.get<CompanyDto[]>(this.commonbaseUrl+"/entitymanagement/get-all-company");
  }
}
