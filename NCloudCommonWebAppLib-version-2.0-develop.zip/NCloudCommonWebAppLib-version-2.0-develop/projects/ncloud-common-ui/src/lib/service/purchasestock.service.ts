import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { FilterOrSortingVo, DownloadVo } from '../dto/Filter-dto/filter-object-backend';
import { PurchaseStockListDto } from '../dto/purchase-stock-list';

@Injectable({
  providedIn: 'root'
})
export class PurchaseStockService {
 

  constructor(private request : HttpClient, @Inject('env') private environment: any) { }

  private baseUrl = this.environment.API_BASE_URL+"/digital-paper";

  getPurchaseDetails(min:number, max:number,fitervo:FilterOrSortingVo[]){
    return this.request.post<PurchaseStockListDto[]>(this.baseUrl+"/getPurchaseList?min="+min+"&max="+max,fitervo);
  }

  getDrowpDownData(){
    return this.request.get(this.baseUrl+"/get-dropdownList");
  }

  getPurchaseOrderCount(filterVo:FilterOrSortingVo[]){
    return this.request.post<number>(this.baseUrl+"/getCount",filterVo);
  }

  getPurchaseStockFile(id:number){
    return this.request.get<number>(this.baseUrl+"/get-stockFileId?id="+id);
  }

  purchaseStockDownload(downloadVo: DownloadVo) {
      return this.request.post(this.baseUrl+"/purchaseStock-download",downloadVo, { responseType: 'blob' });
     
  }
}
