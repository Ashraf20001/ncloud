import { HttpClient } from '@angular/common/http';
import { Injectable, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { ResetPasswordRequest } from '../dto/reset-password-request-dto';
import { Observable, of } from 'rxjs';
import { LoginDto } from '../dto/login-dto';
import { PlatformDetailsDto } from '../dto/platform-details-dto';
import { CookieService } from 'ngx-cookie-service';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';

@Injectable({
    providedIn: 'root'
})
export class AuthService {

    loginResponse:any;

    rz_prefix = '/api';
    dp_prefix = '/auth-service/';

    signInURL = 'auth/signin';

    resetFirstTimeUrl = 'auth/resetpassword';

    sendMailIdToResetPasswordUrl = 'auth/forgetPassword';

    commonResetPasswordUrl = 'auth/updatepassword';

    constructor(private http: HttpClient, private router:Router, @Inject('env') private environment: any, private cookieService : CookieService,
    private toaster:ToastrService,
    public translate: TranslateService,) { }

    // connecting backend and verifing user credentials
    ProceedLogin(username:string, password:string, isAuthority?: boolean): Observable<any> {
        const url = this.getPlatformSpecificUrl();
        const platformDetails = JSON.parse(sessionStorage.getItem('platformDetails') ?? '{}');
        let userType;
        if (isAuthority === true) {
            userType = {
                userTypeId: 1,
                userTypeName: 'ASSOCIATION'
            };
        } else {
            userType = {
                userTypeId: 2,
                userTypeName: 'INSURANCE_COMPANY'
            };
        }
        if(platformDetails) {

            const loginDto: LoginDto = {
                username: username,
                password: password,
                platformDetailsDto: platformDetails,
                userTypeDto: userType
              };

            if(platformDetails.platformId === 1) {
                
                return this.http.post(url + this.signInURL,loginDto);
            }
            else if (platformDetails.platformId === 2){
                // const platformDetails = {
                //     platformId: 2,
                //     platformName: 'Digital Paper',
                //     platformIdentity: 'e31c7ccb51d047e7930b5cf5908ae9de',
                //     platformLogoPath:'',
                //     platformUrl: 'http://localhost:4200'
                // };


                return this.http.post(url + this.signInURL, loginDto);
            }
            else{
                // const platformDetails = {
                //     platformId: 3,
                //     platformName: 'Data Lake',
                //     platformIdentity: 'a129f254-3539-11ee-b22e-f6efad2fa5e2',
                //     platformLogoPath : '/assets/headericon/platformicon/platform_logo.svg',
                //     platformUrl: 'http://localhost:4200'
                //   };
           
                  return this.http.post(this.environment.API_BASE_URL + this.dp_prefix + this.signInURL, loginDto);
            }
        } else {
            return of(null);
        }
    }

    //checking user is still loggedin or not
    IsLoggedIn() {
        let myCurrentToken = sessionStorage.getItem('token') != null;
        return myCurrentToken;
    }

    //checking jwt oken is still in session storage
    GetToken() {
        return sessionStorage.getItem('token');
    }

    //getting role details from payload of jwt token
    HaveAccess() {
        var logintoken = sessionStorage.getItem('token') || '';
        var _extractedtoken = logintoken.split('.')[1];
        var _atobdata = atob(_extractedtoken);
        var _finaldata = JSON.parse(_atobdata);
        if (_finaldata.role == 'admin') {
        return true;
        } else {
        alert('you not having access');
        return false;
        }
    }

    logout() {
        this.router.navigateByUrl('/login')
        sessionStorage.removeItem('userTypeId');
    sessionStorage.removeItem('username');
    sessionStorage.removeItem('token');
    sessionStorage.removeItem('platformDetails');
    sessionStorage.removeItem('companyId');

    }

    // autoLogout(expirationTime: number) {
    //     setTimeout(() => {
    //     this.logout();
    //     }, expirationTime);
    // }

    autoLogout(){
        const logintoken = sessionStorage.getItem('token') || '';
        const _finaldata = JSON.parse(atob(logintoken.split('.')[1]));

        if(_finaldata!==undefined && _finaldata.exp!==null && _finaldata.exp!==undefined){
            const expires = new Date(_finaldata.exp * 1000);
            const timeout = expires.getTime() - Date.now();

            setTimeout(()=>{
                this.logout();
            },timeout)
            // sessionStorage.clear();
        } else {
            console.log('Invalid access token');
        }
    }

    isSessionExpired(): boolean {
        return this.getExpireTime() && this.getExpireTime().getTime() <= Date.now();
    }

    getExpireTime(): any {
        const logintoken = sessionStorage.getItem('token')||'';
        if(logintoken !== '') {
            const _extractedtoken=logintoken.split('.')[1];
            const _atobdata=atob(_extractedtoken);
            const _finaldata=JSON.parse(_atobdata);
            let expires;
            if(_finaldata!==undefined && _finaldata.exp!==null && _finaldata.exp!==undefined){
                expires = new Date(_finaldata.exp * 1000);
            }
            return expires;
        }
        return undefined;
    }

    resetFirstTimePassword(request: ResetPasswordRequest) {
        return this.http.put(this.getPlatformSpecificUrl() + this.resetFirstTimeUrl, request);
    }

    commonResetPassword(request: ResetPasswordRequest) {
        return this.http.put(this.getPlatformSpecificUrl() + this.commonResetPasswordUrl, request);
    }

    sendMailToResetPassword(emailId: string, platformName: string) {
        const forgetPasswordDto:ForgetPasswordDto ={
            emailId:emailId,
            userType:''
        };
        const url = `${this.environment.API_BASE_URL}/auth-service/${this.sendMailIdToResetPasswordUrl}?platformName=${platformName}`;
        return this.http.post( url,
        forgetPasswordDto
        );
    }

    getPlatformDetails() {
        return this.http.get<PlatformDetailsDto[]>(
          this.environment.API_BASE_URL + this.rz_prefix + '/getPlatformDetails'
        );
    }

    /**
     *
     * @returns
     */
    getUserRolePrivillege(){
        return this.http.get(this.environment.API_BASE_URL+'/data-lake/repository/check-authority-type');
      }

    getPlatformSpecificUrl(): string {
        // const platformDetails = JSON.parse(sessionStorage.getItem('platformDetails') ?? '');
        const propertyValue = sessionStorage.getItem('platformDetails');
        if(propertyValue === null) {
            this.toaster.error( this.translate.instant(`ERROR_DATA.PLATEFORM_ERROR`));

        }
         const platformDetails = JSON.parse(propertyValue);
        const url=this.dp_prefix;
        return this.environment.API_BASE_URL + url;
    }

}

export interface ForgetPasswordDto{
    emailId:string;
    userType:string;
}
