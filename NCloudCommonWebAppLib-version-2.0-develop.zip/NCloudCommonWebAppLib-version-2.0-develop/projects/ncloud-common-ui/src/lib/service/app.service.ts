import { Inject, Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { commonConst } from '../const/common.const';
import { NotificationDetailsDto, NotificationRequestDto } from '../dto/notification-request-dto';
import { NotificationDTO } from '../dto/notification-dto';
import { Observable } from 'rxjs';
import { NotificationCountDTO } from '../dto/notification-count-dto';

@Injectable({
    providedIn: 'root'
})
export class AppService {
    public appConst = commonConst;
    private baseUrl = '/api/privillege/all';
    private dataLake = "/data-lake"

    constructor(
        public http: HttpClient,
        @Inject('env') private environment: any
    ) {}

    // GET MENU ROLES
    public getMenubyRole() {
        return this.http.get(this.environment.API_BASE_URL + '/api/menu/all');
    }

    //GET PRIVILEGE FOR PAGE
    public getPrivilegeForPage(pageName: number) {
        return this.http.get(
            this.environment.API_BASE_URL + this.baseUrl + '?pageId=' + pageName
        );
    }

    //GET PAGE ACCESS
    public getPageAccess(pageIdentity: string) {
        return this.http.get(
            this.environment.API_BASE_URL +
            '/api/page/access?pageIdentity=' +
            pageIdentity
        );
    }
    /**
     * Notification List For Data Lake
     * @param baseUrl 
     * @param param 
     * @returns 
     */
    getNotificationListForDataLake(param?: any) {
        return this.http.get(this.environment.API_BASE_URL+ this.dataLake + '/notification', { params: param });
    }

    getNotificationListForDataLakeIC(notificationData: NotificationRequestDto): Observable<NotificationDTO[]> {
        return this.http.post<NotificationDTO[]>(this.environment.API_BASE_URL + '/notify/getNotificationHistory', notificationData);
    }

    updateNotificationListForDataLakeIC(notificationDetailsData: NotificationDetailsDto){
        return this.http.post(this.environment.API_BASE_URL+'/notify/updateNotification',notificationDetailsData);
    }

    getRepositoryDetails(params: HttpParams): Observable <any>{
        return this.http.get(this.environment.API_BASE_URL+this.dataLake+'/repository/repository-details',{params:params});
    }

    /**
     * NOTIFICATION COUNT
     * @returns
     */
    getNotificationCount() {
        return this.http.get(this.environment.API_BASE_URL+ this.dataLake + '/get-notification-Count');
    }

    getNotificationCountIC(notificationData: NotificationRequestDto): Observable<NotificationCountDTO> {
        return this.http.post<NotificationCountDTO>(this.environment.API_BASE_URL + '/notify/getNotificationHistoryCount', notificationData);
    }

   // GET MENU DETAILS
    public getMenuDetails() {
    return this.http.get(this.environment.API_BASE_URL + '/api/app-header/platform-menu-details');
    }

   /**
   * 
   * @param params 
   * @returns 
   */
  getRepositoryStatus(params: HttpParams) {
    return this.http.get(this.environment.API_BASE_URL + '/data-lake/repository/repository-status', {params : params});
  }

  /**
   * 
   * @param params 
   * @returns 
   */
  updateNotification(params: any) {
    return this.http.get(this.environment.API_BASE_URL + '/data-lake/update-notification-unread', { params: params });
} 
}
