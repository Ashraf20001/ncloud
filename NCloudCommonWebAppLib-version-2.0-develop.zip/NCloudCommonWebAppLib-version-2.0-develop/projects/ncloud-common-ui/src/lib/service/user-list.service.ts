import { HttpClient } from '@angular/common/http';
import { EventEmitter, Inject, Injectable, Output } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, from, Observable, of } from 'rxjs';
import { Messager, UserTotalDTO } from '../dto/user-data-dto';
import { ApprovalLimitDto } from '../dto/approval-limit-dto';

@Injectable({
  providedIn: 'root'
})
export class UserListService {
  private baseUrl = this.environment.API_BASE_URL+"/api";
  @Output() cardShow= new EventEmitter<boolean>();
  @Output() isClone= new EventEmitter<boolean>();
  private ClickAddnew = new BehaviorSubject<boolean>(false);
  public ClickAdd$ = this.ClickAddnew.asObservable();
  public sharedCompanyList = [];
  constructor(private http:HttpClient,private router:Router, @Inject('env') private environment: any) { }

getUserComments(claimId: string):Observable<any>{

      return this.http.get(this.baseUrl+"/reportloss/comments?claimId="+claimId);
  }

  setUserComments(claimId:string, data:Messager):Observable<any>{
      return this.http.post(this.baseUrl+"/reportloss/comments?claimId="+claimId,data);
  }

  getFieldList(){
    return this.http.get<any>(this.baseUrl+"/Approvallimit/field-list")
  }
  getRoleList(){
    return this.http.get<any>(this.baseUrl+"/Approvallimit/role-list")
  }
  getCompanyList(action:string){
    return this.http.get<Map<number,string>>(this.baseUrl+"/Approvallimit/company-list"+"?action="+action)
  }
  saveApprovalLimit(ApprovalLimitDto:any){
    return this.http.post(this.baseUrl+"/Approvallimit/saveOrUpdate",ApprovalLimitDto)
  }
  saveKnockKnockLimit(ApprovalLimitDto:any){
    return this.http.post(this.baseUrl+"/Approvallimit/saveOrUpdate-knock-limit",ApprovalLimitDto)
  }
  getApprovalLimitList(min:number,max:number){
    return this.http.get<ApprovalLimitDto[]>(this.baseUrl+"/Approvallimit/get-approval-list"+'?min=' + min+'&max='+max);
  }

  getApprovalLimitCount(){
    return this.http.get<ApprovalLimitDto[]>(this.baseUrl+"/Approvallimit/get-approval-count");
  }

  DeleteApprovalimit(approvalLimitId:any){
    return this.http.get(this.baseUrl+"/Approvallimit/delete-list?approvalLimitId=" +approvalLimitId);
  }
  getAppprovalLimitByIdentity(approvalLimitId:any){
    return this.http.get<ApprovalLimitDto>(this.baseUrl+"/Approvallimit/edit-list?approvalLimitId=" +approvalLimitId)
  }

  getCurrencyTypeList(){
    return this.http.get<any>(this.baseUrl+"/Approvallimit/currency-types");
  }
  public showCard(value: any){
    this.cardShow.emit(value);
}

  getClaimHistory(claimId: string):Observable<any>{
    return this.http.get(this.baseUrl+"/claim/history?claimId="+claimId);
  }
  public clone(value: any){
    this.isClone.emit(value);
}

getAddNew():Observable<boolean> {
  return this.ClickAddnew;

}
setAddNew(value:boolean){
  return this.ClickAddnew.next(value);

}
/*
* DownloadApprovalLimitListExcelList
*/
downloadApprovalLimitListExcelList(){
  return this.http.get(this.baseUrl + "/Approvallimit/download-excel" , {responseType: 'blob'});
}
download(param:any,name: any[]){

  return this.http.post<any>(this.baseUrl+'/data/export-master-datas', name, { params: param });

}

import(param:any,name:FormData)
{
  return this.http.post<any>(this.baseUrl+'/data/import-master-datas', name, { params: param });
}
getExport(param:any)
{
  return this.http.get(this.baseUrl + '/data/get-master-table-details', {params:param});
}

}
