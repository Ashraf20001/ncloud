package com.authentication.common.filters;

import java.util.HashMap; 
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.common.constants.core.ApplicationConstants;


@Component
public class AuthMasterFilterFactory {
	/**
	 * The bw filter.
	 */
	@Autowired(required = false)
	@Qualifier("BWFilter")
	private IMasterFilter bwFilter;

	/**
	 * The equals filter.
	 */
	@Autowired(required = false)
	@Qualifier("EqualFilter")
	private IMasterFilter equalsFilter;

	/**
	 * The gte filter.
	 */
	@Autowired(required = false)
	@Qualifier("GTEFilter")
	private IMasterFilter gteFilter;

	/**
	 * The gt filter.
	 */
	@Autowired(required = false)
	@Qualifier("GTFilter")
	private IMasterFilter gtFilter;

	/**
	 * The like filter.
	 */
	@Autowired(required = false)
	@Qualifier("LikeFilter")
	private IMasterFilter likeFilter;

	/**
	 * The lte filter.
	 */
	@Autowired(required = false)
	@Qualifier("LTEFilter")
	private IMasterFilter lteFilter;

	/**
	 * The lt filter.
	 */
	@Autowired(required = false)
	@Qualifier("LTFilter")
	private IMasterFilter ltFilter;

	/**
	 * The master filter factory map.
	 */
	private Map<String, IMasterFilter> masterFilterFactoryMap = null;

	/**
	 * The round off filter.
	 */
	@Autowired(required = false)
	@Qualifier("RoundOffFilter")
	private IMasterFilter roundOffFilter;

	/**
	 * The sorting filters.
	 */
	@Autowired(required = false)
	@Qualifier("SortingFilters")
	private IMasterFilter sortingFilters;

	/**
	 * Bulid map.
	 */
	@PostConstruct
	public void bulidMap() {
		masterFilterFactoryMap = new HashMap<>();
		masterFilterFactoryMap.put(ApplicationConstants.EQUAL, equalsFilter);
		masterFilterFactoryMap.put(ApplicationConstants.LIKE, likeFilter);
		masterFilterFactoryMap.put(ApplicationConstants.GTE, gteFilter);
		masterFilterFactoryMap.put(ApplicationConstants.GT, gtFilter);
		masterFilterFactoryMap.put(ApplicationConstants.LTE, lteFilter);
		masterFilterFactoryMap.put(ApplicationConstants.LT, ltFilter);
		masterFilterFactoryMap.put(ApplicationConstants.BETWEEN, bwFilter);
		masterFilterFactoryMap.put(ApplicationConstants.ORDERBY, sortingFilters);
		masterFilterFactoryMap.put(ApplicationConstants.ROUNDOFF, roundOffFilter);
	}

	/**
	 * Gets the filter by name.
	 *
	 * @param filterName the filter name
	 * @return the filter by name
	 */
	public IMasterFilter getFilterByName(String filterName) {
		return masterFilterFactoryMap.get(filterName);
	}


}
