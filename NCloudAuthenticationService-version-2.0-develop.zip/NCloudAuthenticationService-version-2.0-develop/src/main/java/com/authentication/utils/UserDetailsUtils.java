package com.authentication.utils;

import java.util.ArrayList;
import java.util.List;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.authentication.model.UserDetailsImpl;
import com.common.transfer.object.entity.Role;
import com.common.utils.core.ApplicationUtils;


/**
 * The Class UserDetailsUtils.
 */
@Component
public class UserDetailsUtils {
	
	/**
	 * Login userdetails.
	 *
	 * @return the user details impl
	 */
	public UserDetailsImpl loginUserdetails() {

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
		return userDetails;
 
	}

	/**
	 * Login user roles.
	 *
	 * @return the list
	 */
	public List<String> loginUserRoles() {

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();

		return userDetails.getAuthorities().stream().map(GrantedAuthority::getAuthority).toList();
	

	}
	
	/**
	 * Gets the role ids.
	 *
	 * @return the role ids
	 */
	public List<Integer> getRoleIds() {
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
		
		List<Integer> roles = userDetails.getroles().stream().map(Role::getRoleId).toList();
		
		return roles;
		
	}

	/**
	 * Checks for super admin privilage.
	 *
	 * @return true, if successful
	 */
	public boolean hasSuperAdminPrivilage() {
		List<String> loginUserRoles = loginUserRoles();
		if(loginUserRoles == null || loginUserRoles.isEmpty()) {
			return false;
		}
		UserDetailsImpl userDetails = loginUserdetails();
		if(ApplicationUtils.isValidateObject(userDetails.getUserTypeId())
				&&userDetails.getUserTypeId().getUserTypeId()==3){
			return true;
		}
		return false;

	}

	
	/**
	 * Checks for association privilage.
	 *
	 * @return true, if successful
	 */
	public boolean hasAssociationPrivilage() {
		List<String> loginUserRoles = loginUserRoles();
		if(loginUserRoles == null || loginUserRoles.isEmpty()) {
			return false;
		}
		UserDetailsImpl userDetails = loginUserdetails();
		if(ApplicationUtils.isValidateObject(userDetails.getUserTypeId())
				&& userDetails.getUserTypeId().getUserTypeId()==1||userDetails.getUserTypeId().getUserTypeId()==3){
			return true;
		}
		return false;
	}
}
