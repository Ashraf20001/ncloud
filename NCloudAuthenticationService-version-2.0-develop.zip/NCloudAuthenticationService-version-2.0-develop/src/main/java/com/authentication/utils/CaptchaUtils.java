package com.authentication.utils;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.Random;

import javax.imageio.ImageIO;

import org.springframework.stereotype.Component;

import com.common.transfer.object.dto.CaptchaDataDto;




/**
 * The Class CaptchaUtils.
 */
@Component
public class CaptchaUtils {
	
	/** The random. */
	private static Random random = new Random();
    
    /** The Constant captcha. */
    private static final String captcha = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
	
	/**
	 * Generate captcha image.
	 *
	 * @return the captcha data dto
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public static CaptchaDataDto generateCaptchaImage() throws IOException {
		String captcha = generateCaptcha(5);

		int width = 140, height = 35;
		BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.OPAQUE);
		Graphics graphics = bufferedImage.createGraphics();
		graphics.setFont(new Font("Arial", Font.BOLD, 20));
		graphics.setColor(new Color(255, 255, 255));
		graphics.fillRect(0, 0, width, height);
		graphics.setColor(new Color(11, 39, 155));
		graphics.drawString(captcha, 35, 25);
		graphics.drawLine(5, 30, 130, 10);
		graphics.drawLine(5, 10, 130, 20);

		// Convert byte array to base64
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		try {
			ImageIO.write(bufferedImage, "png", os);
		} catch (IOException e) {
			throw e;
		}

		CaptchaDataDto captchaData = new CaptchaDataDto();
		captchaData.setCaptcha(Base64.getEncoder().encodeToString(os.toByteArray()));
		captchaData.setCaptchaValue(captcha);
		return captchaData;
	}
	 
 	/**
 	 * Generate captcha.
 	 *
 	 * @param captchaLength the captcha length
 	 * @return the string
 	 */
 	private static String generateCaptcha(int captchaLength) {

			StringBuilder captchaBuffer = new StringBuilder();

			while (captchaBuffer.length() < captchaLength) {
				int index = (int) (random.nextFloat() * captcha.length());
				captchaBuffer.append(captcha.substring(index, index + 1));
			}

			return captchaBuffer.toString();
		}

}
