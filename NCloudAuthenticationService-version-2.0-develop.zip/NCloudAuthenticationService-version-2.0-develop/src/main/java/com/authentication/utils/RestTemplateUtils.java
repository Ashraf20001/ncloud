package com.authentication.utils;

import java.util.Arrays;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

/**
 * The Class RestTemplateUtils.
 */
@Component("authenticationRestTemplate")
public class RestTemplateUtils {
    
    /**
     * Gets the POST headers.
     *
     * @return the POST headers
     */
    public HttpHeaders getPOSTHeaders(){
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        return headers;
    }
    
    /**
     * Gets the gets the headers.
     *
     * @return the gets the headers
     */
    public HttpHeaders getGETHeaders(){
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        return headers;
    }
}
