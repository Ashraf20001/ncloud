package com.authentication.utils;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;

/**
 * The Class EncryptDecryptUtil.
 */
@Component
public class EncryptDecryptUtil {

	/**
	 * Encrypt By secret-key.
	 *
	 * @param plainText the plain text
	 * @param key the key
	 * @return the string
	 * @throws Exception the exception
	 */
	public String encrypt(String plainText, String key) throws Exception {
		Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
		Key aesKey = new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "AES");
		cipher.init(Cipher.ENCRYPT_MODE, aesKey);
		byte[] encryptedBytes = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));
		return Base64.getEncoder().encodeToString(encryptedBytes);
	}

	/**
	 * Decrypt Plain Text by use of secrete key.
	 *
	 * @param encryptedText the encrypted text
	 * @param key the key
	 * @return the string
	 * @throws Exception the exception
	 */
	public String decrypt(String encryptedText, String key) throws Exception {
		Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
		Key aesKey = new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "AES");
		cipher.init(Cipher.DECRYPT_MODE, aesKey);
		byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedText));
		return new String(decryptedBytes, StandardCharsets.UTF_8);
	}

}
