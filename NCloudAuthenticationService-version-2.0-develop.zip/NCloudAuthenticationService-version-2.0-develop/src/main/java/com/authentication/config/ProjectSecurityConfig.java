package com.authentication.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.BaseLdapPathContextSource;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.config.ldap.LdapBindAuthenticationManagerFactory;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.header.writers.CrossOriginEmbedderPolicyHeaderWriter;
import org.springframework.security.web.header.writers.CrossOriginOpenerPolicyHeaderWriter;
import org.springframework.security.web.header.writers.CrossOriginResourcePolicyHeaderWriter;
import org.springframework.security.web.header.writers.ReferrerPolicyHeaderWriter;
import org.springframework.security.web.util.matcher.AnyRequestMatcher;

import com.authentication.security.jwt.AuthEntryPointJwt;
import com.authentication.security.jwt.AuthTokenFilter;
import com.authentication.service.impl.UserDetailsServiceImpl;



/**
 * The Class ProjectSecurityConfig.
 */
@EnableWebSecurity
@Configuration
public class ProjectSecurityConfig {

	/** The user details service. */
	@Autowired
	UserDetailsServiceImpl userDetailsService;

	/** The unauthorized handler. */
	@Autowired
	private AuthEntryPointJwt unauthorizedHandler;
		
	/** The ldap url. */
	@Value("${ldap.url}")
	private String ldapUrl;
	
	/** The base DN. */
	@Value("${base.DN}")
	private String baseDN;
	
	/** The ldap user DN. */
	@Value("${ldap.user.DN}")
	private String ldapUserDN;
	
	/** The password. */
	@Value("${ldap.admin.password}")
	private String password;
	
	/** The is ldap authetication. */
	@Value("${auth.authentication.ldap}")
	private String isLdapAuthetication;

	/**
	 * Authentication jwt token filter.
	 *
	 * @return the auth token filter
	 */
	@Bean
	public AuthTokenFilter authenticationJwtTokenFilter() {
		return new AuthTokenFilter();
	}
	
	/**
	 * Password encoder.
	 *
	 * @return the password encoder
	 */
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	/**
	 * Authentication manager.
	 *
	 * @param authConfig the auth config
	 * @return the authentication manager
	 * @throws Exception the exception
	 */
	@Bean(name = "databaseAuthentication")
	public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception {
		return authConfig.getAuthenticationManager();
	}

	/**
	 * Authentication provider.
	 *
	 * @return the dao authentication provider
	 */
	@Bean
	public DaoAuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
		authProvider.setUserDetailsService(userDetailsService);
		authProvider.setPasswordEncoder(passwordEncoder());

		return authProvider;
	}


	/** The Constant AUTH_WHITELIST. */
	private static final String[] AUTH_WHITELIST = {
            "/v2/api-docs",
            "/swagger-resources",
            "/swagger-resources/**",
            "/configuration/ui",
            "/configuration/security",
            "/swagger-ui.html",

            "/webjars/**",
            "/v3/api-docs/**",
            "/swagger-ui/**",
            "/auth/**",
            "/ws/**",
            "/downloadFile/**",
            "/notification/**",
            "/report/generateData",
			"/trigger-monthly-report-generation",
			"/trigger-payment-reminder-setup",
			"/notification/get-payment-reminder-notification-template",
			"/notification/get-reminder-notification-template",
			"/notification/report/get-unpaid-company-list",
			"/get-scheduler-details",
			"/get-scheduler-details-by-id",
			"/update-scheduler-details",
			"/login"

    };

	/**
	 * Filter chain.
	 *
	 * @param http the http
	 * @return the security filter chain
	 * @throws Exception the exception
	 */
	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

		http.cors().and().csrf().disable().exceptionHandling().authenticationEntryPoint(unauthorizedHandler).and()
				.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and().authorizeRequests()
				.antMatchers(AUTH_WHITELIST).permitAll()
				.anyRequest().authenticated().and().httpBasic().and().formLogin();
		http.headers().httpStrictTransportSecurity().disable();
		http.headers().frameOptions().sameOrigin();
		http.headers()
				.httpStrictTransportSecurity()
				.requestMatcher(AnyRequestMatcher.INSTANCE)
				.includeSubDomains(true).maxAgeInSeconds(31536000);

		http.headers().referrerPolicy(ReferrerPolicyHeaderWriter.ReferrerPolicy.SAME_ORIGIN);
		http.headers().contentSecurityPolicy("script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net;");
		http.headers().crossOriginResourcePolicy().policy(CrossOriginResourcePolicyHeaderWriter.CrossOriginResourcePolicy.CROSS_ORIGIN);
		http.headers().crossOriginEmbedderPolicy().policy(CrossOriginEmbedderPolicyHeaderWriter.CrossOriginEmbedderPolicy.REQUIRE_CORP);
		http.headers().crossOriginOpenerPolicy().policy(CrossOriginOpenerPolicyHeaderWriter.CrossOriginOpenerPolicy.SAME_ORIGIN);
		http.headers(headers -> headers.permissionsPolicy(permissions -> permissions.policy("geolocation=(self)")));	
		http.addFilterBefore(authenticationJwtTokenFilter(), UsernamePasswordAuthenticationFilter.class);
		return http.build();
	}


	@Bean
	public LdapTemplate ldapTemplate() {
		return new LdapTemplate(contextSource());
	}

	@Bean
	public LdapContextSource contextSource() {
		LdapContextSource ldapContextSource = new LdapContextSource();
		ldapContextSource.setUrl(ldapUrl);
		ldapContextSource.setUserDn(baseDN);
		ldapContextSource.setPassword(password);
		return ldapContextSource;
	}
	
	@Bean(name = "ldapAuthentication")
	public AuthenticationManager authManager(BaseLdapPathContextSource source) {
		LdapBindAuthenticationManagerFactory factory = new LdapBindAuthenticationManagerFactory(source);
		factory.setUserDnPatterns(ldapUserDN);
		return factory.createAuthenticationManager();
	}
	
}
