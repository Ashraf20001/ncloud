package com.authentication.config;

import javax.sql.DataSource; 

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.authentication.properties.AuthEnvironmentProperties;
import com.mchange.v2.c3p0.ComboPooledDataSource;

/**
 * The Class AuthDataSourceConfig.
 */
@Configuration
@EnableTransactionManagement
public class AuthDataSourceConfig {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(AuthDataSourceConfig.class);

	/** The environmentproperties. */
	@Autowired
	private AuthEnvironmentProperties environmentproperties;

	/** The master data source. */
	private final ComboPooledDataSource masterDataSource = new ComboPooledDataSource();

	/**
	 * Gets the data source.
	 *
	 * @return the data source
	 */
	@Autowired
	@Bean(name = "masterDataSource")
	@Primary
	public DataSource getDataSource() {
		try {
			masterDataSource.setDriverClass(environmentproperties.getMysqlDriver());
			masterDataSource.setJdbcUrl(environmentproperties.getJdbcUrl());
			masterDataSource.setPassword(environmentproperties.getMySqlPassword());
			masterDataSource.setUser(environmentproperties.getMysqlUserName());
			logger.info("MySql username : " + environmentproperties.getMysqlUserName());
			logger.info("MySql password : " + environmentproperties.getMySqlPassword());
		} catch (Exception e) {
			logger.error("Can't Set Data Source" + e);
		}
		return masterDataSource;
	}

}
