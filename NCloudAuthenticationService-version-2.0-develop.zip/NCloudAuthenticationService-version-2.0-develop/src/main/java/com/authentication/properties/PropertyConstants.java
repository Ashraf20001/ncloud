package com.authentication.properties;

/**
 * The Class PropertyConstants.
 */
public class PropertyConstants {
	
	
	/** The Constant MY_SQL_IP. */
	public static final String MY_SQL_IP = "[MAIN_APP_MYSQL_IP]";
	
	/** The Constant MY_SQL_PORT. */
	public static final String MY_SQL_PORT = "[MAIN_APP_MYSQL_PORT]";
	
	/** The Constant DB_NAME. */
	public static final String DB_NAME = "[DB_NAME]";
	
	/** The Constant MY_SQL_PASSWORD. */
	public static final String MY_SQL_PASSWORD = "mysql.password";
	
	/** The Constant MY_SQL_USERNAME. */
	public static final String MY_SQL_USERNAME = "mysql.username";
	
	/** The Constant MY_SQL_DRIVER. */
	public static final String MY_SQL_DRIVER="mysqlDriver";
	
	/** The Constant RECOVERY_PORTAL_URI. */
	public static final String RECOVERY_PORTAL_URI="recoveryPoratal.uri";
	
	/** The Constant MAX_TIME. */
	public static final String MAX_TIME = "max.time";
	
	/** The Constant MAX_ATTEMPT. */
	public static final String MAX_ATTEMPT = "max.attempt";
	
	/** The Constant SEND_EMAIL. */
	public static final String SEND_EMAIL = "common_send_email";
	
	/** The Constant DP_PATH. */
	public static final String DP_PATH = "digital-paper-url";
	
	/** The Constant GATEWAY_PATH. */
	public static final String GATEWAY_PATH = "gateway-path";
	
	/** The Constant SECRET_KEY. */
	public static final String SECRET_KEY = "secret.key";
}
