package com.authentication.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@ConfigurationProperties(prefix = "auth")
@Data
public class AuthPropertyValueProvider {

	private String mysqlDataSourceUrl;

	private String mysqlIp;

	private String mysqlPort;

	private String mysqlUsername;

	private String mysqlPassword;

	private String mysqlDataBase;

	private String mysqlDriver;
	
	private String recoveryPoratalUri;
	
	private String maxTime;
	
	private String maxAttempt;
	
	private String commonSendEmail;
	
	private String digitalPaperUrl;
	
	private String gatewayPath;
}
