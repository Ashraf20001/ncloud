package com.authentication.properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

/**
 * The Class AuthEnvironmentProperties.
 */
@Configuration
public class AuthEnvironmentProperties {
	
	
	/** The configuration properties. */
	@Autowired
	private AuthPropertyValueProvider configurationProperties;
	
	
	/**
	 * Gets the jdbc url.
	 *
	 * @return the jdbc url
	 */
	public String getJdbcUrl() {

		String url = configurationProperties.getMysqlDataSourceUrl();
		url = url.replace(PropertyConstants.MY_SQL_IP,configurationProperties.getMysqlIp().trim());
		url = url.replace(PropertyConstants.MY_SQL_PORT,configurationProperties.getMysqlPort().trim());
		url = url.replace(PropertyConstants.DB_NAME,configurationProperties.getMysqlDataBase().trim());
		return url;
		
	}
	
	
	/**
	 * Gets the my sql password.
	 *
	 * @return the my sql password
	 */
	public String getMySqlPassword() {
		return configurationProperties.getMysqlPassword();
	}
	
	
	/**
	 * Gets the mysql user name.
	 *
	 * @return the mysql user name
	 */
	public String getMysqlUserName() {
		return configurationProperties.getMysqlUsername();
	}
	
	/**
	 * Gets the mysql driver.
	 *
	 * @return the mysql driver
	 */
	public String getMysqlDriver() {
		return configurationProperties.getMysqlDriver();
	}
	
	/**
	 * Gets the recovery portal uri.
	 *
	 * @return the recovery portal uri
	 */
	public String getRecoveryPortalUri() {
		return configurationProperties.getRecoveryPoratalUri();
	}
	
	/**
	 * Gets the max time.
	 *
	 * @return the max time
	 */
	public Integer getMaxTime() {
		return Integer.parseInt(configurationProperties.getMaxTime());
	}
	
	/**
	 * Gets the max attempt.
	 *
	 * @return the max attempt
	 */
	public Integer getMaxAttempt() {
		return Integer.parseInt(configurationProperties.getMaxAttempt());
	}
	
	/**
	 * Gets the send emai.
	 *
	 * @return the send emai
	 */
	public String getSendEmai() {
		return configurationProperties.getCommonSendEmail();
	}
	
    /**
     * Gets the digital paper path.
     *
     * @return the digital paper path
     */
    public String getDigitalPaperPath() {
    	return configurationProperties.getDigitalPaperUrl();
    }
    
    /**
     * Gets the gateway path.
     *
     * @return the gateway path
     */
    public String getGatewayPath() {
    	return configurationProperties.getGatewayPath();
    }
	

}
