package com.authentication.security.jwt;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;

import com.authentication.model.UserDetailsImpl;
import com.common.constants.core.ApplicationConstants;
import com.common.transfer.object.dto.PlatformDetailsDto;
import com.common.transfer.object.dto.UserRoleDto;
import com.common.transfer.object.entity.Role;
import com.common.utils.core.ApplicationUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.UnsupportedJwtException;

/**
 * The Class JwtUtils.
 */
@SuppressWarnings("deprecation")
@Component
public class JwtUtils {
	
	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(JwtUtils.class);

	/**
	 * jwtSecret
	 */
	@Value("${recovery.app.jwtSecret}")
	private String jwtSecret;

	/**
	 * jwtExpirationMs
	 */
	@Value("${recovery.app.jwtExpirationMs}")
	private int jwtExpirationMs;
	

	/**
	 * @param authentication
	 * @param platformDetails
	 * @return
	 * @throws JsonProcessingException
	 */
	public String generateJwtToken(UserDetailsImpl userDetails, PlatformDetailsDto platformDetails)
			throws JsonProcessingException {

		Map<String, Object> claims = buildMapForUserInfo(userDetails, platformDetails);
		return Jwts.builder().setSubject((userDetails.getUsername())).addClaims(claims).setIssuedAt(new Date())
				.setExpiration(new Date((new Date()).getTime() + jwtExpirationMs))
				.signWith(SignatureAlgorithm.HS512, jwtSecret).compact();
	}
	

	/**
	 * @param userPrincipal
	 * @param platformDetails
	 * @return
	 * @throws JsonProcessingException
	 */
	private Map<String, Object> buildMapForUserInfo(UserDetailsImpl userPrincipal, PlatformDetailsDto platformDetails)
			throws JsonProcessingException {
		Map<String, Object> claims = new HashMap<>();
		claims.put(ApplicationConstants.ID, userPrincipal.getId());
		claims.put(ApplicationConstants.USER_NAME, userPrincipal.getUsername());
		claims.put(ApplicationConstants.EMAIL, userPrincipal.getEmail());
		claims.put(ApplicationConstants.USER_TYPE, userPrincipal.getUserTypeId());
		claims.put(ApplicationConstants.IDENTITY, userPrincipal.getIdentity());
		claims.put(ApplicationConstants.PLATFORM_DETAILS, platformDetails);
		claims.put(ApplicationConstants.ASSOCIATION_ID, userPrincipal.getAssociationId());
		if (ApplicationUtils.isValidId(userPrincipal.getCompanyId())) {
			claims.put(ApplicationConstants.COMPANY_ID, userPrincipal.getCompanyId());
			claims.put(ApplicationConstants.COMPANY_NAME, userPrincipal.getCompanyName());
		}

		Set<Role> roles = userPrincipal.getroles();
		List<Integer> poolId = (roles != null) ? roles.stream().map(x -> ApplicationUtils.isValidateObject(x.getAllocationUserType())
						? x.getAllocationUserType().getId()
						: null)
				.distinct().toList() : null;
		List<UserRoleDto> collect = (roles != null)
				? roles.stream()
						.filter(rle -> rle.getPlatformId().getPlatformId().equals(platformDetails.getPlatformId()))
						.map(x -> mapRoleToDto(x)).collect(Collectors.toList())
				: null;
		String json = new ObjectMapper().writeValueAsString(collect);
		claims.put(ApplicationConstants.ROLES, json);
		if (ApplicationUtils.isValidList(poolId)) {
			Integer validPoolId = poolId.stream().filter(pool->ApplicationUtils.isValidId(pool))
			               .findFirst().orElse(null);
			claims.put(ApplicationConstants.ALLOCATION_USER_TYPE, validPoolId);
		}
		return claims;
	}
	

	/**
	 * @param username
	 * @return
	 */
	public String generateTokenFromUsername(String username) {
		return Jwts.builder().setSubject(username).setIssuedAt(new Date())
				.setExpiration(new Date((new Date()).getTime() + jwtExpirationMs))
				.signWith(SignatureAlgorithm.HS512, jwtSecret).compact();
	}

	/**
	 * @param token
	 * @return
	 */
	public String getUserNameFromJwtToken(String token) {
		return Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(token).getBody().getSubject();
	}

	/**
	 * @param token
	 * @return
	 */
	public Claims getClaims(String token) {
		return Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(token).getBody();
	}

	/**
	 * @param authToken
	 * @return
	 */
	public boolean validateJwtToken(String authToken) {
		try {
			Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(authToken);
			return true;
		} catch (SignatureException e) {
			logger.error("Invalid JWT signature: {}", e.getMessage());
		} catch (MalformedJwtException e) {
			logger.error("Invalid JWT token: {}", e.getMessage());
		} catch (ExpiredJwtException e) {
			logger.error("JWT token is expired: {}", e.getMessage());
		} catch (UnsupportedJwtException e) {
			logger.error("JWT token is unsupported: {}", e.getMessage());
		} catch (IllegalArgumentException e) {
			logger.error("JWT claims string is empty: {}", e.getMessage());
		}

		return false;
	}

	/**
	 * Map role to dto.
	 *
	 * @param role the role
	 * @return the user role dto
	 */
	public UserRoleDto mapRoleToDto(Role role) {
		UserRoleDto dto = new UserRoleDto();
		dto.setAllocationUserType(
				ApplicationUtils.isValidateObject(role.getAllocationUserType()) ? role.getAllocationUserType().getId()
						: null);
		dto.setRoleId(role.getRoleId());
		dto.setRoleName(role.getName());
		return dto;
	}
	
	
	/**
	 * Sets the security context for jwt filter.
	 *
	 * @param request the request
	 * @param userDetails the user details
	 */
	public static void setSecurityContextForJwtFilter(HttpServletRequest request, UserDetails userDetails) {
		UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(userDetails, null,
				userDetails.getAuthorities());
		authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

		SecurityContextHolder.getContext().setAuthentication(authentication);
	}
	
}
