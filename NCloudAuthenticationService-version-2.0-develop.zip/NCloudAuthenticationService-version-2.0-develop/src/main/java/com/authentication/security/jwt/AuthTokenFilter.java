package com.authentication.security.jwt;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import com.authentication.service.impl.UserDetailsServiceImpl;
import com.common.constants.core.ApplicationConstants;


/**
 * The Class AuthTokenFilter.
 */
public class AuthTokenFilter extends OncePerRequestFilter {
	
	/** The jwt utils. */
	@Autowired
	private JwtUtils jwtUtils;

	/** The user details service. */
	@Autowired
	private UserDetailsServiceImpl userDetailsService;
	
	@Value("${auth.authentication.ldap}")
	private String isLdapAuthetication;


	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(AuthTokenFilter.class);

	/**
	 * Get UserName from Bearer Token and Validation occurs for that User's..
	 *
	 * @param request the request
	 * @param response the response
	 * @param filterChain the filter chain
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		try {
			String jwt = parseJwt(request);
			if (jwt != null && jwtUtils.validateJwtToken(jwt)) {
				String username = jwtUtils.getUserNameFromJwtToken(jwt);

				UserDetails userDetails = userDetailsService.loadUserByUsername(username);
				JwtUtils.setSecurityContextForJwtFilter(request, userDetails);

			}
		} catch (Exception e) {
			logger.error("Cannot set user authentication: {}", e);
		}

		filterChain.doFilter(request, response);
	}

	/**
	 * Parses the jwt.
	 *
	 * @param request the request
	 * @return the string
	 */
	private String parseJwt(HttpServletRequest request) {
		String headerAuth = request.getHeader("Authorization");

		if (StringUtils.hasText(headerAuth) && headerAuth.startsWith("Bearer ")) {
			return headerAuth.substring(7, headerAuth.length());
		}

		return null;
	}
	
}
