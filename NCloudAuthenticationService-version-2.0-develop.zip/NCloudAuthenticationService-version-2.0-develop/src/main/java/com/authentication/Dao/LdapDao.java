package com.authentication.Dao;

/**
 * The Interface LdapDao.
 */
import org.springframework.ldap.core.DirContextOperations;

public interface LdapDao {
		
		/**
		 * Reset password.
		 *
		 * @param username the username
		 * @param password the password
		 */
		public void resetPassword(String username, String password);

		DirContextOperations getDirObjectFromUserName(String username);
}
