package com.authentication.Dao;

import com.common.transfer.object.entity.UserCompanyMapping;

/**
 * The Interface AuthCommonDao.
 */
public interface AuthCommonDao {

	/**
	 * Gets the company by user id.
	 *
	 * @param userId the user id
	 * @return the company by user id
	 */
	UserCompanyMapping getCompanyByUserId(String userId);

	/**
	 * Gets the company by user.
	 *
	 * @param trim the trim
	 * @return the company by user
	 */
	UserCompanyMapping getCompanyByUser(String trim);

}
