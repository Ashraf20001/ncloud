package com.authentication.Dao.impl;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

import javax.naming.Name;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.core.DirContextOperations;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.support.LdapNameBuilder;
import org.springframework.stereotype.Repository;

import com.authentication.Dao.LdapDao;
import com.common.constants.core.ApplicationConstants;

/**
 * The Class LdapDaoImpl.
 */
@Repository
@Transactional
public class LdapDaoImpl implements LdapDao{

	/** The ldap template. */
	@Autowired
	private LdapTemplate ldapTemplate;
	
	/**
	 * Reset password.
	 *
	 * @param username the username
	 * @param password the password
	 */
	@Override
	public void resetPassword(String username, String password) {
		Name dn = ldapNameBuilder(username);

		DirContextOperations context = ldapTemplate.lookupContext(dn);
		context.setAttributeValue(ApplicationConstants.USER_PASSWORD, digestSSHA(password));
		ldapTemplate.modifyAttributes(dn, context.getModificationItems());
	}

	/**
	 * Digest SSHA.
	 *
	 * @param password the password
	 * @return the string
	 */
	private String digestSSHA(final String password) {
        String base64;
        try {
            // Generate a random salt
            SecureRandom random = new SecureRandom();
            byte[] salt = new byte[8];
            random.nextBytes(salt);

            // Combine password and salt
            byte[] combined = new byte[password.getBytes().length + salt.length];
            System.arraycopy(password.getBytes(), 0, combined, 0, password.getBytes().length);
            System.arraycopy(salt, 0, combined, password.getBytes().length, salt.length);

            // Hash the combined value using SHA-1
            MessageDigest digest = MessageDigest.getInstance("SHA-1");
            byte[] hashedBytes = digest.digest(combined);

            // Combine hashed value and salt
            byte[] hashedWithSalt = new byte[hashedBytes.length + salt.length];
            System.arraycopy(hashedBytes, 0, hashedWithSalt, 0, hashedBytes.length);
            System.arraycopy(salt, 0, hashedWithSalt, hashedBytes.length, salt.length);

            // Encode the combined value in Base64
            base64 = Base64.getEncoder().encodeToString(hashedWithSalt);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
        return ApplicationConstants.SSHA_ALGORITHM + base64;
    }
	
	/**
	 * Ldap name builder.
	 *
	 * @param username the username
	 * @return the name
	 */
	@Override
	public DirContextOperations getDirObjectFromUserName(String username) {
		Name dn = ldapNameBuilder(username);

		try {
			DirContextOperations context = ldapTemplate.lookupContext(dn);
			return context;
		} catch (Exception e) {
			return null;
		}
	}
	
	private Name ldapNameBuilder(String username) {
    	Name dn = LdapNameBuilder
    			.newInstance()
    			.add(ApplicationConstants.ORGANISATIONAL_UNIT,ApplicationConstants.SYSTEM_UNIT)
    			.add(ApplicationConstants.ORGANISATIONAL_UNIT, ApplicationConstants.USER_UNIT)
    			.add(ApplicationConstants.LDAP_COMMON_NAME, username)
    			.build();
    	return dn;
    }


}
