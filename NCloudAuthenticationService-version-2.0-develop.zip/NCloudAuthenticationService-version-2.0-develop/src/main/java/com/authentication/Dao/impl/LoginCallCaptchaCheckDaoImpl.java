package com.authentication.Dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Component;

import com.authentication.Dao.LoginCallCaptchaCheckDao;
import com.authentication.common.filters.BaseDao;
import com.common.constants.core.TableConstants;
import com.common.exception.core.ApplicationException;
import com.common.transfer.object.entity.LoginCallCaptchaCheck;

/**
 * The Class LoginCallCaptchaCheckDaoImpl.
 */
@Component
public class LoginCallCaptchaCheckDaoImpl extends BaseDao implements LoginCallCaptchaCheckDao {

	/**
	 * Save.
	 *
	 * @param getLoginCallWithIp the get login call with ip
	 * @throws ApplicationException the application exception
	 */
	public void save(LoginCallCaptchaCheck getLoginCallWithIp) throws ApplicationException {
		saveWithoutId(getLoginCallWithIp);
	}

	/**
	 * Update.
	 *
	 * @param getLoginCallAttempt the get login call attempt
	 * @param date the date
	 * @param ip the ip
	 */
	public void update(int getLoginCallAttempt, Date date, String ip) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaUpdate<LoginCallCaptchaCheck> criteria = builder.createCriteriaUpdate(LoginCallCaptchaCheck.class);
		Root<LoginCallCaptchaCheck> root = criteria.from(LoginCallCaptchaCheck.class);
		criteria.set(TableConstants.ATTEMPT, getLoginCallAttempt).set(TableConstants.TIME, date);

		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IP), ip)));
		criteria.where(predicates.toArray(new Predicate[predicates.size()]));
		Query query = getSession().createQuery(criteria);
		query.executeUpdate();
	}

	/**
	 * Gets the login call captcha check.
	 *
	 * @param minDate the min date
	 * @param ip the ip
	 * @return the login call captcha check
	 */
	@Override
	public LoginCallCaptchaCheck getLoginCallCaptchaCheck(Date minDate, String ip) {
		Date currentDate = new Date();
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<LoginCallCaptchaCheck> criteria = builder.createQuery(LoginCallCaptchaCheck.class);
		Root<LoginCallCaptchaCheck> root = criteria.from(LoginCallCaptchaCheck.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		Predicate date = builder.between(root.get(TableConstants.TIME), minDate, currentDate);
		predicates.add(date);
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IP), ip)));
		return (LoginCallCaptchaCheck) getSingleResult(createQuery(builder, criteria, root, predicates));

	}

	/**
	 * Gets the login call captcha by IP.
	 *
	 * @param ip the ip
	 * @return the login call captcha by IP
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<LoginCallCaptchaCheck> getLoginCallCaptchaByIP(String ip) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<LoginCallCaptchaCheck> criteria = builder.createQuery(LoginCallCaptchaCheck.class);
		Root<LoginCallCaptchaCheck> root = criteria.from(LoginCallCaptchaCheck.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.IP), ip)));
		return (List<LoginCallCaptchaCheck>) getResultList(createQuery(builder, criteria, root, predicates));

	}

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
	}

	/**
	 * Delete.
	 *
	 * @param loginCallCaptchaCheck the login call captcha check
	 * @throws ApplicationException the application exception
	 */
	public void delete(LoginCallCaptchaCheck loginCallCaptchaCheck) throws ApplicationException {
		delete(TableConstants.LOGIN_CAPTCHA_CHECK, loginCallCaptchaCheck);
	}

}
