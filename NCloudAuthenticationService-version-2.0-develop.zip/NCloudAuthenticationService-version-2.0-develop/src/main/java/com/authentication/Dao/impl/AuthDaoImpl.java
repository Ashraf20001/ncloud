package com.authentication.Dao.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.authentication.Dao.AuthDao;
import com.authentication.common.filters.BaseDao;
import com.common.constants.core.TableConstants;
import com.common.exception.core.ApplicationException;
import com.common.exception.core.ApplicationUnauthorizedException;
import com.common.transfer.object.core.RefreshToken;
import com.common.transfer.object.entity.ForgetPassword;
import com.common.transfer.object.entity.Platform;
import com.common.transfer.object.entity.Userprofile;

/**
 * The Class AuthDaoImpl.
 */
@Repository
@Transactional
public class AuthDaoImpl extends BaseDao implements AuthDao {
	
	/** The mapper. */
	@Autowired
	ModelMapper mapper;

	/**
	 * Createuser.
	 *
	 * @param userprofile the userprofile
	 * @return the userprofile
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Userprofile createuser(Userprofile userprofile) throws ApplicationException {
		save(userprofile, TableConstants.LOGIN_USER);
		return userprofile;
	}
	
	/**
	 * Verify username or email.
	 *
	 * @param userNameOrEmail the user name or email
	 * @param field the field
	 * @return the list
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Userprofile> verifyUsernameOrEmail(String userNameOrEmail,String field) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Userprofile> criteria = builder.createQuery(Userprofile.class);
		Root<Userprofile> root = criteria.from(Userprofile.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(field), userNameOrEmail)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), 0)));
		List<Userprofile> resultList = (List<Userprofile>)getResultList(createQuery(builder, criteria, root, predicates));
		return resultList;
	}

	/**
	 * Verify email.
	 *
	 * @param email the email
	 * @return true, if successful
	 */
	@Override
	public boolean verifyEmail(String email) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Userprofile> criteria = builder.createQuery(Userprofile.class);
		Root<Userprofile> root = criteria.from(Userprofile.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get("email"), email)));
		Userprofile singleResult = (Userprofile) getSingleResult(createQuery(builder, criteria, root, predicates));
		return !singleResult.getEmail().isEmpty();
	}
	


	/**
	 * Gets the logon user email.
	 *
	 * @param EmailId the email id
	 * @return the logon user email
	 */
	@Override
    public Userprofile getLogonUserEmail(String EmailId) {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<Userprofile> criteria = builder.createQuery(Userprofile.class);
        Root<Userprofile> root = criteria.from(Userprofile.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get("email"), EmailId)));
        predicates.add(builder.and(builder.equal(root.get("isDeleted"), 0)));
		predicates.add(builder.or(
				builder.greaterThan(root.get(TableConstants.EFFECTIVE_DATE), builder.literal(LocalDateTime.now())),
				builder.isNull(root.get(TableConstants.EFFECTIVE_DATE))));
        return (Userprofile) getSingleResult(createQuery(builder, criteria, root, predicates));

    }
	
	/**
	 * Gets the user details by user name.
	 *
	 * @param userName the user name
	 * @return the user details by user name
	 */
	@Override
	public Userprofile getUserDetailsByUserName(String userName) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Userprofile> criteria = builder.createQuery(Userprofile.class);
		Root<Userprofile> root = criteria.from(Userprofile.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get("username"), userName)));
		return (Userprofile) getSingleResult(createQuery(builder, criteria, root, predicates));
		
	}
	
	/**
	 * Gets the plat form details by client id.
	 *
	 * @param clientId the client id
	 * @return the plat form details by client id
	 */
	@Override
	public Platform getPlatFormDetailsByClientId(String clientId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Platform> criteria = builder.createQuery(Platform.class);
		Root<Platform> root = criteria.from(Platform.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get("clientId"), clientId)));
		return (Platform) getSingleResult(createQuery(builder, criteria, root, predicates));
		
	}

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {

	}
	
	/**
	 * Save forget entry.
	 *
	 * @param forgetEntity the forget entity
	 */
	public void saveForgetEntry(ForgetPassword forgetEntity) {
		try {
			save(forgetEntity, "forget_email");
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Gets the date by email id.
	 *
	 * @param today the today
	 * @param email the email
	 * @return the date by email id
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<ForgetPassword> getDateByEmailId(LocalDate today, String email){
		CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<ForgetPassword> criteria = builder.createQuery(ForgetPassword.class);
        Root<ForgetPassword> root = criteria.from(ForgetPassword.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get("createdAt"), today)));
        predicates.add(builder.and(builder.equal(root.get("emailId"), email)));
        return (List<ForgetPassword>) getResultList(createQuery(builder, criteria, root, predicates));
		
	}


	/**
	 * Find by username.
	 *
	 * @param username the username
	 * @param associationType the association type
	 * @return the userprofile
	 * @throws ApplicationUnauthorizedException the application unauthorized exception
	 */
	@Override
	public Userprofile findByUsername(String username, Integer associationType)
			throws ApplicationUnauthorizedException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Userprofile> criteria = builder.createQuery(Userprofile.class);
		Root<Userprofile> root = criteria.from(Userprofile.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.USERNAME), username)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), 0)));
		if (associationType!=null) {
			predicates.add(builder.and(builder.equal(root.get("associationUserType"), associationType)));
		}
		return (Userprofile) getSingleResult(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Gets the user profile by identity.
	 *
	 * @param id the id
	 * @return the user profile by identity
	 */
	@Override
	public Userprofile getUserProfileByIdentity(String id) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Userprofile> criteria = builder.createQuery(Userprofile.class);
		Root<Userprofile> root = criteria.from(Userprofile.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get("identity"), id)));
		Userprofile singleResult = (Userprofile) getSingleResult(createQuery(builder, criteria, root, predicates));
		return singleResult;
	}

	/**
	 * Update user profile.
	 *
	 * @param userprofile the userprofile
	 */
	@Override
	public void updateUserProfile(Userprofile userprofile) {
		
		update(userprofile);
	}

	/**
	 * Gets the user id from login table.
	 *
	 * @param identity the identity
	 * @return the user id from login table
	 */
	@Override
	public ForgetPassword getUserIdFromLoginTable(String identity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<ForgetPassword> criteria = builder.createQuery(ForgetPassword.class);
		Root<ForgetPassword> root = criteria.from(ForgetPassword.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get("identity"), identity)));
		ForgetPassword singleResult = (ForgetPassword) getSingleResult(createQuery(builder, criteria, root, predicates));
		return singleResult;
		
	}

	/**
	 * Gets the user from username.
	 *
	 * @param name the name
	 * @return the user from username
	 */
	@Override
	public Userprofile getUserFromUsername(String name) {
		
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<Userprofile> criteria = builder.createQuery(Userprofile.class);
		Root<Userprofile> root = criteria.from(Userprofile.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get("username"), name)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), 0)));
		return (Userprofile) getSingleResult(createQuery(builder, criteria, root, predicates));
		
	}

	/**
	 * Save refresh token.
	 *
	 * @param refreshToken the refresh token
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void saveRefreshToken(RefreshToken refreshToken) throws ApplicationException {
           save(refreshToken, TableConstants.REFRESH_TOKEN);
	
	}

	/**
	 * Find by token.
	 *
	 * @param requestRefreshToken the request refresh token
	 * @return the refresh token
	 */
	@Override
	public RefreshToken findByToken(String requestRefreshToken) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<RefreshToken> criteria = builder.createQuery(RefreshToken.class);
		Root<RefreshToken> root = criteria.from(RefreshToken.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get("token"), requestRefreshToken)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), 0)));
		return (RefreshToken) getSingleResult(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Delete token.
	 *
	 * @param token the token
	 */
	@Override
	public void deleteToken(RefreshToken token) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaUpdate<RefreshToken> criteria = builder.createCriteriaUpdate(RefreshToken.class);
		Root<RefreshToken> root = criteria.from(RefreshToken.class);
		criteria.set(root.get(TableConstants.ISDELETED), true);
		criteria.where(builder.equal(root.get(TableConstants.TOKEN), token.getToken()));
		createQueryupdate(criteria).executeUpdate();
	}

	/**
	 * Delete by user id.
	 *
	 * @param userId the user id
	 */
	@Override
	public void deleteByUserId(int userId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaUpdate<RefreshToken> criteria = builder.createCriteriaUpdate(RefreshToken.class);
		Root<RefreshToken> root = criteria.from(RefreshToken.class);
		criteria.set(root.get(TableConstants.ISDELETED), true);
		criteria.where(builder.equal(root.get(TableConstants.USER_TOKEN).get(TableConstants.ID),userId));
		createQueryupdate(criteria).executeUpdate();		
	}

}
