package com.authentication.Dao;

import java.util.Date;
import java.util.List;

import com.common.exception.core.ApplicationException;
import com.common.transfer.object.entity.LoginCallCaptchaCheck;


/**
 * The Interface LoginCallCaptchaCheckDao.
 */
public interface LoginCallCaptchaCheckDao {
	
	/**
	 * Save.
	 *
	 * @param getLoginCallWithIp the get login call with ip
	 * @throws ApplicationException the application exception
	 */
	public void save(LoginCallCaptchaCheck getLoginCallWithIp) throws ApplicationException;

	/**
	 * Delete.
	 *
	 * @param getLoginCallWithIp the get login call with ip
	 * @throws ApplicationException the application exception
	 */
	public void delete(LoginCallCaptchaCheck getLoginCallWithIp) throws ApplicationException;

	/**
	 * Update.
	 *
	 * @param getLoginCallAttempt the get login call attempt
	 * @param date the date
	 * @param ip the ip
	 */
	public void update(int getLoginCallAttempt, Date date, String ip);

	/**
	 * Gets the login call captcha check.
	 *
	 * @param minDate the min date
	 * @param ip the ip
	 * @return the login call captcha check
	 */
	public LoginCallCaptchaCheck getLoginCallCaptchaCheck(Date minDate, String ip);

	/**
	 * Gets the login call captcha by IP.
	 *
	 * @param ip the ip
	 * @return the login call captcha by IP
	 */
	List<LoginCallCaptchaCheck> getLoginCallCaptchaByIP(String ip);

}
