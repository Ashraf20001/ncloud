package com.authentication.Dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.authentication.Dao.AuthCommonDao;
import com.authentication.common.filters.BaseDao;
import com.common.constants.core.TableConstants;
import com.common.transfer.object.entity.UserCompanyMapping;

/**
 * The Class AuthCommonDaoImpl.
 */
@Repository
@Transactional
public class AuthCommonDaoImpl extends BaseDao implements AuthCommonDao  {

    /**
     * Gets the company by user id.
     *
     * @param userId the user id
     * @return the company by user id
     */
    @Override
    public UserCompanyMapping getCompanyByUserId(String userId) {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<UserCompanyMapping> criteria = builder.createQuery(UserCompanyMapping.class);
        Root<UserCompanyMapping> root = criteria.from(UserCompanyMapping.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.USER_ID).get(TableConstants.IDENTITY), userId)));
        return (UserCompanyMapping) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);
    }

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
		// TODO Auto-generated method stub
		
	}

    /**
     * Gets the company by user.
     *
     * @param userId the user id
     * @return the company by user
     */
    @Override
    public UserCompanyMapping getCompanyByUser(String userId) {
        CriteriaBuilder builder = getCriteriaBuilder();
        CriteriaQuery<UserCompanyMapping> criteria = builder.createQuery(UserCompanyMapping.class);
        Root<UserCompanyMapping> root = criteria.from(UserCompanyMapping.class);
        criteria.select(root);
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
        predicates.add(builder.and(builder.equal(root.get(TableConstants.USER_ID).get(TableConstants.ID), userId)));
        return (UserCompanyMapping) getResultList(createQuery(builder, criteria, root, predicates)).stream().findFirst().orElse(null);
    }

}
