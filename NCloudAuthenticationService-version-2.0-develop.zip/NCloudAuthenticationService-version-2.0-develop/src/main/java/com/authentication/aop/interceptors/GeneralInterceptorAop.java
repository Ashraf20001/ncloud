package com.authentication.aop.interceptors;

import java.lang.reflect.Field;
import java.time.LocalDateTime;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.ContentCachingRequestWrapper;

import com.authentication.aop.model.AuthAuditEntity;
import com.common.constants.core.ApplicationConstants;
import com.common.exception.core.ApplicationException;
import com.common.transfer.object.core.ApplicationResponse;
import com.common.utils.core.ApplicationUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;

/**
 * The Class GeneralInterceptorAop.
 */
@Aspect
@Component
@RequiredArgsConstructor
public class GeneralInterceptorAop {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(GeneralInterceptorAop.class);
	
	/**
	 * kafka
	 */
	private final KafkaTemplate<String, String> kafkaTemplate;
	
	/**
	 * ObjectMapper
	 */
	private final ObjectMapper objectMapper;
	
	

	/**
	 * AOP method for audit data.
	 * @param joinPoint
	 * @return
	 * @throws Throwable
	 */
	@Around("com.authentication.aop.interceptors.CommonAopAspects.auditAnnotation()")
	public Object audit(ProceedingJoinPoint joinPoint) throws Throwable {
		String userName=null;
		ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
		ContentCachingRequestWrapper wrapper = new ContentCachingRequestWrapper(attributes.getRequest());
		String requestURI = wrapper.getRequestURI();
		Object argumentObject = joinPoint.getArgs()[0];
		userName=getPayloadUserName(argumentObject);
		Object result = null;
		try {
			result=joinPoint.proceed();
			auditDataThroughKafka(joinPoint,result,requestURI,userName);
		}catch(Exception e) {
			result=e;
			auditDataThroughKafka(joinPoint,result,requestURI,userName);
			throw e;
		}
		return result;
	}
	
	
	
	
	/**
	 * @param argumentObject
	 * @return
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 * @throws NoSuchFieldException
	 * @throws SecurityException
	 */
	private String getPayloadUserName(Object argumentObject) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException {
		Class<? extends Object> objectClass = argumentObject.getClass();
		Field userNameField = objectClass.getDeclaredField(ApplicationConstants.LOGINDTO_USER);
		userNameField.setAccessible(true);
		Object value = userNameField.get(argumentObject);
		return (String)value;
	}




	/**
	 * @param result
	 * @param requestURI
	 * @param requestBody
	 * @param requestParam
	 * @param userId
	 * @throws JsonProcessingException 
	 */
	private void auditDataThroughKafka(ProceedingJoinPoint joinPoint,Object result, String requestURI,
			String userName) throws JsonProcessingException {
		AuthAuditEntity auditEntity=null;
		if(ApplicationUtils.isValidateObject(result)) {
			if(result instanceof ApplicationResponse) {
				ApplicationResponse obj=(ApplicationResponse)result;
				LOGGER.info("======> AOP Method {} executed and returned {} ",joinPoint.getSignature(),obj.getContent().toString());
				auditEntity=setAuditEntityData(obj.getContent(), requestURI, userName);
			}
			else if (result instanceof ApplicationException) {
				ApplicationException obj=(ApplicationException)result;
				LOGGER.info("======> AOP Method {} executed and returned {} ",joinPoint.getSignature(),obj.getLocalizedMessage());
				auditEntity=setAuditEntityData(obj.getLocalizedMessage(), requestURI,userName);
			}
			else if(result instanceof Exception) {
				Exception obj=(Exception) result;
				LOGGER.info("======> AOP Method {} executed and returned {} ",joinPoint.getSignature(),obj.getLocalizedMessage());
				auditEntity=setAuditEntityData(obj.getLocalizedMessage(), requestURI,userName);
			}
			else {
				LOGGER.info("======> AOP Method {} executed and returned {} ",joinPoint.getSignature(),result.toString());
				auditEntity=setAuditEntityData(result.toString(), requestURI, userName);
			}
			String auditedValueString = objectMapper.writeValueAsString(auditEntity);
			kafkaTemplate.send(ApplicationConstants.AUTH_KAFKA_TOPIC, auditedValueString);
		}
	}




	/**
	 * @param result
	 * @param requestURI
	 * @param userId
	 * @return
	 */
	private AuthAuditEntity  setAuditEntityData(Object result, String requestURI,
			String userName) {
		AuthAuditEntity auditEntity = new AuthAuditEntity();
		auditEntity.setAuditDate(LocalDateTime.now()).setRequestUrl(requestURI).setResponse(result.toString()).setUserName(userName);
		return auditEntity;
	}

	

}