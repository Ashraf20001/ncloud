package com.authentication.aop.interceptors;

import org.aspectj.lang.annotation.Pointcut;

/**
 * The Class CommonAopAspects.
 */
public class CommonAopAspects {
	
	/**
	 * Service log.
	 */
	@Pointcut("(execution(* com.authentication.*.*.*(..)) && !(within(com.authentication..*Dao*..*) || within(com.authentication..*Dao.impl*..*)))")
	public void serviceLog() {}
	
	/**
	 * Audit annotation.
	 */
	@Pointcut("@annotation(com.authentication.aop.annotation.Auditable)")
	public void auditAnnotation() {}
}