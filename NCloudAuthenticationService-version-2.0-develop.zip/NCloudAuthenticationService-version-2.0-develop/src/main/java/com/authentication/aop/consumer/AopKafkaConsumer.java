package com.authentication.aop.consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import com.authentication.aop.dao.AuditMongoRepository;
import com.authentication.aop.model.AuthAuditEntity;
import com.common.constants.core.ApplicationConstants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;

/**
 * The Class AopKafkaConsumer.
 */
@Component
@RequiredArgsConstructor
public class AopKafkaConsumer {
	
		/** The object mapper. */
		private final ObjectMapper objectMapper;
		
		/** The mongo repository. */
		private final AuditMongoRepository mongoRepository;
		
		/** The Constant LOGGER. */
		private static final Logger LOGGER = LoggerFactory.getLogger(AopKafkaConsumer.class);

		/**
		 * Gets the kafka audit details.
		 *
		 * @param obj the obj
		 * @param acknowledgment the acknowledgment
		 * @return the kafka audit details
		 * @throws JsonMappingException the json mapping exception
		 * @throws JsonProcessingException the json processing exception
		 */
		@KafkaListener(topics = ApplicationConstants.AUTH_KAFKA_TOPIC)
		public void getKafkaAuditDetails(String obj,Acknowledgment acknowledgment) throws JsonMappingException, JsonProcessingException {
			LOGGER.info("====> Drop of audit consumer received");
			acknowledgment.acknowledge();
			try {
				AuthAuditEntity auditData = objectMapper.readValue(obj, AuthAuditEntity.class);
				mongoRepository.save(auditData);
			} catch (Exception e) {
				LOGGER.error(e.getLocalizedMessage());
			}
		}
}