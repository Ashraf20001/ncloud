package com.authentication.model;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AccessTokenRequestDTO.
 */
@Data
@NoArgsConstructor
public class AccessTokenRequestDTO {
	
	/** The authorization code. */
	private String authorizationCode;
	
    /** The client id. */
    private String clientId;
    
    /** The client secret. */
    private String clientSecret;
    
    /** The redirect uri. */
    private String redirectUri;
    
    /** The grant type. */
    private String grantType;

}
