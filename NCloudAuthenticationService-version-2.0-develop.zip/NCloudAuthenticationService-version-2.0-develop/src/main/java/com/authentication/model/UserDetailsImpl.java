package com.authentication.model;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.common.transfer.object.entity.Role;
import com.common.transfer.object.entity.UserType;
import com.common.transfer.object.entity.Userprofile;
import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The Class UserDetailsImpl.
 */
public class UserDetailsImpl implements UserDetails {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The userid. */
	public static Integer userid;

	/** The name. */
	public static String name;

	/** The id. */
	private Integer id;

	/** The username. */
	private String username;

	/** The email. */
	private String email;

	/** The first time login. */
	private boolean firstTimeLogin;

	/** The user type id. */
	private UserType userTypeId;

	/** The identity. */
	private String identity;

	/** The role set. */
	private Set<Role> roleSet;

	/** The platform identity. */
	private String platformIdentity;

	/** The company id. */
	private Integer companyId;

	/** The company name. */
	private String companyName;

	/** The allocation user type id. */
	private Integer allocationUserTypeId;

	/** The association id. */
	private Integer associationId;
	
	/** The effective date. */
	private LocalDateTime effectiveDate;
	
	/** The status. */
	private Boolean status;
	
	/**
	 * Gets the association id.
	 *
	 * @return the association id
	 */
	public Integer getAssociationId() {
		return associationId;
	}

	/**
	 * Sets the association id.
	 *
	 * @param associationId the new association id
	 */
	public void setAssociationId(Integer associationId) {
		this.associationId = associationId;
	}

	/** The password. */
	@JsonIgnore
	private String password;

	/** The authorities. */
	private Collection<? extends GrantedAuthority> authorities;

	/**
	 * Instantiates a new user details impl.
	 *
	 * @param id the id
	 * @param username the username
	 * @param email the email
	 * @param password the password
	 * @param firstTimeLogin the first time login
	 * @param userTypeId the user type id
	 * @param identity the identity
	 * @param authorities the authorities
	 * @param roleset the roleset
	 * @param platformIdentity the platform identity
	 * @param companyId the company id
	 * @param companyName the company name
	 * @param allocationUserTypeId the allocation user type id
	 * @param associationId the association id
	 * @param effectiveDateTime the effective date time
	 * @param status the status
	 */
	public UserDetailsImpl(Integer id, String username, String email, String password, boolean firstTimeLogin,
			UserType userTypeId, String identity, Collection<? extends GrantedAuthority> authorities, Set<Role> roleset,
			String platformIdentity, Integer companyId, String companyName, Integer allocationUserTypeId,
			Integer associationId,LocalDateTime effectiveDateTime,Boolean status) {
		this.id = id;
		this.username = username;
		this.email = email;
		this.password = password;
		this.authorities = authorities;
		this.setFirstTimeLogin(firstTimeLogin);
		this.userTypeId = userTypeId;
		this.userid = id;
		this.name = username;
		this.identity = identity;
		this.roleSet = roleset;
		this.platformIdentity = platformIdentity;
		this.companyId = companyId;
		this.companyName = companyName;
		this.allocationUserTypeId = allocationUserTypeId;
		this.associationId = associationId;
		this.effectiveDate=effectiveDateTime;
		this.status = status;
	}

	/**
	 * Gets the allocation user type id.
	 *
	 * @return the allocation user type id
	 */
	public Integer getAllocationUserTypeId() {
		return allocationUserTypeId;
	}

	/**
	 * Sets the allocation user type id.
	 *
	 * @param allocationUserTypeId the new allocation user type id
	 */
	public void setAllocationUserTypeId(Integer allocationUserTypeId) {
		this.allocationUserTypeId = allocationUserTypeId;
	}

	/**
	 * Builds the.
	 *
	 * @param userprofile the userprofile
	 * @return the user details impl
	 */
	public static UserDetailsImpl build(Userprofile userprofile) {
		List<GrantedAuthority> authorities = userprofile.getRoles().stream()
				.map(role -> new SimpleGrantedAuthority(role.getName())).collect(Collectors.toList());

		return new UserDetailsImpl(userprofile.getId(), userprofile.getUsername(), userprofile.getEmail(),
				userprofile.getPassword(), userprofile.isFirstTimeLogin(), userprofile.getUserTypeId(),
				userprofile.getIdentity(), authorities, userprofile.getRoles(), null, null, null, null,
				userprofile.getAssociationId(),userprofile.getEffectiveDate(),userprofile.getStatus());
	}
	
	/**
	 * Builds the customer.
	 *
	 * @param customer the customer
	 * @return the user details impl
	 */
	public static UserDetailsImpl buildCustomer(CustomerDto customer) {

//		return new UserDetailsImpl(customer.getCustomerId(), customer.getUsername(), customer.getEmail(),
//				customer.getPassword(), customer.isFirstTimeLogin(), null, null, null,null, null,null, null, null);
		return new UserDetailsImpl(customer.getCustomerId(), customer.getUsername(),customer.getEmail(), customer.getPassword(), customer.getIsFirstTimeLogin(), null, customer.getIdentity(), null, null, null,
				customer.getCompanyId(), null, null, null,null,customer.getStatus());
	}

	/**
	 * Gets the authorities.
	 *
	 * @return the authorities
	 */
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return authorities;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	@Override
	public String getPassword() {
		return password;
	}
	
	
	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public Boolean getStatus() {
		return status;
	}

	/**
	 * Gets the username.
	 *
	 * @return the username
	 */
	@Override
	public String getUsername() {
		return username;
	}

	/**
	 * Gets the company id.
	 *
	 * @return the company id
	 */
	public Integer getCompanyId() {
		return companyId;
	}

	/**
	 * Checks if is account non expired.
	 *
	 * @return true, if is account non expired
	 */
	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	/**
	 * Checks if is account non locked.
	 *
	 * @return true, if is account non locked
	 */
	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	/**
	 * Checks if is credentials non expired.
	 *
	 * @return true, if is credentials non expired
	 */
	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	/**
	 * Checks if is enabled.
	 *
	 * @return true, if is enabled
	 */
	@Override
	public boolean isEnabled() {
		return true;
	}

	/**
	 * Equals.
	 *
	 * @param o the o
	 * @return true, if successful
	 */
	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		UserDetailsImpl user = (UserDetailsImpl) o;
		return Objects.equals(id, user.id);
	}

	/**
	 * Checks if is first time login.
	 *
	 * @return true, if is first time login
	 */
	public boolean isFirstTimeLogin() {
		return firstTimeLogin;
	}

	/**
	 * Sets the first time login.
	 *
	 * @param firstTimeLogin the new first time login
	 */
	public void setFirstTimeLogin(boolean firstTimeLogin) {
		this.firstTimeLogin = firstTimeLogin;
	}

	/**
	 * Gets the user type id.
	 *
	 * @return the user type id
	 */
	public UserType getUserTypeId() {
		return userTypeId;
	}

	/**
	 * Sets the user type id.
	 *
	 * @param userTypeId the new user type id
	 */
	public void setUserTypeId(UserType userTypeId) {
		this.userTypeId = userTypeId;
	}

	/**
	 * Gets the identity.
	 *
	 * @return the identity
	 */
	public String getIdentity() {
		return identity;
	}

	/**
	 * Sets the identity.
	 *
	 * @param identity the new identity
	 */
	public void setIdentity(String identity) {
		this.identity = identity;
	}

	/**
	 * Gets the roles.
	 *
	 * @return the roles
	 */
	public Set<Role> getroles() {
		return this.roleSet;
	}

	/**
	 * Gets the platform identity.
	 *
	 * @return the platform identity
	 */
	public String getPlatformIdentity() {
		return platformIdentity;
	}

	/**
	 * Sets the platform identity.
	 *
	 * @param platformIdentity the new platform identity
	 */
	public void setPlatformIdentity(String platformIdentity) {
		this.platformIdentity = platformIdentity;
	}

	/**
	 * Sets the company id.
	 *
	 * @param companyId the new company id
	 */
	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	/**
	 * Gets the company name.
	 *
	 * @return the company name
	 */
	public String getCompanyName() {
		return companyName;
	}

	/**
	 * Sets the company name.
	 *
	 * @param companyName the new company name
	 */
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	/**
	 * Gets the effective date.
	 *
	 * @return the effective date
	 */
	public LocalDateTime getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * Sets the effective date.
	 *
	 * @param effectiveDate the new effective date
	 */
	public void setEffectiveDate(LocalDateTime effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
}