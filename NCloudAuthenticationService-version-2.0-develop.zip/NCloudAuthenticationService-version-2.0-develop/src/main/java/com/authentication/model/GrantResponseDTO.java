package com.authentication.model;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class GrantResponseDTO.
 */
@Data
@NoArgsConstructor
public class GrantResponseDTO {
	
	/** The authorization code. */
	private String authorizationCode;
	
	/** The state. */
	private String state;
	
	/** The scope. */
	private String scope;

}
