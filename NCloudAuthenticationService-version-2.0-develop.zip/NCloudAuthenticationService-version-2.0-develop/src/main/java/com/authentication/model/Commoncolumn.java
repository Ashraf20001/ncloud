package com.authentication.model;


import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.MappedSuperclass;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class Commoncolumn.
 */
@Getter
@Setter
@MappedSuperclass
public class Commoncolumn {
	
	/** The identity. */
	@Column(name="identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public String identity;
	
	
	/** The is deleted. */
	@Column(name="is_deleted")
	public boolean isDeleted;
	
	
	
}
