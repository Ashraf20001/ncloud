package com.authentication.model;

import com.common.transfer.object.core.RefreshToken;
import com.common.transfer.object.dto.LoginDto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AccessTokenResponseDTO.
 */
@Data
@NoArgsConstructor
public class AccessTokenResponseDTO {
	
	/** The access token. */
	private String accessToken;
	
	/** The refresh token. */
	private RefreshToken refreshToken;
	
	/** The expires in. */
	private String expiresIn;
	
	/** The scope. */
	private String  scope;
	
	/** The token type. */
	private String tokenType;
	
	/** The login dto. */
	private LoginDto loginDto;

}
