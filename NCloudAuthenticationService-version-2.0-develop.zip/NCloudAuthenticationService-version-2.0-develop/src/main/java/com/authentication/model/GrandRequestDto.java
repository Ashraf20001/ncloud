package com.authentication.model;

import com.common.transfer.object.dto.LoginDto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class GrandRequestDto.
 */
@Data
@NoArgsConstructor
public class GrandRequestDto {
	
	/** The clinet api. */
	private String clinetApi;
	
	/** The clinet secret. */
	private String clinetSecret;
	
	/** The scope. */
	private String scope;
	
	/** The redirect uri. */
	private String redirectUri;
	
	/** The auth token uri. */
	private String authTokenUri;
	
	/** The response type. */
	private String responseType;
	
	/** The login dto. */
	private LoginDto loginDto;

}
