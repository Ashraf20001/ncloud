package com.authentication.controller;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.authentication.aop.annotation.Auditable;
import com.authentication.model.AccessTokenRequestDTO;
import com.authentication.model.GrandRequestDto;
import com.authentication.model.JwtResponse;
import com.authentication.model.UserDetailsImpl;
import com.authentication.security.jwt.JwtUtils;
import com.authentication.service.AuthService;
import com.common.config.base.controller.BaseController;
import com.common.constants.core.ApplicationConstants;
import com.common.constants.core.TableConstants;
import com.common.constants.enums.UserTypeEnum;
import com.common.crypto.core.TwoWayEncryption;
import com.common.exception.core.ApplicationException;
import com.common.exception.core.codes.ErrorCodes;
import com.common.transfer.object.core.ApplicationResponse;
import com.common.transfer.object.core.RefreshToken;
import com.common.transfer.object.core.TokenRefreshRequest;
import com.common.transfer.object.core.TokenRefreshResponse;
import com.common.transfer.object.dto.ForgetPasswordDto;
import com.common.transfer.object.dto.LoginDto;
import com.common.transfer.object.dto.ResetPasswordDto;
import com.common.transfer.object.dto.UserDto;
import com.fasterxml.jackson.core.JsonProcessingException;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * The Class AuthController.
 */
@RestController
@RequestMapping("/auth")
public class AuthController extends BaseController {


	/** The jwt utils. */
	@Autowired
	JwtUtils jwtUtils;

	/** The modelmapper. */
	@Autowired
	ModelMapper modelmapper;

	/** The authservice. */
	@Autowired
	private AuthService authservice;

	/** The two way encryption. */
	@Autowired
	TwoWayEncryption twoWayEncryption;
	
	/** The clinet api. */
	@Value("${spring.security.oauth2.client.registration.google.client-id}")
	private String clinetApi;
	
	/** The clinet secret. */
	@Value("${spring.security.oauth2.client.registration.google.client-secret}")
	private String clinetSecret;
	
	/** The scope. */
	@Value("${spring.security.oauth2.client.registration.google.scope}")
	private String scope;
	
	/** The redirect uri. */
	@Value("${spring.security.oauth2.client.registration.google.redirect-uri}")
	private String redirectUri;

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(AuthController.class);


	/**
	 * Authenticate and Validate the user using JWT token and platform details.
	 *
	 * @param loginDto {@link LoginDto} containing user credentials.
	 * @return ResponseEntity with JWT response if authentication is successful.
	 * @throws ApplicationException If authentication fails due to application logic.
	 * @throws JsonProcessingException If an error occurs while processing JSON.
	 */
	@ApiOperation(value = "User Authentication", 
	              notes = "Authenticates the user and returns a JWT token if valid credentials are provided.",
	              response = JwtResponse.class)
	@PostMapping("/signin")
	@Auditable
	public ResponseEntity<?> authenticateUser(
			@ApiParam(value = "LoginDto Request PayLoad", required = true) @RequestBody LoginDto loginDto)
			throws ApplicationException, JsonProcessingException {
		logger.info("Strating of AuthController authenticateUser()");
		try {
			if(!loginDto.getUserTypeDto().getUserTypeName().equals(UserTypeEnum.TRAFFIC_AUTHORITY.name()) && !loginDto.getUserTypeDto().getUserTypeName().equals(UserTypeEnum.CUSTOMER.name())) {				
				authservice.captchaCheck();
			}
			if(loginDto.getPlatformDetailsDto().getPlatformId().equals(3)) {
				GrandRequestDto grandRequestDto = new GrandRequestDto();
				grandRequestDto.setClinetApi(clinetApi);
				grandRequestDto.setClinetSecret(clinetSecret);
				grandRequestDto.setRedirectUri(redirectUri);	
				grandRequestDto.setScope(scope);
				grandRequestDto.setLoginDto(loginDto);
				generateAuthorizationCode(grandRequestDto, loginDto.getUsername());
			}
			JwtResponse response = authservice.authicateUser(loginDto);
			authservice.clearIp();
			System.out.println(Thread.currentThread().getStackTrace()[1].getMethodName());
			return ResponseEntity.ok(response);
		}
		catch(Exception e) {
			if(e instanceof com.common.exception.core.ApplicationException || 
				e instanceof org.springframework.security.authentication.BadCredentialsException) {
				throw e;
			}else if(e instanceof UsernameNotFoundException) {
				logger.error("--------- loadbyusername failed-------------");
				throw new ApplicationException(ErrorCodes.BAD_CREDINTIAL);
			}
			logger.error(e.getMessage());
		}
		return null;
	}
	
	
	
	/**
	 * Generates an authorization code for the given user.
	 *
	 * @param grandRequestDto {@link GrandRequestDto} containing authorization request details.
	 * @param userName The username for whom the authorization code is generated.
	 * @throws JsonProcessingException If an error occurs while processing JSON.
	 * @throws ApplicationException If an application-specific error occurs.
	 */
	@ApiOperation(value = "Generate Authorization Code",
	              notes = "Generates an authorization code based on the provided user details.",
	              response = Void.class)
	@PostMapping("/get-auth-code")
	public void generateAuthorizationCode(
			@ApiParam(value = "GrandRequestDto PayLoad Request", required = true) @RequestBody GrandRequestDto grandRequestDto,
			@ApiParam(value = "User Name", required = true) @RequestParam String userName)
			throws JsonProcessingException, ApplicationException {
		authservice.generateAuthorizationCode(grandRequestDto, userName);
	}
	
	
	/**
	 * Generates an authorization token using the provided access token request details.
	 *
	 * @param accessTokenRequestDTO {@link AccessTokenRequestDTO} containing token request details.
	 * @return {@link ResponseEntity} indicating success or failure.
	 * @throws JsonProcessingException If an error occurs while processing JSON.
	 * @throws ApplicationException If an application-specific error occurs.
	 */
	@ApiOperation(value = "Generate Authorization Token",
	              notes = "Generates an authorization token from an authentication provider.",
	              response = String.class)
	@PostMapping("/auth-ad-token")
	public void generateAuthorizationToken(
			@ApiParam(value = "AccessTokenRequestDto PayLoad Request", required = true) @RequestBody AccessTokenRequestDTO accessTokenRequestDTo)
			throws JsonProcessingException, ApplicationException {
		authservice.generateAccessTokenFromProvider(accessTokenRequestDTo, null, null);
	}

	
	/**
	 * Handles user creation (signup) process.
	 *
	 * @param userDto {@link UserDto} containing user details.
	 * @return {@link ResponseEntity<ApplicationResponse>} with created user data.
	 * @throws ApplicationException If an application-specific error occurs.
	 */
	@ApiOperation(value = "User Signup", 
	              notes = "Creates a new user account based on the provided details.", 
	              response = ApplicationResponse.class)
	@PostMapping("/signup")
	public ApplicationResponse userCreation(
			@ApiParam(value = "UserDto Request PayLoad", required = true) @RequestBody UserDto userDto)
			throws ApplicationException {
		logger.info("Strating of AuthController userCreation()");

		UserDto dto = authservice.createuser(userDto);
		return getApplicationResponse(dto);

	}

	
	/**
	 * Verifies if an email exists in the system.
	 *
	 * @param email The email address to verify.
	 * @return {@link ResponseEntity<ApplicationResponse>} indicating if the email exists.
	 */
	@ApiOperation(value = "Verify Email", 
	              notes = "Checks whether the given email is registered in the system.", 
	              response = ApplicationResponse.class)
	@GetMapping("/verifyemail")
	public ApplicationResponse verifyEmail(
			@ApiParam(value = "EmailAddress", required = true) @RequestParam("email") String email) {
		logger.info("Verifying the email to change password");
		boolean isEmailExists = false;
		try {
			isEmailExists = authservice.verifyEmail(email.trim());
		} catch (Exception e) {
			logger.error("email not found");
		}
		logger.info("email exists " + isEmailExists);
		return getApplicationResponse(isEmailExists);
	}


	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {

	}

	/**
	 * Resets the user's password.
	 *
	 * @param resetDto The request payload containing the email and new password.
	 * @return {@link ResponseEntity<ApplicationResponse>} indicating success or failure.
	 * @throws ApplicationException If any error occurs during password reset.
	 */
	@ApiOperation(value = "Reset Password", 
	              notes = "Allows users to reset their password using a valid reset token.", 
	              response = ApplicationResponse.class)
	@PutMapping("/resetpassword")
	public ApplicationResponse resetFirstTimePassword(
			@ApiParam(value = "ResetPasswordDto Request PayLoad", required = true) @RequestBody ResetPasswordDto resetDto)
			throws ApplicationException {
		logger.info("method in AuthController, resetFirstTimePassword() started");
		authservice.resetPassword(resetDto);
		return getApplicationResponse(ApplicationConstants.RESET_SUCCESS);

	}

	/**
	 * Updates the user's password.
	 *
	 * @param resetDto The request payload containing the old password and new password.
	 * @return {@link ResponseEntity<ApplicationResponse>} indicating success or failure.
	 * @throws ApplicationException If the update fails due to validation errors.
	 */
	@ApiOperation(value = "Update Password", 
	              notes = "Allows users to update their password by providing their current password.", 
	              response = ApplicationResponse.class)
	@PutMapping("/updatepassword")
	public ApplicationResponse updatePassword(
			@ApiParam(value = "ResetPasswordDto Request PayLoad", required = true) @RequestBody ResetPasswordDto resetDto)
			throws ApplicationException {
		logger.info("method in AuthController, updatePassword() started");

				String updatePassword = authservice.updatePassword(resetDto);
				return getApplicationResponse(updatePassword);
	}

	/**
	 * Handles the "Forget Password" functionality.
	 *
	 * @param forgetPasswordDto The DTO containing the user's email and user type.
	 * @param platformName The platform name from which the request is coming.
	 * @return ResponseEntity<ApplicationResponse> indicating success or failure.
	 * @throws ApplicationException if the email is not found or any validation fails.
	 */
	@ApiOperation(value = "Forget Password", 
	              notes = "Sends a password reset link to the user's email.",
	              response = ApplicationResponse.class)
	@PostMapping("/forgetPassword")
	public ApplicationResponse forgetPassword(
			@ApiParam(value = "ForgetPasswordDto Request PayLoad", required = true) @RequestBody ForgetPasswordDto forgetPasswordDto,
			@RequestParam String platformName) throws ApplicationException {
		logger.info("forget password method started");
		String returnValue = null;
		returnValue = authservice.checkEmailId(forgetPasswordDto.getEmailId().trim(), forgetPasswordDto.getUserType(),platformName);
		return getApplicationResponse(returnValue);
	}

	/**
	 * Refreshes the authentication token.
	 *
	 * @param request The refresh token request DTO.
	 * @return ResponseEntity<TokenRefreshResponse> with the new access token.
	 * @throws ApplicationException if the refresh token is expired or invalid.
	 */
	@ApiOperation(value = "Refresh Token", 
	              notes = "Generates a new access token using a valid refresh token.",
	              response = TokenRefreshResponse.class)
	@PostMapping("/refreshtoken")
	public TokenRefreshResponse refreshtoken(
			@ApiParam(value = "TokenRefreshRequest Request PayLoad", required = true) @RequestBody TokenRefreshRequest request)
			throws ApplicationException {
		logger.info("method in AuthController, refreshtoken() started");
		String requestRefreshToken = request.getRefreshToken();
		RefreshToken refreshToken=authservice.findByToken(requestRefreshToken);
		refreshToken=authservice.verifyExpiration(refreshToken);
		String jwt = jwtUtils.generateTokenFromUsername((refreshToken.getUser().getUsername()));
		TokenRefreshResponse tokenRefresh =new TokenRefreshResponse(jwt,refreshToken.getToken(),TableConstants.BEARER);


		return tokenRefresh;
	}
	  
  		
	/**
	 * Logs out the user by invalidating their session.
	 */
	@ApiOperation(value = "Sign Out", 
	              notes = "Logs out the currently authenticated user.")
	  @PostMapping("/signout")
	  public void logoutUser() {
	    logger.info("method in AuthController, logoutUser() started");
	    UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
	    int userId = userDetails.getId();
	    authservice.deleteByUserId(userId);
	  }

}
