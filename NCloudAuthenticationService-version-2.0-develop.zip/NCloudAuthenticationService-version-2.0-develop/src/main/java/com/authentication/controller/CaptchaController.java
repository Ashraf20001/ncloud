package com.authentication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.authentication.service.CaptchaService;
import com.common.config.base.controller.BaseController;
import com.common.exception.core.ApplicationException;
import com.common.transfer.object.core.ApplicationResponse;
import com.common.transfer.object.dto.ResultDto;
import com.common.transfer.object.dto.VerifyCaptchaDetailsDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
 

/**
 * The Class CaptchaController.
 */
@RestController
public class CaptchaController extends BaseController {
	
	/** The captcha serviceimpl. */
	@Autowired
	CaptchaService captchaServiceimpl;
	
	/**
	 * Generates a new Captcha.
	 *
	 * @return ResponseEntity<ApplicationResponse> with the generated Captcha.
	 * @throws Exception if an error occurs during Captcha generation.
	 */
	@ApiOperation(value = "Generate Captcha", 
	              notes = "Generates a new Captcha for user verification.",
	              response = ApplicationResponse.class)
	@PostMapping("/auth/generate-captcha")
	public ApplicationResponse getGenerateCaptcha() throws Exception {
		return getApplicationResponse(captchaServiceimpl.generateCaptcha());
	}
	
	/**
	 * Validates the provided Captcha.
	 *
	 * @param slideQuery The Captcha validation request details.
	 * @return ResponseEntity<ResultDto<?>> with the validation result.
	 * @throws Exception if an error occurs during validation.
	 */
	@ApiOperation(value = "Validate Captcha", 
	              notes = "Validates the user-provided Captcha.",
	              response = ResultDto.class)
	@PostMapping("/auth/validate-captcha")
	public ResultDto<?> validateCaptcha(
			@ApiParam(value = "VerifyCaptchaDetailDto PayLoad Request", required = true) @RequestBody VerifyCaptchaDetailsDto slideQuery)
			throws Exception {
		return captchaServiceimpl.vertifyCaptchaData(slideQuery);
	}
		
		
	

	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	@Override
	protected Class<?> getClassName() {
		return this.getClass();
	}

	/**
	 * Gets the vo.
	 *
	 * @param identity the identity
	 * @return the vo
	 * @throws ApplicationException the application exception
	 */
	@Override
	public Object getVo(String identity) throws ApplicationException {
		return null;
	}

	/**
	 * Register interceptor.
	 */
	@Override
	protected void registerInterceptor() {
		// TODO Auto-generated method stub

	}

}
