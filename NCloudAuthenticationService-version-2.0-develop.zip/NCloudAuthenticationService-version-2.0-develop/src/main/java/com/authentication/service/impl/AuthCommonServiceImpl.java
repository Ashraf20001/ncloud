package com.authentication.service.impl;

import java.util.List;

import javax.persistence.Converter;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.authentication.Dao.AuthCommonDao;
import com.authentication.model.UserDetailsImpl;
import com.authentication.service.AuthCommonService;
import com.common.exception.core.ApplicationException;
import com.common.exception.core.codes.ErrorCodes;
import com.common.transfer.object.dto.CompanyDto;
import com.common.transfer.object.dto.UserCompanyMappingDto;
import com.common.transfer.object.dto.UserDto;
import com.common.transfer.object.entity.UserCompanyMapping;
import com.common.transfer.object.entity.Userprofile;
import com.common.transfer.object.reportloss.entity.Company;
import com.common.utils.core.ApplicationUtils;

@Service
public class AuthCommonServiceImpl implements AuthCommonService {
	
	@Autowired
	private AuthCommonDao authCommonDao;
	
//	@Autowired
//	private ModelMapper modelMapper;
	
	private final ModelMapper modelMapper;

	@Autowired
	public AuthCommonServiceImpl(ModelMapper modelMapper) {
		this.modelMapper = modelMapper;
	}

    public UserCompanyMappingDto getCompanyByUserId(String userId) throws ApplicationException {
        if (!ApplicationUtils.isValidString(userId)){
            throw new ApplicationException(ErrorCodes.INVALID_IDENTITY);
        }
        if(hasAssociationPrivilage()){
            return null;
        }
        UserCompanyMapping userCompanyMapping = authCommonDao.getCompanyByUserId(userId.trim());

        if(!ApplicationUtils.isValidObject(userCompanyMapping)){
            throw new ApplicationException(ErrorCodes.INVALID_IDENTITY);
        }
        return convertUserCompanyMappingEntityIntoDto(userCompanyMapping);
    }
	
    private UserCompanyMappingDto convertUserCompanyMappingEntityIntoDto(UserCompanyMapping userCompanyMapping) {
    	if(userCompanyMapping!=null) {
        UserCompanyMappingDto userCompanyMappingDto = new UserCompanyMappingDto();
        userCompanyMappingDto.setUserCompanyMappingId(userCompanyMapping.getUserCompanyMappingId());
        userCompanyMappingDto.setUserId(convertUserIntoDto(userCompanyMapping.getUserId()));
        userCompanyMappingDto.setCompanyId(convertCompanyIntoDto(userCompanyMapping.getCompanyId()));
        return userCompanyMappingDto;
    	}
    	return null;
    }

    private CompanyDto convertCompanyIntoDto(Company companyId) {
        if(ApplicationUtils.isValidateObject(companyId)) {
            return modelMapper.map(companyId, CompanyDto.class);
        }
        return null;
    }

//    private UserDto convertUserIntoDto(Userprofile userId) {
//        if(ApplicationUtils.isValidateObject(userId)) {
//            return modelMapper.map(userId, UserDto.class);
//        }
//        return null;
//    }
    
    org.modelmapper.Converter<Userprofile, UserDto> userprofileToUserDtoConverter = context -> {
        Userprofile userId = context.getSource();
        UserDto userDto = new UserDto();
        // Perform mapping logic manually for each property in the Userprofile and set it in the UserDto
        userDto.setUsername(userId.getUsername());;
        // Set other properties as needed
        return userDto;
    };

   

    private UserDto convertUserIntoDto(Userprofile userId) {
        if(ApplicationUtils.isValidateObject(userId)) {
            modelMapper.addConverter(userprofileToUserDtoConverter);
        }
        return null;
    }
    
    public UserCompanyMappingDto getCompanyByUser(String userId) throws ApplicationException {
        if (!ApplicationUtils.isValidString(userId)){
            throw new ApplicationException(ErrorCodes.INVALID_IDENTITY);
        }
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
		List<String> roles = userDetails.getAuthorities().stream().map(GrantedAuthority::getAuthority).toList();

        UserCompanyMapping userCompanyMapping = authCommonDao.getCompanyByUser(userId.trim());
        if(!ApplicationUtils.isValidObject(userCompanyMapping)&&!hasAssociationPrivilage()){
            throw new ApplicationException(ErrorCodes.INVALID_IDENTITY);
        }
        return convertUserCompanyMappingEntityIntoDto(userCompanyMapping);
    }
	  
	  private boolean hasAssociationPrivilage() {
	        List<String> loginUserRoles = loginUserRoles();
	        if(loginUserRoles == null || loginUserRoles.isEmpty()) {
	            return false;
	        }
	        UserDetailsImpl userDetails = loginUserdetails();
	        if(ApplicationUtils.isValidateObject(userDetails.getUserTypeId())
	                && userDetails.getUserTypeId().getUserTypeId()==1){
	            return true;
	        }
	        return false;
	    }
	  
	    private List<String> loginUserRoles() {
	        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
	        UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
	        List<String> roles = userDetails.getAuthorities().stream().map(GrantedAuthority::getAuthority).toList();
	        return roles;
	    }
	    
	    public UserDetailsImpl loginUserdetails() {
	        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
	        UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
	        return userDetails;
	    }
}
