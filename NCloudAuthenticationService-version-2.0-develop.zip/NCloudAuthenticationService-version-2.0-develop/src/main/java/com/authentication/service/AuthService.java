package com.authentication.service;

import com.authentication.model.AccessTokenRequestDTO;
import com.authentication.model.GrandRequestDto;
import com.authentication.model.JwtResponse;
import com.common.exception.core.ApplicationException;
import com.common.transfer.object.core.RefreshToken;
import com.common.transfer.object.dto.LoginDto;
import com.common.transfer.object.dto.ResetPasswordDto;
import com.common.transfer.object.dto.UserDto;
import com.fasterxml.jackson.core.JsonProcessingException;



/**
 * The Interface AuthService.
 */
public interface AuthService {

	/**
	 * Createuser.
	 *
	 * @param userDto the user dto
	 * @return the user dto
	 * @throws ApplicationException the application exception
	 */
	public UserDto createuser(UserDto userDto) throws ApplicationException;

    /**
     * Verify email.
     *
     * @param email the email
     * @return true, if successful
     */
    boolean verifyEmail(String email);

    /**
     * Update password.
     *
     * @param resetDto the reset dto
     * @return the string
     * @throws ApplicationException the application exception
     */
    public String updatePassword(ResetPasswordDto resetDto) throws ApplicationException;
    
	/**
	 * Reset password.
	 *
	 * @param resetDto the reset dto
	 * @return the user dto
	 * @throws ApplicationException the application exception
	 */
	public UserDto resetPassword(ResetPasswordDto resetDto) throws ApplicationException;
	
	/**
	 * Check email id.
	 *
	 * @param EmailId the email id
	 * @param userTypeName the user type name
	 * @param platformName the platform name
	 * @return the string
	 * @throws ApplicationException the application exception
	 */
	public String checkEmailId(String EmailId, String userTypeName, String platformName) throws ApplicationException;
	
	/**
	 * Gets the user from identity.
	 *
	 * @param id the id
	 * @return the user from identity
	 */
	public UserDto getUserFromIdentity(String id);

	/**
	 * Creates the refresh token.
	 *
	 * @param id the id
	 * @return the refresh token
	 * @throws ApplicationException the application exception
	 */
	public RefreshToken createRefreshToken(String id) throws ApplicationException;

	/**
	 * Find by token.
	 *
	 * @param requestRefreshToken the request refresh token
	 * @return the refresh token
	 * @throws ApplicationException the application exception
	 */
	public RefreshToken findByToken(String requestRefreshToken) throws ApplicationException; 
	
	/**
	 * Verify expiration.
	 *
	 * @param token the token
	 * @return the refresh token
	 * @throws ApplicationException the application exception
	 */
	public RefreshToken verifyExpiration(RefreshToken token) throws ApplicationException;

	/**
	 * Delete by user id.
	 *
	 * @param userId the user id
	 */
	public void deleteByUserId(int userId); 
	
	/**
	 * Captcha check.
	 *
	 * @throws ApplicationException the application exception
	 */
	public void captchaCheck() throws ApplicationException;

	/**
	 * Authicate user.
	 *
	 * @param loginDto the login dto
	 * @return the jwt response
	 * @throws JsonProcessingException the json processing exception
	 * @throws ApplicationException the application exception
	 */
	public JwtResponse authicateUser(Object loginDto) throws JsonProcessingException, ApplicationException;
	
	/**
	 * @param grandRequestDto
	 * @param userName 
	 * @return 
	 * @throws ApplicationException 
	 * @throws JsonProcessingException 
	 */
	public AccessTokenRequestDTO generateAuthorizationCode(GrandRequestDto grandRequestDto, String userName) throws JsonProcessingException, ApplicationException;

	/**
	 * @param accessTokenRequestDTO
	 * @param loginDto
	 * @param identity
	 * @throws JsonProcessingException
	 * @throws ApplicationException
	 */
	void generateAccessTokenFromProvider(AccessTokenRequestDTO accessTokenRequestDTO, LoginDto loginDto,
			String identity) throws JsonProcessingException, ApplicationException;

	/**
	 * Clear ip.
	 */
	void clearIp(); 
}
