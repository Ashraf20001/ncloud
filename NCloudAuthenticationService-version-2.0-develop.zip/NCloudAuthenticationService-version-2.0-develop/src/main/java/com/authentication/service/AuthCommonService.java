package com.authentication.service;

import com.common.exception.core.ApplicationException;
import com.common.transfer.object.dto.UserCompanyMappingDto;

/**
 * The Interface AuthCommonService.
 */
public interface AuthCommonService {

	/**
	 * Gets the company by user id.
	 *
	 * @param userId the user id
	 * @return the company by user id
	 * @throws ApplicationException the application exception
	 */
	UserCompanyMappingDto getCompanyByUserId(String userId) throws ApplicationException;

}
