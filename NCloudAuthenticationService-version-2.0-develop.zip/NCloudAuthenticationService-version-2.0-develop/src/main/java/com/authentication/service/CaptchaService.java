package com.authentication.service;

import java.io.IOException;

import com.common.transfer.object.dto.CaptchaDto;
import com.common.transfer.object.dto.ResultDto;
import com.common.transfer.object.dto.VerifyCaptchaDetailsDto; 


public interface CaptchaService {
	CaptchaDto generateCaptcha() throws IOException;

	ResultDto vertifyCaptchaData(VerifyCaptchaDetailsDto  slideQuery) throws Exception;

}
