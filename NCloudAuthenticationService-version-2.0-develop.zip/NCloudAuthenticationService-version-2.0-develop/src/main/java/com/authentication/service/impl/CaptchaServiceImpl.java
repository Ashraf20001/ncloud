package com.authentication.service.impl;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.authentication.Dao.LoginCallCaptchaCheckDao;
import com.authentication.properties.AuthEnvironmentProperties;
import com.authentication.service.CaptchaService;
import com.authentication.utils.CaptchaUtils;
import com.common.constants.enums.ResultCodeEnum;
import com.common.crypto.core.TwoWayEncryption;
import com.common.exception.core.ApplicationException;
import com.common.transfer.object.dto.CaptchaDataDto;
import com.common.transfer.object.dto.CaptchaDto;
import com.common.transfer.object.dto.ResultDto;
import com.common.transfer.object.dto.VerifyCaptchaDetailsDto;
import com.common.transfer.object.entity.LoginCallCaptchaCheck;
import com.common.utils.core.ApplicationUtils;



/**
 * The Class CaptchaServiceImpl.
 */
@Service
@Transactional
public class CaptchaServiceImpl implements CaptchaService {

	/** The Constant VERIFICATION_ERROR. */
	private static final String VERIFICATION_ERROR = "Verification failed. Please try again";
	
	/** The Constant EMPTY_X_WIDTH. */
	private static final String EMPTY_X_WIDTH = "";
	
	/** The login call captcha check dao. */
	@Autowired
	private LoginCallCaptchaCheckDao loginCallCaptchaCheckDao;
	
	/** The environmentproperties. */
	@Autowired
	AuthEnvironmentProperties environmentproperties;
	
	/** The two way encryption. */
	@Autowired
	TwoWayEncryption twoWayEncryption;
	
	/** The Constant logger. */
	private static final Logger logger= LoggerFactory.getLogger(CaptchaServiceImpl.class); 
	
	/**
	 * Generate captcha.
	 *
	 * @return the captcha dto
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	public CaptchaDto generateCaptcha() throws IOException {
		CaptchaDataDto captchaData = CaptchaUtils.generateCaptchaImage();
		CaptchaDto captchaDto = new CaptchaDto();
		captchaDto.setCaptcha(captchaData.getCaptcha());
		captchaDto.setCaptchaValue(captchaData.getCaptchaValue());
		String encryptedXWidth = twoWayEncryption.doEncryption(
				ApplicationUtils.isNotBlank(captchaData.getCaptchaValue()) ? captchaData.getCaptchaValue().trim()
						: EMPTY_X_WIDTH);
		captchaDto.setCompareCaptchaDataValue(encryptedXWidth);
		return captchaDto;
	}
     
     /**
      * Vertify captcha data.
      *
      * @param slideQuery the slide query
      * @return the result dto
      * @throws Exception the exception
      */
     @Override
	public ResultDto vertifyCaptchaData(@RequestBody VerifyCaptchaDetailsDto slideQuery) throws Exception {
 		String generatedCaptchaValue = twoWayEncryption.doDecryption(slideQuery.getCompareCaptchaDataValue());
		String userCaptchaValue = slideQuery.getCaptchaValue();
		if (ApplicationUtils.isBlank(generatedCaptchaValue) || ApplicationUtils.isBlank(userCaptchaValue)) {
			return ResultDto.failure(ResultCodeEnum.PARAMS_MISS);
		} else if (generatedCaptchaValue.trim().equals(userCaptchaValue.trim())) {
			clearByIp();
			return ResultDto.success();
		} else {
			return ResultDto.failure(ResultCodeEnum.FAILD, VERIFICATION_ERROR);
		}
	}
	
	/**
	 * Clear by ip.
	 */
	private void clearByIp() {

		String ip = "";
          try {
		InetAddress myip = InetAddress.getLocalHost();
		 ip = myip.getHostAddress();
          }catch(UnknownHostException e){
        	  logger.error(e.getMessage());
        	  }
          List<LoginCallCaptchaCheck> getLoginCallAttemptList = loginCallCaptchaCheckDao.getLoginCallCaptchaByIP(ip);
			try {
				for(LoginCallCaptchaCheck loginCallCaptchaCheck: getLoginCallAttemptList){
					loginCallCaptchaCheckDao.delete(loginCallCaptchaCheck);
				}
			} catch (ApplicationException e) {
				System.out.println(e.getMessage());
			}
		

		}		
	

}
