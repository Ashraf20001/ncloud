package com.authentication.service.impl;

import org.slf4j.Logger; 
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.authentication.Dao.impl.AuthDaoImpl;
import com.authentication.model.CustomerDto;
import com.authentication.model.UserDetailsImpl;
import com.authentication.properties.AuthEnvironmentProperties;
import com.common.exception.core.ApplicationUnauthorizedException;
import com.common.transfer.object.entity.Userprofile;
import com.common.utils.core.ApplicationUtils;

 
/**
 * The Class UserDetailsServiceImpl.
 */
@Service
public class UserDetailsServiceImpl implements UserDetailsService {
	
	/** The Constant splitBy. */
	private static final String splitBy = "@#SPLIT#@";
	
	/** The Constant NO_USER_TYPE. */
	private static final String NO_USER_TYPE = "NO_USER_TYPE";
	
	/** The Constant get_customer_url. */
	private static final String get_customer_url = "/digital-paper/get-customer/";
	
	/** The Constant CUSTOMER. */
	private static final String CUSTOMER = "CUSTOMER";
	
	/** The Constant TRAFFIC_AUTHORITY. */
	private static final String TRAFFIC_AUTHORITY = "TRAFFIC_AUTHORITY";
	
	/** The auth dao impl. */
	@Autowired
	AuthDaoImpl authDaoImpl;
	
	/** The environment properties. */
	@Autowired
	private AuthEnvironmentProperties environmentProperties;
	
	/** The rest template. */
	@Autowired
	private RestTemplate restTemplate;
	
	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(UserDetailsServiceImpl.class);

	/**
	 * Load user by username.
	 *
	 * @param username the username
	 * @return the user details
	 * @throws UsernameNotFoundException the username not found exception
	 */
	@Override
	@Transactional
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Userprofile user = null;
		CustomerDto customerDto = null;
		String[] splitUsername = username.split(splitBy);
		try {
			if (splitUsername[1].equals(NO_USER_TYPE)) {
				if (!ApplicationUtils.isValidateObject(user)) {
					throw new UsernameNotFoundException("User not found in the database.");
				}
			}else if(splitUsername[1].equals(CUSTOMER)){
				customerDto = getCustomerDto(splitUsername[0]);
				if (!ApplicationUtils.isValidateObject(customerDto)) {
					throw new UsernameNotFoundException("User not found in the database.");
				}
			}else if(splitUsername[1].equals(TRAFFIC_AUTHORITY)){
				user = authDaoImpl.findByUsername(splitUsername[0],2);
				if (!ApplicationUtils.isValidateObject(user)) {
					throw new UsernameNotFoundException("User not found in the database.");
				}
			}
			else {
				user = authDaoImpl.findByUsername(splitUsername[0],null);
				if (!ApplicationUtils.isValidateObject(user)) {
					throw new UsernameNotFoundException("User not found in the database.");
				}
			}
			
		} catch (ApplicationUnauthorizedException e) {
			logger.error(e.getMessage());
			logger.error("User not found in the database.");
			throw new UsernameNotFoundException("User not found in the database.");
		}
		if (splitUsername[1].equals(CUSTOMER)) {
			return UserDetailsImpl.buildCustomer(customerDto);
		}else if(splitUsername[1].equals(NO_USER_TYPE)) {
			return UserDetailsImpl.build(user);
		}
		else {
			return UserDetailsImpl.build(user);
		}
			
		}

		/**
		 * Gets the customer dto.
		 *
		 * @param username the username
		 * @return the customer dto
		 */
		public CustomerDto getCustomerDto(String username) {
			String digitalPaperPath = environmentProperties.getDigitalPaperPath();
			ResponseEntity<CustomerDto> forEntity = restTemplate.getForEntity(digitalPaperPath+get_customer_url+username, CustomerDto.class);
			return forEntity.getBody();
		}
}