package com.authentication.service.impl;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.ldap.core.DirContextOperations;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.authentication.Dao.AuthDao;
import com.authentication.Dao.LdapDao;
import com.authentication.Dao.LoginCallCaptchaCheckDao;
import com.authentication.model.AccessTokenRequestDTO;
import com.authentication.model.AccessTokenResponseDTO;
import com.authentication.model.GrandRequestDto;
import com.authentication.model.GrantResponseDTO;
import com.authentication.model.JwtResponse;
import com.authentication.model.MailResponse;
import com.authentication.model.ResetPasswordRequest;
import com.authentication.model.UserDetailsImpl;
import com.authentication.properties.AuthEnvironmentProperties;
import com.authentication.security.jwt.JwtUtils;
import com.authentication.service.AuthService;
import com.authentication.utils.RestTemplateUtils;
import com.authentication.utils.UserDetailsUtils;
import com.common.constants.core.ApplicationConstants;
import com.common.crypto.core.TwoWayEncryption;
import com.common.exception.core.ApplicationException;
import com.common.exception.core.codes.ErrorCodes;
import com.common.transfer.object.core.RefreshToken;
import com.common.transfer.object.dto.LoginDto;
import com.common.transfer.object.dto.ResetPasswordDto;
import com.common.transfer.object.dto.UserCompanyMappingDto;
import com.common.transfer.object.dto.UserDto;
import com.common.transfer.object.entity.ForgetPassword;
import com.common.transfer.object.entity.LoginCallCaptchaCheck;
import com.common.transfer.object.entity.Role;
import com.common.transfer.object.entity.Userprofile;
import com.common.utils.core.ApplicationUtils;
import com.fasterxml.jackson.core.JsonProcessingException;

/**
 * The Class AuthServiceImpl.
 */
@Service
@Transactional
public class AuthServiceImpl implements AuthService {
	
	/** The authdao. */
	@Autowired
	AuthDao authdao;
	
	/** The authentication manager. */
	@Autowired
	@Qualifier("databaseAuthentication")
	AuthenticationManager databaseAuthenticationManager;
	
	@Autowired
	@Qualifier("ldapAuthentication")
	AuthenticationManager ldapAuthenticationManager;
	

	/** The password encoder. */
	@Autowired
	private PasswordEncoder passwordEncoder;

	/** The login call captcha check dao. */
	@Autowired
	private LoginCallCaptchaCheckDao loginCallCaptchaCheckDao;

	/** The environmentproperties. */
	@Autowired
	AuthEnvironmentProperties environmentproperties;

	/** The refresh token duration ms. */
	@Value("${jwtRefreshExpirationMs}")
	private Long refreshTokenDurationMs;

	/** The mapper. */
	@Autowired
	ModelMapper mapper;

	/** The encrypt. */
	@Autowired
	private TwoWayEncryption encrypt;

	/** The common send email. */
	@Value("${auth.common-send-email}")
	private String commonSendEmail;

	/**
	 * RestTemplateUtils
	 */
	@Autowired
	private RestTemplateUtils restTemplateUtils;

	/** The auth environment properties. */
	@Autowired
	private AuthEnvironmentProperties authEnvironmentProperties;
	
	/** The jwt utils. */
	@Autowired
	JwtUtils jwtUtils;

	/** The user details utils. */
	@Autowired
	private UserDetailsUtils userDetailsUtils;
	
	/** The ldap user details service impl. */
	@Autowired
	private UserDetailsServiceImpl userDetailsServiceImpl;
	
	/** The ldap repository. */
	@Autowired
	private LdapDao ldapDao;


	/** The Constant splitBy. */
	private static final String splitBy = "@#SPLIT#@";
	
	/** The Constant NO_USER_TYPE. */
	private static final String NO_USER_TYPE = "NO_USER_TYPE";

	/**
	 * RestTemplate
	 */
	@Autowired
	private RestTemplate restTemplate;

	/** The Constant Subject. */
	private static final String Subject = "Reset Password";
	
	/** The Constant expireInMinute. */
	private static final int expireInMinute = 10;

	/** The url. */
	@Value("${auth.forgetPassword-url}")
	private String url;
	
	/** the recovery url. */
	@Value("${auth.forgetPassword-recovery-url}")
	private String recoveryUrl;
	
	/** The traffic url. */
	@Value("${auth.forgetPassword-traffic-url}")
	private String trafficUrl;
	
	/** The data lake url. */
	@Value("${auth.forgetPassword-datalake-url}")
	private String dataLakeUrl;
	
	/** The is ldap authetication. */
	@Value("${auth.authentication.ldap}")
	private String isLdapAuthetication;

	
	/** The Constant logger. */
	private static final Logger logger= LoggerFactory.getLogger(AuthServiceImpl.class);  
	
	/**
	 * Verify email.
	 *
	 * @param email the email
	 * @return true, if successful
	 */
	@Override
	public boolean verifyEmail(String email) {
		return authdao.verifyEmail(email);
	}

	/**
	 * Update password.
	 *
	 * @param resetDto the reset dto
	 * @return the string
	 * @throws ApplicationException the application exception
	 */
	@Override
	public String updatePassword(ResetPasswordDto resetDto) throws ApplicationException {
		ForgetPassword userFromFogotTable = authdao.getUserIdFromLoginTable(resetDto.getIdentity());
		Date expireTime = userFromFogotTable.getExpiriTime();
		Calendar currentTime = Calendar.getInstance();
		Date time = currentTime.getTime();
		boolean before = time.before(expireTime);
		// Password Validation
		Pattern pattern = Pattern.compile(ApplicationConstants.PASSWORD_PATTERN_REGX);
		if ((!ApplicationUtils.isValidString(resetDto.getNewPassword())
				|| !(pattern.matcher(resetDto.getNewPassword()).matches()))) {
			throw new ApplicationException(ErrorCodes.INVALID_PASSWORD_ID);
		}
		if (!resetDto.getNewPassword().equals(resetDto.getConfirmPassword())) {
			throw new ApplicationException(ErrorCodes.PWD_MISSMATCH);
		}
		if (!before) {
			throw new ApplicationException(ErrorCodes.LINK_EXPIRED);
		}
		Userprofile existingUserProfile = authdao.getUserProfileByIdentity(userFromFogotTable.getUserProfileIdentity());

		if (existingUserProfile != null) {

			existingUserProfile.setPassword(passwordEncoder.encode(resetDto.getNewPassword()));
			authdao.updateUserProfile(existingUserProfile);
			mapper.map(existingUserProfile, UserDto.class);
		}

		return ApplicationConstants.UPDATE_SUCCESS;
	}

	/**
	 * Createuser.
	 *
	 * @param userDto the user dto
	 * @return the user dto
	 * @throws ApplicationException the application exception
	 */
	@Override
	public UserDto createuser(UserDto userDto) throws ApplicationException {
		List<Userprofile> verifyUsername = authdao.verifyUsernameOrEmail(userDto.getUsername(), "username");
		if (verifyUsername.size() != 0) {
			throw new ApplicationException(ErrorCodes.USERNAME_EXIST);
		}
		List<Userprofile> verifyEmail = authdao.verifyUsernameOrEmail(userDto.getEmail(), "email");
		if (verifyEmail.size() != 0) {
			throw new ApplicationException(ErrorCodes.EMAIL_EXIST);
		}
		// Password Validation
		Pattern pattern = Pattern.compile(ApplicationConstants.PASSWORD_PATTERN_REGX);
		if ((!ApplicationUtils.isValidString(userDto.getPassword())
				|| !(pattern.matcher(userDto.getPassword()).matches()))) {
			throw new ApplicationException(ErrorCodes.INVALID_PASSWORD_ID);
		}
		String encrypted = "";
		encrypted = passwordEncoder.encode(userDto.getPassword());
		userDto.setPassword(encrypted);
		Userprofile userprofile = mapper.map(userDto, Userprofile.class);
		Userprofile user = authdao.createuser(userprofile);
		UserDto dto = mapper.map(user, UserDto.class);

		return dto;
	}

	/**
	 * Reset password.
	 *
	 * @param resetDto the reset dto
	 * @return the user dto
	 * @throws ApplicationException the application exception
	 */
	@Override
	public UserDto resetPassword(ResetPasswordDto resetDto) throws ApplicationException {
		UserDto map = null;
		String identity = resetDto.getIdentity();
		UserDto user = getUserFromIdentity(identity);
		// Password Validation
		Pattern pattern = Pattern.compile(ApplicationConstants.PASSWORD_PATTERN_REGX);
		if ((!ApplicationUtils.isValidString(resetDto.getNewPassword())
				|| !(pattern.matcher(resetDto.getNewPassword()).matches()))) {
			throw new ApplicationException(ErrorCodes.INVALID_PASSWORD_ID);
		}

		// Validating with old password
		String encryptedPassword = user.getPassword();

		if (passwordEncoder.matches(resetDto.getNewPassword(), encryptedPassword)) {
			throw new ApplicationException(ErrorCodes.OLD_NEW_PASSWORD_ERR);
		}

		String encodedPAssword = passwordEncoder.encode(resetDto.getNewPassword());
		if (resetDto != null && resetDto.getNewPassword().equals(resetDto.getConfirmPassword())
				&& user.isFirstTimeLogin()) {
			Userprofile existingUserProfile = authdao.getUserProfileByIdentity(resetDto.getIdentity());

			if (existingUserProfile.getPassword().equals(encodedPAssword)) {
				throw new ApplicationException(ErrorCodes.OLD_NEW_PASSWORD_ERR);
			}

			if (existingUserProfile != null) {

				existingUserProfile.setPassword(encodedPAssword);
				existingUserProfile.setFirstTimeLogin(false);
				authdao.updateUserProfile(existingUserProfile);
				map = mapper.map(existingUserProfile, UserDto.class);
			}
		}
		if (map == null) {
			throw new ApplicationException(ErrorCodes.PWDFAILED);
		}
		return map;
	}

	/**
	 * Check email id.
	 *
	 * @param emailId the email id
	 * @param userTypeName the user type name
	 * @param platformName the platform name
	 * @return the string
	 * @throws ApplicationException the application exception
	 */
	public String checkEmailId(String emailId, String userTypeName,String platformName) throws ApplicationException {
		LocalDate today = LocalDate.now();
		List<ForgetPassword> forgetLists = new ArrayList<ForgetPassword>();
		String decryptEmailId = null;
		if (ApplicationUtils.isValidString(emailId)) {
			decryptEmailId = encrypt.doDecryption(emailId);
		}
		forgetLists = authdao.getDateByEmailId(today,decryptEmailId);
		if (forgetLists.size() < 3) {
			 Userprofile userProfileData = authdao.getLogonUserEmail(decryptEmailId);
			 if(validateObject(userProfileData)) {
				 
					ForgetPassword forgetEntry = new ForgetPassword();
					Calendar generatedDate = Calendar.getInstance();
					generatedDate.add(Calendar.MINUTE, expireInMinute);
					 Date dateOne = generatedDate.getTime();
					 forgetEntry.setExpiriTime(dateOne);
					forgetEntry.setEmailId(decryptEmailId);
			
					forgetEntry.setUserProfileIdentity(userProfileData.getIdentity());
					forgetEntry.setCreatedAt(today);
					forgetEntry.setUserProfile(userProfileData);
					authdao.saveForgetEntry(forgetEntry);
					List<ForgetPassword> dateByEmailId = authdao.getDateByEmailId(today,decryptEmailId);
					ForgetPassword	forgetPassword = dateByEmailId.get(dateByEmailId.size()-1);
					 String encryptUsername= encrypt.doEncryption(userProfileData.getUsername());
					 String forgetPasswordIdentity = forgetPassword.getIdentity();
					 ResetPasswordRequest resetPasswordRequest = new ResetPasswordRequest();
					 String decryptName = ApplicationConstants.EMPTY_STRING;
					 if(ApplicationUtils.isValidString(userTypeName)) {
						decryptName = encrypt.doDecryption(userTypeName);
					 }
					 resetPasswordRequest.setName(userProfileData.getUsername());
					 if(decryptName.equals(ApplicationConstants.TRAFFIC_AUTHORITY_)) {
						 String trafficAuthorityUrl =trafficUrl;
						 resetPasswordRequest.setSubject(Subject);
						 resetPasswordRequest.setTemplate(trafficAuthorityUrl+"/"+forgetPasswordIdentity +"/"+encryptUsername );
						 resetPasswordRequest.setTo(emailId);
						 getEmailFromAuth(resetPasswordRequest);
				} else {
					resetPasswordRequest.setSubject(Subject);
					if (platformName.equals(ApplicationConstants.DATALAKE)) {
						resetPasswordRequest.setTemplate(
								  dataLakeUrl + ApplicationConstants.SLASH + forgetPasswordIdentity + ApplicationConstants.SLASH + encryptUsername);
					} else if (platformName.equals(ApplicationConstants.DIGITAL_CERTIFICATE)) {
						resetPasswordRequest.setTemplate(
								  url + ApplicationConstants.SLASH + forgetPasswordIdentity + ApplicationConstants.SLASH + encryptUsername);
					}else {
						resetPasswordRequest.setTemplate(
								recoveryUrl + ApplicationConstants.SLASH + forgetPasswordIdentity + ApplicationConstants.SLASH + encryptUsername);
					}
					resetPasswordRequest.setTo(decryptEmailId);
					getEmailFromAuth(resetPasswordRequest);
				}

			} else {
				throw new ApplicationException(ErrorCodes.INVALIDEMAIL);
			}
		} else {
			throw new ApplicationException(ErrorCodes.FORGETPWDLIMIT);
		}

		return ApplicationConstants.valid;

	}

	/**
	 * Validate object.
	 *
	 * @param obj the obj
	 * @return true, if successful
	 */
	public static boolean validateObject(Object obj) {
		if (obj == null) {
			return false;
		}
		if (obj instanceof List<?>) {
			if (((Collection<?>) obj).size() == 0) {
				return false;
			}
		}
		if (obj instanceof Map<?, ?>) {
			if (((Map) obj).isEmpty()) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Gets the user from identity.
	 *
	 * @param id the id
	 * @return the user from identity
	 */
	@Override
	public UserDto getUserFromIdentity(String id) {
		Userprofile userProfileByIdentity = authdao.getUserProfileByIdentity(id);
		UserDto userDto = mapper.map(userProfileByIdentity, UserDto.class);
		return userDto;
	}

	/**
	 * Creates the refresh token.
	 *
	 * @param id the id
	 * @return the refresh token
	 * @throws ApplicationException the application exception
	 */
	@Override
	public RefreshToken createRefreshToken(String id) throws ApplicationException {
		RefreshToken refreshToken = new RefreshToken();
		Userprofile userprofile = authdao.getUserProfileByIdentity(id);

		refreshToken.setUser(userprofile);
		refreshToken.setExpiryDate(Instant.now().plusMillis(refreshTokenDurationMs));
		refreshToken.setToken(UUID.randomUUID().toString());
		authdao.saveRefreshToken(refreshToken);
		return refreshToken;
	}

	/**
	 * Find by token.
	 *
	 * @param requestRefreshToken the request refresh token
	 * @return the refresh token
	 * @throws ApplicationException the application exception
	 */
	@Override
	public RefreshToken findByToken(String requestRefreshToken) throws ApplicationException {
		RefreshToken refreshToken = authdao.findByToken(requestRefreshToken);
		if (!ApplicationUtils.isValidateObject(refreshToken)) {
			throw new ApplicationException(ErrorCodes.REFRESH_TOKEN_INVALID);

		}
		return refreshToken;
	}

	/**
	 * Verify expiration.
	 *
	 * @param token the token
	 * @return the refresh token
	 * @throws ApplicationException the application exception
	 */
	public RefreshToken verifyExpiration(RefreshToken token) throws ApplicationException {
		if (token.getExpiryDate().compareTo(Instant.now()) < 0) {
			authdao.deleteToken(token);
			throw new ApplicationException(ErrorCodes.TOKEN_EXPIRED);
		}

		return token;
	}

	/**
	 * Delete by user id.
	 *
	 * @param userId the user id
	 */
	@Override
	public void deleteByUserId(int userId) {
		authdao.deleteByUserId(userId);
	}

	/**
	 * Captcha check.
	 *
	 * @throws ApplicationException the application exception
	 */
	public void captchaCheck() throws ApplicationException {
		GetLoginCallCaptchaCheck();
	}

	/**
	 * Gets the login call captcha check.
	 *
	 * @throws ApplicationException the application exception
	 */
	private void GetLoginCallCaptchaCheck() throws ApplicationException {
		Integer requsettime = environmentproperties.getMaxTime();
		Integer attempts = environmentproperties.getMaxAttempt();
		Integer requestedtime = requsettime * 1000;
		Date minDate = new Date();
		minDate.setTime(minDate.getTime() - requestedtime);
		String ip = "";
		try {
			InetAddress myip = InetAddress.getLocalHost();
			ip = myip.getHostAddress();
		} catch (UnknownHostException e) {
			logger.error(e.getMessage());
		}

		List<LoginCallCaptchaCheck> getLoginCallAttemptList = loginCallCaptchaCheckDao.getLoginCallCaptchaByIP(ip);
		if (ApplicationUtils.isValidateObject(getLoginCallAttemptList)) {
			for(LoginCallCaptchaCheck getLoginCallAttempt: getLoginCallAttemptList){
				Integer getloginAttempt = getLoginCallAttempt.getAttempt();
				if (getloginAttempt >= attempts) {
					throw new ApplicationException(ErrorCodes.TOO_MANY_ATTEMTS);
				} else {
					Date date = new Date();
					loginCallCaptchaCheckDao.update(getloginAttempt + 1, date, ip);

				}
			}

		} else {
			List<LoginCallCaptchaCheck> loginCallCaptchaCheckList = loginCallCaptchaCheckDao.getLoginCallCaptchaByIP(ip);
			if (ApplicationUtils.isValidateObject(loginCallCaptchaCheckList)) {
				try {
					for(LoginCallCaptchaCheck loginCallCaptchaCheck: loginCallCaptchaCheckList){
						  loginCallCaptchaCheckDao.delete(loginCallCaptchaCheck);
					  }
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
			}
			
			LoginCallCaptchaCheck getLoginCallCaptchaCheck = buildLoginCallCaptchaCheck();
			if (ApplicationUtils.isValidateObject(getLoginCallCaptchaCheck)) {
				loginCallCaptchaCheckDao.save(getLoginCallCaptchaCheck);
			}

		}

	}
	
	/**
	 * Clear ip.
	 */
	@Override
	public void clearIp() {
		InetAddress myip = null;
		try {
			myip = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		}
		String ip = myip.getHostAddress();
		List<LoginCallCaptchaCheck> loginCallCaptchaCheckList = loginCallCaptchaCheckDao.getLoginCallCaptchaByIP(ip);
    try {
		for(LoginCallCaptchaCheck loginCallCaptchaCheck: loginCallCaptchaCheckList){
			loginCallCaptchaCheckDao.delete(loginCallCaptchaCheck);
		}
    }
    catch(Exception e) {
  	  System.out.println(e.getMessage());
    }
	}

	/**
	 * Builds the login call captcha check.
	 *
	 * @return the login call captcha check
	 */
	private LoginCallCaptchaCheck buildLoginCallCaptchaCheck() {
		LoginCallCaptchaCheck loginCallCaptchaCheck = new LoginCallCaptchaCheck();
		Date date = new Date();

		try {
			InetAddress myip = InetAddress.getLocalHost();
			String ip = myip.getHostAddress();
			loginCallCaptchaCheck.setIp(ip);
			loginCallCaptchaCheck.setAttempt(1);
			loginCallCaptchaCheck.setTime(date);
		} catch (UnknownHostException e) {
			logger.error(e.getMessage());
		}

		return loginCallCaptchaCheck;

	}

	/**
	 * Gets the email from auth.
	 *
	 * @param request the request
	 * @return the email from auth
	 */
	public MailResponse getEmailFromAuth(ResetPasswordRequest request) {
		HttpHeaders httpHeaders = restTemplateUtils.getPOSTHeaders();
		HttpEntity<ResetPasswordRequest> entity = new HttpEntity<>(request, httpHeaders);
		String url = authEnvironmentProperties.getSendEmai();
		
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		ResponseEntity<MailResponse> exchange = restTemplate.exchange(builder.toUriString(), HttpMethod.POST, entity,
				MailResponse.class);
		MailResponse body = exchange.getBody();
		return body;

	}

	/**
	 * Authicate user.
	 *
	 * @param loginObj the login obj
	 * @return the jwt response
	 * @throws JsonProcessingException the json processing exception
	 * @throws ApplicationException the application exception
	 */
	@Override
	public JwtResponse authicateUser(Object loginObj) throws JsonProcessingException,ApplicationException {
		LoginDto loginDto = null;
		LocalDateTime currentDateTime=null;
		LocalDateTime effectiveDate = null;
		
		AccessTokenResponseDTO accessTokenResponseDTO = null;
		Boolean isNcloudAd = false;
		if(loginObj instanceof LoginDto) {
			loginDto = (LoginDto) loginObj;
		} else if (loginObj instanceof AccessTokenResponseDTO) {
			accessTokenResponseDTO = (AccessTokenResponseDTO) loginObj;
			loginDto = accessTokenResponseDTO.getLoginDto();
			isNcloudAd = Boolean.TRUE;
		}
		String userTypeName = loginDto.getUserTypeDto().getUserTypeName();
		
	      
	    UserDetailsImpl userDetails = authenticatingUser(loginDto);
	
		if (!userTypeName.equals(ApplicationConstants.CUSTOMER)) {
			if (!userDetails.getUsername().equals(loginDto.getUsername())) {
				throw new ApplicationException(ErrorCodes.BAD_CREDINTIAL);
			}
			
			currentDateTime = LocalDateTime.now();
			effectiveDate = userDetails.getEffectiveDate();
			
			if(ApplicationUtils.isValidateObject(effectiveDate) && effectiveDate.compareTo(currentDateTime)<0){
				throw new ApplicationException(ErrorCodes.USER_DISABLED_ERROR);
			}
		}
		validateActiveUserAndUserRole(userDetails,userTypeName);
		
	
		String companyName = "";
		Integer companyId = null;
		List<String> roles = new ArrayList<String>();
		if (!loginDto.getUserTypeDto().getUserTypeName().equals(ApplicationConstants.CUSTOMER)) {
			if (ApplicationUtils.isValidateObject(loginDto.getUserTypeDto())) {
				if (!userDetails.getUserTypeId().getUserTypeId().equals(loginDto.getUserTypeDto().getUserTypeId())) {
					throw new ApplicationException(ErrorCodes.INVALID_USER_TYPE);
				}
			}
			
			
			Integer platformId = loginDto.getPlatformDetailsDto().getPlatformId();
			roles = userDetails.getroles().stream()
					.filter(role -> role.getPlatformId().getPlatformId().equals(platformId)).map(role -> role.getName())
					.toList();

			
			if (!userDetailsUtils.hasAssociationPrivilage() && !loginDto.getUserTypeDto().getUserTypeName().equals(ApplicationConstants.TRAFFIC_AUTHORITY_)) {

					UserCompanyMappingDto userCompanyMappingDTO;
					userCompanyMappingDTO = getCompanyNameFromUser(userDetails);
					
					if (ApplicationUtils.isValidateObject(userCompanyMappingDTO)
							&& ApplicationUtils.isValidateObject(userCompanyMappingDTO.getCompanyId())) {
						companyName = userCompanyMappingDTO.getCompanyId().getName();
						companyId = userCompanyMappingDTO.getCompanyId().getCompanyId();
						userDetails.setCompanyId(companyId);
						userDetails.setCompanyName(companyName);
						
					}
			}
		}
		String jwt = null;
		RefreshToken refreshToken = null;
		if(Boolean.FALSE.equals(isNcloudAd)) {
			
			jwt = jwtUtils.generateJwtToken(userDetails, loginDto.getPlatformDetailsDto());
			refreshToken = createRefreshToken(userDetails.getIdentity());
			
		
		} else if(Boolean.TRUE.equals(isNcloudAd)) {
			jwt = accessTokenResponseDTO.getAccessToken();
			refreshToken = accessTokenResponseDTO.getRefreshToken();
		}
		
		if(userDetails.isFirstTimeLogin()) {
			DirContextOperations dirObjectFromUserName = ldapDao.getDirObjectFromUserName(userDetails.getUsername());
			if(ApplicationUtils.isValidObject(dirObjectFromUserName)) {
				Userprofile userprofile = authdao.findByUsername(userDetails.getUsername(), null);
				userprofile.setFirstTimeLogin(false);
				authdao.updateUserProfile(userprofile);
				return new JwtResponse(jwt, userDetails.getId(), userDetails.getUsername(),
						userDetails.getIdentity(), userDetails.getEmail(), false,
						userDetails.getUserTypeId(), roles, companyName, refreshToken.getToken(), userDetails.getCompanyId(), userDetails.getAssociationId(), loginDto.getPlatformDetailsDto());
			}
		}
		

		return new JwtResponse(jwt, userDetails.getId(), userDetails.getUsername(),
				userDetails.getIdentity(), userDetails.getEmail(), userDetails.isFirstTimeLogin(),
				userDetails.getUserTypeId(), roles, companyName, refreshToken.getToken(), userDetails.getCompanyId(), userDetails.getAssociationId(), loginDto.getPlatformDetailsDto());
		
	}


	/**
	 * Gets the company name from user.
	 *
	 * @param userDetails the user details
	 * @return the company name from user
	 */
	private UserCompanyMappingDto getCompanyNameFromUser(UserDetailsImpl userDetails) {
		String baseUrl = authEnvironmentProperties.getGatewayPath() + "/api/company/get-company";
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(baseUrl);
		builder.queryParam("user_id", userDetails.getIdentity());
		String finalUrl = builder.toUriString();
		ResponseEntity<UserCompanyMappingDto> forEntity = restTemplate.getForEntity(finalUrl, UserCompanyMappingDto.class);
		return forEntity.getBody();
	}
	
	
	/**
	 * @param userDetails
	 * @throws ApplicationException
	 */
	private void validateActiveUserAndUserRole(UserDetailsImpl userDetails,String userType) throws ApplicationException {
	    if (userType.equals(ApplicationConstants.CUSTOMER) && !userDetails.getStatus()) {
	        throw new ApplicationException(ErrorCodes.INACTIVE_CUSTOMER_USER);
	    } 
	    else if (!userDetails.getStatus()) {
	        throw new ApplicationException(ErrorCodes.INACTIVE_USER);
	    }
	    
	    if(ApplicationUtils.isValidateObject(userDetails.getroles())){
	    
	    List<Role> inActiveRoles = userDetails.getroles().stream().filter(role -> role.getIsActive()).collect(Collectors.toList());

		if (inActiveRoles.isEmpty()) {
		    throw new ApplicationException(ErrorCodes.INACTIVE_USER_ROLE);
		}
	    }
	}
	
	
	/**
	 * @param grandRequestDto
	 * @param userName 
	 * @return 
	 * @throws ApplicationException 
	 * @throws JsonProcessingException 
	 */
	@Override
	public AccessTokenRequestDTO generateAuthorizationCode(GrandRequestDto grandRequestDto, String userName)
			throws JsonProcessingException, ApplicationException {
		Userprofile userInfo = updateUserDetails(userName);
		AccessTokenRequestDTO accessTokenRequestDTO = new AccessTokenRequestDTO();
		GrantResponseDTO grantResponseDTO = new GrantResponseDTO();
		if (ApplicationUtils.isValidateObject(userInfo)) {
			grantResponseDTO.setAuthorizationCode(null);// TODO: Need to remove
			grantResponseDTO.setScope(grandRequestDto.getScope());
			accessTokenRequestDTO.setAuthorizationCode(grandRequestDto.getScope());
			accessTokenRequestDTO.setClientId(grandRequestDto.getClinetApi());
			accessTokenRequestDTO.setClientSecret(grandRequestDto.getClinetSecret());
			generateAccessTokenFromProvider(accessTokenRequestDTO, grandRequestDto.getLoginDto(),
					userInfo.getIdentity());
		} else {
			throw new ApplicationException(ErrorCodes.BAD_CREDINTIAL);
		}
		return accessTokenRequestDTO;
	}

	/**
	 * @param userName
	 * @return
	 */
	private Userprofile updateUserDetails(String userName) {
		Userprofile userInfo = authdao.getUserDetailsByUserName(userName);
		return userInfo;
	}
	
	/**
	 * @param accessTokenRequestDTO
	 * @param loginDto
	 * @param identity
	 * @throws JsonProcessingException
	 * @throws ApplicationException
	 */
	@Override
	public void generateAccessTokenFromProvider(AccessTokenRequestDTO accessTokenRequestDTO, LoginDto loginDto, String identity)
			throws JsonProcessingException, ApplicationException {
		UserDetailsImpl userDetails = authenticatingUser(loginDto);
		String jwt  = jwtUtils.generateJwtToken(userDetails, loginDto.getPlatformDetailsDto());
		RefreshToken refreshToken = createRefreshToken(identity);
		AccessTokenResponseDTO accessTokenResponseDTO = new AccessTokenResponseDTO();
		accessTokenResponseDTO.setAccessToken(jwt);
		accessTokenResponseDTO.setRefreshToken(refreshToken);
		accessTokenResponseDTO.setLoginDto(loginDto);
		authicateUser(accessTokenResponseDTO);
	}
	
	private UserDetailsImpl authenticatingUser(LoginDto loginDto) throws ApplicationException {
	
		boolean isAuthenticated=false; boolean isDatabaseAuthentication = false;
		Authentication dataBaseAuthentication = null;
		
		try {
			Authentication ldapAuthentication = ldapAuthenticationManager
					.authenticate(new UsernamePasswordAuthenticationToken(loginDto.getUsername() ,
							loginDto.getPassword()));
			logger.info("--------------***********************Ldap Authenticated Successfully*******************-----------");
			isAuthenticated = ldapAuthentication.isAuthenticated();
			
		}catch(BadCredentialsException e) {
			
			DirContextOperations dirObjectFromUserName = ldapDao.getDirObjectFromUserName(loginDto.getUsername());
			
			if(ApplicationUtils.isValidateObject(dirObjectFromUserName) && loginDto.getUserTypeDto()!= null && loginDto.getUserTypeDto().getUserTypeName()!=null && 
				!Arrays.asList("TRAFFIC_AUTHORITY","CUSTOMER").contains(loginDto.getUserTypeDto().getUserTypeName())) {
				throw new ApplicationException(ErrorCodes.BAD_CREDINTIAL);
			}
			
			
			dataBaseAuthentication = databaseAuthenticationManager
					.authenticate(new UsernamePasswordAuthenticationToken(loginDto.getUsername() + splitBy
							+ (ApplicationUtils.isValidObject(loginDto.getUserTypeDto())
									? loginDto.getUserTypeDto().getUserTypeName()
											: NO_USER_TYPE),
							loginDto.getPassword()));
			logger.info("-------------- **********Fallback Authenticated Successfully***************-----------");
			isDatabaseAuthentication = true;
			
			isAuthenticated = dataBaseAuthentication.isAuthenticated();
		}
		
		if(isAuthenticated && isDatabaseAuthentication) {
			SecurityContextHolder.getContext().setAuthentication(dataBaseAuthentication);
			UserDetailsImpl userDetails = (UserDetailsImpl) dataBaseAuthentication.getPrincipal();
			return userDetails;
		}else if(isAuthenticated) {
			UserDetails userDetails = userDetailsServiceImpl.loadUserByUsername(loginDto.getUsername() + splitBy
					+ (ApplicationUtils.isValidObject(loginDto.getUserTypeDto())
							? loginDto.getUserTypeDto().getUserTypeName()
							: NO_USER_TYPE));
			UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
					userDetails, null, userDetails.getAuthorities());
			SecurityContextHolder.getContext().setAuthentication(authentication);
			return (UserDetailsImpl) userDetails;
			
		}else {
			throw new ApplicationException(ErrorCodes.BAD_CREDINTIAL);
		}
	
	}

}
