package com.NotificationScheduler.Utils;

/**
 * The Class PlatformConstants.
 */
public class PlatformConstants {

	/** The Constant RECOVEREZ_PLATFORM. */
	public static final String RECOVEREZ_PLATFORM = "Recover EZ";
	
	/** The Constant DIGITAL_PAPER_PLATFORM. */
	public static final String DIGITAL_PAPER_PLATFORM = "Digital Paper";
	
	/** The Constant DATA_LAKE_PLATFORM. */
	public static final String DATA_LAKE_PLATFORM = "Data Lake";
}
