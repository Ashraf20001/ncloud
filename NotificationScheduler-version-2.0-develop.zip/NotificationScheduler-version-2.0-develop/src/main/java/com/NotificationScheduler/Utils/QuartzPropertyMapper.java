package com.NotificationScheduler.Utils;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.PropertySource;
import org.springframework.core.env.AbstractEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MapPropertySource;

/**
 * The Class QuartzPropertyMapper.
 */
@Configuration
@org.springframework.context.annotation.PropertySource("quartz.properties")
public class QuartzPropertyMapper {	
	
	/** The env. */
	@Autowired
	private Environment env;
	
	/** The Constant QUARTZ_PROP_PREFIX. */
	private static final String QUARTZ_PROP_PREFIX = "org.quartz";

    /**
     * Gets the quartz properties.
     *
     * @return the quartz properties
     */
    public  Map<String, Object> getQuartzProperties() 
    {
        Map<String, Object> allAppProp = new HashMap<String, Object>();
        
        for(Iterator<PropertySource<?>> it = ((AbstractEnvironment) env).getPropertySources().iterator(); it.hasNext(); )
        {
            PropertySource<?> propertySource = (PropertySource<?>) it.next();

            if (propertySource instanceof MapPropertySource) 
            {
                allAppProp.putAll( ((MapPropertySource) propertySource).getSource() );
            }
        }
        
        Map<String, Object> quartzProp = new HashMap<String, Object>();
        
        for (Entry<String, Object> entrySet : allAppProp.entrySet())
        {
        	if( entrySet.getKey().startsWith(QUARTZ_PROP_PREFIX) )
        	{
        		quartzProp.put(entrySet.getKey(), entrySet.getValue());
        	}
		}
        return quartzProp;
    }

}
