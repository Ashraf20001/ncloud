package com.NotificationScheduler.Utils;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.PropertySource;
import org.springframework.core.env.AbstractEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MapPropertySource;

/**
 * The Class DataBasePropertyMapper.
 */
@Configuration
@org.springframework.context.annotation.PropertySource("database.properties")
public class DataBasePropertyMapper {
	
	/** The env. */
	@Autowired
    private Environment env;
	
	/** The environmentproperties. */
	@Autowired
	private EnvironmentProperties environmentproperties;
	
	/** The Constant QUARTZ_PROP_PREFIX. */
	private static final String QUARTZ_PROP_PREFIX = "org.quartz";
	
	/** The Constant SCHEDULER_URL. */
	private static final String SCHEDULER_URL = "org.quartz.dataSource.notification.URL";
	
	/** The Constant SCHEDULER_SQL_USER. */
	private static final String SCHEDULER_SQL_USER = "org.quartz.dataSource.notification.user";
	
	/** The Constant SCHEDULER_SQL_PASSWORD. */
	private static final String SCHEDULER_SQL_PASSWORD = "org.quartz.dataSource.notification.password";

    /**
     * Gets the quartz data base properties.
     *
     * @return the quartz data base properties
     */
    public  Map<String, Object> getQuartzDataBaseProperties() 
    {
        Map<String, Object> allAppProp = new HashMap<String, Object>();
        
        for(Iterator<PropertySource<?>> it = ((AbstractEnvironment) env).getPropertySources().iterator(); it.hasNext(); )
        {
            PropertySource<?> propertySource = (PropertySource<?>) it.next();

            if (propertySource instanceof MapPropertySource) 
            {
                allAppProp.putAll( ((MapPropertySource) propertySource).getSource() );
            }
        }
        
        Map<String, Object> quartzProp = new HashMap<String, Object>();
        
        for (Entry<String, Object> entrySet : allAppProp.entrySet())
        {
        	if( entrySet.getKey().startsWith(QUARTZ_PROP_PREFIX) )
        	{
        		String value = (String) entrySet.getValue();
        		
        		value = replaceByActualValue(entrySet, value);
        		quartzProp.put(entrySet.getKey(), value);
        	}
		}
        return quartzProp;
    }

	/**
	 * Replace by {@link String} with {@link Environment} property values.
	 *
	 * @param entrySet the entry set
	 * @param value the value
	 * @return the string
	 */
	private String replaceByActualValue(Entry<String, Object> entrySet, String value) 
	{
		if(SCHEDULER_URL.equals( entrySet.getKey() ))
		{
			value = value.replace(AppPropertyConstants.SCHEDULER_MYSQL_IP,environmentproperties.getMySqlIp());
			value = value.replace(AppPropertyConstants.SCHEDULER_MYSQL_PORT, environmentproperties.getMySqlPort());
		}
		else if(SCHEDULER_SQL_USER.equals( entrySet.getKey() ))
		{
			value = value.replace(AppPropertyConstants.SCHEDULER_MYSQL_USERNAME, environmentproperties.getMySqlUsername());
		}
		else if(SCHEDULER_SQL_PASSWORD.equals(entrySet.getKey()))
		{
			value = value.replace(AppPropertyConstants.SCHEDULER_MYSQL_PASSWORD,environmentproperties.getMySqlPassword());
		}
		return value;
	}


}
