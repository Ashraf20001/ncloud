package com.NotificationScheduler.Utils;

import javax.annotation.PostConstruct;

import org.springframework.boot.autoconfigure.security.saml2.Saml2RelyingPartyProperties.AssertingParty.Verification;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class PropertyValueProvider.
 */
@ConfigurationProperties(prefix = "schedular")
@Getter
@Setter
@Component
public class PropertyValueProvider {
	
	/** The mysql ip. */
	private String mysqlIp;
	
	/** The mysql port. */
	private String mysqlPort;
	
	/** The mysql username. */
	private String mysqlUsername;
	
	/** The mysql password. */
	private String mysqlPassword;
	
	/** The recoverez kafka topic. */
	private String recoverezKafkaTopic;
	
	/** The datalake kafka topic. */
	private String datalakeKafkaTopic;
	
	/** The recoverez wallet topic. */
	private String recoverezWalletTopic;
	
	/** The recoverez wallet payment reminder topic. */
	private String recoverezWalletPaymentReminderTopic;
	
	
	/**
  	 * Prints the properties for {@link Verification}.
  	 */
  	@PostConstruct
	    public void printProperties() {
	        System.out.println("mysqlIp: " + mysqlIp);
	        System.out.println("mysqlPort: " + mysqlPort);
	        System.out.println("mysqlUsername: " + mysqlUsername);
	        System.out.println("mysqlPassword: " + mysqlPassword);
	        System.out.println("recoverezKafkaTopic: " + recoverezKafkaTopic);
	        System.out.println("datalakeKafkaTopic: " + datalakeKafkaTopic);
	        System.out.println("recoverezWalletTopic: " + recoverezWalletTopic);
	        System.out.println("recoverezWalletPaymentReminderTopic: " + recoverezWalletPaymentReminderTopic);
	    }

}

