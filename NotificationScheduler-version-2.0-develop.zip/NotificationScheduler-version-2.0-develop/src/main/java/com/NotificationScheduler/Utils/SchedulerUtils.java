package com.NotificationScheduler.Utils;

import java.util.List;

import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.TriggerKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.NotificationScheduler.Models.SchedulerRequestDto;

/**
 * The Class SchedulerUtils.
 */
@Component
public class SchedulerUtils {

	/** The scheduler. */
	@Autowired
	private Scheduler scheduler;

	/**
	 * Gets the {@link TriggerBuilder}.
	 *
	 * @param schedulerRequest the scheduler request
	 * @return the trigger
	 * @throws SchedulerException the scheduler exception
	 */
	@SuppressWarnings("unchecked")
	public TriggerBuilder<Trigger> getTrigger(SchedulerRequestDto schedulerRequest) throws SchedulerException {

		Trigger oldtrigger = null;
		TriggerBuilder<Trigger> triggerBuilder = null;
		String key = getJobKeyByPlatform(schedulerRequest);
		oldtrigger = scheduler.getTrigger(
				new TriggerKey(key, key));
		if (oldtrigger != null) {
			return (TriggerBuilder<Trigger>) oldtrigger.getTriggerBuilder();
		} else {
			if(schedulerRequest.getStatus().equals(CommonConstants.MONTHLY_REPORT)) {
				triggerBuilder = TriggerBuilder.newTrigger().withIdentity(schedulerRequest.getStatus());
			}else {
				triggerBuilder = TriggerBuilder.newTrigger().withIdentity(key, key);
			}
			return triggerBuilder;
		}
	}

	/**
	 * Gets the {@link JobDetail} by scheduler type.
	 *
	 * @param schedulerRequest the scheduler request
	 * @return the job detail by scheduler type
	 * @throws SchedulerException the scheduler exception
	 */
	public JobDetail getJobDetailBySchedulerType(SchedulerRequestDto schedulerRequest) throws SchedulerException {
		JobDetail jobDetail = null;
		String key = getJobKeyByPlatform(schedulerRequest);
		jobDetail = scheduler
				.getJobDetail(JobKey.jobKey(key, key));
		return jobDetail;
	}
	
	/**
	 * Gets the list of {@link Trigger}.
	 *
	 * @param jobkey the jobkey
	 * @return the listof triggers
	 * @throws SchedulerException the scheduler exception
	 */
	@SuppressWarnings("unchecked")
	public List<Trigger> getListofTriggers(JobKey jobkey) throws SchedulerException{
		List<Trigger> triggers= (List<Trigger>) scheduler.getTriggersOfJob(jobkey);
		return triggers;
	}
	
	/**
	 * Gets the {@link Trigger}.
	 *
	 * @param jobkey the jobkey
	 * @return the triggers
	 * @throws SchedulerException the scheduler exception
	 */
	public Trigger getTriggers(TriggerKey jobkey) throws SchedulerException{
		Trigger trigger =  scheduler.getTrigger(jobkey);
		return trigger;
	}
	
	/**
	 * Gets the job key by platform.
	 *
	 * @param schedulerRequestDto the scheduler request dto
	 * @return the job key by platform
	 */
	public String getJobKeyByPlatform(SchedulerRequestDto schedulerRequestDto) {
		String key = "";
		if(schedulerRequestDto != null) {
			String platformName = schedulerRequestDto.getPlatformName(); // != null ? schedulerRequestDto.getPlatformName() : PlatformConstants.RECOVEREZ_PLATFORM;
			switch(platformName) {
			case PlatformConstants.RECOVEREZ_PLATFORM:
				key = schedulerRequestDto.getStatus() + "_" + schedulerRequestDto.getClaimId() + "_" + schedulerRequestDto.getIsReceivable() + "_" + schedulerRequestDto.getPlatformName();
				break;
			case PlatformConstants.DIGITAL_PAPER_PLATFORM:
				key = "";
				break;
			case PlatformConstants.DATA_LAKE_PLATFORM:
				key = schedulerRequestDto.getStatus();
				break;
			}
		}
		return key;
	}

}
