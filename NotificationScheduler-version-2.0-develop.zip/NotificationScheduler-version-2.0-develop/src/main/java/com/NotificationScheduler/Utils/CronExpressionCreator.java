package com.NotificationScheduler.Utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.NotificationScheduler.Models.CronJobData;
import com.NotificationScheduler.Models.SchedulerRequestDto;

/**
 * The Class CronExpressionCreator.
 */
@Component
public class CronExpressionCreator {
	
	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(CronExpressionCreator.class);

	/**
	 * Build Cron Expression based on {@link SchedulerRequestDto} for all platforms.
	 *
	 * @param schedulerRequestDto the scheduler request dto
	 * @return the string
	 * @throws Exception the exception
	 */
	public String createCronExpression(SchedulerRequestDto schedulerRequestDto) throws Exception {
		String seconds = "0";
		String minutes = "";
		String hours = "";
		String dayOfMonth = "";
		String month = "";
		String dayOfWeek = "";
		String year = "";
		Calendar calendar = Calendar.getInstance();
		CronJobData cronData = schedulerRequestDto.getCronData();
		if(cronData == null) {
			throw new Exception("Exception ====> Cron Data cannot be null");
		}
		if(cronData.getStartDateWithTime() == null) {
			throw new Exception("Exception ====> Start Date cannot be null");
		}
		calendar.setTime(getDateTime(cronData.getStartDateWithTime()));
		minutes = calendar.get(Calendar.MINUTE) + "";
		hours = calendar.get(Calendar.HOUR_OF_DAY) + "";
		year = calendar.get(Calendar.YEAR) + "";
		switch(cronData.getRepeatFormat()) {
		case DAY: {
			if(cronData.getRepeatCount() == null) {
				throw new Exception("Exception ====> Repeat Count cannot be null");
			}
			dayOfMonth = cronData.getRepeatCount() > 0 ? "1/" + cronData.getRepeatCount() : "1";
			month = "*";
			dayOfWeek = "?";
			break;
		}
		case WEEK: {
			if(cronData.getSelectedDays() == null && cronData.getSelectedDays().size() == 0) {
				throw new Exception("Exception ====> Selected Days cannot be null or empty");
			}
			dayOfMonth = "?";
			month = "*";
			dayOfWeek = cronData.getSelectedDays().stream().map(d -> d.name()).collect(Collectors.joining(","));
			break;
		}
		case MONTH: {
			if(cronData.getRepeatCount() == null) {
				throw new Exception("Exception ====> Repeat Count cannot be null");
			}
			month = cronData.getRepeatCount() > 0 ? "1/" + cronData.getRepeatCount() : "1";
			if(cronData.getSelectedDate() != null) {
				dayOfMonth = cronData.getSelectedDate() + "";
				dayOfWeek = "?";
			} else {
				if(cronData.getRepeatOnDay() == null) {
					throw new Exception("Exception ====> Repeat on Day cannot be null");
				}
				if(cronData.getRepeatOn() == null) {
					throw new Exception("Exception ====> Repeat on cannot be null");
				}
				dayOfMonth = "?";
				Integer repeatOnValue = cronData.getRepeatOn().ordinal()+1;
			    dayOfWeek = cronData.getRepeatOnDay().ordinal()+1 + "#" + repeatOnValue;
			}
			break;
		}
		case YEAR: {
			if(cronData.getSelectedMonth() == null) {
				throw new Exception("Exception ====> Selected Month cannot be null");
			}
			month = cronData.getSelectedMonth().ordinal() + 1 + "";
			if(cronData.getSelectedDate() != null) {
				dayOfMonth = cronData.getSelectedDate() + "";
				dayOfWeek = "?";
			} else {
				if(cronData.getRepeatOnDay() == null) {
					throw new Exception("Exception ====> Repeat on Day cannot be null");
				}
				if(cronData.getRepeatOn() == null) {
					throw new Exception("Exception ====> Repeat on cannot be null");
				}
				dayOfMonth = "?";
				Integer repeatOnValue = cronData.getRepeatOn().ordinal()+1;
				dayOfWeek = cronData.getRepeatOnDay().ordinal()+1 + "#" + repeatOnValue;
			}
			break;
		}
		default:
			logger.info("Invalid Repeat Format - " + cronData.getRepeatFormat());
			throw new Exception("Invalid Repeat Format");
		}
		return new StringBuilder().append(seconds).append(" ")
						.append(minutes).append(" ")
						.append(hours).append(" ")
						.append(dayOfMonth).append(" ")
						.append(month).append(" ")
						.append(dayOfWeek).append(" ")
						.append("*").toString();
	}
	
	/**
	 * Convert date {@link String} to {@link Date} format.
	 *
	 * @param dateWithTime the date with time
	 * @return the date time
	 */
	private Date getDateTime(String dateWithTime) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Date parsedDate = new Date();
		sdf.setTimeZone(TimeZone.getTimeZone(CommonConstants.IST));
		try {
			parsedDate = sdf.parse(dateWithTime);
		} catch(ParseException pe) {
			logger.info("Exception while parsing date input =====> " + pe);
		}
		return parsedDate;
	}
}
