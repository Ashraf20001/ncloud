package com.NotificationScheduler.Utils;

/**
 * The Class AppPropertyConstants.
 */
public class AppPropertyConstants {

	/** The Constant SCHEDULER_MYSQL_IP. */
	public static final String SCHEDULER_MYSQL_IP = "[SCHEDULER_MYSQL_IP]";
	
	/** The Constant SCHEDULER_MYSQL_PORT. */
	public static final String SCHEDULER_MYSQL_PORT = "[SCHEDULER_MYSQL_PORT]";
	
	/** The Constant SCHEDULER_MYSQL_USERNAME. */
	public static final String SCHEDULER_MYSQL_USERNAME = "[SCHEDULER_MYSQL_USERNAME]";
	
	/** The Constant SCHEDULER_MYSQL_PASSWORD. */
	public static final String SCHEDULER_MYSQL_PASSWORD = "[SCHEDULER_MYSQL_PASSWORD]";

}
