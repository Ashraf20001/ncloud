package com.NotificationScheduler.Utils;

/**
 * The Class CommonConstants.
 */
public class CommonConstants {

	/** The Constant JOB_ID. */
	public static final String JOB_ID = "jobId";
	
	/** The Constant STATUS. */
	public static final String STATUS = "status";
	
	/** The Constant IST. */
	public static final String IST = "IST";
	
	/** The Constant CLAIM_ID. */
	public static final String CLAIM_ID = "claimId";
	
	/** The Constant IS_RECEIVABLE. */
	public static final String IS_RECEIVABLE = "isReceivable";
	
	/** The Constant PLATFORM_NAME. */
	public static final String PLATFORM_NAME = "platformName";
	
	/** The Constant ASSOCIATION_ID. */
	public static final String ASSOCIATION_ID = "associationId";
	
	/** The Constant MONTHLY_REPORT. */
	public static final String MONTHLY_REPORT = "Monthly Report";
	
	/** The Constant PAYMENT_REMINDER. */
	public static final String PAYMENT_REMINDER = "Payment Reminder";
	
	/** The Constant REPORT_GENERATED_DATE. */
	public static final String REPORT_GENERATED_DATE = "reportGeneratedDate";
	
	/** The Constant REMINDER_TRIGGER. */
	public static final String REMINDER_TRIGGER = "_REMINDER_TGR";
	
	/** The Constant UPLOAD_REMINDED_ON. */
	public static final String UPLOAD_REMINDED_ON = "uploadRemindedOn";
	
	/** The Constant REMINDER_PERIOD. */
	public static final String REMINDER_PERIOD = "reminderPeriod";
    
    /** The Constant RECOVERY_SCHEDULER_REPORT_LOSS. */
    public static final String RECOVERY_SCHEDULER_REPORT_LOSS = "";
}
