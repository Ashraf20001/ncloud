package com.NotificationScheduler.Utils;

import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * The Class EnvironmentProperties.
 */
@Configuration
@RequiredArgsConstructor
public class EnvironmentProperties {
	
	/** The property value provider. */
	private final PropertyValueProvider propertyValueProvider;
	
	/**
	 * Gets the my sql ip.
	 *
	 * @return the my sql ip
	 */
	public String getMySqlIp() {
		return propertyValueProvider.getMysqlIp();
	}
	
	/**
	 * Gets the my sql port.
	 *
	 * @return the my sql port
	 */
	public String getMySqlPort() {
		return propertyValueProvider.getMysqlPort();
	}
	
	/**
	 * Gets the my sql username.
	 *
	 * @return the my sql username
	 */
	public String getMySqlUsername() {
		return propertyValueProvider.getMysqlUsername();
	}
	
	/**
	 * Gets the my sql password.
	 *
	 * @return the my sql password
	 */
	public String getMySqlPassword() {
		return propertyValueProvider.getMysqlPassword();
	}
	
	/**
	 * Gets the recoverez kafka topic.
	 *
	 * @return the recoverez kafka topic
	 */
	public String getRecoverezKafkaTopic() {
		return propertyValueProvider.getRecoverezKafkaTopic();
	}
	
	/**
	 * Gets the data lake kafka topic.
	 *
	 * @return the data lake kafka topic
	 */
	public String getDataLakeKafkaTopic() {
		return propertyValueProvider.getDatalakeKafkaTopic();
	}
	
	/**
	 * Gets the recoverez wallet topic.
	 *
	 * @return the recoverez wallet topic
	 */
	public String getRecoverezWalletTopic() {
		return propertyValueProvider.getRecoverezWalletTopic();
	}
	
	/**
	 * Gets the recoverez wallet payment reminder topic.
	 *
	 * @return the recoverez wallet payment reminder topic
	 */
	public String getRecoverezWalletPaymentReminderTopic() {
		return propertyValueProvider.getRecoverezWalletPaymentReminderTopic();
	}

}
