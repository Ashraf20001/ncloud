package com.NotificationScheduler.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import com.NotificationScheduler.Models.NotificationDto;
import com.NotificationScheduler.Utils.CommonConstants;
import com.NotificationScheduler.Utils.EnvironmentProperties;
import com.NotificationScheduler.Utils.PlatformConstants;

/**
 * The Class KafkaProducer.
 */
@Component
public class KafkaProducer {
	
	/** The environment properties. */
	@Autowired
	private EnvironmentProperties environmentProperties;

	/** The kafka template. */
	@Autowired
	KafkaTemplate<String, NotificationDto> kafkaTemplate;
	
	/**
	 * Send notification.
	 *
	 * @param notificationDto the notification dto
	 * @param platformName the platform name
	 */
	public void sendNotification(NotificationDto notificationDto, String platformName) {
		String topicName = "";
		if(platformName == null) {
			topicName = environmentProperties.getRecoverezKafkaTopic();
		} else {
			switch(platformName) {
			case PlatformConstants.RECOVEREZ_PLATFORM:

                topicName = switch (notificationDto.getStatus()) {
                    case CommonConstants.MONTHLY_REPORT -> environmentProperties.getRecoverezWalletTopic();
                    case CommonConstants.PAYMENT_REMINDER ->environmentProperties.getRecoverezWalletPaymentReminderTopic();
                    case CommonConstants.RECOVERY_SCHEDULER_REPORT_LOSS -> environmentProperties.getRecoverezKafkaTopic();
                    default -> environmentProperties.getRecoverezKafkaTopic();
                };
				break;
			case PlatformConstants.DATA_LAKE_PLATFORM:
				topicName = environmentProperties.getDataLakeKafkaTopic();
				break;
			}
		}
		kafkaTemplate.send(topicName, notificationDto);
	}

}
