package com.NotificationScheduler.Factory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.NotificationScheduler.Models.SchedulerRequestDto;
import com.NotificationScheduler.TriggerBuilder.CustomTriggerBuilder;

/**
 * A factory for creating Scheduler objects.
 */
@Component
public class SchedulerFactory {

	/** The immediate trigger builder. */
	@Autowired
	@Qualifier(value = "ImmediateTriggerBuilder")
	private CustomTriggerBuilder immediateTriggerBuilder;

	/** The cron trigger builder. */
	@Autowired
	@Qualifier(value = "CronTriggerBuilder")
	private CustomTriggerBuilder cronTriggerBuilder;
	
	/** The timed trigger builder. */
	@Autowired
	@Qualifier(value = "TimedTriggerBuilder")
	private CustomTriggerBuilder timedTriggerBuilder;

	/**
	 * Gets the trigger builder.
	 *
	 * @param schedulerRequest the scheduler request
	 * @return the trigger builder
	 */
	public CustomTriggerBuilder getTriggerBuilder(SchedulerRequestDto schedulerRequest) {

		if (schedulerRequest.getTimeInterval() == null) {
			return immediateTriggerBuilder;
		} else if(schedulerRequest.getIsCronJob() != null && schedulerRequest.getIsCronJob()){
			return cronTriggerBuilder;
		} else {
			return timedTriggerBuilder;
		}
	}

}
