package com.NotificationScheduler.Factory;

import org.quartz.spi.TriggerFiredBundle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.quartz.AdaptableJobFactory;
import org.springframework.stereotype.Component;

/**
 * A factory for creating CustomJob objects.
 */
@Component
public class CustomJobFactory extends AdaptableJobFactory {

	/** The application context. */
	@Autowired
	private ApplicationContext applicationContext;

    /**
     * Creates a new CustomJob object.
     *
     * @param bundle the bundle
     * @return the object
     * @throws Exception the exception
     */
    @Override
    protected Object createJobInstance(TriggerFiredBundle bundle) throws Exception {
        return applicationContext.getBean(bundle.getJobDetail().getJobClass());
    }
}
