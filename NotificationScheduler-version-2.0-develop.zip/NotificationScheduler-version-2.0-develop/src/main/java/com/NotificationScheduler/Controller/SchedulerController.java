package com.NotificationScheduler.Controller;

import org.quartz.JobDetail;
import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.NotificationScheduler.Models.NotificationDto;
import com.NotificationScheduler.Models.SchedulerRequestDto;
import com.NotificationScheduler.Models.SchedulerResponse;
import com.NotificationScheduler.service.ScheduleProcessor;

/**
 * The Class SchedulerController.
 */
@RestController
public class SchedulerController {

	/** The scheduleprocessor. */
	@Autowired
	private ScheduleProcessor scheduleprocessor;

	/**
	 * JobBuilder Build {@link JobDetail} using SchedulerrequestDto to create a cron
	 * and trigger the scheduler Common for all three paltform
	 *
	 * @param schedulerRequest the scheduler request
	 * @return the scheduler response
	 * @throws SchedulerException the scheduler exception
	 * @throws Exception          Return the exception that is the underlying cause of this exception.
	 */
	@PostMapping(value = "/triggerScheduler")
	public SchedulerResponse triggerScheduler(@RequestBody SchedulerRequestDto schedulerRequest)
			throws SchedulerException, Exception {
		return scheduleprocessor.triggerJob(schedulerRequest);
	}

	/**
	 * Unschedule the job based on platformId and status.
	 *
	 * @param notificationDetails the notification details
	 * @return the string
	 * @throws SchedulerException the scheduler exception
	 */
	@PostMapping(value = "/stopScheduler")
	public String stopTriger(@RequestBody NotificationDto notificationDetails) throws SchedulerException {
		return scheduleprocessor.stopScheduler(notificationDetails);
	}
	
	/**
	 * Update the jobBuilder details to trigger updated job.
	 *
	 * @param schedulerRequest the scheduler request
	 * @throws SchedulerException the scheduler exception
	 */
	@PostMapping(value ="/updateTimeInterval")
	public void updateTimeInterval(@RequestBody SchedulerRequestDto schedulerRequest) throws SchedulerException {
		scheduleprocessor.updateTimeInterval(schedulerRequest);
	}

}
