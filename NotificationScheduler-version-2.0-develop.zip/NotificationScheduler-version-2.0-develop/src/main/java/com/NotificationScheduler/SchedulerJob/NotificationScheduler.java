package com.NotificationScheduler.SchedulerJob;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.quartz.CronExpression;
import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobKey;
import org.quartz.PersistJobDataAfterExecution;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.NotificationScheduler.Models.NotificationDto;
import com.NotificationScheduler.Models.PlatformEnum;
import com.NotificationScheduler.Utils.CommonConstants;
import com.NotificationScheduler.Utils.PlatformConstants;
import com.NotificationScheduler.kafka.KafkaProducer;

/**
 * The Class NotificationScheduler.
 */
@Component
@PersistJobDataAfterExecution
@DisallowConcurrentExecution
public class NotificationScheduler implements Job {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(NotificationScheduler.class);

	/** The kafka producer. */
	@Autowired
	private KafkaProducer kafkaProducer;

	/** The scheduler. */
	@Autowired
	private Scheduler scheduler;
	
	/** The cron expression. */
	@Value("${wallet.report.generation.cron}")
	private String cronExpression;

	/**
	 *@param context
	 */
	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		logger.info("notification job executed..........................");
		String platformName = "";
		Integer associationId = null;
		Long reportTime = null;
		JobDataMap jdm = context.getJobDetail().getJobDataMap();

		if (jdm != null) {
			String associationIdString = null;
			try {
				platformName = jdm.getString(CommonConstants.PLATFORM_NAME);
				associationIdString = jdm.getString(CommonConstants.ASSOCIATION_ID);
				reportTime = jdm.getLongValue(CommonConstants.REPORT_GENERATED_DATE);
			} catch (Exception e) {
			}
			if (associationIdString != null) {
				associationId = jdm.getIntegerFromString(CommonConstants.ASSOCIATION_ID);
			} else {
				associationId = 1;
			}
		}
		if (platformName.equalsIgnoreCase(PlatformConstants.DATA_LAKE_PLATFORM)) {
			logger.info("notification scheduler ===>  Data Lake");
			try {
				Object reminderKey = jdm.get(CommonConstants.REMINDER_PERIOD);
				if(reminderKey != null) {
					createReminderCronJob(jdm, context, platformName, associationId);
				}
			} catch (SchedulerException e) {
				e.printStackTrace();
			} catch (ParseException e) {
				e.printStackTrace();
			}
			try {
				executeDataLakeJob(context.getJobDetail().getKey().getName(), platformName, associationId, null);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		} else if(platformName.equalsIgnoreCase(PlatformConstants.RECOVEREZ_PLATFORM)
			){
			logger.info("notification scheduler ===>  Recovery EZ");
			executeJob(context.getJobDetail().getKey().getName(), platformName, associationId, reportTime);
		}

	}

	/**
	 * @param jobDetails
	 * @param platformName
	 * @param associationId
	 * @param lastTriggeredDate
	 * @throws ParseException
	 */
	public void executeDataLakeJob(String jobDetails, String platformName, Integer associationId, String lastTriggeredDate) throws ParseException {
		logger.info("JobDetails =====> " + jobDetails);
		logger.info("Platform Name ======> " + platformName);
		logger.info("Association Id ======> " + associationId);
		NotificationDto notificationDetails = new NotificationDto();
		buildNotificationDtoForConsumer(jobDetails, platformName, lastTriggeredDate, notificationDetails);
		notificationDetails.setAssociationId(associationId);
		kafkaProducer.sendNotification(notificationDetails, platformName);
		System.out.println(notificationDetails);
	}

	/**
	 * @param jobDetails
	 * @param platformName
	 * @param lastTriggeredDate
	 * @param notificationDetails
	 * @throws ParseException
	 */
	private void buildNotificationDtoForConsumer(String jobDetails, String platformName, String lastTriggeredDate,
			NotificationDto notificationDetails) throws ParseException {
		logger.info("last triggered date  ===>  " + lastTriggeredDate);
		if (platformName != null && platformName.equals(PlatformConstants.DATA_LAKE_PLATFORM)) {
			notificationDetails.setCompanyName("");
			notificationDetails.setLogoUrl("");
			notificationDetails.setLastActed("");
			notificationDetails.setStatus(jobDetails);
			notificationDetails.setClaimId(-1);
			notificationDetails.setIsReceivable("false");
			if (lastTriggeredDate != null) {
				SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
				Date formattedDate = sdf.parse(lastTriggeredDate);
				notificationDetails.setFromDate(formattedDate);
			}
			notificationDetails.setPlatformId(PlatformEnum.getPlatformIdByName(PlatformConstants.DATA_LAKE_PLATFORM));
		} else {
			notificationDetails.setCompanyName("");
			notificationDetails.setLogoUrl("");
			notificationDetails.setLastActed("");
			String[] jobKey = jobDetails.split("_");
			notificationDetails.setStatus(jobKey[0]);
			notificationDetails.setClaimId(Integer.parseInt(jobKey[1]));
			notificationDetails.setIsReceivable(jobKey[2]);
			notificationDetails.setPlatformId(PlatformEnum.getPlatformIdByName(PlatformConstants.RECOVEREZ_PLATFORM));
		}
	}

	/**
	 * @param jobDetails
	 * @param platformName
	 * @param associationId
	 * @param reportTime
	 */
	public void executeJob(String jobDetails, String platformName, Integer associationId, Long reportTime) {
		logger.info("JobDetails =====> " + jobDetails);
		logger.info("Platform Name ======> " + platformName);
		logger.info("Association Id ======> " + associationId);
		logger.info("report time ==========> " + reportTime);
		NotificationDto notificationDetails = new NotificationDto();
		String[] jobKey = jobDetails.split("_");
		notificationDetails.setStatus(jobKey[0]);
		notificationDetails.setClaimId(Integer.parseInt(jobKey[1]));
		notificationDetails.setIsReceivable(jobKey[2]);
		notificationDetails.setAssociationId(associationId);
		notificationDetails.setCompanyName(reportTime + ""); // report time for wallet payment reminder purpose
		notificationDetails.setPlatformId(PlatformEnum.getPlatformIdByName(platformName));
		extractFromToDateFromCron(notificationDetails); // update cron details

		kafkaProducer.sendNotification(notificationDetails, platformName);
		System.out.println(notificationDetails);
	}

	/**
	 * @param notificationDetails
	 */
	private void extractFromToDateFromCron(NotificationDto notificationDetails) {
		try {

			CronExpression cron = new CronExpression(cronExpression);

			Date now = new Date();
			Date startDate = cron.getNextValidTimeAfter(now);
			java.util.Calendar calendar = java.util.Calendar.getInstance();
			calendar.setTime(now);

			while (true) {
				calendar.add(Calendar.SECOND, -1);
				Date previousDate = calendar.getTime();

				if (cron.isSatisfiedBy(previousDate)) {
					notificationDetails.setFromDate(previousDate);
					notificationDetails.setToDate(startDate);
					break;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Creates the date.
	 *
	 * @param year the year
	 * @param month the month
	 * @param day the day
	 * @param hour the hour
	 * @param minute the minute
	 * @param second the second
	 * @return the date
	 */
	public static Date createDate(int year, int month, int day, int hour, int minute, int second) {
		Calendar calendar = Calendar.getInstance();
		calendar.set(year, month - 1, day, hour, minute, second);
		return calendar.getTime();
	}

	/**
	 * @param jobDataMap
	 * @param jobExecutionContext
	 * @param platformName
	 * @param associationId
	 * @throws SchedulerException
	 * @throws ParseException
	 */
	public void createReminderCronJob(JobDataMap jobDataMap, JobExecutionContext jobExecutionContext,
			String platformName, Integer associationId) throws SchedulerException, ParseException {
		logger.debug("reminder period  ====> " + jobDataMap.getInt(CommonConstants.REMINDER_PERIOD));
		String uniqueIdentity = null;
		uniqueIdentity = jobDataMap.getString(CommonConstants.STATUS) + "_REMINDER";

		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.HOUR, jobDataMap.getInt(CommonConstants.REMINDER_PERIOD));
		Date fromDate = calendar.getTime();

		Calendar secondCalendar = Calendar.getInstance();
		secondCalendar.setTime(fromDate);
		secondCalendar.add(Calendar.HOUR, -1);

		Date nextFire = getNextFireDateTime(jobExecutionContext);
		buildReminderJobAndTrigger(uniqueIdentity, fromDate, secondCalendar, nextFire, platformName, associationId);
	}

	/**
	 * @param uniqueIdentity
	 * @param fromDate
	 * @param secondCalendar
	 * @param nextFire
	 * @param associationId
	 * @param platformName
	 * @throws SchedulerException
	 */
	@SuppressWarnings("deprecation")
	private void buildReminderJobAndTrigger(String uniqueIdentity, Date fromDate, Calendar secondCalendar,
			Date nextFire, String platformName, Integer associationId) throws SchedulerException {
		logger.info("************************** baby cron build started ******************************************");
		JobKey jobKey = new JobKey(uniqueIdentity, uniqueIdentity);
		JobDetail jobDetail = scheduler.getJobDetail(jobKey);
		if (jobDetail == null) {
			Date date = new Date();
			String dateFormat = "dd-MM-yyyy HH:mm:ss";
	        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
	        String formattedDate = sdf.format(date);

			jobDetail = JobBuilder.newJob(DailyReminder.class).usingJobData(CommonConstants.UPLOAD_REMINDED_ON, formattedDate)
					.usingJobData(CommonConstants.PLATFORM_NAME, platformName)
					.usingJobData(CommonConstants.ASSOCIATION_ID, associationId)
					.withIdentity(uniqueIdentity, uniqueIdentity).build();
		}
		CronTrigger newCronTrigger = TriggerBuilder.newTrigger().forJob(uniqueIdentity, uniqueIdentity)
				.withIdentity(uniqueIdentity + "_TGR", uniqueIdentity + "_TGR").startAt(secondCalendar.getTime())
				.endAt(nextFire)
				.withSchedule(CronScheduleBuilder.dailyAtHourAndMinute(fromDate.getHours(), fromDate.getMinutes()))
				.build();
		logger.info("baby cron start ===> " + secondCalendar.getTime());
		logger.info("baby cron end ===> " + nextFire);
		Set<Trigger> triggerSet = new HashSet<Trigger>();
		triggerSet.add(newCronTrigger);
		scheduler.scheduleJob(jobDetail, triggerSet, true);
	}

	/**
	 * @param trigger
	 * @return
	 * @throws ParseException
	 */
	private Date getNextFireDateTime(JobExecutionContext jobExecutionContext) throws ParseException {
		Trigger trigger = jobExecutionContext.getTrigger();
		CronTrigger cronTrigger = (CronTrigger) trigger;
		String cronExpression = cronTrigger.getCronExpression();
		CronExpression cronExp = new CronExpression(cronExpression);
		Date nextFire = cronExp.getNextValidTimeAfter(new Date());
		System.out.println("cron expression || upload schedule =====> " + cronExpression);
		return nextFire;
	}

}
