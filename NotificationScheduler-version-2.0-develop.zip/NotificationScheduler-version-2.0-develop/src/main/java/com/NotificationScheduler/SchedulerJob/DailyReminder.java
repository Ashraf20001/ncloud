package com.NotificationScheduler.SchedulerJob;

import java.text.ParseException;
import java.util.Date;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.PersistJobDataAfterExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.NotificationScheduler.Utils.CommonConstants;

/**
 * The Class DailyReminder.
 */
@Component
@PersistJobDataAfterExecution
@DisallowConcurrentExecution
public class DailyReminder implements Job {

	/**
	 * @implNote Data Lake Specific Job (Reminder Scheduler)
	 */
	private static final Logger logger = LoggerFactory.getLogger(DailyReminder.class);

	/** The notification scheduler. */
	@Autowired
	private NotificationScheduler notificationScheduler;

	/**
	 * @param context
	 */
	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
		logger.info("Daily Reminder Triggered ====>  " + new Date().toString());
		try {
			notificationScheduler.executeDataLakeJob(context.getJobDetail().getKey().getName(),
					jobDataMap.getString(CommonConstants.PLATFORM_NAME),
					jobDataMap.getInt(CommonConstants.ASSOCIATION_ID),
					jobDataMap.getString(CommonConstants.UPLOAD_REMINDED_ON));
		} catch (ParseException e) {
			logger.info(e.getLocalizedMessage());
			e.printStackTrace();
		}
	}

}
