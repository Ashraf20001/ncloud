package com.NotificationScheduler.TriggerBuilder;

import java.util.Calendar;
import java.util.Date;

import org.quartz.CronScheduleBuilder;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.NotificationScheduler.Models.SchedulerRequestDto;
import com.NotificationScheduler.Utils.CommonConstants;
import com.NotificationScheduler.Utils.SchedulerUtils;

/**
 * The Class TimedTriggerBuilder.
 */
@Component("TimedTriggerBuilder")
public class TimedTriggerBuilder implements CustomTriggerBuilder {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(TimedTriggerBuilder.class);
	
	/** The scheduler utils. */
	@Autowired
	private SchedulerUtils schedulerUtils;
	
	/** The cron expression. */
	@Value("${wallet.report.generation.cron}")
	private String cronExpression;
	
	/**
	 * Add Trigger details by time interval provide in {@link SchedulerRequestDto}.
	 * 
	 * @param schedulerRequest
	 */
	@Override
	public Trigger getTrigger(SchedulerRequestDto schedulerRequest) {
		Trigger trigger = null;
		try {
			TriggerBuilder<Trigger> triggerBuilder = schedulerUtils.getTrigger(schedulerRequest);

			trigger = addTriggerDetails(triggerBuilder, schedulerRequest.getTimeInterval(), schedulerRequest.getStatus(), schedulerRequest.getReminderPeriod(), schedulerRequest.getNextTriggerTime());
		} catch (Exception e) {
			logger.info("Exception while getting trigger =====> " + e);
		}
		return trigger;
	}
	
	/**
	 * Trigger scheduler from {@link StartDate} to repeat hourly forever.
	 * @param triggerBuilder
	 * @param timeInterval
	 * @param jobIdentifier
	 * @param date 
	 * @return
	 */
	public Trigger addTriggerDetails(TriggerBuilder<Trigger> triggerBuilder, Integer timeInterval, String jobIdentifier, Integer reminderPeriod, Date nextFireDate) {
		Date startdate = getCurrentDateWithaddedHours(timeInterval);
		Trigger trigger = null;
		Date startDate = null;
		if (jobIdentifier.equals(CommonConstants.PAYMENT_REMINDER)) {
			if (nextFireDate != null) {
				startDate = nextFireDate;
			} else {
				startDate = getCurrentDateWithaddedHours(timeInterval); // start date with grace period added
			}
			trigger = triggerBuilder.startAt(startDate)
					.withSchedule(SimpleScheduleBuilder.repeatHourlyForever(reminderPeriod))
					.build();
		} else if (jobIdentifier.equals(CommonConstants.MONTHLY_REPORT)) {
			trigger = triggerBuilder.startAt(startdate).withSchedule(CronScheduleBuilder.cronSchedule(cronExpression))
					.build();
		} else {
			trigger = triggerBuilder.startAt(getCurrentDateWithaddedHours(timeInterval))
					.withSchedule(SimpleScheduleBuilder.repeatHourlyForever(timeInterval))
					.build();
		}
		return trigger;
	}

	/**
	 * Add hours for current date.
	 * @param timeInterval
	 * @return
	 */
	public Date getCurrentDateWithaddedHours(Integer timeInterval) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());
		calendar.add(Calendar.HOUR, timeInterval);
		return calendar.getTime();
	}

}
