package com.NotificationScheduler.TriggerBuilder;

import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.NotificationScheduler.Models.SchedulerRequestDto;
import com.NotificationScheduler.Utils.SchedulerUtils;

/**
 * The Class ImmediateTriggerBuilder.
 */
@Component("ImmediateTriggerBuilder")
public class ImmediateTriggerBuilder implements CustomTriggerBuilder {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ImmediateTriggerBuilder.class);
	
	/** The scheduler utils. */
	@Autowired
	private SchedulerUtils schedulerUtils;

	/**
	 * Gets the trigger immediately with any time interval.
	 *
	 * @param schedulerRequest the scheduler request
	 * @return the trigger
	 */
	@Override
	public Trigger getTrigger(SchedulerRequestDto schedulerRequest) {
		Trigger trigger = null;
		try {
			TriggerBuilder<Trigger> triggerBuilder = schedulerUtils.getTrigger(schedulerRequest);
			trigger = triggerBuilder.startNow().build();
		} catch (SchedulerException e) {
			logger.info("Exception while getting trigger =====> " + e);
		}
		return trigger;
	}

}
