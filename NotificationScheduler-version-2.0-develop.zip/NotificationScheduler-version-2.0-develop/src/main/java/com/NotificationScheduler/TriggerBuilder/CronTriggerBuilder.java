package com.NotificationScheduler.TriggerBuilder;

import static org.quartz.CronScheduleBuilder.cronSchedule;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.NotificationScheduler.Models.SchedulerRequestDto;
import com.NotificationScheduler.Utils.CronExpressionCreator;
import com.NotificationScheduler.Utils.PlatformConstants;
import com.NotificationScheduler.Utils.SchedulerUtils;

/**
 * The Class CronTriggerBuilder.
 */
@Component("CronTriggerBuilder")
public class CronTriggerBuilder implements CustomTriggerBuilder {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(CronTriggerBuilder.class);
	
	/** The cron expression creator. */
	@Autowired
	private CronExpressionCreator cronExpressionCreator;
	
	/** The scheduler utils. */
	@Autowired
	private SchedulerUtils schedulerUtils;
	
	/** The cron expression. */
	@Value("${wallet.report.generation.cron}")
	private String cronExpression;
	
	/**
	 * This service method for wallet monthly report scheduler and common scheduler
	 * for all platform Build a cron experssion by injecting
	 * {@link CronExpressionCreator}.
	 * 
	 * @param schedulerRequest
	 */
	@Override
	public Trigger getTrigger(SchedulerRequestDto schedulerRequest) {
		logger.info("Received Request ======> " + schedulerRequest.toString());
		Trigger trigger = null;
		try {
			if(schedulerRequest.getStatus().equals("Monthly Report")) {
				TriggerBuilder triggerBuilder = schedulerUtils.getTrigger(schedulerRequest);
				trigger = addTriggerDetailsForMonthlyReport(triggerBuilder, schedulerRequest.getTimeInterval());
			}else {
				String cronExpression = cronExpressionCreator.createCronExpression(schedulerRequest);
				logger.info("Generated Cron Expression =======> " + cronExpression);
				SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
				SimpleDateFormat sDateOnlyFormat = new SimpleDateFormat("yyyy-MM-dd");
				Date fromDate = sDateFormat.parse(schedulerRequest.getCronData().getStartDateWithTime());
				fromDate.setHours(0);
				fromDate.setMinutes(0);
				Date endDate = sDateOnlyFormat.parse(schedulerRequest.getCronData().getEndDate());
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(endDate);
				calendar.set(Calendar.HOUR_OF_DAY, 23);
				calendar.set(Calendar.MINUTE, 59);
				calendar.set(Calendar.SECOND, 59);
				endDate = calendar.getTime();
				CronTrigger newCronTrigger = TriggerBuilder.newTrigger().forJob(schedulerRequest.getStatus(), schedulerRequest.getStatus())
						.withIdentity(schedulerRequest.getStatus(), schedulerRequest.getStatus()).startAt(fromDate)
						.endAt(endDate)
						.withSchedule(CronScheduleBuilder.cronSchedule(cronExpression).withMisfireHandlingInstructionDoNothing())
						.build();
				logger.info("start date ==> " + fromDate);
				logger.info("end date  ===> " + endDate);
				trigger = (Trigger) newCronTrigger;
			}
		} catch (Exception e) {
			logger.info("Exception while getting trigger =====> " + e);
		}
		return trigger;
	}

	
	/**
	 * Adds the trigger details.
	 *
	 * @param triggerBuilder the trigger builder
	 * @param timeInterval the time interval
	 * @return the trigger
	 */
	public Trigger addTriggerDetails(TriggerBuilder triggerBuilder, Integer timeInterval) {
		Date startdate = getCurrentDateWithaddedHours(timeInterval, null);
		Trigger trigger = triggerBuilder.startAt(startdate).withSchedule(SimpleScheduleBuilder.repeatMinutelyForever(2)).build();
		return trigger;

	}
	
	
	/**
	 * Adds the trigger details for monthly report.
	 *
	 * @param triggerBuilder the trigger builder
	 * @param timeInterval the time interval
	 * @return the trigger
	 */
	public Trigger addTriggerDetailsForMonthlyReport(TriggerBuilder triggerBuilder, Integer timeInterval) {
		Date startdate = getCurrentDateWithaddedHours(timeInterval, null);
		Trigger trigger = triggerBuilder.startAt(startdate).withSchedule(cronSchedule(cronExpression)).build();
		return trigger;

	}

	/**
	 * Gets the current date withadded hours.
	 *
	 * @param timeInterval the time interval
	 * @param platformName the platform name
	 * @return the current date withadded hours
	 */
	public Date getCurrentDateWithaddedHours(Integer timeInterval, String platformName) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());
		if(!platformName.equals(PlatformConstants.DATA_LAKE_PLATFORM)) {
		calendar.add(Calendar.MINUTE, timeInterval);
		}
		return calendar.getTime();
	}
}
