package com.NotificationScheduler.TriggerBuilder;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.NotificationScheduler.Utils.DataBasePropertyMapper;
import com.NotificationScheduler.Utils.QuartzPropertyMapper;

/**
 * The Class QuartzPropertyBuilder.
 */
@Component
public class QuartzPropertyBuilder {
	
	/** The quartz property mapper. */
	@Autowired
	QuartzPropertyMapper quartzPropertyMapper;
	
	/** The Data base property mapper. */
	@Autowired
	DataBasePropertyMapper DataBasePropertyMapper;
	
	/**
	 * Gets the properties.
	 *
	 * @return the properties
	 */
	public Properties getProperties() {
		Properties properties = new Properties();
		properties.putAll(quartzPropertyMapper.getQuartzProperties());
		properties.putAll(DataBasePropertyMapper.getQuartzDataBaseProperties());
		return properties;
	}

}
