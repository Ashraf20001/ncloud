package com.NotificationScheduler.TriggerBuilder;

import org.quartz.Trigger;

import com.NotificationScheduler.Models.SchedulerRequestDto;

/**
 * The Interface CustomTriggerBuilder.
 */
public interface CustomTriggerBuilder {
	
	/**
	 * Gets the trigger.
	 *
	 * @param schedulerRequest the scheduler request
	 * @return the trigger
	 */
	public Trigger getTrigger(SchedulerRequestDto schedulerRequest);

}
