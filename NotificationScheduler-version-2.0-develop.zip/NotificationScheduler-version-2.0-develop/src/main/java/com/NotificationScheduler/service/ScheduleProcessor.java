package com.NotificationScheduler.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.quartz.Job;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.NotificationScheduler.Factory.SchedulerFactory;
import com.NotificationScheduler.Models.NotificationDto;
import com.NotificationScheduler.Models.PlatformEnum;
import com.NotificationScheduler.Models.ScheduleStatus;
import com.NotificationScheduler.Models.SchedulerRequestDto;
import com.NotificationScheduler.Models.SchedulerResponse;
import com.NotificationScheduler.SchedulerJob.NotificationScheduler;
import com.NotificationScheduler.TriggerBuilder.CustomTriggerBuilder;
import com.NotificationScheduler.Utils.CommonConstants;
import com.NotificationScheduler.Utils.PlatformConstants;
import com.NotificationScheduler.Utils.SchedulerUtils;

@Component
public class ScheduleProcessor implements Job {

	/**
	 * scheduler injected
	 */
	@Autowired
	private Scheduler scheduler;

	/**
	 * schdeuler factory
	 */
	@Autowired
	private SchedulerFactory schedulerFactory;

	/**
	 * scheduler utils
	 */
	@Autowired
	private SchedulerUtils schedulerUtil;

	/**
	 * Notification Schdeuler
	 */
	@Autowired
	private NotificationScheduler notificationScheduler;

	/**
	 * SchedulerRequestDto - build jobdetail to trigger {@link Scheduler}
	 * 
	 * @param schedulerRequest
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public SchedulerResponse triggerJob(SchedulerRequestDto schedulerRequest) throws SchedulerException, Exception {
		SchedulerResponse schedulerResponse = new SchedulerResponse();
		JobDetail job = schedulerUtil.getJobDetailBySchedulerType(schedulerRequest);
		Class clazz = com.NotificationScheduler.SchedulerJob.NotificationScheduler.class;
		String key = schedulerUtil.getJobKeyByPlatform(schedulerRequest);
		Date date = new Date(); 
		if (job == null) {
           	if(schedulerRequest.getStatus().equals(job)) {
        	   	job = JobBuilder.newJob(clazz).usingJobData(CommonConstants.JOB_ID, schedulerRequest.getClaimId())
   					.usingJobData(CommonConstants.STATUS, schedulerRequest.getStatus())
   					.withIdentity(schedulerRequest.getStatus())
   					.storeDurably(true).build();
           	}
           	else {
				job = JobBuilder.newJob(clazz).usingJobData(CommonConstants.JOB_ID, schedulerRequest.getClaimId())
					.usingJobData(CommonConstants.STATUS, schedulerRequest.getStatus())
					.usingJobData(CommonConstants.CLAIM_ID, schedulerRequest.getClaimId())
					.usingJobData(CommonConstants.IS_RECEIVABLE, schedulerRequest.getIsReceivable())
					.usingJobData(CommonConstants.PLATFORM_NAME, schedulerRequest.getPlatformName())
					.usingJobData(CommonConstants.ASSOCIATION_ID, schedulerRequest.getAssociationId())
					.usingJobData(CommonConstants.REPORT_GENERATED_DATE, date.getTime())
					.usingJobData(CommonConstants.REMINDER_PERIOD, schedulerRequest.getTimeInterval())
					.withIdentity(key, key)
					.storeDurably(true).build();
				TriggerKey reminderTrigger = new TriggerKey(key + CommonConstants.REMINDER_TRIGGER, key + CommonConstants.REMINDER_TRIGGER); // delete reminder trigger on job updation.
				if (reminderTrigger != null) {
					scheduler.unscheduleJob(reminderTrigger);
				}
           	}
		}else {
			if(schedulerRequest.getPlatformName().equals(PlatformConstants.DATA_LAKE_PLATFORM)) {
				job.getJobDataMap().put(CommonConstants.REMINDER_PERIOD, schedulerRequest.getTimeInterval());
			}
		}
		CustomTriggerBuilder customTriggerBuilder = schedulerFactory.getTriggerBuilder(schedulerRequest);
		Trigger newTrigger = customTriggerBuilder.getTrigger(schedulerRequest);
		Set<Trigger> triggerSet = new HashSet<Trigger>();
		triggerSet.add(newTrigger);
		try {
			scheduler.scheduleJob(job, triggerSet, true);
		} catch (SchedulerException e) {
			throw new Exception(e.getLocalizedMessage());
		}
		schedulerResponse.setScheduleStatus(ScheduleStatus.COMPLETED);
		return schedulerResponse;
	}

	/**
	 * UnscheduleJob by initating {@link Scheduler}
	 * @param notificationDetails
	 * @return
	 * @throws SchedulerException
	 */
	public String stopScheduler(NotificationDto notificationDetails) throws SchedulerException {
		SchedulerRequestDto schedulerRequest = new SchedulerRequestDto();
		schedulerRequest.setStatus(notificationDetails.getStatus());
		schedulerRequest.setClaimId(notificationDetails.getClaimId());
		schedulerRequest.setIsReceivable(Boolean.valueOf(notificationDetails.getIsReceivable()));
		schedulerRequest.setPlatformName(PlatformEnum.getPlatformNameById(notificationDetails.getPlatformId()));
		JobDetail job = schedulerUtil.getJobDetailBySchedulerType(schedulerRequest);
		if(job!=null){
			List<Trigger> triggers = schedulerUtil.getListofTriggers(job.getKey());
			for (Trigger unscheduleTrigger : triggers) {
				scheduler.unscheduleJob(unscheduleTrigger.getKey());
			}
		}
		return "Success";

	}

	/**
	 * Update latest time changes in SchedulerRequest {@link SchedulerRequestDto}.
	 * 
	 * @param schedulerRequestDto
	 * @throws SchedulerException
	 */
	public void updateTimeInterval(SchedulerRequestDto schedulerRequestDto) throws SchedulerException {
		List<String> groupNames = scheduler.getTriggerGroupNames();
		List<String> groups = new ArrayList<>();
		for (String group : groupNames) {
			if (group.replaceAll("_", " ").contains(schedulerRequestDto.getStatus())) {
				groups.add(group);
			}
		}
		for (String group : groups) {
			String[] arr = group.split("_");
			SchedulerRequestDto SchedulerRequest = new SchedulerRequestDto();
			SchedulerRequest.setStatus(arr[0]);
			SchedulerRequest.setPlatformName(schedulerRequestDto.getPlatformName());
			SchedulerRequest.setReminderPeriod(schedulerRequestDto.getReminderPeriod());
			SchedulerRequest.setTimeInterval(schedulerRequestDto.getTimeInterval());
			Trigger oldTrigger = null;
			if(arr.length > 1) {
				SchedulerRequest.setClaimId(Integer.parseInt(arr[1]));
				SchedulerRequest.setIsReceivable(Boolean.getBoolean(arr[2]));
				oldTrigger = scheduler.getTrigger(new TriggerKey(group, group));
			} else {
				SchedulerRequest.setClaimId(-1);
				SchedulerRequest.setIsReceivable(false);
				oldTrigger = scheduler.getTrigger(new TriggerKey(SchedulerRequest.getStatus(), SchedulerRequest.getStatus()));
			}
			SchedulerRequest.setTimeInterval(schedulerRequestDto.getTimeInterval());
			if(oldTrigger != null) {
				Date nextTime = oldTrigger.getNextFireTime();
				Date addedTime = getCurrentDateWithaddedHours(schedulerRequestDto.getReminderPeriod());
				if (nextTime.compareTo(addedTime) > 0) {
					scheduler.unscheduleJob(oldTrigger.getKey());
					SchedulerRequest.setNextTriggerTime(nextTime);
					CustomTriggerBuilder customTriggerBuilder = schedulerFactory.getTriggerBuilder(SchedulerRequest);
					Trigger newTrigger = customTriggerBuilder.getTrigger(SchedulerRequest);
					Set<Trigger> triggerSet = new HashSet<Trigger>();
					triggerSet.add(newTrigger);
					JobDetail job = schedulerUtil.getJobDetailBySchedulerType(SchedulerRequest);
					scheduler.scheduleJob(job, triggerSet, true);
				} else if (nextTime.compareTo(addedTime) < 0) {
					notificationScheduler.executeJob(group, schedulerRequestDto.getPlatformName(), schedulerRequestDto.getAssociationId(), null);
					scheduler.unscheduleJob(oldTrigger.getKey());
					CustomTriggerBuilder customTriggerBuilder = schedulerFactory.getTriggerBuilder(SchedulerRequest);
					Trigger newTrigger = customTriggerBuilder.getTrigger(SchedulerRequest);
					Set<Trigger> triggerSet = new HashSet<Trigger>();
					triggerSet.add(newTrigger);
					JobDetail job = schedulerUtil.getJobDetailBySchedulerType(SchedulerRequest);
					scheduler.scheduleJob(job, triggerSet, true);
	
				}
			}
		}
	}

	/**
	 * @param timeInterval
	 * @return
	 */
	public Date getCurrentDateWithaddedHours(Integer timeInterval) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());
		calendar.add(Calendar.MINUTE, timeInterval);
		return calendar.getTime();
	}

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		// TODO Auto-generated method stub

	}

}
