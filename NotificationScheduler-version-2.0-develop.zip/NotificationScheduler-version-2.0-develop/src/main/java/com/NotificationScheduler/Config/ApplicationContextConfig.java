package com.NotificationScheduler.Config;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.NotificationScheduler.Factory.CustomJobFactory;
import com.NotificationScheduler.Models.NotificationDto;
import com.NotificationScheduler.TriggerBuilder.QuartzPropertyBuilder;

/**
 * The Class ApplicationContextConfig.
 */
@Configuration
@EnableTransactionManagement
public class ApplicationContextConfig {
	
	/** The Quartz property builder. */
	@Autowired
	private QuartzPropertyBuilder QuartzPropertyBuilder;
	
	/** The kafka producer url. */
	@Value("${kafka.producer.url}")
	private String kafkaProducerUrl;
	
	/** The custom job factory. */
	@Autowired
	private CustomJobFactory customJobFactory;
	
	/**
	 * Scheduler factory bean.
	 *
	 * @return the scheduler factory bean
	 * @throws SchedulerException the scheduler exception
	 */
	@Bean
	public SchedulerFactoryBean schedulerFactoryBean() throws SchedulerException {
        SchedulerFactoryBean schedulerFactoryBean = new SchedulerFactoryBean();
        schedulerFactoryBean.setJobFactory(customJobFactory);
        schedulerFactoryBean.setQuartzProperties(QuartzPropertyBuilder.getProperties());
        return schedulerFactoryBean;
    }
	
	/**
	 * Producer factory.
	 *
	 * @return the producer factory
	 */
	@Bean
	public ProducerFactory<String, NotificationDto> producerFactory() {
		Map<String, Object> config = new HashMap<>();
		config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaProducerUrl);
		config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
		return new DefaultKafkaProducerFactory<>(config);
	}

	/**
	 * Kafka template.
	 *
	 * @return the kafka template
	 */
	@Bean
	public KafkaTemplate<String, NotificationDto> kafkaTemplate() {
		return new KafkaTemplate<>(producerFactory());
	}

	/**
	 * Scheduler.
	 *
	 * @return the scheduler
	 * @throws SchedulerException the scheduler exception
	 */
	@Bean
	public Scheduler scheduler() throws SchedulerException {
		return schedulerFactoryBean().getScheduler();
	}
}
