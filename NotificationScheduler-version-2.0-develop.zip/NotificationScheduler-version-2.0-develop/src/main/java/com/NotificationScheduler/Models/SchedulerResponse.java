package com.NotificationScheduler.Models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class SchedulerResponse.
 */
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SchedulerResponse {

	/** The schedule status. */
	private ScheduleStatus scheduleStatus;
}
