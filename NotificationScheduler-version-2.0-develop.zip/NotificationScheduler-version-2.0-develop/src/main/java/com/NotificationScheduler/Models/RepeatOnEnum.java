package com.NotificationScheduler.Models;

public enum RepeatOnEnum {
	FIRST, SECOND, THIRD, FOURTH, FIFTH
}
