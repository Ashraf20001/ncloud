package com.NotificationScheduler.Models;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum PlatformEnum {
	
	RECOVERY_EZ(1, "Recover EZ"), DIGITAL_PAPER(2, "Digital Paper"), DATA_LAKE(3, "Data Lake");

	private Integer platformId;
	
	private String platformName;
	
	/**
	 * @param statusDesc
	 * @return
	 */
	public static Integer getPlatformIdByName(String platformName) {
		for (PlatformEnum enums : PlatformEnum.values()) {
			if (enums.getPlatformName().equals(platformName)) {
				return enums.getPlatformId();
			}
		}
		return null;
	}
	public static String getPlatformNameById(Integer platformId) {
		for (PlatformEnum enums : PlatformEnum.values()) {
			if (enums.getPlatformId().equals(platformId)) {
				return enums.getPlatformName();
			}
		}
		return null;
	}
}
