package com.NotificationScheduler.Models;

public enum MonthEnum {
	JAN, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC
}
