package com.NotificationScheduler.Models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

/**
 * The Class NotificationDto.
 */
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class NotificationDto {
	
	/** The status. */
	private String status;
	
	/** The claim id. */
	private Integer claimId;
	
	/** The claim sequence id. */
	private String claimSequenceId;
	
	/** The company name. */
	private String companyName;
	
	/** The is receivable. */
	private String isReceivable;
	
	/** The logo url. */
	private String logoUrl;
	
	/** The last acted. */
	private String lastActed;
	
	/** The association id. */
	private Integer associationId;
	
	/** The from date. */
	private Date fromDate;
	
	/** The to date. */
	private Date toDate;
	
	/** The platform id. */
	private Integer platformId;
	
	/** The user identity. */
	private String userIdentity;

}
