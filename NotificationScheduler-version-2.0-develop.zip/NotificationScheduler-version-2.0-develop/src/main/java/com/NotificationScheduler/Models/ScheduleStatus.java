package com.NotificationScheduler.Models;

public enum ScheduleStatus {
	
	COMPLETED,FAILED

}
