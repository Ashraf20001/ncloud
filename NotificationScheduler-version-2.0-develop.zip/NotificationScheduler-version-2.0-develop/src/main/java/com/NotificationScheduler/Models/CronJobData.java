package com.NotificationScheduler.Models;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class CronJobData.
 */
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class CronJobData {

	/** The start date with time. */
	private String startDateWithTime;
	
	/** The repeat count. */
	private Integer repeatCount;
	
	/** The repeat format. */
	private RepeatFormatEnum repeatFormat;
	
	/** The selected days. */
	private List<DayEnum> selectedDays;
	
	/** The selected date. */
	private Integer selectedDate;
	
	/** The repeat on. */
	private RepeatOnEnum repeatOn;
	
	/** The repeat on day. */
	private DayEnum repeatOnDay;
	
	/** The selected month. */
	private MonthEnum selectedMonth;
	
	/** The end date. */
	private String endDate;
}
