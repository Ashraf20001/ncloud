package com.NotificationScheduler.Models;

public enum DayEnum {
	SUN, MON, TUE, WED, THU, FRI, SAT
}
