package com.NotificationScheduler.Models;

public enum RepeatFormatEnum {
	DAY, WEEK, MONTH, YEAR
}
