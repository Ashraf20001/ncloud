package com.NotificationScheduler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

/**
 * The Class NotificationSchedulerApplication.
 */
@SpringBootApplication(exclude={DataSourceAutoConfiguration.class})
public class NotificationSchedulerApplication {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
	SpringApplication.run(NotificationSchedulerApplication.class, args);
	}

}
