package com.recoveryportal.bulkImportConsumer.dto;

import java.util.List;

import lombok.Data;

@Data
public class UserInfo {
	
	public static Integer userid;

	public static String name;

	private Integer id;

	private String username;

	private String email;

	private boolean firstTimeLogin;

	private String identity;
	
	private UserType userTypeId;
	
	private  PlatformDetailsDto platformDetailsDto;
	
	private String platformIdentity;
	
	private List<UserRoleDto> roles;
	
	private Integer companyId;
	
	private String companyName;
	
	private Integer allocationUserType;
	
	private Integer associationId;

}
