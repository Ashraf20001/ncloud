package com.recoveryportal.bulkImportConsumer.KafkaListner;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.recoveryportal.bulkImportConsumer.dto.BulkImportTriggerConsumerDto;
import com.recoveryportal.bulkImportConsumer.dto.DataLakeBulkUploadDto;
import com.recoveryportal.bulkImportConsumer.dto.StockDto;
import com.recoveryportal.bulkImportConsumer.exception.ApplicationException;
import com.recoveryportal.bulkImportConsumer.service.BulkImportConsumerService;
import com.recoveryportal.bulkImportConsumer.service.StockRemainderService;
import com.recoveryportal.bulkImportConsumer.service.Impl.BulkImportConsumerServiceImpl;

@Service
public class BulkImportListner {
	
	/**
	 * The Constant logger.
	 */
	private static final Logger logger = LoggerFactory.getLogger(BulkImportConsumerServiceImpl.class);

	@Autowired
	private BulkImportConsumerService bulkImportConsumerService;
	
	@Autowired
	private StockRemainderService stockRemainderService;
	
	/**
	 * Listens to the "dp-bulkimport-events" Kafka topic and processes bulk import notifications.
	 *
	 * This method deserializes the incoming Kafka message into a {@link BulkImportTriggerConsumerDto} 
	 * and updates the bulk import history status.
	 *
	 * @param object         the JSON string received from Kafka.
	 * @param acknowledgment the acknowledgment object for manual offset committing.
	 * @throws InvalidFormatException if the message format is invalid.
	 * @throws ApplicationException   if an application-level error occurs.
	 * @throws IOException            if an error occurs while processing the message.
	 */
	@KafkaListener(topics = "dp-bulkimport-events")
	public void NotificationConsumer(String object,Acknowledgment acknowledgment)
			throws InvalidFormatException, ApplicationException, IOException {
		logger.info("drop  of digital paper bulk import object recieved.......................");
		acknowledgment.acknowledge();
		ObjectMapper objectMapper = new ObjectMapper();
		BulkImportTriggerConsumerDto bulkImportTriggerConsumerDto = objectMapper.readValue(object, BulkImportTriggerConsumerDto.class);
		bulkImportConsumerService.updateStatusOfBulkImportHistory(bulkImportTriggerConsumerDto);
	}
	
	
	/**
	 * Listens to the "dl_event" Kafka topic and processes bulk upload events.
	 *
	 * This method deserializes the incoming Kafka message into a {@link DataLakeBulkUploadDto} 
	 * and triggers the bulk upload consumer service.
	 *
	 * @param object         the JSON string received from Kafka.
	 * @param acknowledgment the acknowledgment object for manual offset committing.
	 * @throws ApplicationException   if an application-level error occurs.
	 * @throws FileNotFoundException if the file related to the event is not found.
	 * @throws IOException            if an error occurs while processing the message.
	 */
	@KafkaListener(topics = "dl_event", groupId = "test-group")
	public void bulkUploadConsumer(String object, Acknowledgment acknowledgment) throws ApplicationException, FileNotFoundException, IOException {
		logger.info("drop object recieved.......................");
		acknowledgment.acknowledge();
		ObjectMapper objectMapper = new ObjectMapper();
		DataLakeBulkUploadDto dataLakeBulkUploadDto = objectMapper.readValue(object, DataLakeBulkUploadDto.class);
		bulkImportConsumerService.bulkUploadConsumer(dataLakeBulkUploadDto);
	}
	
	/**
	 * Listens to the "stock-email-topic" Kafka topic and processes stock email notifications.
	 *
	 * This method deserializes the incoming Kafka message into a {@link StockDto} 
	 * and triggers the stock remainder service to send stock details to the main application.
	 *
	 * @param stock          the JSON string received from Kafka.
	 * @param acknowledgment the acknowledgment object for manual offset committing.
	 * @throws JsonMappingException  if the message format is incorrect.
	 * @throws JsonProcessingException if an error occurs while parsing JSON.
	 */
	 @KafkaListener(topics = "stock-email-topic")
	public void stockEmail(String stock, Acknowledgment acknowledgment) throws JsonMappingException, JsonProcessingException {
		logger.info("drop  of stock-email-topic received.......................");
		acknowledgment.acknowledge();
		ObjectMapper objectMapper = new ObjectMapper();
		StockDto stockObj = objectMapper.readValue(stock, StockDto.class);		
		stockRemainderService.sendStockDtoToMainApp(stockObj);
	}

}
