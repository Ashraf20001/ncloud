package com.recoveryportal.bulkImportConsumer.service;

import com.recoveryportal.bulkImportConsumer.dto.StockDto;

/**
 * The Interface StockRemainderService.
 */
public interface StockRemainderService {

	/**
	 * Send stock dto to main app.
	 *
	 * @param stockDto the stock dto
	 */
	public void sendStockDtoToMainApp(StockDto stockDto);
}
