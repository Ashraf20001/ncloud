package com.recoveryportal.bulkImportConsumer.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class PropertyValueProvider.
 */
@Component
@ConfigurationProperties(prefix = "ncbulk")
@Getter
@Setter
public class PropertyValueProvider {

	/** The file path. */
	private String filePath;
	
	/** The base url. */
	private String baseUrl;
	
}
