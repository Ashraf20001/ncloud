package com.recoveryportal.bulkImportConsumer.dto;

import java.io.Serializable;

import javax.servlet.http.HttpServletRequest;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BulkImportTriggerConsumerDto implements Serializable {
	private BulkImportHistoryDto bulkImportHistoryDto;
    private String pageIdentity;
    private String insurer;
    private Integer userId;
    private String bulkImportIdentity;
    private UserInfo userInfo;
    private String uploadType;
    private PoolCountDetails poolCountDetails;
    private String uploadAction;

}
