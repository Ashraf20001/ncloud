package com.recoveryportal.bulkImportConsumer.controller;

import com.recoveryportal.bulkImportConsumer.dto.BulkImportTriggerConsumerDto;
import com.recoveryportal.bulkImportConsumer.exception.ApplicationException;
import com.recoveryportal.bulkImportConsumer.service.BulkImportConsumerService;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

/**
 * The Class BulkImportcontroller.
 */
@RestController
public class BulkImportcontroller {
    
    /** The bulk import consumer service. */
    @Autowired
    private BulkImportConsumerService bulkImportConsumerService;

    
    /**
     * Updates the bulk upload history status via a REST API call, retrieves the file 
     * from the specified path, processes it as a map, and converts it to an Excel file.
     *
     * This method interacts with the bulk import service to update the status 
     * and process bulk data uploads.
     *
     * @param bulkImportTriggerConsumerDto the data transfer object containing bulk import details.
     * @param pageId                       the identifier of the page associated with the bulk import.
     * @param insurer                      the insurer associated with the bulk upload.
     * @param userId                       the ID of the user initiating the bulk upload.
     * @param bulkIdentity                 the unique identity of the bulk import operation.
     * @throws ApplicationException        if an application-level error occurs during processing.
     * @throws IOException                 if an I/O error occurs while retrieving or processing the file.
     * @throws InvalidFormatException      if the file format is invalid or unsupported.
     */
    @PostMapping("/api/auth/process-upload/bulk-upload")
    public void updateBulkUploadStatus(@RequestBody BulkImportTriggerConsumerDto bulkImportTriggerConsumerDto,
                                       @RequestParam("page_id") String pageId,
                                       @RequestParam("insurer") String insurer,
                                       @RequestParam("user_id") String userId,
                                       @RequestParam("bulk_import_identity") String bulkIdentity) throws ApplicationException, IOException, InvalidFormatException {
        bulkImportConsumerService.updateStatusOfBulkImportHistory(bulkImportTriggerConsumerDto);
    }
}
