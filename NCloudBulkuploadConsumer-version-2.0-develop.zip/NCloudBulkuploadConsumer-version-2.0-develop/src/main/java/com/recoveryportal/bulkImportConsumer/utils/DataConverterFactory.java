package com.recoveryportal.bulkImportConsumer.utils;


import com.recoveryportal.bulkImportConsumer.dto.DataTypeConstantsDto;
import com.recoveryportal.bulkImportConsumer.exception.ApplicationException;
import org.springframework.stereotype.Component;

import java.time.ZonedDateTime;

/**
 * A factory for creating DataConverter objects.
 */
@Component
public class DataConverterFactory {
	
	/**
	 * Data converter.
	 *
	 * @param type the type
	 * @param value the value
	 * @return the object
	 * @throws ApplicationException the application exception
	 */
	public Object dataConverter(String type,String value) throws ApplicationException {
		if (value.equals("") || value.isBlank() || value.isEmpty()){
			return null;
		}

		switch (type) {

			case DataTypeConstantsDto.DROPDOWN:
				case DataTypeConstantsDto.TEXT:
				case DataTypeConstantsDto.MULTI_SELECT:
					case DataTypeConstantsDto.DOWNLOAD:
						case DataTypeConstantsDto.FILE:
							case DataTypeConstantsDto.STRING:
				return value;

			case DataTypeConstantsDto.BOOLEAN:
				case DataTypeConstantsDto.CHECKBOX:
				case DataTypeConstantsDto.TOGGLE:
				return Boolean.parseBoolean(value);
			
			case DataTypeConstantsDto.INTEGER:
				return Integer.parseInt(value);

			case DataTypeConstantsDto.LONG:
				return Long.parseLong(value);

			case DataTypeConstantsDto.DOUBLE:
				return Double.parseDouble(value);
			
			case DataTypeConstantsDto.PDATE: 
			case DataTypeConstantsDto.FDATE: {
				return ZonedDateTime.parse(value).toLocalDateTime();
			}
		}
		return null;
		
	}
	
	
}
