package com.recoveryportal.bulkImportConsumer.constants;

/**
 * The Class ApplicationConstants.
 */
public class ApplicationConstants {
    
    /** The Constant ZERO. */
    public static final int ZERO = 0;
    
    /** The Constant HUNDRED. */
    public static final int HUNDRED = 100;
    
    /** The Constant THREE. */
    public static final int THREE = 3;
    
    /** The Constant FOUR. */
    public static final int FOUR = 4;
    
    /** The Constant REPLACE_PATH. */
    public static final String REPLACE_PATH = "BULK_IMPORT_IDENTITY";
    
    /** The Constant REPORTLOSS_BULK_IMPORT. */
    public static final String REPORTLOSS_BULK_IMPORT = "report-loss";
    
    /** The Constant PAPER_DETAILS_BULK_IMPORT. */
    public static final String PAPER_DETAILS_BULK_IMPORT = "paper-details";
    
    /** get resource file. */
    public static final String GET_RESOURCE = "/data-lake/bulk-upload/get-file-resource";
    
    
    /** VALIDATE_FILE. */
    public static final String VALIDATE_FILE = "/data-lake/bulk-upload/validate-file";
    
    /** The Constant AUTHORIZATION. */
    public static final String AUTHORIZATION = "Authorization";
    
    /** The Constant BEARER. */
    public static final String BEARER = "Bearer ";
    
    /** The Constant EMPTY_STRING. */
    public static final String EMPTY_STRING = " ";
	
	/** The Constant STOCK_REMAINDER_URL. */
	public static final String STOCK_REMAINDER_URL ="/digital-paper/send-stock-remainder" ;
}
