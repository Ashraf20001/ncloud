package com.recoveryportal.bulkImportConsumer.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BulkImportErrorDataDto {
    private Integer rowId;
    private String fieldName;
    private String errorId;
}
