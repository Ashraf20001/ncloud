package com.recoveryportal.bulkImportConsumer.utils;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The Class ApplicationUtils.
 */
public class ApplicationUtils {
    
    /**
     * Checks if is validate object.
     *
     * @param obj the obj
     * @return true, if is validate object
     */
    public static boolean isValidateObject(Object obj) {
        if (obj == null) {
            return false;
        }

        if (obj instanceof List<?> && ((Collection<?>) obj).isEmpty()) {
            return false;
        }

        if (obj instanceof Map<?, ?> && ((Map) obj).isEmpty()) {
            return false;
        }

        if (obj instanceof Set<?>) {
            return !((Set) obj).isEmpty();
        }

        return true;
    }
}
