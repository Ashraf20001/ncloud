package com.recoveryportal.bulkImportConsumer.dto;

import lombok.Data;

@Data
public class UserType {
	
	private Integer userTypeId;
	
	private String userTypeName;

}
