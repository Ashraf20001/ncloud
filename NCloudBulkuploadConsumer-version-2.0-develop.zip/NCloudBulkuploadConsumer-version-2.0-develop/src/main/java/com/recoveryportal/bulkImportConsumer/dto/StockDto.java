package com.recoveryportal.bulkImportConsumer.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class StockDto {

	 private Integer stockId;
	 private Integer stockCount;
	 private Integer usedCount;
	 private Integer companyId;
	 private LocalDateTime createdDate;
	 private String identity;
	 private Integer userTypeId;
	 private String userTypeName;
	 private String userTypeIdentity;
	 private Boolean isActive;
	 private Integer availableCount;
}
