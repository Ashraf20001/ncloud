package com.recoveryportal.bulkImportConsumer.service.Impl;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbookFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.recoveryportal.bulkImportConsumer.config.EnvironmentProperties;
import com.recoveryportal.bulkImportConsumer.constants.ApplicationConstants;
import com.recoveryportal.bulkImportConsumer.constants.ErrorCodes;
import com.recoveryportal.bulkImportConsumer.constants.TableConstants;
import com.recoveryportal.bulkImportConsumer.core.ApplicationResponse;
import com.recoveryportal.bulkImportConsumer.dto.BulkImportFieldList;
import com.recoveryportal.bulkImportConsumer.dto.BulkImportFieldValidationDto;
import com.recoveryportal.bulkImportConsumer.dto.BulkImportHistoryDto;
import com.recoveryportal.bulkImportConsumer.dto.BulkImportMappingDto;
import com.recoveryportal.bulkImportConsumer.dto.BulkImportTriggerConsumerDto;
import com.recoveryportal.bulkImportConsumer.dto.BulkUploadSuccessErrorList;
import com.recoveryportal.bulkImportConsumer.dto.DataLakeBulkUploadDto;
import com.recoveryportal.bulkImportConsumer.dto.DataLakeBulkUploadMapDto;
import com.recoveryportal.bulkImportConsumer.dto.FieldDto;
import com.recoveryportal.bulkImportConsumer.dto.PoolCountDetails;
import com.recoveryportal.bulkImportConsumer.dto.UserInfo;
import com.recoveryportal.bulkImportConsumer.exception.ApplicationException;
import com.recoveryportal.bulkImportConsumer.service.BulkImportConsumerService;
import com.recoveryportal.bulkImportConsumer.utils.ApplicationUtils;
import com.recoveryportal.bulkImportConsumer.utils.PlatformMapToBulkUploadIdentity;
import com.recoveryportal.bulkImportConsumer.utils.RestTemplateUtils;

/**
 * The Class BulkImportConsumerServiceImpl.
 */
@Service
public class BulkImportConsumerServiceImpl implements BulkImportConsumerService {
	
	/** The environment properties. */
	@Autowired
	EnvironmentProperties environmentProperties;
	
	/** The rest template utils. */
	@Autowired
	RestTemplateUtils restTemplateUtils;
	
	/** The rest template. */
	@Autowired
	RestTemplate restTemplate;

	/** The base url. */
	@Value("${ncbulk.base-url}")
	private String baseUrl;
	
	/** The bulk upload identity. */
	@Autowired
	private PlatformMapToBulkUploadIdentity bulkUploadIdentity;
	
	/**
	 * The Constant logger.
	 */
	private static final Logger logger = LoggerFactory.getLogger(BulkImportConsumerServiceImpl.class);
	
	/**
	 * Bulk upload consumer.
	 *
	 * @param dataLakeBulkUploadDto the data lake bulk upload dto
	 * @throws FileNotFoundException the file not found exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws ApplicationException the application exception
	 */
	@Override
	public void bulkUploadConsumer(DataLakeBulkUploadDto dataLakeBulkUploadDto) throws FileNotFoundException, IOException, ApplicationException {
		try {
			logger.info("Consumer service started.............................");
			HttpEntity <String> getFilePath = new HttpEntity<String>(restTemplateUtils.getGETHeaders());
			Resource file = buildMapForResrTemplateForDto(dataLakeBulkUploadDto.getFilePath(), getFilePath);
			InputStream fileInputStream = file.getInputStream();
			XSSFWorkbook xssfWorkbook = XSSFWorkbookFactory.createWorkbook(fileInputStream);
			DataLakeBulkUploadMapDto dataLakeBulkUploadMapDto = new DataLakeBulkUploadMapDto();
			List<HashMap<String, Object>>listOfExcelMap =  readExcelFile(xssfWorkbook, dataLakeBulkUploadDto, dataLakeBulkUploadMapDto);
			buildMapObjectForValidateRecords(dataLakeBulkUploadDto, listOfExcelMap, dataLakeBulkUploadMapDto);
			updateBulkUploadHistoryStatus(dataLakeBulkUploadDto, ApplicationConstants.THREE);
		} catch(Exception e) {
			e.printStackTrace();
			logger.error("Consumer Exception............................."+e.getMessage());
			updateBulkUploadHistoryStatus(dataLakeBulkUploadDto, ApplicationConstants.FOUR);
		}
	}

	/**
	 * Builds the map object for validate records.
	 *
	 * @param dataLakeBulkUploadDto the data lake bulk upload dto
	 * @param listOfExcelMap the list of excel map
	 * @param dataLakeBulkUploadMapDto the data lake bulk upload map dto
	 */
	private void buildMapObjectForValidateRecords(DataLakeBulkUploadDto dataLakeBulkUploadDto,
			List<HashMap<String, Object>> listOfExcelMap,DataLakeBulkUploadMapDto dataLakeBulkUploadMapDto) {
		logger.info("call to validate hashmap records.......");
		HttpEntity <DataLakeBulkUploadMapDto> entity = new HttpEntity<DataLakeBulkUploadMapDto>(dataLakeBulkUploadMapDto, restTemplateUtils.getPOSTHeaders());
		Map<String, Object> param = new HashMap<>();
		param.put("repositoryName", dataLakeBulkUploadDto.getRepositoryName());
		param.put("userId", dataLakeBulkUploadDto.getUserInfo().getId());
		param.put("bulkUploadId", dataLakeBulkUploadDto.getBulkUploadId());
		String Path = ApplicationConstants.VALIDATE_FILE;
		String url = baseUrl + Path;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		for (Entry<String, Object> entryData : param.entrySet()) {
			builder.queryParam(entryData.getKey(), entryData.getValue());
		}
		restTemplate.exchange(
				builder.toUriString(), HttpMethod.POST, entity, String.class);
	}

	/**
	 * Builds the map for resr template for dto.
	 *
	 * @param fileName the file name
	 * @param entity2 the entity 2
	 * @return the resource
	 */
	private Resource buildMapForResrTemplateForDto(String fileName,
			HttpEntity<String> entity2) {
		Map<String, String> params = new HashMap<>();
		params.put("fileName", fileName);
		String replacePath = ApplicationConstants.GET_RESOURCE;
		String url2 = baseUrl + replacePath;
		UriComponentsBuilder builder2 = UriComponentsBuilder.fromHttpUrl(url2);
		for (Map.Entry<String, String> entry : params.entrySet()) {
			builder2.queryParam(entry.getKey(), entry.getValue());
		}
		return restTemplate.exchange(
				builder2.toUriString(), HttpMethod.GET, entity2, Resource.class).getBody();
	}
	
	/**
	 * Update bulk upload history status.
	 *
	 * @param dataLakeBulkUploadDto the data lake bulk upload dto
	 * @param status the status
	 * @return the bulk import trigger consumer dto
	 */
	private BulkImportTriggerConsumerDto updateBulkUploadHistoryStatus(DataLakeBulkUploadDto dataLakeBulkUploadDto , Integer status) {
		HttpEntity<DataLakeBulkUploadDto> updateStatusEntity = new HttpEntity<DataLakeBulkUploadDto>(dataLakeBulkUploadDto,restTemplateUtils.getPOSTHeaders());
		Map<String, Integer> params = new HashMap<>();
		params.put("userId", dataLakeBulkUploadDto.getUserInfo().getId());
		params.put("bulkUpload", dataLakeBulkUploadDto .getBulkUploadId());
		params.put("associationId", dataLakeBulkUploadDto.getUserInfo().getAssociationId());
		params.put("status", status);
		String replacePath = "/data-lake/bulk-upload/update-upload-status";
		String url2 = baseUrl + replacePath;
		UriComponentsBuilder builder2 = UriComponentsBuilder.fromHttpUrl(url2);
		for (Map.Entry<String, Integer> entry : params.entrySet()) {
			builder2.queryParam(entry.getKey(), entry.getValue());
		}

		BulkImportTriggerConsumerDto bulkImportTriggerConsumerDto = restTemplate.exchange(
				builder2.toUriString(), HttpMethod.POST, updateStatusEntity, BulkImportTriggerConsumerDto.class).getBody();
		return bulkImportTriggerConsumerDto;
	}
	
	/**
	 * Read excel file.
	 *
	 * @param workbook the workbook
	 * @param dataLakeBulkUploadDto the data lake bulk upload dto
	 * @param dataLakeBulkUploadMapDto the data lake bulk upload map dto
	 * @return the list
	 * @throws FileNotFoundException the file not found exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws ApplicationException the application exception
	 */
	public List<HashMap<String, Object>> readExcelFile(XSSFWorkbook workbook, DataLakeBulkUploadDto dataLakeBulkUploadDto, DataLakeBulkUploadMapDto dataLakeBulkUploadMapDto)
			throws FileNotFoundException, IOException, ApplicationException {
		List<HashMap<String, Object>> reponse = new ArrayList<>();
		List<HashMap<String, Object>> duplicateRows = new ArrayList<>();
		HashMap<Integer, String> headerMap = new LinkedHashMap<>();
		Sheet sheet = workbook.getSheetAt(ApplicationConstants.ZERO);
		Integer lastRowIndex = sheet.getLastRowNum();
		iterateExcelData(reponse, headerMap, sheet, lastRowIndex, dataLakeBulkUploadDto, duplicateRows,dataLakeBulkUploadMapDto);
		workbook.close();
		return reponse;
	}

	/**
	 * Iterate excel data.
	 *
	 * @param reponse the reponse
	 * @param headerMap the header map
	 * @param sheet the sheet
	 * @param lastRowIndex the last row index
	 * @param dataLakeBulkUploadDto the data lake bulk upload dto
	 * @param duplicateRows the duplicate rows
	 * @param dataLakeBulkUploadMapDto the data lake bulk upload map dto
	 * @throws ApplicationException the application exception
	 */
	private void iterateExcelData(List<HashMap<String, Object>> reponse, HashMap<Integer, String> headerMap, Sheet sheet,
			Integer lastRowIndex, DataLakeBulkUploadDto dataLakeBulkUploadDto, List<HashMap<String, Object>> duplicateRows, DataLakeBulkUploadMapDto dataLakeBulkUploadMapDto) throws ApplicationException {
		logger.info("convert file to hashmap ...............");
		int processLimits = 0;
		for (int rowIndex = 0; rowIndex < lastRowIndex + 1; rowIndex++) {
			Row row = sheet.getRow(rowIndex);
			if (rowIndex == ApplicationConstants.ZERO) {
				Integer totalCellCount = (int) row.getLastCellNum();
				for (int cellIndex = 0; cellIndex < totalCellCount; cellIndex++) {
					Cell headerCell = row.getCell(cellIndex);
					if (!headerCell.toString().isBlank()) {
						headerMap.put(cellIndex, headerCell.toString());
					}
				}
				continue;
			}

			Integer index = 0;
			HashMap<String, Object> excelDataMap = new HashMap<>();
			if (ApplicationUtils.isValidateObject(row)) {
			for (int i = 0; i < headerMap.size(); i++) {
					Cell cell1 = row.getCell(i);
					CellType cellType = cell1.getCellType();
					String key = headerMap.get(i);
					
					if (cell1 == null) {
						excelDataMap.put(key, "");
					} else {
						if(cellType.equals(CellType.NUMERIC)) {
							excelDataMap.put(key, (long)cell1.getNumericCellValue());
						}else {	
							excelDataMap.put(key, cell1.toString());
						}
					}
					index++;
				}
			if (ApplicationUtils.isValidateObject(row) && reponse.contains(excelDataMap)) {
				duplicateRows.add(excelDataMap);
			} else if (ApplicationUtils.isValidateObject(row)) {
				reponse.add(excelDataMap);
			}
			}
			processLimits++;
			dataLakeBulkUploadMapDto.setDuplicateRows(duplicateRows);
			dataLakeBulkUploadMapDto.setUniqueRows(reponse);
			if (processLimits % ApplicationConstants.HUNDRED == ApplicationConstants.ZERO) { // 100 should be configureable
				logger.info("100 batch of hashmap to data lake for validate......");
					buildMapObjectForValidateRecords(dataLakeBulkUploadDto, reponse, dataLakeBulkUploadMapDto);
					reponse.clear();
			}
		}
	}

	/**
	 * Update status of bulk import history.
	 *
	 * @param bulkImportTriggerConsumerDto the bulk import trigger consumer dto
	 * @throws ApplicationException the application exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws InvalidFormatException the invalid format exception
	 */
	@Override
	public void updateStatusOfBulkImportHistory(BulkImportTriggerConsumerDto bulkImportTriggerConsumerDto) throws ApplicationException, IOException, InvalidFormatException {
		String pageId=bulkImportTriggerConsumerDto.getPageIdentity();
		 String insurer=bulkImportTriggerConsumerDto.getInsurer();
		 String userId=bulkImportTriggerConsumerDto.getUserId()+"";
		 String bulkIdentity=bulkImportTriggerConsumerDto.getBulkImportIdentity()+"";
		if (!ApplicationUtils.isValidateObject(bulkImportTriggerConsumerDto.getBulkImportHistoryDto())){
			throw new ApplicationException(ErrorCodes.INVALID_BULK_IMPORT_HISTORY);
		}
		
		BulkImportHistoryDto bulkImportHistoryDto = bulkImportTriggerConsumerDto.getBulkImportHistoryDto();
		//update initial history count
		bulkImportHistoryDto.setStatus(TableConstants.STATUS_IN_PROGRESS);
		updateImportHistory(bulkImportHistoryDto,bulkIdentity);
		try{
			//get file location
			String filePath = getFileLocationByUploadId(bulkImportHistoryDto,bulkIdentity);
			insurer = insurer!=null?insurer.replace("%20"," "):null;
			processFileFromPath(filePath, bulkImportHistoryDto, pageId,insurer,userId,bulkIdentity,bulkImportTriggerConsumerDto.getUserInfo(),bulkImportTriggerConsumerDto.getUploadType(),bulkImportTriggerConsumerDto.getPoolCountDetails(),bulkImportTriggerConsumerDto.getUploadAction());
		} catch (Exception e){
			System.err.println(e);
			bulkImportHistoryDto.setStatus(TableConstants.ERROR_FAILED);
			updateImportHistory(bulkImportHistoryDto,bulkIdentity);
		}

	}

	/**
	 * Update import history.
	 *
	 * @param bulkImportHistoryDto the bulk import history dto
	 * @param bulkIdentity the bulk identity
	 */
	public void updateImportHistory(BulkImportHistoryDto bulkImportHistoryDto, String bulkIdentity){

		HttpEntity<BulkImportHistoryDto> entity = new HttpEntity<BulkImportHistoryDto>(bulkImportHistoryDto,restTemplateUtils.getPOSTHeaders());
		String replacePath = TableConstants.UPDATE_IMPORT_HISTORY.replace(ApplicationConstants.REPLACE_PATH, bulkIdentity);
		String url = baseUrl + replacePath;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);

		restTemplate.exchange(
				builder.toUriString(), HttpMethod.POST, entity, BulkImportHistoryDto.class).getBody();
	}

	/**
	 * Gets the file location by upload id.
	 *
	 * @param bulkImportHistoryDto the bulk import history dto
	 * @param bulkIdentity the bulk identity
	 * @return the file location by upload id
	 */
	private String getFileLocationByUploadId(BulkImportHistoryDto bulkImportHistoryDto, String bulkIdentity) {

		HttpEntity <String> entity2 = new HttpEntity<String>(restTemplateUtils.getGETHeaders());

		Map<String, Integer> params = new HashMap<>();
		params.put("upload_id", bulkImportHistoryDto.getUploadId());
		String replacePath = TableConstants.BULK_IMPORT_GET_FILE_PATH.replace(ApplicationConstants.REPLACE_PATH, bulkIdentity);
		String url2 = baseUrl + replacePath;
		UriComponentsBuilder builder2 = UriComponentsBuilder.fromHttpUrl(url2);
		for (Map.Entry<String, Integer> entry : params.entrySet()) {
			builder2.queryParam(entry.getKey(), entry.getValue());
		}

		ApplicationResponse x2 = restTemplate.exchange(
				builder2.toUriString(), HttpMethod.GET, entity2, ApplicationResponse.class).getBody();
		System.out.println((String) x2.getContent());
		return x2.getContent();
	}

	/**
	 * Process file from path.
	 *
	 * @param filePath the file path
	 * @param bulkImportHistoryDto the bulk import history dto
	 * @param pageId the page id
	 * @param insurer the insurer
	 * @param userId the user id
	 * @param bulkIdentity the bulk identity
	 * @param userInfo the user info
	 * @param uploadType the upload type
	 * @param poolCountDetails the pool count details
	 * @param uploadAction the upload action
	 * @throws ApplicationException the application exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws InvalidFormatException the invalid format exception
	 */
	private void processFileFromPath(String filePath, BulkImportHistoryDto bulkImportHistoryDto, String pageId, String insurer,String userId,String bulkIdentity,UserInfo userInfo, String uploadType,PoolCountDetails poolCountDetails,String uploadAction ) throws ApplicationException, IOException, InvalidFormatException {
		if(!ApplicationUtils.isValidateObject(filePath)){
			throw new ApplicationException(ErrorCodes.INVALID_PATH);
		}
		String path =environmentProperties.getFilePathOfReportLoss()+filePath;

		BulkImportFieldList metaDataFieldsByPageId = getMetaDataFieldsByPageId(pageId,bulkIdentity);
		List<FieldDto> fieldList = metaDataFieldsByPageId.getListOfField();
		List<BulkImportMappingDto> bulkImportMapping = metaDataFieldsByPageId.getBulkImportMapping();
		// looping
		ConvertExcelIntoMap(fieldList,path,bulkImportHistoryDto,pageId,insurer,userId,bulkImportMapping,bulkIdentity,userInfo,uploadType,poolCountDetails,uploadAction);

	}

	/**
	 * Gets the meta data fields by page id.
	 *
	 * @param pageId the page id
	 * @param bulkIdentity the bulk identity
	 * @return the meta data fields by page id
	 */
	private BulkImportFieldList getMetaDataFieldsByPageId(String pageId, String bulkIdentity) {

		HttpEntity <String> entity3= new HttpEntity<String>(restTemplateUtils.getGETHeaders());
		
		Integer platformId = bulkUploadIdentity.getPlatformId(bulkIdentity);

		Map<String, String> params = new HashMap<>();
		params.put("page_id",pageId);
		params.put("platform_id",platformId.toString());
		String replacePath = TableConstants.GET_FIELD_LIST.replace(ApplicationConstants.REPLACE_PATH, bulkIdentity);
		String url3 =  baseUrl + replacePath;
		UriComponentsBuilder builder3 = UriComponentsBuilder.fromHttpUrl(url3);
		for (Map.Entry<String, String> entry : params.entrySet()) {
			builder3.queryParam(entry.getKey(), entry.getValue());
		}

		ResponseEntity<BulkImportFieldList> res = restTemplate.exchange(
				builder3.toUriString(), HttpMethod.GET, entity3, BulkImportFieldList.class);
		BulkImportFieldList x3 = res.getBody();
		return x3;
	}

	/**
	 * Convert excel into map.
	 *
	 * @param fieldDtoList the field dto list
	 * @param path the path
	 * @param bulkImportHistoryDto the bulk import history dto
	 * @param filePath the file path
	 * @param insurer the insurer
	 * @param userId the user id
	 * @param bulkImportMapping the bulk import mapping
	 * @param bulkIdentity the bulk identity
	 * @param userInfo the user info
	 * @param uploadType the upload type
	 * @param poolCountDetails the pool count details
	 * @param uploadAction the upload action
	 */
	private void ConvertExcelIntoMap(List<FieldDto> fieldDtoList, String path,
			BulkImportHistoryDto bulkImportHistoryDto, String filePath, String insurer, String userId,List<BulkImportMappingDto> bulkImportMapping,String bulkIdentity,UserInfo userInfo, String uploadType, PoolCountDetails poolCountDetails, String uploadAction) {
		Map<String, String> bulkImportMap = new HashMap<>();
		for (BulkImportMappingDto bulkImportMappingDto : bulkImportMapping) {
			bulkImportMap.put(bulkImportMappingDto.getBulkImportAliasName(), bulkImportMappingDto.getBulkImportFieldName());
		}
		try {
			
			FileInputStream fileInputStream = new FileInputStream(path);
			BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
			XSSFWorkbook workbook = new XSSFWorkbook(bufferedInputStream);

			Sheet sheet = workbook.getSheetAt(0);
			Integer lastRowNum = sheet.getLastRowNum();

			Iterator<Row> rows = sheet.iterator();
			int rowNumber = 0;
			List<Map<String,String>> listOfMap = new ArrayList<>();


			Row  row = sheet.getRow(0);

			int minColIx = row.getFirstCellNum();
			int maxColIx = row.getLastCellNum();

			int processLimit = 0;
			int initialRowOfEachProcess = 0;
			int totalCount =0;
			processLimit=0;
			while ( rows.hasNext() && rowNumber <= (lastRowNum+1)) {
				Map<String, String> map = new HashMap<String,String>();
				if (rowNumber == 0) {
					rowNumber++;
					continue;
				}
				Row  row1 = sheet.getRow(rowNumber);
				
				if (row1==null || processLimit ==TableConstants.PROCESS_LIMIT){
					Boolean isLastProcess = false;
					if (row1 == null) {
						isLastProcess = true;
					}
					validateFieldValue(userId, bulkImportHistoryDto, listOfMap, fieldDtoList, initialRowOfEachProcess,
							insurer, bulkIdentity, userInfo, uploadType, lastRowNum, poolCountDetails, isLastProcess,
							uploadAction);
					initialRowOfEachProcess = rowNumber;
					listOfMap.clear();

					if (row1==null) {
						bulkImportHistoryDto.setStatus(TableConstants.STATUS_COMPLETED);
						updateImportHistory(bulkImportHistoryDto,bulkIdentity);
						return;
					}else {
						updateImportHistory(bulkImportHistoryDto,bulkIdentity);
					}
				}

				

				for(int colIx=minColIx; colIx<maxColIx; colIx++) {

					Cell cell = row.getCell(colIx);
					Cell cell1 = row1.getCell(colIx);
					if(cell1 != null) {
						cell.setCellType(CellType.STRING);
						cell1.setCellType(CellType.STRING);
						map.put(bulkImportMap.get(cell.getStringCellValue()).trim(),cell1.getStringCellValue().trim());
					}
				}
				listOfMap.add(map);
				rowNumber++;
				processLimit++;
			}

			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(TableConstants.ERMSG_PARSE_EXCEL + e.getMessage());
		}
	}

	/**
	 * Validate field value.
	 *
	 * @param userId the user id
	 * @param bulkImportHistoryDto the bulk import history dto
	 * @param mapList the map list
	 * @param fieldList the field list
	 * @param initialRowNumber the initial row number
	 * @param insurerName the insurer name
	 * @param bulkIdentity the bulk identity
	 * @param userInfo the user info
	 * @param uploadType the upload type
	 * @param lastRowNum the last row num
	 * @param poolCountDetails the pool count details
	 * @param isLastProcess the is last process
	 * @param uploadAction the upload action
	 * @return the bulk upload success error list
	 * @throws Exception the exception
	 */
	BulkUploadSuccessErrorList validateFieldValue(String userId, BulkImportHistoryDto bulkImportHistoryDto, List<Map<String,String>> mapList,
			List<FieldDto> fieldList, Integer initialRowNumber,String insurerName, String bulkIdentity,UserInfo userInfo, 
					String uploadType, Integer lastRowNum, PoolCountDetails poolCountDetails,Boolean isLastProcess,String uploadAction) throws Exception {

		BulkImportFieldValidationDto validationDto = new BulkImportFieldValidationDto();
		validationDto.setUserId(userId);
		validationDto.setBulkImportHistoryDto(bulkImportHistoryDto);
		validationDto.setMapList(mapList);
		validationDto.setFieldList(fieldList);
		validationDto.setInitialRowNumber(initialRowNumber);
		validationDto.setInsurerName(insurerName);
		validationDto.setUploadType(uploadType);
		validationDto.setUserInfo(userInfo);
		validationDto.setTotalRowInExcel(lastRowNum);
		validationDto.setPoolCountDetails(poolCountDetails);
		validationDto.setIsLastProcess(isLastProcess);
		validationDto.setUploadAction(uploadAction);

		//rest call for field validation
		HttpEntity<BulkImportFieldValidationDto> entity5 = new HttpEntity<BulkImportFieldValidationDto>(validationDto,restTemplateUtils.getPOSTHeaders());
		String replacePath = TableConstants.BULK_IMPORT_VALIDATE_FIELDS.replace(ApplicationConstants.REPLACE_PATH, bulkIdentity);
		String url5 =  baseUrl + replacePath;

		UriComponentsBuilder builder5 = UriComponentsBuilder.fromHttpUrl(url5);

		ResponseEntity<BulkUploadSuccessErrorList> response = restTemplate.exchange(
				builder5.toUriString(), HttpMethod.POST, entity5, BulkUploadSuccessErrorList.class);
		return response.getBody();
	}


	/**
	 * Sets the base url.
	 *
	 * @param baseUrl the new base url
	 */
	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}
}
