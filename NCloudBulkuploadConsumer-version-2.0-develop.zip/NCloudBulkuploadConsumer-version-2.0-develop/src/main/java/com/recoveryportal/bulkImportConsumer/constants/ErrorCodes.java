package com.recoveryportal.bulkImportConsumer.constants;

import com.recoveryportal.bulkImportConsumer.exception.ErrorId;

/**
 * The Class ErrorCodes.
 */
public class ErrorCodes {
    
    /** The Constant INVALID_BULK_IMPORT_HISTORY. */
    public static final ErrorId INVALID_BULK_IMPORT_HISTORY = new ErrorId("E8001","Invalid Bulk Import History");
    
    /** The Constant INVALID_PATH. */
    public static final ErrorId INVALID_PATH = new ErrorId("E8002","Invalid Path");

}
