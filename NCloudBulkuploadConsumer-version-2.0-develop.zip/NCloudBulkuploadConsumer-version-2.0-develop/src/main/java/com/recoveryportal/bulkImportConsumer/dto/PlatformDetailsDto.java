package com.recoveryportal.bulkImportConsumer.dto;

import lombok.Data;

@Data
public class PlatformDetailsDto {

	private Integer platformId;

	private String platformName;

	private String platformIdentity;
	
	private String platformUrl;
	
    private String platformLogoPath;

}
