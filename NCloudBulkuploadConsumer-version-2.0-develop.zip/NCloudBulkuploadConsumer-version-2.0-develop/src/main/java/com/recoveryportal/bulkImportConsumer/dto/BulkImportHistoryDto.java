package com.recoveryportal.bulkImportConsumer.dto;

import java.time.LocalDateTime;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BulkImportHistoryDto {
	private String uploadImageName;
    private Integer uploadId;
    private Integer successCount=0;
    private Integer failureCount=0;
    private Integer totalCount=0;
    private String status;
    private Integer pageId;
    private String createdBy;
    private String createdDate;
    private String identity;
    private Integer poolId;
    private Integer platformId;
    private Integer uploadType;
    private String url;
    private Integer actionType;
}
