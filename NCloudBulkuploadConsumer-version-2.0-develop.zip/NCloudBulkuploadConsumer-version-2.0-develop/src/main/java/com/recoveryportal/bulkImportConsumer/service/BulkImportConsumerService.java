package com.recoveryportal.bulkImportConsumer.service;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.recoveryportal.bulkImportConsumer.dto.BulkImportTriggerConsumerDto;
import com.recoveryportal.bulkImportConsumer.dto.DataLakeBulkUploadDto;
import com.recoveryportal.bulkImportConsumer.exception.ApplicationException;

/**
 * The Interface BulkImportConsumerService.
 */
public interface BulkImportConsumerService {
    
    /**
     * Update status of bulk import history.
     *
     * @param bulkImportTriggerConsumerDto the bulk import trigger consumer dto
     * @throws ApplicationException the application exception
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws InvalidFormatException the invalid format exception
     */
    void updateStatusOfBulkImportHistory(BulkImportTriggerConsumerDto bulkImportTriggerConsumerDto) throws ApplicationException, IOException, InvalidFormatException;

	/**
	 * Bulk upload consumer.
	 *
	 * @param dataLakeBulkUploadDto the data lake bulk upload dto
	 * @throws FileNotFoundException the file not found exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws ApplicationException the application exception
	 */
	void bulkUploadConsumer(DataLakeBulkUploadDto dataLakeBulkUploadDto) throws FileNotFoundException, IOException, ApplicationException;
}
