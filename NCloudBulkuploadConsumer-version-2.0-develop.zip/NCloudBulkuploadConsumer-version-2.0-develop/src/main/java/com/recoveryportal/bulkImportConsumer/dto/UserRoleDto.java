package com.recoveryportal.bulkImportConsumer.dto;

import lombok.Data;

@Data
public class UserRoleDto {

	private Integer roleId;

	private String roleName;
	
	private Integer allocationUserType;

}
