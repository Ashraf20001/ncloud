package com.recoveryportal.bulkImportConsumer.dto;

import lombok.Data;

@Data
public class PoolCountDetails {
	
	private Integer reservedPaperCount;
	private Integer successPaperGenerateCount;
	private Integer failedPaperGenerateCount;

}
