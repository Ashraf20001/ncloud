package com.recoveryportal.bulkImportConsumer.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BulkImportTempData {
	//claimDetails
    private Integer uploadDataId;
    private Integer uploadId;
    private Boolean status;
    private String errorDescription;
    private String insurerName;
    
    //InsurerInfo
    private String inRegistrationNo;
    private String inMake;
    private String inModel;
    private String inPurchaseDate;
    private String inSumInsured;
    //ThirdPartyInfo
    private String tpName;
    private String tpPolicyNumber;
    private String tpClaimNo;
    private String tpRegistrationNo;
    private String tpRegistrationType;
    private String tpMake;
    private String tpModel;
    //loss details
    private String ldDateOfLoss;
    private String ldClaimNumber;
    private String ldReportedDate;
    private String ldPolicyNumber;
    private String ldReserveAmount;
    private String ldPoliceReportNumber;
    private String ldIsTotalLoss;
    //garageInfo
    private String garageName;
    private String garageLocation;
    private String garageContactDetails;
    private String garageType;
    private String garageInvoiceName;
    //survey Details
    private String sdSurveyAllocationDate;
    private String sdSurveyDueDate;
    private String sdSurveyReportName;
    //survey report
    private String srTotalLoss;
    private String srSpareParts;
    private String srLabourCost	;
    private String srSurveyAmount;
    private String identity;
    private LocalDateTime createdDate;
    private Integer createdBy;
    private LocalDateTime modifiedDate;
    private Integer modifiedBy;
    private Boolean isDeleted = false;
}