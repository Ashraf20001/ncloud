package com.recoveryportal.bulkImportConsumer.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class BulkUploadSuccessErrorList {
    private List<ReportLossDto> reportLossList;
    private List<BulkImportErrorDataDto> errorList;
    private List<BulkImportTempData> bulkImportData;
}
