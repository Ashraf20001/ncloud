package com.recoveryportal.bulkImportConsumer.utils;

import java.util.HashMap;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.recoveryportal.bulkImportConsumer.constants.ApplicationConstants;

/**
 * The Class PlatformMapToBulkUploadIdentity.
 */
@Component
public class PlatformMapToBulkUploadIdentity {
	
	/** The platform map. */
	HashMap<String, Integer> platformMap = new HashMap<>();
	
	
	
	/**
	 * Construct class map.
	 */
	@PostConstruct
	void constructClassMap() {
		platformMap.put(ApplicationConstants.REPORTLOSS_BULK_IMPORT, 1);
		platformMap.put(ApplicationConstants.PAPER_DETAILS_BULK_IMPORT, 2);
	}
	
	
	
	/**
	 * Gets the platform id.
	 *
	 * @param className the class name
	 * @return the platform id
	 */
	public Integer getPlatformId(String className){
		return platformMap.get(className);
	}

}
