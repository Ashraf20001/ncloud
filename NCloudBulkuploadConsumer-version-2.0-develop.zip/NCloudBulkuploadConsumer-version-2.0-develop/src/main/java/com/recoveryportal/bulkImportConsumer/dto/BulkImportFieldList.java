package com.recoveryportal.bulkImportConsumer.dto;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BulkImportFieldList {
	
	List<FieldDto> listOfField;
	
	List<BulkImportMappingDto> bulkImportMapping;

}
