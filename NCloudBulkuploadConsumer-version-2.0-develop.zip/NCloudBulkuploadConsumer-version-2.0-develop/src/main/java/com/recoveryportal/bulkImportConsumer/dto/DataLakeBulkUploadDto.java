package com.recoveryportal.bulkImportConsumer.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

import lombok.Data;

@Data
public class DataLakeBulkUploadDto implements Serializable {

	/**
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 5988016141095508139L;

	/**
	 * bulkUploadId
	 */
	private Integer bulkUploadId;

	/**
	 * filePath
	 */
	private String filePath;

	/**
	 * repositoryName
	 */
	private String repositoryName;

	/**
	 * userInfo
	 */
	private UserInfo UserInfo;

}
