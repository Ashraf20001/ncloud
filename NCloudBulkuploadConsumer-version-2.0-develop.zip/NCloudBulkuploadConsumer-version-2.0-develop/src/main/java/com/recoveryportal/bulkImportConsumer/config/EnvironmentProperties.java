package com.recoveryportal.bulkImportConsumer.config;

import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * The Class EnvironmentProperties.
 */
@Configuration
@RequiredArgsConstructor		
public class EnvironmentProperties {

	/** The property value provider. */
	private final PropertyValueProvider propertyValueProvider;

    /**
     * Gets the file path of report loss.
     *
     * @return the file path of report loss
     */
    public String getFilePathOfReportLoss() {
        return propertyValueProvider.getFilePath();
    }
    
    /**
     * Gets the base url.
     *
     * @return the base url
     */
    public String getBaseUrl() {
    	return propertyValueProvider.getBaseUrl();
    }
}
