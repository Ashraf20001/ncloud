package com.recoveryportal.bulkImportConsumer.config;

import java.util.Map;

import org.apache.kafka.common.serialization.Deserializer;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.recoveryportal.bulkImportConsumer.dto.BulkImportTriggerConsumerDto;


/**
 * The Class ObjectDeserializer.
 */
public class ObjectDeserializer implements Deserializer<BulkImportTriggerConsumerDto>{
	
	/**
	 * Configure.
	 *
	 * @param configs the configs
	 * @param isKey the is key
	 */
	@Override
	public void configure(Map<String, ?> configs, boolean isKey) {
		// TODO Auto-generated method stub
		
	}

	/**
	 * Deserialize.
	 *
	 * @param topic the topic
	 * @param data the data
	 * @return the bulk import trigger consumer dto
	 */
	@Override
	public BulkImportTriggerConsumerDto deserialize(String topic, byte[] data) {
		ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		BulkImportTriggerConsumerDto version = null;
	    try {
	    	version = mapper.readValue(data, BulkImportTriggerConsumerDto.class);
	    } catch (Exception e) {

	      e.printStackTrace();
	    }
	    return version;
	}
	
	/**
	 * Close.
	 */
	@Override
	public void close() {
		// TODO Auto-generated method stub
		
	}

}
