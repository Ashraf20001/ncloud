package com.recoveryportal.bulkImportConsumer.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.recoveryportal.bulkImportConsumer.config.EnvironmentProperties;
import com.recoveryportal.bulkImportConsumer.constants.ApplicationConstants;
import com.recoveryportal.bulkImportConsumer.dto.StockDto;
import com.recoveryportal.bulkImportConsumer.service.StockRemainderService;

/**
 * The Class StockRemainderServiceImpl.
 */
@Service
public class StockRemainderServiceImpl implements StockRemainderService {
	
	/** The rest template. */
	@Autowired
	private RestTemplate restTemplate;
	
	/** The environment properties. */
	@Autowired
	private EnvironmentProperties environmentProperties;

	/**
	 * Send stock dto to main app by injecting {@link RestTemplate}.
	 *
	 * @param stockDto the stock dto
	 */
	@Override
	public void sendStockDtoToMainApp(StockDto stockDto) {
		
		String url=environmentProperties.getBaseUrl()+ApplicationConstants.STOCK_REMAINDER_URL;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		restTemplate.postForEntity(builder.toUriString(),stockDto,Void.class);
	}

}
