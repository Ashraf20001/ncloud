package com.recoveryportal.bulkImportConsumer.mockData;

import com.recoveryportal.bulkImportConsumer.dto.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class MockData {
    public static BulkImportHistoryDto getBulkImportHistoryDto(){
        BulkImportHistoryDto bulkImportHistoryDto = new BulkImportHistoryDto();
        bulkImportHistoryDto.setUploadId(1);
        bulkImportHistoryDto.setIdentity("fvgbhjnkl");
        bulkImportHistoryDto.setStatus("In progress");
        bulkImportHistoryDto.setPageId(1);
        bulkImportHistoryDto.setSuccessCount(686);
        bulkImportHistoryDto.setTotalCount(1000);
        bulkImportHistoryDto.setFailureCount(314);
        return bulkImportHistoryDto;
    }

    public static List<BulkImportHistoryDto> getBulkImportHistoryDtoList() {
        List<BulkImportHistoryDto> bulkImportHistoryDtos = new ArrayList<>();
        bulkImportHistoryDtos.add(getBulkImportHistoryDto());
        return bulkImportHistoryDtos;
    }

    public static List<BulkImportMappingDto> getBulkImportMappingList() {
        List<BulkImportMappingDto> bulkImportMappingDtos = new ArrayList<>();
        bulkImportMappingDtos.add(getBulkImportMapping());
        bulkImportMappingDtos.add(new BulkImportMappingDto("inRegistrationNo", "Registration Number"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("inMake", "Make"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("inModel", "Model"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("tpName", "Third Party Company Name"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("tpClaimNo", "TP Insurance Claim Number"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("tpPolicyNumber", "Policy Id"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("ldDateOfLoss", "Date of Loss"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("ldClaimNumber", "Claim Number"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("ldPoliceReportNumber", "Police Report Number"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("garageName", "Garage Name"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("garageLocation", "Garage Location"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("srSurveyAmount", "Survey Amount"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("inPurchaseDate", "Date of Purchase"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("srLabourCost", "Labour Cost"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("tpRegistrationNo", "TP Registration Number"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("tpRegistrationType", "Registration Type"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("tpMake", "TP Make"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("tpModel", "TP Model"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("ldReportedDate", "Reported Date"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("ldPolicyNumber", "Policy Number"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("ldReserveAmount", "Reserve Amount"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("ldIsTotalLoss", "Total Loss"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("garageType", "Garage Type"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("garageContactDetails", "Garage Contact Details"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("garageInvoiceName", "Garage Invoice Name"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("sdSurveyName", "Surveyor Name"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("sdSurveyAllocationDate", "Survey Allocation Date"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("sdSurveyDueDate", "Survey Due Date"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("sdSurveyReportName", "Survey Report Name"));
        bulkImportMappingDtos.add(new BulkImportMappingDto("srSpareParts", "Spare Parts Amount"));
        return bulkImportMappingDtos;

    }

    public static BulkImportMappingDto getBulkImportMapping() {
        BulkImportMappingDto bulkImportMappingDto = new BulkImportMappingDto();
        bulkImportMappingDto.setBulkImportAliasName("Sum Insured");
        bulkImportMappingDto.setBulkImportFieldName("inSumInsured");
        return bulkImportMappingDto;
    }

    public static List<FieldDto> getListOfFields() {
        List<FieldDto> fieldDtos = new ArrayList<>();
        fieldDtos.add(getDoubleField());
        fieldDtos.add(getStringField());
        fieldDtos.add(getStringField2());
        fieldDtos.add(getStringField3());
        fieldDtos.add(getDateField());
        fieldDtos.add(getBooleanField());
        return fieldDtos;
     }

    public static FieldDto getStringField3() {
        FieldDto fieldDto = new FieldDto();
        fieldDto.setFieldId("6");
        fieldDto.setFieldName("inInsurerName");
        fieldDto.setFieldType("String");
        fieldDto.setIsCoreData(true);
        fieldDto.setAliasName("alias6");
        fieldDto.setColumnName("column6");
        fieldDto.setMandatory(false);
        fieldDto.setValue("insurer");
        fieldDto.setEntityName("ReportLoss");
        fieldDto.setMinLength(1);
        fieldDto.setMaxLength(100);
        fieldDto.setDefaultValues("default");
        fieldDto.setRegex("");
        return fieldDto;
    }

    public static FieldDto getStringField2() {
        FieldDto fieldDto = new FieldDto();
        fieldDto.setFieldId("5");
        fieldDto.setFieldName("sdSurveyName");
        fieldDto.setFieldType("String");
        fieldDto.setIsCoreData(true);
        fieldDto.setAliasName("Surveyor Name");
        fieldDto.setColumnName("column5");
        fieldDto.setMandatory(false);
        fieldDto.setValue("fgh");
        fieldDto.setEntityName("ReportLoss");
        fieldDto.setMinLength(1);
        fieldDto.setMaxLength(100);
        fieldDto.setDefaultValues("default");
        fieldDto.setRegex("");
        return fieldDto;
    }

    public static FieldDto getBooleanField() {
        FieldDto fieldDto = new FieldDto();
        fieldDto.setFieldId("4");
        fieldDto.setFieldName("ldIsTotalLoss");
        fieldDto.setFieldType("checkbox");
        fieldDto.setIsCoreData(true);
        fieldDto.setAliasName("Total Loss");
        fieldDto.setColumnName("column4");
        fieldDto.setMandatory(false);
        fieldDto.setValue("true");
        fieldDto.setEntityName("ReportLoss");
        fieldDto.setMinLength(1);
        fieldDto.setMaxLength(100);
        fieldDto.setDefaultValues("default");
        fieldDto.setRegex("");
        return fieldDto;
    }

    public static FieldDto getDateField() {
        FieldDto fieldDto = new FieldDto();
        fieldDto.setFieldId("3");
        fieldDto.setFieldName("ldDateOfLoss");
        fieldDto.setFieldType("fDate");
        fieldDto.setIsCoreData(true);
        fieldDto.setAliasName("Date of Loss");
        fieldDto.setColumnName("column3");
        fieldDto.setMandatory(false);
        fieldDto.setValue("20-05-2023");
        fieldDto.setEntityName("ReportLoss");
        fieldDto.setMinLength(1);
        fieldDto.setMaxLength(100);
        fieldDto.setDefaultValues("default");
        fieldDto.setRegex("");
        return fieldDto;
    }

    public static FieldDto getDoubleField() {
        FieldDto fieldDto = new FieldDto();
        fieldDto.setFieldId("1");
        fieldDto.setFieldName("inSumInsured");
        fieldDto.setFieldType("Double");
        fieldDto.setIsCoreData(true);
        fieldDto.setAliasName("Sum Insured");
        fieldDto.setColumnName("column1");
        fieldDto.setMandatory(true);
        fieldDto.setValue("123.1");
        fieldDto.setEntityName("ReportLoss");
        fieldDto.setMinLength(1);
        fieldDto.setMaxLength(100);
        fieldDto.setDefaultValues("default");
        fieldDto.setRegex("");
        return fieldDto;
    }

    public static FieldDto getStringField() {
        FieldDto fieldDto = new FieldDto();
        fieldDto.setFieldId("2");
        fieldDto.setFieldName("tpName");
        fieldDto.setFieldType("String");
        fieldDto.setIsCoreData(true);
        fieldDto.setAliasName("Third Party Company Name");
        fieldDto.setColumnName("column2");
        fieldDto.setMandatory(true);
        fieldDto.setValue("cde");
        fieldDto.setEntityName("ReportLoss");
        fieldDto.setMinLength(1);
        fieldDto.setMaxLength(100);
        fieldDto.setDefaultValues("default");
        fieldDto.setRegex("");
        return fieldDto;
    }


    public static FieldDto getDateField2() {
        FieldDto fieldDto = new FieldDto();
        fieldDto.setFieldId("11");
        fieldDto.setFieldName("sdSurveyDueDate");
        fieldDto.setFieldType("pDate");
        fieldDto.setIsCoreData(true);
        fieldDto.setAliasName("Survey Due Date");
        fieldDto.setColumnName("column3");
        fieldDto.setMandatory(false);
        fieldDto.setValue("20-05-2023");
        fieldDto.setEntityName("ReportLoss");
        fieldDto.setMinLength(1);
        fieldDto.setMaxLength(100);
        fieldDto.setDefaultValues("default");
        fieldDto.setRegex("");
        return fieldDto;
    }

    public static BulkUploadSuccessErrorList getBulkUploadSuccessErrorList() {
        BulkUploadSuccessErrorList bulkUploadSuccessErrorList = new BulkUploadSuccessErrorList();
        bulkUploadSuccessErrorList.setBulkImportData(getBulkImportTempDataList());
        bulkUploadSuccessErrorList.setErrorList(getBulkImportErrorDataDtoList());
        bulkUploadSuccessErrorList.setReportLossList(getReportLossDtoList());
        return bulkUploadSuccessErrorList;
    }

    private static List<ReportLossDto> getReportLossDtoList() {
        List<ReportLossDto> reportLossDto = new ArrayList<>();
        reportLossDto.add(getReportLossDtoData());
        return reportLossDto;
    }
    public static ReportLossDto getReportLossDtoData(){
        ReportLossDto reportLossDto = new ReportLossDto();

        reportLossDto.setState("status");
        //insured info
        //vehicle details
        reportLossDto.setInRegistrationNo("123");
        reportLossDto.setInMake("12344");
        reportLossDto.setInModel("12345");
        reportLossDto.setInPurchaseDate(LocalDateTime.now());
        reportLossDto.setInSumInsured(123456.0);

        //third party info
        reportLossDto.setTpPolicyNumber("12345");
        reportLossDto.setTpName("tp alpha");
        //vehicle details
        reportLossDto.setTpRegistrationNo("123");
        reportLossDto.setTpRegistrationType("123");
        reportLossDto.setTpMake("12344");
        reportLossDto.setTpModel("12345");

        //garage info
        reportLossDto.setGarageName("g1");
        reportLossDto.setGarageType("ABC");

        reportLossDto.setLdDateOfLoss(LocalDateTime.now());
        reportLossDto.setLdIsTotalLoss(true);
        reportLossDto.setLdDateOfLoss(LocalDateTime.now());
        reportLossDto.setLdClaimNumber("fghj");

        reportLossDto.setRdPoliceReportFee(345.4);
        reportLossDto.setRdClaimAmount(2345.4);
        reportLossDto.setRdCashSettlement(45.4);

        reportLossDto.setPrDocumentUpload("fgh");

        reportLossDto.setSdSurveyReportName("hsdf");
        reportLossDto.setSdSurveyDueDate(LocalDateTime.now());
        reportLossDto.setSdSurveyAllocationDate(LocalDateTime.now());

        reportLossDto.setSrTotalLoss(false);

        reportLossDto.setRrReserveAmount(6566.0);
        reportLossDto.setRrTPSurveyAmount(7687.3);
        reportLossDto.setRrTotalClaimAmount(687.3);

        reportLossDto.setRrTotalClaimAmount(6776.3);
        reportLossDto.setGiGarageInvoiceNo("132");
        reportLossDto.setGiDocument("1s32");

        reportLossDto.setCnCreditNoteDocument("AD");
        reportLossDto.setCnCreditNoteNumber("AsD");
        reportLossDto.setDnDebitNoteDocument("AdD");
        reportLossDto.setDnDebitNoteNumber("AdD");

        return reportLossDto;
    }

    private static List<BulkImportErrorDataDto> getBulkImportErrorDataDtoList() {
        List<BulkImportErrorDataDto> bulkImportErrorDataDtos = new ArrayList<>();
        bulkImportErrorDataDtos.add(getBulkImportErrorDataDto());
        return bulkImportErrorDataDtos;
    }

    private static BulkImportErrorDataDto getBulkImportErrorDataDto() {
        BulkImportErrorDataDto bulkImportErrorDataDto = new BulkImportErrorDataDto();
        bulkImportErrorDataDto.setErrorId("1");
        bulkImportErrorDataDto.setFieldName("field name");
        bulkImportErrorDataDto.setRowId(1);
        return bulkImportErrorDataDto;
    }

    private static List<BulkImportTempData> getBulkImportTempDataList() {
        List<BulkImportTempData> bulkImportTempDataList = new ArrayList<>();
        bulkImportTempDataList.add(getBulkImportTempData());
        return bulkImportTempDataList;
    }

    private static BulkImportTempData getBulkImportTempData() {
        BulkImportTempData bulkImportTempData = new BulkImportTempData();

        //insured info
        //vehicle details
        bulkImportTempData.setInRegistrationNo("123");
        bulkImportTempData.setInMake("12344");
        bulkImportTempData.setInModel("12345");
        bulkImportTempData.setInPurchaseDate(LocalDateTime.now().toString());
        bulkImportTempData.setInSumInsured("123456.0");

        //third party info
        bulkImportTempData.setTpPolicyNumber("12345");
        bulkImportTempData.setTpName("tp alpha");
        //vehicle details
        bulkImportTempData.setTpRegistrationNo("123");
        bulkImportTempData.setTpRegistrationType("123");
        bulkImportTempData.setTpMake("12344");
        bulkImportTempData.setTpModel("12345");

        //garage info
        bulkImportTempData.setGarageName("g1");
        bulkImportTempData.setGarageType("ABC");

        bulkImportTempData.setLdDateOfLoss(LocalDateTime.now().toString());
        bulkImportTempData.setLdIsTotalLoss("true");
        bulkImportTempData.setLdDateOfLoss(LocalDateTime.now().toString());
        bulkImportTempData.setLdClaimNumber("fghj");


        bulkImportTempData.setSdSurveyReportName("hsdf");
        bulkImportTempData.setSdSurveyDueDate(LocalDateTime.now().toString());
        bulkImportTempData.setSdSurveyAllocationDate(LocalDateTime.now().toString());

        bulkImportTempData.setSrTotalLoss("false");

        bulkImportTempData.setUploadDataId(1);
        bulkImportTempData.setCreatedBy(1);
        bulkImportTempData.setStatus(true);
        bulkImportTempData.setErrorDescription("");
        bulkImportTempData.setCreatedDate(LocalDateTime.now());

        return bulkImportTempData;
    }
    
	public static BulkImportTriggerConsumerDto getBulkImportTriggerConsumerDto() {
		BulkImportTriggerConsumerDto consumerDto = new BulkImportTriggerConsumerDto();
		consumerDto.setBulkImportHistoryDto(getBulkImportHistoryDto());
		consumerDto.setBulkImportIdentity("identity");
		consumerDto.setInsurer("insurer");
		consumerDto.setPageIdentity("page");
		consumerDto.setPoolCountDetails(null);
		consumerDto.setUploadType("FLEET");
		consumerDto.setUserId(1);
		consumerDto.setUserInfo(null);
		return consumerDto;
	}
}
