package com.recoveryportal.bulkImportConsumer.service;

import com.recoveryportal.bulkImportConsumer.RecoveryPortalBulkImportConsumerApplication;
import com.recoveryportal.bulkImportConsumer.config.EnvironmentProperties;
import com.recoveryportal.bulkImportConsumer.core.ApplicationResponse;
import com.recoveryportal.bulkImportConsumer.dto.BulkImportFieldList;
import com.recoveryportal.bulkImportConsumer.dto.BulkImportHistoryDto;
import com.recoveryportal.bulkImportConsumer.dto.BulkImportTriggerConsumerDto;
import com.recoveryportal.bulkImportConsumer.dto.BulkUploadSuccessErrorList;
import com.recoveryportal.bulkImportConsumer.dto.FieldDto;
import com.recoveryportal.bulkImportConsumer.mockData.MockData;
import com.recoveryportal.bulkImportConsumer.service.Impl.BulkImportConsumerServiceImpl;
import com.recoveryportal.bulkImportConsumer.test.RecoveryUnitTest;
import com.recoveryportal.bulkImportConsumer.utils.DataConverterFactory;
import com.recoveryportal.bulkImportConsumer.utils.FieldClassMapper;
import com.recoveryportal.bulkImportConsumer.utils.RestTemplateUtils;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.client.RestTemplate;

import java.io.File;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = RecoveryPortalBulkImportConsumerApplication.class)
public class BulkImportConsumerServiceTest extends RecoveryUnitTest {

    @InjectMocks
    BulkImportConsumerServiceImpl bulkImportConsumerService;
    @Mock
    EnvironmentProperties environmentProperties;
    @Mock
    RestTemplateUtils restTemplateUtils;
    @Mock
    RestTemplate restTemplate;
    @Mock
    DataConverterFactory converterFactory;
    @Mock
    FieldClassMapper classMapper;
    @Mock
    private OPCPackage opcPackage;

    @Test
    void updateStatusOfBulkImportHistory_save_Happy_Flow() {
        BulkImportTriggerConsumerDto bulkImportTriggerConsumerDto = MockData.getBulkImportTriggerConsumerDto();
        ApplicationResponse convertedValue = new ApplicationResponse();
        convertedValue.setContent("Bulk_Upload_ReportLoss_test.xlsx");

        BulkImportFieldList bulkImportFieldList = new BulkImportFieldList();
        bulkImportFieldList.setListOfField(MockData.getListOfFields());
        bulkImportFieldList.setBulkImportMapping(MockData.getBulkImportMappingList());

        BulkUploadSuccessErrorList bulkUploadSuccessErrorList = MockData.getBulkUploadSuccessErrorList();
        String files = "Files/";
        ResponseEntity responseEntity1 = ResponseEntity.ok()
                .header("Custom-Header", "values")
                .body("Custom body");
        ResponseEntity responseEntity2 = ResponseEntity.ok()
                .header("Custom-Header", "values")
                .body(convertedValue);
        ResponseEntity<BulkImportFieldList> responseEntity3 = new ResponseEntity<BulkImportFieldList>(
                bulkImportFieldList, HttpStatus.OK);
        ResponseEntity<BulkUploadSuccessErrorList> responseEntity4 = new ResponseEntity<BulkUploadSuccessErrorList>(
                bulkUploadSuccessErrorList, HttpStatus.OK);

        String pageId = "pgId", insurer = "insurer", userId = "12";

        try {
            bulkImportConsumerService.setBaseUrl("http://localhost:9090");
            doReturn(responseEntity1).when(restTemplate).exchange(
                    ArgumentMatchers.anyString(),
                    eq(HttpMethod.POST),
                    ArgumentMatchers.any(),
                    eq(BulkImportHistoryDto.class)
            );
            doReturn(responseEntity3).when(restTemplate).exchange(
                    ArgumentMatchers.anyString(),
                    ArgumentMatchers.any(HttpMethod.class),
                    ArgumentMatchers.any(),
                    eq(BulkImportFieldList.class)
            );
            doReturn(responseEntity2).when(restTemplate).exchange(
                    ArgumentMatchers.anyString(),
                    ArgumentMatchers.any(HttpMethod.class),
                    ArgumentMatchers.any(),
                    eq(ApplicationResponse.class)
            );
            doReturn(responseEntity4).when(restTemplate).exchange(
                    ArgumentMatchers.anyString(),
                    ArgumentMatchers.any(HttpMethod.class),
                    ArgumentMatchers.any(),
                    eq(BulkUploadSuccessErrorList.class)
            );
            when(environmentProperties.getFilePathOfReportLoss()).thenReturn(files);
            doReturn(Double.class).when(classMapper).getClass("Double");
            doReturn(String.class).when(classMapper).getClass("String");
            doReturn(LocalDateTime.class).when(classMapper).getClass("LocalDateTime");
            doReturn(boolean.class).when(classMapper).getClass("Boolean");
            doReturn(Long.class).when(classMapper).getClass("Long");
            doCallRealMethod().when(converterFactory).dataConverter(any(),any());
            bulkImportConsumerService.updateStatusOfBulkImportHistory(bulkImportTriggerConsumerDto);
        } catch (Exception e) {
            Assertions.fail(e.toString());
        }
    }

}
