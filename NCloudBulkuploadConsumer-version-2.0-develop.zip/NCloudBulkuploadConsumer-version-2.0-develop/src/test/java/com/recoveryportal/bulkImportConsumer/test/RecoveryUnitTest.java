package com.recoveryportal.bulkImportConsumer.test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.recoveryportal.bulkImportConsumer.config.DbContextHolder;
import com.recoveryportal.bulkImportConsumer.config.DbType;
import com.recoveryportal.bulkImportConsumer.exception.ErrorIdList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.io.IOException;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = RecoveryUnitTest.class)
@ComponentScan("com.recoveryportal.*")
public class RecoveryUnitTest {

	
	@Autowired
	private WebApplicationContext wac;

	protected MockMvc mockMvc;

	protected ErrorIdList convertJsonToJava(String jsonStr) {
		ErrorIdList errorIdList = null;

		try {
			errorIdList = new ObjectMapper().readValue(jsonStr, ErrorIdList.class);
		} catch (IOException e) {
			e.printStackTrace();

		}

		return errorIdList;
	}

	protected Object convertJsonToJavaObject(String jsonStr, Class<?> c) {
		Object obj = null;
		try {
			obj = new ObjectMapper().readValue(jsonStr, c);
		} catch (IOException e) {
			e.printStackTrace();

		}
		return obj;
	}

	@SuppressWarnings("deprecation")
	@BeforeEach
	public void setup() {
		DbContextHolder.setDbType(DbType.TEST);
//		AOPVersioningProcessor.setAsRunningTest(true);
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
		MockitoAnnotations.initMocks(this);
	}
	
	 
}
