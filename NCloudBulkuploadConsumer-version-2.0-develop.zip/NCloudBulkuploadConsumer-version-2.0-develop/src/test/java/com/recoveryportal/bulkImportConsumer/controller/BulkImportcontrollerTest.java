package com.recoveryportal.bulkImportConsumer.controller;

import com.recoveryportal.bulkImportConsumer.RecoveryPortalBulkImportConsumerApplication;
import com.recoveryportal.bulkImportConsumer.dto.BulkImportTriggerConsumerDto;
import com.recoveryportal.bulkImportConsumer.mockData.MockData;
import com.recoveryportal.bulkImportConsumer.service.BulkImportConsumerService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@SpringBootTest(classes = RecoveryPortalBulkImportConsumerApplication.class)
public class BulkImportcontrollerTest {
    @InjectMocks
    BulkImportcontroller bulkImportcontroller;
    @Mock
    BulkImportConsumerService bulkImportConsumerServiceMock;

    @Test
    void updateBulkUploadStatus_Happy_Flow(){
        BulkImportTriggerConsumerDto bulkImportTriggerConsumerDto = MockData.getBulkImportTriggerConsumerDto();
        String pageId = "pgId", insurer = "insurer", userId = "12",bulkIdentity="fleet";
        try {
            doNothing().when(bulkImportConsumerServiceMock).updateStatusOfBulkImportHistory(
                    any(BulkImportTriggerConsumerDto.class)
            );
            bulkImportcontroller.updateBulkUploadStatus(bulkImportTriggerConsumerDto, pageId, insurer, userId,bulkIdentity);
        } catch (Exception e){
            Assertions.fail(e.toString());
        }
    }
}
