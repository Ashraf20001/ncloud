export const environment = {
  production: true,
  API_BASE_URL: '',
  NOTIFICATION_BASE_URL: 'https://recoverez-notification.azurewebsites.net'
};
