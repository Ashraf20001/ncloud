export const environment = {
    production: false,
    API_BASE_URL: 'http://10.10.11.180:9000',
    NOTIFICATION_BASE_URL: 'http://10.10.11.180:9092'
};
