export const environment = {
  production: false,
  API_BASE_URL : 'http://localhost:6060',
  AUTH_URL : 'http://localhost:6060',
  // API_BASE_URL: 'http://10.10.11.43:8510'
  // API_BASE_URL: 'http://10.10.11.180:8500'
  //  API_BASE_URL: '',
  // NOTIFICATION_BASE_URL: 'http://10.10.11.43:8601'
  NOTIFICATION_BASE_URL: 'https://recoverez-notification.azurewebsites.net'
};
