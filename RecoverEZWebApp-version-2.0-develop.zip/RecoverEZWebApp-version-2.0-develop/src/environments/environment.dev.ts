export const environment = {
 


    production: false,
    API_BASE_URL : 'http://localhost:6060',
    AUTH_URL : 'http://localhost:6060',
   
    NOTIFICATION_BASE_URL: 'http://localhost:8601'


};
  