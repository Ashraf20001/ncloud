import { Component } from '@angular/core';
import { AppService } from '../service/role access/service/app.service';
import { appConst } from '../service/app.const';
import { AccessMappingPageDto } from '../models/user-role-management/access-Mapping-PageDto ';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent {
  accessMappingPageDto: AccessMappingPageDto;
  paymentListPageEnabled: boolean;
  constructor(private appService : AppService){
    this. getPageAccessData();
  }
  getPageAccessData(): void {
    this.appService.getPageAccess(appConst.PAGE_NAME.PAYMENT.PAYMENT_DETAILS_LIST.PAGE_IDENTITY).subscribe((response: any) => {
      this.accessMappingPageDto = response.content;
      this.paymentListPageEnabled = this.accessMappingPageDto.isEnabled;
     
    });
  }
}
