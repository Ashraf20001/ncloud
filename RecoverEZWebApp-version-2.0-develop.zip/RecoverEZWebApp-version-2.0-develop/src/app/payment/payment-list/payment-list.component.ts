import { AfterViewInit, ChangeDetectorRef, Component, OnDestroy, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { Subject, Subscription, debounceTime } from 'rxjs';
import { ErrorHandlerDirective } from 'src/app/common/directives/errorHandler.directive';
import { PaymentSatus } from 'src/app/common/enum/paymentStatus-enum';
import { PaymentDto } from 'src/app/models/reports-dto/PaymentDto';
import { AccessMappingPageDto } from 'src/app/models/user-role-management/access-Mapping-PageDto ';
import { PaymentPopupComponent } from 'src/app/reports/payment-popup/payment-popup.component';
import { PreviewPopupComponent } from 'src/app/reports/preview-popup/preview-popup.component';
import { ProceedToPaymentPopupComponent } from 'src/app/reports/proceed-to-payment-popup/proceed-to-payment-popup.component';
import { PayReportReqDto } from 'src/app/reports/reports-card/reports-card.component';
import { AdminService } from 'src/app/service/admin.service';
import { appConst } from 'src/app/service/app.const';
import { PaymentService } from 'src/app/service/payment.service';
import { AppService } from 'src/app/service/role access/service/app.service';

@Component({
  selector: 'app-payment-list',
  templateUrl: './payment-list.component.html',
  styleUrls: ['./payment-list.component.scss']
})
export class PaymentListComponent implements OnDestroy,AfterViewInit {
  displayedColumns: string[] = ['Payment By', 'Company Name', 'Transaction ID', 'Payment ID', 'Payment Date', 'Payment Type', 'Amount', 'Payment Status', 'View', 'Approve/Reject'];
  dataSource = new MatTableDataSource<PaymentDto>();
  totalLength: number;
  pagesize = 10;
  pageIndex = 1;
  minLength: number;
  maxLength: number;
  endingIndex = 10;
  paymentDto: PaymentDto[] = []

  ZERO = 0;
  TEN = 10;
  companyList: String[] = [];

  showDownload = false;
  dataNotFound = false;
  searchdisable = false;
  transactionCompanyId: number[] = [];
  tableList: any[] = []
  private subscriptions = new Subscription();
  isApprovedEnable: boolean = true;
  approveOrRejectBtn: boolean = true;
  associateUser: boolean;
  customPageIndex: number = 0;
  currentPageIndex: number;
  pageChangedEvent = new Subject<number>();
  pageInfo: any;
  public appConst = appConst;
  pageId = appConst.PAGE_NAME.PAYMENT.PAYMENT_DETAILS_LIST.PAGEID;
  accessMappingPageDto: AccessMappingPageDto;
  paymentListPageEnabled: boolean;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(public dialog: MatDialog, private route: ActivatedRoute,private paginatorName: MatPaginatorIntl,
    private detector: ChangeDetectorRef,
    private toaster: ToastrService, private paymentService: PaymentService, private errorHandler: ErrorHandlerDirective, private adminService: AdminService,
    public translate: TranslateService,private appService : AppService) {

    if (paginatorName) {
      this.translateLabels(paginatorName);
    }
    this.translate.onLangChange.subscribe(() => {
      this.translateLabels(paginatorName);
    });
    this.getPrivilege();
    if(this.paginatorName) {
      this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    }
  }

  ngOnInit(): void {
    this.associateUser = this.adminService.isAssociationUser();
    if(this.associateUser){
      this.displayedColumns= ['Company Name', 'Transaction ID', 'Payment ID', 'Payment Date', 'Payment Type', 'Amount', 'Payment Status', 'View', 'Approve/Reject'];
    }
    this.minLength = this.ZERO;
    this.maxLength = this.TEN;
    this.getPaymentDetailcount(this.minLength, this.maxLength);
    this.pageChangedEvent.pipe(debounceTime(300)).subscribe((data: number) => {
      this.changePageIndex();
    });
    this.translate.onLangChange.subscribe(() => {
      if (this.paginator) {
        this.paginator._intl.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
        this.paginator._changePageSize(this.paginator.pageSize);
        this.detector.detectChanges();
      }
    });
    if(this.paginatorName) {
      this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    }
  }

  ngAfterViewInit() {
    if (this.dataSource !== undefined && this.dataSource !== null) {
      this.dataSource.paginator = this.paginator;
    }
    if(this.paginatorName) {
      this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    }
  }
  /*
  * Get PaymentDetail count
  */
  getPaymentDetailcount(min: number, max: number) {
    this.subscriptions = this.paymentService.getPayementDetailsCount().subscribe((res => {
      if (res['content'] != 0) {
        this.dataNotFound = false;
        if(res['content'].length >= 9){
          this.dataNotFound = false;
        }
        this.totalLength = res['content'];
        this.getPaymentDetailList(this.minLength, this.maxLength);
      } else {
        this.dataNotFound = true;
      }
    }), (error: Response) => {
      this.errorHandler.getMessage(error)
    });
  }
  /*
  * Get PaymentDetail List
  */
  getPaymentDetailList(min: number, max: number) {
    this.subscriptions = this.paymentService.getPayementDetailsList(min, max).subscribe(res => {
      this.paymentDto=[];
      if (res['content'].length != 0) {
        this.dataNotFound = false;
        this.paymentDto = res['content'];
        this.dataSource = new MatTableDataSource(this.paymentDto);
      } else {
        this.dataSource = new MatTableDataSource(this.paymentDto);
        this.dataNotFound = true;
      }
    }, (error: Response) => {
      this.errorHandler.getMessage(error)
    });
  }
  /*
  * Donwload File
  */
  private donwloadFile(value: any, downloadType: string) {
    const blob = new Blob([value], { type: '' });
    const downloadLink = document.createElement('a');
    downloadLink.style.display = 'none';
    document.body.appendChild(downloadLink);
    downloadLink.setAttribute('href', window.URL.createObjectURL(blob));
    downloadLink.setAttribute('download', 'Excel');
    downloadLink.click();
    document.body.removeChild(downloadLink);
  }
  /*
  * Open ProceedToPaymentPopupComponent
  */
  openDialog(element: any): void {
    this.dataSource.filteredData.forEach(ele => {
      if (ele.paymentId == element.paymentId) {
        if (ele.paymentStatus == PaymentSatus.SUBMITTED ) {
          this.approveOrRejectBtn = true;
        }else{
          this.approveOrRejectBtn=false;
        }
      }
    });
    if (!this.associateUser) {
      var toCompanyName = element.toCompanyName;
    } else {
      toCompanyName = "Association";
    }
    const dialogRef = this.dialog.open(ProceedToPaymentPopupComponent, {
      width: '1561px',
      height: '570px',
      data: {
        paymentBy:element.paymentBy,
        fromCompanyName:element.fromCompanyName,
        toCompanyName,
        transactionId: element.transactionId,
        paymentDate:element.paymentDate,
        paymentId: element.paymentId,
        totalAmount: element.totalAmount,
        paymentMethod: element.paymentMethod,
        paymentStatus: element.paymentStatus,
        referenceId: element.referenceId,
        reportId: element.reportId,
        autoGeneratedPdfID:element.autoGeneratedPdfID,
        approveOrReject: this.approveOrRejectBtn,
        isView:true
      },
      disableClose: true
    });
    dialogRef.afterClosed().subscribe(result => {
      if(result != undefined){
        this.isApprovedEnable = false;
        this.getPaymentDetailList(this.minLength,this.maxLength);
      }
    });
  }

  /*
  * PaymentMethod
  */
  paymentMethod(data: any) {
    const payReportReqDto = new PayReportReqDto();
    payReportReqDto.fromCompany = data.fromCompanyName;
    payReportReqDto.paymentId = data.paymentId;
    payReportReqDto.reportId = data.reportId;
    this.subscriptions = this.paymentService.getComapnyAmountData(payReportReqDto).subscribe(res => {
      if (res['content']) {
        let totalClaimAmount = res['content'].totalClaimAmount;
        let companyAmountMap: Map<string, number> = res['content'].companyAmountMap;
        const dialogRef = this.dialog.open(PaymentPopupComponent, {
          width: '1561px',
          height: '569px',
          data: {
            totalClaimAmount,
            companyAmountMap,
            fromCompanyName: data.fromCompanyName,
            reportId: data.reportId,
            autoGeneratedPdfID:data.autoGeneratedPdfID
          },
          disableClose: true
        });
        dialogRef.afterClosed().subscribe(result => {
          if(result != undefined){
            this.isApprovedEnable = false;
            this.getPaymentDetailList(this.minLength,this.maxLength);
          }
        });
      }
    })


  }

  /*
  *  Change Page
  */
  changePage(event) {
    if(event.pageIndex > event.previousPageIndex ){
      //previous
      this.customPageIndex = event.pageIndex+1;
    }else{
     // next
     this.customPageIndex =  this.customPageIndex-1;
    }
    if (event.pageIndex != this.ZERO) {
      this.maxLength = event.pageSize;
      this.minLength = event.pageSize * event.pageIndex;
      this.endingIndex = event.pageSize;
      this.pageIndex = this.customPageIndex;
    } else {
      this.maxLength = event.pageSize;
      this.minLength = event.pageIndex;
      this.endingIndex = event.pageSize;
      this.pageIndex = this.customPageIndex+1;
    }
    this.getPaymentDetailList(this.minLength, this.maxLength);
  }
  /*
  *   Page Index
  */
  pageindex(): void {
    this.pageChangedEvent.next(this.pageIndex);
  }

  changePageIndex(): void {
    if (this.pageIndex > 0) {
      const totalPageIndex = this.totalLength / this.endingIndex + 1;
      if(this.pageIndex > totalPageIndex) {
        this.pageIndex = this.customPageIndex === 0 ? 1 : this.customPageIndex;
        return;
      }
      this.customPageIndex = this.pageIndex;
      this.currentPageIndex = this.pageIndex-1;
      this.maxLength = this.endingIndex;
      this.minLength = this.endingIndex * this.currentPageIndex;
      this.getPaymentDetailList(this.minLength, this.maxLength);
    }
  }

  onKeyDown(event: KeyboardEvent) {
    if (event.keyCode === 190) {
      event.preventDefault();
    }
  }

  /*
    * BackTocard
    */
  backTocard() {
    // this.router.navigateByUrl("authority-paper-details/purchase-history/card");
  }

  private translateLabels(paginatorName: MatPaginatorIntl) {
    paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    paginatorName.firstPageLabel = this.translate.instant('Paginator.FirstPage');
    paginatorName.lastPageLabel = this.translate.instant('Paginator.LastPage');
    paginatorName.nextPageLabel = this.translate.instant('Paginator.NextPage');
    paginatorName.previousPageLabel = this.translate.instant('Paginator.PreviousPage');

  }
  getPrivilege(){
    this.appService.getPrivilegeForPage(this.pageId).subscribe((res: any)=>{
      this.pageInfo = res.content;
      this.getPageInfo(this.pageId);
    });
  }

  getPageInfo(pageID: number): boolean{
    if(this.pageInfo != null || this.pageInfo !== undefined){
      const pageValue = this.pageInfo.find((element: any) => element.pageId === pageID);
      return pageValue;
    }else{
      return true;
    }

  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege ? privillege.isEnabled : false;
    }
    return isEnabled;
  }

  /*
  * ngOnDestroy
  */
  ngOnDestroy(): void {
    this.subscriptions.unsubscribe;
  }

}
