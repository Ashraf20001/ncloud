import { NgModule } from "@angular/core";
import { PaymentRoutingModule } from "./payment-routing.module";
import { CommonModule } from "@angular/common";
import { TranslateModule } from "@ngx-translate/core";

@NgModule({
    declarations: [
     
  
    ],
    imports: [
        TranslateModule,
        CommonModule,
        PaymentRoutingModule
    ],
    exports:[
        PaymentRoutingModule ,
    ]
  })
  export class PaymentModule { }