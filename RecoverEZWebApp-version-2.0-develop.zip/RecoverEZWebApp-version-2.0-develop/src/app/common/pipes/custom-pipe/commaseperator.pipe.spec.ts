import { CommaseperatorPipe } from './commaseperator.pipe';

describe('CommaseperatorPipe', () => {
  it('create an instance', () => {
    const pipe = new CommaseperatorPipe();
    expect(pipe).toBeTruthy();
  });
});
