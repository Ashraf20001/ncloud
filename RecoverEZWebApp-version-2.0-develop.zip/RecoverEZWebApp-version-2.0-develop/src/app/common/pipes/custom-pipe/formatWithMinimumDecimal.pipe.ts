import { Pipe, PipeTransform } from '@angular/core';
import { AmountFormatEnum } from '../../enum/enum';

@Pipe({
  name: 'formatMinimumDecimal',
})
export class FormatMinimumDecimalPipe implements PipeTransform {
  transform(value: number | string, locale?: string): string {
    if(value===null || value===undefined || value === ''){
      return null;
    }else{
      return new Intl.NumberFormat(locale, {
        minimumFractionDigits: AmountFormatEnum.minimumDecimal,
        maximumFractionDigits: AmountFormatEnum.maximumDecimal
      }).format(Number(value));
    }
  }
}