import { Pipe, PipeTransform } from '@angular/core';
import { AmountFormatEnum } from '../../enum/enum';

@Pipe({
  name: 'format',
})
export class FormatPipe implements PipeTransform {
  transform(value: number | string, locale?: string): string {
    if(value===null || value===undefined || value === ''){
      return null;
    }else{
      return new Intl.NumberFormat(locale, {
        maximumFractionDigits: AmountFormatEnum.maximumDecimal
      }).format(Number(value));
    }
  }
}
