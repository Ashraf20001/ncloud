import { FormatnumberDirective } from './formatnumber.directive';

describe('FormatnumberDirective', () => {
  it('should create an instance', () => {
    const directive = new FormatnumberDirective();
    expect(directive).toBeTruthy();
  });
});
