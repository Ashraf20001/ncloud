import { appConst } from "src/app/service/app.const";

export enum multilanguage{
  tamil='Tamil',
  english='English',
  arabic='Arabic',
  malayalam='Malayalam'

}
export enum ErrorCode{
  serverDown = 0,
  unauthorised = 403,
  unauthenticated = 401
}
export enum  ToasterMesage{
  captchaError="Entered captcha is incorrect"
}
export enum CatchaErrorCode{
errorCode="E7126"
}

export enum ExpireTime{
  expirationTime = 12 * 60 * 60 * 1000
}

export enum  ToasterMesage{
  tooManyAttempts='Too Many Attempts'
}

export enum StageNameReportLoss {

  insuredDetails = 'Insured Details',
  tpDetails = 'TP Details',
  lossDetails = 'Loss Details',
  policeDetails = 'Police Report',
  garageDetails = 'Garage Details',
  surveyDetails = 'Survey Details',
  surveyReport = 'Survey Report',
  recoveryDetails = 'Recovery Details',
  reserveReview = 'Reserve Review',
  contact = 'Contact',
  garageInvoice = 'Garage Invoice',
  debitNote = 'Debit Note',
  creditNote = 'Credit Note',
}

export enum ReportLossStatus{
draft = 'Draft',
notificationOpen = 'Notification Open',
notificationReceived = 'Notification Received',
notificationAccepted = 'Notification Accepted',
garageAndSurveyDetails = 'Garage And Survey Details Updated',
movedToInspection = 'Moved To Inspection',
underInspection = 'Under Inspection',
expensesAndDocumentUpdated ='Expenses And Document Updated',
receivedLiabality ='Received Liability',
liabilityAccepted ='Liability Accepted',
liabilityReview ='Liability Review',
confirmLiability ='Confirmed Liability',
debitNoteGenerated = 'Debit Note Generated',
claimSettled = 'Claim Settled',
notificationRejected = 'Notification Rejected',
receiveRejectedNotification = 'Received Rejected Notification',
needMoreDetails = 'Need More Details',
detailsProvided = 'Details Provided',
reopen = 'Reopen',
dispute = 'Dispute',
disputeReopen = 'Dispute Reopen',
totalLossInitiated = 'Total Loss Initiated',
totalLossAccepted = 'Total Loss Accepted',
surveyAssigned = 'Surveyor Assigned',
knockForKnock = "Knock For Knock"
}

export enum ReportLossStatusValue{
  draft = 100,
  notificationOpen = 101,
  notificationReceived = 102,
  notificationAccepted = 103,
  garageAndSurveyDetails = 104,
  movedToInspection = 105,
  underInspection = 106,
  expensesAndDocumentUpdated = 107,
  receivedLiabality =108,
  liabilityReview= 109,
  knockForKnock = 110,
  liabilityAccepted =111,
  confirmLiability =112,
  debitNoteGenerated = 113,
  claimSettled = 114

  //fail flow
  // notificationRejected = 'NOTIFICATION REJECTED',
  // receiveRejectedNotification = 'RECEIVED REJECTED NOTIFICATION',
  // needMoreDetails = 'NEED MORE DETAIL',
  // detailsProvided = 'DETAILS PROVIDED',
  // reopen = 'REOPEN',
  // dispute = 'DISPUTE',
  // disputeReopen = 'DISPUTE REOPEN',
  // totalLossInitiated = 'TOTALLOSS INITITED',
  // totalLossAccepted = 'TOTALLOSS ACCEPTED',
  // surveyAssigned = 'SURVEYOR ASSIGNED'
  }

  export enum ReportLossStageEnum {
    notificationStage = 'Notification Stage',
    claimInspectionStage = 'Claim Inspection Stage',
    liabilityConfirmationStage = 'Liability Confirmation Stage',
    settlementStage = 'Settlement Stage'
  }
  export enum GarageFieldEnum {
   garagecontact = 'garageContactDetails',
    garagrlocation = 'garageLocation',
    garagename='garageName'
  }
  export enum MimeTypeEnum {
    IMAGE = "image",
    PDF = "pdf"
  }

  export enum EntityName{
    insuredDetails = 'InsuredDetails',
  tpDetails = 'ThirdPartyDetails',
  lossDetails = 'LossDetails',
  policeDetails = 'PoliceReport',
  garageDetails = 'GarageInfo',
  surveyDetails = 'SurveyDetails',
  surveyReport = 'SurveyReport',
  recoveryDetails = 'RecoveryDetails',
  reserveReview = 'ReserveReview',
  contact = 'Contact',
  garageInvoice = 'GarageInvoice',
  debitNote = 'DebitNote',
  creditNote = 'CreditNote',
  }

  export enum REPORTHEADER{
    accepted= 'ACCEPTED',
    rejected= 'REJECTED',
    need_more_details='NEED_MORE_DETAILS',
    save= 'SAVE',
    assign_surveyor= 'ASSIGN_SURVEYOR',
    dispute= 'DISPUTE',
    details_provuded= 'DETAILS_PROVIDED',
    approved= 'APPROVED',
    reopen= 'REOPEN',
    dispute_repon= 'DISPUTE_REOPEN',
    notification_rejected = "NOTIFICATION REJECTED"
  }

  export enum ErrorCodeToIgnore{
    companyLogoError = 'E7117'
  }

  export enum DateTime{
    startingTime=" 00:00:00",
    endingTime=" 23:59:00"
  }

  export const UserManagementRoleRestriction = [
    {
      menuName:appConst.MENU_CONSTANTS.MENUNAME.DASHBOARD.NAME,
      isEdit: false,
      isNotification:false,
      isDownload:true,
      isView:true
    },
    {
      menuName:appConst.MENU_CONSTANTS.MENUNAME.RECEIVABLE.NAME,
      isEdit: true,
      isNotification:true,
      isDownload:false,
      isView:true
    },
    {
      menuName:appConst.MENU_CONSTANTS.MENUNAME.PAYABLE.NAME,
      isEdit: true,
      isNotification:true,
      isDownload:false,
      isView:true
    },
    {
      menuName:appConst.MENU_CONSTANTS.MENUNAME.REPORTS.NAME,
      isEdit: true,
      isNotification:false,
      isDownload:true,
      isView:true
    },
    {
      menuName:appConst.MENU_CONSTANTS.MENUNAME.USERMANAGEMENT.NAME,
      isEdit: true,
      isNotification:false,
      isDownload:false,
      isView:true
    },
    {
      menuName:appConst.MENU_CONSTANTS.MENUNAME.ENTITYMANAGEMENT.NAME,
      isEdit: true,
      isNotification:false,
      isDownload:false,
      isView:true
    }
  ]

  export enum ToasterMessage {
    claimAccepted='Claim Accepted',
    claimRejected='Claim Rejected',
    moreDetailsRequired='More Details Required',
    claimInitiatedSuccessfully='Claim Initiated Successfully',
    claimSubmitted='Claim Submitted',
    surveyorAssigned='Surveyor Assigned',
    disputeRaised='Dispute Raised',
    detailsProvided='Details Provided',
    claimApproved='Claim Approved',
    claimReponed='Claim Reopened',
    disputeReopened='Dispute Reopened'
  }

  export enum AmountFormatEnum {
    minimumDecimal = 2,
    maximumDecimal = 2,
    commaSeparator = 2
  }
