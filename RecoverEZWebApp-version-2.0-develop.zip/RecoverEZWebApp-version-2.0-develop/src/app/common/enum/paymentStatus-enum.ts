export enum PaymentSatus {
    SUBMITTED = "Submitted",
    APPROVED = "Approved",
    REJECTED = "Rejected",
    PAID = "Paid"
}

export enum PaymentNotificationStatus {
    
	PAYMENT_FROM_INSURANCE_SUBMITTED_TO_INSURANCE="Payment From Insurance Submitted To Insurance",
	PAYMENT_FROM_INSURANCE_APPROVED_BY_INSURANCE="Payment From Insurance Approved By Insurance",
	PAYMENT_FROM_INSURANCE_REJECTED_BY_INSURANCE="Payment From Insurance Rejected By Insurance",

	PAYMENT_FROM_INSURANCE_SUBMITTED_TO_ASSOCIATION="Payment From Insurance Submitted To Association",
	PAYMENT_FROM_INSURANCE_APPROVED_BY_ASSOCIATION="Payment From Insurance Approved By Association",
	PAYMENT_FROM_INSURANCE_REJECTED_BY_ASSOCIATION="Payment From Insurance Rejected By Association",

	PAYMENT_FROM_ASSOCIATION_SUBMITTED_TO_INSURANCE="Payment From Association Submitted To Insurance",
	PAYMENT_FROM_ASSOCIATION_APPROVED_BY_INSURANCE="Payment From Association Approved By Insurance",
	PAYMENT_FROM_ASSOCIATION_REJECTED_BY_INSURANCE="Payment From Association Rejected By Insurance",

}