export enum PaymentMethodEnum {
    CHEQUE = "CHEQUE"
}