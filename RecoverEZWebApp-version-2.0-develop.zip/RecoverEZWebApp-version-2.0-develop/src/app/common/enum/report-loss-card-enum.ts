import { StageNameReportLoss } from "./enum";


export const ReportLossConst = {
    STATUS: {
      DRAFT: {
        ISRECEIVABLE: true,
        ENABLED_CARDS: [
          StageNameReportLoss.insuredDetails,
          StageNameReportLoss.tpDetails,
          StageNameReportLoss.lossDetails,
          StageNameReportLoss.policeDetails,
          StageNameReportLoss.garageDetails,
          StageNameReportLoss.surveyDetails
        ]
      },
      NOTIFICATION_OPEN: {
        ISRECEIVABLE: true,
        ENABLED_CARDS: [
          StageNameReportLoss.garageDetails,
          StageNameReportLoss.surveyDetails
        ]
      },
      NOTIFICATION_RECEIVED: {
        ISRECEIVABLE: false,
        ENABLED_CARDS: [
          StageNameReportLoss.tpDetails
        ]
      },
      NOTIFICATION_ACCEPTED:{
        ISRECEIVABLE:true,
        ENABLED_CARDS:[
          StageNameReportLoss.garageDetails,
          StageNameReportLoss.surveyDetails
        ]
      },
      MOVED_TO_INSPECTION_NEED_MORE_DETAILS:{
        ISRECEIVABLE:true,
        ENABLED_CARDS:[
          StageNameReportLoss.garageDetails,
          StageNameReportLoss.surveyDetails
        ]
      },
      MOVED_TO_INSPECTION:{
        ISRECEIVABLE:false,
        ENABLED_CARDS:[
          StageNameReportLoss.surveyReport
        ]
      },
      UNDER_INSPECTION:{
        ISRECEIVABLE:false,
        ENABLED_CARDS:[
          StageNameReportLoss.surveyReport
        ]
      }, RECEIVED_LIABILITY:{
        ISRECEIVABLE:true,
        ENABLED_CARDS:[
          StageNameReportLoss.recoveryDetails
          // StageNameReportLoss.surveyReport
        ]
      }, LIABILITY_ACCEPTED:{
        ISRECEIVABLE:true,
        ENABLED_CARDS:[
          StageNameReportLoss.garageInvoice,
          StageNameReportLoss.recoveryDetails
        ]
      }, SURVEYOR_ASSIGNED:{
        ISRECEIVABLE:true,
        ENABLED_CARDS:[
          StageNameReportLoss.recoveryDetails
        ]
      },RECOVERY_DTLS:{
        ISRECEIVABLE:true,
        ENABLED_CARDS:[
          StageNameReportLoss.recoveryDetails
        ]
      },TOTALLOSS_INIATED_NEED_INFO_REOPEN:{
        ISRECEIVABLE:false,
        ENABLED_CARDS:[
          StageNameReportLoss.surveyReport
        ]
      },
      SURVEYOR_ASSIGNED_NEED_INFO_REOPEN:{
        ISRECEIVABLE:true,
        ENABLED_CARDS:[
          StageNameReportLoss.recoveryDetails
        ]
      },RECEIVED_LIABILITY_DISPUTE_REOPEN:{
        ISRECEIVABLE:false,
        ENABLED_CARDS:[
          StageNameReportLoss.surveyReport
        ]
      },EXPENSES_AND_DOCUMENT_UPDATED:{
        ISRECEIVABLE:false,
        ENABLED_CARDS:[
          StageNameReportLoss.surveyReport
        ]
      },TOTALLOSS_INIATED_RECEIVABLE:{
        ISRECEIVABLE:true,
        ENABLED_CARDS:[
          StageNameReportLoss.recoveryDetails
        ]
      },DEBIT_NOTE_NEED_MORE_INFO:{
        ISRECEIVABLE:true,
        ENABLED_CARDS:[
          StageNameReportLoss.recoveryDetails,
        ]
      },RESERVE_REVIEW_DISPUTE_REPOEN:{
        ISRECEIVABLE:true,
        ENABLED_CARDS:[
          StageNameReportLoss.recoveryDetails,
        ]
      },TOTALLOSS_INIATED_SURVEY_REPORT_DETAILS_PROVIDED:{
        ISRECEIVABLE:true,
        ENABLED_CARDS:[
          StageNameReportLoss.surveyReport
        ]
      }
    }
  };
