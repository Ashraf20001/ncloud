import { Component, Inject, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';
import moment from 'moment';
import { ToastrService } from 'ngx-toastr';
import { DisableDto } from 'src/app/models/disable-dto';
import { MAT_DATE_FORMATS } from '@angular/material/core';

const CUSTOM_DATE_FORMAT = {
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'MMM YYYY'
  }
};

@Component({
  selector: 'app-disable-popup',
  templateUrl: './disable-popup.component.html',
  styleUrls: ['./disable-popup.component.css'],
  providers: [
    { provide: MAT_DATE_FORMATS, useValue: CUSTOM_DATE_FORMAT }
  ]
})
export class DisablePopupComponent implements OnInit{
    
  effectiveDate = new FormControl();
  disableDto = new DisableDto();
  minimumDate = new Date();
  msg:string;
  constructor(public dialogRef: MatDialogRef<DisablePopupComponent>, @Inject(MAT_DIALOG_DATA) public data: Data,private toaster:ToastrService,private translate: TranslateService) { }
 
  ngOnInit(): void {
   
   this.msg =  this.translate.instant("DisablePopUp.popup_msg").replace('[type]',this.data.name).replace('[status]',this.data.status).replace('[النوع]',this.data.name).replace('[الحالة]',this.data.name);
   
  }
  /*
  * Clear Date Field
  */
  clearDateField(){
    this.effectiveDate.setValue(null); 
  }
  /*
  * Cancel
  */
  cancel(value: boolean) {
    this.dialogRef.close(value);
  }
  /*
  * Submit
  */
  submit() {
    if(this.effectiveDate.value != null){
      const dateWithEndTime = moment(this.effectiveDate.value).endOf("day");
      this.disableDto.effectiveDate = dateWithEndTime.format("YYYY-MM-DDTHH:mm:ss") + 'Z';
      this.dialogRef.close(this.disableDto);
    }else{
      const errorMsg = this.translate.instant("Toaster_Message.Disable_Exceed")
      this.toaster.error(errorMsg.replace('User',this.data.name));
    }
    
  }
  /*
  * CloseTab
  */
  closeTab(){
    this.dialogRef.close(false);
  }

}

export interface Data {
  status: string;
  name:string;
  effectiveDate: string;
  }
