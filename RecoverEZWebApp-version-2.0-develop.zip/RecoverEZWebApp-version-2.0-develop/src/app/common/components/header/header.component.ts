import { EventEmitter, OnDestroy, OnInit, Output } from '@angular/core';
import { Component } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { I18nServiceService } from 'src/app/service/i18n-service.service';
import * as Stomp from 'stompjs';
import * as SockJS from 'sockjs-client';
import { DashboardService } from 'src/app/service/dashboard.service';
import { HttpParams } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { NotificationService } from 'src/app/service/notification.service';
import { Subscription } from 'rxjs';
import { ErrorHandlerDirective } from '../../directives/errorHandler.directive';
import { NotificationDTO } from 'src/app/models/notification-dto';
import { AppService } from 'src/app/service/role access/service/app.service';
import { appConst } from 'src/app/service/app.const';
import { AdminService } from 'src/app/service/admin.service';
import { NotificationPopupComponent } from '../notification-popup/notification-popup.component';
import { MatDialog } from '@angular/material/dialog';
import { ReceivableService } from 'src/app/service/receivable.service';
import { PaymentNotificationStatus } from '../../enum/paymentStatus-enum';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})

export class HeaderComponent implements OnInit,OnDestroy{

  showmessage=false;
  companyId:string;
  imgUrl='';
  stompClient: any;
  socket: any;
  notificationCount: any = 0;
  companyName: any = '';
  currentCompanyName: string;
  noNotification = false;
  notificationSubscribtion: Subscription;
  notoficationCountSubscription:Subscription;
  notificationDetailsList: NotificationDTO[];
  menuHeaderList: any;
  notification_Data:any[]=[
    {
      profileImg: 'assets/prfile.svg',
      content:'Garage details has been added for',
      claimId:'1235',
      company:'Partner Insurance Limited',
    },
    {
      profileImg:'assets/prfile.svg',
      content:'Garage details has been added for ',
      claimId:'1235',
      company:'Partner Insurance Limited',
    },
  ]
  public appConst = appConst;

  @Output() showClaimEvent = new EventEmitter<{ claimId: string, isReceivable: boolean }>();
  @Output() fullViewNotification=new EventEmitter<boolean>();
  isReceivable = true;
  fromNotification = false;
  userName:string = sessionStorage.getItem('username');
  temp: NotificationDTO[];
  currentLanguage: string;

constructor(public dialog: MatDialog,private route:Router,  public i18nConf: I18nServiceService,private dashboardService: DashboardService, private activatedRoute: ActivatedRoute,
  private notificationService: NotificationService,private errorHandler: ErrorHandlerDirective, private appservice: AppService, private adminService: AdminService,
  private receivableService:ReceivableService,public toastr: ToastrService, private translate:TranslateService){
  this.getCurrentUrl();
  this.i18nConf = i18nConf;
  this.i18nConf.setUpConf();
  this.getLoggedInUserCompanyId();
  this.currentCompanyName  = sessionStorage.getItem("companyName");
  this.userName=sessionStorage.getItem('username');
  this.translate.use(sessionStorage.getItem("Language"));
}
  currentRoute: string;

getCurrentUrl(){
  this.currentRoute = window.location.href;
  this.route.events.subscribe((event: any) => {
    if (event instanceof NavigationEnd) {
      this.currentRoute = event.url
    }
  });

}

  isAdmin:boolean;

  ngOnInit(): void {
  this.getMenuItems();

  this.isAdmin = this.adminService.isAssociationUser();


    this.notificationGET();
    this.notificationCountGET();


  this.activatedRoute.queryParams.subscribe((queryParams: any) => {
    if(!this.fromNotification) {
      this.isReceivable = queryParams["rec"] !== undefined ? queryParams["rec"] !== 'false' : true;
    }
     this.receivableService.getChangePayableTab().subscribe(res =>{
      if(res){
        this.isReceivable = (sessionStorage.getItem("toggleButtonStatus") == "false");
      }
     })
  });
  
  this.translate.onLangChange.subscribe(() => {
    this.fetchNotificationData();
  })
  if(!sessionStorage.getItem("toggleButtonStatus")){
    sessionStorage.setItem("toggleButtonStatus",JSON.stringify(this.receivable));
  }
  }

baseUrl = environment.NOTIFICATION_BASE_URL;

  collapsed=true;
  nav1='dashboard'
  nav2='reportloss'
  nav3='receivable'
  nav4='payable'
  nav5='user'

  /**
   * GET COMPANY ID OF LOGGED-IN USER
   */
  getLoggedInUserCompanyId(){
    const identity = sessionStorage.getItem("userIdentity");
    const params =  new HttpParams().set("user_id",identity);
    this.dashboardService.getLoggedInUserCompanyId(params).subscribe((data:any)=>{
      const name = data?.companyId.name;
      this.companyId = data?.companyId?.companyId;
      if(name != null){
        this.companyName = name;
        this.connectWebSocket();
      }
      if(this.companyId) {
        this.dashboardService.getCompanyLogo(this.companyId).subscribe((response)=>{
          if (response) {
            this.imgUrl = response['content']
          }
        });
      }
    });
  }

  /**
   * WEBSCKET CONNECTION & SUBSCRIPTION
   */
  connectWebSocket() {
    const userIdentity = sessionStorage.getItem('userIdentity');
    this.socket = new SockJS(this.baseUrl + '/notify/ws');
    this.stompClient = Stomp.over(this.socket);
    const _this = this;
    _this.stompClient.connect({}, function (frame: any) {
      _this.stompClient.subscribe(
        '/topic/notification/' + _this.companyName + '/' + userIdentity,
        function (response: any) {
          _this.onMessageReceived(response);
        }
      );
    });
  }

  /**
   * NOTIFICATION COUNT ADDITION - WEBSOCKET
   * @param response
   */
  onMessageReceived(response: any) {
    let notification = JSON.parse(response.body);
    if(notification != null || notification != undefined){
      notification = this.replaceNotificationContent(notification);
      this.notificationDetailsList.unshift(notification);
      this.notificationCount = this.notificationCount + 1;
      this.noNotification = this.notificationCount === 0;
    }
  }

  /**
   * NOTIFICATION GET CALL METHOD
   */
  notificationGET(){

    this.notificationSubscribtion = this.notificationService.getNotificationList().subscribe((res:any)=>{
      if(res) {
       this.temp = res;
        this.fetchNotificationData();
      }
    },(error:Response)=>{
      this.errorHandler.getMessage(error);
    })
  }

  replaceNotificationContent(x: NotificationDTO): NotificationDTO {
    if (x.status && x.template) {
      var notificationTemplate = this.translate.instant(`NotificationTemplate.${x.status.toUpperCase()}`);
      const parsedObject = JSON.parse(x.rePlacableTemplateData);
      const keyValueList = [];
      for (const key in parsedObject) {
        if (parsedObject.hasOwnProperty(key)) {
          keyValueList.push({ key, value: parsedObject[key] });
        }
      }
      keyValueList.forEach(({ key, value }) => {
        // const regex = new RegExp(key, "g");
        notificationTemplate = notificationTemplate.replaceAll(key, value);
      });
      if (!notificationTemplate.includes('NotificationTemplate')) {
        x.template = notificationTemplate;
      }
    }
    return x;
  }

  private fetchNotificationData() {
    this.temp.map(x => this.replaceNotificationContent(x));
    this.notificationDetailsList = this.temp;
  }

  /**
   * NOTIFICATION COUNT CALL GET METHOD
   */
  notificationCountGET(){
    this.notoficationCountSubscription = this.notificationService.getNotificationCount().subscribe((res:any)=>{
      let result = res;
      this.notificationCount = result ? result.totalCount : 0;
      this.noNotification = this.notificationCount === 0;
    },(error:Response)=>{
      this.errorHandler.getMessage(error);
    })
  }
  /**
   * DESTROY THE SUBSCRIBTION
   */
  ngOnDestroy(): void {
    if(this.notificationSubscribtion){
      this.notificationSubscribtion.unsubscribe();
    }
    if(this.notoficationCountSubscription){
      this.notoficationCountSubscription.unsubscribe();
    }
  }

  getNotificationLogo(notification: NotificationDTO): string {
    let name = '';
    name = notification.lastActedCompany;
    if(name === 'AXA insurance') {
      name = 'AXA';
    }
    const logo = 'assets/company_logo/' + name + '_Logo.png';
    return logo;
  }

  showClaim(notification: NotificationDTO, index : number): void {

    sessionStorage.setItem('ViewReportLoss',JSON.stringify(this.isReceivable));
    if(Object.values(PaymentNotificationStatus).includes(notification.status as PaymentNotificationStatus)){
      this.route.navigateByUrl("/payment/paymentList");
      this.updateNotification(notification.approvalId);

    }
    else if(notification.status != "Edit Approval Limit"
      &&  notification.status != "Add Approval Limit"
      && notification.status != "Payment Submitted"
      && notification.claimIdentity){
      this.notificationDetailsList.splice(index,1)
      this.notificationCount--;
      this.isReceivable = notification.receivable;
      this.fromNotification = true;
      this.showClaimEvent.emit({
        claimId: notification.claimIdentity,
        isReceivable: this.isReceivable
      });
    }
    else{
      this.updateNotification(notification.approvalId);
    }

  }
  updateNotification(event:number){

    this.notificationService.updateNotification(event).subscribe((res:any)=>
    (error:Response)=>{
      this.errorHandler.getMessage(error);
    })
    this.notificationGET();
  this.notificationCountGET();
  }

  getMenuHeader(pageName: string): boolean{
    const menuHeader = this.menuHeaderList?.find((element) => element.menuName === pageName);
    return menuHeader;
  }

  getMenuItems(){
    this.appservice.getMenubyRole().subscribe((res: any)=>{
      this.menuHeaderList = res.content;
      if(this.menuHeaderList.length>0){
        this.appservice.menuList$.next(this.menuHeaderList);
        this.appservice.menuListFromHeader = this.menuHeaderList;
      }else{
        this.toastr.error(this.translate.instant('Backend_Toaster_Error.E7149'));
        sessionStorage.clear();
        this.route.navigate([''])
      }
    });
  }
  getLogo(){
    if (this.imgUrl!=='') {
      return this.imgUrl;
    }else{
      return 'assets/company_logo/no_company_logo.jpg';
    }
  }
  setDefaultNotificationImage(index:any){
    this.notificationDetailsList[index].imageUrl = 'assets/company_logo/no_company_logo.jpg';
  }

  setDefaultLogoImage(){
    this.imgUrl = 'assets/company_logo/no_company_logo.jpg';
    return this.imgUrl;
  }

  notification_fullview(){

    this.fullViewNotification.emit();


  }
  popup_fullscreen()

  {
    this.showmessage=true;
    const dialogRef = this.dialog.open(NotificationPopupComponent, {
     width:'600px',
    //  height:'577px'
      data: {
        currentLang: this.translate.currentLang,
        notificationData: this.notificationDetailsList
      }
    });

    dialogRef.afterClosed().subscribe(result => {
     if(result){

        this.showClaim(result, result.index);
     }

    });
  }

  doLogout(): void {    
    setTimeout(() => {
      this.currentLanguage = sessionStorage?.getItem('Language');
      this.currentLanguage = localStorage.getItem('Language');
      sessionStorage.clear();
      this.route.navigate(['']);
      sessionStorage.setItem('Language', this.currentLanguage);
    }, 500);
  }


  toggle(){

  }
  dashboards=false;
  receivable=false;
  payable=false;
  reports=false;
  usermangement=false;
  navcollaps=false;
  PageConfigurator=false;
  EntityManagement=false;
  payment=false;
  exportImport=false;

  // mobilefunction(selected:boolean){
    dashboard(){
      this.dashboards=true;
      this.receivable=false;
      this.payable=false;
      this.reports=false;
      this.usermangement=false;
      this.PageConfigurator=false;
      this.EntityManagement=false;
      this.payment=false;
      this.exportImport=false;
    }
    Receivable(){
      this.dashboards=false;
      this.receivable=true;
      this.payable=false;
      this.reports=false;
      this.usermangement=false;
      this.PageConfigurator=false;
      this.EntityManagement=false;
      this.payment=false;
      this.exportImport=false;
      this.receivableService.setBackToRcvleCard_PayableCard(true);
    }
    Payable(){
      this.dashboards=false;
      this.receivable=false;
      this.payable=true;
      this.reports=false;
      this.usermangement=false;
      this.PageConfigurator=false;
      this.EntityManagement=false;
      this.payment=false;
      this.exportImport=false;
      this.receivableService.setBackToRcvleCard_PayableCard(true);
    }
    Reports(){
      this.dashboards=false;
      this.receivable=false;
      this.payable=false;
      this.reports=true;
      this.usermangement=false;
      this.PageConfigurator=false;
      this.EntityManagement=false;
      this.payment=false;
      this.exportImport=false;
    }

    UserManagement(){
      this.dashboards=false;
      this.receivable=false;
      this.payable=false;
      this.reports=false;
      this.usermangement=true
      this.PageConfigurator=false;
      this.EntityManagement=false;
      this.payment=false;
      this.exportImport=false

    }
    pageConfigurator(){
      this.dashboards=false;
      this.receivable=false;
      this.payable=false;
      this.reports=false;
      this.usermangement=false;
      this.EntityManagement=false;
     this.PageConfigurator=true;
     this.payment=false;
     this.exportImport=false;
    }
    entityManagement(){
      this.dashboards=false;
      this.receivable=false;
      this.payable=false;
      this.reports=false;
      this.usermangement=false;
      this.PageConfigurator=false;
      this.EntityManagement=true;
      this.payment=false;
      this.exportImport=false;
    }
    payments(){

      this.dashboards=false;
      this.receivable=false;
      this.payable=false;
      this.reports=false;
      this.usermangement=false;
      this.PageConfigurator=false;
      this.EntityManagement=false;
      // this.payment=false;
      this.payment=true;
      this.exportImport=false;
    }
  exportAndImport()
  {
    this.dashboards=false;
    this.receivable=false;
    this.payable=false;
    this.reports=false;
    this.usermangement=false;
    this.PageConfigurator=false;
    this.EntityManagement=true;
    this.payment=false;
    this.exportImport=true;
  }

}



