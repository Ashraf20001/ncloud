import { ChangeDetectorRef, Component, Inject, OnInit, Optional } from '@angular/core';
import { NotificationDTO } from 'src/app/models/notification-dto';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';
import { I18nServiceService } from 'src/app/service/i18n-service.service';


@Component({
  selector: 'app-notification-popup',
  templateUrl: './notification-popup.component.html',
  styleUrls: ['./notification-popup.component.scss']
})
export class NotificationPopupComponent implements OnInit {

  notificationCount = 0;
  notificationDetailsList: NotificationDTO[];
  currentLang: any;

  constructor(private dialog: MatDialog, private dialogRef: MatDialogRef<NotificationPopupComponent>,
    public i18nConf: I18nServiceService, private translate: TranslateService, private ref: ChangeDetectorRef,
    @Optional() @Inject(MAT_DIALOG_DATA) dialogData: any) {
    this.translate.use(sessionStorage.getItem("Language"));
    this.currentLang = sessionStorage.getItem("Language")
    this.i18nConf.currentLang =  this.currentLang ;
    this.i18nConf = i18nConf;
    this.i18nConf.setUpConf();
    this.notificationDetailsList = dialogData.notificationData;
    this.notificationCount = this.notificationDetailsList ? this.notificationDetailsList.length : 0;
  }

  ngOnInit(): void {
    this.translate.onLangChange.subscribe(() => {
      const temp = this.notificationDetailsList;
      this.notificationDetailsList = [];
      this.notificationDetailsList = temp;
      this.notificationCount = this.notificationDetailsList ? this.notificationDetailsList.length : 0;
      this.ref.detectChanges();
    })
  }

  showClaim(notification: NotificationDTO, index : number): void {
    this.notificationDetailsList.splice(index,1)
    notification.index=index;
    this.dialogRef.close(notification);
  }

  closeTab(): void {
    this.dialog.closeAll();
  }

}
