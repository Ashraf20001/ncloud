import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {MatCardModule} from '@angular/material/card';
import { MatSlideToggleModule } from '@angular/material/slide-toggle'
import {MatDividerModule} from '@angular/material/divider';
import {  TranslateModule } from '@ngx-translate/core';
import { NgbPopoverModule } from '@ng-bootstrap/ng-bootstrap';
import { PopupComponent } from "./popup/popup.component";
import { HeaderComponent } from "./header/header.component";
import { PagenotfoundComponent } from "./pagenotfound/pagenotfound.component";
import { CommonCardComponent } from "./card-component/common-card.component";
import { DemoMaterialModule } from "./material-module";
import{BreadcrumbComponent} from './breadcrumb/breadcrumb.component'
import{BreadcrumbService,BreadcrumbModule} from 'xng-breadcrumb'
import {RouterModule} from '@angular/router';
import { AppService } from "src/app/service/role access/service/app.service";
import { NotificationPopupComponent } from './notification-popup/notification-popup.component';
import {MatDialogModule} from '@angular/material/dialog';
import { DisablePopupComponent } from './disable-popup/disable-popup.component';
import { MatMomentDateModule, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from "@angular/material-moment-adapter"

@NgModule({
  declarations:[
    HeaderComponent,
    PagenotfoundComponent,
    CommonCardComponent,
    PopupComponent,
    BreadcrumbComponent,
    NotificationPopupComponent,
    DisablePopupComponent
  ],
  imports:[
    CommonModule,MatDialogModule,
    FormsModule,
    MatCardModule,
    MatSlideToggleModule,
    MatDividerModule,
    TranslateModule,
    NgbPopoverModule,
    DemoMaterialModule,
    BreadcrumbModule,
    RouterModule,
    ReactiveFormsModule ,
    MatMomentDateModule
  ],
  exports:[
    HeaderComponent,
    PagenotfoundComponent,
    CommonCardComponent,
    PopupComponent,
    BreadcrumbComponent
  ],
  providers:[
    BreadcrumbService,
    CommonCardComponent,
    AppService,
    { provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: { useUtc: true } }
  ]
})

export class AppCommonModule{

}
