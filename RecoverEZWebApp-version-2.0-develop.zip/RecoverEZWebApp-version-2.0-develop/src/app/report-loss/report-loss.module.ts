/* eslint-disable @typescript-eslint/no-unused-vars */
import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { ReportLossRoutingModule } from "./report-loss-routing.module";
import { ReportLossComponent } from "./report-loss.component";
import { NumberPipe } from "../common/pipes/custom-pipe/number.pipe";
import { ReceivableModule } from "./receivable/receivable.module";
import { PayableModule } from "./payable/payable.module";
import { ReportLossCommonModule } from "./common/report-loss-common.module";
import { DemoMaterialModule } from "../common/components/material-module";
import {  TranslateModule } from '@ngx-translate/core';

@NgModule({
  declarations:[
    ReportLossComponent,
    NumberPipe
  ],
  imports:[
    CommonModule,
    FormsModule,
    ReportLossRoutingModule,
    ReceivableModule,
    PayableModule,
    DemoMaterialModule,
    TranslateModule
  ],
  exports:[

  ]
})

export class ReportLossModule{

}
