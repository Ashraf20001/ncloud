import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { ReportLossComponent } from "../report-loss.component";


const routes : Routes =  [
  {
    path: '', component: ReportLossComponent,
    children : [
      // {
      //   path: 'authority',  component: AuthorityLoginComponent
      // },
      {
        path: '',  redirectTo: 'report-loss', pathMatch: "full"
      },
    ]
  }
]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class PayableRoutingModule { }
