import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { PayableRoutingModule } from "./payable-routing.module";
import { PayableComponent } from "./payable.component";

@NgModule({
  declarations:[
    PayableComponent,
  ],
  imports:[
    CommonModule,
    FormsModule,
    PayableRoutingModule,

  ]
})

export class PayableModule{

}
