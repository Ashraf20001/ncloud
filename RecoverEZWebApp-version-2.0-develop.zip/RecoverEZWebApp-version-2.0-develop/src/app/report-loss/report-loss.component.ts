import { Component} from '@angular/core';

@Component({
  selector: 'app-report-loss',
  templateUrl: './report-loss.component.html',
  styleUrls: ['./report-loss.component.scss']
})

export class ReportLossComponent {











}
