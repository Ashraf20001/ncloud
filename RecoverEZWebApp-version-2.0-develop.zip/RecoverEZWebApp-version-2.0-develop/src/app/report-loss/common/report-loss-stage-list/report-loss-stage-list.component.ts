import { MimeTypeEnum, ReportLossStageEnum, ReportLossStatus } from './../../../common/enum/enum';
import { ToastrService } from 'ngx-toastr';
import { TotalLoss } from './../../../models/report-loss-dto/total-loss';
import { FormGroup, FormControl, Validators } from '@angular/forms';
/* eslint-disable @angular-eslint/no-empty-lifecycle-method */
import { OnChanges, SimpleChanges, OnInit, ViewChild, ElementRef } from '@angular/core';
/* eslint-disable prefer-const */
import { DatePipe } from '@angular/common';
/* eslint-disable @typescript-eslint/no-empty-function */
import { ReportLossData } from './../../../models/report-loss-dto/report-loss-data';
/* eslint-disable @typescript-eslint/no-inferrable-types */
import { Section } from 'src/app/models/report-loss-dto/section';
import { Field } from './../../../models/report-loss-dto/field';
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, EventEmitter, Input, Output } from '@angular/core';

import { ReportLossService } from 'src/app/service/report-loss.service';
import { StageNameReportLoss } from 'src/app/common/enum/enum';
import { DropDownServiceService } from 'src/app/service/drop-down-service.service';
import { FileUploadService } from 'src/app/service/file-upload.service';
import { ActivatedRoute } from '@angular/router';
import { ReportLossConst } from 'src/app/common/enum/report-loss-card-enum';
import { AdminService } from 'src/app/service/admin.service';
import { TranslateService } from '@ngx-translate/core';
import { ParentDropdownFieldMap } from 'src/app/models/report-loss-dto/parentDropdownField';
import moment from 'moment';
import { AppService } from 'src/app/service/role access/service/app.service';
import { appConst } from 'src/app/service/app.const';

@Component({
  selector: 'app-report-loss-stage-list',
  templateUrl: './report-loss-stage-list.component.html',
  styleUrls: ['./report-loss-stage-list.component.scss'],
})
export class ReportLossStageListComponent implements OnChanges,OnInit{
  @ViewChild('fileDropRef') hiddenInput: ElementRef;
  @Input() name: string;
  @Input() sectionFromCard: Field[];
  @Input() sectionToChild: Section;
  @Input() isReceivableFromCommon: boolean;
  @Input() reportLossDataToSubChild: ReportLossData;
  @Input() surveyDueHours:string;
  @Output() selectedFieldListItems = new EventEmitter<{ fileData: FileUploadDTO, sectionName: string, data: Field[], isAllDeleted: boolean, removedFileList: number[] }>();
  @Output() showCardView = new EventEmitter<boolean>();
  @Output() isFieldsFull = new EventEmitter<any>();
  @Output() showParent = new EventEmitter<void>();
  @Output() sendValues = new EventEmitter<any>();
  @Output() sendIsReceivable = new EventEmitter<boolean>();

  field: Field;

  showCards: boolean;
  show:boolean=false;
  dropdownlist: any;
  modelDropdownlist: any;
  ReportLossService: any;
  reporting: any;
  reportingList: any;
  formFlag: boolean;
  selectedItemFieldList: any;

  amount1:number;
  amount2:number;
  totalAmount:number =0;
  adjustor1:string;
  adjustor2:string;
  date1:any;
  date2:any;
  totalLossReason:string;
  nameOfSalvageSeller:string;
  nameOfSalvageBuyer:string;
  salvageTotal:number;

  saveButton = true;
  downloadAndPreviewButton = false;
  lastStatus:string;
  status:string;
  isPdfShown = false;

  readOnlyField = true;
  dateOfPurchase:string;

  isSurveyReport:boolean=false;
  isRecoveryDetails:boolean=false;
  totallosshidden:boolean=true;
  isLossDetailTotalLoss:boolean=false;

  url:any;
  maxDate = new Date();
  minDate = new Date();
  lastDate = new Date(new Date().setFullYear(new Date().getFullYear() - 10));

  fiveYearBack = new Date(new Date().setFullYear(new Date().getFullYear() - 5));
  minYearBack = new Date(new Date().setFullYear(new Date().getFullYear() - 1));

  tpSurveyAmount = 0;
  fileName = 'Drag and drop file or';
  fileType:any
  fileViewList = [];
  reasonTotalLossDropDown:any = [];
  isReceivablepage: boolean = false;
  isDisabled: boolean = false;
  valueChoosed: boolean = false;
  showDownload:boolean=false;

  setMinDecimal=false;
  setMinDecimalPipeAmount1=false;
  setMinDecimalPipeAmount2=false;
  setMinDecimalPipeAmount3=false;
  setMinDecimalPipeAmount4=false;
  activeSection: Section;
  isClaimSettled = false;
  isTotalLossInitiated = false;
  surveyAmount: any;
  salvageAmount: number;
  showSpareAmt = false;
  isAtFaultInitiated = false ;
  showSurveyAmount = false;
  disableSurveyDatePicker1 = false ;
  disableSurveyDatePicker2 = false ;
  atFaultCompanyName: string;
  insurerName: string;
  showDate = new Date();
  showDate1 : string;
  dueDate: number;
  minimumDate= new Date();
  disableSurveyDueDate= false;
  rdClaimAmount: number;
  parentFieldMap: ParentDropdownFieldMap[];
  pageInfo: any;
  public appConst = appConst;
  pageId = appConst.PAGE_NAME.RECEIVABLE.RECEIVABLE_REPORTLOSS.PAGEID;
  constructor(
    private dataservice: ReportLossService,
    public datepipe: DatePipe,
    private toaster:ToastrService,
    private dropDownService : DropDownServiceService,
    private fileUploadService: FileUploadService,
    private adminService: AdminService,
    private translate: TranslateService,
    private appService : AppService
  ) {
  }

  receivable= true;
  receivableString:string;
  totalLossType:string;

  ngOnChanges(changes: SimpleChanges): void {
    if (changes) {
      this.sendValues.emit(this.sendValue)
      this.sendIsReceivable.emit(this.receivable)
            this.dateOfPurchase = this.reportLossDataToSubChild?.metaData.sectionList[0].sectionList[0].fieldList[3].value;
      this.lastStatus = this.reportLossDataToSubChild?.lastStatus;
      this.status = this.reportLossDataToSubChild?.status;
      this.totalLossType = this.reportLossDataToSubChild?.totalLossType;
      //this.checkTotalLoss();
      this.showSaveButton();
      this.showDownloadAndPreviewButton();
      this.differenceBtwDate();
      this.showDownloadButton()
      if(this.dateOfPurchase != null &&  this.dateOfPurchase != undefined){
        const date = new Date(this.dateOfPurchase);
        this.fiveYearBack = date;
        this.minYearBack=date;
        this.lastDate = new Date(this.dateOfPurchase);
      }
    }
    this.receivable = this.isReceivableFromCommon;
    this.getPrivilege();
    this.mutliLanguageForField();
    this.translate.onLangChange.subscribe(() => {
      this.mutliLanguageForField();
    })
  }

  makeTotalLossAmountWithFormat(){
    this.setMinDecimalPipeAmount1 = !this.setMinDecimalPipeAmount1 ;
    this.setMinDecimalPipeAmount2 = !this.setMinDecimalPipeAmount2 ;
    this.setMinDecimalPipeAmount3 = !this.setMinDecimalPipeAmount3 ;
    this.setMinDecimalPipeAmount4 = !this.setMinDecimalPipeAmount4 ;
  }
  pdfSrc = '';

  showDownloadButton(){
    const filestagenames:StageNameReportLoss[]=[];
    filestagenames.push(StageNameReportLoss.policeDetails);
    filestagenames.push(StageNameReportLoss.surveyReport);
    filestagenames.push(StageNameReportLoss.garageInvoice);

    if(filestagenames.includes(this.name as StageNameReportLoss)){
     const document = this.sectionFromCard.find((dt) => dt.fieldType === "file")?.value;
     if(document==null||document==undefined||document.endsWith("/")){
      this.showDownload=true;
     }
    }
  }


  onFileSelected() {
    let $img: any = document.querySelector('#file');
    const fileType = $img.files[0].type;
      if(fileType == "image/png" || fileType == "image/jpeg" ||
         fileType == "image/jpg" || fileType == "image/svg+xml"){
              const reader = new FileReader();
              reader.onload = (event : any) => {
                this.url = event.target.result;
              }
              reader.readAsDataURL($img.files[0]);
      }
      else if(fileType == "application/pdf"){
          if (typeof FileReader !== 'undefined') {
                let reader = new FileReader();
                reader.onload = (e: any) => {
                  this.pdfSrc = e.target.result;
                };
                reader.readAsArrayBuffer($img.files[0]);
              }
        }
  }
  checkUserIsAdmin(){
    this.adminService.isAssociationUser();
  }

  // checkTotalLoss(){
  //   if (this.totalLossType) {
  //     this.checkBoxTick = true;
  //   }
  // }

  getTotalLossDropDownValue(){
    let fieldName = "Reason for Total loss";
    this.dropDownService.getOption(null,null,fieldName).subscribe((response:any)=>{
        if (response) {
          this.reasonTotalLossDropDown = response;
        }
      })
  }

  ngOnInit(): void {
    this.getIsAtFaultInitiatedTotalLoss();
    this.getTotalLossAmount();
    this.sectionFromCard = this.sectionFromCard.sort((a: Field, b: Field) => a.orderBy - b.orderBy);
    this.activeSection = this.sectionToChild.sectionList.find((sec: Section) => sec.sectionName === this.name);
    this.receivable = this.isReceivableFromCommon;
   this.getPrivilege();
    this.dropDownService.getParentFieldMap().subscribe((res)=>{
      if(res){
        this.parentFieldMap = res.content;
        this.parentFieldMap.forEach(parentField => {
          const metaData = this.sectionFromCard.find((dt) => dt.fieldName === parentField.parentFieldName);
          const childMetaData = this.sectionFromCard.find((dt) => dt.fieldName === parentField.childFieldName);
          if (childMetaData && childMetaData?.dropDownList===undefined) {
            this.getChildDropDowValue(null,metaData);
          }
    
          if(metaData && metaData.dropDownList===undefined){
           this.buildDropDownValues(parentField.parentFieldName,metaData,null)
          }
        });
      }
    }); 

    // const parentFieldMap = this.dropDownService.getParentFieldMap();
    

    const lossDetailsTotalLoss = this.sectionFromCard.find((dt) => dt.fieldName === "ldIsTotalLoss");
    const surveyReportTotalLoss =this.reportLossDataToSubChild.metaData.sectionList.find(item=>item.sectionName==ReportLossStageEnum.claimInspectionStage).sectionList.find(item=>item.sectionName==StageNameReportLoss.surveyReport).fieldList.find(item=>item.fieldName=="srTotalLoss");

    if(lossDetailsTotalLoss != undefined){
    if(lossDetailsTotalLoss.value == "true"){
      this.checkBox = true;
      this.valueChoosed =true;
      this.isLossDetailTotalLoss=true;
      this.getTotalLoss();
    }
  }

  if(surveyReportTotalLoss != undefined){
    if(surveyReportTotalLoss != undefined&&surveyReportTotalLoss.value == "true"&&(this.name=="Survey Report"||this.name=="Recovery Details")){

      this.valueChoosed =true;
      this.checkBox = true;
      this.getTotalLoss();

    }
  }

  if(this.name=="Survey Report"){
    this.isSurveyReport=true;
  }else{
    this.isSurveyReport=false
  }

  if(this.name=="Recovery Details"){
    this.isRecoveryDetails=true;
  }else{
    this.isRecoveryDetails=false
  }
  if(this.reportLossDataToSubChild.totalLossType){
    this.surveyReportDisable(false);

  }
  if(this.isClaimSettled){
    this.TotalLoss.disable();
    this.disableSurveyDatePicker1 = true;
    this.disableSurveyDatePicker2 = true;
  }
  else if(this.isReceivableFromCommon ){
    if(this.name === "Loss Details"){
      this.TotalLoss.controls['adjustorName2'].disable();
      this.TotalLoss.controls['surveyDate2'].disable();
      this.disableSurveyDatePicker2 = true;
      this.TotalLoss.controls['totalLossAmount2'].disable();

      this.TotalLoss.controls['adjustorName1'].enable();
      this.TotalLoss.controls['surveyDate1'].enable();
      this.disableSurveyDatePicker1 = false;
      this.TotalLoss.controls['totalLossAmount1'].enable();
      this.isDisabled = true;
    }else{
      this.TotalLoss.controls['adjustorName2'].enable();
      this.TotalLoss.controls['surveyDate2'].enable();
      this.disableSurveyDatePicker2 = false;
      this.TotalLoss.controls['totalLossAmount2'].enable();

      this.TotalLoss.controls['adjustorName1'].disable();
      this.TotalLoss.controls['surveyDate1'].disable();
      this.disableSurveyDatePicker1 = true;
      this.TotalLoss.controls['totalLossAmount1'].disable();
      this.isDisabled = false;
    }
  }else{
      if(this.name === StageNameReportLoss.lossDetails){
        this.TotalLoss.controls['adjustorName1'].disable();
        this.TotalLoss.controls['surveyDate1'].disable();
        this.disableSurveyDatePicker1 = true;
        this.TotalLoss.controls['totalLossAmount1'].disable();

        this.TotalLoss.controls['adjustorName2'].enable();
        this.TotalLoss.controls['surveyDate2'].enable();
        this.disableSurveyDatePicker2 = false;
        this.TotalLoss.controls['totalLossAmount2'].enable();
        this.isDisabled = false;
      }else{
        this.TotalLoss.controls['adjustorName2'].disable();
        this.TotalLoss.controls['surveyDate2'].disable();
        this.disableSurveyDatePicker2 = true;
        this.TotalLoss.controls['totalLossAmount2'].disable();

        this.TotalLoss.controls['adjustorName1'].enable();
        this.TotalLoss.controls['surveyDate1'].enable();
        this.disableSurveyDatePicker1 = false;
        this.TotalLoss.controls['totalLossAmount1'].enable();
        this.isDisabled = true;
      }
      this.setTotalLossFieldDisable();
    }
    this.makeTotalLossAmountWithFormat();
  }
  getIsAtFaultInitiatedTotalLoss() {
    if(this.reportLossDataToSubChild!=null || this.reportLossDataToSubChild!=undefined){
      this.atFaultCompanyName = this.reportLossDataToSubChild.atFaultCompanyName;
      this.insurerName = this.reportLossDataToSubChild.insurerName;
      this.reportLossDataToSubChild.metaData.sectionList.forEach((xx:Section)=>{
        xx.sectionList.forEach(subSec=>{
          const lossDetailsTotalLoss2 = subSec.fieldList.find((dt) => dt.fieldName === "ldIsTotalLoss");
          const surveyReportTotalLoss2 = subSec.fieldList.find((dt) => dt.fieldName === "srTotalLoss");

          if(lossDetailsTotalLoss2 != undefined){
            if(lossDetailsTotalLoss2.value == "true"){
              this.isAtFaultInitiated = false;
              this.isTotalLossInitiated = true;
              return;
            }
          }
          if(surveyReportTotalLoss2 != undefined){
            if(surveyReportTotalLoss2.value == "true"){
              this.isAtFaultInitiated = true;
              this.isTotalLossInitiated = true;
              return;
            }
          }
        })
      })
    }
  }




  TotalLoss = new FormGroup({
    adjustorName1: new FormControl("", [Validators.required]),
    surveyDate1: new FormControl("", [Validators.required]),
    totalLossAmount1: new FormControl("", [Validators.required]),
    adjustorName2: new FormControl("", [Validators.required]),
    surveyDate2: new FormControl("", [Validators.required]),
    totalLossAmount2: new FormControl("", [Validators.required]),
    reasonForTotalLoss: new FormControl("", [Validators.required]),
    estimatedTotalLossAmount: new FormControl("", [Validators.required]),
    salvageSellerName: new FormControl("", [Validators.required]),
    salvageAmount: new FormControl("", [Validators.required]),
    salvageBuyerName: new FormControl("", [Validators.required])
  });

  saveTotalLossDetails() {
    const totalLossDto = new TotalLoss();

    totalLossDto.claimId = this.reportLossDataToSubChild.claimId,
    totalLossDto.claimIdentity = this.reportLossDataToSubChild.claimIdentity,
    totalLossDto.adjustorName1 = this.TotalLoss.get('adjustorName1').value;
    totalLossDto.adjustorName2 = this.TotalLoss.get('adjustorName2').value ;
    totalLossDto.estimatedTotalLossAmount = this.removeCommas2(this.TotalLoss.get('estimatedTotalLossAmount').value)
    totalLossDto.reasonForTotalLoss =this.TotalLoss.get('reasonForTotalLoss').value;
    totalLossDto.salvageAmount = this.removeCommas2(this.TotalLoss.get('salvageAmount').value? this.TotalLoss.get('salvageAmount').value:"0");
    totalLossDto.salvageBuyerName = this.TotalLoss.get('salvageBuyerName').value;
    totalLossDto.salvageSellerName = this.TotalLoss.get('salvageSellerName').value;
    totalLossDto.surveyDate1 = this.TotalLoss.get('surveyDate1').value;
    totalLossDto.surveyDate2 = this.TotalLoss.get('surveyDate2').value;
    totalLossDto.totalLossAmount1 = this.removeCommas2(this.TotalLoss.get('totalLossAmount1').value)
    totalLossDto.totalLossAmount2 = this.removeCommas2(this.TotalLoss.get('totalLossAmount2').value)



    if (this.TotalLoss) {
      this.dataservice.sendTotalLossDetails(totalLossDto).subscribe((response)=>{
        if (response) {
          // this.toaster.success('Total loss Details Saved');
        }
      })
    }
  }

  showSaveButton(){
    if(this.status===ReportLossStatus.claimSettled){
      this.isClaimSettled = true;
    }

    if (this.status===ReportLossStatus.dispute) {
        this.saveButton = true;
    }

    if(this.status===ReportLossStatus.draft&&ReportLossConst.STATUS.DRAFT.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.DRAFT.ISRECEIVABLE===this.isReceivableFromCommon){
      this.saveButton = false;
    }
    if(!this.status){
      this.saveButton=false
    }

    // if(this.status===ReportLossStatus.notificationOpen&&ReportLossConst.STATUS.NOTIFICATION_OPEN.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.NOTIFICATION_OPEN.ISRECEIVABLE===this.isReceivableFromCommon){
    //   this.saveButton = false;
    // }

    if(this.status===ReportLossStatus.notificationReceived&&ReportLossConst.STATUS.NOTIFICATION_RECEIVED.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.NOTIFICATION_RECEIVED.ISRECEIVABLE===this.isReceivableFromCommon){
      this.saveButton = false;
    }

    if((this.status===ReportLossStatus.notificationAccepted)&&ReportLossConst.STATUS.NOTIFICATION_ACCEPTED.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.NOTIFICATION_ACCEPTED.ISRECEIVABLE===this.isReceivableFromCommon){
      this.saveButton = false;
    }
    if((this.status===ReportLossStatus.needMoreDetails&&this.lastStatus===ReportLossStatus.movedToInspection)&&ReportLossConst.STATUS.MOVED_TO_INSPECTION_NEED_MORE_DETAILS.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.MOVED_TO_INSPECTION_NEED_MORE_DETAILS.ISRECEIVABLE===this.isReceivableFromCommon){
      this.saveButton = false;
    }
    // if(this.status===ReportLossStatus.disputeReopen&&ReportLossConst.STATUS.EXPENSES_AND_DOCUMENT_UPDATED.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.EXPENSES_AND_DOCUMENT_UPDATED.ISRECEIVABLE===this.isReceivableFromCommon){
    //   this.saveButton = false;
    // }

    if(this.status===ReportLossStatus.movedToInspection&&ReportLossConst.STATUS.MOVED_TO_INSPECTION.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.MOVED_TO_INSPECTION.ISRECEIVABLE===this.isReceivableFromCommon){
      this.saveButton = false;
    }
    if(this.status===ReportLossStatus.underInspection&&ReportLossConst.STATUS.UNDER_INSPECTION.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.UNDER_INSPECTION.ISRECEIVABLE===this.isReceivableFromCommon){
      this.saveButton = false;
    }
    if(this.status===ReportLossStatus.receivedLiabality&&ReportLossConst.STATUS.RECEIVED_LIABILITY.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.RECEIVED_LIABILITY.ISRECEIVABLE===this.isReceivableFromCommon){
      this.saveButton = false;
    }
    if(this.status===ReportLossStatus.liabilityAccepted&&!this.totalLossType&&ReportLossConst.STATUS.LIABILITY_ACCEPTED.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.LIABILITY_ACCEPTED.ISRECEIVABLE===this.isReceivableFromCommon){
      this.saveButton = false;
    }
    //NEGATIVE FLOW

    if(this.status===ReportLossStatus.receiveRejectedNotification||this.status===ReportLossStatus.needMoreDetails&&this.lastStatus===ReportLossStatus.notificationReceived&&ReportLossConst.STATUS.DRAFT.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.DRAFT.ISRECEIVABLE===this.isReceivableFromCommon){
      this.saveButton = false;
    }

    if(this.status===ReportLossStatus.detailsProvided&&this.lastStatus===ReportLossStatus.notificationReceived&&ReportLossConst.STATUS.NOTIFICATION_RECEIVED.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.NOTIFICATION_RECEIVED.ISRECEIVABLE===this.isReceivableFromCommon){
      this.saveButton = false;
    }

    if(this.status===ReportLossStatus.detailsProvided&&this.lastStatus===ReportLossStatus.notificationReceived&&ReportLossConst.STATUS.NOTIFICATION_RECEIVED.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.NOTIFICATION_RECEIVED.ISRECEIVABLE===this.isReceivableFromCommon){
      this.saveButton = false;
    }  

    if(this.status===ReportLossStatus.needMoreDetails&&this.lastStatus===ReportLossStatus.confirmLiability&&ReportLossConst.STATUS.LIABILITY_ACCEPTED.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.LIABILITY_ACCEPTED.ISRECEIVABLE===this.isReceivableFromCommon){
      this.saveButton = false;
    }

    if(this.status===ReportLossStatus.needMoreDetails&&this.lastStatus===ReportLossStatus.receivedLiabality&&ReportLossConst.STATUS.MOVED_TO_INSPECTION.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.MOVED_TO_INSPECTION.ISRECEIVABLE===this.isReceivableFromCommon){
      this.saveButton = false;
    }

    if(this.status===ReportLossStatus.disputeReopen&&this.lastStatus===ReportLossStatus.receivedLiabality&&ReportLossConst.STATUS.RECEIVED_LIABILITY_DISPUTE_REOPEN.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.RECEIVED_LIABILITY_DISPUTE_REOPEN.ISRECEIVABLE===this.isReceivableFromCommon){
      this.saveButton = false;
    }
    //tottalLoss
    // console.log(this.name as StageNameReportLoss," : ",StageNameReportLoss.lossDetails);

    if(this.status===ReportLossStatus.totalLossInitiated&&!this.totalLossType&&ReportLossConst.STATUS.DRAFT.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.DRAFT.ISRECEIVABLE===this.isReceivableFromCommon){
      this.saveButton = false;
    }
    if(this.status===ReportLossStatus.surveyAssigned&&this.totalLossType&&ReportLossConst.STATUS.SURVEYOR_ASSIGNED.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.SURVEYOR_ASSIGNED.ISRECEIVABLE===this.isReceivableFromCommon){
      this.saveButton = false;
    }
    if((this.status===ReportLossStatus.disputeReopen||this.status===ReportLossStatus.needMoreDetails)&&this.lastStatus===ReportLossStatus.confirmLiability&&ReportLossConst.STATUS.RECOVERY_DTLS.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.RECOVERY_DTLS.ISRECEIVABLE===this.isReceivableFromCommon){
      this.saveButton = false;
    }
    if((this.status===ReportLossStatus.disputeReopen||this.status===ReportLossStatus.needMoreDetails)&&this.lastStatus===ReportLossStatus.debitNoteGenerated&&ReportLossConst.STATUS.RECOVERY_DTLS.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.RECOVERY_DTLS.ISRECEIVABLE===this.isReceivableFromCommon){
      this.saveButton = false;
    }
    if((this.status===ReportLossStatus.disputeReopen||this.status===ReportLossStatus.needMoreDetails)&&this.lastStatus===ReportLossStatus.liabilityReview&&ReportLossConst.STATUS.RECOVERY_DTLS.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.RECOVERY_DTLS.ISRECEIVABLE===this.isReceivableFromCommon){
      this.saveButton = false;
    }
    if((this.status===ReportLossStatus.disputeReopen||this.status===ReportLossStatus.needMoreDetails)&&this.lastStatus===ReportLossStatus.totalLossInitiated&&ReportLossConst.STATUS.TOTALLOSS_INIATED_NEED_INFO_REOPEN.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.TOTALLOSS_INIATED_NEED_INFO_REOPEN.ISRECEIVABLE===this.isReceivableFromCommon){
      this.saveButton = false;
    }
    if((this.status===ReportLossStatus.disputeReopen||this.status===ReportLossStatus.needMoreDetails)&&this.lastStatus===ReportLossStatus.surveyAssigned&&ReportLossConst.STATUS.SURVEYOR_ASSIGNED_NEED_INFO_REOPEN.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.SURVEYOR_ASSIGNED_NEED_INFO_REOPEN.ISRECEIVABLE===this.isReceivableFromCommon){
      this.saveButton = false;
    }
    if((this.status===ReportLossStatus.totalLossInitiated)&&ReportLossConst.STATUS.TOTALLOSS_INIATED_RECEIVABLE.ENABLED_CARDS.includes(this.name as StageNameReportLoss) && ReportLossConst.STATUS.TOTALLOSS_INIATED_RECEIVABLE.ISRECEIVABLE === this.isReceivableFromCommon){
      this.saveButton = false;
    }
    if (((this.status === ReportLossStatus.needMoreDetails || this.status === ReportLossStatus.disputeReopen || this.status === ReportLossStatus.dispute) && (this.lastStatus === ReportLossStatus.debitNoteGenerated || this.lastStatus === ReportLossStatus.totalLossAccepted || this.lastStatus === ReportLossStatus.surveyAssigned)) && ReportLossConst.STATUS.DEBIT_NOTE_NEED_MORE_INFO.ENABLED_CARDS.includes(this.name as StageNameReportLoss) && ReportLossConst.STATUS.DEBIT_NOTE_NEED_MORE_INFO.ISRECEIVABLE === this.isReceivableFromCommon) {
      this.saveButton = false;
    }
    // Reserve Review Dispute Reopen Flow
    if(this.status===ReportLossStatus.liabilityAccepted&&this.totalLossType&&ReportLossConst.STATUS.RESERVE_REVIEW_DISPUTE_REPOEN.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.RESERVE_REVIEW_DISPUTE_REPOEN.ISRECEIVABLE===this.isReceivableFromCommon){
      this.saveButton = false;
    }
    // TotalLoss Intiated  Details Provide
    if((this.status===ReportLossStatus.detailsProvided && this.lastStatus===ReportLossStatus.totalLossInitiated && this.totalLossType )&&ReportLossConst.STATUS.RESERVE_REVIEW_DISPUTE_REPOEN.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.TOTALLOSS_INIATED_SURVEY_REPORT_DETAILS_PROVIDED.ISRECEIVABLE===this.isReceivableFromCommon){
      this.saveButton = false;
    }
    this.setTotalLossFieldDisable();
  }

  private setTotalLossFieldDisable(){
    if(this.saveButton){
      this.TotalLoss.controls['adjustorName1'].disable();
      this.TotalLoss.controls['surveyDate1'].disable();
      this.TotalLoss.controls['totalLossAmount1'].disable();
      this.TotalLoss.controls['adjustorName2'].disable();
      this.TotalLoss.controls['surveyDate2'].disable();
      this.TotalLoss.controls['totalLossAmount2'].disable();
      this.TotalLoss.controls['estimatedTotalLossAmount'].disable();
      this.TotalLoss.controls['reasonForTotalLoss'].disable();
      this.TotalLoss.controls['salvageAmount'].disable();
      this.TotalLoss.controls['salvageBuyerName'].disable();
      this.TotalLoss.controls['salvageSellerName'].disable();
    }
  }

  showDownloadAndPreviewButton(){
   const statuslst:string[]=[];
   statuslst.push(ReportLossStatus.debitNoteGenerated);
   statuslst.push(ReportLossStatus.confirmLiability);
   statuslst.push(ReportLossStatus.claimSettled);


    if(statuslst.includes(this.status) || statuslst.includes(this.lastStatus)){
      this.downloadAndPreviewButton = true;
    }
  }


  returnreportloss(myData: Field[]): void {
    myData.forEach((dt) =>{
      if(dt.fieldName=="sdSurveyDueDate"){
        dt.value = new Date(dt.value).toISOString();
      }
      if(dt.fieldName=="ldDateOfLoss" || dt.fieldName=="inPurchaseDate"){
        const moment = require('moment');
        let dateWithEndTime = null;
        try {
          const parsedDate = moment.utc(dt.value);
          if (parsedDate.isValid()) {
            dateWithEndTime = parsedDate.startOf("day").format("YYYY-MM-DDTHH:mm:ss") + 'Z';
          }
        } catch (error) {
          console.error('Invalid date:', error);
        }
        dt.value = dateWithEndTime;
      }
    })
    this.onInput();
    if((this.name === StageNameReportLoss.lossDetails || this.name === StageNameReportLoss.surveyReport||this.name===StageNameReportLoss.recoveryDetails) &&  this.valueChoosed ){
      this.saveTotalLossDetails();

    }
    this.field.value = this.field.value === '' ? null : this.field.value;
    const fileData: FileUploadDTO = {
      fileList: this.fileList,
      referenceId: this.field.value,
      fieldName: 'group'  // represents multiple file uploads for report loss
    };
    let removedFileList = [];
    if(this.fileViewList && this.fileViewList.length > 0) {
      const list = this.fileViewList.filter((file: any) => file.isRemoved);
      removedFileList = list.map((f: any) => f.id);
    }
    this.selectedItemFieldList = myData;
    this.selectedFieldListItems.emit({
      fileData,
      sectionName: this.name,
      data: this.selectedItemFieldList,
      isAllDeleted: this.fileViewList?.length === removedFileList?.length,
      removedFileList
    });
    this.dataservice.isOpenStage(false);
    this.navigateBack();
  }

  sendValue:any;
  claimAmount:number;
  activeIdx: number;

addStyle(i)
{
  this.activeIdx = i;
}

  sendData(myData: any,data:any){

    this.updateSurveyAmount(myData);
    this.updateClaimAmount(myData);
    this.sendValue = myData;
    // this.saveTotalLossDetails();
    // this.getChildDropDowValue(myData,data);

  }
  updateSurveyAmtInSurveyReport(){
    this.updateSurveyAmount(this.sectionFromCard);
  }


  updateSurveyAmount(myData): void {
    if(!myData) {
      return;
    }
    this.tpSurveyAmount = 0.000;
    if(this.TotalLoss.controls["salvageSellerName"].value !== this.reportLossDataToSubChild.insurerName){
      if(this.amount1 != null || this.amount1 != undefined){
        this.tpSurveyAmount = this.tpSurveyAmount + Number(this.amount1 + '');
      }
      if(this.amount2 != null || this.amount2 != undefined){
        this.tpSurveyAmount = this.rdClaimAmount;
      }
    }else{
      if(this.amount1 != null || this.amount1 != undefined){
        this.tpSurveyAmount = this.tpSurveyAmount + Number(this.amount1 + '');
      }
      if(this.amount2 != null || this.amount2 != undefined){
        this.tpSurveyAmount = this.rdClaimAmount;
      }

      if(this.salvageTotal != null || this.salvageTotal != undefined){
        this.tpSurveyAmount = this.tpSurveyAmount - Number(this.salvageTotal+'')
      }
    }
    if (myData[0].entityName==='SurveyReport'||myData[0].entityName==='RecoveryDetails') {
      this.reportLossDataToSubChild.metaData.sectionList.find(item=>item.sectionName==ReportLossStageEnum.claimInspectionStage).sectionList.find(item=>item.sectionName==StageNameReportLoss.surveyReport).fieldList.forEach((element: Field) => {
        if ((element.fieldName === 'srSpareParts' || element.fieldName === 'srLabourCost') && element.value!=null) {
          this.tpSurveyAmount = this.tpSurveyAmount + Number(element.value + '');
        }
        if (element.fieldName==='srSurveyAmount') {
          element.value = this.tpSurveyAmount.toFixed(3);
        }
      });
      this.reportLossDataToSubChild.metaData.sectionList.find(item=>item.sectionName==ReportLossStageEnum.liabilityConfirmationStage).sectionList.find(item=>item.sectionName === StageNameReportLoss.recoveryDetails).fieldList.forEach((element: Field) => {
        if (element.fieldName ==='rdClaimAmount' && (element.value === undefined || element.value === null || +element.value === 0)) {
          element.value = this.tpSurveyAmount.toFixed(3);
        }
      });
      this.reportLossDataToSubChild.metaData.sectionList.find(item=>item.sectionName==ReportLossStageEnum.liabilityConfirmationStage).sectionList.find(item=>item.sectionName === StageNameReportLoss.reserveReview).fieldList.forEach((element: Field) => {
        if (element.fieldName ==='rrClaimAmount') {
          element.value = this.tpSurveyAmount.toFixed(3);
        }
      });
    }
    // this.sendValue = myData;
  }
  getTotalLossAmount(){
    this.dataservice.getTotalLossDetails(this.reportLossDataToSubChild.claimIdentity).subscribe((response)=>{
      if(response){

        this.amount1 = response['content'].totalLossAmount1;
        this.salvageTotal = response['content'].salvageAmount;
        this.updateSurveyAmount(this.sectionFromCard);
      }
    });
  }

  updateClaimAmount(myData){
    if(!myData) {
      return;
    }
    if (myData[0].entityName==='RecoveryDetails') {
      this.claimAmount = 0.000;
      myData.forEach(element => {
        if (element.fieldName!=='rdTPSurveyAmount' && element.fieldName!=='rdClaimAmount' && element.value) {
          this.claimAmount = Number(this.claimAmount) + Number(element.value+'');
        }
        if(this.reportLossDataToSubChild.totalLossType){
          if(element.fieldName=="rdTPSurveyAmount"){
            this.claimAmount=Number(this.claimAmount)+Number(element.value+'');
          }
        }
        if (element.fieldName==='rdClaimAmount') {
          element.value = this.claimAmount.toFixed(3);
        }
      });

    }
  }

  inputData(){
    
    let totAmt=0;
    if (this.differenceBtwDate()<=3) {
      if (this.amount1!==null && this.amount1!==undefined) {
        totAmt = this.amount1
        this.totalAmount = totAmt
      }
    }else{
   
      if (this.amount2 > this.amount1) {
        totAmt = ((this.amount2 - this.amount1) / 100) * 75 + this.amount1
        this.rdClaimAmount = totAmt;
      }

      else if (this.amount1 !== null && this.amount1 !== undefined) {
        totAmt = this.amount1
      }


      if (totAmt >= 0) {
        this.totalAmount = totAmt;
      }
     
      if(this.salvageTotal){
        if(this.TotalLoss.controls["salvageSellerName"].value === this.reportLossDataToSubChild.insurerName){
          totAmt = this.amount1 -this.salvageTotal;
        }
      }
    }

    this.reportLossDataToSubChild.metaData.sectionList.find(item=>item.sectionName== ReportLossStageEnum.claimInspectionStage).sectionList.find(item=>item.sectionName==StageNameReportLoss.surveyReport).fieldList.forEach((field: Field) => {
      if(field.fieldName === 'srSurveyAmount' || field.fieldName === 'rdTPSurveyAmount' || field.fieldName === 'rrTPSurveyAmount') {
        if(this.totalAmount){
        field.value = Number(totAmt).toFixed(3);
        }
      }
    });

  }

  differenceBtwDate(){
    const currentDate = new Date().getTime()/86400000;
    const purchaseDate = new Date(this.dateOfPurchase).getTime()/86400000
    return ((currentDate-purchaseDate)/365.25);
  }


  refreshPageInTpDetails(name:string){

  }



  getDate(dates: any) {
    const date: Date = new Date();
    const currentDate = this.datepipe.transform(date, 'yyyy-MM-dd');
  }

  navigateBack(): void {
    this.showCardView.emit();
  }

  //------------------------ Dynamic field type starts--------------------------------

  getTextInput(items: Field) {
    if (items.fieldType === 'text') {
      return true;
    }
    return false;
  }
  getStringInput(items: Field) {
    if (items.fieldType === 'String') {
      return true;
    }
    return false;
  }

  getDateInput(items: Field) {
    if (items.fieldType === 'pDate' || items.fieldType === 'fDate') {
      this.minimumDate = new Date();
      this.buttonShowOrNot(items);
      return true;
    }
    return false;
  }
  addDays(date: Date, days: number): Date {
    date.setDate(date.getDate() + days);
    return date;
}


  getDropdownInput(items: Field) {
    if (items.fieldType === 'Dropdown' || items.fieldType === 'MultiSelect') {
        return true;
    }else{
      return false;
    }

  }

//   addDays(date: Date, days: number): Date {
//     date.setDate(date.getDate() + days);
//     return date;
// }

  chooseChildDate(data:any, event){
    if(data.fieldName === "sdSurveyAllocationDate"){

      if(data.value != null){
        this.minDate = new Date(data.value);
        if(this.surveyDueHours !== undefined && this.surveyDueHours!== null && Number(this.surveyDueHours)){
          this.dueDate = Number(this.surveyDueHours)/24;
          this.showDate = this.addDays(this.minDate,this.dueDate)
        }
        this.showDate1 = this.datepipe.transform(this.showDate, 'yyyy-MM-dd')
        this.sectionFromCard.find((x)=>x.fieldName=="sdSurveyDueDate").value= this.showDate1;
      }else{
        this.minDate= new Date();
      }
    }else if (data.fieldName === "ldDateOfLoss"){
      if(data.value){
        this.lastDate = new Date(data.value);
      }else{
        this.lastDate = new Date(new Date().setFullYear(new Date().getFullYear() - 10));
      }
    }
  }

    getChildDropDowValue(metaData:any,data:any){
      let childFieldName;
      const childFieldObject = this.parentFieldMap.find((data2) => data2.parentFieldName === data.fieldName);
       if(childFieldObject) {
        childFieldName = childFieldObject.childFieldName;
       } else {
        childFieldName = '';
       }
    // let childFieldName = this.dropDownService.getChildFieldName(data.fieldName);
    const childmetaData = this.sectionFromCard.find((dt) => dt.fieldName === childFieldName);

      this.buildDropDownValues(childFieldName,childmetaData,data.value);
      if(data.fieldName === 'garageName'){
        const subchild = this.sectionFromCard.find((dt) => dt.fieldName === 'garageContactDetails');
        const location = this.sectionFromCard.find((dt) => dt.fieldName === 'garageLocation');

        this.setContactDetails(subchild,location,data.value)
      }
      if(data.columnName === "dualCurrency" && data.value !== null && data.value !== "null"){
        this.reportLossDataToSubChild.currencyType = data.value;
      }else{
        this.reportLossDataToSubChild.currencyType = '';
      }
   }
   setContactDetails(subchild:Field,location:Field,garageName:string){

    this.dropDownService.getContactDetails(garageName).subscribe(data=>{
      if(data){
        subchild.value= data['content'][0];
        location.value=data['content'][1];
      }else{
        subchild.value='';
      }
    })

   }

   buildDropDownValues(fieldName:string, metaData:Field, value:string){
    if(fieldName && fieldName != '' ){

        this.dropDownService.getOption(metaData.fieldId,value,null).subscribe(data=>{
          if (data) {
            if(metaData.aliasName == "Third Party Company Name"){
               let currentCompanyName  = sessionStorage.getItem("companyName");
              const index: number = data.indexOf(currentCompanyName);
              if (index !== -1) {
                data.splice(index, 1);
            }
              metaData.dropDownList = data;
            }else{
              metaData.dropDownList = data;
            }
          }
        })
    }
   }

   buttonShowOrNot(items: Field){
    if(this.isTotalLossInitiated){
      this.showSpareAmt = (items.fieldName === "rdSpareParts" || items.fieldName === "rdLabourCost");
    }
    if(items.fieldName === "sdSurveyAllocationDate" || items.fieldName === "sdSurveyDueDate"){
       this.minimumDate = null ;
    }
    this.showSurveyAmount = (items.fieldName === "srSurveyAmount");
    this.disableSurveyDueDate = (items.fieldName === "sdSurveyDueDate")
  }

  getNumberInput(items: Field) {
    if (items.fieldType === 'Long' || items.fieldType === 'Double') {
      this.buttonShowOrNot(items);
      return true;
    }
    return false;
  }

  fileFlag = true;

  getFileUploadInput(items: Field) {
    this.field = items;
    if (items.fieldType === 'file') {
      if(items.value !== undefined && items.value !== null && !Number.isNaN(parseInt(items.value)) && this.fileFlag) {
        this.fileFlag = false;
        this.fileUploadService.getFileList(parseInt(items.value)).subscribe((response: any) => {
          const data = response.content;
          this.fileViewList = [];
          if(data && data.length > 0) {
            data.forEach((file: {id: number, url: string}, index: number) => {
              this.fileViewList.push({
                id: file.id,
                name: file.url.slice(56),
                url: file.url,
                isRemoved: false
              });
            });
          }
        });
      }
      return true;
    }
    return false;
  }

  private mutliLanguageForField(){
    this.sectionFromCard.find((dt) =>{
      const translateFieldName   = this.translate.instant("reportloss."+dt.fieldName);
    if(!translateFieldName.includes('reportloss.')){
      dt.aliasName = translateFieldName;
    }
   });
  }

  getCheckboxInput(items: Field) {
    if (items.fieldType === 'checkbox'|| items.fieldType === 'Boolean' 
      || items.fieldType === 'RadioButton'|| items.fieldType === 'toggle' ) {
      return true;
    }
    return false;
  }

  getDownloadInput(items:Field){
    if (items.fieldType==="download") {
      if (items.defaultValues !== null) {
        this.dropdownlist = items.defaultValues.split(',');

      }
      return true;
    }
    return false;
  }

  removeFile(index: number): void {
    this.fileViewList[index].isRemoved = true;
    // this.sectionFromCard.find((field: Field) => {
    //   if (field.fieldType === 'file') {
    //     field.fileName = null;
    //     field.value = null;
    //     field.pdfSrc = null;
    //   }
    // });
  }

  getDownloadFile(file: any): void {
    this.fileUploadService.downloadFile(file.url).subscribe((response) => {
      const blob = new Blob([response]);
      const fileURL = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = fileURL;
      a.target = '_blank';
      a.download = file.url.substring(file.url.lastIndexOf("/") + 1);
      document.body.appendChild(a);
      a.click();
    });
  }
  getPreviewFile(dataUrl: string): void {
    this.fileUploadService.downloadFile(dataUrl).subscribe((response) => {
      const blob = new Blob([response]);
      const fileURL = URL.createObjectURL(blob);
      this.pdfSrc = fileURL;
    });
  }
  //------------------------ Dynamic field type ends--------------------------------

  // ------------------file upload starts------------------------

  fileList: File[] = null; // Variable to store file

  // On file Select

  filemap = new Map<string,string>([
    [ "pdf", "assets/file/pdf.svg" ],
    [ "xlsx", "assets/file/xlsx.svg" ],
    [ "xls", "assets/file/xls.svg" ],
    [ "doc", "assets/file/doc.svg" ],
     [ "docx", "assets/file/docx.svg" ],
     [ "img", "assets/file/img.svg" ],
     [ "jpeg", "assets/file/jpeg.svg"],
     [ "jpg", "assets/file/jpg.svg" ],
     [ "png", "assets/file/png.svg"],
     [ "svg", "assets/file/svg.svg"]
]);
filesize:number;
fileboolean:boolean=false;
file='';
  onChange(event, data: Field) {
    this.fileList = event.target.files;
    this.file = event.target.files[0].type;
    data.fileName = this.fileList[this.fileList.length - 1].name;
    const totalSize = this.getTotalFileSize(); // Get total size in bytes
    this.filesize = Math.ceil(totalSize / 1048576);
    const maxSizeMB = 20; // 20MB
    if (this.filesize < maxSizeMB)
   {
    if(this.file =="application/pdf"  ||
      this.file =="application/vnd.ms-excel"  ||
      this.file =="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
      this.file =="application/msword" ||
      this.file =="application/vnd.ms-excel" ||
      this.file =="application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
      this.file =="image/png" ||
      this.file=="image/jpeg" ||
      this.file=="image/jpg" ||
      this.file=="image/svg+xml")
    {
      this.fileboolean=true;
    data.fileName = this.fileList[this.fileList.length - 1].name;
    const str = data.fileName.split(".");      // Split the string using dot as separator
     const filename = str.pop();
     for (let key of this.filemap.keys()) {
      if(key===filename){
        this.fileType=this.filemap.get(key).toString();
      }
    }
    if(this.fileType===null||this.fileType===undefined){
      this.fileType="assets/file/file.svg";
    }

    if(this.file == "image/png" || this.file == "image/jpeg" ||
    this.file == "image/jpg"  || this.file == "image/svg+xml"){
         data.mimeType = MimeTypeEnum.IMAGE;
          const reader = new FileReader();
          reader.onload = (event : any) => {
            data.pdfSrc = event.target.result;
          }
          reader.readAsDataURL(this.fileList[0]);
  }
  else if(this.file == "application/pdf"){
       data.mimeType = MimeTypeEnum.PDF;
      if (typeof FileReader !== 'undefined') {
            let reader = new FileReader();
            reader.onload = (e: any) => {
              data.pdfSrc = e.target.result;
            };
            reader.readAsArrayBuffer(this.fileList[0]);
          }
    }

  }else{
    this.fileboolean=false;
    this.fileList = null;
    data.fileName = null;
    this.toaster.error(this.translate.instant("Toaster_Message.Invalid_file_format"));
  }

  }
  else{
    this.fileboolean=false;
    this.fileList =null;
    data.fileName = null;
    this.toaster.error(this.translate.instant("Toaster_Message.Upload_file_size"));
    this.hiddenInput.nativeElement.value = null;
    this.hiddenInput.nativeElement.click();
  }
  // ------------------file upload ends------------------------
  }
  getTotalFileSize(): number {
    let totalSize = 0;
    for (const file of this.fileList) {
      totalSize += file.size;
    }
    return totalSize;
  }


  // ------------------file upload ends------------------------

  checkBox = false;
  checkBoxTick:boolean;
  totalLossResponse:TotalLoss;

  onCheckboxChange(item:Field,value:boolean) {
    if(item) {
      item.value = JSON.stringify(value);
    }
    if (item.value==='true') {
      this.valueChoosed =true;
      this.checkBox = !this.checkBox;
      this.checkBoxTick = true;
      this.getTotalLossDropDownValue();

    }else if(item.value==='false'){
      this.valueChoosed =false;
      this.checkBoxTick = false;
      this.checkBox = !this.checkBox;
    }
    if (this.name === StageNameReportLoss.lossDetails) {
      if (item.value === 'true') {
        this.isLossDetailTotalLoss = true
      } else {
        this.isLossDetailTotalLoss = false
      }
    } else if (this.name === StageNameReportLoss.surveyReport) {
      if (item.value === 'true') {
        this.isSurveyReport = true
      } else {
        this.isSurveyReport = false
      }
    }


    this.surveyReportDisable(!this.checkBox);
  }

  surveyReportDisable(isdisabled:boolean){
   const fieldArr:string[]=[];
   fieldArr.push("srLabourCost")
   fieldArr.push("srSpareParts")
   fieldArr.push("giDocument")
  fieldArr.push("giGarageInvoiceNo")
   fieldArr.push("srSurveyAmount")

    this.sectionFromCard.forEach((item) => {
      if (fieldArr.includes(item.fieldName)) {
       item.readOnly=isdisabled;
       if(item.fieldName=="srLabourCost"||item.fieldName=="srSpareParts" || item.fieldName =='srSurveyAmount'){
        item.value="";
       }
      }

    });

  }


  getTotalLoss(){
    this.getTotalLossDropDownValue();
    this.dataservice.getTotalLossDetails(this.reportLossDataToSubChild.claimIdentity).subscribe((response)=>{
      if (response) {
        this.totalLossResponse = response['content'];
        
        this.amount1 = this.removeCommas2(this.totalLossResponse.totalLossAmount1);
        this.amount2 = this.removeCommas2(this.totalLossResponse.totalLossAmount2);
        this.totalAmount = this.removeCommas2(this.totalLossResponse.estimatedTotalLossAmount);
        this.adjustor1 = this.totalLossResponse.adjustorName1;
        this.adjustor2 = this.totalLossResponse.adjustorName2;
        this.date1 = this.totalLossResponse.surveyDate1;
        this.date2 = this.totalLossResponse.surveyDate2;
        this.totalLossReason = this.totalLossResponse.reasonForTotalLoss;
        this.TotalLoss.controls['reasonForTotalLoss'].setValue(this.totalLossResponse.reasonForTotalLoss);
        this.nameOfSalvageSeller = this.totalLossResponse.salvageSellerName;
        this.nameOfSalvageBuyer = this.totalLossResponse.salvageBuyerName;
        this.salvageTotal = this.removeCommas2(this.totalLossResponse.salvageAmount);


        if(this.date1!=null){
          this.date1 =new Date(this.date1);
          }
          if(this.date2!=null){
            this.date2 =new Date(this.date2);

          }


          this.TotalLoss.controls['adjustorName1'].setValue(this.adjustor1);
          this.TotalLoss.controls['surveyDate1'].setValue(this.date1);
          this.TotalLoss.controls['totalLossAmount1'].setValue(this.amount1?this.amount1+"":"");
          this.TotalLoss.controls['adjustorName2'].setValue(this.adjustor2);
          this.TotalLoss.controls['surveyDate2'].setValue(this.date2);
          this.TotalLoss.controls['totalLossAmount2'].setValue((this.amount2?this.amount2+"":""));
          this.TotalLoss.controls['estimatedTotalLossAmount'].setValue(this.totalAmount?this.totalAmount+"":"");
          this.TotalLoss.controls['salvageSellerName'].setValue(this.nameOfSalvageSeller);
          this.TotalLoss.controls['salvageAmount'].setValue(this.salvageTotal?this.salvageTotal+"":"");
          this.TotalLoss.controls['salvageBuyerName'].setValue(this.nameOfSalvageBuyer);

          // this.inputData();
          this.makeTotalLossAmountWithFormat();
      }
    })
  }

  backToList(){
    this.checkBox = !this.checkBox;
  }




  onInput(): void {
    // let count = 0;
    // this.sectionFromCard
    // if (this.sectionFromCard.length === count) {
    //   this.isFieldsFull.emit({
    //     isNotFilled:false,
    //     subSectionName:this.name
    //   });
    // }
  }

  checkTPName(data): boolean {
    return (!this.isReceivableFromCommon && data.aliasName === 'Third Party Company Name');
  }

  checkShow(): boolean {
    return this.name !== StageNameReportLoss.reserveReview && this.name !== StageNameReportLoss.debitNote && this.name !== StageNameReportLoss.creditNote;
  }

  shouldShow(data: string): boolean {
    return data.includes('http://');
  }

  shouldShowDeleteFile(): boolean {
    return (this.name === StageNameReportLoss.policeDetails && this.receivable) ||
      (this.name === StageNameReportLoss.surveyReport && !this.receivable) ||
      (this.name === StageNameReportLoss.garageInvoice && this.receivable);
  }

  getFileName(imageData: any): string {
    return imageData.name !== '' ? imageData.name : imageData.url;
  }

  getPreviewImage(imageData:any){
    const name = this.getFileName(imageData);
    switch (name.split('.').slice(-1)[0]) {
      case 'jpg':
        return 'assets/file/jpg.svg'

        case 'pdf':
        return 'assets/file/pdf.svg'

        case 'doc':
        return 'assets/file/doc.svg'

        case 'docx':
        return 'assets/file/docx.svg'

        case 'img':
        return 'assets/file/img.svg'

        case 'jpeg':
        return 'assets/file/jpeg.svg'

        case 'png':
        return 'assets/file/png.svg'

        case 'svg':
        return 'assets/file/svg.svg'

        case 'txt':
        return 'assets/file/txt.svg'

        case 'upload':
        return 'assets/file/upload.svg'

        case 'xls':
        return 'assets/file/xls.svg'

        case 'xlsx':
        return 'assets/file/xlsx.svg'
    }
  }

  removeCommas(value: string){
    if (value !== undefined && value !== null && value !=='') {

      const num =  Number(value.toString().replace(/,/g, ''));
      return num.toLocaleString("en",{useGrouping: false,minimumFractionDigits: 3});
      // return num.toFixed(3);
    } else {
      return '';
    }
  }

  removeCommas2(value: any):number{
    if (value !== undefined && value !== null && value !=='') {

      const num =  Number(value.toString().replace(/,/g, ''));
      return Number(num.toLocaleString("en",{useGrouping: false,minimumFractionDigits: 3}));
      // return num.toFixed(3);
    } else {
      return null;
    }
  }
  /*
  * Clear Date Field Value
  */
  clearDateField(editableSts:any,filedName:string){
    if(!editableSts._disabled){
      this.sectionFromCard.forEach(ele =>{
        if(ele.fieldType=== 'pDate' || ele.fieldType === 'fDate')
        if(ele.fieldName == filedName || 'sdSurveyDueDate' == ele.fieldName ){
          ele.value = "";
        }
      })
    }
  }
  /*
  * Clear TotalLoss Date Field Value
  */
  clearTotalLossDateField(isEditable:any,surveyDate1:boolean){
    if(!isEditable._disabled){
      if(surveyDate1){
        this.TotalLoss.controls['surveyDate1'].setValue("");
        this.date1 = "";
      }else{
        this.TotalLoss.controls['surveyDate2'].setValue("");
        this.date2 = "";
      }
    }
  }

  getPrivilege(){
    var pageId =  appConst.PAGE_NAME.PAYABLE.PAYABLE_REPORTLOSS.PAGEID;
    if(this.receivable){
     pageId =  appConst.PAGE_NAME.RECEIVABLE.RECEIVABLE_REPORTLOSS.PAGEID;
    }
    this.appService.getPrivilegeForPage(pageId).subscribe((res: any)=>{
      this.pageInfo = res.content;
      this.getPageInfo(pageId);
    });
  }
 
  getPageInfo(pageID: number): boolean{
    if(this.pageInfo != null || this.pageInfo !== undefined){
      const pageValue = this.pageInfo.find((element: any) => element.pageId === pageID);
      return pageValue;
    }else{
      return true;
    }

  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege ? privillege.isEnabled : false;
    }
    return isEnabled;
  }

  public isFileDisabled(data: any): boolean {
    return !data.readOnly || this.saveButton || !this.activeSection.isEditable || this.isClaimSettled;
  }
}

export interface FileUploadDTO {
  fileList: File[];
  referenceId?: string;
  identity?:string;
  fieldName: string;
}


