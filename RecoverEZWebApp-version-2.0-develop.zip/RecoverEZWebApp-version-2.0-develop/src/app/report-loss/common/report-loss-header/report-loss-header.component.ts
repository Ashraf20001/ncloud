import { Field } from './../../../models/report-loss-dto/field';
import { Section } from './../../../models/report-loss-dto/section';
import { ToastrService } from 'ngx-toastr';
import { ReportLossService } from 'src/app/service/report-loss.service';
import { REPORTHEADER, ReportLossStatus, ToasterMessage } from './../../../common/enum/enum';
/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable @angular-eslint/no-empty-lifecycle-method */
import { ReportLossData } from './../../../models/report-loss-dto/report-loss-data';
import {
  Component,
  Input,
  OnInit,
  OnChanges,
  Output,
  EventEmitter,
} from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { I18nServiceService } from 'src/app/service/i18n-service.service';
import { ToastrServiceService } from 'src/app/service/toastr-service.service';
import {  ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MetaDataDto } from 'src/app/models/report-loss-dto/meta-data-dto';
import { appConst } from 'src/app/service/app.const';
import { BulkUploadService } from 'src/app/service/bulk-upload.service';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { FileUploadDialogComponent } from 'src/app/receivable-list/receivable-list-card/receivable-bulk-history/file-upload-dialog/file-upload-dialog.component';
import { ReceivableBulkHistoryComponent } from 'src/app/receivable-list/receivable-list-card/receivable-bulk-history/receivable-bulk-history.component';
import { AdminService } from 'src/app/service/admin.service';
import { UploadPopupComponent } from '../upload-popup/upload-popup.component';
import { AppService } from 'src/app/service/role access/service/app.service';

@Component({
  selector: 'app-report-loss-header',
  templateUrl: './report-loss-header.component.html',
  styleUrls: ['./report-loss-header.component.scss'],
})
export class ReportLossHeaderComponent implements OnInit, OnChanges {
  @Input() selectedSectionNameFromParent: string;
  @Input() reportLossDataFromParent: ReportLossData;
  @Input() isReceivableFromParent: boolean;
  @Input() pageInfo: any;
  @Output() sendClaimId = new EventEmitter<string>();
  @Output() triggerButtonSubmit = new EventEmitter<string>();
  @Output() sendStatus = new EventEmitter<string>();
  @Output() sendReportLossData = new EventEmitter<ReportLossData>();
 @Output() fullViewReport=new EventEmitter<boolean>();
 @Output() fullViewReports=new EventEmitter<boolean>();


 @Output() refreshMainPage=new EventEmitter<any>();
@Output() showcmd= new EventEmitter<boolean>();
@Output() showhis=new EventEmitter<boolean>();
  acceptButton: boolean;
  rejectButton: boolean;
  needInfoButton: boolean;
  submitButton: boolean;
  assignSurveyor: boolean;
  disputeButton: boolean;
  detailsProvideButton: boolean;
  approveButton: boolean;
  reopenButton: boolean;
  reSubmitButton: boolean;
  acceptLiability: boolean;
  disputeReopen:boolean;
  claimSequenceId: string;
  claimNumber: string;
  currentDate: string;
  insuredName: string;
  faultCompanyName: string;
  receivableAmount: number;
  status: string;
  lastStatus:string;
  claimId: string;
  totalLossType:string;

  isReceivable = true;
  receivableString: string;

  showmessage = false;
  showcurrentHistory = false;
  currentRoute: string;
  isReceivablepage = true;
  public appConst = appConst;
  isPayable = false;

  isAcceptDisabled = false;
  isSubmitDisabled = false;
  isSaveDisabled = false;
  isAssignDisabled = false;
  isApproveDisabled = false;
  isRejectedDisabled = false;
  isDisputeDisabled = false;
  isDetailsDisabled = false;
  isReopenDisabled = false;
  isResubmitDisabled = false;
  isDisputeReopenDisabled = false;
  isNeedInfoDisabled = false;
 isAdmin:boolean;
 isActionBtnDisabled:boolean;
  currencyCode: string;
 

  ngOnChanges(): void {
    this.insuredName = this.reportLossDataFromParent?.insuredName;
    this.faultCompanyName = this.reportLossDataFromParent?.atFaultCompanyName;
    this.claimId = this.reportLossDataFromParent?.claimIdentity;
    this.receivableAmount = this.reportLossDataFromParent?.receivableAmount;
    this.currencyCode = this.reportLossDataFromParent?.currencyType;
    this.status = this.reportLossDataFromParent?.status;
    this.lastStatus = this.reportLossDataFromParent?.lastStatus;
    this.totalLossType = this.reportLossDataFromParent?.totalLossType;
    this.sendClaimId.emit(this.claimId);
    this.sendStatus.emit(this.status);
    this.isReceivable = this.isReceivableFromParent;
    this.claimSequenceId = this.reportLossDataFromParent?.claimSequenceId;
    this.buttonRefresh();
    // this.buttonStatus(ReportLossStatus.totalLossAccepted,true);
    this.buttonStatus(this.reportLossDataFromParent.status, this.isReceivable);
    this.currentDate = new Date().toLocaleString();
    this.claimSequenceStr(this.reportLossDataFromParent?.metaData);
    this.getPrivilege();
  }

  ngOnInit(): void {
        this.enableStatusButtons();
    this.isReceivable = this.isReceivableFromParent;
    this.claimId = this.reportLossDataFromParent?.claimIdentity;
    this.Visisbility();
    this.activatedRoute.queryParams.subscribe((queryParams: any) => {
      this.isReceivablepage = queryParams["rec"] !== undefined ? queryParams["rec"] !== 'false' : true;
    });
    this.isAdmin = this.adminService.isAssociationUser();

    if(this.currentRoute.includes('/report-loss') && !this.isReceivablepage){
      this.isPayable = true;
    }else{
      this.isPayable = false;
    }
    this.getPrivilege();
  }
  claimSequenceStr(metaData:MetaDataDto){

    if(this.isReceivable) {
      const lossDetailsSection = metaData?.sectionList[0]?.sectionList.find((section: Section) => section.sectionName === 'Loss Details');
      if(lossDetailsSection) {
        this.claimNumber = lossDetailsSection.fieldList.find((field: Field) => field.aliasName === 'Claim Number').value;
        this.isClaimNumberEmpty(this.claimNumber);
      }
    } else {
      const tpDetailsSection = metaData?.sectionList[0]?.sectionList.find((section: Section) => section.sectionName === 'TP Details');
      if(tpDetailsSection) {
        this.claimNumber = tpDetailsSection.fieldList.find((field: Field) => field.aliasName === 'TP Insurance Claim Number').value;
        this.isClaimNumberEmpty(this.claimNumber);
      }
    }
    if(!this.claimSequenceId){
      this.claimSequenceId="NA"
    }

  }
  isClaimNumberEmpty(claimNo:string){
    if(!claimNo){
      this.claimNumber="NA";
    }
  }

  buttonRefresh() {
    this.acceptButton = false;
    this.rejectButton = false;
    this.needInfoButton = false;
    this.submitButton = false;
    this.assignSurveyor = false;
    this.disputeButton = false;
    this.detailsProvideButton = false;
    this.approveButton = false;
    this.reopenButton = false;
    this.reSubmitButton = false;
    this.acceptLiability = false;
  }

  fullView=true;
  nofullview=false;
  fullview()
  {
    this.fullView=!this.fullView;
    this.nofullview=!this.nofullview;
   this.fullViewReport.emit();

  }

  buttonStatus(status: string, receivable: boolean) {
    switch (status) {
      case ReportLossStatus.draft:
        if (receivable) {
          this.submitButton = true;
        }
        break;
      case ReportLossStatus.notificationReceived:
        if (!receivable) {
          this.acceptButton = true;
          this.rejectButton = true;
          this.needInfoButton = true;
        }
        break;

        case ReportLossStatus.receiveRejectedNotification:
          if (receivable) {
            this.reopenButton = true;
          }
          break;

      case ReportLossStatus.notificationAccepted:
        if (receivable) {
          this.submitButton = true;
        }
        break;

      case ReportLossStatus.movedToInspection:
        if (!receivable) {
          this.assignSurveyor = false;
          this.submitButton = true;
          this.needInfoButton = true;

        }
        break;

      case ReportLossStatus.underInspection:
        if (!receivable) {
          this.submitButton = true;
        }
        break;

      case ReportLossStatus.receivedLiabality:
        if (receivable) {
          this.needInfoButton = true;
          this.submitButton = true;
          this.disputeButton = true;
        }
        break;

      case ReportLossStatus.liabilityReview:
        if (!this.totalLossType) {

        if (!receivable) {
            this.needInfoButton = true;
            this.disputeButton = true;
            this.acceptButton = true;
        }
          }else{
            if(receivable){
              this.acceptButton=true;
            }
          }

        break;

      case ReportLossStatus.liabilityAccepted:
        if (receivable) {
          if(!this.totalLossType){
            this.submitButton = true;
          }
        }
        break;
        case ReportLossStatus.confirmLiability:
          if (!receivable) {
            if (!this.totalLossType) {
              this.needInfoButton = true;
              this.disputeButton = true;
            }
              this.approveButton = true;
          }
          break;


      case ReportLossStatus.needMoreDetails:
          if (this.lastStatus===ReportLossStatus.notificationReceived || this.lastStatus===ReportLossStatus.liabilityReview || this.lastStatus===ReportLossStatus.debitNoteGenerated || this.lastStatus===ReportLossStatus.confirmLiability||this.lastStatus===ReportLossStatus.movedToInspection||this.lastStatus===ReportLossStatus.totalLossAccepted) {
            if (!receivable) {
              this.acceptButton = false;
            }
            if(receivable){
              this.detailsProvideButton = true;
            }
          }
          else if (this.lastStatus === ReportLossStatus.receivedLiabality||this.lastStatus===ReportLossStatus.totalLossInitiated) {
            if (receivable) {
              this.acceptButton = false;
            }
            if(!receivable){
              this.detailsProvideButton = true;
            }

          }else if(this.lastStatus===ReportLossStatus.surveyAssigned){
            if (receivable) {
              this.detailsProvideButton = true;
            }
          }

        break;

      case ReportLossStatus.detailsProvided:
        if (this.lastStatus===ReportLossStatus.notificationReceived ) {
          if (receivable) {
            this.acceptButton = false;
          }
          if(!receivable){
            this.needInfoButton = true;
            this.acceptButton = true;
            this.rejectButton = true;
          }

        }
        if (this.lastStatus===ReportLossStatus.liabilityReview) {
          if (receivable) {
            this.acceptButton = false;
          }
          else if(!receivable){
            this.needInfoButton = true;
            this.acceptButton = true;
          }

        }
       else if (this.lastStatus===ReportLossStatus.debitNoteGenerated || this.lastStatus===ReportLossStatus.confirmLiability) {
          if (receivable) {
            this.acceptButton = false;
          }
          else if(!receivable){
            this.needInfoButton = true;
            this.approveButton = true;
            this.disputeButton = true;
          }

        }

        else if (this.lastStatus===ReportLossStatus.receivedLiabality ) {
          if (receivable) {
            this.needInfoButton = true;
            this.submitButton = true;
          }
          else if(!receivable){
            this.needInfoButton = false;
          }

        }
        else if (this.lastStatus===ReportLossStatus.movedToInspection ) {
          if (!receivable) {
            this.needInfoButton = true;
            this.submitButton = true;
          }

        }
        else if(this.lastStatus===ReportLossStatus.totalLossInitiated){
          if (this.totalLossType) {
            if (receivable) {
              this.acceptButton = true;
              this.needInfoButton = true;
              this.disputeButton = true;
            }
          }
        }
        else if(this.lastStatus===ReportLossStatus.surveyAssigned){
          if (!receivable) {
               this.acceptButton = true;
              this.needInfoButton = true;
              this.disputeButton = true;
          }
        } else if(this.lastStatus===ReportLossStatus.totalLossAccepted){
          if (!receivable) {
            this.acceptButton = true;
            this.needInfoButton = true;
            this.disputeButton = true
          }
        }
        break;



      case ReportLossStatus.reopen:
        if (!receivable) {
          // this.submitButton = true;
        }
        break;

      case ReportLossStatus.dispute:
        if (this.lastStatus===ReportLossStatus.receivedLiabality||this.lastStatus===ReportLossStatus.totalLossInitiated) {

          if (receivable) {
            this.disputeReopen = true;
          }
        } if(this.lastStatus === ReportLossStatus.liabilityReview || this.lastStatus === ReportLossStatus.debitNoteGenerated || this.lastStatus === ReportLossStatus.confirmLiability||this.lastStatus===ReportLossStatus.surveyAssigned){
          if (!receivable) {
            this.disputeReopen = true;
          }
        } else if(this.lastStatus=== ReportLossStatus.totalLossAccepted){
          if(!receivable){
            this.disputeReopen = true;
          }
        }

        break;


      case ReportLossStatus.disputeReopen:
        if (this.lastStatus===ReportLossStatus.receivedLiabality||this.lastStatus===ReportLossStatus.totalLossInitiated) {
        if (!receivable) {
          this.submitButton = true;
        }
      } if(this.lastStatus === ReportLossStatus.liabilityReview  || this.lastStatus === ReportLossStatus.confirmLiability||this.lastStatus===ReportLossStatus.surveyAssigned){
        if (receivable) {
          this.submitButton = true;
        }
      } else if(this.lastStatus=== ReportLossStatus.totalLossAccepted){
        if(!receivable){
          this.acceptButton = true;
          this.needInfoButton = true;
          this.disputeButton = true;
        }
      }
 
        break;

      case ReportLossStatus.totalLossInitiated:
        if (this.totalLossType) {
          if (receivable) {
            this.acceptButton = true;
            this.needInfoButton = true;
            this.disputeButton = true;

          }
        }

        break;

      case ReportLossStatus.totalLossAccepted:
        if (!receivable) {
          this.acceptButton = true;
          this.needInfoButton = true;
          this.disputeButton = true;
        }
        break;

      case ReportLossStatus.surveyAssigned:
        if (!receivable) {
          this.acceptButton = true;
          this.needInfoButton = true;
          this.disputeButton = true;

        }
        break;
      case ReportLossStatus.debitNoteGenerated:
        if (!receivable) {
          if (!this.totalLossType) {
            this.needInfoButton = true;
            this.disputeButton = true;
          }
          if(this.totalLossType){
            this.needInfoButton = true;
            this.disputeButton = true;
            this.approveButton = true;
          }
        }
        break;
    }
  }
  showComments() {
    this.fullViewReports.emit();
    this.showcmd.emit()
    // this.showmessage = true;
    // const reportView=false
    // this.reportLossService.showUserComments(reportView);
    // this.showcurrentHistory = false;

  }

  showHistory() {
    this.fullViewReports.emit();
    this.showhis.emit()
    this.showcurrentHistory = true;
    this.reportLossService.showClaimHistory(this.showcurrentHistory);
    this.showmessage=false;
      }

  Visisbility(){
    this.reportLossService.reportView.subscribe((data:boolean)=>{

      this.showcurrentHistory = !data;
      this.showmessage= false;
    });
  }

  constructor(
    private toasterService: ToastrServiceService,
    public i18Service: I18nServiceService,
    private translate: TranslateService,
    private reportLossService: ReportLossService,
    private bulkUploadService:BulkUploadService,
    private dialog: MatDialog,
    private toaster: ToastrService,
    private route: Router,
    private activatedRoute: ActivatedRoute,
    private adminService: AdminService,
    private appService : AppService
  ) {
  this.i18Service = i18Service;
  this.i18Service.setUpConf();
    this.currentRoute = window.location.href;

  this.route.events.subscribe((event: any) => {
    if (event instanceof NavigationEnd) {
      this.currentRoute = event.url
    }
  }); 
  this.translate.use(sessionStorage.getItem('Language'));
  }

  pageId = 'sdjashbsdadajdkui';
  reportLossDataWithClaimId: ReportLossData;

  buttonToaster:string;

  sendButtonValue(buttonValue:string){
    this.isActionBtnDisabled = true;
    this.disabledAllButton();
    this.disableOtherStatusButton(buttonValue);
      this.reportLossService.statusButtonFlow(buttonValue, this.claimId).subscribe((response) => {
        if (response) {
          this.buttonshow=true;
          this.buttonToaster =  this.sendToasterMessage(buttonValue);
          var toasterMsg =  this.translate.instant(`ReportLossToasterMsg.${this.buttonToaster}`);
          this.toaster.success(toasterMsg);
          sessionStorage.removeItem('commends');
          sessionStorage.removeItem('claimHistory');
          setTimeout(() => {
            window.location.reload();
                      }, 2000);
        }
        },Error =>{
          console.log("error", Error);
          this.isActionBtnDisabled = false;
        if (buttonValue === REPORTHEADER.rejected || buttonValue === REPORTHEADER.need_more_details || buttonValue === REPORTHEADER.dispute || buttonValue === REPORTHEADER.details_provuded || buttonValue === REPORTHEADER.reopen || buttonValue === REPORTHEADER.dispute_repon || buttonValue === REPORTHEADER.notification_rejected) {
          this.fullViewReports.emit();
          this.showcmd.emit();
        }
        });

  }
  buttonshow=false;
  sendToasterMessage(buttonValue:string){
    switch (buttonValue) {
      case REPORTHEADER.accepted:
        return 'claimAccepted'
      case REPORTHEADER.rejected:
        return 'claimRejected'
      case REPORTHEADER.need_more_details:
        return 'moreDetailsRequired'
      case REPORTHEADER.save:
        return this.status === ReportLossStatus.draft ? 'claimInitiatedSuccessfully' : 'claimSubmitted'
      case REPORTHEADER.assign_surveyor:
        return 'surveyorAssigned'
      case REPORTHEADER.dispute:
        return 'disputeRaised'
      case REPORTHEADER.details_provuded:
        return 'detailsProvided'
      case REPORTHEADER.approved:
        return 'claimApproved'
      case REPORTHEADER.reopen:
        return 'claimReponed'
      case REPORTHEADER.dispute_repon:
        return 'disputeReopened'
    }

  }
  
  triggerSubmitButton(){
    this.triggerButtonSubmit.emit();
  }
  goBack() {

    if(this.currentRoute.includes('/report-loss') && !this.isReceivablepage){
      this.route.navigateByUrl('payable/Payable-card');

    }else{
      this.route.navigateByUrl('receivable-list');
    }
  }

  notificationOpen(){
    if (this.status===ReportLossStatus.draft || this.status===null) {
      return true;
    }
    return false;
    }


  /**
   * upload reportLoss File
   */
  repostLessFileUpload() {
    const config: MatDialogConfig = {
      panelClass: 'dialog-responsive2',
      // height: '569px',
      width: '1561px', 
      data: {
        status : this.status
      },
      disableClose: true 
}
    const dialogRef = this.dialog.open(FileUploadDialogComponent,config);
    dialogRef.afterClosed().subscribe(result => {
      // console.log(`Dialog result: ${result}`);
    });
  }

  bulkUploadHistory() {
    const config: MatDialogConfig = {
      panelClass: 'dialog-responsive2',
      maxWidth:'91.5vw',
      // height: '569px',
      width: '1561px', 
      data: {
      },
      disableClose: true 
}
    const dialogRef = this.dialog.open(ReceivableBulkHistoryComponent,config)
    dialogRef.afterClosed().subscribe(result => {
      // console.log(`Dialog result: ${result}`);
    });
  }
  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege ? privillege.isEnabled : false;
    }
    return isEnabled;
  }

  disabledAllButton() {
    this.buttonshow = true;
    this.isAcceptDisabled = true;
    this.isSaveDisabled = true;
    this.isAssignDisabled = true;
    this.isApproveDisabled = true;
    this.isRejectedDisabled = true;
    this.isDisputeDisabled = true;
    this.isDetailsDisabled = true;
    this.isReopenDisabled = true;
    this.isResubmitDisabled = true;
    this.isDisputeReopenDisabled = true;
    this.isNeedInfoDisabled = true;
  }

  enableStatusButtons() {
    this.buttonshow = false;
    this.isAcceptDisabled = false;
    this.isSaveDisabled = false;
    this.isAssignDisabled = false;
    this.isApproveDisabled = false;
    this.isRejectedDisabled = false;
    this.isDisputeDisabled = false;
    this.isDetailsDisabled = false;
    this.isReopenDisabled = false;
    this.isResubmitDisabled = false;
    this.isDisputeReopenDisabled = false;
    this.isNeedInfoDisabled = false;
  }

  disableOtherStatusButton(action: string) {
    switch (action) {
      case 'REJECTED':
        this.isRejectedDisabled = false;
        break;

      case 'DISPUTE':
        this.isDisputeDisabled = false;
        break;

      case 'DETAILS_PROVIDED':
        this.isDetailsDisabled = false;
        break;

      case 'REOPEN':
        this.isReopenDisabled = false;
        break;

      case 'RESUBMIT':
        this.isResubmitDisabled = false;
        break;

      case 'DISPUTE_REOPEN':
        this.isDisputeReopenDisabled = false;
        break;

      case 'NEED_MORE_DETAILS':
        this.isNeedInfoDisabled = false;
        break;

      case 'SAVE':
        this.buttonshow = false;
        this.isSaveDisabled = false;
        break;

      case 'ACCEPTED':
        this.isAcceptDisabled = false;
        break;

      case 'APPROVED':
        this.isApproveDisabled = false;
        break;

      case 'ASSIGN_SURVEYOR':
        this.isAssignDisabled = false;
        break;
    }
  }
  getPrivilege(){
    var pageId =  appConst.PAGE_NAME.PAYABLE.PAYABLE_REPORTLOSS.PAGEID;
    if(this.isReceivable){
     pageId =  appConst.PAGE_NAME.RECEIVABLE.RECEIVABLE_REPORTLOSS.PAGEID;
    }
    this.appService.getPrivilegeForPage(pageId).subscribe((res: any)=>{
      this.pageInfo = res.content;
      this.getPageInfo(pageId);
    });
  }

  getPageInfo(pageID: number): boolean{
    if(this.pageInfo != null || this.pageInfo !== undefined){
      const pageValue = this.pageInfo.find((element: any) => element.pageId === pageID);
      return pageValue;
    }else{
      return true;
    }
  }

}
