import { Component, Input, OnInit, Output,EventEmitter } from '@angular/core';
import { Messager } from 'src/app/models/user-data-dto';
import { ReportLossService } from 'src/app/service/report-loss.service';
import { UserListService } from 'src/app/service/user-list.service';

@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.scss']
})
export class CommentsComponent implements OnInit {

  messages:Messager[]=[];
  commentsData= new Messager();
  popupDiv=false;
  @Output() commentsshowornot=new EventEmitter<boolean>();

  @Input()
  claimId: string;

  @Input()
  status:string;

  @Input()
  receivable:boolean;

  newMessage='';

   constructor(private service:UserListService, private reportLossService:ReportLossService){}

   ngOnInit() {
    this.getMessageData();
  }

  dateofchat=[];
  timeofchat=[];

  getMessageData(){
    this.messages =[];
    this.service.getUserComments(this.claimId).subscribe((data)=>{

    data.forEach(element => {
       this.messages.push(element);
    });
    })
  }

  keyBoardEvent(event :any){
  }

  getMessageFromChat(){

    if(this.newMessage!='' && this.newMessage!=undefined){
      this.popupDiv=false;
      this.commentsData.message=this.newMessage;
      this.commentsData.isReceivable=this.receivable;
      this.commentsData.status=this.status;
      this.service.setUserComments(this.claimId,this.commentsData).subscribe(data=>{
        this.getMessageData();
      });
      this.newMessage='';
    }

    else{
      this.popupDiv=true;
    }

  }

  onClosing(){
    this.commentsshowornot.emit();
    this.reportLossService.showReportLoss(true,true);
  }


  removemessage()
  {
    this.popupDiv=false;
  }


}

