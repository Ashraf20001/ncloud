import { EventEmitter, Output, OnChanges, SimpleChanges } from '@angular/core';
/* eslint-disable @typescript-eslint/no-empty-function */
import { Section } from './../../../models/report-loss-dto/section';
import { Component, OnInit, Input } from '@angular/core';
import { ReportLossService } from 'src/app/service/report-loss.service';

@Component({
  selector: 'app-report-loss-section',
  templateUrl: './report-loss-section.component.html',
  styleUrls: ['./report-loss-section.component.scss']
})

export class ReportLossSectionComponent implements OnChanges{

  @Input() sectionListFromParent:Section[];
  @Input() sectionNamefromCard:string;
  @Input() currentParantSectionName:string;
  @Input() mainSectionNameFromCard:string;
  @Input() sectionEnable:boolean[];
  @Input() percentageValues = [0, 0, 0, 0];
  @Output() showParent = new EventEmitter<Section>();
  @Output() sendButtonStatusFromSection = new EventEmitter<any>();
  selectedSectionName = '';

  isNotificationStage = false;
  isInspectionStage = true;
  isLiabilityStage = true;
  isSettlementStage = true;

  isEnable=[
    this.isNotificationStage,
    this.isInspectionStage,
    this.isLiabilityStage,
    this.isSettlementStage
  ];

  // isEnable:boolean[];

  imageSectionList = [
    {
      image:"assets/reportloss/stage/Notification Stage.svg",
      title:"Notification Stage"
    },
    {
      image:"assets/reportloss/stage/Claim Inspection Stage.svg",
      title:"Claim Inspection Stage"
    },
    {
      image:"assets/reportloss/stage/Liability Confirmation Stage.svg",
      title:"Liability Confirmation Stage"
    },
    {
      image:"assets/reportloss/stage/newsettlementStage.svg",
      title:"Settlement Stage"
    }
  ]

  constructor(private dataservice: ReportLossService) {
  }


  ngOnChanges(changes: SimpleChanges): void {
    if(this.currentParantSectionName != undefined){
      this.sectionNamefromCard =this.currentParantSectionName;
    }
      if(changes) {
          this.selectedSectionName = this.mainSectionNameFromCard;
      }
  }

  sendItemToParent(item:Section){
    this.showParent.emit(item);
    this.dataservice.isOpenStage(false);
    this.selectedSectionName = item.sectionName;
  }

  getUrl(item: Section): string {
    let src = '';
    const img = this.imageSectionList.find((img) => img.title === item.sectionName);
    if(img) {
      src = img.image;
    }
    return src;
  }


}
