import { Component } from '@angular/core';

@Component({
  selector: 'app-report-loss-header-action',
  templateUrl: './report-loss-header-action.component.html',
  styleUrls: ['./report-loss-header-action.component.scss']
})

export class ReportLossHeaderActionComponent{

}
