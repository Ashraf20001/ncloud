import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { FormControl } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { StageNameReportLoss } from 'src/app/common/enum/enum';
import { DashboardService } from 'src/app/service/dashboard.service';
import { FileUploadService } from 'src/app/service/file-upload.service';
import { ReportLossService } from 'src/app/service/report-loss.service';
import { UserListService } from 'src/app/service/user-list.service';
import { environment } from 'src/environments/environment';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { TranslateService } from '@ngx-translate/core';

export const MY_FORMATS = {
  parse: {
      dateInput: 'LL'
  },
  display: {
      dateInput: 'DD-MM-YYYY',
      monthYearLabel: 'YYYY',
      dateA11yLabel: 'LL',
      monthYearA11yLabel: 'YYYY'
  }
};
@Component({
  selector: 'app-claim-history',
  templateUrl: './claim-history.component.html',
  styleUrls: ['./claim-history.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }
  ],
})

export class ClaimHistoryComponent implements OnChanges {
  claimSection = new FormControl('');


  claimSectionList: string[] = [StageNameReportLoss.insuredDetails,StageNameReportLoss.tpDetails,StageNameReportLoss.lossDetails,StageNameReportLoss.policeDetails,StageNameReportLoss.garageDetails,StageNameReportLoss.surveyDetails,StageNameReportLoss.surveyReport,StageNameReportLoss.recoveryDetails,StageNameReportLoss.reserveReview,StageNameReportLoss.garageInvoice,StageNameReportLoss.debitNote,StageNameReportLoss.creditNote];
  @Output() triggerCloseHistory = new EventEmitter<boolean>();
  @Output() showhismessage = new EventEmitter<boolean>();
  @Output() fullViewReporthistory=new EventEmitter<boolean>();
  @Output() fullViewReportshow=new EventEmitter<boolean>();
  @Input()
  claimId: string;
  @Input() clickClaimHistoryIcon : number;
  
  historyList:any[]=[];
  historyListcopy:any[]=[];

  documentFile: any;

  insuranceCompanyImgUrl = '';

  tpCompanyImgUrl = '';
  histort_full=false;

  public dPDF;

  historyCount: any;

  imageList = [];
  hide_button=true;

  imageSectionList = [
    {
      image: "assets/reportloss/stage/Notification Stage.svg",
      title: "Notification Stage"
    },
    {
      image: "assets/reportloss/stage/Claim Inspection Stage.svg",
      title: "Claim Inspection Stage"
    },
    {
      image: "assets/reportloss/stage/Liability Confirmation Stage.svg",
      title: "Liability Confirmation Stage"
    },
    {
      image: "assets/reportloss/stage/Settlement Stage.svg",
      title: "Settlement Stage"
    }
  ]

  imageSectionListMessage = [
    {
      image: "assets/reportloss/stage/message/Notification Stage.svg",
      title: "Notification Stage"
    },
    {
      image: "assets/reportloss/stage/message/Claim Inspection Stage.svg",
      title: "Claim Inspection Stage"
    },
    {
      image: "assets/reportloss/stage/message/Liability Confirmation Stage.svg",
      title: "Liability Confirmation Stage"
    },
    {
      image: "assets/reportloss/stage/message/Settlement Stage.svg",
      title: "Settlement Stage"
    }
  ]
  selectedObjects : any[];
  temp: any;
  constructor(private utilsService: UserListService, private reportLossService: ReportLossService, private sanitizer: DomSanitizer, 
    private fileUploadService: FileUploadService, private dashboardService: DashboardService, private translate: TranslateService) {
      this.translate.onLangChange.subscribe(() => {
        this.getClaimHistory();
      });
    }
  list:any[]=[];
  selectedObjects1(){
    this.historyList=[];
    if(this.selectedObjects.length>0)
    {
      this.selectedObjects.forEach((sectionName: string) => {
        this.historyListcopy.find((data: any) =>{
          if(data.sectionName === sectionName){
            this.historyList.push(data)
          }
        });
      });
    }else{
      this.historyList = this.historyListcopy;
    }
      }
  /*
  * clickClaim HistoryIcon After Change
  */
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['clickClaimHistoryIcon'].currentValue!== undefined) {
      this.selectedObjects = [];
      this.getClaimHistory();
    }
  }

  getClaimHistory() {
    this.historyList  = [];
    this.temp = [];
    this.utilsService.getClaimHistory(this.claimId).subscribe((data) => {
      this.temp = data;
      this.historyList = this.temp;
      this.temp.map(x => {
        if (x.claimHistoryUniqueCode) {
          var tmp = this.translate.instant(`claimHistoryTemplate.${x.claimHistoryUniqueCode}`);
          const parsedObject = JSON.parse(x.replaceableData);
          const keyValueList = [];
          for (const key in parsedObject) {
            if (parsedObject.hasOwnProperty(key)) {
              keyValueList.push({ key, value: parsedObject[key] });
            }
          }
          keyValueList.forEach(({ key, value }) => {
            const regex = new RegExp(key, "g");
            tmp = tmp.replace(regex, value);
          });
          if (!tmp.includes("claimHistoryTemplate")) {
            x.template = tmp;
          }
        }
      })
      this.historyList  = [];
      this.historyListcopy = [];
      this.historyList = this.temp;
      this.historyListcopy = this.historyList;
      this.historyCount = this.historyList.length;
      this.hide_button = true;
      this.histort_full = false;
      this.dashboardService.getCompanyLogo(data[0].insuranceCompanyId).subscribe((response) => {
        if (response) {
          this.insuranceCompanyImgUrl = response['content']
        }
      });
      this.dashboardService.getCompanyLogo(data[0].tpCompanyId).subscribe((response) => {
        if (response) {
          this.tpCompanyImgUrl = response['content']
        }
      });
    });
  }

  onClose() {
    this.showhismessage.emit()
    this.fullViewReportshow.emit();
    this.reportLossService.showReportLoss(true, true);
    // this.triggerCloseHistory.emit();
  }

  downloadAttachments(fielName: any): void {
    this.fileUploadService.downloadImageByImageName(fielName).subscribe((response) => {
      const blob = new Blob([response]);
      const fileURL = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = fileURL;
      a.target = '_blank';
      const fileName = ['.']
      fileName.forEach(element => {
        if (fielName && !fielName.includes(element)) {
          a.download = fielName+".pdf";
          document.body.appendChild(a);
          a.click();
        }else{
          a.download = fielName;
          document.body.appendChild(a);
          a.click();
        }
      });


    });

  }

  getUrl(item: String): string {
    let src = '';
    if (item) {
      const img = this.imageSectionList.find((img) => img.title === item);
      if (img) {
        src = img.image;
      }
    }
    return src;
  }
  getUrl1(item: String): string {
    let src = '';
    if (item) {
      const img = this.imageSectionListMessage.find((img) => img.title === item);
      if (img) {
        src = img.image;
      }
    }
    return src;
  }

  getInsuredLogo(){
    if (this.insuranceCompanyImgUrl!=='') {
      return this.insuranceCompanyImgUrl;
    }else{
      return 'assets/no-logo.svg';
    }
  }

  getTpLogo(){
    if (this.tpCompanyImgUrl!=='') {
      return this.tpCompanyImgUrl;
    }else{
      return 'assets/no-logo.svg';
    }
  }

  load_more_history(){
    this.hide_button=false;
    this.fullViewReporthistory.emit();
    this.histort_full=true;

  }

}



