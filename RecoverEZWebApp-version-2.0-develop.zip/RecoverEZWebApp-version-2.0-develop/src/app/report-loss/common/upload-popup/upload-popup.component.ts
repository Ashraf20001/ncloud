import { Component ,OnInit} from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Observable, map, startWith } from 'rxjs';
import { SubUploadPopupComponent } from '../sub-upload-popup/sub-upload-popup.component';

@Component({
  selector: 'app-upload-popup',
  templateUrl:'./upload-popup.component.html',
  styleUrls: ['./upload-popup.component.scss']
})
export class UploadPopupComponent implements OnInit{
constructor(public dialog: MatDialog){

}
  closeTab()
  {
    this.dialog.closeAll();
  }
  myControl = new FormControl('');
  options: string[] = ['One', 'Two', 'Three'];
  filteredOptions: Observable<string[]>;

  ngOnInit() {
    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value || '')),
    );
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.options.filter(option => option.toLowerCase().includes(filterValue));
  }
uploaded_file_list(){


  const dialogRef = this.dialog.open(SubUploadPopupComponent, {
  width:'1200px',height:'600px'

  });

  dialogRef.afterClosed().subscribe(() => {


  });
}

}
