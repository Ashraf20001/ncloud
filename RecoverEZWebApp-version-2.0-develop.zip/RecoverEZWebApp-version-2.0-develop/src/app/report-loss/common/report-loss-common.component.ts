import { ReportLossStageCardComponent } from './report-loss-stage-card/report-loss-stage-card.component';
import { Router } from '@angular/router';
import { FileUploadDTO } from './report-loss-stage-list/report-loss-stage-list.component';
import { Field } from './../../models/report-loss-dto/field';
/* eslint-disable @typescript-eslint/no-empty-function */
import { ToastrService } from 'ngx-toastr';
import { ReportLossData } from './../../models/report-loss-dto/report-loss-data';
import { ReportLossService } from 'src/app/service/report-loss.service';
import { Component, HostListener, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MetaDataDto } from 'src/app/models/report-loss-dto/meta-data-dto';
import { Section } from 'src/app/models/report-loss-dto/section';
import { ActivatedRoute } from '@angular/router';
import { FileUploadService } from 'src/app/service/file-upload.service';
import { ReportLossStageEnum } from 'src/app/common/enum/enum';
import { AppService } from 'src/app/service/role access/service/app.service';
import { appConst } from 'src/app/service/app.const';
import { ErrorHandlerDirective } from 'src/app/common/directives/errorHandler.directive';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-report-loss-common',
  templateUrl: './report-loss-common.component.html',
  styleUrls: ['./report-loss-common.component.scss']
})

export class ReportLossCommonComponent implements OnInit,OnDestroy{

  @ViewChild(ReportLossStageCardComponent) stageCard:ReportLossStageCardComponent;

  reportLossData: ReportLossData;
  metaData:MetaDataDto;
  sectionList:Section[];
  selectedSection: Section;
  reportLossPageVisibility=true;

  parentPageId : string;
  claimId : string = null;
  cardItem: any;
  selectedFieldItems: any;
  fieldListItems: any;
  isOpenstage:boolean;

  pageInfo: any;
  public appConst = appConst;
  pageId :number;
  percentageValues = [0, 0, 0, 0];
  isFromPayable = false;
  currentParantSectionName: any;
  bulkImportUploadIdentity: string;
  clickClaimHistoryIcon: number = 0;
  showhistorys=true;
  showcomments=true;
  isSomeOneWorking=false;
  ispageEnabled: boolean;

  constructor(private reportLossService: ReportLossService,
    private router:Router,
    private toaster:ToastrService, private route: ActivatedRoute,
    private fileUploadService: FileUploadService, private appService : AppService,private errorHandler : ErrorHandlerDirective,private translate: TranslateService){
      this.route.queryParams.subscribe(params => {
        const claimId = params['claimId'];
        if (claimId) {
          this.saveReportLossWorkingUser(claimId);
        }
      });
      this.route.queryParams.subscribe((queryParams: any) => {
        this.isFromPayable = queryParams["rec"];
        this.claimId = queryParams['claimId'];
        this.bulkImportUploadIdentity = queryParams['uploadIdentity']
        this.parentPageId =  appConst.PAGE_NAME.RECEIVABLE.RECEIVABLE_REPORTLOSS.PAGE_IDENTITY;
        this.pageId =  appConst.PAGE_NAME.RECEIVABLE.RECEIVABLE_REPORTLOSS.PAGEID;
        const page = sessionStorage.getItem('ViewReportLoss');
        if( page === "Payable" || page === "false"){
          this.pageId = appConst.PAGE_NAME.PAYABLE.PAYABLE_REPORTLOSS.PAGEID;
          this.parentPageId = appConst.PAGE_NAME.PAYABLE.PAYABLE_REPORTLOSS.PAGE_IDENTITY;
        }
        this.getPrivilege();
        this.getMetadata(this.parentPageId, this.claimId, this.bulkImportUploadIdentity);

      });
      this.getHistoryCommentsShowStatus();
    }

    
    @HostListener('window:beforeunload', ['$event'])
    beforeUnloadHandler(event: any) {
      this.route.queryParams.subscribe(params => {
        const claimId = params['claimId'];
        if (claimId) {
          this.removeReportLossWorkingUser(claimId);   
        }
      });
    }
  
  ngOnInit() {

    this.reportLossService.isOpen.subscribe((value:boolean) => {
      this.isOpenstage=value;
    });

    this.reportLossService.view.subscribe((value:boolean)=>{
      this.reportLossPageVisibility=value;

    });

    this.reportLossService.viewHistory.subscribe((value:boolean)=>{
      this.reportLossPageVisibility= value;
    });

    this.reportLossService.hideUser.subscribe((data:boolean)=>{
  this.reportLossPageVisibility=data;

    });


  }
  isReceivable:boolean;
  receivableBoolean:boolean;
  status:string;
  surveyDueHours:string;

  getMetadata(pageId: string, claimId: string, uploadIdentity:string){
    if(uploadIdentity){
      this.reportLossService.getMetaDataDtoForBulkUpload(uploadIdentity).subscribe((result: ReportLossData)=>{
        if(result){
          this.reportLossData = result;
          this.surveyDueHours = this.reportLossData.surveyDueHours;
          this.metaData = this.reportLossData.metaData;
          this.sectionList = result.metaData.sectionList;
          this.receivableBoolean = result.receivable;
          this.status = result.status;
          this.ispageEnabled =  this.metaData.enabled;
          this.setReadOnly(this.metaData.sectionList, this.status);
          sessionStorage.setItem('insurerName',result.insurerName)
        }
      })
    }else{
      this.reportLossService.getMetaDataDto(pageId, claimId).subscribe((result: ReportLossData)=>{
        if(result){
          this.reportLossData = result;
          this.surveyDueHours = this.reportLossData.surveyDueHours;
          this.metaData = this.reportLossData.metaData;
          this.sectionList = result.metaData.sectionList;
          this.receivableBoolean = result.receivable;
          this.status = result.status;
          this.ispageEnabled =  this.metaData.enabled;
          this.setReadOnly(this.metaData.sectionList,this.status);
          sessionStorage.setItem('insurerName',result.insurerName)
        }
      })
    }
  }

  selectedSectionName:string;

  setSelectedSection(item: Section): void {
    this.selectedSection = item;
    this.selectedSectionName = item.sectionName;
    this.cardToSection = item.sectionName;
    this.stageCard.triggerStageList();
  }

  sendParentSectionNameToChild(event){
    this.selectedSectionName = event;
  }

  setReadOnly(sectionList: Section[],status :string): void {
    sectionList.forEach((section: Section) => {
      if(section && section.sectionList && section.sectionList.length > 0) {
        this.setReadOnly(section.sectionList,status);
      }
      if(section && section.fieldList && section.fieldList.length > 0) {
        section.fieldList.forEach((field: Field) => {
          field.readOnly = field.isCoreData !== null && field.isCoreData === !this.receivableBoolean;
          if(field.columnName === "tpName" && field.value !== null && status != 'Draft'){
            field.readOnly = false;
          }
        });
      }
    });
  }


  setSelectedCard(event: any): void{
    this.cardItem = event;
  }
  setparantSectionName(event){
    this.currentParantSectionName = event;
    // this.cardToSection = event;
  }

  setFieldList(event: { fileData: FileUploadDTO, sectionName: string, data: Field[], isAllDeleted: boolean, removedFileList: number[]}): void{
    this.fieldListItems = event.data;
    this.cardItem = event.sectionName;
    if(event.fileData && event.fileData.fileList && event.fileData.fileList.length > 0) {
      this.onUpload(event.fileData,event.data);
    } else {
      if(event.removedFileList && event.removedFileList.length > 0) {
        this.fileUploadService.deleteFileList(event.removedFileList).subscribe((response: any) => {
          this.toaster.success(this.translate.instant("Toaster_Message.Document_remove"));
          if(event.isAllDeleted) {
            event.data.forEach((field: Field) => {
              if(field.fieldType === 'file') {
                field.value = null;
              }
            });
          }
          this.settingMetaData(event.data);
        });
      } else {
        this.settingMetaData(event.data);
      }
    }
  }

  selectedFieldListItems(event: { fileData: FileUploadDTO, sectionName: string, data: Field[], isAllDeleted: boolean, removedFileList: number[]}){
    this.fieldListItems = event.data;
    this.cardItem = event.sectionName;
    if(event.fileData && event.fileData.fileList && event.fileData.fileList.length > 0) {
      this.onUpload(event.fileData,event.data);
    } else {
      if(event.removedFileList && event.removedFileList.length > 0) {
        this.fileUploadService.deleteFileList(event.removedFileList).subscribe((response: any) => {
          this.toaster.success(this.translate.instant("Toaster_Message.Documet_removes"));
          if(event.isAllDeleted) {
            event.data.forEach((field: Field) => {
              if(field.fieldType === 'file') {
                field.value = null;
              }
            });
          }
          this.settingMetaData(event.data);
        });
      } else {
        this.settingMetaData(event.data);
      }
    }
  }

  // OnClick of button Upload
  onUpload(fileData: FileUploadDTO,data: Field[]) {
    this.fileUploadService
      .upload(
        fileData.fileList,
        fileData.referenceId,
        fileData.fieldName
      )
      .subscribe((response) => {
        if(response) {
          const groupId = response.content;
          this.fieldListItems.forEach((field: Field, index: number) => {
            if(field.fieldType === 'file') {
              field.value = groupId;
              data[index].value = groupId;
            }
          });
          if(data[0].entityName==="PoliceReport"){
        //  this.toaster.success( data[0].entityName.replace(/([A-Z])/g, ' $1').trim() +' File(s) Uploaded Successfully');
         this.toaster.success(this.translate.instant("Toaster_Message.Police_report_save"));

          }
        }else{
          if(data[0].entityName === "PoliceReport"){
            this.toaster.error(this.translate.instant("Toaster_Message.Police_report_mandatory"))
          }
        }
        this.settingMetaData(data);
      });
  }

  settingMetaData(data: Field[]): void{
    this.reportLossData.metaData.sectionList.forEach((value)=>{
      if(value.sectionList.length > 0){
        value.sectionList.forEach((element)=>{
          if(element.sectionName === this.cardItem){
            element.fieldList = this.fieldListItems;
          }
          // Validate For All Mandatory field is Filled
          const mandatoryFiledWithFilledValueCount = element.fieldList.filter(item => item.mandatory && item.value && item.value !== "null");
          const mandatoryFiledCount = element.fieldList.filter(item => item.mandatory);
          element.isAllFilled = mandatoryFiledCount.length > 0 && mandatoryFiledWithFilledValueCount.length === mandatoryFiledCount.length;

        })
      }
    });
    this.reportLossService.saveReportLoss(this.reportLossData,this.claimId,data).subscribe((response) => {

      if (response) {
        this.checkFilled(data);
        this.claimId = response.claimIdentity;
        this.router.navigateByUrl('report-loss?claimId='+this.claimId+"&rec="+this.isFromPayable, { replaceUrl: true });
        if(data[0].entityName === "GarageInfo"){
          this.toaster.success(this.translate.instant("Toaster_Message.Garage_detail_save"));
        }else{
          if(data[0].entityName !== "PoliceReport"){
          this.toaster.success( this.translate.instant("entity_name."+data[0].entityName) + " " + this.translate.instant("Toaster_Message.Saved"));
        }
      }
      }

    }, error => {
      this.checkFilled(data);
    });
  }

  checkFilled(data: Field[]): void {
    let count = 0;
    
    data.forEach((item) => {
        if((item.fieldName=="srSpareParts"||item.fieldName=="srLabourCost")
        &&(this.reportLossData.totalLossType=="type1"||this.reportLossData.totalLossType=="type2")){
          count++;
        }
      else if (item.mandatory && item.value) {
        count++;
      } else if(!item.mandatory) {
        count++;
      }// }else if(item.fieldName==='tpClaimNo' && item.value===null){
      //   count++;
      // }
    });
    if(data.length === count) {
      this.isFieldFromStageListData = true;
      this.filledSubSectionName = this.cardItem;
    } else {
      this.isFieldFromStageListData = false;
      this.filledSubSectionName = '';
    }
    this.reportLossService.filledSection$.next(this.filledSubSectionName);
  }

  details:any;
  fieldListFromStage:Field[];

  fromStageToParent(event){
    this.details = event;
    this.fieldListFromStage = event.fieldList;
    this.showhistorys = true;
    this.showcomments = true;
    this.claimHistoryAndCommentAddedTheSessionStroge();
  }

  claimIdFromHeader:string;

  geClaimId(event){
    this.claimIdFromHeader = event;
  }

  cardToSection:string;

  fromCardToParent(event){
    this.cardToSection = event;
  }

  isFieldFromStageListData:boolean;
  filledSubSectionName:string;
  isFieldFromStageList(event){
    this.isFieldFromStageListData = event.isNotFilled;
    this.filledSubSectionName = event.subSectionName;
  }

  isFieldFilledArray:boolean[];

  fieldBooleanValues(event){
    this.isFieldFilledArray = event;
  }

  mainSectionNameFromCard:string;

  collectMainSectionName(event){
    this.mainSectionNameFromCard = event;
  }

  enableSectionFromStage:boolean[];

  enableSections(event){
    this.enableSectionFromStage = event;
  }

  valuesFromStageList:any;

  valuesFromListToParent(event){
    this.fieldListItems = event;
  }

  submitButtonTrigger(){
  //  this.settingMetaData(data);
  }

  currentStatus:string;

  getStatus(event){
    this.currentStatus = event;
  }

  getReportLossData(event){
    this.reportLossData = event;
  }

  getIsReceivable(event){
    this.isReceivable = event;
  }

  detailsFromStage:any;

  getDetails(event){
    this.detailsFromStage = event;
  }

  getPrivilege(){
    this.appService.getPrivilegeForPage(this.pageId).subscribe((res: any)=>{
      this.pageInfo = res.content;
      this.getPageInfo();
    });
  }

  getPageInfo(): boolean{
    if(this.pageId){
      const pageValue = this.pageInfo && (this.pageInfo.length === 0 || this.pageInfo.find((element: any) => element.pageId === this.pageId));
      return pageValue;
    }
  }

  setPercentageData(data: number[]): void {
    this.percentageValues = data;
  }

  isFullViewOpen = true;



  fullViewReport()
  {
    this.ngOnInit();
    this.isFullViewOpen =!this.isFullViewOpen;
  }


  historyfull=true;
  fullViewReporthistory(){
    this.ngOnInit();
    this.historyfull=!this.historyfull;

  }


  notification=true;
  fullViewNotification(){
    this.ngOnInit();
    this.notification=!this.notification;

  }

  full_close()
  {
    this.ngOnInit();
    this.historyfull=true;
  }

  fullViewReports()
  {
    this.ngOnInit();
    this.isFullViewOpen=true;
  }
  showcomment()
  {
    this.ngOnInit();
    this.showcomments=false;
    this.showhistorys=true;
    this.historyfull=true;
    this.claimHistoryAndCommentAddedTheSessionStroge();
  }
  commentsshowornot()
  {
    this.ngOnInit();
    this.showcomments=true;
    this.claimHistoryAndCommentAddedTheSessionStroge();
  }
 
  showhistory()
  {
    this.ngOnInit();
    this.showhistorys=false;
    this.showcomments=true;
    this.historyfull=true;
    this.clickClaimHistoryIcon = this.clickClaimHistoryIcon+1;
    this.claimHistoryAndCommentAddedTheSessionStroge();
  }
  showhismessage()
  {
    this.ngOnInit();
    this.showhistorys=true;
    this.claimHistoryAndCommentAddedTheSessionStroge();
  }
  refreshPage(){
    this.getMetadata(this.parentPageId,this.claimId, this.bulkImportUploadIdentity);
  }

  closeFullView(){
    this.ngOnInit();
    this.isFullViewOpen = !this.isFullViewOpen;
  }

  claimHistoryAndCommentAddedTheSessionStroge(){
    sessionStorage.setItem("claimHistory",JSON.stringify(this.showhistorys));
    sessionStorage.setItem("commends",JSON.stringify(this.showcomments));
  }

  getHistoryCommentsShowStatus(){
    if(sessionStorage.getItem("claimHistory")){      
      this.showhistorys =  sessionStorage.getItem("claimHistory") == "true";
    }
    if(sessionStorage.getItem("commends")){      
      this.showcomments = sessionStorage.getItem("commends") == "true";    
    }  
  }

  ngOnDestroy(): void {
    this.route.queryParams.subscribe(params => {
      const claimId = params['claimId'];
      if (claimId) {
        this.removeReportLossWorkingUser(claimId);
      }
    });    
    sessionStorage.removeItem("claimHistory");
    sessionStorage.removeItem("commends");
  }

  saveReportLossWorkingUser(claimId: string) {
    this.reportLossService.saveReportLossWorkingUser(claimId).subscribe((response) =>{
      this.isSomeOneWorking = false;
    }, (error: Response) =>{
      this.isSomeOneWorking = true;
    });
  }

  removeReportLossWorkingUser(claimId: string) {
    this.reportLossService.removeReportLossWorkingUser(claimId).subscribe((response) =>{
    });
  }
}
