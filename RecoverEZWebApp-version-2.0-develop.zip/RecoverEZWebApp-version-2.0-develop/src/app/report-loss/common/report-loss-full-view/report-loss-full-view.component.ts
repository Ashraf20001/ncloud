import { reportDataVo } from './../../../models/field-dto';
import { EntityName, GarageFieldEnum, ReportLossStageEnum } from './../../../common/enum/enum';
/* eslint-disable prefer-const */
import { FileUploadDTO } from 'src/app/report-loss/common/report-loss-stage-list/report-loss-stage-list.component';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { TotalLoss } from './../../../models/report-loss-dto/total-loss';
import { DatePipe } from '@angular/common';
import { Component, ElementRef, EventEmitter, Input, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { MimeTypeEnum, ReportLossStatus, ReportLossStatusValue, StageNameReportLoss } from 'src/app/common/enum/enum';
import { Field } from 'src/app/models/report-loss-dto/field';
import { MetaDataDto } from 'src/app/models/report-loss-dto/meta-data-dto';
import { ReportLossData } from 'src/app/models/report-loss-dto/report-loss-data';
import { Section } from 'src/app/models/report-loss-dto/section';
import { DropDownServiceService } from 'src/app/service/drop-down-service.service';
import { FileUploadService } from 'src/app/service/file-upload.service';
import { ReportLossService } from 'src/app/service/report-loss.service';
import { ReportLossConst } from 'src/app/common/enum/report-loss-card-enum';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { TranslateService } from '@ngx-translate/core';
import { ParentDropdownFieldMap } from 'src/app/models/report-loss-dto/parentDropdownField';

export const MY_FORMATS = {
  parse: {
      dateInput: 'LL'
  },
  display: {
      dateInput: 'DD-MM-YYYY',
      monthYearLabel: 'YYYY',
      dateA11yLabel: 'LL',
      monthYearA11yLabel: 'YYYY'
  }
};

@Component({
  selector: 'app-report-loss-full-view',
  templateUrl: './report-loss-full-view.component.html',
  styleUrls: ['./report-loss-full-view.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }
  ],
})
export class ReportLossFullViewComponent implements OnInit {
  panelOpenState = false;
  @Input()  isReceivableFromParent:boolean;
  @Input() reportLossData:ReportLossData;
  @Input() isReceivableFromCommon: boolean;
  @Input() surveyDueHours:string;
  @Output() selectedFieldListItems = new EventEmitter<{ fileData: FileUploadDTO, sectionName: string, data: Field[], isAllDeleted: boolean, removedFileList: number[] }>();
  @Output() fullView = new EventEmitter<any>();
  @Input() sectionFromCard: Field[];
  @Input() filledSubSectionNameFromparent: string;
  @Input() percentageValue = [0, 0, 0, 0];
  @ViewChild('fileDropRef') hiddenInput: ElementRef;
  isTotalLossPresent!: boolean;
  showLossDetailsTotalLoss = false;
  showsurveyReportTotalLoss = false;
  showTotalLossColumns!: boolean;
  setMinDecimalPipe=false;
  setMinDecimalPipeAmount1=false;
  setMinDecimalPipeAmount2=false;
  setMinDecimalPipeAmount3=false;
  showSurveyAmount = false;
  showDownload:boolean=false;
  disableSurveyDatePicker2 = false;
  disableSurveyDatePicker1 = false;
  atFaultCompanyName: string;
  insurerName: string;
  reasonTotalLossDropDown: any [];
  dueDate: number;
  showDate = new Date();
  showDate1: string;
  disableSurveyDueDate = false;
  minimumDate= new Date();

  isSurveyReportView:boolean=false;
  isRecoveryDetailsView:boolean=false;
  totallosshiddenView:boolean=true;
  isLossDetailTotalLossView:boolean=false;
  fileRemoved: boolean = false;
  parentFieldMap: ParentDropdownFieldMap[];
  policeReportFields: number;

  rdClaimAmount: number;

  constructor(
    private dataservice: ReportLossService,
    public datepipe: DatePipe,
    private toaster:ToastrService,
    private dropDownService : DropDownServiceService,
    private fileUploadService: FileUploadService,
    private activatedRoute: ActivatedRoute,
    private translate: TranslateService
  ) {
  }

  subSectionList:Section;
  sectionList:Section[];
  isFilledBoolean:boolean[];


  report_datas()
  {
    this.sectionList = [];
    this.isFilledBoolean = [];
    this.reportLossData?.metaData.sectionList.forEach(element => {
      element?.sectionList.forEach(element1 => {
        this.subSectionList = element1;
        this.subSectionList.isExpanded = false;
        if (this.subSectionList!== undefined) {
          this.sectionList.push(this.subSectionList)
          this.isFilledBoolean.push(this.subSectionList.isAllFilled)
        }
      });
    });
    this.sectionList[0].fieldList.sort((a: Field, b: Field) => a.orderBy - b.orderBy);
    this.selectedFieldList = this.sectionList[0].fieldList;
  }




   field: Field;

  showCards: boolean;
  show=false;
  dropdownlist: any;
  modelDropdownlist: any;
  ReportLossService: any;
  reporting: any;
  reportingList: any;
  formFlag: boolean;
  selectedItemFieldList: any;

  amount1:number;
  amount2:number;
  totalAmount:number;
  adjustor1:string;
  adjustor2:string;
  date1:any;
  date2:any;
  totalLossReason:string;
  nameOfSalvageSeller:string;
  nameOfSalvageBuyer:string;
  salvageTotal:number;

  saveButton = true;
  downloadAndPreviewButton = false;
  lastStatus:string;
  status:string;


  readOnlyField = true;
  dateOfPurchase:string;

  maxDate = new Date();
  minDate = new Date();
  fiveYearBack = new Date(new Date().setFullYear(new Date().getFullYear() - 5));
  minYearBack = new Date(new Date().setFullYear(new Date().getFullYear() - 1));

  tpSurveyAmount :number = 0;
  fileName = 'Drag and drop file or';
  fileType:any
  fileViewList = [];
  isReceivablepage = false;
  isDisabled = false;

  selectedFieldList:Field[]=[];
  name:string;


  receivable= true;
  receivableString:string;
  totalLossType:string;
  lastDate = new Date(new Date().setFullYear(new Date().getFullYear() - 10));

  isClaimSettled = false;
  isTotalLossInitiated = false;
  surveyAmount: any;
  salvageAmount: number;
  showSpareAmt = false;
  isAtFaultInitiated: boolean = false ;
  // totAmt1: number ;
  // salAmt: number;
  activeIdx: number;
  NOTIFICATION_STAGE = 'Notification Stage';
  INSURED_INFO_SECTION = 'Insured Details';
  PURCHASED_DATE_FIELD = 'inPurchaseDate';
  
  addStyle(i)
  {
    this.activeIdx = i;
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes) {
      if(this.reportLossData) {
        const idx = this.reportLossData.metaData.sectionList.findIndex((sec: Section) => sec.sectionName === this.NOTIFICATION_STAGE);
        if(idx !== -1) {
          const index = this.reportLossData.metaData.sectionList[idx].sectionList.findIndex((sec: Section) => sec.sectionName === this.INSURED_INFO_SECTION);
          if(index !== -1) {
            const i = this.reportLossData.metaData.sectionList[idx].sectionList[index].fieldList.findIndex((value: Field) => value.fieldName === this.PURCHASED_DATE_FIELD);
            this.dateOfPurchase = i !== -1 ? this.reportLossData.metaData.sectionList[idx].sectionList[index].fieldList[i].value : undefined;
          }
          this.policeReportFields = this.reportLossData.metaData.sectionList[idx].sectionList[index].fieldList.length;
        }
        const lossDetailsTotalLoss = this.reportLossData.metaData.sectionList.find(item=>item.sectionName==ReportLossStageEnum.notificationStage)
        .sectionList.find(item=>item.sectionName==StageNameReportLoss.lossDetails)
        .fieldList.find(item=>item.fieldName=="ldIsTotalLoss");
        const surveyReportTotalLoss = this.reportLossData.metaData.sectionList.find(item=>item.sectionName==ReportLossStageEnum.claimInspectionStage)
        .sectionList.find(item=>item.sectionName==StageNameReportLoss.surveyReport)
        .fieldList.find(item=>item.fieldName=="srTotalLoss");
    
        if(lossDetailsTotalLoss != undefined){
        if(lossDetailsTotalLoss.value == "true"){
          this.checkBox = true;
        }
      }
      if(surveyReportTotalLoss != undefined){
        if(surveyReportTotalLoss != undefined&&surveyReportTotalLoss.value == "true"){
          this.checkBox = true;
        }
      }
      }
      // this.dateOfPurchase = this.reportLossData?.metaData.sectionList[0].sectionList[0].fieldList[3].value;
      // this.policeReportFields = this.reportLossData?.metaData.sectionList[0].sectionList[0].fieldList.length;
      this.lastStatus = this.reportLossData?.lastStatus;
      this.status = this.reportLossData?.status;
      this.totalLossType = this.reportLossData?.totalLossType;
     //this.checkTotalLoss();
      this.showDownloadAndPreviewButton();
      this.differenceBtwDate();
      this.changeButtonAccordingToStatus()
      this.showDownloadButton()

      if(this.dateOfPurchase != null &&  this.dateOfPurchase != undefined){
        const date = new Date(this.dateOfPurchase);
        this.fiveYearBack = date;
        this.minYearBack = date;
        this.lastDate = new Date(this.dateOfPurchase);
      }
    }

  }
  pdfSrc = '';




  onFileSelected(data: Field) {
    const $img: any = document.getElementById('#file'+data.fieldName);
    if (typeof FileReader !== 'undefined') {
      let reader = new FileReader();
      reader.onload = (e: any) => {
        data.pdfSrc = e.target.result;
      };
      reader.readAsArrayBuffer($img.files[0]);
    }
  }
  showDownloadButton(){
     const document = this.selectedFieldList?.find((dt) => dt?.fieldType === "file");
     if(document?.value==null||document?.value==undefined||document?.value?.endsWith("/")){
      this.showDownload=true;
     } else {
      this.showDownload = false;
     }
  }
  // checkTotalLoss(){
  //   if (this.totalLossType) {
  //     this.checkBoxTick = true;
  //   }
  // }


  getDropDown(){
    this.dropDownService.getParentFieldMap().subscribe((res)=>{
      if(res){
        this.parentFieldMap = res.content;
        this.parentFieldMap.forEach(parentField => {
          const metaData = this.selectedFieldList.find((dt) => dt.fieldName === parentField.parentFieldName);
          const childMetaData = this.selectedFieldList.find((dt) => dt.fieldName === parentField.childFieldName);
          if (childMetaData && childMetaData?.dropDownList===undefined) {
            this.getChildDropDowValue(null,metaData);
          }
                if(metaData && metaData.dropDownList===undefined){
           this.buildDropDownValues(parentField.parentFieldName,metaData,null)
          }
        });
      }
    })
    // const parentFieldMap = this.dropDownService.getParentFieldMap();

  }

  ngOnInit() {
    this.getIsAtFaultInitiatedTotalLoss();
    this.getTotalLossAmount();
    this.getTotalLossDropDownValue();
    this.isTickEnable = [
      true,true,true,true,true,true,true,true,true,true,true,true
     ];
     this.report_datas();
     this.changeButtonAccordingToStatus()

    this.receivable = this.isReceivableFromCommon;
    const parentFieldMap = this.dropDownService.getParentFieldMap();
        parentFieldMap.forEach(parentField => {
      const metaData = this.selectedFieldList.find((dt) => dt.fieldName === parentField.parentFieldName);
      const childMetaData = this.selectedFieldList.find((dt) => dt.fieldName === parentField.childFieldName);
      if (childMetaData && childMetaData.dropDownList===undefined) {
        this.getChildDropDowValue(null,metaData);
      }
            if(metaData && metaData.dropDownList===undefined){
       this.buildDropDownValues(parentField.parentFieldName,metaData,null)
      }
    });

     this.getTotalLoss();
     this.dataservice.filledSection$.subscribe((sectionName: string) => {
      this.isTickEnable[this.getIndexNumberOfEntity(sectionName)] = false;
     });
     this.showDownloadButton();

     this.mutliLanguageForField();
     this.translate.onLangChange.subscribe(() => {
       this.mutliLanguageForField();
     })

  }

  getIsAtFaultInitiatedTotalLoss() {
    if(this.reportLossData!=null || this.reportLossData!=undefined){
      this.atFaultCompanyName = this.reportLossData.atFaultCompanyName;
      this.insurerName = this.reportLossData.insurerName;
      this.reportLossData.metaData.sectionList.forEach((xx:Section)=>{
        xx.sectionList.forEach(subSec=>{
          const lossDetailsTotalLoss2 = subSec.fieldList.find((dt) => dt.fieldName === "ldIsTotalLoss");
          const surveyReportTotalLoss2 = subSec.fieldList.find((dt) => dt.fieldName === "srTotalLoss");

          if(lossDetailsTotalLoss2 != undefined){
            if(lossDetailsTotalLoss2.value == "true"){
              this.isAtFaultInitiated = false;
              this.isTotalLossInitiated = true;
              this.isLossDetailTotalLossView=true;
              return;
            }
          }
          if(surveyReportTotalLoss2 != undefined){
            if(surveyReportTotalLoss2.value == "true"){
              this.isAtFaultInitiated = true;
              this.isTotalLossInitiated = true;
              return;
            }
          }
        })
      })
    }
  }

  getTotalLossDropDownValue(){
    let fieldName = "Reason for Total loss";
    this.dropDownService.getOption(null,null,fieldName).subscribe((response:any)=>{
        if (response) {
          this.reasonTotalLossDropDown = response;
        }
      })
  }
  setFieldList(section:Section, index: number){
    this.name = section.sectionName;
    this.sectionList[index].isExpanded = true;
    this.selectedFieldList = section.fieldList;
    this.saveButton = this.showSaveButton();
        if(this.saveButton === undefined) {
      this.saveButton = true;
    }
    this.getDropDown();
    if(this.isClaimSettled){
      this.TotalLoss.disable();
      this.disableSurveyDatePicker1 = true;
      this.disableSurveyDatePicker2 = true;
    }
    else if(this.isReceivableFromCommon ){
      if(this.name === "Loss Details"){
        this.TotalLoss.controls['adjustorName2'].disable();
        this.TotalLoss.controls['surveyDate2'].disable();
        this.disableSurveyDatePicker2 = true;
        this.TotalLoss.controls['totalLossAmount2'].disable();

        this.TotalLoss.controls['adjustorName1'].enable();
        this.TotalLoss.controls['surveyDate1'].enable();
        this.disableSurveyDatePicker1 = false;
        this.TotalLoss.controls['totalLossAmount1'].enable();
        this.isDisabled = true;
      }else{
        this.TotalLoss.controls['adjustorName2'].enable();
        this.TotalLoss.controls['surveyDate2'].enable();
        this.disableSurveyDatePicker2 = false;
        this.TotalLoss.controls['totalLossAmount2'].enable();
        if(this.name === "Recovery Details"){
          this.TotalLoss.controls['salvageSellerName'].enable();
          this.TotalLoss.controls['salvageBuyerName'].enable();
          this.TotalLoss.controls['salvageAmount'].enable();
          this.TotalLoss.controls['estimatedTotalLossAmount'].enable();
        }

        this.TotalLoss.controls['adjustorName1'].disable();
        this.TotalLoss.controls['surveyDate1'].disable();
        this.disableSurveyDatePicker1 = true;
        this.TotalLoss.controls['totalLossAmount1'].disable();
        this.isDisabled = false;
      }
    }else{
      if(this.name ==="Loss Details"){
        this.TotalLoss.controls['adjustorName2'].enable();
        this.TotalLoss.controls['surveyDate2'].enable();
        this.disableSurveyDatePicker2 = false;
        this.TotalLoss.controls['totalLossAmount2'].enable();

        this.TotalLoss.controls['adjustorName1'].disable();
        this.TotalLoss.controls['surveyDate1'].disable();
        this.disableSurveyDatePicker1 = true;
        this.TotalLoss.controls['totalLossAmount1'].disable();
        this.isDisabled = false;
      }else{

        this.TotalLoss.controls['adjustorName1'].enable();
        this.TotalLoss.controls['surveyDate1'].enable();
        this.disableSurveyDatePicker1 = false;
        this.TotalLoss.controls['totalLossAmount1'].enable();

        this.TotalLoss.controls['adjustorName2'].disable();
        this.TotalLoss.controls['surveyDate2'].disable();
        this.disableSurveyDatePicker2 = true;
        this.TotalLoss.controls['totalLossAmount2'].disable();
        this.isDisabled = true;
      }
    }
    if(this.name=="Survey Report"){
      this.isSurveyReportView=true;
    }else{
      this.isSurveyReportView=false
    }

    if(this.name=="Recovery Details"){
      this.isRecoveryDetailsView=true;
    }else{
      this.isRecoveryDetailsView=false
    }
    this.setTotalLossFieldDisable();
    this.showDownloadButton();
  }

  private setTotalLossFieldDisable(){
    if(this.saveButton){
      this.TotalLoss.controls['adjustorName1'].disable();
      this.TotalLoss.controls['surveyDate1'].disable();
      this.TotalLoss.controls['totalLossAmount1'].disable();
      this.TotalLoss.controls['adjustorName2'].disable();
      this.TotalLoss.controls['surveyDate2'].disable();
      this.TotalLoss.controls['totalLossAmount2'].disable();
      this.TotalLoss.controls['estimatedTotalLossAmount'].disable();
      this.TotalLoss.controls['reasonForTotalLoss'].disable();
      this.TotalLoss.controls['salvageAmount'].disable();
      this.TotalLoss.controls['salvageBuyerName'].disable();
      this.TotalLoss.controls['salvageSellerName'].disable();
    }
  }

  isFilePresent=false;

  checkForTotalLoss(items: Field[]): void {
    this.isTotalLossPresent = items.findIndex((dt) => dt.fieldType === 'checkbox') !== -1;
    this.checkTotalLossSection(items);
    this.fileFlag = true;
     this.getFileUploadInput(items.find((item: Field) => item.fieldType === 'file'));
    this.isFilePresent = items.findIndex((dt) => dt.fieldType === 'file') !== -1;
  }
  checkTotalLossSection(items: Field[]) {
    const ldtotlss= items.find((dt) => dt.fieldName === 'ldIsTotalLoss');
    if(ldtotlss!==undefined && ldtotlss.value!==null && ldtotlss.value === 'true'){
      this.showLossDetailsTotalLoss = true;
    }
    let srtotlss= items.find((dt) => dt.fieldName === 'srTotalLoss');
    if(srtotlss!==undefined && srtotlss.value!==null && srtotlss.value === 'true'){
      this.showsurveyReportTotalLoss = true;
    }
    this.reportLossData.metaData.sectionList.forEach((xx:Section)=>{
      xx.sectionList.forEach(subSec=>{
        const surveyReportTotalLoss2 = subSec.fieldList.find((dt) => dt.fieldName === "srTotalLoss");
        if(surveyReportTotalLoss2 != undefined){
          if(surveyReportTotalLoss2.value == "true"){
            this.showsurveyReportTotalLoss = true;
            if(this.name=='Survey Report'||this.name=='Recovery Details'){
              this.isTotalLossPresent =true;
              srtotlss=surveyReportTotalLoss2;
            }else{
              this.isTotalLossPresent=false
            }
            return;
          }
        }
      })
    })

    this.showTotalLossColumns = false;
    if(ldtotlss!==undefined && this.showLossDetailsTotalLoss){
      this.showTotalLossColumns = true;
    }
    if(srtotlss!==undefined && this.showsurveyReportTotalLoss){
      this.showTotalLossColumns = true;
    }
  }

  TotalLoss = new FormGroup({
    adjustorName1: new FormControl("", [Validators.required]),
    surveyDate1: new FormControl("", [Validators.required]),
    totalLossAmount1: new FormControl("", [Validators.required]),
    adjustorName2: new FormControl("", [Validators.required]),
    surveyDate2: new FormControl("", [Validators.required]),
    totalLossAmount2: new FormControl("", [Validators.required]),
    reasonForTotalLoss: new FormControl("", [Validators.required]),
    estimatedTotalLossAmount: new FormControl("", [Validators.required]),
    salvageSellerName: new FormControl("", [Validators.required]),
    salvageAmount: new FormControl("", [Validators.required]),
    salvageBuyerName: new FormControl("", [Validators.required])
  });

  saveTotalLossDetails() {
    const totalLossDto = new TotalLoss();

    totalLossDto.claimId = this.reportLossData.claimId
    totalLossDto.claimIdentity = this.reportLossData.claimIdentity,

    // totalLossDto.adjustorName1 = this.TotalLoss.value.adjustorName1
    // totalLossDto.adjustorName2 = this.TotalLoss.value.adjustorName2
    // totalLossDto.estimatedTotalLossAmount = this.removeCommas2(this.TotalLoss.value.estimatedTotalLossAmount)
    // totalLossDto.reasonForTotalLoss = this.TotalLoss.value.reasonForTotalLoss
    // totalLossDto.salvageAmount = this.removeCommas2(this.TotalLoss.value.salvageAmount)
    // totalLossDto.salvageBuyerName = this.TotalLoss.value.salvageBuyerName
    // totalLossDto.salvageSellerName = this.TotalLoss.value.salvageSellerName
    // totalLossDto.surveyDate1 = this.TotalLoss.value.surveyDate1
    // totalLossDto.surveyDate2 = this.TotalLoss.value.surveyDate2
    // totalLossDto.totalLossAmount1 = this.removeCommas2(this.TotalLoss.value.totalLossAmount1)
    // totalLossDto.totalLossAmount2 = this.removeCommas2(this.TotalLoss.value.totalLossAmount2)


    totalLossDto.adjustorName1 = this.TotalLoss.get('adjustorName1').value;
    totalLossDto.adjustorName2 = this.TotalLoss.get('adjustorName2').value ;
    totalLossDto.estimatedTotalLossAmount = this.removeCommas2(this.TotalLoss.get('estimatedTotalLossAmount').value)
    totalLossDto.reasonForTotalLoss =this.TotalLoss.get('reasonForTotalLoss').value;
    totalLossDto.salvageAmount = this.removeCommas2(this.TotalLoss.get('salvageAmount').value? this.TotalLoss.get('salvageAmount').value:"0");
    totalLossDto.salvageBuyerName = this.TotalLoss.get('salvageBuyerName').value;
    totalLossDto.salvageSellerName = this.TotalLoss.get('salvageSellerName').value;
    totalLossDto.surveyDate1 = this.TotalLoss.get('surveyDate1').value;
    totalLossDto.surveyDate2 = this.TotalLoss.get('surveyDate2').value;
    totalLossDto.totalLossAmount1 = this.removeCommas2(this.TotalLoss.get('totalLossAmount1').value)
    totalLossDto.totalLossAmount2 = this.removeCommas2(this.TotalLoss.get('totalLossAmount2').value)


    if (this.TotalLoss) {
      this.dataservice.sendTotalLossDetails(totalLossDto).subscribe((response)=>{
        if (response) {
          this.toaster.success(this.translate.instant("Toaster_Message.Totalloss_detail_save"));
        }
      })
    }
  }

  showSaveButton(){
    if(this.status===ReportLossStatus.claimSettled){
      this.isClaimSettled = true;
    }

    if (this.status===ReportLossStatus.dispute) {
       this.saveButton = true;
    }

    if(this.status===ReportLossStatus.draft&&ReportLossConst.STATUS.DRAFT.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.DRAFT.ISRECEIVABLE===this.isReceivableFromCommon){
      return false;
    }
    if(!this.status){
      return false
    }

    if(this.status===ReportLossStatus.notificationReceived&&ReportLossConst.STATUS.NOTIFICATION_RECEIVED.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.NOTIFICATION_RECEIVED.ISRECEIVABLE===this.isReceivableFromCommon){
      return false;
    }

    if((this.status===ReportLossStatus.notificationAccepted||this.lastStatus===ReportLossStatus.movedToInspection)&&ReportLossConst.STATUS.NOTIFICATION_ACCEPTED.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.NOTIFICATION_ACCEPTED.ISRECEIVABLE===this.isReceivableFromCommon){
      return false;
    }


    if(this.status===ReportLossStatus.movedToInspection&&ReportLossConst.STATUS.MOVED_TO_INSPECTION.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.MOVED_TO_INSPECTION.ISRECEIVABLE===this.isReceivableFromCommon){
      return false;
    }
    if(this.status===ReportLossStatus.underInspection&&ReportLossConst.STATUS.UNDER_INSPECTION.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.UNDER_INSPECTION.ISRECEIVABLE===this.isReceivableFromCommon){
      return false;
    }
    if(this.status===ReportLossStatus.receivedLiabality&&ReportLossConst.STATUS.RECEIVED_LIABILITY.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.RECEIVED_LIABILITY.ISRECEIVABLE===this.isReceivableFromCommon){
      return false;
    }
    if(this.status===ReportLossStatus.liabilityAccepted&&ReportLossConst.STATUS.LIABILITY_ACCEPTED.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.LIABILITY_ACCEPTED.ISRECEIVABLE===this.isReceivableFromCommon){
      return false;
    }
    //NEGATIVE FLOW

    if(this.status===ReportLossStatus.receiveRejectedNotification||this.status===ReportLossStatus.needMoreDetails&&this.lastStatus===ReportLossStatus.notificationReceived&&ReportLossConst.STATUS.DRAFT.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.DRAFT.ISRECEIVABLE===this.isReceivableFromCommon){
      return false;
    }

    if(this.status===ReportLossStatus.detailsProvided&&this.lastStatus===ReportLossStatus.notificationReceived&&ReportLossConst.STATUS.NOTIFICATION_RECEIVED.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.NOTIFICATION_RECEIVED.ISRECEIVABLE===this.isReceivableFromCommon){
      return false;
    }

    if(this.status===ReportLossStatus.needMoreDetails&&this.lastStatus===ReportLossStatus.confirmLiability&&ReportLossConst.STATUS.LIABILITY_ACCEPTED.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.LIABILITY_ACCEPTED.ISRECEIVABLE===this.isReceivableFromCommon){
      return false;
    }

    if(this.status===ReportLossStatus.needMoreDetails&&this.lastStatus===ReportLossStatus.receivedLiabality&&ReportLossConst.STATUS.MOVED_TO_INSPECTION.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.MOVED_TO_INSPECTION.ISRECEIVABLE===this.isReceivableFromCommon){
      return false;
    }

    if(this.status===ReportLossStatus.disputeReopen&&this.lastStatus===ReportLossStatus.receivedLiabality&&ReportLossConst.STATUS.RECEIVED_LIABILITY_DISPUTE_REOPEN.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.RECEIVED_LIABILITY_DISPUTE_REOPEN.ISRECEIVABLE===this.isReceivableFromCommon){
      return false;
    }
    //tottalLoss
    if(this.status===ReportLossStatus.totalLossInitiated&&!this.totalLossType&&ReportLossConst.STATUS.DRAFT.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.DRAFT.ISRECEIVABLE===this.isReceivableFromCommon){
      return false;
    }
    if(this.status===ReportLossStatus.surveyAssigned&&this.totalLossType&&ReportLossConst.STATUS.SURVEYOR_ASSIGNED.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.SURVEYOR_ASSIGNED.ISRECEIVABLE===this.isReceivableFromCommon){
      return false;
    }
    if((this.status===ReportLossStatus.disputeReopen||this.status===ReportLossStatus.needMoreDetails)&&this.lastStatus===ReportLossStatus.confirmLiability&&ReportLossConst.STATUS.RECOVERY_DTLS.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.RECOVERY_DTLS.ISRECEIVABLE===this.isReceivableFromCommon){
      return false;
    }
    if((this.status===ReportLossStatus.disputeReopen||this.status===ReportLossStatus.needMoreDetails)&&this.lastStatus===ReportLossStatus.debitNoteGenerated&&ReportLossConst.STATUS.RECOVERY_DTLS.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.RECOVERY_DTLS.ISRECEIVABLE===this.isReceivableFromCommon){
      return false;
    }
    if((this.status===ReportLossStatus.disputeReopen||this.status===ReportLossStatus.dispute||this.status===ReportLossStatus.needMoreDetails)&&this.lastStatus===ReportLossStatus.liabilityReview&&ReportLossConst.STATUS.RECOVERY_DTLS.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.RECOVERY_DTLS.ISRECEIVABLE===this.isReceivableFromCommon){
      return false;
    }
    if (((this.status === ReportLossStatus.needMoreDetails || this.status === ReportLossStatus.disputeReopen) && (this.lastStatus === ReportLossStatus.debitNoteGenerated || this.lastStatus === ReportLossStatus.totalLossAccepted || this.lastStatus === ReportLossStatus.surveyAssigned)) && ReportLossConst.STATUS.DEBIT_NOTE_NEED_MORE_INFO.ENABLED_CARDS.includes(this.name as StageNameReportLoss) && ReportLossConst.STATUS.DEBIT_NOTE_NEED_MORE_INFO.ISRECEIVABLE === this.isReceivableFromCommon) {
      return false;
    }
    if((this.status===ReportLossStatus.totalLossInitiated)&&ReportLossConst.STATUS.TOTALLOSS_INIATED_RECEIVABLE.ENABLED_CARDS.includes(this.name as StageNameReportLoss) && ReportLossConst.STATUS.TOTALLOSS_INIATED_RECEIVABLE.ISRECEIVABLE === this.isReceivableFromCommon){
      return false;
    }
     // Reserve Review Dispute Reopen Flow
     if(this.status===ReportLossStatus.liabilityAccepted&&this.totalLossType&&ReportLossConst.STATUS.RESERVE_REVIEW_DISPUTE_REPOEN.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.RESERVE_REVIEW_DISPUTE_REPOEN.ISRECEIVABLE===this.isReceivableFromCommon){
      return false;
    }
    // Total Loss Initiated Recovery Details DisputeReopen Or NeedMore Details
    if((this.status===ReportLossStatus.disputeReopen||this.status===ReportLossStatus.needMoreDetails)&&this.lastStatus===ReportLossStatus.totalLossInitiated&&ReportLossConst.STATUS.TOTALLOSS_INIATED_NEED_INFO_REOPEN.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.TOTALLOSS_INIATED_NEED_INFO_REOPEN.ISRECEIVABLE===this.isReceivableFromCommon){
      return false;
    }
     // TotalLoss Intiated  Details Provide
     if((this.status===ReportLossStatus.detailsProvided && this.lastStatus===ReportLossStatus.totalLossInitiated && this.totalLossType )&&ReportLossConst.STATUS.RESERVE_REVIEW_DISPUTE_REPOEN.ENABLED_CARDS.includes(this.name as StageNameReportLoss)&&ReportLossConst.STATUS.TOTALLOSS_INIATED_SURVEY_REPORT_DETAILS_PROVIDED.ISRECEIVABLE===this.isReceivableFromCommon){
      return false;
    }
  }


  showDownloadAndPreviewButton(){
    const statuslst:String[]=[];
   statuslst.push(ReportLossStatus.debitNoteGenerated);
   statuslst.push(ReportLossStatus.confirmLiability);
   statuslst.push(ReportLossStatus.claimSettled);


    if(statuslst.includes(this.status) || statuslst.includes(this.lastStatus)){
      this.downloadAndPreviewButton = true;
    }
  }



  returnreportloss(myData: Field[]): void {
    // this.onInput();
    myData.forEach((dt) =>{
      if(dt.fieldName=="sdSurveyDueDate"){
        dt.value = new Date(dt.value).toISOString();
      }
      if(dt.fieldName=="ldDateOfLoss" || dt.fieldName=="inPurchaseDate"){
        const moment = require('moment');
        let dateWithEndTime = null;
        try {
          const parsedDate = moment.utc(dt.value);
          if (parsedDate.isValid()) {
            dateWithEndTime = parsedDate.startOf("day").format("YYYY-MM-DDTHH:mm:ss") + 'Z';
          }
        } catch (error) {
          console.error('Invalid date:', error);
        }
        dt.value = dateWithEndTime;
      }
    })

    this.checkFilled(myData);
    if((this.name === "Loss Details" || this.name === "Survey Report"||this.name==="Recovery Details") && this.checkBoxTick){
      this.saveTotalLossDetails();
    }
    let fileFieldValue = null;
    myData.forEach((field: Field) => {
      if(field.fieldType === 'file') {
        fileFieldValue = field.value === '' ? null : field.value;
      }
    });

    const fileData: FileUploadDTO = {
      fileList: this.fileList,
      referenceId: fileFieldValue,
      fieldName: 'group'  // represents multiple file uploads for report loss
    };
    let removedFileList = [];
    if(!this.fileRemoved){
      this.fileViewList.filter((file: any) => {
        if(file.isRemoved){
          file = null;
        }
      });
    }
    if(this.fileViewList && this.fileViewList.length > 0) {
      const list = this.fileViewList.filter((file: any) => file.isRemoved);
      removedFileList = list.map((f: any) => f.id);
    }
    this.selectedItemFieldList = myData;
    this.selectedFieldListItems.emit({
      fileData,
      sectionName: this.name,
      data: this.selectedItemFieldList,
      isAllDeleted: this.fileViewList?.length === removedFileList?.length,
      removedFileList
    });
    this.dataservice.isOpenStage(false);
    const curIndex = this.sectionList.findIndex((ele) => ele.sectionName === this.name);
    this.sectionList[curIndex].isExpanded = false;
    if(curIndex < this.sectionList.length - 1) {
      this.sectionList[curIndex + 1].isExpanded = true;
    }
    this.fileRemoved = false;
    this.fileList  = null;
    this.fileRemoved = false;
    // this.navigateBack();
  }

  sendValue:any;
  claimAmount:number;
  indexNumber:number;


  // updateSurveyAmtInSurveyReport(item:any){
  //   // this.reportLossData.metaData.sectionList.forEach(element => {
  //   //     element
  //   // });
  //   if(item.sectionName === 'Survey Report'){
  //     this.updateSurveyAmount(item.fieldList);
  //     this.updateSurveyorAmount(item.fieldList);
  //   }
  // }

  showfiles(items: any):boolean{
    if(items.fieldType === 'file')
      return true;
    else
      return false;
  }

  sendData(myData: any,data:any){

    this.updateSurveyAmount(myData);
    this.updateClaimAmount(myData);
    this.updateSurveyorAmount(myData)
    this.sendValue = myData;
    // this.saveTotalLossDetails();
    // this.getChildDropDowValue(myData,data);

  }
  updateSurveyAmtInSurveyReport(item:any){
    if(item.sectionName === 'Survey Report'||item.sectionName==='Recovery Details'){
      this.updateSurveyAmount(item.fieldList);
      this.updateSurveyorAmount(item.fieldList);
    }
  }
  updateSurveyAmount(myData): void {
    if(!myData) {
      return;
    }
    this.tpSurveyAmount = 0.000;
    if(this.TotalLoss.controls["salvageSellerName"].value !== this.reportLossData.insurerName){
      if(this.amount1 != null || this.amount1 != undefined){
        this.tpSurveyAmount = this.tpSurveyAmount + Number(this.amount1 + '');
      }
      if(this.amount2 != null || this.amount2 != undefined){
        this.tpSurveyAmount = this.rdClaimAmount;
      }
    }else{
      if(this.amount1 != null || this.amount1 != undefined){
        this.tpSurveyAmount = this.tpSurveyAmount + Number(this.amount1 + '');
      }
      if(this.amount2 != null || this.amount2 != undefined){
        this.tpSurveyAmount = this.rdClaimAmount;
      }

      if(this.salvageTotal != null || this.salvageTotal != undefined){
        this.tpSurveyAmount = this.tpSurveyAmount - Number(this.salvageTotal+'')
      }
    }
    if (myData[0].entityName==='SurveyReport'||myData[0].entityName==='RecoveryDetails') {
      this.reportLossData.metaData.sectionList.find(item=>item.sectionName==ReportLossStageEnum.claimInspectionStage).sectionList.find(item=>item.sectionName==StageNameReportLoss.surveyReport).fieldList.forEach((element: Field) => {
        if ((element.fieldName === 'srSpareParts' || element.fieldName === 'srLabourCost') && element.value!=null) {
          this.tpSurveyAmount = this.tpSurveyAmount + Number(element.value + '');
        }
        if (element.fieldName==='srSurveyAmount') {
          element.value = this.tpSurveyAmount.toFixed(3);
        }
      });
      this.reportLossData.metaData.sectionList.find(item=>item.sectionName==ReportLossStageEnum.liabilityConfirmationStage).sectionList.find(item=>item.sectionName === StageNameReportLoss.recoveryDetails).fieldList.forEach((element: Field) => {
        if (element.fieldName ==='rdClaimAmount' && (element.value === undefined || element.value === null || +element.value === 0)) {
          element.value = this.tpSurveyAmount.toFixed(3);
        }
      });
      this.reportLossData.metaData.sectionList.find(item=>item.sectionName==ReportLossStageEnum.liabilityConfirmationStage).sectionList.find(item=>item.sectionName === StageNameReportLoss.reserveReview).fieldList.forEach((element: Field) => {
        if (element.fieldName ==='rrClaimAmount') {
          element.value = this.tpSurveyAmount.toFixed(3);
        }
      });
    }
    // this.tpSurveyAmount = 0.000;
    // if(this.TotalLoss.controls["salvageSellerName"].value !== this.reportLossData.insurerName){
    //   if(this.amount1 != null || this.amount1 != undefined){
    //     this.tpSurveyAmount = this.tpSurveyAmount + Number(this.amount1 + '');
    //   }
    // }else{
    //   if(this.amount1 != null || this.amount1 != undefined){
    //     this.tpSurveyAmount = this.tpSurveyAmount + Number(this.amount1 + '');
    //   }
    //   if(this.salvageTotal != null || this.salvageTotal != undefined){
    //     this.tpSurveyAmount = this.tpSurveyAmount - Number(this.salvageTotal+'')
    //   }
    // }
    // // if (myData[0]?.entityName==='SurveyReport') {
    // //   myData.forEach(element => {
    // //     if ((element.fieldName === 'srSpareParts' || element.fieldName === 'srLabourCost') && element.value!=null) {
    // //       this.tpSurveyAmount = this.tpSurveyAmount + Number(element.value + '');
    // //     }
    // //     if (element.fieldName==='srSurveyAmount') {
    // //       element.value = this.tpSurveyAmount.toFixed(3);
    // //     }
    // //   });
    // // }

    // if (myData[0]?.entityName==='SurveyReport'||myData[0]?.entityName==='RecoveryDetails') {
    //   this.reportLossData.metaData.sectionList.find(item=>item.sectionName== ReportLossStageEnum.claimInspectionStage).sectionList.find(item=>item.sectionName==StageNameReportLoss.surveyReport).fieldList.forEach((element: Field) => {
    //     if ((element.fieldName === 'srSpareParts' || element.fieldName === 'srLabourCost') && element.value!=null) {
    //       this.tpSurveyAmount = this.tpSurveyAmount + Number(element.value + '');
    //     }
    //     if (element.fieldName==='srSurveyAmount') {
    //       element.value = this.tpSurveyAmount.toFixed(3);
    //     }
    //   });
    // }


  }
  getTotalLossAmount(){
    this.dataservice.getTotalLossDetails(this.reportLossData.claimIdentity).subscribe((response)=>{
      if(response){

        this.amount1 = response['content'].totalLossAmount1;
        this.salvageTotal = response['content'].salvageAmount;
        // this.updateSurveyAmount(this.sectionList);
        // this.updateSurveyorAmount(this.sectionList);
      }
    });
  }
  buttonShowOrNot(items: Field){
    if(this.isTotalLossInitiated){
      this.showSpareAmt = (items.fieldName === "rdSpareParts" || items.fieldName === "rdLabourCost");
    }
    if(items.fieldName === "sdSurveyAllocationDate" || items.fieldName === "sdSurveyDueDate"){
      this.minimumDate = null ;
   }
    this.showSurveyAmount = (items.fieldName === "srSurveyAmount");
    this.disableSurveyDueDate = (items.fieldName === "sdSurveyDueDate")
    }
   updateClaimAmount(myData){
     if(!myData) {
      return;
    }
    if (myData[0].entityName==='RecoveryDetails') {
      this.claimAmount = 0.000;
      myData.forEach(element => {
        if (element.fieldName!=='rdTPSurveyAmount' && element.fieldName!=='rdClaimAmount' && element.value) {
          this.claimAmount = Number(this.claimAmount) + Number(element.value+'');
        }
        if(this.reportLossData.totalLossType){
          if(element.fieldName=="rdTPSurveyAmount"){
            this.claimAmount=Number(this.claimAmount)+Number(element.value+'');
          }
        }
        if (element.fieldName==='rdClaimAmount') {
          element.value = this.claimAmount.toFixed(3);
        }
      });

    }
  }

surveyorAmount:number;

  updateSurveyorAmount(myData){
    this.surveyorAmount = 0.000;
    if(!this.isAtFaultInitiated){
      if(this.amount1 != null || this.amount1 != undefined){
        this.surveyorAmount = this.surveyorAmount + Number(this.amount1 + '');
      }
    }else{
      if(this.amount1 != null || this.amount1 != undefined){
        this.surveyorAmount = this.surveyorAmount + Number(this.amount1 + '');
      }
      if(this.salvageTotal != null || this.salvageTotal != undefined){
        this.surveyorAmount = this.surveyorAmount - Number(this.salvageTotal+'')
      }
    }
    if (myData[0]?.entityName==='RecoveryDetails') {
      myData.forEach(element => {
        if ((element.fieldName==='rdSpareParts' || element.fieldName==='rdLabourCost') && element.value!=null) {
          this.surveyorAmount= this.surveyorAmount + Number(element.value+'');
        }
        if (element.fieldName==='srSurveyAmount') {
          element.value = this.surveyorAmount.toFixed(3);
        }
      });
    }

  }

  inputData(){
    
    let totAmt=0;
    if (this.differenceBtwDate()<=3) {
      if (this.amount1!==null && this.amount1!==undefined) {
        totAmt = this.amount1
        this.totalAmount = totAmt
      }
    }else{
   
      if (this.amount2 > this.amount1) {
        totAmt = ((this.amount2 - this.amount1) / 100) * 75 + this.amount1
        this.rdClaimAmount = totAmt;
      }

      else if (this.amount1 !== null && this.amount1 !== undefined) {
        totAmt = this.amount1
      }


      if (totAmt >= 0) {
        this.totalAmount = totAmt;
      }
     
      if(this.salvageTotal){
        if(this.TotalLoss.controls["salvageSellerName"].value === this.reportLossData.insurerName){
          totAmt = this.amount1 -this.salvageTotal;
        }
      }
    }

    this.reportLossData.metaData.sectionList.find(item=>item.sectionName== ReportLossStageEnum.claimInspectionStage).sectionList.find(item=>item.sectionName==StageNameReportLoss.surveyReport).fieldList.forEach((field: Field) => {
      if(field.fieldName === 'srSurveyAmount' || field.fieldName === 'rdTPSurveyAmount' || field.fieldName === 'rrTPSurveyAmount') {
        if(this.totalAmount){
        field.value = Number(totAmt).toFixed(3);
        }
      }
    });

  }

  differenceBtwDate(){
    const currentDate = new Date().getTime()/86400000;
    const purchaseDate = new Date(this.dateOfPurchase).getTime()/86400000
    return ((currentDate-purchaseDate)/365.25);
  }


  // refreshPageInTpDetails(name:string){

  // }



  getDate(dates: any) {
    const date: Date = new Date();
    const currentDate = this.datepipe.transform(date, 'yyyy-MM-dd');
  }

  // navigateBack(): void {
  //   this.showCardView.emit();
  // }

  //------------------------ Dynamic field type starts--------------------------------

  getTextInput(items: Field) {
    if (items.fieldType === 'text') {
      return true;
    }
    return false;
  }
  getStringInput(items: Field) {
    if (items.fieldType === 'String') {
      return true;
    }
    return false;
  }

  getDateInput(items: Field) {
    if (items.fieldType === 'pDate' || items.fieldType === 'fDate') {
      this.minimumDate = new Date();
      this.buttonShowOrNot(items);
      return true;
    }
    return false;
  }


  getDropdownInput(items: Field) {
    if (items.fieldType === 'Dropdown' || items.fieldType === 'MultiSelect') {
        return true;
    }else{
      return false;
    }

  }

  addDays(date: Date, days: number): Date {
    date.setDate(date.getDate() + days);
    return date;
}
  chooseChildDate(data:any, event){
    if(data.fieldName === "sdSurveyAllocationDate"){
      this.minDate = new Date(data.value);
      if(this.surveyDueHours !== undefined && this.surveyDueHours!== null && Number(this.surveyDueHours)){
        this.dueDate = Number(this.surveyDueHours)/24;
        this.showDate = this.addDays(this.minDate,this.dueDate)
      }
      this.showDate1 = this.datepipe.transform(this.showDate, 'yyyy-MM-dd')
      if(this.showDate1 !== undefined && this.showDate1!==null){

        // this.reportLossData.metaData.sectionList.forEach((xx:Section)=>{
        //   xx.sectionList.forEach(subSec=>{
        //     subSec.fieldList.forEach((dt:Field) =>{
        //       if(dt.fieldName=="sdSurveyDueDate"){
        //         dt.value =  this.showDate1;
        //       }
        //     })
        //   })
        // });

        this.sectionList.forEach((xx:Section)=>{
          xx.fieldList.forEach((dt:Field) =>{
            if(dt.fieldName=="sdSurveyDueDate"){
              dt.value =  this.showDate1;
            }
          })
        });
      }


    }else{
      this.minDate = new Date();
    }
  }

    getChildDropDowValue(metaData:any,data:any){
      let childFieldName;
      const childFieldObject = this.parentFieldMap.find((data2) => data2.parentFieldName === data.fieldName);
       if(childFieldObject) {
        childFieldName = childFieldObject.childFieldName;
       } else {
        childFieldName = '';
       }
    // const childFieldName = this.dropDownService.getChildFieldName(data.fieldName);
    const childmetaData = this.selectedFieldList.find((dt) => dt.fieldName === childFieldName);

      this.buildDropDownValues(childFieldName,childmetaData,data.value);
      if(data.fieldName === GarageFieldEnum.garagename){
        const subchild = this.selectedFieldList.find((dt) => dt.fieldName === GarageFieldEnum.garagecontact);
        const location = this.selectedFieldList.find((dt) => dt.fieldName === GarageFieldEnum.garagrlocation);

        this.setContactDetails(subchild,location,data.value)
      }

   }
   setContactDetails(subchild:Field,location:Field,garageName:string){

    this.dropDownService.getContactDetails(garageName).subscribe(data=>{
      if(data){
        subchild.value= data['content'][0];
        location.value=data['content'][1];
      }else{
        subchild.value='';
      }
    })

   }

   buildDropDownValues(fieldName:string, metaData:Field, value:string){
    if(fieldName && fieldName != '' ){

        this.dropDownService.getOption(metaData.fieldId,value,null).subscribe(data=>{
          if (data) {
            if(metaData.fieldName == "tpName"){
               const currentCompanyName  = sessionStorage.getItem("companyName");
              const index: number = data.indexOf(currentCompanyName);
              if (index !== -1) {
                data.splice(index, 1);
            }
              metaData.dropDownList = data;
            }else{
              metaData.dropDownList = data;
            }
          }
        })
    }
   }

  getNumberInput(items: Field) {
    if (items.fieldType === 'Long' || items.fieldType === 'Double') {
      this.buttonShowOrNot(items);
      return true;
    }
    return false;
  }

  fileFlag = true;

  getFileUploadInput(items: Field) {



    if(!this.fileRemoved){


    this.field = items;
    if (items && items.fieldType === 'file') {

      if(items.value !== undefined && items.value !== null && !Number.isNaN(parseInt(items.value)) && this.fileFlag) {
        this.fileFlag = false;
        this.fileUploadService.getFileList(parseInt(items.value)).subscribe((response: any) => {
          const data = response.content;
          this.fileViewList = [];
          if(data && data.length > 0) {
            data.forEach((file: {id: number, url: string}, index: number) => {
              this.fileViewList.push({
                id: file.id,
                name: file.url.slice(56),
                url: file.url,
                isRemoved: false
              });
            });
          }
        });
      }
      return true;

  }
    return false;
  }

  }

  getCheckboxInput(items: Field) {
    if (items.fieldType === 'checkbox'|| items.fieldType === 'Boolean'
    || items.fieldType === 'RadioButton'|| items.fieldType === 'toggle') {
      return true;
    }
    return false;
  }

  getDownloadInput(items:Field){
    if (items.fieldType==="download") {
      if (items.defaultValues !== null) {
        this.dropdownlist = items.defaultValues.split(',');

      }
      return true;
    }
    return false;
  }

  removeFile(index: number): void {
    this.fileRemoved = true
    this.fileViewList[index].isRemoved = true;
    // this.reportLossData?.metaData.sectionList[0].sectionList[3].fieldList.find((field: Field) => {
    //   if (field.fieldType === 'file') {
    //     field.fileName = null;
    //     field.pdfSrc = null;
    //     field.value = null;
    //   }
    // });
  }

  getDownloadFile(file: any): void {
    this.fileUploadService.downloadFile(file.url).subscribe((response) => {
      const blob = new Blob([response]);
      const fileURL = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = fileURL;
      a.target = '_blank';
      a.download = file.url.substring(file.url.lastIndexOf("/") + 1);
      document.body.appendChild(a);
      a.click();
    });
  }
  getPreviewFile(dataUrl: string): void {
    this.fileUploadService.downloadFile(dataUrl).subscribe((response) => {
      const blob = new Blob([response]);
      const fileURL = URL.createObjectURL(blob);
      this.pdfSrc = fileURL;
    });
  }
  //------------------------ Dynamic field type ends--------------------------------

  // ------------------file upload starts------------------------

  fileList: File[] = null; // Variable to store file

  // On file Select

  filemap = new Map<string,string>([
    [ "pdf", "assets/file/pdf.svg" ],
    [ "xlsx", "assets/file/xlsx.svg" ],
    [ "xls", "assets/file/xls.svg" ],
    [ "doc", "assets/file/doc.svg" ],
     [ "docx", "assets/file/docx.svg" ],
     [ "img", "assets/file/img.svg" ],
     [ "jpeg", "assets/file/jpeg.svg"],
     [ "jpg", "assets/file/jpg.svg" ],
     [ "png", "assets/file/png.svg"],
     [ "svg", "assets/file/svg.svg"]
]);
filesize:number;
fileboolean=false;
file='';
  onChange(event, data: Field) {
    this.fileList = event.target.files;
    this.file = event.target.files[0].type;
    data.fileName = this.fileList[this.fileList.length - 1].name;
    const totalSize = this.getTotalFileSize(); // Get total size in bytes
    this.filesize = Math.ceil(totalSize / 1048576);
    const maxSizeMB = 20; // 20MB
    if (this.filesize < maxSizeMB)
   {
    if(this.file =="application/pdf" ||
    this.file =="application/vnd.ms-excel"  ||
    this.file =="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
    this.file =="application/msword" ||
    this.file =="application/vnd.ms-excel" ||
    this.file =="application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
    this.file =="image/png" ||
    this.file=="image/jpeg" ||
    this.file=="image/jpg" ||
    this.file=="image/svg" ||
    this.file=="image/svg+xml")
    {
      this.fileboolean=true;
    data.fileName = this.fileList[this.fileList.length - 1].name;
    const str = data.fileName.split(".");      // Split the string using dot as separator
     const filename = str.pop();
     for (let key of this.filemap.keys()) {
      if(key===filename){
        this.fileType=this.filemap.get(key).toString();
      }

    }
    if(this.fileType===null||this.fileType===undefined){
      this.fileType="assets/file/file.svg";
    }

    if(this.file == "image/png" || this.file == "image/jpeg" ||
    this.file == "image/jpg"  || this.file == "image/svg+xml"){
         data.mimeType = MimeTypeEnum.IMAGE;
          const reader = new FileReader();
          reader.onload = (event : any) => {
            data.pdfSrc = event.target.result;
          }
          reader.readAsDataURL(this.fileList[0]);
  }
  else if(this.file == "application/pdf"){
       data.mimeType = MimeTypeEnum.PDF;
      if (typeof FileReader !== 'undefined') {
            let reader = new FileReader();
            reader.onload = (e: any) => {
              data.pdfSrc = e.target.result;
            };
            reader.readAsArrayBuffer(this.fileList[0]);
          }
    }
  }else{
    this.fileboolean=false;
    this.fileList = null;
    this.toaster.error(this.translate.instant("Toaster_Message.Invalid_file_format"));
    this.hiddenInput.nativeElement.value = null;
    this.hiddenInput.nativeElement.click();
  }

  }
  else{
    this.fileboolean=false;
    this.fileList =null;
    this.toaster.error(this.translate.instant("Toaster_Message.Upload_file_size"));
  }
  }
  getTotalFileSize(): number {
    let totalSize = 0;
    for (const file of this.fileList) {
      totalSize += file.size;
    }
    return totalSize;
  }


  // ------------------file upload ends------------------------

  checkBox = false;
  checkBoxTick:boolean;
  totalLossResponse:TotalLoss;

  onCheckboxChange(item:Field,value:boolean) {
    if(item) {
      item.value = JSON.stringify(value);
    }
    if (item.value==='true') {
      this.checkBox = !this.checkBox;
      this.checkBoxTick = true;
      this.getTotalLoss();
      this.checkForTotalLoss(this.selectedFieldList);
    }else if(item.value==='false'){
      this.checkBoxTick = false;
      this.checkBox = !this.checkBox;
    }
    if (this.name === StageNameReportLoss.lossDetails) {
      if (item.value === 'true') {
        this.isLossDetailTotalLossView = true;
      } else {
        this.isLossDetailTotalLossView = false;
      }
    }
    else if (this.name == StageNameReportLoss.surveyReport) {
      if (item.value === 'true') {
        this.isSurveyReportView = true;
      } else {
        this.isSurveyReportView = false;
      }
    }

    this.surveyReportDisable(!this.checkBox);
  }


  getTotalLoss(){
    this.dataservice.getTotalLossDetails(this.reportLossData.claimIdentity).subscribe((response)=>{
      if (response) {
        this.totalLossResponse = response['content'];
        this.amount1 = this.removeCommas2(this.totalLossResponse.totalLossAmount1)
        this.amount2 = this.removeCommas2(this.totalLossResponse.totalLossAmount2)
        this.totalAmount = this.removeCommas2(this.totalLossResponse.estimatedTotalLossAmount)
        this.adjustor1 = this.totalLossResponse.adjustorName1
        this.adjustor2 = this.totalLossResponse.adjustorName2
        this.date1 = this.totalLossResponse.surveyDate1
        this.date2 = this.totalLossResponse.surveyDate2
        this.totalLossReason = this.totalLossResponse.reasonForTotalLoss
        this.nameOfSalvageSeller = this.totalLossResponse.salvageSellerName
        this.nameOfSalvageBuyer = this.totalLossResponse.salvageBuyerName
        this.salvageTotal = this.removeCommas2(this.totalLossResponse.salvageAmount)

        if(this.date1!=null){
          this.date1 =new Date(this.date1);
          }
          if(this.date2!=null){
            this.date2 =new Date(this.date2);

          }


          this.TotalLoss.controls['adjustorName1'].setValue(this.adjustor1);
          this.TotalLoss.controls['surveyDate1'].setValue(this.date1);
          this.TotalLoss.controls['totalLossAmount1'].setValue(this.amount1?this.amount1+"":"");
          this.TotalLoss.controls['adjustorName2'].setValue(this.adjustor2);
          this.TotalLoss.controls['surveyDate2'].setValue(this.date2);
          this.TotalLoss.controls['totalLossAmount2'].setValue((this.amount2?this.amount2+"":""));
          this.TotalLoss.controls['estimatedTotalLossAmount'].setValue(this.totalAmount?this.totalAmount+"":"");
          this.TotalLoss.controls['salvageSellerName'].setValue(this.nameOfSalvageSeller);
          this.TotalLoss.controls['salvageAmount'].setValue(this.salvageTotal?this.salvageTotal+"":"");
          this.TotalLoss.controls['salvageBuyerName'].setValue(this.nameOfSalvageBuyer);

      }
    })
  }

  backToList(){
    this.checkBox = !this.checkBox;
  }


  surveyReportDisable(isdisabled:boolean){
    const fieldArr:string[]=[];
    fieldArr.push("srLabourCost")
    fieldArr.push("srSpareParts")
    fieldArr.push("giDocument")
    fieldArr.push("giGarageInvoiceNo")
    fieldArr.push("srSurveyAmount")
    this.reportLossData.metaData.sectionList.find(item=>item.sectionName== ReportLossStageEnum.claimInspectionStage).sectionList.find(item=>item.sectionName==StageNameReportLoss.surveyReport).fieldList.forEach((field: Field) => {
        if (fieldArr.includes(field.fieldName)) {
          field.readOnly=isdisabled;
         if(field.fieldName=="srLabourCost"||field.fieldName=="srSpareParts" || field.fieldName =='srSurveyAmount'){
          field.value="";
         }
        }
      });

   }


  checkTPName(data) {
    return (!this.isReceivableFromCommon && data.fieldName === 'tpName');
  }

  checkShow() {
    return this.name !== StageNameReportLoss.reserveReview && this.name !== StageNameReportLoss.debitNote && this.name !== StageNameReportLoss.creditNote;
  }


  imageAssetList = [
    {
      image:"assets/reportloss/stage-icons/Insured Details.svg",
      title:"Insured Details"
    },
    {
      image:"assets/reportloss/stage-icons/TP Details.svg",
      title:"TP Details"
    },
    {
      image:"assets/reportloss/stage-icons/Loss Details.svg",
      title:"Loss Details"
    },
    {
      image:"assets/reportloss/stage-icons/Police Report.svg",
      title:"Police Report"
    },
    {
      image:"assets/reportloss/stage-icons/Garage Details.svg",
      title:"Garage Details"
    },
    {
      image:"assets/reportloss/stage-icons/Survey Details.svg",
      title:"Survey Details"
    },
    {
      image:"assets/reportloss/stage-icons/Survey Report.svg",
      title:"Survey Report"

    },
    {
      image:"assets/reportloss/stage-icons/Recovery Details.svg",
      title:"Recovery Details"
    },
    {
      image:"assets/reportloss/stage-icons/Reserve Review.svg",
      title:"Reserve Review"
    },
    {
      image:"assets/reportloss/stage-icons/Garage Invoice.svg",
      title:"Garage Invoice"
    },
    {
      image:"assets/reportloss/stage-icons/Debit Note.svg",
      title:"Debit Note"
    },
    {
      image:"assets/reportloss/stage-icons/Credit Note.svg",
      title:"Credit Note"
    }
  ]


  getImgs(item:Section)
  {
    let src='';
    const img = this.imageAssetList.find((img) => img.title === item.sectionName);
    if(img) {
          src = img.image;
        }
        return src;
  }


  closeIt=true;

  isNotificationStage = false;
    isInsuredDetails=false
    isThirdPartyDetails=false
    isLossDetails=false
    isPoliceDetails=false

    enableInspectionStage=false
    isGarageInfo=false
    isSurveyDetails=false
    isSurveyReport=true
    isRecoveryDetails=true

    enableLiabilityStage = true
    isReserveReview=true

    enableSettlementStage = true
    isGarageInvoice = true
    isDebitNote=true
    isCreditNote=true

    isFieldFilled:boolean[]=[];

    isTickEnable:boolean[];



    isInsuredDetailsFilled=true
    isThirdPartyDetailsFilled=true
    isLossDetailsFilled=true
    isPoliceDetailsFilled=true
    isGarageInfoFilled=true
    isSurveyDetailsFilled=true
    isSurveyReportFilled=true
    isRecoveryDetailsFilled=true
    isReserveReviewFilled=true
    isGarageInvoiceFilled = true
    isDebitNoteFilled=true
    isCreditNoteFilled=true

  percentageValues = [0, 0, 0, 0];

  changeButtonAccordingToStatus(){
    if(this.currentStatusValue(this.status)>=ReportLossStatusValue.notificationOpen){
      this.isInsuredDetails = false;
      this.isThirdPartyDetails = false;
      this.isLossDetails = false;
      this.isPoliceDetails = false;
      this.percentageValues[0] = 25;
      if(this.sectionList) {
        this.sectionList[0].isExpanded = true;
      }
      if(this.sectionList){
        this.selectedFieldList = this.sectionList[0].fieldList;
      }
      // this.isLockInsuredDetails = false;
      // this.isLockThirdPartyDetails = false;
      // this.isLockLossDetails = false;
      // this.isLockPoliceDetails = false;
  }
    if (this.currentStatusValue(this.status)>=ReportLossStatusValue.notificationAccepted) {
      this.isGarageInfo = false;
      this.isSurveyDetails = false;

      this.enableInspectionStage = false;
      this.percentageValues[0] = 25;
      if(this.sectionList){
        this.sectionList[4].isExpanded = true;
        this.selectedFieldList = this.sectionList[4].fieldList;
      }
      // this.isLockGarageInfo = false;
      // this.isLockSurveyDetails = false;
    } else {
      // this.isGarageInfo = true;
      // this.isSurveyDetails = true;
      // this.enableInspectionStage = true;
    }
     if(this.currentStatusValue(this.status)>=ReportLossStatusValue.garageAndSurveyDetails){
        this.isSurveyReport = false;
        this.percentageValues[1] = 37;
        if(this.sectionList){
          this.sectionList[6].isExpanded = true;
          this.selectedFieldList = this.sectionList[6].fieldList;
        }
        // this.isLockSurveyReport = false;
    } else {
      this.isSurveyReport = true;
    }
     if(this.currentStatusValue(this.status)>=ReportLossStatusValue.expensesAndDocumentUpdated){
        this.isRecoveryDetails = false;
        // this.isLockRecoveryDetails = false;
        this.percentageValues[1] = 50;
        if(this.sectionList){
          this.sectionList[7].isExpanded = true;
          this.selectedFieldList = this.sectionList[7].fieldList;
        }
    } else {
      this.isRecoveryDetails = true;
    }
    if(this.currentStatusValue(this.status)>=ReportLossStatusValue.liabilityReview){
      this.isReserveReview = false;
      this.percentageValues[2] = 63;
      if( this.sectionList){
        this.sectionList[8].isExpanded = true;
        this.selectedFieldList = this.sectionList[8].fieldList;
      }
      this.enableLiabilityStage=false;
      // this.isGarageInvoice = false;
      // this.isLockReserveReview = false;
  } else {
    this.isReserveReview = true;
    this.enableLiabilityStage = true;
  }
     if(this.currentStatusValue(this.status)>=ReportLossStatusValue.liabilityAccepted){
        this.isReserveReview = false;
        this.percentageValues[2] = 63;
        if( this.sectionList){
          this.sectionList[8].isExpanded = true;
          this.selectedFieldList = this.sectionList[8].fieldList;
        }
        this.enableLiabilityStage=false;
        this.isGarageInvoice = false;
        // this.isLockReserveReview = false;
    } else {
      // this.isReserveReview = true;
      this.enableLiabilityStage = true;
    }
     if(this.currentStatusValue(this.status)>=ReportLossStatusValue.confirmLiability){
        this.isGarageInvoice = false;
        this.isDebitNote = false;
        this.percentageValues[2] = 75;
        if( this.sectionList){
          this.sectionList[9].isExpanded = true;
          this.selectedFieldList = this.sectionList[9].fieldList;
        }
        this.enableSettlementStage = false;
        // this.isLockGarageInfo = false;
        // this.isLockDebitNote = false;
    } else {
      // this.isGarageInvoice = true;
      this.enableSettlementStage = true;
    }
     if(this.currentStatusValue(this.status)>=ReportLossStatusValue.claimSettled){
      this.isCreditNote = false;
      if(this.sectionList){
        this.sectionList[11].isExpanded = true;
        this.selectedFieldList = this.sectionList[11].fieldList;
      }
      this.percentageValues[3] = 100;
      // this.isLockCreditNote = false;
    }
    if (this.lastStatus === ReportLossStatus.receivedLiabality) {
      this.isGarageInfo = false;
      this.isSurveyDetails = false;
      this.isSurveyReport = false;
      this.percentageValues[2] = 75;
      if(this.sectionList){
        this.sectionList[4].isExpanded = true;
        this.selectedFieldList = this.sectionList[4].fieldList;
      }
    }
    if (this.lastStatus === ReportLossStatus.liabilityReview) {
      this.isGarageInfo = false;
      this.isSurveyDetails = false;
      this.isSurveyReport = false;
      this.isRecoveryDetails = false;
      this.percentageValues[2] = 75;
      if(this.sectionList){ 
        this.sectionList[4].isExpanded = true;
        this.selectedFieldList = this.sectionList[4].fieldList;
      }
    }

    if ((this.lastStatus === ReportLossStatus.debitNoteGenerated || this.lastStatus === ReportLossStatus.confirmLiability || this.lastStatus === ReportLossStatus.totalLossAccepted)) {
      this.isGarageInfo = false;
      this.isSurveyDetails = false;
      this.isSurveyReport = false;
      this.isRecoveryDetails = false;
      this.isReserveReview = false;
      this.isGarageInvoice = false;
      this.isDebitNote = false;
      // this.isCreditNote = false;
      this.percentageValues[3] = 87;
      if(this.sectionList){
        this.sectionList[7].isExpanded = true;
        this.selectedFieldList = this.sectionList[7].fieldList;
      }
    }
    if (this.totalLossType) {

      this.enableInspectionStage=false
      this.isGarageInfo=false
      this.isSurveyDetails=false
      this.isSurveyReport=false
      this.isRecoveryDetails = false
      this.isReserveReview = false
    }

      // knockForKnock
  if (this.currentStatusValue(this.status) == ReportLossStatusValue.knockForKnock) {
    this.isReserveReview = false;
    this.percentageValues[2] = 75;

  }

    this.isFieldFilled=[
      this.isInsuredDetails,
      this.isThirdPartyDetails,
      this.isLossDetails,
      this.isPoliceDetails,
      this.isGarageInfo,
      this.isSurveyDetails,
      this.isSurveyReport,
      this.isRecoveryDetails,
      this.isReserveReview,
      this.isGarageInvoice,
      this.isDebitNote,
      this.isCreditNote
    ]
    }

  currentStatusValue(currentStatus: string) {
    switch (currentStatus) {

      case ReportLossStatus.draft:
        return ReportLossStatusValue.draft;

      case ReportLossStatus.notificationOpen:
        return ReportLossStatusValue.notificationOpen;

      case ReportLossStatus.notificationReceived:
        return ReportLossStatusValue.notificationReceived;

      case ReportLossStatus.notificationAccepted:
        return ReportLossStatusValue.notificationAccepted;

      case ReportLossStatus.garageAndSurveyDetails:
        return ReportLossStatusValue.garageAndSurveyDetails;

      case ReportLossStatus.movedToInspection:
        return ReportLossStatusValue.movedToInspection;

      case ReportLossStatus.underInspection:
        return ReportLossStatusValue.underInspection;

      case ReportLossStatus.expensesAndDocumentUpdated:
        return ReportLossStatusValue.expensesAndDocumentUpdated;

      case ReportLossStatus.receivedLiabality:
        return ReportLossStatusValue.receivedLiabality;

      case ReportLossStatus.liabilityReview:
        return ReportLossStatusValue.liabilityReview;

      case ReportLossStatus.liabilityAccepted:
        return ReportLossStatusValue.liabilityAccepted;

      case ReportLossStatus.confirmLiability:
        return ReportLossStatusValue.confirmLiability;

      case ReportLossStatus.debitNoteGenerated:
        return ReportLossStatusValue.debitNoteGenerated;

      case ReportLossStatus.claimSettled:
        return ReportLossStatusValue.claimSettled;

        case ReportLossStatus.knockForKnock:
          return ReportLossStatusValue.knockForKnock;
    }
  }

  closeFullView(){
    this.fullView.emit();
  }

  checkCheckbox(data:Field){
    if (data.fieldName ==='ldIsTotalLoss' || data.fieldName === 'srTotalLoss') {
      if (data.value==='true') {
         this.checkBox = true;
        return true;
      }else{
        return false;
      }
    }
  }
/**
 * Get payable Section Name HighLight
 * @param sectionName
 * @returns
 */
  getPayableHighlight(sectionName: string): boolean {
    if(sectionName !== StageNameReportLoss.tpDetails && sectionName !== StageNameReportLoss.surveyReport && sectionName !== StageNameReportLoss.reserveReview && sectionName !== StageNameReportLoss.creditNote) {
      return false;
    } else if(sectionName === StageNameReportLoss.surveyReport || sectionName === StageNameReportLoss.creditNote ) {
      return true;
    } else if((sectionName === StageNameReportLoss.reserveReview) && this.isReceivableFromParent) {
      return true;
    } else {
      return true;
    }
  }
  getReceivableHighlight(sectionName: string): boolean {
    if(sectionName !== StageNameReportLoss.tpDetails && sectionName !== StageNameReportLoss.surveyReport && sectionName !== StageNameReportLoss.reserveReview && sectionName !== StageNameReportLoss.creditNote) {
      return true;
    } else if((sectionName === StageNameReportLoss.reserveReview) && this.isReceivableFromParent) {
      return false;
    } else {
      return false;
    }
  }

  checkFilled(data: Field[]): void {
    let count = 0;
    data.forEach((item) => {
      if (item.mandatory && item.value) {
        count++;
      } else if(!item.mandatory) {
        count++;
      }
    });
    if(data.length === count) {
      this.isTickEnable[this.getIndexNumberOfEntity(data[0].entityName)] = false
    }
    else if(this.filledSubSectionNameFromparent){
      this.isTickEnable[this.getIndexNumberOfEntity(this.filledSubSectionNameFromparent)] = false
    }

  }

  getIndexNumberOfEntity(entitryName:string){
    switch (entitryName) {
      case EntityName.insuredDetails:
        return 0;

        case EntityName.tpDetails:
        return 1;

        case EntityName.lossDetails:
        return 2;

        case EntityName.policeDetails:
        return 3;

        case StageNameReportLoss.policeDetails:
        return 3;

        case EntityName.garageDetails:
        return 4;

        case EntityName.surveyDetails:
        return 5;

        case EntityName.surveyReport:
        return 6;

        case StageNameReportLoss.surveyReport:
        return 6;

        case EntityName.recoveryDetails:
        return 7;

        case EntityName.reserveReview:
        return 8;

        case EntityName.garageInvoice:
        return 9;

        case EntityName.debitNote:
        return 10;

        case EntityName.creditNote:
        return 11;

    }
  }

  shouldShowDeleteFile(): boolean {
    return !this.saveButton && ((this.name === StageNameReportLoss.policeDetails && this.receivable && !this.isClaimSettled) ||
      (this.name === StageNameReportLoss.surveyReport && !this.receivable && !this.isClaimSettled) ||
      (this.name === StageNameReportLoss.garageInvoice && this.receivable && !this.isClaimSettled ));
  }

  getFileName(imageData: any): string {
    return imageData.name !== '' ? imageData.name : imageData.url;
  }

  getPreviewImage(imageData:any){
    const name = this.getFileName(imageData);
    switch (name.split('.').slice(-1)[0]) {
      case 'jpg':
        return 'assets/file/jpg.svg'

        case 'pdf':
        return 'assets/file/pdf.svg'

        case 'doc':
        return 'assets/file/doc.svg'

        case 'docx':
        return 'assets/file/docx.svg'

        case 'img':
        return 'assets/file/img.svg'

        case 'jpeg':
        return 'assets/file/jpeg.svg'

        case 'png':
        return 'assets/file/png.svg'

        case 'svg':
        return 'assets/file/svg.svg'

        case 'txt':
        return 'assets/file/txt.svg'

        case 'upload':
        return 'assets/file/upload.svg'

        case 'xls':
        return 'assets/file/xls.svg'

        case 'xlsx':
        return 'assets/file/xlsx.svg'
    }
  }


  removeCommas(value: string){
    if (value !== undefined && value !== null && value !=='') {

      const num =  Number(value.toString().replace(/,/g, ''));
      return num.toLocaleString("en",{useGrouping: false,minimumFractionDigits: 3});
      // return num.toFixed(3);
    } else {
      return '';
    }
  }

  removeCommas2(value: any):number{
    if (value !== undefined && value !== null && value !=='') {

      var num =  Number(value.toString().replace(/,/g, ''));
      return Number(num.toLocaleString("en",{useGrouping: false,minimumFractionDigits: 3}));
      // return num.toFixed(3);
    } else {
      return null;
    }
  }
  /*
  * Clear Date Field Value
  */
  clearDateField(editableSts:any,selectedFieldList:any,filedName:string){
    if(!editableSts._disabled){
      this.selectedFieldList.forEach(ele =>{
        if(ele.fieldType=== 'pDate' || ele.fieldType === 'fDate')
        if(ele.fieldName == filedName  || 'sdSurveyDueDate' == ele.fieldName){
          ele.value = "";
        }
      })
    }

  }
  /*
  * Clear TotalLoss Date Field Value
  */
  clearTotalLossDateField(isEditable:any,surveyDate1:boolean){
    if(!isEditable._disabled){
      if(surveyDate1){
        this.TotalLoss.controls['surveyDate1'].setValue("");
        this.date1 = "";
      }else{
        this.TotalLoss.controls['surveyDate2'].setValue("");
        this.date2 = "";
      }
    }
  }

  private mutliLanguageForField(){
    this.reportLossData.metaData.sectionList.forEach((xx:Section)=>{
      xx.sectionList.forEach(subSec=>{
        subSec.fieldList.find((dt)=>{
          const translateFieldName   = this.translate.instant("reportloss."+dt.fieldName);
          if(!translateFieldName.includes('reportloss.')){
            dt.aliasName = translateFieldName;
          }
       });
      });
    });
  }

  public isFileDisabled(data: any): boolean {
    return !data.readOnly || this.saveButton || this.isClaimSettled;
  }
}
