import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportLossFullViewComponent } from './report-loss-full-view.component';

describe('ReportLossFullViewComponent', () => {
  let component: ReportLossFullViewComponent;
  let fixture: ComponentFixture<ReportLossFullViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReportLossFullViewComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ReportLossFullViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
