import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-sub-upload-popup',
  templateUrl: './sub-upload-popup.component.html',
  styleUrls: ['./sub-upload-popup.component.scss']
})
export class SubUploadPopupComponent {
  fileName: any;
  file: File=null;
  fileType: string;


  constructor(public dialog: MatDialog){}
  closeTab()

  {
    this.dialog.closeAll();
  }

  filemap = new Map<string,string>([ [ "pdf", "/assets/file/pdf.svg" ], [ "xlsx", "/assets/file/xlsx.svg" ], [ "xls", "/assets/file/xls.svg" ], [ "doc", "/assets/file/doc.svg" ], [ "docx", "/assets/file/docx.svg" ], [ "img", "/assets/file/img.svg" ], [ "jpeg", "/assets/file/jpeg.svg"], [ "jpg", "/assets/file/jpg.svg" ], [ "png", "/assets/file/png.svg"], [ "svg", "/assets/file/svg.svg"] ]);
   // On file Select
    onChange(event) {
       this.file = event.target.files[0];
      this.fileName = this.file.name;
      const str = this.fileName.split(".");
       // Split the string using dot as separator
        const filename = str.pop(); for (const key of this.filemap.keys()) { if(key===filename){ this.fileType=this.filemap.get(key).toString(); } } if(this.fileType===null||this.fileType===undefined){ this.fileType="/assets/file/file.svg"; } }


}
