import { Component } from '@angular/core';

@Component({
  selector: 'app-report-loss-card',
  templateUrl: './report-loss-card.component.html',
  styleUrls: ['./report-loss-card.component.scss']
})

export class ReportLossCardComponent{

}
