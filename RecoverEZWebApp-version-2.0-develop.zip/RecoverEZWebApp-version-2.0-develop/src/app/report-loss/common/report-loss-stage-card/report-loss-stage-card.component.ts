import { ReportLossStageListComponent } from './../report-loss-stage-list/report-loss-stage-list.component';
import { ReportLossStageEnum, ReportLossStatus, ReportLossStatusValue, StageNameReportLoss } from './../../../common/enum/enum';
import { ReportLossData } from './../../../models/report-loss-dto/report-loss-data';
/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable @angular-eslint/no-empty-lifecycle-method */
import { Field } from './../../../models/report-loss-dto/field';
import { Section } from './../../../models/report-loss-dto/section';
import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ReportLossService } from 'src/app/service/report-loss.service';
import { FileUploadDTO } from '../report-loss-stage-list/report-loss-stage-list.component';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MomentDateAdapter } from '@angular/material-moment-adapter';

export const MY_FORMATS = {
  parse: {
      dateInput: 'LL'
  },
  display: {
      dateInput: 'DD-MM-YYYY',
      monthYearLabel: 'YYYY',
      dateA11yLabel: 'LL',
      monthYearA11yLabel: 'YYYY'
  }
};

@Component({
  selector: 'app-report-loss-stage-card',
  templateUrl: './report-loss-stage-card.component.html',
  styleUrls: ['./report-loss-stage-card.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }
  ],
})

export class ReportLossStageCardComponent implements OnInit {
  @Input()  currentStatus:string;
  @Input() sectionListFromParent:Section[];
  @Input() sectionFromParent:Section;
  @Input() reportLossDataToChild:ReportLossData;
  @Input()  detailsFromParent:any;
  @Input()  fieldListToStageCard:Field[];
  @Input()  fieldFilledBooleanArray:boolean[];
  @Input()  isReceivableFromParent:boolean;
  @Input() surveyDueHours:string;
  @Output() fromCardToParent = new EventEmitter<string>();
  @Output() mainSectionName = new EventEmitter<string>();
  @Output() isFieldFromStageList = new EventEmitter<boolean>();
  @Output() valueFromListToParent = new EventEmitter<any>();
  @Output() IsReceivable = new EventEmitter<any>();


  uploaded="Uploaded";
  sectionDetails:Section[];
  fieldLisDetails:Field[];
  entityName:string[];

  sectionNameFromCard:string;
  ReportLossService: any;
  reporting: any;
  reportingList: any;
  report:any;
  fielddata:any;
  selectedItem: any;
  sectionName:any;

  showField=true;
  selectedFieldListItems: any;

  @Output() selectedCardSection = new EventEmitter<string>();
  @Output() parantSectionName = new EventEmitter<string>();
  @Output() selectedFieldList = new EventEmitter<{ fileData: FileUploadDTO, sectionName: string, data: Field[], isAllDeleted: boolean, removedFileList: number[] }>();
  @ViewChild(ReportLossStageListComponent) stageList:ReportLossStageListComponent;

  imageAssetList = [
    {
      image:"assets/reportloss/Not at fault-theme/Insured Details-1.svg",
      title:"Insured Details"
    },
    {
      image:"assets/reportloss/At fault/TP Details-2.svg",
      title:"TP Details"
    },
    {
      image:"assets/reportloss/Not at fault-theme/Loss Details-1.svg",
      title:"Loss Details"
    },
    {
      image:"assets/reportloss/Not at fault-theme/Police Report-1.svg",
      title:"Police Report"
    },
    {
      image:"assets/reportloss/Not at fault-theme/Garage Details-1.svg",
      title:"Garage Details"
    },
    {
      image:"assets/reportloss/Not at fault-theme/Survey Details-1.svg",
      title:"Survey Details"
    },
    {
      image:"assets/reportloss/At fault/Survey Report-2.svg",
      title:"Survey Report"

    },
    {
      image:"assets/reportloss/Not at fault-theme/Recovery Details-1.svg",
      title:"Recovery Details"
    },
    {
      image:"assets/reportloss/At fault/Reserve Review-2.svg",
      title:"Reserve Review",
      isReceivable: true
    },
    {
      image:"assets/reportloss/At fault/Reserve Review-2.svg",
      title:"Reserve Review",
      isReceivable: false
    },
    {
      image:"assets/reportloss/Not at fault-theme/Garage Invoice-1.svg",
      title:"Garage Invoice"
    },
    {
      image:"assets/reportloss/Not at fault-theme/Debit Note-1.svg",
      title:"Debit Note"
    },
    {
      image:"assets/reportloss/At fault/credit note-2.svg",
      title:"Credit Note"
    }
  ]
  totalLossType: string;

    constructor(private router: Router, private route: ActivatedRoute, private dataservice: ReportLossService) {
      this.sectionDetails = [];
      this.entityName = [];
      this.fieldLisDetails = [];
    }
    triggerStageList(){
      this.stageList.navigateBack();
    }


    currentStage:string;


  ngOnInit(){
    const receivableAmount = this.reportLossDataToChild.receivableAmount;
    this.totalLossType = this.reportLossDataToChild?.totalLossType;
    if(this.reportLossDataToChild.lastStatus){
      if(this.reportLossDataToChild.lastStatus===ReportLossStatus.receivedLiabality){
        this.sectionFromParent = this.sectionListFromParent[1]
      }else{
      this.currentStage = this.getCurrentSection(this.currentStatusValue(this.reportLossDataToChild.lastStatus, receivableAmount));
      }
    }else if (this.currentStatus!==null && this.currentStatusValue(this.currentStatus, receivableAmount) !==null && this.currentStatusValue(this.currentStatus, receivableAmount)!== undefined) {

      this.currentStage = this.getCurrentSection(this.currentStatusValue(this.currentStatus, receivableAmount));

    }else{
      this.sectionFromParent = this.sectionListFromParent[0]
    }


    // this.sectionFromParent = this.sectionListFromParent[0]
    this.sectionListFromParent.forEach(element => {
      if (this.currentStage === element.sectionName) {
       this.sectionFromParent = element;
      }
    });
    // if(this.detailsFromParent !== undefined) {
    //   this.sectionFromParent = this.detailsFromParent.section;
    // }
    // this.sendSectionName();
    // if(this.fieldListToStageCard !== undefined) {
    //   this.selectedItem = this.fieldListToStageCard;
    // } else {
    //   this.selectedItem = this.sectionFromParent.sectionList[0].fieldList;
    // }
    // if(this.detailsFromParent !== undefined) {
    //   this.sectionName = this.detailsFromParent.subSection.sectionName;
    // } else {
    //   this.sectionName = this.sectionFromParent.sectionList[0].sectionName;
    // }
    if(this.detailsFromParent){
      this.sectionFromParent = this.detailsFromParent.section;
      this.sendSectionName();
      this.selectedItem = this.fieldListToStageCard;
      this.sectionName = this.detailsFromParent.subSection.sectionName;
      this.showField = false;
    }  
  }

  // ngDoCheck(){
  //   this.sendSectionName();
  // }





    sendSectionName(){
      this.sectionNameFromCard = this.sectionFromParent.sectionName;
      this.fromCardToParent.emit(this.sectionNameFromCard)
    }

    navigate(item: Section,parantSectionName:string){
      this.selectedItem = item.fieldList;
      this.sectionName = item.sectionName;
      this.showField = false;
      this.selectedCardSection.emit(this.sectionName);
      this.parantSectionName.emit(parantSectionName);
    }
    getGarageInvoice(section:Section){
      if (section.fieldList==null) {
        return true;
      }
      return false;
    }


    setSelectedFieldList(event: any): void{
      this.selectedFieldListItems = event;
      this.selectedFieldList.emit(this.selectedFieldListItems);
    }

    showCardviewOfParent(){
      this.showField = !this.showField;
    }

    getUrl(sectionName: string): string {
      let src = '';
      let img = undefined;
      if(sectionName === StageNameReportLoss.reserveReview) {
        img = this.imageAssetList.find((img) => img.title === sectionName && img.isReceivable === this.isReceivableFromParent);
      } else {
        img = this.imageAssetList.find((img) => img.title === sectionName);
      }
      if(img) {
        src = img.image;
      }
      return src;
    }


    filledSubSectionNameFromList:string;
    isFieldIsFull(event){
      this.filledSubSectionNameFromList = event.subSectionName;
      this.isFieldFromStageList.emit(event) ;
    }


  getThis(name:string){

    switch (name) {
      case StageNameReportLoss.insuredDetails:
        return this.fieldFilledBooleanArray[0];

      case StageNameReportLoss.tpDetails:
        return this.fieldFilledBooleanArray[1];

      case StageNameReportLoss.lossDetails:
        return this.fieldFilledBooleanArray[2];

      case StageNameReportLoss.policeDetails:
        return this.fieldFilledBooleanArray[3];

      case StageNameReportLoss.garageDetails:
        return this.fieldFilledBooleanArray[4];

      case StageNameReportLoss.surveyDetails:
        return this.fieldFilledBooleanArray[5];

      case StageNameReportLoss.surveyReport:
        return this.fieldFilledBooleanArray[6];

      case StageNameReportLoss.recoveryDetails:
        return this.fieldFilledBooleanArray[7];

      case StageNameReportLoss.reserveReview:
        return this.fieldFilledBooleanArray[8];

      case StageNameReportLoss.garageInvoice:
        return this.fieldFilledBooleanArray[9];

      case StageNameReportLoss.debitNote:
        return this.fieldFilledBooleanArray[10];

      case StageNameReportLoss.creditNote:
        return this.fieldFilledBooleanArray[11];

    }

  }

  getSectionName(sectionName:string){
    this.mainSectionName.emit(sectionName);
  }

  valuesFromList(event){
    this.valueFromListToParent.emit(event)
  }


  sendIsReceivable(event){
    this.IsReceivable.emit(event)
  }

  getExpandUrl(sectionName: string): string {
    if(sectionName !== StageNameReportLoss.tpDetails && sectionName !== StageNameReportLoss.surveyReport && sectionName !== StageNameReportLoss.reserveReview && sectionName !== StageNameReportLoss.creditNote) {
      return 'assets/reportloss/Expand and Collapse-1/Expand Not at fault.svg';
    } else if(sectionName === StageNameReportLoss.surveyReport || sectionName === StageNameReportLoss.creditNote) {
      return 'assets/reportloss/Expand and Collapse-1/Expand at fault.svg';
    } else if((sectionName === StageNameReportLoss.tpDetails || sectionName === StageNameReportLoss.reserveReview) && this.isReceivableFromParent) {
      return 'assets/reportloss/Expand and Collapse-1/Expand Not at fault.svg';
    } else {
      return 'assets/reportloss/Expand and Collapse-1/Expand at fault.svg';
    }
  }

  getMicUrl(sectionName: string): string {
    if(sectionName !== StageNameReportLoss.tpDetails && sectionName !== StageNameReportLoss.surveyReport && sectionName !== StageNameReportLoss.reserveReview && sectionName !== StageNameReportLoss.creditNote) {
      return 'assets/reportloss/Expand and Collapse-1/Mic Not at fault.svg';
    } else if(sectionName === StageNameReportLoss.surveyReport || sectionName === StageNameReportLoss.creditNote) {
      return 'assets/reportloss/Expand and Collapse-1/Mic at fault.svg';
    } else if((sectionName === StageNameReportLoss.tpDetails || sectionName === StageNameReportLoss.reserveReview) && this.isReceivableFromParent) {
      return 'assets/reportloss/Expand and Collapse-1/Mic Not at fault.svg';
    } else {
      return 'assets/reportloss/Expand and Collapse-1/Mic at fault.svg';
    }
  }

  getReceivableHighlight(sectionName: string): boolean {
    if(sectionName !== StageNameReportLoss.tpDetails && sectionName !== StageNameReportLoss.surveyReport && sectionName !== StageNameReportLoss.reserveReview && sectionName !== StageNameReportLoss.creditNote) {
      return true;
    } else if(sectionName === StageNameReportLoss.surveyReport || sectionName === StageNameReportLoss.creditNote) {
      return false;
    } else if((sectionName === StageNameReportLoss.tpDetails || sectionName === StageNameReportLoss.reserveReview) && this.isReceivableFromParent) {
      return true;
    } else {
      return false;
    }
  }

  getPayableHighlight(sectionName: string): boolean {
    if(sectionName !== StageNameReportLoss.tpDetails && sectionName !== StageNameReportLoss.surveyReport && sectionName !== StageNameReportLoss.reserveReview && sectionName !== StageNameReportLoss.creditNote) {
      return false;
    } else if(sectionName === StageNameReportLoss.surveyReport || sectionName === StageNameReportLoss.creditNote) {
      return true;
    } else {
      return true;
    }

  }

  currentStatusValue(currentStatus: string, receivableAmount: number | null) {
    switch (currentStatus) {

      case ReportLossStatus.draft:
        return ReportLossStatusValue.draft;

      case ReportLossStatus.notificationOpen:
        return ReportLossStatusValue.notificationOpen;

      case ReportLossStatus.notificationReceived:
        return ReportLossStatusValue.notificationReceived;

      case ReportLossStatus.notificationAccepted:
        return ReportLossStatusValue.notificationAccepted;

      case ReportLossStatus.garageAndSurveyDetails:
        return ReportLossStatusValue.garageAndSurveyDetails;

      case ReportLossStatus.movedToInspection:
        return ReportLossStatusValue.movedToInspection;

      case ReportLossStatus.underInspection:
        return ReportLossStatusValue.underInspection;

      case ReportLossStatus.expensesAndDocumentUpdated:
        return ReportLossStatusValue.expensesAndDocumentUpdated;

      case ReportLossStatus.receivedLiabality:
        return ReportLossStatusValue.receivedLiabality;

      case ReportLossStatus.liabilityReview:
        return ReportLossStatusValue.liabilityReview;

      case ReportLossStatus.liabilityAccepted:
        return ReportLossStatusValue.liabilityAccepted;

      case ReportLossStatus.confirmLiability:
        return ReportLossStatusValue.confirmLiability;

      case ReportLossStatus.debitNoteGenerated:
        return ReportLossStatusValue.debitNoteGenerated;

      case ReportLossStatus.claimSettled:
        return ReportLossStatusValue.claimSettled;

      case ReportLossStatus.totalLossInitiated:
        if(this.totalLossType != 'type1'){
          if(receivableAmount && receivableAmount > 0 ) {
            return ReportLossStatusValue.expensesAndDocumentUpdated;
          } else {
            return ReportLossStatusValue.notificationAccepted;
          }
        }else{
          return ReportLossStatusValue.receivedLiabality;
        }
       
        

      case ReportLossStatus.totalLossAccepted:
        return ReportLossStatusValue.receivedLiabality;

      case ReportLossStatus.surveyAssigned:
        return ReportLossStatusValue.expensesAndDocumentUpdated;
      
      case ReportLossStatus.knockForKnock:
        return ReportLossStatusValue.knockForKnock;
    }
  }

  getCurrentSection(value:number){
    if (value<103) {
      return ReportLossStageEnum.notificationStage;
    }
    else if(value<=106){
      return ReportLossStageEnum.claimInspectionStage;
    }
    else if(value<111){
      return ReportLossStageEnum.liabilityConfirmationStage;
    }
    else{
      return ReportLossStageEnum.settlementStage;
    }
  }

  getFileName(section: string, fieldValue: string): string {
    if(fieldValue) {
      switch(section) {
        case StageNameReportLoss.policeDetails:
          return 'Police Report';
        case StageNameReportLoss.surveyReport:
          return 'Survey Report';
        case StageNameReportLoss.garageInvoice:
          return 'Garage Invoice';
        default:
          return '';
      }
    }
  }
}
