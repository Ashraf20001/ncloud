import { StageNameReportLoss, ReportLossStatus, ReportLossStatusValue } from './../../../common/enum/enum';
import { ReportLossData } from './../../../models/report-loss-dto/report-loss-data';
import { Field } from './../../../models/report-loss-dto/field';
import { MetaDataDto } from 'src/app/models/report-loss-dto/meta-data-dto';
import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';


import { ReportLossService } from 'src/app/service/report-loss.service';
import { Section } from 'src/app/models/report-loss-dto/section';




@Component({
  selector: 'app-report-loss-stage',
  templateUrl: './report-loss-stage.component.html',
  styleUrls: ['./report-loss-stage.component.scss']
})


export class ReportLossStageComponent  implements OnInit,OnChanges {
  constructor(private dataservice: ReportLossService) {
    this.details = [];
  }
  @Input() sectionListFromParent:Section[];
  @Input() sectionFromParent:Section;
  @Input() metaDataToChild:MetaDataDto;
  @Input() reportLossDataToChild:ReportLossData;
  @Input() isFieldFromStageList:boolean;
  @Input() filledSubSectionNameFromList:string;
  @Input() currentStatusToParent:string;
  @Input() currentSectionName:string;
  @Input() currentParantSectionName:string;
  @Input() receivableBooleanFromParent:boolean;
  @Input() selectedSectionNameFromSection:string;


  @Output() showParentList = new EventEmitter<Section>();
  @Output() selectedCardSection = new EventEmitter<string>();
  @Output() selectedFieldLists = new EventEmitter<any>();
  @Output() selectParentSectionName = new EventEmitter<string>();
  @Output() sendIsFieldValueFilled = new EventEmitter<any>;
  @Output() enableSection = new EventEmitter<any>;
  @Output() emitPercentage = new EventEmitter<number[]>();
  selectedFieldListItems: any;
  selectedItem: Field[];
  sectionName:string;
  showField=true;
  isOpenstage:boolean
  details= [];
  selectedSectionName = '';
  stageList= true;
  filledSubSectionName:string;

    isNotificationStage = false;
    isInsuredDetails=false
    isThirdPartyDetails=false
    isLossDetails=false
    isPoliceDetails=false

    enableInspectionStage=false
    isGarageInfo=false
    isSurveyDetails=false
    isSurveyReport=true
    isRecoveryDetails=true

    enableLiabilityStage = true
    isReserveReview=true

    enableSettlementStage = true
    isGarageInvoice = true
    isDebitNote=true
    isCreditNote=true

    isLockInsuredDetails=true
    isLockThirdPartyDetails=true
    isLockLossDetails=true
    isLockPoliceDetails=true
    isLockGarageInfo=true
    isLockSurveyDetails=true
    isLockSurveyReport=true
    isLockRecoveryDetails=true
    isLockReserveReview=true
    isLockGarageInvoice = true
    isLockDebitNote=true
    isLockCreditNote=true

    lastStatus:string;
    totalLossType:string;
    percentageValues = [0, 0, 0, 0];

ngOnChanges(changes: SimpleChanges): void {
  if(this.currentSectionName !== undefined){
    this.selectedSectionName = this.currentSectionName;
  }
  if(this.currentParantSectionName !== undefined){
    this.selectedSectionNameFromSection= this.currentParantSectionName;
  }
     if (changes) {
      this.lastStatus = this.reportLossDataToChild?.lastStatus;
      this.totalLossType = this.reportLossDataToChild?.totalLossType;
      this.changeButtons();
      this.changeButtonAccordingToStatus();
    }
}

changeButtons(): void {
  if (this.isFieldFromStageList!== undefined) {
    this.stageList = this.isFieldFromStageList;
    this.filledSubSectionName = this.filledSubSectionNameFromList;
    if (this.filledSubSectionNameFromList===StageNameReportLoss.insuredDetails) {
        this.isThirdPartyDetails = false;
        this.isLockInsuredDetails = false
    }
    if(this.currentStatusValue(this.currentStatusToParent) >= ReportLossStatusValue.debitNoteGenerated) {
      this.isCreditNote = false;
    }
    else if (this.filledSubSectionNameFromList===StageNameReportLoss.tpDetails) {
        this.isLossDetails = false;
        this.isLockThirdPartyDetails = false;
    }
    else if (this.filledSubSectionNameFromList===StageNameReportLoss.lossDetails) {
        this.isPoliceDetails = false;
        this.isLockLossDetails =false;
        this.enableInspectionStage=false;
    }
    else if (this.filledSubSectionNameFromList===StageNameReportLoss.policeDetails) {
      this.isLockPoliceDetails = false;
      if (this.currentStatusValue(this.currentStatusToParent)>=ReportLossStatusValue.notificationAccepted) {
        this.isGarageInfo = false;
      }
    }
    else if (this.filledSubSectionNameFromList===StageNameReportLoss.garageDetails) {
        this.isSurveyDetails = false;
        this.isLockGarageInfo = false;
    }
    else if (this.filledSubSectionNameFromList===StageNameReportLoss.surveyDetails) {
      this.isLockSurveyDetails = false;
      if (this.currentStatusValue(this.currentStatusToParent)>=ReportLossStatusValue.garageAndSurveyDetails) {
        this.isSurveyReport = false;
      }
    }
    else if (this.filledSubSectionNameFromList===StageNameReportLoss.surveyReport) {
      this.isLockSurveyReport = false;
      this.enableLiabilityStage=false;
      if (this.currentStatusValue(this.currentStatusToParent)>=ReportLossStatusValue.expensesAndDocumentUpdated) {
        this.isRecoveryDetails = false;
      }
    }
    else if (this.filledSubSectionNameFromList===StageNameReportLoss.recoveryDetails) {
      if (this.currentStatusValue(this.currentStatusToParent)>=ReportLossStatusValue.liabilityAccepted) {
        this.isReserveReview = false;
      }
      this.isLockRecoveryDetails = false;
      this.enableSettlementStage=false;
    }
    else if (this.filledSubSectionNameFromList===StageNameReportLoss.reserveReview) {
        this.isGarageInvoice = false;
        this.isLockReserveReview = false;
        if (this.currentStatusValue(this.currentStatusToParent)>=ReportLossStatusValue.debitNoteGenerated) {
          this.isCreditNote = false;
        }
    }
    else if (this.filledSubSectionNameFromList===StageNameReportLoss.garageInvoice) {
        this.isDebitNote = false;
        this.isLockGarageInvoice = false;
    }
    else if (this.filledSubSectionNameFromList===StageNameReportLoss.debitNote) {
      this.isLockDebitNote = false;
    }
    else if (this.filledSubSectionNameFromList===StageNameReportLoss.creditNote) {
    this.isCreditNote = false;
       this.isLockCreditNote = false;
  }
    this.report_datas();
  }
}

changeButtonAccordingToStatus(){
  if(this.currentStatusValue(this.currentStatusToParent)>=ReportLossStatusValue.notificationOpen){
    this.isInsuredDetails = false;
    this.isThirdPartyDetails = false;
    this.isLossDetails = false;
    this.isPoliceDetails = false;
    this.percentageValues[0] = 25;
    // this.isLockInsuredDetails = false;
    // this.isLockThirdPartyDetails = false;
    // this.isLockLossDetails = false;
    // this.isLockPoliceDetails = false;
}
  if (this.currentStatusValue(this.currentStatusToParent)>=ReportLossStatusValue.notificationAccepted) {
    this.isGarageInfo = false;
    this.isSurveyDetails = false;

    this.enableInspectionStage = false;
    this.percentageValues[0] = 25;
    // this.isLockGarageInfo = false;
    // this.isLockSurveyDetails = false;
  } else {
    // this.isGarageInfo = true;
    // this.isSurveyDetails = true;
    // this.enableInspectionStage = true;
  }
   if(this.currentStatusValue(this.currentStatusToParent)>=ReportLossStatusValue.garageAndSurveyDetails){
      this.isSurveyReport = false;
      this.percentageValues[1] = 37;
      // this.isLockSurveyReport = false;
  } else {
    this.isSurveyReport = true;
  }
   if(this.currentStatusValue(this.currentStatusToParent)>=ReportLossStatusValue.expensesAndDocumentUpdated){
      this.isRecoveryDetails = false;
      // this.isLockRecoveryDetails = false;
      this.percentageValues[2] = 63;
      this.enableLiabilityStage=false;
      this.percentageValues[1] = 50;
  } else {
    this.isRecoveryDetails = true;
  }
  if(this.currentStatusValue(this.currentStatusToParent)>=ReportLossStatusValue.liabilityReview){
    this.isReserveReview = false;
    this.percentageValues[2] = 63;
    this.enableLiabilityStage=false;
    // this.isGarageInvoice = false;
    // this.isLockReserveReview = false;
} else {
  this.isReserveReview = true;
  this.enableLiabilityStage = true;
}
    if(this.currentStatusValue(this.currentStatusToParent)>=ReportLossStatusValue.liabilityAccepted){
      this.isReserveReview = false;
      this.percentageValues[2] = 75;
      this.enableLiabilityStage=false;
      this.isGarageInvoice = false;
      // this.isLockReserveReview = false;
  } else {
    // this.isReserveReview = true;
    this.enableLiabilityStage = true;
  }
   if(this.currentStatusValue(this.currentStatusToParent)>=ReportLossStatusValue.confirmLiability){
      this.isGarageInvoice = false;
      this.isDebitNote = false;
      this.percentageValues[0]= 25;
      this.percentageValues[1] = 50;
      this.percentageValues[2] = 75;
      this.enableSettlementStage = false;
      // this.isLockGarageInfo = false;
      // this.isLockDebitNote = false;
  } else {
    // this.isGarageInvoice = true;
    this.enableSettlementStage = true;
  }
   if(this.currentStatusValue(this.currentStatusToParent)>=ReportLossStatusValue.claimSettled){
    this.isCreditNote = false;
    this.isLockGarageInvoice = false;
    this.percentageValues[3] = 100;
    // this.isLockCreditNote = false;
  }
  if (this.lastStatus === ReportLossStatus.receivedLiabality) {
    this.isGarageInfo = false;
    this.isSurveyDetails = false;
    this.isSurveyReport = false;
    this.percentageValues[0]=25;
    this.percentageValues[1] = 50;
    // this.percentageValues[2] = 75;
  }
  // if (this.currentStatusToParent===ReportLossStatus.disputeReopen&&this.lastStatus === ReportLossStatus.receivedLiabality) {
  //   this.isGarageInfo = false;
  //   this.isSurveyDetails = false;
  //   this.isSurveyReport = false;
  //   this.isRecoveryDetails=false;
  //   this.percentageValues[0]=25;
  //   this.percentageValues[1] = 50;
  //   // this.percentageValues[2] = 75;
  // }
  if (this.lastStatus === ReportLossStatus.liabilityReview) {
    this.isGarageInfo = false;
    this.isSurveyDetails = false;
    this.isSurveyReport = false;
    this.isRecoveryDetails = false;
    this.percentageValues[0]= 25;
    this.percentageValues[1] = 50;
    this.percentageValues[2]=75;
  }

  if (this.lastStatus === ReportLossStatus.debitNoteGenerated) {
    this.isGarageInfo = false;
    this.isSurveyDetails = false;
    this.isSurveyReport = false;
    this.isRecoveryDetails = false;
    this.isReserveReview = false;
    this.isGarageInvoice = false;
    if(!this.totalLossType){
      this.isLockGarageInvoice =false;
    }
    this.isDebitNote = false;
    // this.isCreditNote = false;
    this.percentageValues[0]= 25;
    this.percentageValues[1] = 50;
    this.percentageValues[2] = 75;
    this.percentageValues[3] = 87;
  }
  if (this.lastStatus === ReportLossStatus.confirmLiability) {
    this.isGarageInfo = false;
    this.isSurveyDetails = false;
    this.isSurveyReport = false;
    this.isRecoveryDetails = false;
    this.isReserveReview = false;
    this.isGarageInvoice = false;
    this.isDebitNote = false;
    // this.isCreditNote = false;
    this.percentageValues[0]= 25;
    this.percentageValues[1] = 50;
    this.percentageValues[2] = 75;
    this.percentageValues[3] = 87;
  }

  if (this.totalLossType) {

    this.percentageValues[0] = 25;
    this.percentageValues[1] = 50;
    this.enableInspectionStage=false
    this.isGarageInfo=false
    this.isSurveyDetails=false
    this.isSurveyReport=false
    this.isRecoveryDetails = false
    this.isReserveReview = false
    if(this.totalLossType == "type1" && this.lastStatus == ReportLossStatus.totalLossAccepted || this.currentStatusToParent == ReportLossStatus.liabilityAccepted){
      this.isLockReserveReview = false;
      this.isLockRecoveryDetails = false;
    }
    if(this.totalLossType == "type2" ){
      this.enableLiabilityStage = false;
    }
  }
  // knockForKnock
  if (this.currentStatusValue(this.currentStatusToParent) == ReportLossStatusValue.knockForKnock) {
    this.isLockReserveReview = false;
    this.isLockRecoveryDetails = false;
    this.isReserveReview = false;
    this.percentageValues[2] = 75;
    this.enableLiabilityStage = false;
    this.enableInspectionStage = false;
    this.enableSettlementStage = true;
  }

  this.emitPercentage.emit(this.percentageValues);
}

currentStatusValue(currentStatus: string) {
  switch (currentStatus) {

    case ReportLossStatus.draft:
      return ReportLossStatusValue.draft;
      
    case ReportLossStatus.notificationOpen:
      return ReportLossStatusValue.notificationOpen;
      
    case ReportLossStatus.notificationReceived:
      return ReportLossStatusValue.notificationReceived;
      
    case ReportLossStatus.notificationAccepted:
      return ReportLossStatusValue.notificationAccepted;
      
    case ReportLossStatus.garageAndSurveyDetails:
      return ReportLossStatusValue.garageAndSurveyDetails;
      
    case ReportLossStatus.movedToInspection:
      return ReportLossStatusValue.movedToInspection;
      
    case ReportLossStatus.underInspection:
      return ReportLossStatusValue.underInspection;
      
    case ReportLossStatus.expensesAndDocumentUpdated:
      return ReportLossStatusValue.expensesAndDocumentUpdated;
      
    case ReportLossStatus.receivedLiabality:
      return ReportLossStatusValue.receivedLiabality;
      
    case ReportLossStatus.liabilityReview:
      return ReportLossStatusValue.liabilityReview;
      
    case ReportLossStatus.liabilityAccepted:
      return ReportLossStatusValue.liabilityAccepted;
      
    case ReportLossStatus.confirmLiability:
      return ReportLossStatusValue.confirmLiability;
      
    case ReportLossStatus.debitNoteGenerated:
      return ReportLossStatusValue.debitNoteGenerated;
      
    case ReportLossStatus.claimSettled:
      return ReportLossStatusValue.claimSettled;
     
      case ReportLossStatus.knockForKnock:
        return ReportLossStatusValue.knockForKnock;
  }
}

  imageAssetList = [
    {
      image:"assets/reportloss/stage-icons/Insured Details.svg",
      title:"Insured Details"
    },
    {
      image:"assets/reportloss/stage-icons/TP Details.svg",
      title:"TP Details"
    },
    {
      image:"assets/reportloss/stage-icons/Loss Details.svg",
      title:"Loss Details"
    },
    {
      image:"assets/reportloss/stage-icons/Police Report.svg",
      title:"Police Report"
    },
    {
      image:"assets/reportloss/stage-icons/Garage Details.svg",
      title:"Garage Details"
    },
    {
      image:"assets/reportloss/stage-icons/Survey Details.svg",
      title:"Survey Details"
    },
    {
      image:"assets/reportloss/stage-icons/Survey Report.svg",
      title:"Survey Report"

    },
    {
      image:"assets/reportloss/stage-icons/Recovery Details.svg",
      title:"Recovery Details"
    },
    {
      image:"assets/reportloss/stage-icons/Reserve Review.svg",
      title:"Reserve Review"
    },
    {
      image:"assets/reportloss/stage-icons/Garage Invoice.svg",
      title:"Garage Invoice"
    },
    {
      image:"assets/reportloss/stage-icons/Debit Note.svg",
      title:"Debit Note"
    },
    {
      image:"assets/reportloss/stage-icons/Credit Note.svg",
      title:"Credit Note"
    }
  ]

  ngOnInit(){
    this.dataservice.isOpen.subscribe((value:boolean) => {
      this.isOpenstage=value;
    });
    this.report_datas();
  }

  goBack(){
    this.showField=!this.showField;
    this.isOpenstage=!this.isOpenstage;
  }

  isFieldFilled:boolean[];
  isStageLocked:boolean[];


    report_datas(){
      this.isFieldFilled=[
        this.isInsuredDetails,
        this.isThirdPartyDetails,
        this.isLossDetails,
        this.isPoliceDetails,
        this.isGarageInfo,
        this.isSurveyDetails,
        this.isSurveyReport,
        this.isRecoveryDetails,
        this.isReserveReview,
        this.isGarageInvoice,
        this.isDebitNote,
        this.isCreditNote
      ]
        this.isStageLocked=[
          this.isLockInsuredDetails,
          this.isLockThirdPartyDetails,
          this.isLockLossDetails,
          this.isLockPoliceDetails,
          this.isLockGarageInfo,
          this.isLockSurveyDetails,
          this.isLockSurveyReport,
          this.isLockRecoveryDetails,
          this.isLockReserveReview,
          this.isLockGarageInvoice,
          this.isLockDebitNote,
          this.isCreditNote
        ]

      this.sendIsFieldValueFilled.emit(this.isFieldFilled);
      this.enableSection.emit([
        this.isNotificationStage,
        this.enableInspectionStage,
        this.enableLiabilityStage,
        this.enableSettlementStage
      ])
      this.details = [];
    this.metaDataToChild?.sectionList.forEach(element => {


      element.sectionList.forEach(element1 => {
        this.imageAssetList.forEach(item =>{
          if(element1.sectionName === StageNameReportLoss.garageInvoice && element1.sectionName === item.title){
            this.details.push({
              section:element,
              subSection:element1,
              parentSectionName : element.sectionName,
              isFilled:this.isFieldFilled,
              isLocked:this.isStageLocked,
              sectionName : item.title,
              imageUrl: item.image,
              sectionList : element1.sectionList,
              sectionId: element1.sectionId,
              fieldList: element1.fieldList,
            });
          }

          if(element1.sectionName === item.title && element1.sectionName !== StageNameReportLoss.garageInvoice){
            this.details.push({
              section:element,
              subSection:element1,
              parentSectionName : element.sectionName,
              isFilled:this.isFieldFilled,
              isLocked:this.isStageLocked,
              sectionName : item.title,
              imageUrl: item.image,
              sectionList : element1.sectionList,
              sectionId: element1.sectionId,
              fieldList: element1.fieldList,
              islast: false
            });
          }
        })
      });

      this.details[this.details.length - 1].islast = true;
    });

  }
  selectedStageName:string;

  sendItemToParentFromStage(data:Section){
    this.selectedStageName = data.sectionName;
    this.showParentList.emit(data);
    this.dataservice.isOpenStage(false);
  }

  sendParentSectionName(name:string){
    this.selectParentSectionName.emit(name);
  }


  navigate(sectionName,fieldList){
    this.selectedItem = fieldList;
    this.sectionName = sectionName;
    this.showField=false;
    this.dataservice.isOpenStage(true);
    this.selectedCardSection.emit(this.sectionName);
    this.selectedSectionName = sectionName;
  }


  setSelectedFieldList(event: any): void{
    this.selectedFieldListItems = event;
    this.selectedFieldLists.emit({
      fieldList: this.selectedFieldListItems,
      sectionName: this.selectedStageName,
    });
  }


}
