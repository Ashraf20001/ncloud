import { DemoMaterialModule } from './../../common/components/material-module';
import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule,ReactiveFormsModule } from "@angular/forms";
import { ReportLossCardComponent } from "./report-loss-card/report-loss-card.component";
import { ReportLossHeaderActionComponent } from "./report-loss-header-action/report-loss-header-action.component";
import { ReportLossHeaderComponent } from "./report-loss-header/report-loss-header.component";
import { ReportLossCommonComponent } from "./report-loss-common.component";
import { ReportLossSectionComponent } from "./report-loss-section/report-loss-section.component";
import { ReportLossStageComponent } from "./report-loss-stage/report-loss-stage.component";
import { ReportLossStageCardComponent } from "./report-loss-stage-card/report-loss-stage-card.component";
import { ReportLossStageListComponent } from "./report-loss-stage-list/report-loss-stage-list.component";
import { ReportLossModule } from "../report-loss.module";
import { TranslateModule } from "@ngx-translate/core";
import { CommentsComponent } from './comments/comments.component';
import { ClaimHistoryComponent } from './claim-history/claim-history.component';
import { CustomDirectiveModule } from 'src/app/common/directives/custom-directive.module';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { ReportLossFullViewComponent } from './report-loss-full-view/report-loss-full-view.component';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatButtonModule} from '@angular/material/button';
import {MatCardModule} from '@angular/material/card';
import { NgbPopoverModule } from '@ng-bootstrap/ng-bootstrap';
import { CustomPipeModule } from 'src/app/common/pipes/custom-pipe/custom-pipe.module';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatFormFieldModule} from '@angular/material/form-field';
import { UploadPopupComponent } from './upload-popup/upload-popup.component';
import { SubUploadPopupComponent } from './sub-upload-popup/sub-upload-popup.component';

@NgModule({
    declarations: [
        ReportLossHeaderComponent,
        ReportLossHeaderActionComponent,
        ReportLossCardComponent,
        ReportLossSectionComponent,
        ReportLossStageComponent,
        ReportLossStageCardComponent,
        ReportLossStageListComponent,
        ReportLossCommonComponent,
        CommentsComponent,
        ClaimHistoryComponent,
        ReportLossFullViewComponent,
        UploadPopupComponent,
        SubUploadPopupComponent

    ],
    exports: [
        ReportLossHeaderComponent,
        ReportLossHeaderActionComponent,
        ReportLossCardComponent,
        ReportLossStageComponent,
        ReportLossStageListComponent,
        ReportLossStageCardComponent,
        ReportLossSectionComponent,
        ReportLossCommonComponent,
        CommentsComponent,
        ClaimHistoryComponent,


    ],
    imports: [
        CommonModule,
        FormsModule,
        TranslateModule,
        ReactiveFormsModule,
        DemoMaterialModule,
        CustomDirectiveModule,PdfViewerModule,MatExpansionModule,MatButtonModule,MatCardModule,
        NgbPopoverModule,
        CustomPipeModule,
        MatFormFieldModule,
        MatAutocompleteModule

    ]
})

export class ReportLossCommonModule{

}
