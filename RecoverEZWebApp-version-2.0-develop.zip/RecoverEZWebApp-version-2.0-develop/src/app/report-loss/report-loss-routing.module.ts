import { ReportLossCommonComponent } from './common/report-loss-common.component';
import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { CommentsComponent } from './common/comments/comments.component';


const routes : Routes =  [

  {
    path: '', component: ReportLossCommonComponent,
    children : [
      {
        path: '',  redirectTo: 'report-loss', pathMatch: "full"
      },
      {
        path: 'comments',component: CommentsComponent
      },
      {
        path: 'history',component: CommentsComponent
      },

    ]
  },
  {
    path: 'report-loss:claimId',component: ReportLossCommonComponent
  },
]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class ReportLossRoutingModule { }
