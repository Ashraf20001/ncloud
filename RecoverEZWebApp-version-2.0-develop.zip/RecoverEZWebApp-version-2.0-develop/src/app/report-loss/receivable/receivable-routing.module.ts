import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { ReportLossCommonComponent } from "../common/report-loss-common.component";


const routes : Routes =  [
  {
    path: '', component: ReportLossCommonComponent,
    children : [
      // {
      //   path: 'authority',  component: AuthorityLoginComponent
      // },
      {
        path: '',  redirectTo: 'report-loss', pathMatch: "full"
      },
    ]
  }
]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class ReceivableRoutingModule { }
