import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { ReceivableRoutingModule } from "./receivable-routing.module";
import { ReceivableComponent } from "./receivable.component";

@NgModule({
  declarations:[
    ReceivableComponent
  ],
  imports:[
    CommonModule,
    FormsModule,
    ReceivableRoutingModule,
  ]
})

export class ReceivableModule{

}
