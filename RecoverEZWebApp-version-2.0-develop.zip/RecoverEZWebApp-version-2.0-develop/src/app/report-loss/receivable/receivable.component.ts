import { Component } from '@angular/core';

@Component({
  selector: 'app-receivable',
  templateUrl: './receivable.component.html',
  styleUrls: ['./receivable.component.scss']
})

export class ReceivableComponent{

}
