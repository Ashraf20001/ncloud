export class VerifyCaptchaDetailsDto{
    clear:boolean
    captchaValue:string
    compareCaptchaDataValue:string
  }

export class CaptchaDto{
    captcha:string
    captchaValue:string
    compareCaptchaDataValue:string
  }

export class CaptchaResultDto{
    success:boolean
    code:string
    msg:string
    errorMsg:string
  }