import { FieldValueDTO } from "./field-value-dto";

export interface FieldGroupDTO {
    groupName: string;
    fieldValues: FieldValueDTO[];
    fieldGroups: FieldGroupDTO[];
}
