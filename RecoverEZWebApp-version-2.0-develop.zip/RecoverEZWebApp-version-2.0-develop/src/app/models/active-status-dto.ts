export class ActiveStatusDto{
id : number;
noOfActive : number;
isActive : boolean;
}