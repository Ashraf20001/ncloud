export class DropDownTypeDto{
  value : any
  viewValue : any
  }

  export class DropDownListDto{
    dropDownId : number;
    dropDownName : string;
    dropDownType: number;
    identity:string;
    }