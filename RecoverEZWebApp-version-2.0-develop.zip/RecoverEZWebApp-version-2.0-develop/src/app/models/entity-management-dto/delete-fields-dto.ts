export class DeletedFieldDto{
  sectionName : any;
  fieldId : string[];
  optionIdList : number[];
}