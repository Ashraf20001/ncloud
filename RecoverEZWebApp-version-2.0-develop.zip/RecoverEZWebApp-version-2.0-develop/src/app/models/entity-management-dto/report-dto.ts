import { Field } from "../report-loss-dto/field"

export class ReportDto{
  stage : any
  section : any
  fieldList : Field[] = [];
}