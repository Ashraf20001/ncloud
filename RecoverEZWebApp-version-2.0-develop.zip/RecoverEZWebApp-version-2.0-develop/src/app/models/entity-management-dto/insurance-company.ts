import { MetaDataDto } from "../report-loss-dto/meta-data-dto";
export class InsuranceCompanyDto{
        emInsCompanyId: number;
        emInsName: string;
        emInsPhone: string;
        emInsEmail: string;
        emInsPassword: string;
        emInsLocation: string;
        emInsAddress: string;
        emInsMaxPayableAmount: number;
        emMaxTime: number;
        emInsLogo: string;
        emInsShortName: string;
        emInsIsActive:string;
        emInsCompanyIdentity : string;
        loading: boolean = true;

}
