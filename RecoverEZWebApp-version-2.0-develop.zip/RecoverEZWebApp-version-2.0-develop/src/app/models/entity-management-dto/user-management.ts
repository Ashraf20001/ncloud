import { UserRole } from './userRole';


export class userManagement{
  userName:string;
  emailId:string;
  userId:number;
  addedDate:string;
  status:boolean;
  userIdentity:string;
  userRoleList:UserRole[];
  isDisableUser:boolean;
}
