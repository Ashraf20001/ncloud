export interface PieChartFilterDto {
  label:Array<string>;
  count: Array<string>;
}

export class pieChart{
  content:Array<PieChartFilterDto>
}


