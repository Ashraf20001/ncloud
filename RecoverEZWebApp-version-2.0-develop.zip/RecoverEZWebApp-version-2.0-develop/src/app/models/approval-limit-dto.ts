export class ApprovalLimitDto{
    approvalLimitId:number;
    fieldName:string;
    approvalLevel:ApprovalLevelDto[];
    isActive:string;
    stageName:string;
    sectionName:string;
    role?:string[];
    approvalLimitIdentity : string;
}

export class ApprovalLevelDto{

    roleId:number[];
	minValue:DoubleRange;
     maxValue:DoubleRange;
     roleName:string;

}
