export interface ParentDropdownFieldMap {
    parentFieldName : string;
    childFieldName : string;
}