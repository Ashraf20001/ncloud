export class TotalLoss{
  claimId:string;
  adjustorName1:string;
  surveyDate1:string;
  totalLossAmount1:number;
  adjustorName2:string;
  surveyDate2:string;
  totalLossAmount2:number;
  reasonForTotalLoss:string;
  estimatedTotalLossAmount:number;
  salvageSellerName:string;
  salvageAmount:number;
  salvageBuyerName:string;
  claimIdentity : string;
}