export class RecentClaimsDto{
  claimId : number;
  historyMessage : string;
  claimIdentity : string;
  rePlacableTemplateData: string;
  claimHistoryUniqueCode: string;
}
