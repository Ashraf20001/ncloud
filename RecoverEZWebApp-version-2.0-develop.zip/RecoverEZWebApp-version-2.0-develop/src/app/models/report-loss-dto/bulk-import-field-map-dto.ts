export interface BulkImportFieldMapDTO {
    bulkImportFieldName: string;
    bulkImportAliasName: string;
    isDropDown: boolean;
    isMandatory: boolean;
}
