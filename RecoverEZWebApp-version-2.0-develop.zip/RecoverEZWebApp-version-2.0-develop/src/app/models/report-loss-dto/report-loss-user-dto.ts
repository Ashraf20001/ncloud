export class ReportLossUserDto{
    reportLossId : string;
    receivableUserId: number;
    payableUserId:number;
    identity:string;
}