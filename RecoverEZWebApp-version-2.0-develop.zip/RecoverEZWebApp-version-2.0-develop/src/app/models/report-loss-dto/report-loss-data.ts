import { MetaDataDto } from 'src/app/models/report-loss-dto/meta-data-dto';
export class ReportLossData{
  claimId:string;
  insuredName:string;
  atFaultCompanyName:string;
  receivableAmount:number;
  status:string;
  metaData:MetaDataDto;
  receivable:boolean;
  insurerName:string;
  lastStatus:string;
  totalLossType:string;
  claimSequenceId:string;
  surveyDueHours:string;
  claimIdentity : string;
  currencyType: string;
}
