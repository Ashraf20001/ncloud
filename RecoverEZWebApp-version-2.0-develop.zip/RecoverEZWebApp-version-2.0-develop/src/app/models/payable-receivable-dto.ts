export class PayableReceivableDto{
  companyName:string;
  claimsCount:number;
  notificationStage:number;
  claimInspectionStage:number;
  liabilityConformationStage:number;
  settlementStage:number;
  totalClaimsCount:number;
  totalNotificationStage:number;
  totalClaimInspectionStage:number;
  totalliabilityConformationStage:number;
  totalSettlementStage:number;

}