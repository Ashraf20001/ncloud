export class DisableDto {
    effectiveDate : string;
    identity : string;
  }