export class SchedulerNotificationDto{

  schedularId:number;
  notificationName:string;
  message:string;
  triggeredStatus:string;
  remainder:number;
  action:string;
  isActive:boolean;
}

export class updateDto{
  schedularId:number;
  triggeredStatus:string;
  remainder:number;
}
