export interface DropDownOptionDto {
    optionId: number;
    optionName: string;
    identity: string;
}
