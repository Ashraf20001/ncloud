/* eslint-disable @typescript-eslint/no-unused-vars */
import { CommonResetPasswordComponent } from './common/components/common-reset-password/common-reset-password.component';
import { AuthGuard } from './service/guard/auth.guard';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PagenotfoundComponent } from './common/components/pagenotfound/pagenotfound.component';
import { CommentsComponent } from './report-loss/common/comments/comments.component';

const routes: Routes = [
  {
      path: 'login',
    // canActivate:[AuthGuard],
    loadChildren: () =>
      import('ncloud-common-ui').then((m)=> m.LoginModule)
  },
  {
    path: 'common-reset-password/:userIdentity/:userName',
    component: CommonResetPasswordComponent,
  },
  {
    path: 'dashboard',
    loadChildren: () =>
      import('./dashboard/dashboard.module').then((m) => m.DashboardModule),canActivate: [AuthGuard]
  },
  {
    path: 'receivable-list',
    loadChildren: () =>
      import('./receivable-list/receivable-list.module').then(
        (m) => m.ReceivableListModule
      ),canActivate: [AuthGuard]
  },
  {
    path: 'report-loss',
    loadChildren: () =>
      import('./report-loss/report-loss.module').then(
        (m) => m.ReportLossModule
      ),canActivate: [AuthGuard]
  },
  {
    path: 'payable',
    loadChildren: () =>
      import('./payable-list/payable-list.module').then(
        (m) => m.PayableListModule
      ),canActivate: [AuthGuard]
  },
  {
    path: 'file-upload',
    component: CommentsComponent,
  },
  {
    path: 'report-Data',
    loadChildren: () =>
      import('./reports/reports.module').then((m) => m.ReportsModule),canActivate: [AuthGuard]
  },
  {
    path: 'usermanagement',
    loadChildren: () => import('ncloud-common-ui').then((m) => m.UserManagementModule),
    
    // canActivate: [AuthGuard]
  },
  {
    path:'entitymanagement',
    loadChildren :()=> import('ncloud-common-ui').then((m)=> m.EntityManagementModule)
  },
  { path: 'export-import', 
    loadChildren: () => import('ncloud-common-ui').then(m => m.ExportImportModule) },
  {
    path:'payment',
    loadChildren :()=>
    import('./payment/payment.module').then((m) => m.PaymentModule),canActivate: [AuthGuard],
    data: { skipBreadcrumb : true}
  },
  { path: '', redirectTo: 'login/insurance-company', pathMatch: 'full' },
  {
    path:'page-config',
    loadChildren:()=> import('./page-config/page-config.module').then((m)=> m.PageConfigModule)
  },
 
  // Route for 404 request
  { path: '**', component: PagenotfoundComponent, canActivate: [AuthGuard] },

];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      useHash: true,
      onSameUrlNavigation: 'reload'
    }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
