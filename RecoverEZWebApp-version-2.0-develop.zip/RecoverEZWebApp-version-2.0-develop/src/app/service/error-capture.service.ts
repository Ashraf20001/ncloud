import { EventEmitter, Injectable, Output } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
    providedIn:'root'
})
export class ErrorCaptureService{

    @Output() emitErrorObject = new EventEmitter<Object>();

    private errorObject$ = new BehaviorSubject<any>({});
    selectederrorObject$ = this.errorObject$.asObservable();

    setErrorObject(product: any) {
        this.errorObject$.next(product);
        this.emitErrorObject.emit(product);
    }

    passErrorObject(element:Object) {
    }
}