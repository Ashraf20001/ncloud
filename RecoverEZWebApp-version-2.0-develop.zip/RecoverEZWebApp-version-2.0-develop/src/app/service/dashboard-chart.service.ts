import { EventEmitter, Injectable, Output } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from './../../environments/environment';
import { AdminService } from './admin.service';

@Injectable({
  providedIn: 'root'
})
export class DashboardChartService {
  // stackedBarChartData() {
  //   throw new Error('Method not implemented.');
  // }
  // horizontalBarChartData() {
  //   throw new Error('Method not implemented.');
  // }

  apiurl = environment.API_BASE_URL+"/recovery" ;
  @Output() isCheck= new EventEmitter<boolean>();
  currencyValueChangeEvent = new EventEmitter<number>();

  constructor(private http: HttpClient, private adminService: AdminService){
  }

  checkUserIsAdmin(): boolean {
    return this.adminService.isAssociationUser();
  }

  //get bar chart data from get api's based on filters
  barChartData(data:InsuredAndTpArray,xlab:string,xval:string,ylab:string,yval:number,selectedCurrencyId: number):any{
    if (this.checkUserIsAdmin()) {
      return this.http.post<any>(this.apiurl + '/dashboard-chart/bar-chart-data-filter?xlabel='+xlab+'&xvalue='+xval+'&ylabel='+ylab+'&yvalue='+yval+'&cur='+selectedCurrencyId,data);
    }else{
    return this.http.post<any>(this.apiurl + '/dashboard-chart/total-receivables-payables?xlabel='+xlab+'&xvalue='+xval+'&ylabel='+ylab+'&yvalue='+yval+'&cur='+selectedCurrencyId,{});
    }
  }

	getbychartData(data:InsuredAndTpArray,isReceivable:Boolean, selectedCurrencyId: number){
    if(isReceivable==undefined){
      isReceivable=true;
    }
    if (this.checkUserIsAdmin()) {
      return this.http.post<any>(this.apiurl + '/dashboard-chart/pie-chart-data-filter?isReceivable='+isReceivable+'&cur='+selectedCurrencyId,data);
    }else{
      return this.http.post<any>(this.apiurl + '/dashboard-chart/receivable-claim-count?isReceivable='+isReceivable+'&cur='+selectedCurrencyId,{});
    }
 }

 getHorizontalbar(data:InsuredAndTpArray,isReceivable:Boolean, selectedCurrencyId: number){
  if(isReceivable==undefined){
    isReceivable=true;
  }
  if (this.checkUserIsAdmin()) {
    return this.http.post<any>(this.apiurl + '/dashboard-chart/horizontal-chart-data-filter?isReceivable='+isReceivable+'&cur='+selectedCurrencyId,data)
  }else{
    return this.http.post<any>(this.apiurl + '/dashboard-chart/top-recovery?isReceivable='+isReceivable+'&cur='+selectedCurrencyId,{})

  }

 }

 getverticalbardata(data:InsuredAndTpArray,isReceivable:Boolean, selectedCurrencyId: number){
  if(isReceivable==undefined){
    isReceivable=true;
  }
  if (this.checkUserIsAdmin()) {
    return this.http.post<any>(this.apiurl + '/dashboard-chart/pending-receivables-filter?isReceivable='+isReceivable+'&cur='+selectedCurrencyId,data)
  }else{
    return this.http.post<any>(this.apiurl + '/dashboard-chart/pending-receivables?isReceivable='+isReceivable+'&cur='+selectedCurrencyId,{})

  } }

 stackedBarChartData(data:InsuredAndTpArray,isReceivable:boolean, selectedCurrencyId: number){
  if(isReceivable==undefined){
    isReceivable=true;
  }
  if (this.checkUserIsAdmin()) {
    return this.http.post<any>(this.apiurl + '/dashboard-chart/non-settled-claims-filter?isReceivable='+isReceivable+'&cur='+selectedCurrencyId,data)
  }else{
    return this.http.post<any>(this.apiurl + '/dashboard-chart/non-settled-claims?isReceivable='+isReceivable+'&cur='+selectedCurrencyId,{})
  }  
}

  toggleTrueOrNot(value:boolean){
    this.isCheck.emit(value);
  }
}

export class InsuredAndTpArray{
  insurenceCompanyNames:string[];
  tpCompanyNames:string[];
}
