import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { SchedulerNotificationDto, updateDto } from '../models/scheduler-dto';

@Injectable({
  providedIn: 'root'
})
export class SchedulerService {
  baseUrl = environment.API_BASE_URL ;
  scheduler:any[]=[]



  constructor(
    private http:HttpClient
  ) { }

 public savedata(schedulerNotificationDto:SchedulerNotificationDto){
   return this.http.post(this.baseUrl+"/recovery/update-scheduler-details",schedulerNotificationDto);

 }

 public getedit(value:number){
  return this.http.get(this.baseUrl+"/recovery/get-scheduler-details-by-id?schedularId="+ value);
 }

  public getschedulerdetail(){

      return this.http.get(this.baseUrl+"/recovery/get-scheduler-details");


    }
}


