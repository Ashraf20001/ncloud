import { EventEmitter, Injectable, Output } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LanguageService {
  // eslint-disable-next-line @typescript-eslint/ban-types
  @Output()emitlangObject = new EventEmitter<Object>();
  private langObject$=new BehaviorSubject<any>({});
  selectedLangObject$= this.langObject$.asObservable();
  setlanguageObject(lang:any){
    this.langObject$.next(lang);
    this.emitlangObject.emit(lang);
  }

}
