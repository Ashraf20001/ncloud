import { MenuDto } from './../models/user-role-management/menu-dto';
import { userPageDto } from './../models/user-role-management/user_pageDto';
/* eslint-disable prefer-const */
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { UserRolePage } from './../models/user-role-management/user-role-pageDto';
import { UserRoleDto } from './../models/user-role-management/userRoleDto';
import { MetaDataDto } from 'src/app/models/report-loss-dto/meta-data-dto';
import { RoleDto, UserDto } from './../models/user-role-management/role-dto';
/* eslint-disable @typescript-eslint/no-empty-function */
import { FieldGroupDTO } from './../models/field-group-dto';
import { Field } from './../models/report-loss-dto/field';
import { FieldDTO } from './../models/field-dto';
import { FieldValueDTO } from './../models/field-value-dto';
import { Section } from './../models/report-loss-dto/section';
import { BehaviorSubject, of } from 'rxjs';
import { Injectable } from '@angular/core';
import { DisableDto } from '../models/disable-dto';
import { ActiveStatusDto } from '../models/active-status-dto';
@Injectable({
  providedIn: 'root'
})
export class UserManagementService {

  private baseUrl = environment.API_BASE_URL;

  constructor(private http: HttpClient) { }


  private ClickAddnew = new BehaviorSubject<boolean>(false);

  public ClickAdd$ = this.ClickAddnew.asObservable();


  getAccessMappingDetails(pageid:string,userRoleId:string){
    if (userRoleId!==null) {
      return this.http.get<any>(this.baseUrl + "/api/get-role-page-info?page_id="+ pageid + "&role_id="+ userRoleId)
    }else{
      return this.http.get<any>(this.baseUrl + "/api/get-role-page-info?page_id="+ pageid)

    }
  }

  sendUserRoleData(data:MetaDataDto,accessMap:RoleDto,isActive:boolean){
    const fieldGroupDTO: FieldGroupDTO = this.convertToFieldGroup(data.sectionList,UserManagementService.USER_MANAGEMENT_ROLE__GROUP_NAME);
    const sendUserRoleDetails = new UserRolePage();

    sendUserRoleDetails.isActive = isActive;
    sendUserRoleDetails.roleDetails = fieldGroupDTO;
    sendUserRoleDetails.accessMapping = accessMap;
    // http://localhost:9090/api/user-role/saveOrUpdate?role_id=22
    return this.http.post(this.baseUrl + "/api/user-role/saveOrUpdate",sendUserRoleDetails)
  }

  sendUserData(data:MetaDataDto,notification:MenuDto[],isActive:boolean){
    const fieldGroupDTO: FieldGroupDTO = this.convertToFieldGroup(data.sectionList,UserManagementService.USER_MANAGEMENT_GROUP_NAME);
    const sendUserDetails = new userPageDto();
    const userDto = new UserDto()
    userDto.menuData = notification;
    sendUserDetails.isActive = isActive;
    sendUserDetails.userDetails = fieldGroupDTO;
    sendUserDetails.enableNotification = userDto;
    return this.http.post(this.baseUrl + "/api/user-management/saveOrUpdate",sendUserDetails)
    // console.log(sendUserDetails);


    // return null;
  }

  private static USER_MANAGEMENT_ROLE__GROUP_NAME = 'UserRoleManagementDto';
  private static USER_MANAGEMENT_GROUP_NAME = 'UserManagementDto';
  private convertToFieldGroup(sectionList: Section[],groupName:string): FieldGroupDTO {
    const fieldGroupDTO: FieldGroupDTO = {
      groupName: groupName,
      fieldValues: [],
      fieldGroups: []
    };

    sectionList.forEach((section: Section) => {
      this.getFieldGroupDTO(section, fieldGroupDTO);
    });
    return fieldGroupDTO;
  }

  private getFieldGroupDTO(section: Section, parentFieldGroup: FieldGroupDTO): FieldGroupDTO {
    if(section !== undefined && section !== null) {
      const fieldGroup: FieldGroupDTO = {
        groupName: section.sectionName,
        fieldValues: [],
        fieldGroups: []
      };
      if(section.fieldList && section.fieldList.length > 0) {
        section.fieldList.forEach((field: Field) => {
          const fieldDTO: FieldDTO = {
            fieldId: field.fieldId,
            fieldName: field.fieldName,
            fieldType: field.fieldType,
            fieldDefault: field.defaultValues
          };
          const fieldValueDTO: FieldValueDTO = {
            field: fieldDTO,
            value: field.value
          };
          fieldGroup.fieldValues.push(fieldValueDTO);
        });
      }
      // console.log('parent - ', parentFieldGroup, 'child - ', fieldGroup);
      if(section.sectionList && section.sectionList.length > 0) {
        section.sectionList.forEach((subSection: Section) => {
          this.getFieldGroupDTO(subSection, fieldGroup);
        });
      }
      parentFieldGroup.fieldGroups.push(fieldGroup);
    }
    return parentFieldGroup;
  }

  getCardDetails(min:number,max:number){
    return this.http.get<CardDetails>(this.baseUrl + "/api/get-role-card"+'?min=' + min+'&max='+max);
  }

  getTotalCountForUserRole(){
    return this.http.get<CardDetails>(this.baseUrl + "/api/get-role-list-count");
  }

   getUserDetails(pageId:string,userIdentity:string){

    if (userIdentity!==null) {
      return this.http.get<any>(this.baseUrl + "/api/get-user-management-page-info?page_id="+ pageId + "&user_id="+ userIdentity)
    }else{
      return this.http.get<any>(this.baseUrl + "/api/get-user-management-page-info?page_id="+ pageId)

    }
  }

  getUserManagementTableList(min:number,max:number){

    return this.http.get<any>(this.baseUrl + "/api/get-user-management-list"+'?min=' + min+'&max='+max)
  }

  getUserManagementTableCount(){

    return this.http.get<any>(this.baseUrl + "/api/get-user-management-count")
  }

  deleteUserDetails(disableDto: DisableDto){
    return this.http.post(this.baseUrl + "/api/user-management/deleteUser",disableDto);
  }

  // deleteUserRoleDetails(id:number){
  //   return this.http.post(this.baseUrl + "/api/user-role/deleteRole?role_id="+id,{})
  // }


  getPageBasedOnRoles(list:number[]){
    const listOfRole = new ListOfRoles();
    listOfRole.listOfRoles = list;
    return this.http.post<any>(this.baseUrl + "/api/user-management/showPages"  ,listOfRole)
  }


  downloadUserExcelList(){
   return this.http.get(this.baseUrl + "/api/user-management/download-excel" , {responseType: 'blob'})
  }


  downloadRoleExcelList(){
    return this.http.get(this.baseUrl + "/api/user-role/download-excel" , {responseType: 'blob'})
   }

   setAddNew(value:boolean){
      return this.ClickAddnew.next(value);
  }
 /*
 * DISABLE USER ROLE
 */
  disableUserRole(disableDto: DisableDto) {
    return this.http.post<ActiveStatusDto>(this.baseUrl + "/api/user-role/deleteRole"  ,disableDto);
  }
}

export class CardDetails{
  roleId:number;
  roleName:string;
  description:string;
  userCount:number;
  isActive:boolean;
  inActiveDate:string;
  isMapped:boolean;
  roleIdentity:string;
  isDisableRole:boolean;
  isDeleted:boolean;
}

export class ListOfRoles{
  listOfRoles:number[];
}
