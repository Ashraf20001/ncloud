import { HttpClient} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ParentDropdownFieldMap } from '../models/report-loss-dto/parentDropdownField';

@Injectable({
  providedIn: 'root'
})
export class DropDownServiceService {

  private baseUrl = environment.API_BASE_URL+"/recovery"

  constructor(private http:HttpClient) { }

  private parentFieldMap :ParentDropdownFieldMap[];
    getParentFieldMap():Observable<any>{
      return this.http.get<any>(this.baseUrl+"/report/getDropDownFieldMap");
    }

    // getChildFieldName(parentFieldName: string): string {
    //   const childFieldObject = this.parentFieldMap.find((data) => data.parentFieldName === parentFieldName);
    //    if(childFieldObject) {
    //   return childFieldObject.childFieldName;
    //  }
    //    return '';
    // }

  public getOption(fieldIdentity:string, fieldValue:string,fieldName:any):Observable<any>{
      return this.http.get(this.baseUrl+"/report/getDropDownData?fieldIdentity="+fieldIdentity+'&fieldValue='+fieldValue+'&fieldName='+fieldName);
  }
  public getDropDownOptionList(dropDownListId:string){
    return this.http.get(this.baseUrl+"/page-config/drop-down/option?dropDownListId="+ dropDownListId);
 }
  getContactDetails(garageName: string) {
    return this.http.get(environment.API_BASE_URL+"/api/get-contact-detail?garageName="+garageName);
  }

}
