import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";
import { PayReportReqDto } from "../reports/reports-card/reports-card.component";
import { PaymentDto } from "../models/reports-dto/PaymentDto";

const baseUrl = environment.API_BASE_URL+"/recovery";
@Injectable({
  providedIn: 'root'
})
export class PaymentService{
    constructor(private http: HttpClient) { }
    /*
    * Get PayementDetails Count
    */
    getPayementDetailsCount(){
        return this.http.get<number>(baseUrl+'/report/payment-details-count');
    }
    /*
    * Get PayementDetails List
    */
    getPayementDetailsList(min:number,max:number){
        return this.http.get<number>(baseUrl+'/report/get-payment-details?min='+min +'&max='+max);
    }
    /*
  * Get ComapnyAmount Data
  */
   getComapnyAmountData(payReportReqDto: PayReportReqDto) {
    return this.http.post(baseUrl+"/report/pay-report" ,payReportReqDto);
   }
   /*
   * Save Payment
   */
   savePayment(paymentDto: PaymentDto) {
     return this.http.post(baseUrl+"/report/save-payment" ,paymentDto);
   }
}