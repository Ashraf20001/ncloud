import { HttpClient } from '@angular/common/http';
import { EventEmitter, Injectable, Output } from '@angular/core';
import { environment } from 'src/environments/environment';
import { ConstantService } from './constants.service';
import { InsuredAndTpArray } from './dashboard-chart.service';
@Injectable({
  providedIn: 'root',
})
export class DashboardService {
  baseUrl = environment.API_BASE_URL;
  constructor(private http: HttpClient) {}
  @Output() isCheck = new EventEmitter<boolean>();

  reportForList() {
    return this.http.get(
      this.baseUrl + ConstantService.dashboard + ConstantService.reportList
    );
  }

  /**
   *
   * @param param
   * @returns
   */
  getLoggedInUserCompanyId(param: any) {
    return this.http.get(this.baseUrl + '/api/company/get-company', {
      params: param,
    });
  }

  getRecentClaim(param: any, companyList: InsuredAndTpArray) {
    return this.http.post<any>(
      this.baseUrl + '/recovery/dashboard-chart/getRecentClaims',
      companyList,
      { params: param }
    );
  }
  
  toggleTrueOrNot(value: boolean) {
    this.isCheck.emit(value);
  }

  getCompanyLogo(id: string) {
    return this.http.get(
      this.baseUrl + '/api/company/get-logo?companyId=' + id
    );
  }

  getCurrencyDropDownData() {
    return this.http.get(this.baseUrl + '/recovery/dashboard/currency-types');
  }
}
