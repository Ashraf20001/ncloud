import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";
import { VerifyCaptchaDetailsDto } from "../models/captcha-dto";

@Injectable({
    providedIn: 'root'
})
export class CaptchaService {
    

  private baseUrl = environment.API_BASE_URL;

  constructor(private http: HttpClient) { }

    generateCaptcha(): any {
        return this.http.post(this.baseUrl+'/auth-service/auth/generate-captcha',{});
    }

    validateCaptcha(verifyCaptchaDetailsDto:VerifyCaptchaDetailsDto): any {
        return this.http.post(this.baseUrl+'/auth-servce/auth/validate-captcha',verifyCaptchaDetailsDto);
    }
}
