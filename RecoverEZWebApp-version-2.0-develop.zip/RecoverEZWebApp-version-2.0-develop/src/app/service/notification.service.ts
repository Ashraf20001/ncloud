import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment} from "src/environments/environment";
import { NotificationDTO } from '../models/notification-dto';
const baseUrl = environment.API_BASE_URL;
@Injectable({
  providedIn: 'root'
})
export class NotificationService {

constructor(private http: HttpClient) { }

/**
 * NOTIFICATION LIST
 * @returns
 */
getNotificationList(): Observable<NotificationDTO[]>{
  return this.http.get<NotificationDTO[]>(baseUrl+'/recovery/claim/notification');
}
/**
 * NOTIFICATION COUNT
 * @returns
 */
getNotificationCount(){
  return this.http.get(baseUrl+'/recovery/notification/count');
}

updateNotification(approvalId:number){
  return this.http.get(baseUrl+'/recovery/notification/update?approvalId='+ approvalId);
}

}
