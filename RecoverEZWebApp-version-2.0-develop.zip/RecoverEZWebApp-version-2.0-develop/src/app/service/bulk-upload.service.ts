import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SortingDto } from '../receivable-list/receivable-list-card/receivable-bulk-history/totalrecords-popup/totalrecords-popup.component';
import { BulkImportFieldMapDTO } from '../models/report-loss-dto/bulk-import-field-map-dto';

@Injectable({
  providedIn: 'root'
})
export class BulkUploadService {
  private baseUrl = environment.API_BASE_URL+ "/recovery/report-loss/bulk-import/download-sample-excel";

  private errorHistoryurl = environment.API_BASE_URL + "/recovery/report-loss/bulk-import/import-history";
  private downloadErrorHistoryUrl = environment.API_BASE_URL + "/recovery/report-loss/bulk-import/error-data";
  private bulkUploadUrl = environment.API_BASE_URL + "/recovery/report-loss/bulk-import/excel";
  private errorHistoryListUrl = environment.API_BASE_URL + "/recovery/report-loss/bulk-import/get-error-data-list";
  private successHistoryListUrl = environment.API_BASE_URL + "/recovery/report-loss/bulk-import/get-success-data-list";
  private downloaderrorHistoryDataUrl = environment.API_BASE_URL + "/recovery/report-loss/bulk-import/download-error-data-excel";
  private deleteErrorHistoryDataUrl = environment.API_BASE_URL + "/recovery/auth/report-loss/bulk-import/Delete";

  private bulkImportFieldMapListUrl = environment.API_BASE_URL + '/recovery/report-loss/get-bulk-import-field-map';

  constructor(private http: HttpClient) { }

  downLoadSampleExcelFile(){
   return this.http.get(this.baseUrl, {responseType: 'blob'});
  }


  getErrorHistory(){
    return this.http.get<any>(this.errorHistoryurl);
  }

  downloaderrorData(id:string){
    return this.http.get(this.downloadErrorHistoryUrl + '?upload_id='+id, {responseType: 'blob'});
  }

  bulkUpload(file){
    const pageId = 'sdjashbsdadajdkui';
     const formData = new FormData();
     formData.append("bulk_import_file", file);
     return this.http.post(this.bulkUploadUrl+'?page_id=' + pageId, formData)
  }
 /*
  * Get BulkUpload Error Data
  */
  getBulkUploadErrorData(uploadId:number,sortingDto:SortingDto){
    return this.http.post<any>(this.errorHistoryListUrl + '?uploadId=' + uploadId, sortingDto);
  }

  /*
   * Get BulkUpload Success Data
   */
  getBulkUploadSuccessData(uploadId:number,sortingDto:SortingDto){
     return this.http.post<any>(this.successHistoryListUrl + '?uploadId=' + uploadId ,sortingDto);
   }
  /*
  * Get ErrorData Excel
  */
  getErrorDataExcel(uploadId:number, isSuccessData:boolean){
    return this.http.get(this.downloaderrorHistoryDataUrl + '?uploadId='+uploadId +'&isSuccessData='+isSuccessData, {responseType: 'blob'});
  }
  /*
  * Delete ErrorData 
  */
  deleteErrorData(uploadIdentity:string){
    return this.http.get<any>(this.deleteErrorHistoryDataUrl+'?uploadIdentity='+uploadIdentity);
  }

  getBulkImportFieldMapList(): Observable<BulkImportFieldMapDTO[]> {
    return this.http.get<BulkImportFieldMapDTO[]>(this.bulkImportFieldMapListUrl);
  }
}
 
export class ErrorHistory{
  uploadId:number;
  successCount:number;
  failureCount:number;
  totalCount:number;
  status:string;
  pageId:number;
  createdBy:string;
  createdDate:string;
  identity:string;
}
