export const appConst = {

  PAGE_NAME: {
    DASHBOARD:
    {
      RECEIVABLE_DASHBOARD: {
        PAGENAME: 'dashboard',
        PAGEID: 2,
        PAGE_IDENTITY: 'rcvybunimokvybuv',
        BUTTON_ACCESS : {
          QUICKLINKS: 'Quick Links'
        }
      },
      PAYABLE_DASHBOARD: {
        PAGENAME: 'dashboard',
        PAGEID: 29,
        PAGE_IDENTITY: '0189b4a60b634f9da710f8a9904264a4',
        BUTTON_ACCESS: {
          QUICKLINKS: 'Quick Links'
        }
      }
    },
    RECEIVABLE: {
      RECEIVABLE_CARD:
      {
        PAGENAME: 'receivablecard',
        PAGEID: 3,
        PAGE_IDENTITY: 'mntbrvefjynthbgvfcd',
        BUTTON_ACCESS : {
          VIEWRECEIVABLE: 'View Receivable',
          REPORTALOSS:'Report Loss',
          DOWNLOAD: 'Download Receivable',
          DELETE:"Delete",
          EDIT:"Edit"
        }
      },
      RECEIVABLE_LIST:
      {
        PAGENAME: 'receivablelist',
        PAGEID: 7,
        PAGE_IDENTITY: 'ef1bcae549bf45de9d1e315aab6e83d8',
        BUTTON_ACCESS : {
          DELETE:"Delete",
          EDIT:"Edit"
        }
      },
      RECEIVABLE_REPORTLOSS:
      {
        PAGENAME: 'reportloss',
        PAGEID: 1,
        PAGE_IDENTITY: 'sdjashbsdadajdkui',
        BUTTON_ACCESS : {
          ACCEPT: 'Accept',
          REJECT:'Reject',
          NEED_MORE_DETAILS: 'Need Info',
          SAVE: 'Submit',
          ASSIGN_SURVEYOR: 'Assign Surveyor',
          DISPUTE: 'Dispute',
          DETAILS_PROVIDED: 'Provide Details',
          REOPEN: 'Rejected Reopen',
          APPROVED: 'Approve',
          RESUBMIT: 'Resubmit',
          DISPUTE_REOPEN: 'Reopen',
          REPORT_LOSS_COMMON_SAVE: 'Save',
          CANCEL: 'Cancel'
        }
      }
    },
    PAYABLE: {
      PAYABLE_CARD:
      {
        PAGENAME: 'payablecard',
        PAGEID: 4,
        PAGE_IDENTITY: 'cvbntfyntbrvecd',
        BUTTON_ACCESS : {
          VIEWPAYABLE: 'View Payable',
          DOWNLOAD: 'Download Payable'
        }
      },
      PAYABLE_LIST:
      {
        PAGENAME: 'payablelist',
        PAGEID: 8,
        PAGE_IDENTITY: '1ccec1083cdd4bdc94103c41e2c19741',
        BUTTON_ACCESS : {
          DELETE:"Delete",
          EDIT:"Edit"
        }
      },
      PAYABLE_REPORTLOSS:
      {
        PAGENAME: 'reportloss',
        PAGEID: 31,
        PAGE_IDENTITY: 'sdjashbsdadajdkui222',
      }
    },
    REPORTS: {
      REPORTS_CARD:
      {
        PAGENAME: 'reportscard',
        PAGEID: 5,
        PAGE_IDENTITY: 'rvynrtvybunicvn',
        BUTTON_ACCESS : {
          GENERATE_REPORT: 'Generate Report',
          DOWNLOAD: 'Report Download',
          EDIT: 'Report Edit',
          PAY: 'Pay'
        }
      },
      REPORTS_GENERATE:
      {
        PAGENAME: 'reportsgenerate',
        PAGEID: 9,
        PAGE_IDENTITY: '4c306b3a92224b79b0cd9eab82fd13a8',
        BUTTON_ACCESS : {
          GENERATE_REPORT: 'Generate Report',
          PREVIEW_REPORT: 'Preview Report'
        }
      },
    },
    USERMANAGEMENT: {
      USERMANAGEMENT_USERROLE : {
        USERMANAGEMENT_USERROLE_CARD:
        {
          PAGENAME: 'usermanagementuserrolecard',
          PAGEID: 6,
          PAGE_IDENTITY: 'xcvybunijoksxdctvyu',
          BUTTON_ACCESS : {
            ADDNEW: 'Add User Role',
            EDIT: 'Edit User Role',
            DELETE: 'Disable User Role',
            CLONE: 'Clone User Role'
          }
        },
        USERMANAGEMENT_USERROLE_LIST:
        {
          PAGENAME: 'usermanagementuserrolelist',
          PAGEID: 10,
          PAGE_IDENTITY: '5a843f1272854675a4f9d42e7cde82b1',
          BUTTON_ACCESS : {
            ADDNEW: 'Add User Role',
            EDIT: 'Edit',
            DELETE: 'Disable',
            CLONE: 'Clone'
          }
        },
        USERMANAGEMENT_USERROLE_ADD:
        {
          PAGENAME: 'usermanagementuserroleaddedit',
          PAGEID: 11,
          PAGE_IDENTITY: 'c1f3da8cbd12424ab1a729fc045455d6',
          BUTTON_ACCESS : {
            SAVE:'Save User Role',
          }
        },
      },
      USERMANAGEMENT_USER : {
        USERMANAGEMENT_USER_CARD:
        {
          PAGENAME: 'usermanagementusercard',
          PAGEID: 12,
          PAGE_IDENTITY: '7dec9f37fc944f6193fa24f8d0a02483',
          BUTTON_ACCESS : {
            ADDNEW: 'Add New User',
            EDIT: 'Edit User',
            DELETE: 'Disable User',
            CLONE: 'Clone User'
          }
        },
        USERMANAGEMENT_USER_LIST:
        {
          PAGENAME: 'usermanagementuserlist',
          PAGEID: 13,
          PAGE_IDENTITY: 'adfcecc47f3848d49be20c243c32a418',
          BUTTON_ACCESS : {
            ADDNEW: 'Add New User',
            EDIT: 'Edit User',
            DELETE: 'Delete User',
            CLONE: 'Clone User'
          }
        },
        USERMANAGEMENT_USER_ADD:
        {
          PAGENAME: 'usermanagementuseraddedit',
          PAGEID: 14,
          PAGE_IDENTITY: '8b891619527447b38b2090890cf14cc8',
          BUTTON_ACCESS : {
            SAVE:'Save User',
          }
        },
      },
      USERMANAGEMENT_APPROVALLIMIT : {
        USERMANAGEMENT_APPROVALLIMIT_CARD:
        {
          PAGENAME: 'usermanagementapprovallimitcard',
          PAGEID: 15,
          PAGE_IDENTITY: '5dd111e036214c65b31da2e2150adad5',
          BUTTON_ACCESS : {
            ADDNEW: 'Add New Approval Limit',
            EDIT: 'Edit Approval Limit',
            DELETE: 'Delete Approval Limit',
            CLONE: 'Clone Approval Limit'
          }
        },
        USERMANAGEMENT_APPROVALLIMIT_LIST:
        {
          PAGENAME: 'usermanagementapprovallimitlist',
          PAGEID: 16,
          PAGE_IDENTITY: 'f2cd3a53cf5e42f080eb52fd4865f726',
          BUTTON_ACCESS : {
            ADDNEW: 'Add New Approval Limit',
            EDIT: 'Edit Approval Limit',
            DELETE: 'Delete Approval Limit',
            CLONE: 'Clone Approval Limit'
          }
        },
        USERMANAGEMENT_APPROVALLIMIT_ADD:
        {
          PAGENAME: 'usermanagementapprovallimitaddedit',
          PAGEID: 17,
          PAGE_IDENTITY: 'f921882c0b214238a87ffb34b4540e1f',
          BUTTON_ACCESS : {
            SAVE:'Save Approval Limit',
          }
        },
      }
    },
    PAGECONFIGURATOR:
    {
      PAGE_CONFIGURATOR_CARD:
      {
        PAGENAME: 'pageconfiguratorcard',
        PAGEID: 18,
        PAGE_IDENTITY: '9613e9d92f94483fbf3e3eac6462297b',
        BUTTON_ACCESS : {
          LAUNCHINPORTAL: 'Launch in Portal',
        }
      },
      FIELD_CONFIGURATOR:
      {
        PAGENAME: 'fieldconfigurator',
        PAGEID: 19,
        PAGE_IDENTITY: 'f1a5a9b8b5a742e09dadcc1cca6a5a03',
        BUTTON_ACCESS : {
          SAVE:'Save',
        }
      },
      SCHEDULER:
      {
        SCHEDULER_CARD:
        {
          PAGENAME: 'schedularcard',
          PAGEID: 20,
          PAGE_IDENTITY: 'c741ae6b5c3a49b888d2592a51c6b580',
          BUTTON_ACCESS : {
            EDIT: 'Edit',
            DELETE: 'Delete'
          }
        },
        SCHEDULER_LIST:
        {
          PAGENAME: 'schedulerlist',
          PAGEID: 23,
          PAGE_IDENTITY: '4248cdbc93874202ba335b9d7dafeee7'
        },
        SCHEDULER_ADD:
        {
          PAGENAME: 'scheduleraddedit',
          PAGEID: 24,
          PAGE_IDENTITY: '04ed8fab9bd345ff9d9ffaa7915cd086',
          BUTTON_ACCESS : {
            SAVE:'Save',
          }
        }
      }
    },
    ENTITYMANAGEMENT:
    {
      INSURANCECOMPANY:
        {
        INSURANCECOMPANY_CARD:
          {
            PAGENAME: 'emcompanycard',
            PAGEID: 21,
            PAGE_IDENTITY: '6e1af0b2a37c422eade138c7cc255e44',
            BUTTON_ACCESS : {
              ADD: 'Insurance Company Add',
              EDIT: 'Insurance Company Edit',
              CLONE: 'Insurance Company Clone',
              DELETE: 'Insurance Company Delete'
            }
          },
        INSURANCECOMPANY_LIST:
          {
            PAGENAME: 'emcompanylist',
            PAGEID: 25,
            PAGE_IDENTITY: 'b316494470ac4803a5fced114f048b96'
          },
        INSURANCECOMPANY_ADD:
          {
            PAGENAME: 'emcompanyaaddedit',
            PAGEID: 26,
            PAGE_IDENTITY: '29',
            BUTTON_ACCESS : {
              Save: 'Insurance Company Save'
            }
          },
        },

      GARAGE:
      {
        GARAGE_CARD:
          {
            PAGENAME: 'emgaragecard',
            PAGEID: 22,
            PAGE_IDENTITY: 'b981ad80c6654124b394ed390fdb0a0d',
            BUTTON_ACCESS : {
              ADD: 'Garage Add',
              EDIT: 'Garage Edit',
              CLONE: 'Garage Clone',
              DELETE: 'Garage Disable'
            }
          },
        GARAGE_LIST:
          {
            PAGENAME: 'emgaragelist',
            PAGEID: 27,
            PAGE_IDENTITY: 'b316494470ac4803a5fced114f048b96'
          },
        GARAGE_ADD:
          {
            PAGENAME: 'emgarageaaddedit',
            PAGEID: 28,
            PAGE_IDENTITY: '30',
            BUTTON_ACCESS : {
              Save: 'Garage Save'
            }
          },
      },
      
   
    },
    PAYMENT: {
      PAYMENT_DETAILS_LIST:
      {
        PAGENAME: 'payment_details',
        PAGEID: 54,
        PAGE_IDENTITY: '815602dc-f36b-11ef-9dd1-c8f750208afd',
        BUTTON_ACCESS : {
          APPROVE: 'Approve',
          REJECT: 'Reject',
          PAY:"Pay",
          PROCEEDTOPAY:'ProceedToPay',
          VIEW: 'View'
        }
      },
    },
   
  },

  MENU_CONSTANTS:
  {
    MENUNAME:{
      DASHBOARD :{
        NAME:'Dashboard',
        URL:'/dashboard/dash'
      } ,
      PAGECONFIGURATOR : {
        NAME:'Page Configurator',
        URL:'/page-config/field-configure'
      } ,
      REPORTLOSS:{
        NAME: 'Report Loss',
        URL: '/report-loss'
      } ,
      RECEIVABLE: {
        NAME:'Receivable',
        URL:'/receivable-list'
      } ,
      PAYABLE: {
        NAME:'Payable',
        URL:'/payable/Payable-card'
      },
      ENTITYMANAGEMENT:{
        NAME:'Entity Management',
        URL:'/entitymanagement'
      } ,
      REPORTS:{
        NAME:'Reports',
        URL:'/report-Data/reports-card'
      } ,
      USERMANAGEMENT:{
        NAME:'User Management',
        URL:'/usermanagement'
      } ,
      PAYMENT:{
        NAME:'Payment',
        URL:'/payment/paymentList'
      }
      ,EXPORTIMPORT:{
        NAME:'Export and Import',
        URL:'/export-import/export-import-card'
      }
    }
  }

};
