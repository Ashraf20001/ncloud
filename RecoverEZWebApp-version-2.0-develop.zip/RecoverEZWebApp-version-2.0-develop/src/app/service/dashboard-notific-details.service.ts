import { InsuredAndTpArray } from './../dashboard-charts/dashbord-claim-details/dashboard-claim-details.component';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from './../../environments/environment';
const BaseUrl = environment.API_BASE_URL;
@Injectable({
  providedIn: 'root'
})
export class DashboardNotificDetailsService {

constructor(private http: HttpClient) { }

/**
 * RECEIVABLE GET METHOD
 * @returns
 */
getdashboardnotificationForReceivable(listCompany:InsuredAndTpArray, selectedCurrencyId: number){
  return this.http.post(BaseUrl + '/recovery/dashboard/receivable-details?cur='+selectedCurrencyId,listCompany);
}
/**
 * PAYABLE GET METHOD
 * @returns
 */
getdashboardnotificationForPayable(listCompany:InsuredAndTpArray, selectedCurrencyId: number){
  return this.http.post(BaseUrl+ '/recovery/dashboard/payable-details?cur='+selectedCurrencyId,listCompany);
}
}
