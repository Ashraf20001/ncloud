/* eslint-disable @typescript-eslint/no-empty-function */
import { ResetPasswordRequest } from './../models/reset-password-request';
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable no-var */
/* eslint-disable prefer-const */
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from './../../environments/environment';
import { ActivatedRoute, Router } from '@angular/router';
import { EmailDto } from 'ncloud-common-ui';


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  loginResponse:any;
  currentLanguage: string;

  constructor(private http:HttpClient,private router:Router,) { }

  apiurl =  environment.API_BASE_URL+'/api/auth/signin'// authentication url from backend
// apiurl = 'http://10.10.12.43:8500/api/auth/signin'
  // const BASE_API_URL =  + this.apiurl


   resetFirstTimeUrl = environment.API_BASE_URL + '/api/auth/resetpassword'

   sendMailIdToResetPasswordUrl = environment.API_BASE_URL + '/api/auth/forgetPassword'

   commonResetPasswordUrl = environment.API_BASE_URL + '/api/auth/updatepassword'




  // connecting backend and verifing user credentials
  ProceedLogin(username:string,password:string){
  return this.http.post(this.apiurl,{username,password})

  }


  //checking user is still loggedin or not
  IsLoggedIn(){
    let myCurrentToken = sessionStorage.getItem('token')!= null
    return myCurrentToken;
  }


  //checking jwt oken is still in session storage
  GetToken(){
    return sessionStorage.getItem('token');
  }


  //getting role details from payload of jwt token
  HaveAccess(){
    var logintoken = sessionStorage.getItem('token')||'';
    var _extractedtoken=logintoken.split('.')[1];
    var _atobdata=atob(_extractedtoken);
    var _finaldata=JSON.parse(_atobdata);
    if(_finaldata.role=='admin'){
      return true
    }else{
      return false
    }
  }

  logout(){
    this.currentLanguage = sessionStorage?.getItem('Language');
    this.currentLanguage = localStorage.getItem('Language');
    this.router.navigate(['']);
    sessionStorage.clear();
    sessionStorage.setItem('Language', this.currentLanguage);
  }

  autoLogout(){
    
    var logintoken = sessionStorage.getItem('token')||'';
    var _finaldata=JSON.parse(atob(logintoken.split('.')[1]));
    
    if(_finaldata!==undefined && _finaldata.exp!==null && _finaldata.exp!==undefined){
      const expires = new Date(_finaldata.exp * 1000);
      const timeout = expires.getTime() - Date.now();
      
      setTimeout(()=>{
        this.logout();
      },timeout)
    }else{
      console.log('Invalid access token');
    }

  }

  isSessionExpired(): boolean {
    return this.getExpireTime() && this.getExpireTime().getTime() <= Date.now();
  }

  getExpireTime(): any {
    const logintoken = sessionStorage.getItem('token')||'';
    if(logintoken !== '') {
      const _extractedtoken=logintoken.split('.')[1];
      const _atobdata=atob(_extractedtoken);
      const _finaldata=JSON.parse(_atobdata);
      let expires;
      if(_finaldata!==undefined && _finaldata.exp!==null && _finaldata.exp!==undefined){
        expires = new Date(_finaldata.exp * 1000);
      }
      return expires;
    }
    return undefined;
  }

  resetFirstTimePassword(request:ResetPasswordRequest){
    return this.http.put(this.resetFirstTimeUrl,request);
  }


  commonResetPassword(request:ResetPasswordRequest){
      return this.http.put(this.commonResetPasswordUrl,request);

  }


  sendMailToResetPassword(emailDto: EmailDto){
    return this.http.post(this.sendMailIdToResetPasswordUrl + '?emailId=' ,emailDto);
  }

  // Buffer.from("hello",'id').toString('binary')

  // console.log(Buffer.from("Hello World").toString('base64'));
// SGVsbG8gV29ybGQ=
// console.log(Buffer.from("SGVsbG8gV29ybGQ=", 'base64').toString('binary'))
// Hello World





}
