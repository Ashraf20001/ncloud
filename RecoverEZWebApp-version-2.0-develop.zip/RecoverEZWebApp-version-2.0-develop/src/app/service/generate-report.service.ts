import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { environment } from 'src/environments/environment';
import { PayReportReqDto } from '../reports/reports-card/reports-card.component';
import { PaymentDto } from '../reports/payment-popup/payment-popup.component';

@Injectable({
  providedIn: 'root'
})
export class GenerateReportService {
  private baseUrl = environment.API_BASE_URL+"/recovery"

  // eslint-disable-next-line @typescript-eslint/no-empty-function
  constructor(private http:HttpClient) { }

  public formDetails: string[] = [];



  savereport(values) :Observable<any>{

    return this.http.post(this.baseUrl+"/report/saveData",values);

  }
  getReport():Observable<any>{
    return this.http.get(this.baseUrl+"/report/getData");
  }

  getSingleData(identity:string){
    return this.http.post(this.baseUrl+"/report/getByIdentity",identity);
  }
  getReportSelectedFields(){
    return this.http.get(this.baseUrl+"/report/ReportFields");
  }
  getReportdata(report:any):Observable<any>{
    return this.http.post(this.baseUrl+"/report/data",report);
  }
  updateValue(report:any){
    return this.http.post(this.baseUrl+"/report/updateData",report);
  }

  getByteSourceForExcelReport(report:any):Observable<any>{
    return this.http.post(this.baseUrl+"/generate/report/export-to-excel", report, { responseType: 'blob' });
  }

  getByteSourceForCsvReport(report: any): Observable<any> {
    return this.http.post(this.baseUrl+"/generate/report/export-to-csv", report, { responseType: 'blob' });
  }

  getByteSourceForPdfReport(report: any): Observable<any> {
    return this.http.post(this.baseUrl+"/generate/report/export-to-pdf", report, { responseType: 'blob' });
  }
  
} 
