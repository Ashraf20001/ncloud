/* eslint-disable @typescript-eslint/no-explicit-any */
import { ErrorCode, ErrorCodeToIgnore } from './../common/enum/enum';
import { ConstantService } from './constants.service';
import { HttpErrorResponse, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { throwError, Observable, of } from 'rxjs';
import { catchError, concatMap, retryWhen } from 'rxjs/operators';
import { ErrorCaptureService } from './error-capture.service';
import { TranslateService } from '@ngx-translate/core';

@Injectable({
  providedIn: 'root',
})
export class HttpErrorInterceptorService implements HttpInterceptor {

  constructor(private toaster:ToastrService,private errorCapture:ErrorCaptureService,
    private translate:TranslateService){}

  //checking if there is error for every http request
  intercept(request: HttpRequest<any>, next: HttpHandler) {
    return next.handle(request)
        .pipe(
            retryWhen(error => this.retryRequest(error,1)),
            catchError((error: HttpErrorResponse) => {
                const errorMessage = this.setError(error);
                console.log(error);
                return throwError(errorMessage);
            })
        );
}



  // Retry the request in case of errror
  retryRequest(error: Observable<unknown>, retryCount: number): Observable<unknown>
  {
      return error.pipe(
          concatMap((checkErr: HttpErrorResponse, count: number) => {

              if(count <= retryCount)
              {
                  switch(checkErr.status)
                  {
                  case ErrorCode.serverDown :
                      return of(checkErr);

                  // case ErrorCode.unauthenticated :
                  //     return of(checkErr);

                  }
              }
              return throwError(checkErr);
          })
      );
  }


  //setting error
  setError(error: HttpErrorResponse): string {
      let errorMessage = ConstantService.unknownError;
      if(error.error instanceof ErrorEvent) {
          // Client side error
          errorMessage = error.error.message;
      } else {
          // server side error
          if(error.status=== ErrorCode.unauthorised)
          {
            const errorIdList = JSON.parse(error.error.message);
            const msg =`Backend_Toaster_Error.${errorIdList.errorIds[0].errorCode}`;
            errorMessage = this.translate.instant(msg);
            this.toaster.error(this.translate.instant("Toaster_Message.Server_error"));
              return error.statusText
          }
          if(error.status=== 400)
          {
            const errorIdList = JSON.parse(error.error.message);

            const msg =`Backend_Toaster_Error.${errorIdList.errorIds[0].errorCode}`;
            errorMessage = this.translate.instant(msg);
            errorMessage = this.setDynamicErrorFromBackend(errorMessage,errorIdList.errorIds[0].hints)
            this.errorCapture.setErrorObject(errorIdList.errorIds[0].errorCode);

            if(errorIdList.errorIds[0].errorCode !== ErrorCodeToIgnore.companyLogoError){
              this.toaster.error(errorMessage);
            }
              return error.statusText;
          }

          if (error.error.message && error.status!==ErrorCode.serverDown) {
              {
                const errorIdList = JSON.parse(error.error.message);
                // errorMessage = errorIdList.errorIds[0].errorMessage;
                const msg =`Backend_Toaster_Error.${errorIdList.errorIds[0].errorCode}`;
                errorMessage = this.translate.instant(msg);
              }
                this.toaster.error(errorMessage);
                return error.statusText
          }

          if (!error.error.message && error.error && error.status!==ErrorCode.serverDown) {
              {const errorIdList = JSON.parse(error.error.message);
                const msg =`Backend_Toaster_Error.${errorIdList.errorIds[0].errorCode}`;
                errorMessage = this.translate.instant(msg);}
          }
      }
      this.toaster.error(errorMessage);
      return errorMessage;
  }
  setDynamicErrorFromBackend(errorMessage: string, hints: any[]): string {
    let msgg = errorMessage;
    if (hints) {
      hints.forEach(hint => {
        msgg = msgg.replace(hint.hintKey, hint.hintValue);
      });
    }
    return msgg;
  }
}
