import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-preview-popup',
  templateUrl: './preview-popup.component.html',
  styleUrls: ['./preview-popup.component.scss']
})
export class PreviewPopupComponent implements OnInit {

  img: string;
  fileType: string;
  name: string;

  constructor(public dialogRef: MatDialogRef<PreviewPopupComponent>, @Inject(MAT_DIALOG_DATA) public data: DialogData, private _formBuilder: FormBuilder,
    public sanitizer: DomSanitizer) {
    this.img = this.data.image;
    this.fileType = this.data.fileType;
    this.name = this.data.name;
  }

  ngOnInit() {
   
  }

  closeDialog() {
    this.dialogRef.close('Preview PopUp Closed!');
  }
}
export interface DialogData {
  image: string;
  fileType: string;
  name: string
}