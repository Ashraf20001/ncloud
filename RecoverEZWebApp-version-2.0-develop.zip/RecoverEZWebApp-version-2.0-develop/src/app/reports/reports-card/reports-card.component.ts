import { Component, OnDestroy, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { ToastrService } from "ngx-toastr";
import { FileTypeEnum } from "src/app/models/report-loss-dto/FileTypeEnum";
import { AccessMappingPageDto } from "src/app/models/user-role-management/access-Mapping-PageDto ";
import { appConst } from "src/app/service/app.const";
import { GenerateReportService } from "src/app/service/generate-report.service";
import { AppService } from "src/app/service/role access/service/app.service";
import { PaymentPopupComponent } from "../payment-popup/payment-popup.component";
import { MatDialog } from "@angular/material/dialog";
import { Subscription } from "rxjs";
import { PaymentService } from "src/app/service/payment.service";
import { TranslateService } from "@ngx-translate/core";

@Component({
  selector: 'app-reports-card',
  templateUrl: './reports-card.component.html',
  styleUrls: ['./reports-card.component.scss']
})


export class ReportsCardComponent implements OnInit,OnDestroy{


company:any;
selectedcol:any;
selectedcol1:any;
TotalCardList:any[]=[];
TotalCardListCopy:any[]=[];
allCardList:any[]=[];
selectColumn:any[]=['Not At Fault Company','At Fault Company','Receivable Claim Amount','Payable Claim Amount'];

total:any;

pageInfo: any;
public appConst = appConst;
pageId= appConst.PAGE_NAME.REPORTS.REPORTS_CARD.PAGEID;
saveData: any;
searchvalue: any;
isReportCardEnabled = true;
reportCardPageAccessDto: AccessMappingPageDto;
dataNotFound:boolean;
private subscriptions = new Subscription();
  constructor(private getdataservice:GenerateReportService,private route:Router, private activatedRoute: ActivatedRoute, private tosterservice:ToastrService, private appService : AppService,private toastr : ToastrService,
    public dialog: MatDialog,private paymentService: PaymentService, private translate:TranslateService) {
    this.getDataFromCard();
    this.activatedRoute.queryParams.subscribe((queryParams: any) => {
      this.dataNotFound = false;
      this.searchvalue = queryParams['recSearchQuery'];
      if (this.searchvalue !== "") {
        this.TotalCardList = this.TotalCardListCopy.filter((m) => String(m.reportType.toUpperCase()).includes(this.searchvalue.toUpperCase()));
        if (this.TotalCardList.length == 0) {
          this.dataNotFound = true;
        }
      } else {
        this.TotalCardList = this.TotalCardListCopy;
      }
    });

    }



    getDataFromCard(){
      this.getdataservice.getReport().subscribe(data=>{
      this.TotalCardList = data;
      this.dataNotFound = false;
      if (this.TotalCardList===null || this.TotalCardList.length===0) {
        this.dataNotFound = true;
      }
      this.TotalCardListCopy = data;
      for(let i= 0; i<this.TotalCardListCopy.length;i++){
        if(this.TotalCardListCopy[i].selectColumn != null){
          if(this.TotalCardListCopy[i].selectColumn.length < 4){
            this.TotalCardListCopy[i].selectColumn.push(... this.selectColumn);
          }
        }else{
          this.TotalCardListCopy[i].selectColumn= this.selectColumn;
          this.TotalCardListCopy[i].totalColumn=0;
        }
      }
      })

    }

    ngOnInit(){
      this.getPageAccess();
    }

  name:string

  duplicateCopy(data:any){
    this.TotalCardList.unshift(data);
    this.getdataservice.savereport(data).subscribe(data=>{
      this.tosterservice.success( this.translate.instant("Toaster_Message.Saved"));
    });
  }

  editFunct(data:any){
    const edit="EDIT"
    sessionStorage.setItem('edit',edit );
    this.route.navigate(['report-Data/report-list'], { queryParams: { Identity: data.identity } })

  }

  getPrivilege(){
    this.appService.getPrivilegeForPage(this.pageId).subscribe((res: any)=>{
      this.pageInfo = res.content;
      this.getPageInfo(this.pageId);
    });
  }

  getPageInfo(pageID: number): boolean{
    if(this.pageInfo != null || this.pageInfo !== undefined){
      const pageValue = this.pageInfo.find((element: any) => element.pageId === pageID);
      return pageValue.isEnabled;
    }else{
      return true;
    }

  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege && privillege.isEnabled;
    }
    return isEnabled;
  }

  downloadReport(data:any){
    this.saveData = data;
    this.downloadReportData(data);
  }

   /**
  * REPORT - DOWNLOAD
  */
   private downloadReportData(data: any) {
    if (data.fileType == 'Excel') {
      this.getdataservice.getByteSourceForExcelReport(data).subscribe(response => {
        if(response.size === 0){
          this.toastr.error(this.translate.instant('Backend_Toaster_Error.E7147'))
        }else{
          this.downloadFile(response, FileTypeEnum.EXCEL);
        }
      })
    }
    else if (data.fileType == 'Csv') {
      this.getdataservice.getByteSourceForCsvReport(data).subscribe(response => {
        if(response.size === 0){
          this.toastr.error(this.translate.instant('Backend_Toaster_Error.E7147'))
        }else{
          this.downloadFile(response, FileTypeEnum.CSV);
        }
      })
    }else{
      this.getdataservice.getByteSourceForPdfReport(data).subscribe(response => {
        if(response.size === 0){
          this.toastr.error(this.translate.instant('Backend_Toaster_Error.E7147'))
        }else{
          this.downloadFile(response, FileTypeEnum.PDF);
        }
      })
    }
  }
  /**
   *
   * @param value
   * @param downloadType
   */
  private downloadFile(value: any, downloadType: string) {
    const blob = new Blob([value], { type: downloadType });
    const downloadLink = document.createElement('a');
    downloadLink.style.display = 'none';
    document.body.appendChild(downloadLink);
    downloadLink.setAttribute('href', window.URL.createObjectURL(blob));
    downloadLink.setAttribute('download', this.saveData.reportType);
    downloadLink.click();
    document.body.removeChild(downloadLink);
  }

  getPageAccess(): void {
    this.appService.getPageAccess(appConst.PAGE_NAME.REPORTS.REPORTS_CARD.PAGE_IDENTITY).subscribe((response: any) => {
      this.reportCardPageAccessDto = response.content;
      this.isReportCardEnabled = this.reportCardPageAccessDto.isEnabled;
      if(this.isReportCardEnabled){
       this.getDataFromCard();
      this.getPrivilege();
      }
    });
  }
  /*
  * PaymentMethod
  */
  paymentMethod(data: any) {
    if(data.toDate && data.fromDate){
    const payReportReqDto = new PayReportReqDto();
    payReportReqDto.fromDate = data.fromDate;
    payReportReqDto.toDate = data.toDate;
    payReportReqDto.insuredCompanies = data.thirdPartyCompanyName;
    payReportReqDto.fromCompany = data.companyName;
    payReportReqDto.reportId = data.reportId;
    this.subscriptions = this.paymentService.getComapnyAmountData(payReportReqDto).subscribe(res => {
      if (res['content']) {
         let totalClaimAmount = res['content'].totalClaimAmount;
         let companyAmountMap:Map<string, number> = res['content'].companyAmountMap;
         let currencyType:Map<string, number> = res['content'].currencyType;
        const dialogRef = this.dialog.open(PaymentPopupComponent, {
          width: '1561px',
          height: '569px',
          data: {
            currencyType,
            totalClaimAmount,
            companyAmountMap,
            reportId:data.reportId,
            fromCompanyName:data.companyName,
            autoGeneratedPdfID: data.autoGeneratedPDF,
            isReportCard : true
          },
          disableClose: true 
        });
        dialogRef.afterClosed().subscribe(result => {
        });
      }
    })
  }else{
    this.toastr.error(this.translate.instant('Backend_Toaster_Error.E7153'));
  }
  }
  ngOnDestroy(): void {
    this.subscriptions.unsubscribe;
  }
}
export class PayReportReqDto {
  fromDate: string;
  toDate: string;
  fromCompany:string;
  paymentId:number;
  reportId:number;
  insuredCompanies: [];
}
