import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { appConst } from 'src/app/service/app.const';

@Component({
  selector: 'app-report-header',
  templateUrl: './report-header.component.html',
  styleUrls: ['./report-header.component.scss']
})
export class ReportHeaderComponent {

  @Input() pageInfo: any;

  public appConst = appConst;
  searchvalue:string;
  closeIcon:boolean = false;
  searchValueEntered: any;
  constructor(public router:Router,private translate : TranslateService){
    this.translate.use(sessionStorage.getItem('Language'));
  }

  generatepage(){
    const edit='New'
    sessionStorage.setItem('edit',edit );
    this.router.navigate(['report-Data/report-list'])
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege ? privillege.isEnabled : false;
    }
    return isEnabled;
  }

  Search(){
    this.trimLeadingSpace();
    this.closeIcon=true;
    this.router.navigate([], { queryParams: { recSearchQuery: this.searchvalue } });
  }

  removeValue(){
    this.searchvalue='';
    this.closeIcon = false;
    this.router.navigate([], { queryParams: { recSearchQuery: this.searchvalue} });
  }

  handleKeyup(event: KeyboardEvent) {
    if (event.key === 'Backspace' && this.searchvalue === '' && this.closeIcon) {
      this.closeIcon = false;
    }
  }

  trimLeadingSpace() {
    this.searchvalue = this.searchvalue.replace(/^\s+/g, '');
  }

}
