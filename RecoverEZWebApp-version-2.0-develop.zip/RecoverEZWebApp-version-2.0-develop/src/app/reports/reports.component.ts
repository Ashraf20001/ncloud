import { Component, ElementRef, ViewChild, OnInit, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormControl, Validators, FormGroup } from '@angular/forms';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { MatChipInputEvent } from '@angular/material/chips';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { debounceTime, EMPTY, map, Observable, startWith, Subject } from 'rxjs';
import { reportDataVo } from '../models/field-dto';
import { GenerateReportService } from '../service/generate-report.service';
import { ReceivableService } from '../service/receivable.service';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { ReportLossService } from '../service/report-loss.service';
import { appConst } from '../service/app.const';
import { AppService } from '../service/role access/service/app.service';
import { FileTypeEnum } from '../models/report-loss-dto/FileTypeEnum';
import { ReportDto } from '../models/entity-management-dto/report-dto';
import { AdminService } from '../service/admin.service';
import { AccessMappingPageDto } from '../models/user-role-management/access-Mapping-PageDto ';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDatepickerInput, MatDatepickerModule } from '@angular/material/datepicker';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateTime } from '../common/enum/enum';
import { TranslateService } from '@ngx-translate/core';
import { ErrorHandlerDirective } from '../common/directives/errorHandler.directive';
import { I18nServiceService } from '../service/i18n-service.service';

export const MY_FORMATS = {
  parse: {
      dateInput: 'LL'
  },
  display: {
      dateInput: 'DD-MM-YYYY',
      monthYearLabel: 'YYYY',
      dateA11yLabel: 'LL',
      monthYearA11yLabel: 'YYYY'
  }
};

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }
  ],
})

export class ReportsComponent implements OnInit,AfterViewInit {

  addOnBlur = true;
  panelOpenState:boolean;
  tableopenstate :boolean;
  displayedColumns = ['Claim Number', 'Date', 'Type','At Fault Company','Status','Currency Type','Receivable Claim Amount','Payable Claim Amount'];
  dataSource: any;
  readonly = true;
  period: string;
  fromdate: string;
  SelectedTpNameList:string;
  todate: string;
  tpCompany: string[];
  selectedColumns: any[];
  selectedStatusList: string[]=["Draft","Notification Open","Notification Received","Notification Accepted","Garage And Survey Details Updated",
  "Moved To Inspection","Under Inspection","Expenses And Document Updated","Received Liability","Liability Accepted",
  "Liability Review","Confirmed Liability","Debit Note Generated","Claim Settled","Notification Rejected","Received Rejected Notification",
  "Need More Details","Details Provided","Reopen","Dispute","Dispute Reopen","Total Loss Initiated","Total Loss Accepted","Surveyor Assigned","Knock For Knock", "Paid"];
  selectedStatusListCopy: string[] = [];
  selectedStatusListDuplicate = this.selectedStatusList;
  claimType = [];
  insuranceCompany: string;
  TypeValue: string;
  fileTypeValue: string;
  CurrencyTypeValue: string;
  totalcount: any;
  companylist: any;
  totalcolumn: string;
  maxDate: string = new Date().toISOString().split('T')[0];
  fileType: any[] = [
    { name: 'Excel', check: false },
    { name: 'Csv', check: false },
    { name: 'Pdf', check: false }
  ];
  dateperiod: any[] = [
    { value: 'Select' },
    { value: '3Month' },
    { value: '6Month' },
    { value: '1Year' }
  ];
  type: any[] = [
    { name: 'Receivables', check:false },
    { name: 'Payables', check:false }
  ];

  currencyType: { currencyName: string, checking: boolean }[] = [];

  saveData = new reportDataVo();
  updateValue: any;
  separatorKeysCodes: number[];
  filteredFruits: Observable<string[]>;
  ColumnNameList: string[] = [];
  CompanyNameList: string[] = [];
  allColumnNameList;
  allColumnNameListCopy;
  allCompanyNameListCopy;
  allCompanyNameList: string[] = [];
  identityValue: any;
  check= false;
  Excel=false;
  csv=false;
  theDate: any;
  pdf=false;
  reportdata: FormGroup;
  selectCompanyName: any;
  pageInfo: any;
  public appConst = appConst;
  pageId= appConst.PAGE_NAME.REPORTS.REPORTS_GENERATE.PAGEID;
  receivableAmount: number=0;
  payableAmpunt: number=0;
  notAtFaultCompany: any;
  isGenerateReportEnabled = true;
  generateReportPageAccessDto: AccessMappingPageDto;
  dataNotFound: boolean = false;
  pageIndex :number = 1;
  customPageIndex: number = 0;
  currentPageIndex: number;
  ZERO: number = 0;
  minLength: number;
  maxLength: number;
  endingIndex=10;
  showtabledata: any;
  totalLength: number;
  pageChangedEvent = new Subject<number>();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor(private paginatorName: MatPaginatorIntl,
    private detector: ChangeDetectorRef,private getreportservice: GenerateReportService, private router: Router, private tosterservice: ToastrService,
    private activatedRoute: ActivatedRoute, private reportloss: ReportLossService, private formBuilder: FormBuilder, private appService: AppService, private toastr : ToastrService,
    private adminService: AdminService, private translate: TranslateService, private errorHandler : ErrorHandlerDirective,public i18Service: I18nServiceService) {

      this.reportdata = this.formBuilder.group({
      insuranceCompany: ["", [Validators.required]],
      tpCompany: ["", [Validators.required]],
      selectedColumn: [""],
      selectedStatus:["", [Validators.required]],
      fileType: ["", [Validators.required]],
      reportName: ["", [Validators.required]],
      period: [""],
      fromdate:[""],
      todate:[""],
      currencyType:["",[Validators.required]]
    });
    this.fetchDataForMultiLang(i18Service);
    if(this.paginatorName) {
      this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    }

  }
  ngAfterViewInit(): void {
    if(this.paginatorName) {
      this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    }
  }
  ngOnInit(): void {
    this.getCurrencyValue();
    this.getPageAccess();
    this.pageChangedEvent.pipe(debounceTime(300)).subscribe((data: number) => {
      this.changePageIndex();
    });
    this.translate.onLangChange.subscribe(() => {
      if (this.paginator) {
        this.paginator._intl.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
        this.paginator._changePageSize(this.paginator.pageSize);
        this.detector.detectChanges();
      }
    });
    if(this.paginatorName) {
      this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    }
  }

  doProcess(): void {
    this.getPrivilege();
    this.insuranceCompany = sessionStorage.getItem("companyName");
    this.reportdata.controls["insuranceCompany"].setValue(this.insuranceCompany);
    this.getSelectedFieldList();
    this.getReportlossDetails();
       this.activatedRoute.queryParams.subscribe(data => {
      this.identityValue = data['Identity'];
      if (this.identityValue != null) {
        this.getSingleValue(this.identityValue);
      }
    });
  }
  /**
  * FETCH DATA FOR MULTILANGUAGE
  */
  private fetchDataForMultiLang(i18Service: I18nServiceService) {
    this.translate.use(sessionStorage.getItem('Language'));
    this.i18Service = i18Service;
    this.i18Service.setUpConf();
    this.translateLabels();
    this.translate.onLangChange.subscribe(() => {
      this.translateLabels();
    });
  }

  /**
  * GET CURRENCY VALUE
  */
  private getCurrencyValue() {
    this.reportloss.getCurrencyTypeList().subscribe((res) => {
      if (res && res['content']) {
        this.currencyType = [];
        res['content'].forEach((currency) => {
          this.currencyType.push({ currencyName: currency.optionName, checking: false });
        });
      }
    });
  }
  
  generateReport() {
    if (this.reportdata.valid) {
      this.saveData.status = this.reportdata.get('selectedStatus').value;
      if (this.claimType.length != 0 && this.saveData.status.length !== 0 && this.tpCompany.length != 0) {
        if (this.getdate()) {
          this.tableopenstate = true;
          this.saveData.claimType = this.claimType;
          this.saveData.fileType = this.fileTypeValue;
          this.saveData.companyName = this.insuranceCompany;
          this.saveData.reportType = this.reportdata.get('reportName').value;
          this.saveData.selectColumn = this.ColumnNameList;
          this.saveData.thirdPartyCompanyName = this.tpCompany;

          if (this.fromdate > this.todate) {
            this.tosterservice.error(this.translate.instant("Toaster_Message.Todate_less"));
            return;
          }
          if (this.identityValue != null) {
            this.saveData.identity = this.identityValue;
            this.getreportservice.getReportdata(this.saveData).subscribe(data => {
              if (data.dataList.length > 0) {
                this.getreportservice.updateValue(this.saveData).subscribe(data => {
                  if (data['content'] != null) {
                    this.dowloadReportsData();
                    this.router.navigateByUrl('report-Data/reports-card');
                  }
                });
              } else {
                this.toastr.error(this.translate.instant('Backend_Toaster_Error.E7102'))
              }
            })
          } else {
            this.getreportservice.getReportdata(this.saveData).subscribe(data => {
              if (data.dataList.length > 0) {
                this.getreportservice.savereport(this.saveData).subscribe(value => {
                  if (value['content'] != null) {
                    this.dowloadReportsData();
                    this.router.navigateByUrl('report-Data/reports-card');
                  }
                });
              } else {
                this.toastr.error(this.translate.instant('Backend_Toaster_Error.E7102'))
              }
            })
          }
        }
      } else {
        this.tosterservice.error(this.translate.instant("Toaster_Message.Field_type"));
      }
    } else {
      this.tosterservice.error(this.translate.instant("Toaster_Message.Required_Field"));
    }
  }

  /**
  *  Extract Download ReportsData
  */

  private dowloadReportsData() {
    if (this.saveData.fileType == 'Excel') {
      this.downloadReport(FileTypeEnum.EXCEL, this.saveData);
    }
    else if (this.saveData.fileType == 'Csv') {
      this.downloadReport(FileTypeEnum.CSV, this.saveData);
    }
    else {
      this.downloadReport(FileTypeEnum.PDF, this.saveData);
    }
  }

  searchOption(event){
    const filterValue =event.target.value.toLowerCase();
    if(filterValue != null && filterValue != undefined && filterValue !==""){
      let SearchList= this.allCompanyNameListCopy.filter(data => data.toLowerCase().includes(filterValue));
      this.allCompanyNameList =SearchList;
    }else{
      this.allCompanyNameList = this.allCompanyNameListCopy;
    }
  }

  // inputValidation(event: any) {
  //   var charCode = (event.which) ? event.which : event.keyCode;
  //   let k;
  //   if (/^[a-zA-Z\s]*$/.test(event.key)) {
  //     return true;
  //   } else {
  //     event.preventDefault();
  //     return false;
  //   }
  // }

  searchOptionForCompanyList(event){

    const filterValue =event.target.value.toLowerCase();
    if(filterValue != null && filterValue != undefined && filterValue !==""){
      let SearchList= this.allColumnNameListCopy.filter(data => data.toLowerCase().includes(filterValue));
      this.allColumnNameList =SearchList;
    }else{
      this.allColumnNameList = this.allColumnNameListCopy;
    }

  }

  statusSearch(event){

    const filterValue =event.target.value.toLowerCase();
    if(filterValue != null && filterValue != undefined && filterValue !==""){
      let SearchList= this.selectedStatusListDuplicate.filter(data => data.toLowerCase().includes(filterValue));
      this.selectedStatusList =SearchList;
    }else{
      this.selectedStatusList = this.selectedStatusListDuplicate;
    }

  }

  duplicateValue=[];
  changes(event){
    this.duplicateValue.push(event.target.value.trim());
    if(this.duplicateValue.includes(event.target.value.trim())) {
      const index = this.allCompanyNameListCopy.indexOf(event.target.value);

    if (index >= 0) {
      this.allCompanyNameListCopy.splice(index, 1);
      this.allCompanyNameList = this.allCompanyNameListCopy;
    }

    } if(this.duplicateValue.length == 2){

      let duplicateName = this.duplicateValue[0];
        this.duplicateValue.splice(0, 1);
      this.allCompanyNameListCopy.push(duplicateName);
      this.allCompanyNameList = this.allCompanyNameListCopy;
    }
  }

  checkUserIsAdmin(){
    return this.adminService.isAssociationUser();
  }
  /*
  * Preview Report
  */
  previewReport() {
    if (this.reportdata.valid) {
      if (this.getdate()) {
        if (this.fromdate > this.todate) {
          this.tosterservice.error(this.translate.instant("Toaster_Message.Todate_less"));
          return;
        }
        const tpcom = this.reportdata.get('tpCompany').value;
        const slcol = this.reportdata.get('selectedColumn').value;
        this.saveData.status = this.reportdata.get('selectedStatus').value;
        if (this.claimType.length != 0 && this.saveData.status.length !== 0 && tpcom.length != 0) {
          this.tableopenstate = true;
          this.saveData.claimType = this.claimType;
          this.saveData.fileType = this.fileTypeValue;
          this.saveData.companyName = this.insuranceCompany;
          this.saveData.reportType = this.reportdata.get('reportName').value;
          this.saveData.selectColumn = this.ColumnNameList;
          this.saveData.thirdPartyCompanyName = this.tpCompany;
          if (this.identityValue) {
            this.saveData.identity = this.identityValue;
            this.saveData.isAutoGenerated = this.updateValue.autoGenerated;
            this.saveData.isPaid = this.updateValue.paid;
            this.saveData.autoGeneratedPDF = this.updateValue.autoGeneratedPDF;
          }

          this.getreportservice.getReportdata(this.saveData).subscribe(data => {
            this.dataNotFound = false;
            this.showtabledata = data.dataList;
            this.ColumnNameList.forEach(columnName=>{
              if(!this.displayedColumns.includes(columnName)){
              this.displayedColumns.push(columnName);
              }
            })
              const tableList = this.showtabledata.slice(0, 10);
              this.dataSource = new MatTableDataSource(tableList);
              this.totalLength = this.showtabledata.length;
            if (data.dataList.length != 0) {
              this.tableopenstate = true;
              this.dataSource.paginator = this.paginator;
              this.dataSource.length = this.totalLength;
              this.receivableAmount = data.receivableAmount;
              this.payableAmpunt = data.payableAmount;

            } else {
              this.receivableAmount = data.receivableAmount;
              this.payableAmpunt = data.payableAmount;
              this.dataNotFound = true;
              this.tosterservice.error(this.translate.instant('Backend_Toaster_Error.E7148'));
            }

          });
        } else {
          this.tosterservice.error(this.translate.instant("Toaster_Message.Required_Field"));
        }
      }
    } else {
      this.tosterservice.error(this.translate.instant("Toaster_Message.Required_Field"));
    }
  }
  getToday(): string {
    return new Date().toISOString().split('T')[0]
  }
  getSelectedFieldList() {
    this.getreportservice.getReportSelectedFields().subscribe(Result => {
      this.allColumnNameList = Result;
      this.allColumnNameListCopy = Result;
    });
  }
  getReportlossDetails() {
    this.allCompanyNameListCopy =[];
    this.allCompanyNameList=[];
    this.notAtFaultCompany=[];
    this.reportloss.getReportLossDetails().subscribe(Result => {
      let List = Result
      for (let i = 0; i < List.length; i++) {
        this.allCompanyNameList.push(List[i].name);
        this.allCompanyNameListCopy.push(List[i].name);
        this.notAtFaultCompany.push(List[i].name);
      }
    });
  }

  getSingleValue(identity: string) {
    this.getreportservice.getSingleData(identity).subscribe(data => {
      this.updateValue = data;
      this.insuranceCompany =  this.updateValue.companyName;
      this.reportdata.controls['insuranceCompany'].setValue(this.updateValue.companyName);

      if(this.updateValue.fromDate != null || this.updateValue.fromDate != undefined){
        let fromtd = this.updateValue.fromDate;
        fromtd = fromtd.split(' ')[0];
        this.fromdate=fromtd;
        this.ready1= true;
        this.reportdata.controls['fromdate'].setValue(fromtd);
      }

      if(this.updateValue.toDate != null || this.updateValue.toDate != undefined){
        let toTd = this.updateValue.toDate;
        toTd = toTd.split(' ')[0];
        this.todate=toTd;
        this.ready1= true;
        this.reportdata.controls['todate'].setValue(toTd);
      }

      this.period=this.updateValue.period;
      this.reportdata.controls['period'].setValue(this.updateValue.period);
      this.reportdata.controls['reportName'].setValue(this.updateValue.reportType);
      if(this.updateValue.status !== null){
        this.reportdata.controls['selectedStatus'].setValue(this.updateValue.status);
      this.selectedStatusListCopy=this.updateValue.status;
      }
      this.reportdata.controls['fileType'].setValue(this.updateValue.fileType);
      this.claimType = this.updateValue.claimType;
      this.CompanyNameList = this.updateValue.thirdPartyCompanyName;
      if(this.updateValue.selectColumn !=null){
      this.ColumnNameList = this.updateValue.selectColumn;
      }
      if(this.updateValue.thirdPartyCompanyName !=null){
      this.reportdata.controls['tpCompany'].setValue(this.updateValue.thirdPartyCompanyName);
      this.tpCompany= this.updateValue.thirdPartyCompanyName;
      }

      if(this.checkUserIsAdmin()){
        const index = this.allCompanyNameListCopy.indexOf(this.updateValue.companyName);
        this.allCompanyNameListCopy.splice(index, 1);
      this.allCompanyNameList = this.allCompanyNameListCopy;
      }

      for(let i =0; i< this.fileType.length;i++){
        if(this.updateValue.fileType == this.fileType[i].name){
          this.fileType[i].check= true;
        }
        this.fileTypeValue = this.updateValue.fileType;
      }

      for(let i =0; i< this.type.length;i++){
        if(this.updateValue.claimType.length != 2){
          if(this.updateValue.claimType[0] == this.type[i].name){
            this.type[i].check= true;
          }else{
            this.type[i].check= false;
          }
        }else{
          this.type[i].check= true;
        }
      }
      this.SelectCurrencytype(this.updateValue.currencyType);
      this.previewReport();

    },(error:Response)=>{
      this.errorHandler.getMessage(error);
    })
  }

  remove(ListName: string): void {
    const index = this.ColumnNameList.indexOf(ListName);
    if (index >= 0) {
      this.ColumnNameList.splice(index, 1);
    }
  }

  removeStatus(ListName: string): void {
    const index = this.selectedStatusListCopy.indexOf(ListName);
    if (index >= 0) {
      this.selectedStatusListCopy.splice(index, 1);
    }
  }


  removeCompany(ListName: string): void {
    const index = this.CompanyNameList.indexOf(ListName);
    if (index >= 0) {
      this.CompanyNameList.splice(index, 1);
    }
  }


  selectedColumn(event: MatAutocompleteSelectedEvent): void {
      this.ColumnNameList.forEach(function(item){
        if(item===event.option.viewValue)
        {
          this.ColumnNameList.splice(event.option.viewValue);
        }
      });

    this.ColumnNameList.push(this.allColumnNameList[event.option.value]);
    this.reportdata.controls['selectedColumn'].setValue(this.ColumnNameList);
    this.selectedColumns = this.ColumnNameList;
    this.totalcolumn = this.ColumnNameList.length.toString();
  }

  selectedStatus(event: MatAutocompleteSelectedEvent): void {
    this.selectedStatusListCopy?.forEach(function(item){
      if(item===event.option.viewValue)
      {
        this.selectedStatusListCopy.splice(event.option.viewValue);
      }
    });

  this.selectedStatusListCopy.push(event.option.viewValue);
  this.reportdata.controls['selectedStatus'].setValue(this.selectedStatusListCopy);
}

    displayFn(option: any): string {
      return '';
    }

  selectedCompany(event: MatAutocompleteSelectedEvent): void {
    this.CompanyNameList.forEach(function(item){
      if(item==event.option.viewValue)
      {
        this.CompanyNameList.splice(event.option.viewValue);
      }
    })
    this.CompanyNameList.push(event.option.viewValue);
    this.tpCompany = this.CompanyNameList;
    this.reportdata.controls['tpCompany'].setValue(this.tpCompany)
    this.totalcolumn = this.ColumnNameList.length.toString();
  }

  SelectTypeFunc(data: string) {
    this.TypeValue = data;
  }
  SelectFileType(value:string) {
    this.fileTypeValue = value;
    this.reportdata.controls['fileType'].setValue(value);
    if( value ==='Excel'){

      this.fileType[0].check= true;
      this.fileType[1].check= false;
      this.fileType[2].check= false;
    }
    else if( value==='Csv'){

      this.fileType[1].check= true;
      this.fileType[2].check= false;
      this.fileType[0].check= false;

    }
    else if( value==='Pdf'){

      this.fileType[2].check= true;
      this.fileType[0].check= false;
      this.fileType[1].check= false;
    }

  }


  SelectCurrencytype(value: string){
    this.CurrencyTypeValue = value;
    this.reportdata.controls['currencyType'].setValue(value);
    this.currencyType.forEach((dt: { currencyName: string, checking: boolean }) => {
      if(dt.currencyName === value) {
        dt.checking = true;
      } else {
        dt.checking = false;
      }
    });
    this.saveData.currencyType = value;
  }

  getdate():boolean {
    if (this.period && this.period != "Select") {
      this.saveData.period = this.period;
      this.saveData.fromDate=null;
      this.saveData.toDate =null;
      return true;
    }
    else if(this.fromdate && this.todate){
      this.saveData.fromDate = this.fromdate + DateTime.startingTime;
      this.saveData.toDate = this.todate + DateTime.endingTime;
      this.saveData.period = null;
      return true;
    }else{
      this.saveData.period = null;
      this.saveData.fromDate=null;
      this.saveData.toDate =null;
      this.tosterservice.error(this.translate.instant("Toaster_Message.Fill_Date_filed"));
      return false;
    }

  }
  claim(event: MatCheckboxChange, name: any) {
    if (event.source.checked) {
      this.claimType.push(name.trim());
    }
    if(!event.source.checked) {
      for(let i =0;i< this.claimType.length;i++){
        if(this.claimType[i].trim() === name.trim()){
          this.claimType.splice(i, 1);
        }
      }
    }
  }

  ready = false;
  ready1 = true;

  showDate(data: any) {
    if (data == "Select") {
      this.ready = false;
      this.fromdate = null;
      this.todate = null;
    }
    else {
      this.period = data;
      this.fromdate = null;
      this.todate = null;
      this.ready = true;
      this.fromdate = null;
      this.todate = null;
    }
  }

  setFromDate(data: any) {
    this.ready = false;
    if (data) {
      this.fromdate = this.parseDate(data);
      if (this.fromdate) {
        this.ready1 = true;
        this.period = null;
      }
    }
  }

  setToDate(data: any) {
    this.ready = false;
    if (data) {
      this.todate = this.parseDate(data);
      if (this.todate) {
        this.ready1 = true;
        this.period = null;
        if (this.fromdate > this.todate) {
          this.maxDate = new Date().toISOString().split('T')[0];
        } else {
          this.maxDate = this.todate;
        }
      }
    }
  }

  parseDate(selectedDate: string): string {
    const date = new Date(selectedDate);
    const dd = String(date.getDate()).padStart(2, '0');
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const yyyy = date.getFullYear();
    return yyyy + '-' + mm + '-' + dd;
  }
  /**
  * REPORT - DOWNLOAD
  */
  private downloadReport(downloadType: string, data: reportDataVo) {
    if (data.fileType == 'Excel') {
      this.getreportservice.getByteSourceForExcelReport(this.saveData).subscribe(response => {
        if(response.size === 0){
          this.toastr.error(this.translate.instant('Backend_Toaster_Error.E7147'))
        }else{
          this.donwloadFile(response, downloadType);
        }
      })
    }
    else if (data.fileType == 'Csv') {
      this.getreportservice.getByteSourceForCsvReport(this.saveData).subscribe(response => {
        if(response.size === 0){
          this.toastr.error(this.translate.instant('Backend_Toaster_Error.E7147'))
        }else{
          this.donwloadFile(response, downloadType);
        }
      })
    }else{
      this.getreportservice.getByteSourceForPdfReport(this.saveData).subscribe(response => {
        if(response.size === 0){
          this.toastr.error(this.translate.instant('Backend_Toaster_Error.E7147'))
        }else{
          this.donwloadFile(response, downloadType);
        }
      })
    }
  }
  /**
   *
   * @param value
   * @param downloadType
   */
  private donwloadFile(value: any, downloadType: string) {
    const blob = new Blob([value], { type: downloadType });
    const downloadLink = document.createElement('a');
    downloadLink.style.display = 'none';
    document.body.appendChild(downloadLink);
    downloadLink.setAttribute('href', window.URL.createObjectURL(blob));
    downloadLink.setAttribute('download', this.saveData.reportType);
    downloadLink.click();
    document.body.removeChild(downloadLink);
  }

  getPrivilege(): void {
    this.appService.getPrivilegeForPage(this.pageId).subscribe((res: any)=>{
      this.pageInfo = res.content;
      this.getPageInfo(this.pageId);
    });
  }

  getPageInfo(pageID: number): boolean {
    if(this.pageInfo != null || this.pageInfo !== undefined){
      const pageValue = this.pageInfo && (this.pageInfo.length === 0 || this.pageInfo.find((element: any) => element.pageId === pageID));
    return pageValue;
    }else{
      return true;
    }
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege ? privillege.isEnabled : false;
    }
    return isEnabled;
  }

  getPageAccess(): void {
    this.appService.getPageAccess(appConst.PAGE_NAME.REPORTS.REPORTS_GENERATE.PAGE_IDENTITY).subscribe((response: any) => {
      this.generateReportPageAccessDto = response.content;
      this.isGenerateReportEnabled = this.generateReportPageAccessDto.isEnabled;
      if(this.isGenerateReportEnabled) {
        this.doProcess();
      }
    });
  }
  /*
  * Clear Date Field Value
  */
  clearDateField(fromDate:boolean){
    if(fromDate){
     this.fromdate = null ;
    }else{
       this.todate = null;
    }
 }

 isAutogenerate():boolean{
    if(this.updateValue && this.updateValue.autoGenerated===true){
      return true;
    }
    return false;
 }
 changePage(event){

  if(event.pageIndex > event.previousPageIndex ){
    //previous
    this.customPageIndex = event.pageIndex+1;
  }else{
   // next
   this.customPageIndex =  this.customPageIndex-1;
  }
  if(event.pageIndex != this.ZERO){
    this.maxLength= event.pageSize * this.customPageIndex;
    this.minLength = event.pageSize * event.pageIndex;
    this.endingIndex = event.pageSize;
    this.pageIndex = this.customPageIndex;
  }else{
    this.maxLength= event.pageSize;
    this.minLength = event.pageIndex;
    this.endingIndex = event.pageSize;
    this.pageIndex = event.pageIndex+1;
  }
  this.fetchTableData();
}

  pageindex(): void {
    this.pageChangedEvent.next(this.pageIndex);
  }

  changePageIndex(): void {
    if (this.pageIndex > 0) {
      const totalPageIndex = this.totalLength / this.endingIndex + 1;
      if(this.pageIndex > totalPageIndex) {
        this.pageIndex = this.customPageIndex === 0 ? 1 : this.customPageIndex;
        return;
      }
      this.customPageIndex = this.pageIndex;
      this.currentPageIndex = this.pageIndex - 1;
      this.maxLength = this.endingIndex * this.pageIndex;
      this.minLength = this.endingIndex * this.currentPageIndex;
      this.fetchTableData();
    }
  }

private fetchTableData() {
  const tableList = this.showtabledata.slice(this.minLength,this.maxLength);
  this.dataSource = new MatTableDataSource(tableList);
  if(tableList.length == 0 ){
     this.dataNotFound =true ;
  }else{
    this.dataNotFound =false ;
  }
}

onKeyDown(event: KeyboardEvent) {
  if (event.keyCode === 190) {
    event.preventDefault();
  }
}

  translateLabels() {
    this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    this.paginatorName.firstPageLabel = this.translate.instant('Paginator.FirstPage');
    this.paginatorName.lastPageLabel = this.translate.instant('Paginator.LastPage');
    this.paginatorName.nextPageLabel = this.translate.instant('Paginator.NextPage');
    this.paginatorName.previousPageLabel = this.translate.instant('Paginator.PreviousPage');
  }
}
