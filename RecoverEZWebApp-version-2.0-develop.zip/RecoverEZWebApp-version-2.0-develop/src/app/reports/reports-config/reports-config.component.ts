import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { TranslateService } from "@ngx-translate/core";
import { appConst } from "src/app/service/app.const";
import { AppService } from "src/app/service/role access/service/app.service";

@Component({
  selector: 'app-reports-config',
  templateUrl: './reports-config.component.html',
  styleUrls: ['./reports-config.component.scss']
})


export class ReportsConfigComponent implements OnInit{
  edit:any;
  pageInfo: any;
  public appConst = appConst;
  pageId= appConst.PAGE_NAME.REPORTS.REPORTS_GENERATE.PAGEID;

 constructor(private router:Router, private appService: AppService, private translate: TranslateService ){}

 ngOnInit(): void {


this.translate.use(sessionStorage.getItem('Language'));
  const edit= sessionStorage.getItem('edit')
  if(edit=='EDIT'){
this.edit=edit;
 }
 else if(edit=='New')
 {
  this.edit=edit;
 }
  this.getPrivilege();
}

  generatepage(){
    this.router.navigate(['report-Data/reports-card']);
  }

  getPrivilege(){
    this.appService.getPrivilegeForPage(this.pageId).subscribe((res: any)=>{
      this.pageInfo = res.content;
      this.getPageInfo(this.pageId);
    });
  }

  getPageInfo(pageID: number): boolean{
    if(this.pageInfo != null || this.pageInfo !== undefined){
      const pageValue = this.pageInfo && (this.pageInfo.length === 0 || this.pageInfo.find((element: any) => element.pageId === pageID));
    return pageValue;
    }else{
      return true;
    }
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege ? privillege.isEnabled : false;
    }
    return isEnabled;
  }

}

