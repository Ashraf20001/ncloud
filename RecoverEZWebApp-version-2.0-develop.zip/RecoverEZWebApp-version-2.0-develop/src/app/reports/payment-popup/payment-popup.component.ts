import { Component, ElementRef, HostListener, Inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { Observable, ReplaySubject, Subscription } from 'rxjs';
import { TotalrecordsPopupComponent } from 'src/app/receivable-list/receivable-list-card/receivable-bulk-history/totalrecords-popup/totalrecords-popup.component';
import { PreviewPopupComponent } from '../preview-popup/preview-popup.component';
import { ProceedToPaymentPopupComponent } from '../proceed-to-payment-popup/proceed-to-payment-popup.component';
import { PayReportDto } from 'src/app/models/reports-dto/PayReportDto';
import { GenerateReportService } from 'src/app/service/generate-report.service';
import { FileUploadService } from 'src/app/service/file-upload.service';
import { PaymentMethodEnum } from 'src/app/common/enum/paymentMethod';
import { PaymentDto } from 'src/app/models/reports-dto/PaymentDto';
import { PaymentService } from 'src/app/service/payment.service';
import { AdminService } from 'src/app/service/admin.service';
import { PaymentSatus } from 'src/app/common/enum/paymentStatus-enum';
import { ErrorHandlerDirective } from 'src/app/common/directives/errorHandler.directive';
import { TranslateService } from '@ngx-translate/core';
import { appConst } from 'src/app/service/app.const';
import { AppService } from 'src/app/service/role access/service/app.service';
import { NgxUiLoaderService } from 'ngx-ui-loader';
export { PaymentDto } from 'src/app/models/reports-dto/PaymentDto';

@Component({
  selector: 'app-payment-popup',
  templateUrl: './payment-popup.component.html',
  styleUrls: ['./payment-popup.component.scss']
})
export class PaymentPopupComponent implements OnInit, OnDestroy {

  @ViewChild('fileDropRef') hiddenInput: ElementRef;
  credit_card = false;
  airtel = false;
  debitcard = false;
  upipayment = false;
  cheque = false;
  cash = false;

  creditcardisInActive = true;
  creditcardActive = false;
  aittelmoneyInActive = true;
  airtelmoneyActive = false;
  debitcardInActive = true;
  debitcardActive = false;
  upiInActive = true;
  upiActive = false;
  chequeisActive = true;
  chequeActive = false;
  cashpaymentActive = false;
  cashpaymentInActive = true;
  creditCardCheckbox: boolean = false;

  paymentMethodSelect: string;
  base64Output: string;
  fileList: File[] = [];
  fileListduplicate: File[] = null;
  filesize: number;
  fileboolean: boolean = false;
  fileType: string;
  Papers: string = '0';
  showFile: boolean = false;
  AvailableStockAmt: number = 0;
  updateFileDataCopyList = new updateFileList();
  fileNameList: updateFileList[] = [];
  userType: string[] = [];
  comapanyList: string[] = []
  enableToCompanyList: boolean;
  paymentForm = new FormGroup({
    fromCompany: new FormControl('', [Validators.required]),
    toCompany: new FormControl(null),
    paymentMethod: new FormControl(null, [Validators.required]),
    totalAmount: new FormControl(null, [Validators.required])
  })
  totalClaimAmount: number;
  currencyType:string;
  private subscriptions = new Subscription();
  referenceId: number;
  acceptOrRejectBtn: boolean = false;
  associateUser: boolean;
  isButtonDisabled :boolean = false;
  public appConst = appConst;
  pageInfo: any;
  pageId: number;
  constructor(public dialogRef: MatDialogRef<TotalrecordsPopupComponent>, private reportServie: GenerateReportService, private fileService: FileUploadService,
    public dialog: MatDialog, private tosterservice: ToastrService, @Inject(MAT_DIALOG_DATA) public data: PayReportDto, private paymentService: PaymentService,
     private adminService: AdminService,private toastr: ToastrService,private errorHandler: ErrorHandlerDirective
     ,private translate: TranslateService, private appService : AppService, private ngxLoader: NgxUiLoaderService) {
       this.pageId = appConst.PAGE_NAME.PAYMENT.PAYMENT_DETAILS_LIST.PAGEID;
      if(data.isReportCard){
        this.pageId = appConst.PAGE_NAME.REPORTS.REPORTS_CARD.PAGEID
      }
     this.getPrivilege();
  }
  ngOnInit(): void {
    this.paymentMethodCardStatus();
    this.associateUser = this.adminService.isAssociationUser();
    if (!this.associateUser) {
      this.fetchInsCompanyInputValue()
    } else {
      this.fetchAssociateInputValue()
    }

  }
  /*  Fetch Dialog-Data Value
  */
  fetchInsCompanyInputValue() {
    this.totalClaimAmount = this.data.totalClaimAmount;
    this.currencyType = this.data.currencyType;
    this.userType = ['Association', 'Insurance'];
    this.paymentForm.controls['fromCompany'].setValue('Association');
    this.paymentForm.controls['totalAmount'].setValue(this.totalClaimAmount);
    Object.entries(this.data.companyAmountMap).forEach(([key, value]) => {
      this.comapanyList.push(key);
    })
  }

  fetchAssociateInputValue() {
    this.userType.push(this.data.fromCompanyName);
    this.paymentForm.controls['fromCompany'].setValue(this.data.fromCompanyName);
    this.enableToCompanyList = true;
    Object.entries(this.data.companyAmountMap).forEach(([key, value]) => {
      this.comapanyList.push(key);

    })
  }

  /*  Change UserType in InputField
   */
  changeFromCompany() {
    if (this.paymentForm.controls['fromCompany'].value == "Insurance") {
      this.enableToCompanyList = true;
    } else {
      this.enableToCompanyList = false;
      this.totalClaimAmount = this.data.totalClaimAmount;
      this.currencyType = this.data.currencyType;;
      this.paymentForm.controls['totalAmount'].setValue(this.totalClaimAmount)
      this.paymentForm.controls['toCompany'].setValue(null)
    }
  }

  changeToCompany() {
      Object.entries(this.data.companyAmountMap).forEach(([key, value]) => {
        if (this.paymentForm.controls['toCompany'].value == key) {
          this.paymentForm.controls['totalAmount'].setValue(value);
          this.totalClaimAmount = value;
        }
      })
  }

  closeDialog(value: boolean) {
      this.dialogRef.close(value);
    }

  /*  File Delete
  */
  fileDelete(fileName: string) {
    this.fileNameList.forEach((element, index) => {
      if (element.name === fileName) {
        this.fileNameList.splice(index, 1);
        this.fileList.splice(index, 1);
      }
    })
  }

  onFileSelected(event) {
    this.convertFile(event.target.files[0]).subscribe(base64 => {
      this.base64Output = base64;
    });
  }

  convertFile(file: File): Observable<string> {
    const result = new ReplaySubject<string>(1);
    const reader = new FileReader();
    reader.readAsBinaryString(file);
    reader.onload = (event) => result.next(btoa(event.target.result.toString()));
    return result;
  }

  onChange(event: any) {
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
    const files = event.target.files;
    const kb = 1024;
    // const maxSizeLimit = 15;
    const allowedFormats = ['png', 'jpeg', 'pdf', 'jpg'];
    for (let i = 0; i < files.length; i++) {
      // if (this.fileList.length >= maxSizeLimit) {
      //   this.toastr.error(this.translate.instant('Backend_Toaster_Error.E7151'));
      //   break;
      // }
      const file = files[i];
      const fileType = file.type.split('/')[1].toLowerCase();
      if (allowedFormats.includes(fileType)) {
      const fileName = file.name;
      const round = Math.floor(Math.log(file.size) / Math.log(kb));
      const size = `${parseFloat((file.size / Math.pow(kb, round)).toFixed(0))} ${sizes[round]}`
      this.fileList.push(file);
      this.convertFile(file).subscribe(base64 => {
        const fileOk = new updateFileList();
        fileOk.name = fileName;
        fileOk.size = size;
        fileOk.file = base64;
        fileOk.fileType = file.type;
        this.fileNameList.push(fileOk);
      });
    }else{
      this.toastr.error(this.translate.instant('Backend_Toaster_Error.E7152'));
    }
  }
  this.hiddenInput.nativeElement.value = null;
  this.hiddenInput.nativeElement.click();
    this.showFile = true;
  }

  /* Open PreviewPopupComponent
  */
  openDialog(i: number): void {
    const dialogRef = this.dialog.open(PreviewPopupComponent, {
      width: '937px',
      height: '374px',
      data: {
        image: this.fileNameList[i].file,
        fileType: this.fileNameList[i].fileType,
        name: this.fileNameList[i].name
      },
      disableClose: true 
    });
    dialogRef.afterClosed().subscribe(result => {
    });
  }

  paymentMethodCardStatus() {
    if (this.paymentMethodSelect) {
      // === PaymentChoice.CHEQUE
      this.chequeisActive = false;
      this.chequeActive = true;
      this.credit_card = false;
      this.airtel = false;
      this.debitcard = false;
      this.upipayment = false;
      this.cheque = true;
      this.cash = false;
    }
    else if (this.paymentMethodSelect) {
      // === PaymentChoice.CASH
      this.cashpaymentActive = true;
      this.cashpaymentInActive = false;
      this.credit_card = false;
      this.airtel = false;
      this.debitcard = false;
      this.upipayment = false;
      this.cheque = false;
      this.cash = true;
    }
    else if (this.paymentMethodSelect) {
      // === PaymentChoice.CREDIDCARD
      this.credit_card = true;
      this.airtel = false;
      this.debitcard = false;
      this.upipayment = false;
      this.cheque = false;
      this.cash = false;
      this.creditcardisInActive = false;
      this.creditcardActive = true;
    }
    else if (this.paymentMethodSelect) {
      // === PaymentChoice.UPI
      this.credit_card = false;
      this.airtel = false;
      this.debitcard = false;
      this.upipayment = true;
      this.cheque = false;
      this.cash = false;
      this.upiInActive = false;
      this.upiActive = true;

    }
    else if (this.paymentMethodSelect) {
      // === PaymentChoice.AIRTELMONEY

      this.credit_card = false;
      this.airtel = true;
      this.debitcard = false;
      this.upipayment = false;
      this.cheque = false;
      this.cash = false;

      this.aittelmoneyInActive = false;
      this.airtelmoneyActive = true;
    }
    else if (this.paymentMethodSelect) {
      // === PaymentChoice.DEBITCARD
      this.credit_card = false;
      this.airtel = false;
      this.debitcard = true;
      this.upipayment = false;
      this.cheque = false;
      this.cash = false;
      this.debitcardInActive = false;
      this.debitcardActive = true;
    }


  }

  creditcard() {
    this.credit_card = true;
    this.airtel = false;
    this.debitcard = false;
    this.upipayment = false;
    this.cheque = false;
    this.cash = false;

    this.creditcardisInActive = false;
    this.creditcardActive = true;
    this.airtelmoneyActive = false;
    this.aittelmoneyInActive = true;
    this.debitcardActive = false;
    this.debitcardInActive = true;
    this.upiActive = false;
    this.upiInActive = true;
    this.chequeisActive = true;
    this.chequeActive = false;
    this.cashpaymentActive = false;
    this.cashpaymentInActive = true;
  }
  airtelMoney() {
    this.credit_card = false;
    this.airtel = true;
    this.debitcard = false;
    this.upipayment = false;
    this.cheque = false;
    this.cash = false;

    this.creditcardisInActive = true;
    this.creditcardActive = false;
    this.aittelmoneyInActive = false;
    this.airtelmoneyActive = true;
    this.debitcardInActive = true;
    this.debitcardActive = false;
    this.upiInActive = true;
    this.upiActive = false;
    this.chequeisActive = true;
    this.chequeActive = false;
    this.cashpaymentActive = false;
    this.cashpaymentInActive = true;
  }
  debitCard() {
    this.credit_card = false;
    this.airtel = false;
    this.debitcard = true;
    this.upipayment = false;
    this.cheque = false;
    this.cash = false;

    this.creditcardisInActive = true;
    this.creditcardActive = false;
    this.aittelmoneyInActive = true;
    this.airtelmoneyActive = false;
    this.debitcardInActive = false;
    this.debitcardActive = true;
    this.upiInActive = true;
    this.upiActive = false;
    this.chequeisActive = true;
    this.chequeActive = false;
    this.cashpaymentActive = false;
    this.cashpaymentInActive = true;
  }
  upi() {
    this.credit_card = false;
    this.airtel = false;
    this.debitcard = false;
    this.upipayment = true;
    this.cheque = false;
    this.cash = false;

    this.creditcardisInActive = true;
    this.creditcardActive = false;
    this.aittelmoneyInActive = true;
    this.airtelmoneyActive = false;
    this.debitcardInActive = true;
    this.debitcardActive = false;
    this.upiInActive = false;
    this.upiActive = true;
    this.chequeisActive = true;
    this.chequeActive = false;
    this.cashpaymentActive = false;
    this.cashpaymentInActive = true;
  }
  chequemethod() {
    this.credit_card = false;
    this.airtel = false;
    this.debitcard = false;
    this.upipayment = false;
    this.cheque = true;
    this.cash = false;

    this.creditcardisInActive = true;
    this.creditcardActive = false;
    this.aittelmoneyInActive = true;
    this.airtelmoneyActive = false;
    this.debitcardInActive = true;
    this.debitcardActive = false;
    this.upiInActive = true;
    this.upiActive = false;
    this.chequeisActive = false;
    this.chequeActive = true;
    this.cashpaymentActive = false;
    this.cashpaymentInActive = true;
    this.paymentForm.controls['paymentMethod'].setValue(PaymentMethodEnum.CHEQUE)
  }
  cashPayment() {
    this.credit_card = false;
    this.airtel = false;
    this.debitcard = false;
    this.upipayment = false;
    this.cheque = false;
    this.cash = true;

    this.creditcardisInActive = true;
    this.creditcardActive = false;
    this.aittelmoneyInActive = true;
    this.airtelmoneyActive = false;
    this.debitcardInActive = true;
    this.debitcardActive = false;
    this.upiInActive = true;
    this.upiActive = false;
    this.chequeisActive = true;
    this.chequeActive = false;
    this.cashpaymentActive = true;
    this.cashpaymentInActive = false;
  }

  checkbox(event: any) {
    this.creditCardCheckbox = event.target.value;
  }
  /*  Save Payment Details
  */
  proceedTopay() {
    if (this.paymentForm.valid) {
      this.isButtonDisabled = true;
      let paymentDto = new PaymentDto();
      paymentDto.fromCompanyName = this.paymentForm.controls['fromCompany'].value;
      if(this.associateUser){
        paymentDto.paymentBy = "Association";
      }else{
        paymentDto.paymentBy = "Insurance";
      }
      paymentDto.totalAmount = this.paymentForm.controls['totalAmount'].value;
      paymentDto.paymentMethod = this.paymentForm.controls['paymentMethod'].value;
      paymentDto.paymentStatus = PaymentSatus.SUBMITTED;
      paymentDto.reportId = this.data.reportId;
      if (this.enableToCompanyList) {
        if (this.paymentForm.controls['toCompany'].value != null) {
          paymentDto.toCompanyName = this.paymentForm.controls['toCompany'].value;
          this.savePaymentDetails(paymentDto);
        } else {
          this.tosterservice.error(this.translate.instant("Toaster_Message.Select_company"))
          this.isButtonDisabled = false;
        }

      } else {
        paymentDto.companyAmountMap = paymentDto.companyAmountMap;
        this.savePaymentDetails(paymentDto);
      }

    } else {
      // this.ngxLoader.stop();
      if(this.paymentForm.controls['toCompany'].value == null  
          && this.paymentForm.controls['fromCompany'].value != 'Association'){
        this.tosterservice.error(this.translate.instant("Toaster_Message.Select_company"));
        this.isButtonDisabled = false;
      }else{
        this.isButtonDisabled = false;
        this.tosterservice.error(this.translate.instant("Toaster_Message.Payment_type"));
      }
    }
    // this.ngxLoader.stop();
  }

  private savePaymentDetails(paymentDto: PaymentDto) {
    if (this.fileList.length != 0) {
      if(this.fileList.length<=15){
      this.ngxLoader.start();
      this.fileService.upload(this.fileList, null, 'group').subscribe(res => {
        if (res['content']) {
          paymentDto.referenceId = res['content'];
          paymentDto.autoGeneratedPdfID = this.data.autoGeneratedPdfID;
          this.subscriptions = this.paymentService.savePayment(paymentDto).subscribe(res => {
            if (res['content']) {
              let paymentId = res['content'].paymentId;
              let toCompanyName = res['content'].toCompanyName;
              let paymentMethod = res['content'].paymentMethod;
              let paymentStatus = res['content'].paymentStatus;
              let totalAmount = res['content'].totalAmount;
              let transactionId = res['content'].transactionId;
              let referenceId = res['content'].referenceId;
              if(this.paymentForm.controls['fromCompany'].value === 'Association'){
                toCompanyName = this.paymentForm.controls['fromCompany'].value;
              }              
              this.ngxLoader.stop();
              this.toastr.success( this.translate.instant("Toaster_Message.payment_status_submit"));
              const dialogRef = this.dialog.open(ProceedToPaymentPopupComponent, {
                width: '1561px',
                height: '569px',
                data: {
                  referenceId,
                  toCompanyName,
                  paymentMethod,
                  paymentStatus,
                  totalAmount,
                  transactionId,
                  paymentId,
                  approveOrReject: this.acceptOrRejectBtn,
                  autoGeneratedPdfID: this.data.autoGeneratedPdfID,
                },
                disableClose: true 
              });              
              dialogRef.afterClosed().subscribe(result => {
                this.isButtonDisabled = false;
              });
            }
          },(error : Response) =>{
            // this.ngxLoader.stop();
            this.isButtonDisabled = false;
            this.errorHandler.getMessage(error);
          });
        }
      },(error : Response) =>{
        this.ngxLoader.stop();
        this.isButtonDisabled = false;
        this.errorHandler.getMessage(error);
      });
    }else{
      this.isButtonDisabled = false;
      this.fileNameList =[];
      this.fileList =[];
      this.toastr.error(this.translate.instant('Backend_Toaster_Error.E7151'));
    }
    } else {
      this.isButtonDisabled = false;
      this.tosterservice.error(this.translate.instant("Toaster_Message.Select_file"));
    }

  }

  getPrivilege(){
    this.appService.getPrivilegeForPage(this.pageId).subscribe((res: any)=>{
      this.pageInfo = res.content;
      this.getPageInfo(this.pageId);
    });
  }
 
  getPageInfo(pageID: number): boolean{
    if(this.pageInfo != null || this.pageInfo !== undefined){
      const pageValue = this.pageInfo.find((element: any) => element.pageId === pageID);
      return pageValue;
    }else{
      return true;
    }

  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege ? privillege.isEnabled : false;
    }
    return isEnabled;
  }

  sensorval = window.innerWidth < 600 ? true : false
  @HostListener('window:resize', ['$event'])
  onResize(event: any) {
    this.sensorval = event.target.innerWidth < 600 ? true : false
  }
  /*  Ng OnDestroy
  */
  ngOnDestroy(): void {
    this.subscriptions.unsubscribe;
  }

}

export class updateFileList {
  name: string;
  file: any;
  size: any;
  fileType: string;
}
