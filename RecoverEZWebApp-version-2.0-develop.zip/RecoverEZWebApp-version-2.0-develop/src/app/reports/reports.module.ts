import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import {  FormsModule } from "@angular/forms";
import { RouterModule } from "@angular/router";
import { ReportsComponent } from "./reports.component";
import { ReportsConfigComponent } from "./reports-config/reports-config.component";
import { ReactiveFormsModule } from "@angular/forms";
import { ReportCardModule } from "./reports-card/report-card.module";
import { ReportRoutingModule } from "./reports-routing.module";
import { DemoMaterialModule } from "../common/components/material-module";
import { TranslateModule } from "@ngx-translate/core";
import {MatTooltipModule} from '@angular/material/tooltip';
import { PaymentPopupComponent } from './payment-popup/payment-popup.component';
import { PreviewPopupComponent } from './preview-popup/preview-popup.component';
import { ProceedToPaymentPopupComponent } from './proceed-to-payment-popup/proceed-to-payment-popup.component';
import { CustomPipeModule } from "../common/pipes/custom-pipe/custom-pipe.module";
import { PdfViewerModule } from "ng2-pdf-viewer";
@NgModule({
    declarations: [
        ReportsComponent,
        ReportsConfigComponent,
        PaymentPopupComponent,
        PreviewPopupComponent,
        ProceedToPaymentPopupComponent,
    ],
    exports: [
        DemoMaterialModule
    ],
    imports: [
        CommonModule,
        FormsModule,
        ReportCardModule,
        RouterModule,
        ReportRoutingModule,
        ReactiveFormsModule,
        DemoMaterialModule,
        TranslateModule, MatTooltipModule,
        CustomPipeModule,
        PdfViewerModule, // <- Add PdfViewerModule to imports
    ]
})

export class ReportsModule{

}
