import { AppCommonModule } from './../common/components/app-common.module';
import { DemoMaterialModule } from './../common/components/material-module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PageConfigRoutingModule } from './page-config-routing.module';
import { PageConfigComponent } from './page-config.component';
import { FieldConfigureModule } from './field-configure/field-configure.module';
import { SchedulerModule } from './scheduler/scheduler.module';



@NgModule({
  declarations: [
    PageConfigComponent
  ],
  imports: [
    CommonModule,
    FieldConfigureModule,
    PageConfigRoutingModule,
    DemoMaterialModule,
    AppCommonModule,
    SchedulerModule
  ],

})
export class PageConfigModule { }
