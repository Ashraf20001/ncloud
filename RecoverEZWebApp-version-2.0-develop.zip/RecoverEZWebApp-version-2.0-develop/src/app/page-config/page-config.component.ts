import { Component } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-page-config',
  templateUrl: './page-config.component.html',
  styleUrls: ['./page-config.component.scss']
})
export class PageConfigComponent {
  fieldconfigure_Class ="fieldconfigure"
  scheduler_Class ="scheduler";
  main_page="main-page"

  tabs: TabDTO[] = [
    {
      name: 'Field Configurator',
      url: 'field-configure',
      class: 'fieldconfigure'
    },
    {
      name: 'Scheduler',
      url: 'scheduler',
      class: 'scheduler'
    }
  ];

  constructor(private router: Router, private route: ActivatedRoute){ }

  /**
   * TAB CHANGE EVENT
   * @param event
   */
  tabChange(event: MatTabChangeEvent): void {
    const tab = this.tabs.find((t: TabDTO) => t.name === event.tab.textLabel);
    if(tab) {
      this.router.navigate([tab.url], { relativeTo: this.route });
    }
  }
}

export interface TabDTO {
  name: string;
  url: string;
  class: string;
}
