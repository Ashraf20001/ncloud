import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PageConfigComponent } from './page-config.component';




const routes: Routes = [
  {
    path:'', component:PageConfigComponent,
    children: [
      {
        path:'field-configure',
        loadChildren: ()=> import('./field-configure/field-configure.module').then(m=> m.FieldConfigureModule)
      },
      {
        path:'scheduler',
        loadChildren: ()=> import('./scheduler/scheduler.module').then(m=> m.SchedulerModule)
      },
      {
        path: '',
        redirectTo: 'field-configure',
        pathMatch: 'full',
      }
      // {
      //   path:'',redirectTo:'page-config/field-configure',pathMatch:'full'
      // },

    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PageConfigRoutingModule { }
