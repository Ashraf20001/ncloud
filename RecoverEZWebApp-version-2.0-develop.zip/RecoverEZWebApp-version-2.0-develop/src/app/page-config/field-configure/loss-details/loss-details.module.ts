import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LossDetailsRoutingModule } from './loss-details-routing.module';
import { LossDetailsComponent } from './loss-details.component';
import { DemoMaterialModule } from 'src/app/common/components/material-module';


@NgModule({
  declarations: [
    LossDetailsComponent
  ],
  imports: [
    CommonModule,
    LossDetailsRoutingModule,
    DemoMaterialModule
  ],
  exports:[
    LossDetailsComponent
  ]
})
export class LossDetailsModule { }
