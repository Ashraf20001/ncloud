import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LossDetailsComponent } from './loss-details.component';

describe('LossDetailsComponent', () => {
  let component: LossDetailsComponent;
  let fixture: ComponentFixture<LossDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LossDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LossDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
