import { CdkDragDrop, moveItemInArray, copyArrayItem } from '@angular/cdk/drag-drop';
import { Component, Input, OnInit } from '@angular/core';
import remove from 'lodash-es/remove';
@Component({
  selector: 'app-loss-details',
  templateUrl: './loss-details.component.html',
  styleUrls: ['./loss-details.component.scss']
})
export class LossDetailsComponent implements OnInit {
  loss_deatils_Data: any = []
  @Input()loss_details_input;
  constructor(){

  }
  ngOnInit(): void {

  }
  /**
   * DESIGNATION DROPED ITEM
   * @param event
   */
  destinationDropped(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      copyArrayItem(event.previousContainer.data,
                        event.container.data,
                        event.previousIndex,
                        event.currentIndex);
    }
    if (event.previousContainer.data) {
      remove(this.loss_details_input, { temp: true });
    }
  }
  /**
   * REMOVE ITEM BY INDEX
   * @param index
   */
  removeItem(index:any){
    this.loss_deatils_Data.splice(index,1)
    }

}
