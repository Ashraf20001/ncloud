import { CdkDragDrop, copyArrayItem, moveItemInArray } from '@angular/cdk/drag-drop';
import { Component, Input, OnInit } from '@angular/core';
import remove from 'lodash-es/remove';
@Component({
  selector: 'app-police-report',
  templateUrl: './police-report.component.html',
  styleUrls: ['./police-report.component.scss']
})
export class PoliceReportComponent implements OnInit{
  police_report_Data:any = []
  @Input()police_report_input;
  constructor(){

  }
  ngOnInit(): void {

  }
  /**
   * DESIGNATION DROPED ITEM
   * @param event
   */
  destinationDropped(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      copyArrayItem(event.previousContainer.data,
                        event.container.data,
                        event.previousIndex,
                        event.currentIndex);
    }
    if (event.previousContainer.data) {
      remove(this.police_report_input, { temp: true });
    }
  }
  /**
   * REMOVE ITEM BY INDEX
   * @param index
   */
  removeItem(index:any){
  this.police_report_Data.splice(index,1)
  }

}
