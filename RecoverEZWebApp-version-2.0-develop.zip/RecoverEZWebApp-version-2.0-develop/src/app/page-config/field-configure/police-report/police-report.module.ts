import { DemoMaterialModule } from './../../../common/components/material-module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PoliceReportRoutingModule } from './police-report-routing.module';
import { PoliceReportComponent } from './police-report.component';


@NgModule({
  declarations: [
    PoliceReportComponent
  ],
  imports: [
    CommonModule,
    PoliceReportRoutingModule,
    DemoMaterialModule
  ],
  exports:[
    PoliceReportComponent
  ]
})
export class PoliceReportModule { }
