import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FieldConfigureComponent } from './field-configure.component';


const routes: Routes = [
  {
    path:'',
    component:FieldConfigureComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FieldConfigureRoutingModule { }
