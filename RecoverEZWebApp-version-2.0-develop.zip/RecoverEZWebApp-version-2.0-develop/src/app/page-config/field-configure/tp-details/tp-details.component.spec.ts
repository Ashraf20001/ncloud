import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TPDetailsComponent } from './tp-details.component';

describe('TPDetailsComponent', () => {
  let component: TPDetailsComponent;
  let fixture: ComponentFixture<TPDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TPDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TPDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
