import { DemoMaterialModule } from './../../../common/components/material-module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TPDetailsRoutingModule } from './tp-details-routing.module';
import { TPDetailsComponent } from '../tp-details/tp-details.component';


@NgModule({
  declarations: [
    TPDetailsComponent
  ],
  imports: [
    CommonModule,
    TPDetailsRoutingModule,
    DemoMaterialModule
  ],
  exports:[
    TPDetailsComponent
  ]
})
export class TPDetailsModule { }
