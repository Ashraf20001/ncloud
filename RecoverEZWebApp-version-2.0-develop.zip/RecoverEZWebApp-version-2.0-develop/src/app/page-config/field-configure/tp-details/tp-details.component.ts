import { CdkDragDrop, moveItemInArray, copyArrayItem } from '@angular/cdk/drag-drop';
import { Component, Input, OnInit } from '@angular/core';
import remove from 'lodash-es/remove';
@Component({
  selector: 'app-tp-details',
  templateUrl: './tp-details.component.html',
  styleUrls: ['./tp-details.component.scss']
})
export class TPDetailsComponent implements OnInit{
  tp_Data_Item: any = []
  @Input()tp_Details_input;
  constructor(){

  }
  ngOnInit(): void {

  }
  /**
   * DESIGNATION DROPED ITEM
   * @param event
   */
  destinationDropped(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      copyArrayItem(event.previousContainer.data,
                        event.container.data,
                        event.previousIndex,
                        event.currentIndex);
    }
    if (event.previousContainer.data) {
      remove(this.tp_Details_input, { temp: true });
    }
  }
  /**
   * REMOVE ITEM BY INDEX
   * @param index
   */
  removeItem(index:any){
  this.tp_Data_Item.splice(index,1)
  }

}
