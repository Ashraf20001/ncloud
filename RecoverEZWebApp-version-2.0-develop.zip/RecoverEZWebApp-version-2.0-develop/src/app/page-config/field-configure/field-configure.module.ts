import { ConfigurationModule } from './configuration/configuration.module';
import { StagesModule } from './stages/stages.module';
import { TPDetailsModule } from './tp-details/tp-details.module';
import { PoliceReportModule } from './police-report/police-report.module';
import { LossDetailsModule } from './loss-details/loss-details.module';
import { InsuredDetailModule } from './insured-detail/insured-detail.module';
import { DemoMaterialModule } from './../../common/components/material-module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FieldConfigureRoutingModule } from './field-configure-routing.module';
import { FieldConfigureComponent } from './field-configure.component';
import { AppCommonModule } from 'src/app/common/components/app-common.module';


@NgModule({
  declarations: [
    FieldConfigureComponent
  ],
  imports: [
    CommonModule,
    FieldConfigureRoutingModule,
    DemoMaterialModule,
    InsuredDetailModule,
    LossDetailsModule,
    PoliceReportModule,
    TPDetailsModule,
    StagesModule,
    ConfigurationModule,
    AppCommonModule
  ],
  exports:[
    FieldConfigureComponent
  ]
})
export class FieldConfigureModule { }
