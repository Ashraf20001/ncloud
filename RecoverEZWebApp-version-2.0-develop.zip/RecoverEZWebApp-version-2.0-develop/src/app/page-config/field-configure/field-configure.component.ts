import { CdkDragEnter, CdkDragExit } from '@angular/cdk/drag-drop';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormArray } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import * as _ from 'lodash';
import remove from 'lodash-es/remove';
import { ToastrService } from 'ngx-toastr';
import { DeletedFieldDto } from 'src/app/models/entity-management-dto/delete-fields-dto';
import { ReportDto } from 'src/app/models/entity-management-dto/report-dto';
import { FieldConfig } from 'src/app/models/field-config';
import { Field } from 'src/app/models/report-loss-dto/field';
import { MetaDataDto } from 'src/app/models/report-loss-dto/meta-data-dto';
import { Section } from 'src/app/models/report-loss-dto/section';
import { ReportLossService } from 'src/app/service/report-loss.service';
import { ConfigurationComponent } from './configuration/configuration.component';
import { InsuredDetailComponent } from './insured-detail/insured-detail.component';
import { StagesComponent } from './stages/stages.component';

@Component({
  selector: 'app-field-configure',
  templateUrl: './field-configure.component.html',
  styleUrls: ['./field-configure.component.scss']
})
export class FieldConfigureComponent implements OnInit {
  insured_detail_Class = "insured";
  tp_detail_Class = "tp";
  loss_detail_Class = "loss";
  police_detail_Class = "police";
  sub_page = "sub-page";
  /**MOCK DATA FOR FIELDS */
  FiledItem_Data: Field[] = [
    {
      fieldId: null, aliasName: 'Text Box', icon: 'assets/page_config_icons/textboxt.svg',
      defaultValues: '', columnName: '', entityName: '', fieldName: 'Text Box', fieldType: 'text',
      isCoreData: false, mandatory: false, value: '', referenceId: null, index: null, isSystemGenerated: false, tempId: null
    },

    {
      fieldId: null, aliasName: 'Drop Down', icon: 'assets/page_config_icons/dropdown.svg',
      defaultValues: '', columnName: '', entityName: '', fieldName: 'Drop Down', fieldType: 'Dropdown',
      isCoreData: false, mandatory: false, value: '', referenceId: null, index: null, isSystemGenerated: false, tempId: null
    },

    // {
    //   fieldId: null, aliasName: 'MultiSelect', icon: 'assets/page_config_icons/multiselect.svg',
    //   defaultValues: '', columnName: '', entityName: '', fieldName: 'MultiSelect', fieldType: 'MultiSelect',
    //   isCoreData: false, mandatory: false, value: '', referenceId: null, index: null, isSystemGenerated: false, tempId: null
    // },

    {
      fieldId: null, aliasName: 'Date', icon: 'assets/page_config_icons/date.svg',
      defaultValues: '', columnName: '', entityName: '', fieldName: 'Date', fieldType: 'pDate',
      isCoreData: false, mandatory: false, value: '', referenceId: null, index: null, isSystemGenerated: false, tempId: null
    },

    {
      fieldId: null, aliasName: 'checkBox', icon: 'assets/page_config_icons/checkbox.svg',
      defaultValues: '', columnName: '', entityName: '', fieldName: 'checkBox', fieldType: 'checkbox',
      isCoreData: false, mandatory: false, value: '', referenceId: null, index: null, isSystemGenerated: false, tempId: null
    },

    // {
    //   fieldId: null, aliasName: 'Radio', icon: 'assets/page_config_icons/radio.svg',
    //   defaultValues: '', columnName: '', entityName: '', fieldName: 'Radio', fieldType: 'RadioButton',
    //   isCoreData: false, mandatory: false, value: '', referenceId: null, index: null, isSystemGenerated: false, tempId: null
    // },

    {
      fieldId: null, aliasName: 'File Upload', icon: 'assets/page_config_icons/fileupload.svg',
      defaultValues: '', columnName: '', entityName: '', fieldName: 'fileUpload', fieldType: 'file',
      isCoreData: false, mandatory: false, value: '', referenceId: null, index: null, isSystemGenerated: false, tempId: null
    }
  ]
  subSectionList = [];
  fieldList: Field[] = [];
  stageSectionMap = new Map<String, string[]>();
  sectionFieldMap = new Map<String, Field[]>();
  deletedFieldMap = new Map<String, String[]>();
  metaData: MetaDataDto;
  MetaDatoList: ReportDto[] = [];
  updatedMetaDataList: ReportDto[] = [];
  subSection: any;
  sectionName: string;
  fieldForChild: [];
  sectionList: any[];
  inputData = [];
  test = [];
  activeSection: any;
  deletedFieldList: DeletedFieldDto[] = [];
  stageDetailsList: Section[] = [];
  @ViewChild('configuration') configuration: ConfigurationComponent
  @ViewChild('stage') stage: StagesComponent
  @ViewChild('fieldList') fields: InsuredDetailComponent
  selectedStage: any;
  isObjectAdded: boolean;
  isFieldChanged: boolean = false;
  fieldAddedToDeletion: boolean;
  addedIndex: any;
  isNewFieldAdded: boolean;
  stageSectionData: Section[] = [];
  fieldAddCount = 1;
  constructor(private reportService: ReportLossService, private toastr: ToastrService, private translate:TranslateService) { }

  ngOnInit(): void {
    this.getMetaData();
  }

  private getMetaData() {
    this.reportService.getMetaDataDto("sdjashbsdadajdkui", null).subscribe((response) => {
      if (response) {
        this.metaData = response.metaData;
        this.stageSectionData = [];
        response.metaData.sectionList.forEach(element => {
          let section = new Section();
          section.sectionName = element.sectionName;
          section.isEnabled = (element.isEnabled == null || element.isEnabled == false) ? false : true;
          section.sectionId = element.sectionId;
          this.stageSectionData.push(section);
          this.sectionList = [];
          element.sectionList.forEach(ele => {
            this.sectionList.push(ele.sectionName);
          });
          this.stageSectionMap.set(element.sectionName, this.sectionList)
        });

        this.metaData.sectionList.forEach(section => {
          if (section.sectionList.length > 0 && (section.fieldList == null || section.fieldList.length == 0)) {
            section.sectionList.forEach((subSection => {
              if (subSection.fieldList.length != 0) {
                this.sectionName = subSection.sectionName;
                this.fieldList = [];
                subSection.fieldList = subSection.fieldList.sort((a: Field, b: Field) => a.orderBy - b.orderBy);
                subSection.fieldList.forEach(field => {
                  this.fieldList.push(field);
                  this.sectionFieldMap.set(this.sectionName, this.fieldList);
                })
              }
            }))
          }
          for (let data of this.sectionFieldMap.keys()) {
            this.subSectionList.push(data);
          }
          let uniqueSections = [...new Set(this.subSectionList)];
          this.subSectionList = uniqueSections;
        });
        this.getSelectedStage(this.stageSectionData[0].sectionName);
        this.stage.activeStage = this.stageSectionData[0];
        this.configuration.activeField = null;
        this.tabchange(this.activeSection)
      }
    },
      (error) => {
        console.log(error);
      }
    );
  }
  /**
   * PREDICATE EMPTY DEFAULT
   * @returns
   */
  noReturnPredicate() {
    return false;
  }
  /**
   * DRAG THE POINTER EXIT
   * @param event
   */
  onSourceListExited(event: CdkDragExit<any>) {
    this.FiledItem_Data.splice(event.container.data(event.item) + 1, 0, { ...event.item.data, temp: true });
  }
  /**
   * TAB CHANGE EVENT TRIGGER
   * @param event
   */
  tabchange(event: any) {
    // if (this.configuration.activeField != null) {
    //   this.getUpdateFields(true);
    // }
    this.inputData = [];
    this.activeSection = event === undefined || event.tab == undefined ? this.activeSection : event.tab.textLabel;
    if(this.activeSection) {
      const sectionFieldObject = this.sectionFieldMap.get(this.activeSection);
      sectionFieldObject.forEach(element => {
        this.FiledItem_Data.forEach(ele => {
          (ele.aliasName == element.fieldType) ? element.icon = ele.icon : ''
        })
        this.inputData.push(element)
      });
      this.reportService.loaderDataForTabChange.next(this.inputData);
    }
  }
  /**
   * DRAG THE POINTER ENTERED
   * @param event
   */
  onSourceListEntered(event: CdkDragEnter<any>) {
    remove(this.FiledItem_Data, { temp: true });
  }

  getSelectedStage(event: any) {
    this.selectedStage = event;
    this.subSectionList = [];
    this.stageSectionMap.get(event).forEach(ele => {
      this.subSectionList.push(ele);
    })
  }

  getDeletedField(event: any) {
    const index = this.inputData.indexOf(event);
    this.inputData.splice(index, 1);
    const map = this.sectionFieldMap.get(this.activeSection);
    const mapIndex = map.indexOf(event);
    map.splice(mapIndex, 1);

    this.fieldAddedToDeletion = false;
    if (this.deletedFieldList.length > 0) {
      let mapObject = this.deletedFieldList.forEach(ele => {
        if (ele.sectionName == this.activeSection) {
          this.fieldAddedToDeletion = true;
          ele.fieldId.push(event.fieldId)
        }
      })
    }

    if (this.fieldAddedToDeletion == false) {
      let deletedIdnty = [];
      deletedIdnty.push(event.fieldId);
      let dltFld = new DeletedFieldDto();
      dltFld.sectionName = this.activeSection;
      dltFld.fieldId = deletedIdnty;
      this.deletedFieldList.push(dltFld)
    }
  }

  updateOrder(fieldList: Field[]): void {
    let metaDataDto = new ReportDto();
    metaDataDto.fieldList = fieldList;
    metaDataDto.section = this.activeSection;
    metaDataDto.stage = this.selectedStage;
    this.updatedMetaDataList.push(metaDataDto);
  }

  getUpdateFields(evt: any) {
    this.isFieldChanged = false;
    let fieldObject = this.configuration.activeField;
    if (fieldObject != null) {
      fieldObject.isCoreData = this.configuration.fieldConfigForm.controls['coreDataControl'].value;
      fieldObject.aliasName = this.configuration.fieldConfigForm.controls['fieldNameControl'].value;
      fieldObject.mandatory = this.configuration.fieldConfigForm.controls['mandatoryControl'].value;
      if (this.configuration.canShowDropDown) {
        fieldObject.referenceId = this.configuration.fieldConfigForm.controls['datatypeControlControl'].value;
        fieldObject.dropDownList = this.configuration.fieldConfigForm.controls['listofFieldOptions'].value;
      } else {
        fieldObject.fieldType = this.configuration.fieldConfigForm.controls['optionControlControl'].value
      }
      if (fieldObject.fieldId != null) {
        let sectionFieldObject = this.sectionFieldMap.get(this.activeSection);
        for (let sectionFld of sectionFieldObject) {
          if (!(objectEquals(sectionFld, fieldObject)) && sectionFld.fieldId == fieldObject.fieldId) {
            this.isFieldChanged = true;
            break;
          }
        }

        if (this.isFieldChanged) {
          let identityArray = this.inputData.map(ele => ele.fieldId);
          let index = identityArray.indexOf(fieldObject.fieldId)
          this.inputData[index] = fieldObject;

          let fieldIdentity = sectionFieldObject.map(ele => ele.fieldId);
          for (let i = 0; i < fieldIdentity.length; i++) {
            if (fieldIdentity[i] == fieldObject.fieldId) {
              sectionFieldObject[i] = fieldObject;
            }
          }

          this.isObjectAdded = false;
          let metaDataDto = new ReportDto();
          metaDataDto.fieldList.push(fieldObject);
          metaDataDto.section = this.activeSection;
          metaDataDto.stage = this.selectedStage;

          if (this.MetaDatoList.length > 0) {
            this.MetaDatoList.forEach(ele => {
              if (ele.section == metaDataDto.section && metaDataDto.stage == this.selectedStage) {
                let fieldIdty = ele.fieldList.map(res => res.fieldId)
                let index = fieldIdty.indexOf(fieldObject.fieldId)
                this.isObjectAdded = true;
                if (index != -1) {
                  ele.fieldList[index] = fieldObject
                } else {
                  ele.fieldList.push(fieldObject);
                }
              }
            })
          }

          if (this.isObjectAdded == false) {
            this.MetaDatoList.push(metaDataDto);
          }
        }
        this.reportService.loaderDataForTabChange.next(this.inputData);
      } else {
        let tempIdentityArray = this.inputData.filter(ele => ele.tempId != undefined || ele.tempId != null).map(ele => ele.tempId);
        let index = tempIdentityArray.indexOf(fieldObject.tempId)
        this.inputData[index] = fieldObject;

        let sectionFieldObject = this.sectionFieldMap.get(this.activeSection);
        let fieldTempIdentity = sectionFieldObject.filter(ele => ele.tempId != undefined || ele.tempId != null).map(ele => ele.tempId);
        for (let i = 0; i < fieldTempIdentity.length; i++) {
          if (fieldTempIdentity[i] == fieldObject.tempId) {
            sectionFieldObject[i] = fieldObject;
          }
        }
        this.isNewFieldAdded = false
        let metaDataDto = new ReportDto();
        metaDataDto.fieldList.push(fieldObject);
        metaDataDto.section = this.activeSection;
        metaDataDto.stage = this.selectedStage;

        this.MetaDatoList.forEach(ele => {
          if (ele.section == metaDataDto.section && metaDataDto.stage == this.selectedStage) {
            let fieldIdty = ele.fieldList.map(res => res.tempId)
            let index = fieldIdty.indexOf(fieldObject.tempId)
            if(index == -1){
              ele.fieldList.push(fieldObject);
            }else{
              ele.fieldList[index] = fieldObject;
            }
            this.isNewFieldAdded = true;
          }
        })
        if (this.isNewFieldAdded == false) {
          this.MetaDatoList.push(metaDataDto)
        }
      }
    }
  }

  saveConfiguration() {
    if(this.stageDetailsList.length > 0){
      this.reportService.enableDisableSections(this.stageDetailsList).subscribe((response)=>{
      })
    }
    this.getUpdateFields(true);
    if (this.MetaDatoList.length > 0 || this.deletedFieldList.length > 0 || this.updatedMetaDataList.length > 0) {
      const data = new FieldConfig();
      data.pageId = 'sdjashbsdadajdkui';
      data.deletedFields = this.deletedFieldList
      data.updatedFields = this.MetaDatoList;
      if(data.updatedFields && data.updatedFields.length > 0) {
        this.updatedMetaDataList.forEach((value: ReportDto) => {
          const idx = data.updatedFields.findIndex((v: ReportDto) => v.stage === value.stage && v.section === value.section);
          if(idx !== -1) {
            value.fieldList.forEach((x: Field) => {
              const ix = data.updatedFields[idx].fieldList.findIndex((y: Field) => y.fieldId === x.fieldId);
              if(ix !== -1) {
                data.updatedFields[idx].fieldList[ix] = x;
              } else {
                data.updatedFields[idx].fieldList.push(x);
              }
            });
          } else {
            data.updatedFields.push(value);
          }
        });
      } else {
        data.updatedFields = this.updatedMetaDataList;
      }
      this.reportService.modifyMetaData(data).subscribe((data) => {
        if (data) {
          this.MetaDatoList = [];
          this.deletedFieldList = [];
          this.updatedMetaDataList = [];
          this.getMetaData();
        }
        this.toastr.success(this.translate.instant("Toaster_Message.field_modified"))
      }, (error)=> {
          this.MetaDatoList = [];
          this.deletedFieldList = [];
          this.updatedMetaDataList = [];
          this.getMetaData();
          const options = this.configuration.fieldConfigForm.get('listofFieldOptions') as FormArray;
          options.clear();
          this.configuration.listofFieldOptions.forEach(opt =>options.push(this.configuration.fb.group(opt)));
      })
    } else {
      if(this.stageDetailsList.length > 0){
        this.toastr.success(this.translate.instant("Toaster_Message.section_modified"))
        this.stageDetailsList = [];
      }else{
        this.toastr.error(this.translate.instant('Backend_Toaster_Error.E7150'));
      }
    }
  }

  getNewlyAddedFields(evt: any) {
    let fieldObject = _.cloneDeep(evt);
    let sectionFieldLnk = this.sectionFieldMap.get(this.activeSection);
    fieldObject.tempId = null;
    fieldObject.tempId = this.fieldAddCount;
    sectionFieldLnk.splice(this.addedIndex, 0, fieldObject);
    this.fieldAddCount++;
    this.inputData = [];
    sectionFieldLnk.forEach(element => {
      this.FiledItem_Data.forEach(ele => {
        (ele.aliasName == element.fieldType) ? element.icon = ele.icon : ''
      })
      this.inputData.push(element)
    });
    this.reportService.loaderDataForTabChange.next(this.inputData);
  }

  getAddedIndex(event: any) {
    this.addedIndex = event;
  }

  getStageDetails(event:any){ 
    let idList = this.stageDetailsList.map(ele=> ele.sectionId);
    let posistion = idList.indexOf(event.sectionId);
    if(posistion == -1){
      this.stageDetailsList.push(event);
    }else{
      this.stageDetailsList[posistion] = event;
    }
  }
}
export function objectEquals(obj1, obj2) {
  for (var i in obj1) {
    if (obj1.hasOwnProperty(i)) {
      if (!obj2.hasOwnProperty(i)) return false;
      if (obj1[i] != obj2[i]) return false;
    }
  }
  for (var i in obj2) {
    if (obj2.hasOwnProperty(i)) {
      if (!obj1.hasOwnProperty(i)) return false;
      if (obj1[i] != obj2[i]) return false;
    }
  }
  return true;
}
