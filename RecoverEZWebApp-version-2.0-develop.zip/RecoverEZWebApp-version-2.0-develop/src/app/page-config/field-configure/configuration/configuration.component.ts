import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { ReportLossService } from 'src/app/service/report-loss.service';
import { Field } from 'src/app/models/report-loss-dto/field';
import { DropDownListDto, DropDownTypeDto } from 'src/app/models/entity-management-dto/drop-down-type';
import { DropDownServiceService } from 'src/app/service/drop-down-service.service';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-configuration',
  templateUrl: './configuration.component.html',
  styleUrls: ['./configuration.component.scss']
})
export class ConfigurationComponent implements OnInit {
  @Output() updatedField = new EventEmitter<any>();
  @Output() addedField = new EventEmitter<any>();
  @Output() addedIndex = new EventEmitter<any>();
  select: any
  fieldConfigForm!: FormGroup;
  canShowDataType: boolean;
  canShowDropDown: boolean;
  activeField: Field = null;
  listofFieldOptions: any;
  isReadOnly: boolean;
  isDropDownOption: boolean;
  selectedField: null;
  dropDownOptionData: any[];
  existingOptions: any;
  constructor(public fb: FormBuilder, private report: ReportLossService, private dropDownService : DropDownServiceService,
    private reportService: ReportLossService, private toastrService: ToastrService, private translateService: TranslateService) { 
  }

  /** ACCESS MOCK DATA */
  Access_List_Data: any = [
    { IsActive: true, Name: 'Insured Company' },
    { IsActive: false, Name: 'Third Part Company' },
  ];
  /** OPTION MOCK DATA */
  Options_Data: DropDownTypeDto[] = [
    { value: '0', viewValue: 'Long' },
    { value: '1', viewValue: 'Double' },
    { value: '2', viewValue: 'Boolean' },
    { value: '3', viewValue: 'String' }
  ];
  dataType = ["STRING", "NUMBER", "LONG", "BOOLEAN", "DOUBLE", "TEXT"]
  optionalDataType = ["DROPDOWN", "MULTISELECT"]


  radio_data = [
    { value: false, viewValue: 'Insurance Company' },
    { value: true, viewValue: 'Third Party Company' }
  ]
 
   /** OPTION MOCK DATA */
   data_Type_Data: DropDownTypeDto[] = [
    { value: '0', viewValue: 'Long' },
    { value: '1', viewValue: 'Double' },
    { value: '2', viewValue: 'Boolean' },
    { value: '3', viewValue: 'String' }
  ];
 
  ngOnInit(): void {
    this.report.getDropDownList().subscribe((data: any) => {
      this.Options_Data = [];
      for (let i = 0; i < data.length; i++) {
        let dropdown = new DropDownTypeDto()
        dropdown.value = data[i].dropDownId;
        dropdown.viewValue = data[i].dropDownName;
        this.Options_Data.push(dropdown)
      }
    })
    this.formBuilder();
    this.report.editedField.subscribe((data) => {
      this.activeField = null;
      if (data != null && data != undefined) {
        let recievedData = JSON.stringify(data);
        if(recievedData){
          this.activeField = JSON.parse(recievedData);
          this.fieldConfigForm.reset();
          this.formBuilder();
          this.isDropDownOption = false;
          if (this.activeField.isSystemGenerated) {
            this.fieldConfigForm.controls['datatypeControlControl'].disable();
            this.fieldConfigForm.controls['optionControlControl'].disable();
            this.fieldConfigForm.controls['fieldNameControl'].disable();
            this.fieldConfigForm.controls['mandatoryControl'].disable();
            this.fieldConfigForm.controls['coreDataControl'].disable();
          }
          this.fieldConfigForm.controls['fieldNameControl'].setValue(this.activeField.aliasName);
          this.fieldConfigForm.controls['mandatoryControl'].setValue(this.activeField.mandatory);
          this.fieldConfigForm.controls['coreDataControl'].setValue(this.activeField.isCoreData);
          this.canShowDataType = this.dataType.includes(this.activeField.fieldType.toUpperCase());
          this.canShowDropDown = this.optionalDataType.includes(this.activeField.fieldType.toUpperCase());
          this.fieldConfigForm.controls['datatypeControlControl'].setValue(this.activeField.referenceId);
          this.fieldConfigForm.controls['optionControlControl'].setValue(this.activeField.fieldType);
          this.fieldConfigForm.controls['listofFieldOptions'].disable();
          if(this.canShowDropDown){
            this.onSelectionChange(this.activeField.referenceId);
          }
        }
        }
    })
  }
  private formBuilder() {
    this.fieldConfigForm = this.fb.group({
      fieldNameControl: [''],
      mandatoryControl: [''],
      datatypeControlControl: [''],
      optionControlControl: [''],
      coreDataControl: [''],
      AccessList: this.fb.array([], [customValidateArrayGroup()]),
      listofFieldOptions: this.fb.array([])
    });
    this.buildAccessListForFormGroup();
    this.addOptionFormGroup(1);
  }
  private buildAccessListForFormGroup() {
    this.Access_List_Data.forEach(value => {
      this.channels.push(this.fb.group({
        isActive: value.IsActive,
        name: value.Name
      }));
    });
  }

  get channels() {
    return this.fieldConfigForm.get('AccessList') as FormArray;
  }
  /**
   * @function build-dropdown-data
   */
  get dropDownData() {
    return this.fieldConfigForm.get('listofFieldOptions') as FormArray;
  }

  /**
   * RADIO CHNAGE EVENT
   * @param event
   */
  changeEventRadio(event: any) {
    let result = event;
  }

   /**
   * DROP-DOWN CHNAGE EVENT
   * @param event
   */
  onSelectionChange(event: any): void {
    let dropDownListId = event.value;
    if(dropDownListId == undefined){
       dropDownListId = event;
    }
    if(event){
      this.dropDownService.getDropDownOptionList(dropDownListId).subscribe((response:any)=>{
        if (response) {
          this.listofFieldOptions = [];
          this.listofFieldOptions = response.content;
          const options = this.fieldConfigForm.get('listofFieldOptions') as FormArray;
          options.clear();
          this.listofFieldOptions.forEach(opt =>options.push(this.fb.group(opt)));
        }
      })
    }
  }
  

   /**
   * @function remove-existing-dropdown
   * @param index 
   */
   deleteOptionFormGroup(index: number) {
    const options = this.dropDownData;
    if(this.dropDownData.length > 1){
      options.removeAt(index);
    }
    return;
  }

   /**
   * @function add-new-dropdown
   * @param index
   */
   addOptionFormGroup(index : number) {
    const options = this.fieldConfigForm.get('listofFieldOptions') as FormArray;
     options.insert(index, this.createOptionFormGroup());
  }
  
  /**
   * @function event-trigger-for-collecting-dropdown-options
   * @param changedInput 
   * @param index 
  */
 monitorInputChange(changedInput : any, index : number){
   if(changedInput.value == ''){
     return;
    }else{
      const value = changedInput.value;
      const existing = this.dropDownData.value.filter((d: any) => d.dropDownName.toLowerCase() === value.toLowerCase());
      if(existing && existing.length > 1) {
        this.toastrService.error(this.translateService.instant("Backend_Toaster_Error.E8028"));
      } else {
        this.dropDownData.value[index].dropDownName = changedInput.value;
        this.updatedField.emit(true);
      }
    }
  }
  
  /**
  * @function init-dropdown-options 
  */
  createOptionFormGroup() {
   const dropDownOptionValue: DropDownListDto = {
    dropDownId : null,
    dropDownName : null,
    dropDownType: null,
    identity:null,
   };
   return this.fb.group(dropDownOptionValue);
 }
}

/**
 * CHECKBOX ERROR ABSTRACT METHOD
 * @returns
 */
export function customValidateArrayGroup() {
  return function validate(formArr: AbstractControl): ValidationErrors | null {
    const filtered = formArr.value.filter(chk => chk.isActive);
    return filtered.length ? null : { hasError: true }
  };
}

