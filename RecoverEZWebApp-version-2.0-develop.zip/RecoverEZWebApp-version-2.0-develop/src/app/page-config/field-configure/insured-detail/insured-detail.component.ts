import { CdkDragDrop, moveItemInArray, copyArrayItem } from '@angular/cdk/drag-drop';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import remove from 'lodash-es/remove';
import { debounceTime, distinctUntilChanged } from 'rxjs';
import { Field } from 'src/app/models/report-loss-dto/field';
import { ReportLossService } from 'src/app/service/report-loss.service';
@Component({
  selector: 'app-insured-detail',
  templateUrl: './insured-detail.component.html',
  styleUrls: ['./insured-detail.component.scss']
})
export class InsuredDetailComponent implements OnInit {
  insured_details_Data: any = []
  @Input() insured_details_input;
  @Output() deletedField = new EventEmitter<any>();
  @Output() updatedField = new EventEmitter<any>();
  @Output() addedField = new EventEmitter<any>();
  @Output() addedIndex = new EventEmitter<any>();
  @Output() orderChangeForField = new EventEmitter<Field[]>();
  selectedField: any = null;
  activeField: any;
  index: any = 0;
  constructor(private reportService: ReportLossService) {

  }
  ngOnInit(): void {
    this.reportService.loaderDataForTabChange.pipe(debounceTime(300),distinctUntilChanged()).subscribe(data => {
      if(data.length > 0){
        this.activeField = null;
        this.selectedField = null;
        this.insured_details_Data = [];
        this.insured_details_Data = data;
        this.insured_details_Data.sort((a: Field, b: Field) => a.orderBy - b.orderBy);
      }
    });
    if(this.insured_details_Data) {
      this.insured_details_Data.sort((a: Field, b: Field) => a.orderBy - b.orderBy);
    }
  }
  /**
   * DESIGNATION DROPED ITEM
   * @param event
   */
  destinationDropped(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      // const idx = this.insured_details_Data.findIndex((field: Field)=>field.fieldId === event.item.data.fieldId);
      // if(idx !== -1) {
      //   this.insured_details_Data[idx].orderBy = event.currentIndex + 1;
      // }
      const updatedFields: Field[] = [];
      if(event.previousIndex > event.currentIndex) {
        for(let i=event.currentIndex; i<this.insured_details_Data.length; i++) {
          if(this.insured_details_Data[i].fieldId === event.item.data.fieldId) {
            this.insured_details_Data[i].orderBy = event.currentIndex + 1;
          } else {
            this.insured_details_Data[i].orderBy += 1;
          }
          updatedFields.push(this.insured_details_Data[i]);
        }
      } else {
        for(let i=event.previousIndex; i<this.insured_details_Data.length; i++) {
          if(this.insured_details_Data[i].fieldId === event.item.data.fieldId) {
            this.insured_details_Data[i].orderBy = event.currentIndex + 1;
          } else {
            this.insured_details_Data[i].orderBy -= 1;
          }
          updatedFields.push(this.insured_details_Data[i]);
        }
      }
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
      this.activeField = this.insured_details_Data[event.currentIndex];
      this.selectedField = this.insured_details_Data[event.currentIndex];
      this.reportService.editedField.next(this.insured_details_Data[event.currentIndex]);
      this.orderChangeForField.emit(updatedFields);
    } else {
      if(event.currentIndex < this.insured_details_Data.length) {
        const updatedFields: Field[] = [];
        for(let i=event.currentIndex; i<this.insured_details_Data.length; i++) {
          this.insured_details_Data[i].orderBy += 1;
          updatedFields.push(this.insured_details_Data[i]);
        }
        this.orderChangeForField.emit(updatedFields);
      }
      copyArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );
      event.item.data.orderBy = event.currentIndex + 1;
      this.addedIndex.emit(event.currentIndex);
      this.emitSelectedField(this.insured_details_Data[event.currentIndex]);
    }
// if (event.previousContainer.data) {
    //   remove(this.insured_details_input, { temp: true });
    // }
  }
  /**
   * REMOVE ITEM BY INDEX
   * @param index
   */
  removeItem(index: any, field: any) {
    const updatedFields: Field[] = [];
    for(let i=index+1; i<this.insured_details_Data.length; i++) {
      this.insured_details_Data[i].orderBy -= 1;
      updatedFields.push(this.insured_details_Data[i]);
    }
    if(updatedFields.length > 0) {
      this.orderChangeForField.emit(updatedFields);
    }
    this.deletedField.emit(field);
  }

  emitSelectedField(field: any) {
    this.activeField = field;
    this.selectedField = field;
    this.reportService.editedField.next(field);
    this.updatedField.emit(this.selectedField);
  }

}
