import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SchedulerCardComponent } from './scheduler-card/scheduler-card.component';
import { SchedulerEditComponent } from './scheduler-edit/scheduler-edit.component';
import { SchedulerListComponent } from './scheduler-list/scheduler-list.component';
import { SchedulerComponent } from './scheduler.component';

const routes : Routes =  [
  {
    path: '',
    component: SchedulerComponent,
    children: [
      {
        path: 'card',
        component: SchedulerCardComponent,

      },
      {
        path: 'list',  component:SchedulerListComponent,

      },
      {
        path: 'edit/:schedularId',  component:SchedulerEditComponent,

      },
      {
        path: '',
        redirectTo: 'card',
        pathMatch: 'full'
      }
    ]
  }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SchedulerRoutingModule { }
