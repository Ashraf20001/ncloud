import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { SchedulerService } from 'src/app/service/scheduler.service';
import { PopupComponent } from 'src/app/common/components/popup/popup.component';



@Component({
  selector: 'app-scheduler-view',
  templateUrl: './scheduler-card.component.html',
  styleUrls: ['./scheduler-card.component.scss']
})
export class SchedulerCardComponent{

  show_edit=false;
  @Output() tableEvent= new EventEmitter<boolean>();
  values=true;
  constructor(
    private scheduler:SchedulerService ,private router:Router,private activateRoute:ActivatedRoute,
    private dialog:MatDialog
  ){
    this.gettabledata();
  }

  schedularId:any
  datalist:any
  gettabledata(){
    this.scheduler.getschedulerdetail().subscribe((data:any)=>{
      this.datalist=data.content;
    }
  )};

  editfun(value){
    this.show_edit=!this.show_edit;
    this.schedularId=value;
    this.router.navigate(['..','edit',value], {relativeTo: this.activateRoute});
  }
  editfun1(){
    this.router.navigateByUrl('/page-config/scheduler/list')
  }
  changes($event: boolean){
    // debugger;
    this.show_edit= !$event;
  }

  opendelete(){

    const dialogRef = this.dialog.open(PopupComponent, {
     width: '30%',
     height:'20%',
         data: {
         message: "Are you sure you want to delete?",
          okButton: "Ok",
           cancelButton: "Cancel"
         }
     });
     dialogRef.afterClosed().subscribe(result => {
      if (result) {
console.log()
         }
     });
     return false;
    }

}
