import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SchedulerRoutingModule } from './scheduler-routing.module';
import { SchedulerComponent } from './scheduler.component';
import {MatCardModule} from '@angular/material/card';
import { SchedulerListComponent } from './scheduler-list/scheduler-list.component';
import { SchedulerEditComponent } from './scheduler-edit/scheduler-edit.component';
import { SchedulerCardComponent } from './scheduler-card/scheduler-card.component';
import { MatTableModule } from '@angular/material/table'
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatSelectModule} from '@angular/material/select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatTooltipModule} from '@angular/material/tooltip';
import {  TranslateModule } from '@ngx-translate/core';
import { MatPaginatorModule } from '@angular/material/paginator';


@NgModule({
  declarations: [
    SchedulerComponent,
    SchedulerListComponent,
    SchedulerEditComponent,
    SchedulerCardComponent


  ],
  imports: [
    CommonModule,
    SchedulerRoutingModule,
    MatCardModule,
    MatTableModule,
    MatSlideToggleModule,
    MatSelectModule,
    FormsModule,
    ReactiveFormsModule,
    MatTooltipModule,
    TranslateModule,
    MatPaginatorModule

  ],
  exports:[
    SchedulerComponent,
    SchedulerListComponent,
    SchedulerEditComponent,
    SchedulerCardComponent
  ]
})
export class SchedulerModule { }
