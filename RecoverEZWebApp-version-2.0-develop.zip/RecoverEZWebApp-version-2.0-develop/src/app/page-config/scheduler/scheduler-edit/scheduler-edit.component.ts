import { Component, EventEmitter, Input,OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { SchedulerNotificationDto } from 'src/app/models/scheduler-dto';
import { SchedulerService } from 'src/app/service/scheduler.service';

@Component({
  selector: 'app-scheduler-edit',
  templateUrl: './scheduler-edit.component.html',
  styleUrls: ['./scheduler-edit.component.scss']
})
export class SchedulerEditComponent implements OnInit {
  isActive: any;
  schedulerId: number;
  schdulerListElement:SchedulerNotificationDto;
  editvaluelist:any;
  editvalue=true;
  editvalues=true;
  dropdown = [];
  actionlist=[
    {id: 1,name:'Resend Notification'}
  ];

  form = new FormGroup({
    trigger: new FormControl("", [Validators.required]),
    remainder: new FormControl("", [Validators.required]),
  });
  remainderTime = new FormControl('');
  hours: number;
  action: string;

  constructor(
    private scheduler:SchedulerService ,private router:Router,private activeRoute:ActivatedRoute,
    private toastrService: ToastrService, private translateService: TranslateService
  ){}
  
  ngOnInit(): void {
    this.form.controls['trigger'].disable();
    this.form.controls['remainder'].disable();
    this.activeRoute.params.subscribe((params: any) => {
      if(params['schedularId']){
        this.schedulerId = +params['schedularId'];
        this.getEdit();
      }
    });
    
  }

 setDropDownValues(): { id: number, name: string }[] {
    this.dropdown = [
        { id: 1, name: '2' },
        { id: 2, name: '5' },
        { id: 3, name: '1' },
        { id: 4, name: '3' }
    ];

    if (this.editvaluelist?.notificationName === 'Survey Due Date') {
        this.dropdown = [
            { id: 1, name: '24' },
            { id: 2, name: '48' },
            { id: 3, name: '72' },
            { id: 4, name: '96' },
        ];
    }

    return this.dropdown;
}

  
  getEdit(): void {
    this.scheduler.getedit(this.schedulerId).subscribe((res: any) => {
        if (res.content) {
            this.editvaluelist = res.content;
            this.isActive = this.editvaluelist.isActive;
            this.setDropDownValues();
            const remainderValue = {id: 1, name: this.editvaluelist.remainder};
            this.dropdown.push(remainderValue);
            this.action = this.editvaluelist.action;
            this.hours = this.editvaluelist.remainder;
            this.remainderTime.setValue(JSON.stringify(this.hours));
        }
    });
}

  
  
  onToggling(event: any){
    this.isActive=event.checked;
  }

  onSelect(value:any){
    this.hours=value;
  //   this.dropdown.forEach((x, index) => {
  //     if (x.name === this.editvaluelist.remainder) {
  //         this.dropdown.splice(index, 1);
  //     }
  // });
  
  }

  onSelectActionChange(value:any){
    this.action=value;

  }

  savedata2(schdulerData:SchedulerNotificationDto){
    this.getEmptyschdulerListElement()
    this.schdulerListElement.schedularId=schdulerData.schedularId,
    this.schdulerListElement.triggeredStatus=schdulerData.triggeredStatus,
    this.schdulerListElement.message = schdulerData.message,
    this.schdulerListElement.notificationName = schdulerData.notificationName,
    this.schdulerListElement.remainder= this.hours,
    this.schdulerListElement.isActive = this.isActive,
    this.schdulerListElement.action = this.action,
    this.scheduler.savedata(this.schdulerListElement).subscribe((data:any)=>{
      this.toastrService.success(this.translateService.instant("Toaster_Message.Scheduler_update_success"));
      this.goBack();
    });
  }

  goBack(): void {
    this.router.navigateByUrl('/page-config/scheduler');
  }

  getEmptyschdulerListElement(){
    this.schdulerListElement={
      schedularId:0,
      notificationName:"",
      message:"",
      triggeredStatus:"",
      remainder:0,
      action:"",
      isActive :false,
    };
  }
}
