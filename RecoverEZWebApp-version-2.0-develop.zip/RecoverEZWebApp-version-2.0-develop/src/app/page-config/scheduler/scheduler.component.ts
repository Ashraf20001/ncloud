import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { SchedulerNotificationDto, updateDto } from 'src/app/models/scheduler-dto';
import { SchedulerService } from 'src/app/service/scheduler.service';










export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}





@Component({
  selector: 'app-scheduler',
  templateUrl: './scheduler.component.html',
  styleUrls: ['./scheduler.component.scss']
})
export class SchedulerComponent implements OnInit {

  constructor(
    private scheduler:SchedulerService,private activateRoute:ActivatedRoute, private router: Router,private formBuilder:FormBuilder
  ){
   // this.gettabledata()
  }

  // @ViewChild(MatPaginator,{ static: true }) paginator: MatPaginator;
  // @ViewChild(MatPaginator) page:MatPaginator;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  // eslint-disable-next-line @angular-eslint/use-lifecycle-interface
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }


  show_edit=true;
  editvaluelist:any
  displayedColumns: string[] = ['Notification Name', 'Message', 'Triggered Status', 'Reminder Period','Status','Edit','Delete'];
  dataSource = new MatTableDataSource<SchedulerNotificationDto>();
  isActive: any;
  showtabledata:SchedulerNotificationDto[];
  schdulerListElement:SchedulerNotificationDto;
  updatelist:updateDto[];
  updatelist2:updateDto
  readonly:true;
dropdown=[
  {id:'1',name:"2"},
  {id:'2',name:"5"},
  {id:'3',name:'1'},
  {id:'4',name:'3'}
]
actionlist=[
  {id:'1',name:'Resend Notification'}
]

editfun(value){

    this.show_edit =!this.show_edit;
    this.scheduler.getedit(value).subscribe((res:any)=>{
    this.editvaluelist=res.content

    })


}


onToggling(event: any){
  this.isActive=event.checked;
 }

 gettabledata(){
  this.scheduler.getschedulerdetail().subscribe((data:any)=>{
    const datalist=data.content;

    this.showtabledata =[];
    for(const item of datalist){
      this. getEmptyschdulerListElement()
      this.schdulerListElement.schedularId= item.schedularId,
      this.schdulerListElement.notificationName=item.notificationName,
      this.schdulerListElement.message=item.message,
      this.schdulerListElement.triggeredStatus=item.triggeredStatus,
      this.schdulerListElement.remainder=item.remainder,
      this.schdulerListElement.isActive=item.isActive,
      this.showtabledata.push(this.schdulerListElement);


    }
    this.dataSource=new MatTableDataSource<SchedulerNotificationDto>(this.showtabledata);

  }
  );

 }


 savedata2(value1:number,value2:string){
  this.getEmptyschdulerListElement()
  this.schdulerListElement.schedularId=value1,
  this.schdulerListElement.triggeredStatus=value2,
  this.schdulerListElement.remainder=this.hours



  this.scheduler.savedata(this.schdulerListElement).subscribe((data:any)=>{
    if(data){

    }
  });
  this.scheduler.getschedulerdetail();
  this.show_edit =true;
 }

 getEmptyschdulerListElement(){
  this.schdulerListElement={

  schedularId:0,
  notificationName:"",
  message:"",
  triggeredStatus:"",
  remainder:0,
  action:"",
  isActive:false
 }
}
getvalue(){
  this.updatelist2={
    schedularId:0,
    triggeredStatus:"",
    remainder:0,

  }
}



hours:any

form = new FormGroup({
  trigger: new FormControl("", [Validators.required]),
  remainder: new FormControl("", [Validators.required]),
});

onSelect(value:any){
this.hours=value;

}

ngOnInit(): void {
  this.form.controls['trigger'].disable();
  this.form.controls['remainder'].disable();

  // this.form=this.formBuilder.group(
  //   {
  //     box1:[''],
  //     box2:[''],
  //     box3:[''],
  //   }
  // )
}




}
