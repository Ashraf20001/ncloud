


import { Component, EventEmitter, Output, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { PopupComponent } from 'src/app/common/components/popup/popup.component';
import { SchedulerNotificationDto, updateDto } from 'src/app/models/scheduler-dto';
import { SchedulerService } from 'src/app/service/scheduler.service';
import { Subject } from 'rxjs';

export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}





@Component({
  selector: 'app-scheduler-list',
  templateUrl: './scheduler-list.component.html',
  styleUrls: ['./scheduler-list.component.scss']
})
export class SchedulerListComponent {
  schedularId:string;

@Output() valueEvent= new EventEmitter<string>();

  constructor(

private dialog:MatDialog, private scheduler:SchedulerService,private activateRoute:ActivatedRoute, private router: Router,private formBuilder:FormBuilder
  ){
    this.gettabledata()
  }

  // @ViewChild(MatPaginator,{ static: true }) paginator: MatPaginator;
  // @ViewChild(MatPaginator) page:MatPaginator;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  // eslint-disable-next-line @angular-eslint/use-lifecycle-interface
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }


  show_edit=true;
  editvaluelist:any
  displayedColumns: string[] = ['Notification Name', 'Message', 'Triggered Status', 'Reminder Period','Status','Edit'
  // ,'Delete'
];
  dataSource = new MatTableDataSource<SchedulerNotificationDto>();
  isActive: any;
  showtabledata:SchedulerNotificationDto[];
  schdulerListElement:SchedulerNotificationDto;
  updatelist:updateDto[];
  updatelist2:updateDto
  readonly:true;
  totalLength: any;
  pageIndex = 1;
  pageChangedEvent = new Subject<number>();
  customPageIndex: number = 0;
  minLength: number;
  maxLength: number;
  endingIndex = 10;

dropdown=[
  {id:'1',name:"2"},
  {id:'2',name:"5"},
  {id:'3',name:'1'},
  {id:'4',name:'3'}
]
actionlist=[
  {id:'1',name:'Resend Notification'}
]

editfun(value){
  this.schedularId=value;
  this.show_edit =!this.show_edit;
  this.router.navigate(['..','edit',value], {relativeTo: this.activateRoute});
}

change($event){
  this.show_edit=$event;
}


onToggling(event: any){
  this.isActive=event.checked;
 }

 gettabledata(){
  this.scheduler.getschedulerdetail().subscribe((data:any)=>{
    const datalist=data.content;

    this.showtabledata =[];
    // if (data['content'].length != 0) {
    //   this.dataSource =new MatTableDataSource(this.showtabledata)
    // }
    for(const item of datalist){
      this. getEmptyschdulerListElement()
      this.schdulerListElement.schedularId= item.schedularId,
      this.schdulerListElement.notificationName=item.notificationName,
      this.schdulerListElement.message=item.message,
      this.schdulerListElement.triggeredStatus=item.triggeredStatus,
      this.schdulerListElement.remainder=item.remainder,
      this.schdulerListElement.isActive=item.isActive,
      this.showtabledata.push(this.schdulerListElement);


    }
    this.dataSource=new MatTableDataSource<SchedulerNotificationDto>(this.showtabledata);

  }
  );

 }


 savedata2(value1:number,value2:string){
  this.getEmptyschdulerListElement()
  this.schdulerListElement.schedularId=value1,
  this.schdulerListElement.triggeredStatus=value2,
  this.schdulerListElement.remainder=this.hours



  this.scheduler.savedata(this.schdulerListElement).subscribe((data:any)=>{
    if(data){

    }
  });
  this.scheduler.getschedulerdetail();
  this.show_edit =true;
 }

 getEmptyschdulerListElement(){
  this.schdulerListElement={

  schedularId:0,
  notificationName:"",
  message:"",
  triggeredStatus:"",
  remainder:0,
  action:"",
  isActive: false
 }
}
getvalue(){
  this.updatelist2={
    schedularId:0,
    triggeredStatus:"",
    remainder:0,

  }
}



hours:any

form = new FormGroup({
  trigger: new FormControl("", [Validators.required]),
  remainder: new FormControl("", [Validators.required]),
});

onSelect(value:any){
this.hours=value;

}

ngOnInit(): void {
  this.form.controls['trigger'].disable();
  this.form.controls['remainder'].disable();


}


cardview(){
  this.router.navigateByUrl('/page-config/scheduler/card')
}
opendelete(){

  const dialogRef = this.dialog.open(PopupComponent, {
   width: '30%',
   height:'20%',
       data: {
       message: "Are you sure you want to delete?",
        okButton: "Ok",
         cancelButton: "Cancel"
       }
   });
   dialogRef.afterClosed().subscribe(result => {
    if (result) {
console.log()
       }
   });
   return false;
  }

  onKeyDown(event: KeyboardEvent) {
    if (event.keyCode === 190) {
      event.preventDefault();
    }
  }

  pageindex(): void {
    this.pageChangedEvent.next(this.pageIndex);
  }
  
  changePage(event) {
    if(event.pageIndex > event.previousPageIndex ){
      //previous
      this.customPageIndex = event.pageIndex+1;
    }else{
     // next
     this.customPageIndex =  this.customPageIndex-1;
    }
    if (event.pageIndex != this.pageIndex) {
      this.maxLength = event.pageSize;
      this.minLength = event.pageSize * event.pageIndex;
      this.endingIndex = event.pageSize;
      this.pageIndex = this.customPageIndex;
    } else {
      this.maxLength = event.pageSize;
      this.minLength = event.pageIndex;
      this.endingIndex = event.pageSize;
      this.pageIndex = this.customPageIndex+1;
    }
    this.gettabledata();
  
  }
  

}
