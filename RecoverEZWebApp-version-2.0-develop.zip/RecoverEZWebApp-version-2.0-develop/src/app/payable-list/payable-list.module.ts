import { DemoMaterialModule } from './../common/components/material-module';
import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { PayableListCardComponent } from "./payable-list-card/payable-list-card.component";
import { PayableListRoutingModule } from "./payable-list-routing.module";
import { PayableListTableComponent } from "./payable-list-table/payable-list-table.component";
import { PayableListComponent } from "./payable-list.component";
import {  TranslateModule } from '@ngx-translate/core';
@NgModule({
  declarations:[
    PayableListCardComponent,
    PayableListComponent,
    PayableListTableComponent
  ],
  imports:[
    CommonModule,
    FormsModule,
    PayableListRoutingModule,
    TranslateModule,
    DemoMaterialModule
  ],
  exports:[
  ]
})

export class PayableListModule{

}
