import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { appConst } from '../service/app.const';
import { ReceivableService } from '../service/receivable.service';
import { AppService } from '../service/role access/service/app.service';
import { ToastrService } from 'ngx-toastr';
import { PayableListTableComponent } from './payable-list-table/payable-list-table.component';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-payable-list',
  templateUrl: './payable-list.component.html',
  styleUrls: ['./payable-list.component.scss']
})

export class PayableListComponent implements OnInit,OnDestroy{
  searchvalue: string;
  buttonDisable: boolean;
  backIcon: boolean;
  pageInfo: any;
  payable_edit:boolean;
  closeIcon:boolean = false;
  public appConst = appConst;
  pageId= appConst.PAGE_NAME.PAYABLE.PAYABLE_CARD.PAGEID;
  downloadEnable: boolean;
  payableDto = new PayablevableListDto();
  constructor(private route:Router,private router : ActivatedRoute,private receivable: ReceivableService, private appService : AppService,private toaster:ToastrService,private translate: TranslateService){
    this.receivable.getCheckbox().subscribe((value:boolean) => {
      if(value){
        this.buttonDisable=value;
      }else{
        this.buttonDisable=value;
        this.redirectToPayableCard();
      }
    });
    this.getButtonSts();
}

  ngOnInit(): void {
    this.getPrivilege();
  }

  onClick() {
    this.route.navigate(['Payable-table'],{
          relativeTo:this.router
    });
    sessionStorage.setItem('ViewReportLoss',"Payable");
    this.backIcon=true;
    this.payable_edit=false;
    this.downloadEnable=false;
    this.setButtonSts();
  }
  goBack() {
    this.searchvalue = '';
    this.closeIcon = false;
    this.payable_edit = true;
    this.route.navigate(['Payable-card'], {
      relativeTo: this.router
    });
    this.backIcon = false;
    this.downloadEnable = true;
    this.setButtonSts();
  }

  Search(){
    this.trimLeadingSpace();
    this.closeIcon=true;
    this.route.navigate([], { queryParams: {recSearchQuery: this.searchvalue }, queryParamsHandling: 'merge' })
  }

  removeValue(){
    this.searchvalue = '';
    this.closeIcon = false;
    this.route.navigate([], { queryParams: {recSearchQuery: this.searchvalue }, queryParamsHandling: 'merge' })
  }

  handleKeyup(event: KeyboardEvent) {
    if (event.key === 'Backspace' && this.searchvalue === '' && this.closeIcon) {
      this.closeIcon = false;
    }
  }

  trimLeadingSpace() {
    this.searchvalue = this.searchvalue.replace(/^\s+/g, '');
  }

  getPrivilege(){
    this.appService.getPrivilegeForPage(this.pageId).subscribe((res: any)=>{
      this.pageInfo = res.content;
      this.getPageInfo(this.pageId);
    });
  }

  getPageInfo(pageID: number): boolean{
    if(this.pageInfo){
    const pageValue = this.pageInfo && (this.pageInfo.length === 0 || this.pageInfo.find((element: any) => element.pageId === pageID));
    return pageValue.isEnabled;
  }
  return false;
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege ? privillege.isEnabled : false;
    }
    return isEnabled;
  }

  /**
   *Download Payable-List
   * @param value
   * @param downloadType
   */
  downloadPayableList(){
    this.payableDto.list = JSON.parse(localStorage.getItem("companyId"));
    this.payableDto.limit = 0;
    this.payableDto.skip = 0;
    this.payableDto.stageName = null;
    this.receivable.exportPayableListAsExcel( this.payableDto).subscribe((response:any)=>{
      if (response) {
        const blob = new Blob([response],
          { type: 'application/vnd.ms-excel' });
        const file = new File([blob], 'Payable_List.xlsx',
          { type: 'application/vnd.ms-excel' });
        const fileURL = URL.createObjectURL(file);
        const a         = document.createElement('a');
        a.href        = fileURL;
        a.target      = '_blank';
        a.download    = "Payable_List"+'.xlsx';
        document.body.appendChild(a);
        a.click();
        this.toaster.success(this.translate.instant("Toaster_Message.Payable_list_download"));
      }
    });
}
  /**
   *redirectToPayableCard
   */
  private redirectToPayableCard() {
       this.receivable.getBackToRcvleCard_PayableCard().subscribe((value: boolean) => {
       if (value) {
           this.goBack();
         }
     });
  }

  private setButtonSts() {
    sessionStorage.setItem("backIcon", JSON.stringify(this.backIcon));
    sessionStorage.setItem("downloadEnable", JSON.stringify(this.downloadEnable));
    sessionStorage.setItem("payable_edit", JSON.stringify(this.payable_edit));
  }

  private getButtonSts() {
    this.backIcon = sessionStorage.getItem("backIcon") === "true";
    this.downloadEnable = sessionStorage.getItem("downloadEnable") === "true";
    this.payable_edit = sessionStorage.getItem("payable_edit") === "true";
  }

  /**
   * Destroy
   */
  ngOnDestroy(): void {
    // sessionStorage.removeItem("backIcon");
    // sessionStorage.removeItem("downloadEnable");
    // sessionStorage.removeItem("payable_edit");
  }
}
export class PayablevableListDto{
  list:string[];
  limit:number;
  skip:number;
  stageName:string
}
