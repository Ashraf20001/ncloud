import { HttpParams } from '@angular/common/http';
import { Component, ViewChild, OnInit, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Subject, Subscription, debounceTime } from 'rxjs';
import { PopupComponent } from 'src/app/common/components/popup/popup.component';
import { Section } from 'src/app/models/report-loss-dto/section';
import { AccessMappingPageDto } from 'src/app/models/user-role-management/access-Mapping-PageDto ';
import { AdminService } from 'src/app/service/admin.service';
import { appConst } from 'src/app/service/app.const';
import { ClaimTable, ReceivableService } from 'src/app/service/receivable.service';
import { AppService } from 'src/app/service/role access/service/app.service';

@Component({
  selector: 'app-payable-table-list',
  templateUrl: './payable-list-table.component.html',
  styleUrls: ['./payable-list-table.component.scss']
})

export class PayableListTableComponent implements OnInit,AfterViewInit{
  displayedColumns: string[] = ['claim', 'insurarname','atfault','notatfault','totallossamount','lossofdate','stageandsection','status','edit','delete'];
  dataSource :MatTableDataSource<ClaimTable>;


  payableVO =new payableGetVO();

  ZERO=0;
   TEN=10;
   totalLength: any;
  tableList:any;
  showtabledata: []=[];
  searchvalue: string;
  pageInfo: any;
  public appConst = appConst;
  pageId= appConst.PAGE_NAME.PAYABLE.PAYABLE_LIST.PAGEID;
  associateUser: boolean;
  dataNotFound=false;
  payableListPageAccessDto: AccessMappingPageDto;
  isPayableListEnabled = true;
  limit: number=0;
  skip: number=0;
  endingIndex:number=10;
  stageName:string;
  private subscriptions = new Subscription();
  pagesize: number = 10;
  customPageIndex: any;
  currentPageIndex: number;
  pageIndex = 1;
  pageChangedEvent = new Subject<number>();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  currencyId = -1;

  constructor(private paginatorName: MatPaginatorIntl,
    private detector: ChangeDetectorRef,private datas:ReceivableService, private route:Router,private router : ActivatedRoute,private dialog:MatDialog, private appService : AppService,
    private adminService: AdminService, private translate:TranslateService){
      if(this.paginatorName) {
        this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
      }
  }

  ngOnInit(): void {
    this.getPageAccessData();
    this.getPrivilege();
    if(this.paginator){
      this.paginatorName.itemsPerPageLabel = this.translate.instant("paginator.rowsPerPage");
    }
    this.translate.onLangChange.subscribe(() => {
      this.translateLabels();
    });
    this.pageChangedEvent.pipe(debounceTime(300)).subscribe((data: number) => {
      this.changePageIndex();
    });
    this.translate.onLangChange.subscribe(() => {
      if (this.paginator) {
        this.paginator._intl.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
        this.paginator._changePageSize(this.paginator.pageSize);
        this.detector.detectChanges();
      }
    });
    if(this.paginatorName) {
      this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    }
  }

  doProcess(): void {
    this.associateUser = this.adminService.isAssociationUser();
    if(!this.associateUser){
      this.displayedColumns = ['claim', 'insurarname', 'notatfault','totallossamount','lossofdate','stageandsection','status','edit','delete'];
    }
    this.payableVO.list= JSON.parse(localStorage.getItem("companyId"));
    this.translateLabels();
    this.router.queryParams.subscribe((queryParams: any) => {
      let isSearch = false;
      if(queryParams['recSearchQuery']) {
        isSearch = true;
        this.searchvalue = queryParams['recSearchQuery'];
      }else{
        this.searchvalue = "" ;
      }
      if(queryParams['stage']) {
        this.payableVO.stageName=queryParams['stage'];
      }
      if(queryParams['cur']) {
        this.currencyId = +queryParams['cur'];
        this.payableVO.currencyId = this.currencyId;
      }
      if(this.searchvalue){
       this.getTotalCountForFilterdPayableList(this.payableVO,this.searchvalue);
      //this.dataSource.filter = this.searchvalue.trim().toLowerCase();
      }
      if (this.dataSource?.paginator) {
        this.dataSource.paginator.firstPage();
      }
      if(queryParams['stage']) {
        this.stageName=queryParams['stage'] ;
      }
        if(!isSearch) {
          this.dataNotFound = false;
          this.getTotalCount(this.payableVO);
        }


   });
  }

  editFunc(value:any){
    this.route.navigate(['report-loss/'], { queryParams: { claimId: value.claimIdentity, rec: false } })
  }
  getPayableList(payableList:payableGetVO){
    payableList.stageName=this.stageName;
    this.datas.getPayableList(payableList).subscribe((response:any)=>{
      this.tableList=response.content;
      if (this.tableList != 0) {
        if(this.tableList.length >=9){
          this.dataNotFound = false;
        }
      }else{
        this.dataNotFound = true;
      }
      this.dataSource=new MatTableDataSource(this.tableList);
    });
  }



  getTotalCount(companyName:any){
    this.datas.getPayableCount(companyName).subscribe((response:any)=>{
      this.totalLength = response.content;
      this.payableVO.limit=this.ZERO;
      this.payableVO.skip=this.TEN;
    this.getPayableList(this.payableVO);
    });
  }

  changePage(event){
    if(event.pageIndex > event.previousPageIndex ){
      //previous
      this.customPageIndex = event.pageIndex+1;
    }else{
     // next
     this.customPageIndex =  this.customPageIndex-1;
    }
    if(event.pageIndex != this.ZERO){
      this.payableVO.skip= event.pageSize;
      this.payableVO.limit = event.pageSize * event.pageIndex;
      this.endingIndex = event.pageSize;
      this.pageIndex = this.customPageIndex;
    }else{
      this.payableVO.skip= event.pageSize;
      this.payableVO.limit = event.pageIndex;
      this.endingIndex = event.pageSize;
      this.pageIndex = event.pageIndex+1;
    }
    if(!this.searchvalue){
      this.getPayableList(this.payableVO);
    }else{
      this.getTotalCountForFilterdPayableList(this.payableVO,this.searchvalue);
    }
  }

  pageindex(): void {
    this.pageChangedEvent.next(this.pageIndex);
  }

  changePageIndex(): void {
    if(this.pageIndex > 0){
      const totalPageIndex = this.totalLength / this.endingIndex + 1;
      if(this.pageIndex > totalPageIndex) {
        this.pageIndex = this.customPageIndex === 0 ? 1 : this.customPageIndex;
        return;
      }
      this.customPageIndex = this.pageIndex;
      this.currentPageIndex = this.pageIndex-1;
      this.payableVO.skip= this.endingIndex;
      this.payableVO.limit = this.endingIndex * this.currentPageIndex;
      if(!this.searchvalue){
        this.getPayableList(this.payableVO);
      }else{
        this.getTotalCountForFilterdPayableList(this.payableVO,this.searchvalue);
      }

    }
  }

  onKeyDown(event: KeyboardEvent) {
    if (event.keyCode === 190) {
      event.preventDefault();
    }
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    if(this.paginatorName) {
      this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    }
  }
  Delete(claimId:string){
    if(!this.associateUser) {
    const dialogRef = this.dialog.open(PopupComponent, {
   width: 'auto',
   height:'auto',
       data: {
       message: "Are you sure you want to delete?",
        okButton: "Ok",
         cancelButton: "Cancel"
       }
   });
   dialogRef.afterClosed().subscribe(result => {
    if (result) {
this.datas.DeleteReceivabletList(claimId).subscribe();
this.getTotalCount(this.payableVO);
    }
   });
   return false;
  }
  }


  getPrivilege(){
    this.appService.getPrivilegeForPage(this.pageId).subscribe((res: any)=>{
      this.pageInfo = res.content;
      this.getPageInfo(this.pageId);
    });
  }

  getPageInfo(pageID: number): boolean{
    const pageValue = this.pageInfo && (this.pageInfo.length === 0 || this.pageInfo.find((element: any) => element.pageId === pageID));
    return pageValue;
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege ? privillege.isEnabled : false;
    }
    return isEnabled;
  }





  imageSectionList = [
    {
      image:"assets/reportloss/stage/Notification Stage.svg",
      title:"Notification Stage"
    },
    {
      image:"assets/reportloss/stage/Claim Inspection Stage.svg",
      title:"Claim Inspection Stage"
    },
    {
      image:"assets/reportloss/stage/Liability Confirmation Stage.svg",
      title:"Liability Confirmation Stage"
    },
    {
      image:"assets/reportloss/stage/newsettlementStage.svg",
      title:"Settlement Stage"
    }
  ]

  getUrl(item: String): string {
    let src = '';
    if(item){
    const img = this.imageSectionList.find((img) => img.title === item);
    if(img) {
      src = img.image;
    }
  }
    return src;
  }

  getPageAccessData(): void {
    this.appService.getPageAccess(appConst.PAGE_NAME.PAYABLE.PAYABLE_LIST.PAGE_IDENTITY).subscribe((response: any) => {
      this.payableListPageAccessDto = response.content;
      this.isPayableListEnabled = this.payableListPageAccessDto.isEnabled;
      if(this.isPayableListEnabled) {
        this.doProcess();
      }
    });
  }
  /*
   * Get SearchValue For PayableListCount
   */
  getTotalCountForFilterdPayableList(payableVO : payableGetVO,searchValue : string){
    payableVO.searchValue = searchValue;
    this.subscriptions = this.datas.getFilterPayableListCount(payableVO).subscribe((response : any) => {
        this.totalLength = response.content;
        this.getSearchValueForPayableList(payableVO);
    })
  }
  /*
   * Get SearchValue For PayableList
   */
  getSearchValueForPayableList(payableVO : payableGetVO) {
    this.subscriptions = this.datas.getPayableListFilter(payableVO).subscribe((response: any) => {
      this.tableList = response.content;
      if(this.tableList.length != 0){
        this.dataNotFound = false;
      }else{
        this.dataNotFound = true;
      }
      this.dataSource = new MatTableDataSource(this.tableList);
    });
  }

  translateLabels() {
    this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    this.paginatorName.firstPageLabel = this.translate.instant('Paginator.FirstPage');
    this.paginatorName.lastPageLabel = this.translate.instant('Paginator.LastPage');
    this.paginatorName.nextPageLabel = this.translate.instant('Paginator.NextPage');
    this.paginatorName.previousPageLabel = this.translate.instant('Paginator.PreviousPage');
  }

  /*
  *   unsubscribe
  */
  ngOnDestroy(): void {
    this.subscriptions.unsubscribe;
  }
}


export class payableGetVO{
  list:string[];
  skip:number;
  limit:number;
  stageName:string;
  searchValue: string;
  currencyId: number;
}

