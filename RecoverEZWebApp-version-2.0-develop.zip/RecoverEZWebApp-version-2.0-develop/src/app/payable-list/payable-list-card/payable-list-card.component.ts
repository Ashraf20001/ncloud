import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccessMappingPageDto } from 'src/app/models/user-role-management/access-Mapping-PageDto ';
import { appConst } from 'src/app/service/app.const';
import { ReceivableService } from 'src/app/service/receivable.service';
import { AppService } from 'src/app/service/role access/service/app.service';

@Component({
  selector: 'app-payable-list-card',
  templateUrl: './payable-list-card.component.html',
  styleUrls: ['./payable-list-card.component.scss']
})

export class PayableListCardComponent {
  allCompanies;
  cardDetails;
  cardCompanyIdList = [];
  companyList = [];
  CompanyNameList=[];
  completedCheck= [];
  showCard=true;
  allComplete=false;
  searchvalue: string;
  pageInfo: any;
  public appConst = appConst;
  pageId= appConst.PAGE_NAME.DASHBOARD.RECEIVABLE_DASHBOARD.PAGEID;
  isPayableCardEnabled = true;
  payableCardPageAccessDto: AccessMappingPageDto;
  dataNotFound: boolean;

  constructor(private receiveService: ReceivableService, private route:Router,private router : ActivatedRoute, private appService : AppService) {
    this.router.queryParams.subscribe((queryParams: any) => {
       this.searchvalue = queryParams['recSearchQuery'];
       if(this.searchvalue == undefined || this.searchvalue == null || this.searchvalue==""){
        this.showCard=true;
       }else{
        this.showCard=false;
       }
        this.filter(this.searchvalue);
    });
  }
  ngOnInit() {
    this.getPageAccessData();
  }

  doProcess(): void {
    this.getPrivilege();
    this.receiveService.setCheckbox(false);
    this.receiveService.getCompanyPayables().subscribe(response => {
       this.cardDetails = response;
       this.CompanyNameList = response;
       this.isPayableCardEnabled = false;
       this.dataNotFound = true;
       if(this.CompanyNameList.length > 0){
         this.dataNotFound = false;
         this.isPayableCardEnabled = true;
       }
       this.allCompanies=response[0];
       });

      //  this.receiveService.getAllPayables().subscribe(response=> {
      //   this.allCompanies=response;
      //  });
  }
filter(value:string){
  if(value !== undefined){
    this.CompanyNameList = this.cardDetails.filter((m) => String(m.companyName.toUpperCase()).includes(value.toUpperCase()));
    this.dataNotFound = true;
    if(this.CompanyNameList.length > 0){
      this.dataNotFound = false;
    }
  }
}
  getPayable(companyId, event, i :number) {
    this.CheckCheckBox(event.checked,companyId);
  }


  CheckCheckBox(check:boolean, companyId){
    const index = this.companyList.indexOf(companyId);
    if(check == true){
      this.companyList.push(companyId);
      this.passCompanyId(this.companyList);
    } else if(index == -1){
      const indexValue = this.cardCompanyIdList.indexOf(companyId);
      this.cardCompanyIdList.splice(indexValue , 1);
      this.allComplete = false;
      this.passCompanyId(this.cardCompanyIdList);
    }
    else{
      this.companyList.splice(index , 1);
      this.allComplete = false;
      this.passCompanyId(this.companyList);
    }
    if(this.companyList.length==0 && this.cardCompanyIdList.length==0){
      this.receiveService.setCheckbox(false);
    }
    else{
      this.receiveService.setCheckbox(true);
    }

  }

  passCompanyId(CompanyId:any){
    const arr = JSON.stringify(CompanyId);
    localStorage.setItem("companyId", arr);
  }

  AllCompanys(completed: boolean){
    if(completed == true){
      this.completedCheck =[];
      this.receiveService.setCheckbox(true);
      this.companyList=[];
      this.passCompanyId(this.companyList);
      this.cardCompanyIdList=[];
      for(let i=0;i< this.cardDetails.length; i++){
        this.cardCompanyIdList.push(this.cardDetails[i].companyId);
        this.completedCheck.push(completed);
      }
    }else{
      this.receiveService.setCheckbox(false);
      this.completedCheck =[];
      this.cardCompanyIdList=[];
      this.allComplete = completed;
    }

  }

  getPrivilege(){
    this.appService.getPrivilegeForPage(this.pageId).subscribe((res: any)=>{
      this.pageInfo = res.content;
      this.getPageInfo(this.pageId);
    });
  }

  getPageInfo(pageID: number): boolean{
    const pageValue = this.pageInfo && (this.pageInfo.length === 0 || this.pageInfo.find((element: any) => element.pageId === pageID));
    return true;
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege ? privillege.isEnabled : false;
    }
    return isEnabled;
  }

  getPageAccessData(): void {
    this.appService.getPageAccess(appConst.PAGE_NAME.PAYABLE.PAYABLE_CARD.PAGE_IDENTITY).subscribe((response: any) => {
      this.payableCardPageAccessDto = response.content;
      this.isPayableCardEnabled = this.payableCardPageAccessDto.isEnabled;
      if(this.isPayableCardEnabled) {
        this.doProcess();
      }
    });
  }
}
