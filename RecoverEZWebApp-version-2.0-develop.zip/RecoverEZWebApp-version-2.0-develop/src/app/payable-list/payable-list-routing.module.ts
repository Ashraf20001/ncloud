import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { PayableListCardComponent } from "./payable-list-card/payable-list-card.component";
import { PayableListTableComponent } from "./payable-list-table/payable-list-table.component";
import { PayableListComponent } from "./payable-list.component";


const routes : Routes =  [
  {
    path: '', component: PayableListComponent,
    children : [
      {
        path: 'Payable-table',  component: PayableListTableComponent
      },
      {
        path: 'Payable-card',  component: PayableListCardComponent
      },
      {
        path: '',  redirectTo: 'Payable-card', pathMatch: "full"
      },
    ]
  }
]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class PayableListRoutingModule { }
