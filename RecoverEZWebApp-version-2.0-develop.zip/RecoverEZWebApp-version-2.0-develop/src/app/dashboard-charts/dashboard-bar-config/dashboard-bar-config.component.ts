import { Component, Inject, OnInit, Input } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DashboardBarComponent } from '../dashboard-bar/dashboard-bar.component';

@Component({
  selector: 'app-dashboard-bar-config',
  templateUrl: './dashboard-bar-config.component.html',
  styleUrls: ['./dashboard-bar-config.component.scss']
})

export class DashboardBarConfigComponent implements OnInit{

  @Input() filterListFromDashboard:InsuredAndTpArray;
  xlabel: string;
  xvalue: string;
  ylabel: string;
  yvalue: number;
  selectedValue:any;

  xlabels: Xlabel[] = [
    {value: 'Period', viewValue: 'Period'},
  ];
  xvalues: Xvalue[] = [
    {value: 'Month', viewValue: 'Month'},
    {value: 'Year', viewValue: 'Year'},
  ];
  ylabels: Ylabel[] = [
    {value: 'Count', viewValue: 'Count'},
    {value: 'Amount', viewValue: 'Amount'},
  ];
  yvalues: Yvalue[] = [
    {value: 100, viewValue: 100},
    {value: 500, viewValue: 500},
    {value: 1000, viewValue: 1000},
  ];

  constructor(public dialog: MatDialog, public dialogRef: MatDialogRef<DashboardBarComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
      this.xlabel = data.xlabel;
      this.xvalue = data.xvalue;
      this.ylabel = data.ylabel;
      this.yvalue = data.yvalue;
  }
  ngOnInit(): void {
    this.amtchange();
  }

  ///filter mtds
  applyfilter(){
    let output = new FilterData(this.xlabel,this.xvalue,this.ylabel,this.yvalue)
    this.dialogRef.close(output);
  }

  //filter y axis - label and values
  amtchange(){
    if(this.ylabel=="Amount"){
      this.selectedValue = 100000;
      this.yvalues= [
        {value: 100000, viewValue: 100000},
        {value: 500000, viewValue: 500000},
        {value: 1000000, viewValue: 1000000},
      ];
    }else{
      this.selectedValue = 100;
      this.yvalues= [
        {value: 100, viewValue: 100},
        {value: 500, viewValue: 500},
        {value: 1000, viewValue: 1000},
      ];
    }
  }
}


export interface Xlabel {
  value: string;
  viewValue: string;
}
export interface Xvalue {
  value: string;
  viewValue: string;
}
export interface Ylabel {
  value: string;
  viewValue: string;
}
export interface Yvalue {
  value: number;
  viewValue: number;
}
export class FilterData{
  xlabel:string;
  xvalue:string;
  ylabel:string;
  yvalue:number;
  constructor(xlabel:string,xvalue:string,ylabel:string,yvalue:number){
    this.xlabel=xlabel;
    this.xvalue=xvalue;
    this.ylabel=ylabel;
    this.yvalue=yvalue;
  }
}

export class InsuredAndTpArray{
  insurenceCompanyNames:string[];
  tpCompanyNames:string[];
}