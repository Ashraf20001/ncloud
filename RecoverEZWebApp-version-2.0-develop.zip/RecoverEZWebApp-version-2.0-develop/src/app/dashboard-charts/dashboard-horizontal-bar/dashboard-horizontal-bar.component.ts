import { Component, ElementRef, ViewChild, Input, HostListener } from '@angular/core';
import Chart from 'chart.js/auto';
import { DashboardChartService } from 'src/app/service/dashboard-chart.service';
import fscreen from 'fscreen';
import jsPDF from 'jspdf';
import * as XLSX from 'xlsx';
import { AccessMappingSectionDto } from 'src/app/models/user-role-management/section-dto';
import { DashboardService } from 'src/app/service/dashboard.service';
import * as ExcelJS from 'exceljs';
import * as FileSaver from 'file-saver';
import { TranslateService } from '@ngx-translate/core';
import { debounceTime, distinctUntilChanged } from 'rxjs';

@Component({
  selector: 'app-dashboard-horizontal-bar',
  templateUrl: './dashboard-horizontal-bar.component.html',
  styleUrls: ['./dashboard-horizontal-bar.component.scss']
})

export class DashboardHorizontalBarComponent{

  @Input() filterListFromDashboard:InsuredAndTpArray;

  @Input() receivableHorizontalBarChartAccessData: AccessMappingSectionDto;

  @Input() payableHorizontalBarChartAccessData: AccessMappingSectionDto;

  @Input() selectedCurrencyId = -1;

  barChart: any;
  horizonatldata=[]
  label=[];
  count=[];
  labellist=[];
  zoomchat=false;
  fullshow=true;

  horizontalBarChartData: any;
  hasFullscreenSupport: boolean = fscreen.fullscreenEnabled;
  isFullscreen: boolean;
  jsout:any;
  @ViewChild('HorizontalBarChartDiv') HorizontalBarChartDiv!: { nativeElement: any };
  @ViewChild('HorizontalBarChart') HorizontalBarChart!: { nativeElement: any };
  elem:any;
  showOrHideIcon=true
  canvas: any;
  ctx: any;
  isReceivable:boolean;
  isDownloadEnabled = true;
  harizondalBarLebel: string;
  emptylist:InsuredAndTpArray = new InsuredAndTpArray();

  constructor(private chartservice:DashboardChartService,private dasboardService:DashboardService,private translate: TranslateService) {

    if (this.hasFullscreenSupport) {
      fscreen.addEventListener('fullscreenchange', () => {
        this.isFullscreen = (fscreen.fullscreenElement !== null);
      }, false);
    }
    this.isReceivable = (sessionStorage.getItem("toggleButtonStatus") == "false");

    this.translate.onLangChange.subscribe(() => {
      this.fetchHorizontalBarData(this.jsout);
    });
  }

  // eslint-disable-next-line @angular-eslint/use-lifecycle-interface
  ngOnDestroy() {
    if (this.hasFullscreenSupport) {
      fscreen.removeEventListener('fullscreenchange');
    }
  }

  // eslint-disable-next-line @angular-eslint/use-lifecycle-interface
  ngOnInit() {
    this.isDownloadEnabled = (this.isReceivable && this.receivableHorizontalBarChartAccessData.isDownload) || (!this.isReceivable && this.payableHorizontalBarChartAccessData.isDownload);
    this.emptylist.insurenceCompanyNames = []
    this.emptylist.tpCompanyNames = []
    // this.barChartMethod(this.emptylist);
    this.dasboardService.isCheck.pipe(debounceTime(300),distinctUntilChanged()).subscribe(value=>{
      this.isReceivable=value;
      this.barChartMethod(this.emptylist);
      this.isDownloadEnabled = (this.isReceivable && this.receivableHorizontalBarChartAccessData.isDownload) || (!this.isReceivable && this.payableHorizontalBarChartAccessData.isDownload);
    });
    this.chartservice.currencyValueChangeEvent.subscribe((value: number) => {
      this.selectedCurrencyId = value;
      this.barChartMethod(this.emptylist);
    });
  }
  toggleFullScreen() {
    if (this.hasFullscreenSupport && !this.isFullscreen) {
      const elem = this.HorizontalBarChartDiv.nativeElement;
      fscreen.requestFullscreen(elem) || elem['mozRequestFullscreen'] || elem['msRequestFullscreen'];
      this.showOrHideIcon=false
      this.zoomchat=true;
      this.fullshow=false;
    } else {
      fscreen.exitFullscreen();
      this.showOrHideIcon=true
      this.zoomchat=false;
      this.fullshow=true;
    }
  }
  @HostListener('fullscreenchange', ['$event'])
@HostListener('webkitfullscreenchange', ['$event'])
@HostListener('mozfullscreenchange', ['$event'])
@HostListener('MSFullscreenChange', ['$event'])
screenChange(event) {
 this.toggleFullScreen();
}


  barChartMethod(companyList: InsuredAndTpArray) {
    this.chartservice.getHorizontalbar(companyList, this.isReceivable, this.selectedCurrencyId).subscribe((data: any) => {
      if (data) {
        this.jsout = data;
        this.fetchHorizontalBarData(data);
      }
    })
  }

  private fetchHorizontalBarData(data: any) {
    const labels = data.content.map((item) => item.shortName);
    const counts = data.content.map((item) => item.count);
    const companies = data.content.map((item) => item.company);
    const nameLabel = this.translate.instant("HarizontalBar.company");
    const countLabel = this.translate.instant("HarizontalBar.count");
    const plugin = {
      id: 'customCanvasBackgroundColor',
      beforeDraw: (chart, args, options) => {
        const { ctx } = chart;
        ctx.save();
        ctx.globalCompositeOperation = 'destination-over';
        ctx.fillStyle = options.color || '#FFFFFF';
        ctx.fillRect(0, 0, chart.width, chart.height);
        ctx.restore();

      }
    };

    if (this.horizontalBarChartData) {
      this.horizontalBarChartData.clear();
      this.horizontalBarChartData.destroy();
    }

    this.canvas = this.HorizontalBarChart.nativeElement;
    if(this.canvas) {
      this.ctx = this.canvas.getContext('2d');

      this.horizontalBarChartData = new Chart(this.ctx, {
        type: 'bar',

        data: {
          labels: labels,
          datasets: [
            {
              data: counts,
              barPercentage: 0.5,
              label: this.harizondalBarLebel,
              backgroundColor: '#688F99'
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          indexAxis: 'y',
          plugins: {
            legend: {
              display: true,
              position: 'bottom',
              align: 'end',
              labels: {
                font: {
                  size: 14.5,
                  family: 'Inter',
                },
                boxWidth: 14
              }
            },
            tooltip: {
              callbacks: {
                label: function (context) {
                  const dataIndex = context.dataIndex;
                  const company = companies[dataIndex];
                  const count = counts[dataIndex];
                  return ` ${nameLabel} ${company} - ${countLabel} ${count}`;
                },
              },
            },
          },
          scales: {
            y: {
              grid: {
                display: false
              },
              ticks: {
                callback: function (value: number) {
                  const lbl = this.getLabelForValue(value);
                  return lbl.length <= 5 ? lbl : lbl.slice(0, 5);

                },
                font: {
                  size: 14.5,
                  family: 'Inter',
                },

                precision: 0
              }
            }, x: {
              grid: {
                display: false
              },
              ticks: {
                font: {
                  size: 14.5,
                  family: 'Inter',
                },

                precision: 0
              }
            }
          },
          aspectRatio: 2.5,
        },
        plugins: [plugin],
      });
    }
    this.multiLanguageForLebel();
  }

  private multiLanguageForLebel() {
  this.horizontalBarChartData.data.datasets[0].label = this.translate.instant("HarizontalBar.label");
  this.harizondalBarLebel = this.horizontalBarChartData.data.datasets[0].label;
  this.horizontalBarChartData.update();
}

  // download option
  //download chart as image
  downloadAsJPEG(){
    const chartCanvas = document.getElementById(
      'HorizontalBarChart'
    ) as HTMLCanvasElement;
    const ctx = chartCanvas.getContext('2d');

    // Get the heading text
    const headingText ='Top Recovery'

    // Create a new canvas to combine the heading and chart
    const combinedCanvas = document.createElement('canvas');
    const combinedCtx = combinedCanvas.getContext('2d');

    // Set the canvas size to match the chart canvas plus the heading height
    combinedCanvas.width = chartCanvas.width;
    combinedCanvas.height = chartCanvas.height + 30; // Adjust the value as needed for the heading height

    // Draw the heading on the combined canvas
    combinedCtx.fillStyle = '#FFF'; // Set the background color if needed
    combinedCtx.fillRect(0, 0, combinedCanvas.width, combinedCanvas.height); // Fill the background
    combinedCtx.font = '24px Arial'; // Set the heading font
    combinedCtx.fillStyle = '#688f99'; // Set the heading color
    combinedCtx.textAlign = 'left'; // Left-align the heading
    combinedCtx.fillText(headingText, 10, 20); // Draw the heading, adjust '10' for the desired left margin

    // Draw the chart canvas on the combined canvas, below the heading
    combinedCtx.drawImage(chartCanvas, 0, 30); // Adjust the value as needed to position the chart below the heading

    // Convert the combined canvas to a data URL and trigger the download
    const imglink = document.createElement('a');
    const canvass = this.HorizontalBarChart.nativeElement;
    imglink.download = 'TopRecovery.jpeg';
    // imglink.href = canvass.toDataURL('image/png',1);
    imglink.href = combinedCanvas.toDataURL('image/jpeg', 1);
    imglink.click();
  }

  //download chart as image
  downloadAsPDF(){
    const chartCanvas = document.getElementById('HorizontalBarChart') as HTMLCanvasElement;

    // Get the heading text and color
    const headingText ='Top Recovery'
    const headingColor = '#688f99'; // Replace this with your desired color
    const combinedCanvas = document.createElement('canvas');
    combinedCanvas.width = chartCanvas.width;
    combinedCanvas.height = chartCanvas.height + 30; // Adjust the value as needed for the heading height

    // Get the 2D context of the combined canvas
    const combinedCtx = combinedCanvas.getContext('2d');

    // Draw the heading on the combined canvas
    combinedCtx.fillStyle = '#ffffff'; // Set the background color to transparent
    combinedCtx.fillRect(0, 0, combinedCanvas.width, combinedCanvas.height); // Fill the canvas with the transparent background

    combinedCtx.fillStyle = headingColor; // Set the heading color
    combinedCtx.font = '24px Arial'; // Set the heading font
    combinedCtx.textAlign = 'left'; // Left-align the heading
    combinedCtx.fillText(headingText, 10, 20); // Draw the heading, adjust '10' for the desired left margin

    // Draw the chart canvas on the combined canvas, below the heading
    combinedCtx.drawImage(chartCanvas, 0, 40); // Adjust the value as needed to position the chart below the heading

    // Convert the combined canvas to a data URL
    const combinedImage = combinedCanvas.toDataURL('image/jpeg', 1);

    // const canvass = this.HorizontalBarChart.nativeElement;
    // const canvasimg = canvass.toDataURL('image/png',1);

    const pdf = new jsPDF();
    pdf.addImage(combinedImage,'JPEG',15,15,180,80);
    pdf.save("TopRecovery.pdf")
  }

  //download chart data as Excel
  async downloadAsExcel(){
    const data = this.jsout.content;
    const header: string[] = Object.keys(data[0]);
    const filename = 'TopRecovery.xlsx';

  // Capitalize the first letter of each header
  const headerFormatted = header.map(this.capitalizeFirstLetter);

  // Create a new workbook and worksheet using ExcelJS
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet(filename, {
    views: [{ state: 'normal' }],
  });

  // Set bold style for the header row
  const headerRow = worksheet.addRow(headerFormatted);
  headerRow.font = { bold: true };

  // Add data rows to the worksheet
  data.forEach((rowData) => worksheet.addRow(Object.values(rowData)));

   // Adjust the column width based on content
   for (let i = 0; i < header.length; i++) {
    const column = worksheet.getColumn(i + 1); // Columns are 1-indexed
    const columnData = [headerFormatted[i], ...data.map((row) => row[header[i]])];
    const columnMaxWidth = Math.max(...columnData.map((cell) => cell.toString().length));
    column.width = Math.min(columnMaxWidth + 2, 50); // Limit maximum width to 50 characters
  }

  // Generate Excel file and download
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  FileSaver.saveAs(blob, filename);
  }

  capitalizeFirstLetter(input: string): string {
    if (typeof input !== 'string') {
      return input;
    }
    return input.charAt(0).toUpperCase() + input.slice(1);
  }
}

export class InsuredAndTpArray{
  insurenceCompanyNames:string[];
  tpCompanyNames:string[];
}
