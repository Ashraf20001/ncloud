import { HttpParams } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild,Input, HostListener} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DashboardService } from 'src/app/service/dashboard.service';
import fscreen from 'fscreen';
import { RecentClaimsDto } from 'src/app/models/report-loss-dto/recent-claim-dto';
import * as _ from 'lodash';
import { ReceivableService } from 'src/app/service/receivable.service';
import { TranslateService } from '@ngx-translate/core';
import { DashboardChartService } from 'src/app/service/dashboard-chart.service';
import { debounceTime, distinctUntilChanged } from 'rxjs';

@Component({
  selector: 'app-dashboard-claim-details',
  templateUrl: './dashboard-claim-details.component.html',
  styleUrls: ['./dashboard-claim-details.component.scss']
})
export class DashboardClaimDetailsComponent implements OnInit{
  RecentClaim:RecentClaimsDto[]=[];
  isPayable=true;
  zoomchat=false;
  fullshow=true;
  hasFullscreenSupport: boolean = fscreen.fullscreenEnabled;
  isFullscreen: boolean;
  @ViewChild('receiveclaims') receiveclaims: ElementRef | undefined;
  @Input() filterListFromDashboard:InsuredAndTpArray;
  @Input() selectedCurrencyId = -1;
  jsout: any;
  tempRecentClaims:RecentClaimsDto[]=[];
  temp: any;
  emptylist:InsuredAndTpArray = new InsuredAndTpArray();

  constructor(private dashboardService:DashboardService,private router:Router,
    private activedRouter:ActivatedRoute,private receivableService:ReceivableService,
    private chartService: DashboardChartService, private translate: TranslateService){

    if (this.hasFullscreenSupport) {
      fscreen.addEventListener('fullscreenchange', () => {
        this.isFullscreen = (fscreen.fullscreenElement !== null);
      }, false);
    }
    this.isPayable = (sessionStorage.getItem("toggleButtonStatus") == "false");
    this.translate.onLangChange.subscribe(() => {
      this.multiLanguageLebel();
    });
  }

  // eslint-disable-next-line @angular-eslint/use-lifecycle-interface
  ngOnDestroy() {
    if (this.hasFullscreenSupport) {
      fscreen.removeEventListener('fullscreenchange');
    }
  }
  ngOnInit(): void {
    this.emptylist.insurenceCompanyNames = [];
    this.emptylist.tpCompanyNames = [];
    this.dashboardService.isCheck.pipe(debounceTime(300),distinctUntilChanged()).subscribe(value=>{
      this.isPayable=value;
      this.getRecentClaims(this.emptylist);
    })
    this.getRecentClaims(this.emptylist);
    this.chartService.currencyValueChangeEvent.subscribe((value: number) => {
      this.selectedCurrencyId = value;
      this.getRecentClaims(this.emptylist);
    });
  }

  getRecentClaimsMtd(companyList:InsuredAndTpArray) {
    this.getRecentClaims(companyList);
  }

  /**
   * GET LATEST TEN CLAIM HISTORY
   */
  private getRecentClaims(companyList:InsuredAndTpArray) {
    const params = new HttpParams().set("isReceivable", this.isPayable).set("cur", this.selectedCurrencyId);
    sessionStorage.setItem('ViewReportLoss',JSON.stringify(this.isPayable));
    this.dashboardService.getRecentClaim(params, companyList).subscribe(data => {
      if (data) {
        this.temp = data;
        this.RecentClaim = this.temp;
         this.tempRecentClaims = _.cloneDeep(this.temp);
        this.multiLanguageLebel();
      }
    });
  }

  private multiLanguageLebel() {
    this.temp.map(x => {
      if (x.claimHistoryUniqueCode) {
        var tmp = this.translate.instant(`claimHistoryTemplate.${x.claimHistoryUniqueCode}`);
        const parsedObject = JSON.parse(x.rePlacableTemplateData);
        const keyValueList = [];
        for (const key in parsedObject) {
          if (parsedObject.hasOwnProperty(key)) {
            keyValueList.push({ key, value: parsedObject[key] });
          }
        }
        keyValueList.forEach(({ key, value }) => {
          const regex = new RegExp(key, "g");
          tmp = tmp.replace(regex, value);
        });
        if (!tmp.includes("claimHistoryTemplate")) {
          x.historyMessage = tmp;
        }
      }
    this.RecentClaim = this.temp;
    this.RecentClaim = this.RecentClaim.slice(0, 5);
    this.tempRecentClaims = _.cloneDeep(this.temp);
    });
    
  }

  ViewClaims(claimIdeintity){
    this.receivableService.setChangePayableTab(true);
    this.router.navigateByUrl('report-loss?claimId='+claimIdeintity);
  }



  toggleFullScreen() {
    if (this.hasFullscreenSupport && !this.isFullscreen) {
      const elem = this.receiveclaims.nativeElement;
      fscreen.requestFullscreen(elem) || elem['mozRequestFullscreen'] || elem['msRequestFullscreen'];
      this.zoomchat=true;
      this.fullshow=false;
      this.RecentClaim = this.tempRecentClaims.slice(0,10);
    }else{
      fscreen.exitFullscreen();
      this.zoomchat=false;
      this.fullshow=true;
      this.RecentClaim = this.RecentClaim.slice(0,5);
    }
  }
  @HostListener('fullscreenchange', ['$event'])
@HostListener('webkitfullscreenchange', ['$event'])
@HostListener('mozfullscreenchange', ['$event'])
@HostListener('MSFullscreenChange', ['$event'])
screenChange(event) {
 this.toggleFullScreen();
}



}

export class InsuredAndTpArray{
  insurenceCompanyNames:string[];
  tpCompanyNames:string[];
}
