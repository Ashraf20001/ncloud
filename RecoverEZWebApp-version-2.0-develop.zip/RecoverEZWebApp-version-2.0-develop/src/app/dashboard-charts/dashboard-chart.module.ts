import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { DashboardBarConfigComponent } from "./dashboard-bar-config/dashboard-bar-config.component";
import { DashboardBarComponent } from "./dashboard-bar/dashboard-bar.component";
import { DashboardHorizontalBarComponent } from "./dashboard-horizontal-bar/dashboard-horizontal-bar.component";
import { DashboardHorizontalStackedBarComponent } from "./dashboard-horizontal-stacked-bar/dashboard-horizontal-stacked-bar.component";
import { DashboardPieComponent } from "./dashboard-pie/dashboard-pie.component";
import { DatePipe } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatDialogModule } from '@angular/material/dialog';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatMenuModule } from '@angular/material/menu';
import {  TranslateModule } from '@ngx-translate/core';
import { DashboardVerticalBarComponent } from "./dashboard-vertical-bar/dashboard-vertical-bar.component";
import {MatTooltipModule} from '@angular/material/tooltip';
import { DashboardClaimDetailsComponent } from './dashbord-claim-details/dashboard-claim-details.component';


@NgModule({
  declarations:[
    DashboardBarComponent,
    DashboardBarConfigComponent,
    DashboardHorizontalBarComponent,
    DashboardHorizontalStackedBarComponent,
    DashboardPieComponent,
    DashboardVerticalBarComponent,
    DashboardClaimDetailsComponent
  ],
  imports:[
    CommonModule,MatTooltipModule,
    FormsModule,
    MatButtonModule,
    MatFormFieldModule,
    MatDialogModule,
    MatCardModule,
    MatIconModule,
    MatSelectModule,
    MatMenuModule,
    TranslateModule
  ],
  exports:[
    DashboardBarComponent,
    DashboardBarConfigComponent,
    DashboardHorizontalBarComponent,
    DashboardHorizontalStackedBarComponent,
    DashboardPieComponent,
    DashboardVerticalBarComponent,
    DashboardClaimDetailsComponent
  ],
  providers:[
    DatePipe
  ]
})

export class DashboardChartModule{
  static count: any;
  static label: unknown[];

}
