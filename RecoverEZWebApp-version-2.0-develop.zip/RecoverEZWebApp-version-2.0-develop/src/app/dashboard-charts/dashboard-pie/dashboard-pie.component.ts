import { Component, ViewChild, Input, SimpleChanges, HostListener, OnInit } from '@angular/core';
import Chart from 'chart.js/auto';
import jsPDF from 'jspdf';
import { pieChart, PieChartFilterDto } from 'src/app/models/dashboard-charts';
import { DashboardChartService } from 'src/app/service/dashboard-chart.service';
import { DashboardChartModule } from '../dashboard-chart.module';
import * as XLSX from 'xlsx';
import fscreen from 'fscreen';
import { AccessMappingSectionDto } from 'src/app/models/user-role-management/section-dto';
import { DashboardService } from 'src/app/service/dashboard.service';
import * as FileSaver from 'file-saver';
import * as ExcelJS from 'exceljs';
import { TranslateService } from '@ngx-translate/core';
import { debounceTime, distinctUntilChanged } from 'rxjs';

@Component({
  selector: 'app-dashboard-pie',
  templateUrl: './dashboard-pie.component.html',
  styleUrls: ['./dashboard-pie.component.scss']
})

export class DashboardPieComponent implements OnInit{
  canvas: any;
  ctx: any;
  @ViewChild('pieCanvas') pieCanvas!: { nativeElement: any };
  @ViewChild('pieChartDiv') pieChartDiv!: { nativeElement: any };
  @Input() filterListFromDashboard:InsuredAndTpArray;
  @Input() selectedCurrencyId = -1;
  lable = [];
  count=[];
  pieChart:any;
  countingitem=[]
  piechartvalue:pieChart ;
  isReceivable:boolean;

  zoomchat=false;
  fullshow=true;


  hasFullscreenSupport: boolean = fscreen.fullscreenEnabled;
  isFullscreen: boolean;
  elem:any;
  showOrHideIcon=true
  jsout: any;
  Reciableshow:boolean ;
  PayableShow:boolean;
  emptylist:InsuredAndTpArray = new InsuredAndTpArray();

  isDownloadEnabled = true;

  @Input() receivablePieChartAccessData: AccessMappingSectionDto;

  @Input() payablePieChartAccessData: AccessMappingSectionDto;

  constructor(private chatservice:DashboardChartService,private dashboardService:DashboardService,private translate : TranslateService) {

    if (this.hasFullscreenSupport) {
      fscreen.addEventListener('fullscreenchange', () => {
        this.isFullscreen = (fscreen.fullscreenElement !== null);
      }, false);
    }
    this.isReceivable = (sessionStorage.getItem("toggleButtonStatus") == "false");
  }

  ngOnInit() {
    this.isDownloadEnabled = (this.isReceivable && this.receivablePieChartAccessData.isDownload) || (!this.isReceivable && this.payablePieChartAccessData.isDownload);
    this.emptylist.insurenceCompanyNames = []
    this.emptylist.tpCompanyNames = []
    this.pieChartBrowser(this.isReceivable,this.emptylist);
    this.dashboardService.isCheck.pipe(debounceTime(300),distinctUntilChanged()).subscribe(value=>{
      this.isReceivable=value;
      this.pieChartBrowser(this.isReceivable,this.emptylist);
      this.isDownloadEnabled = (this.isReceivable && this.receivablePieChartAccessData.isDownload) || (!this.isReceivable && this.payablePieChartAccessData.isDownload);
    });
    this.translate.onLangChange.subscribe(() => {
      this.processDataAndInitializeChart(this.jsout);
    });
    this.chatservice.currencyValueChangeEvent.subscribe((value: number) => {
      this.selectedCurrencyId = value;
      this.pieChartBrowser(this.isReceivable,this.emptylist);
    });
  }


  pieChartBrowse1rMtd(companyList:InsuredAndTpArray){
    this.pieChartBrowser(this.isReceivable,companyList);
  }
  pieChartBrowser(isReceivable: boolean, companyList: InsuredAndTpArray): void {
    this.chatservice.getbychartData(companyList, isReceivable, this.selectedCurrencyId).subscribe((data: any) => {
      if(data.content){
      this.jsout =  data.content;
      this.processDataAndInitializeChart(this.jsout);
      }
    });

    this.Reciableshow = isReceivable;
    this.PayableShow = !isReceivable;
  }

  private processDataAndInitializeChart(data:any) {
    this.lable = [];
    this.count = [];
    this.countingitem = [];
    for (let i = 0; i < this.jsout.length; i++) {
      const tmp = this.translate.instant(`Pie_chart.${this.jsout[i][1]}`);
      this.count.push(this.jsout[i][0]);
      this.lable.push(tmp + "  " + "(" + this.jsout[i][0] + ")");
      this.countingitem.push(tmp + "  " + "(" + this.jsout[i][0] + ")");
    }
    if (this.pieChart) {
      this.pieChart.clear();
      this.pieChart.destroy();
    }
    this.canvas = this.pieCanvas.nativeElement;
    this.ctx = this.canvas.getContext('2d');
    this.pieChart = new Chart(this.ctx, {
      type: 'pie',
      data: {
        datasets: [
          {
            backgroundColor: [
              '#009E60',
              '#2E8B57',
              '#0BDA51',
              '#32CD32',
              '#90EE90',
              '#4CBB17',
              '#2AAA8A',
              '#00A36C',
              '#228B22',
              '#50C878',
            ],
            data: this.count, // Replace this with your actual data
          },
        ],
        labels: this.countingitem, // Replace this with your actual data
      },
      options: {
        plugins: {
          legend: {
            display: true,
            position: 'right',
            align: 'center',
            labels: {
              font: {
                size: 12,
                family: 'Inter',
              },
              boxWidth: 20,
            },
          },
        },
        aspectRatio: 2.5,
      },
      plugins: [this.customCanvasBackgroundColorPlugin()],
    });
    if (this.pieChart) {
      this.pieChart.data.labels = this.countingitem;
      this.pieChart.update();
    }
  }

  private customCanvasBackgroundColorPlugin() {
    return {
      id: 'customCanvasBackgroundColor',
      beforeDraw: (chart, args, options) => {
        const { ctx } = chart;
        ctx.save();
        ctx.globalCompositeOperation = 'destination-over';
        ctx.fillStyle = options.color || '#FFFFFF';
        ctx.fillRect(0, 0, chart.width, chart.height);
        ctx.restore();
      },
    };
  }


  ngOnDestroy() {
    if (this.hasFullscreenSupport) {
      fscreen.removeEventListener('fullscreenchange');
    }
  }


  //bar chart popup into fulscreen
  toggleFullScreen() {
    this.elem = this.pieChartDiv.nativeElement;

    if (this.hasFullscreenSupport && !this.isFullscreen) {
      fscreen.requestFullscreen(this.elem) ;
      this.showOrHideIcon=false
      this.zoomchat=true;
      this.fullshow=false;
    } else {
      fscreen.exitFullscreen();
      this.showOrHideIcon=true
      this.zoomchat=false;
      this.fullshow=true;
    }
  }
  @HostListener('fullscreenchange', ['$event'])
@HostListener('webkitfullscreenchange', ['$event'])
@HostListener('mozfullscreenchange', ['$event'])
@HostListener('MSFullscreenChange', ['$event'])
screenChange(event) {
 this.toggleFullScreen();
}


  // download option
  //download chart as image
  downloadAsJPEG(){
    let Receivablefilename
    if(!this.isReceivable){
      Receivablefilename = 'PayableClaimCountByStatus.jpeg';      
    }else{
      Receivablefilename = 'ReceivableClaimCountByStatus.jpeg';
    }
    const chartCanvas = document.getElementById(
      'pieChart'
    ) as HTMLCanvasElement;
    const ctx = chartCanvas.getContext('2d');

    // Get the heading text
    let headingText
    if(!this.isReceivable){
    headingText ='Payable Claim Count by Status';
    }else{
      headingText ='Receivable Claim Count by Status';
    }
    // Create a new canvas to combine the heading and chart
    const combinedCanvas = document.createElement('canvas');
    const combinedCtx = combinedCanvas.getContext('2d');

    // Set the canvas size to match the chart canvas plus the heading height
    combinedCanvas.width = chartCanvas.width;
    combinedCanvas.height = chartCanvas.height + 30; // Adjust the value as needed for the heading height

    // Draw the heading on the combined canvas
    combinedCtx.fillStyle = '#FFF'; // Set the background color if needed
    combinedCtx.fillRect(0, 0, combinedCanvas.width, combinedCanvas.height); // Fill the background
    combinedCtx.font = '24px Arial'; // Set the heading font
    combinedCtx.fillStyle = '#688f99'; // Set the heading color
    combinedCtx.textAlign = 'left'; // Left-align the heading
    combinedCtx.fillText(headingText, 10, 20); // Draw the heading, adjust '10' for the desired left margin

    // Draw the chart canvas on the combined canvas, below the heading
    combinedCtx.drawImage(chartCanvas, 0, 30); // Adjust the value as needed to position the chart below the heading

    // Convert the combined canvas to a data URL and trigger the download
    const imglink = document.createElement('a');
    const canvass = this.pieCanvas.nativeElement;
    imglink.download = Receivablefilename;
    // imglink.href = canvass.toDataURL('image/png',1);
    imglink.href = combinedCanvas.toDataURL('image/jpeg', 1);
    imglink.click();
  }

  //download chart as image
  downloadAsPDF(){
    let Receivablefilename
    if(!this.isReceivable){
      Receivablefilename = 'PayableClaimCountByStatus.pdf';      
    }else{
      Receivablefilename = 'ReceivableClaimCountByStatus.pdf';
    }
    const chartCanvas = document.getElementById('pieChart') as HTMLCanvasElement;

    // Get the heading text and color
    let headingText
    if(!this.isReceivable){
    headingText ='Payable Claim Count by Status';
    }else{
      headingText ='Receivable Claim Count by Status';
    }
    const headingColor = '#688f99'; // Replace this with your desired color
    const combinedCanvas = document.createElement('canvas');
    combinedCanvas.width = chartCanvas.width;
    combinedCanvas.height = chartCanvas.height + 30; // Adjust the value as needed for the heading height

    // Get the 2D context of the combined canvas
    const combinedCtx = combinedCanvas.getContext('2d');

    // Draw the heading on the combined canvas
    combinedCtx.fillStyle = '#ffffff'; // Set the background color to transparent
    combinedCtx.fillRect(0, 0, combinedCanvas.width, combinedCanvas.height); // Fill the canvas with the transparent background

    combinedCtx.fillStyle = headingColor; // Set the heading color
    combinedCtx.font = '24px Arial'; // Set the heading font
    combinedCtx.textAlign = 'left'; // Left-align the heading
    combinedCtx.fillText(headingText, 10, 20); // Draw the heading, adjust '10' for the desired left margin

    // Draw the chart canvas on the combined canvas, below the heading
    combinedCtx.drawImage(chartCanvas, 0, 30); // Adjust the value as needed to position the chart below the heading

    // Convert the combined canvas to a data URL
    const combinedImage = combinedCanvas.toDataURL('image/jpeg', 1);

    // const canvass = this.pieCanvas.nativeElement;
    // const canvasimg = canvass.toDataURL('image/png',1);

    let pdf = new jsPDF();
    pdf.addImage(combinedImage,'JPEG',15,15,180,80);
    pdf.save(Receivablefilename)
  }

  //download chart data as Excel
  async downloadAsExcel(){
    const data =this.jsout;
    const header = ['Count', 'Status'];

  // file name
  let Receivablefilename: string;
  if (!this.isReceivable) {
    Receivablefilename = 'PayableClaimCountByStatus.xlsx';
  } else {
    Receivablefilename = 'ReceivableClaimCountByStatus.xlsx';
  }
  // Capitalize the first letter of each header
  const headerFormatted = header.map(this.capitalizeFirstLetter);

  // Create a new workbook and worksheet using ExcelJS
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet(Receivablefilename, {
    views: [{ state: 'normal' }],
  });

  // Set bold style for the header row
  const headerRow = worksheet.addRow(headerFormatted);
  headerRow.font = { bold: true };

  // Add data rows to the worksheet
  data.forEach((rowData) => worksheet.addRow(Object.values(rowData)));

  // Generate Excel file and download
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  FileSaver.saveAs(blob, Receivablefilename);

  }

  capitalizeFirstLetter(input: string): string {
    if (typeof input !== 'string') {
      return input;
    }
    return input.charAt(0).toUpperCase() + input.slice(1);
  }

}

export class InsuredAndTpArray{
  insurenceCompanyNames:string[];
  tpCompanyNames:string[];
}


