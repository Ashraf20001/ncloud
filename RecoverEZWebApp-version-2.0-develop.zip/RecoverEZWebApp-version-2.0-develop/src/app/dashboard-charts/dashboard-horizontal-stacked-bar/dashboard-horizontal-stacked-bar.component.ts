import { HostListener, Input } from '@angular/core';
import { Component, ElementRef, ViewChild } from '@angular/core';
import Chart from 'chart.js/auto';
import jsPDF from 'jspdf';
import * as XLSX from 'xlsx';
import { DashboardChartService } from 'src/app/service/dashboard-chart.service';
import fscreen from 'fscreen';
import { AccessMappingSectionDto } from 'src/app/models/user-role-management/section-dto';
import { DashboardService } from 'src/app/service/dashboard.service';
import * as FileSaver from 'file-saver';
import * as ExcelJS from 'exceljs';
import { TranslateService } from '@ngx-translate/core';
import { debounceTime, distinctUntilChanged } from 'rxjs';
  @Component({
    selector: 'app-dashboard-horizontal-stacked-bar',
    templateUrl: './dashboard-horizontal-stacked-bar.component.html',
    styleUrls: ['./dashboard-horizontal-stacked-bar.component.scss']
  })

  export class DashboardHorizontalStackedBarComponent {
    jsout: any;
    showOrHideIcon=true
    hasFullscreenSupport: boolean = fscreen.fullscreenEnabled;
    isFullscreen: boolean;
    isReceivable:boolean;
    fullshow=true;
    @Input() filterListFromDashboard:InsuredAndTpArray;

    isDownloadEnabled = true;

    @Input() receivableHorizontalStackedBarChartAccessData: AccessMappingSectionDto;

    @Input() payableHorizontalStackedBarChartAccessData: AccessMappingSectionDto;

    @Input() selectedCurrencyId = -1;

    @ViewChild('StackedBarChart') StackedBarChart: ElementRef | undefined;
    @ViewChild('StackedBarChartDiv') StackedBarChartDiv: ElementRef | undefined;
    stackedBarChartData: Chart<"bar", number[], string>;
    jsobject: StackedBarExcelData[] = [];
    stackedBarChartLabel: string;
    toolTipValue: any;
    toolTipCompanyCount: any;
    emptylist:InsuredAndTpArray = new InsuredAndTpArray();

    constructor(
      public chartService: DashboardChartService,private dasboardService:DashboardService,private translate: TranslateService) {
        if (this.hasFullscreenSupport) {
          fscreen.addEventListener('fullscreenchange', () => {
            this.isFullscreen = (fscreen.fullscreenElement !== null);
          }, false);
        }
        this.isReceivable= (sessionStorage.getItem("toggleButtonStatus") == "false");

        this.translate.onLangChange.subscribe(() => {
          this.fetchStackedBarChart(this.jsout);
        });
    }

    ngOnInit() {
      this.isDownloadEnabled = (this.isReceivable && this.receivableHorizontalStackedBarChartAccessData.isDownload) || (!this.isReceivable && this.payableHorizontalStackedBarChartAccessData.isDownload);
      this.emptylist.insurenceCompanyNames = [];
      this.emptylist.tpCompanyNames = [];
      // this.stackedBarChart(this.isReceivable,Emptylist);
      // this.stackedBarChart(this.isReceivable,this.emptylist);
      this.dasboardService.isCheck.pipe(debounceTime(300),distinctUntilChanged()).subscribe(value=>{
        this.isReceivable=value;
        this.stackedBarChart(this.isReceivable,this.emptylist);
        this.isDownloadEnabled = (this.isReceivable && this.receivableHorizontalStackedBarChartAccessData.isDownload) || (!this.isReceivable && this.payableHorizontalStackedBarChartAccessData.isDownload);
      });
      this.chartService.currencyValueChangeEvent.subscribe((value: number) => {
        this.selectedCurrencyId = value;
        this.stackedBarChart(this.isReceivable,this.emptylist);
      });
    }

    openDialog(){}

  Reciableshow=false;
  PayableShow=true;
  zoomchat=false;
  backgroundColor=[
    'rgba(104, 143, 153, 1)', 'rgb(255,155,107)','rgb(0,200,200)','rgb(173,212,88)','rgb(116,186,161)'
  ]

  pieChartData:DataSetPieChart[] = [];
  stackedBarChartMtd(companyList:InsuredAndTpArray){
    this.stackedBarChart(this.isReceivable,companyList)
  }

    stackedBarChart(isReceivable:boolean,companyList:InsuredAndTpArray) {
      this.chartService.stackedBarChartData(companyList,isReceivable, this.selectedCurrencyId).subscribe((res: any) => {
        if(res){
          this.jsout = res;
          this.fetchStackedBarChart(this.jsout);
        }
      });
      this.Reciableshow=isReceivable;
      this.PayableShow=!isReceivable;
    }

    private fetchStackedBarChart(res: any) {
      this.pieChartData = [];
      const companies = res['content'].map(res => res.company);
      const values = res['content'].map(res => res.count);
      const shortNames = res['content'].map(res => res.shortName);
      const labels = ['0-5', '6-15', '16-30', '31-60', '61-90'];
      const nameLabel = this.translate.instant("HarizontalBar.company");
      const countLabel = this.translate.instant("HarizontalBar.count");
      const plugin = {
        id: 'customCanvasBackgroundColor',
        beforeDraw: (chart, args, options) => {
          const { ctx } = chart;
          ctx.save();
          ctx.globalCompositeOperation = 'destination-over';
          ctx.fillStyle = options.color || '#FFFFFF';
          ctx.fillRect(0, 0, chart.width, chart.height);
          ctx.restore();

        }
      };

      if (this.stackedBarChartData) {
        this.stackedBarChartData.clear();
        this.stackedBarChartData.destroy();
      }

      for (let index = 0; index < companies.length; index++) {
        const chartData = new DataSetPieChart();
        chartData.company = companies[index];
        chartData.label = shortNames[index];
        chartData.data = values[index];
        chartData.backgroundColor = this.backgroundColor[index];
        if (chartData !== undefined) {
          this.pieChartData.push(chartData);
        }

      }
      this.stackedBarChartData = new Chart("StackedBarChart", {
        type: 'bar',
        data: {
          labels: labels,

          datasets: this.pieChartData,
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          indexAxis: 'y',
          scales: {
            x: {
              grid: {
                display: false
              },
              stacked: true,
              ticks: {
                font: {
                  size: 14.5,
                  family: 'Inter',
                },

                precision: 0
              }
            },
            y: {
              grid: {
                display: false
              },
              stacked: true,
              display: true,
              reverse: true,
              beginAtZero: true,
              ticks: {
                font: {
                  size: 14.5,
                  family: 'Inter',
                },

                precision: 0
              },
              title: {
                display: true,
                text: this.stackedBarChartLabel,
                align: 'center',
                font: {
                  family: 'Inter'
                }
              },
            },
          },
          plugins: {
            legend: {
              position: 'bottom',
              labels: {
                font: {
                  size: 14.5,
                  family: 'Inter',
                },
                boxWidth: 20
              }
            },
            tooltip: {
              mode: 'index',
              position: 'nearest',
              callbacks: {
                label: function (context) {
                  const datasetIndex = context.datasetIndex;
                  const dataIndex = context.dataIndex;
                  const companyy = companies[datasetIndex];
                  const dataset = context.dataset.data;
                  const count = Array.isArray(dataset[dataIndex]) ? dataset[dataIndex][context.parsed.x] : dataset[dataIndex];
                  if (count > 0) {
                    return `${nameLabel}  ${companyy} - ${countLabel} ${count}`;
                  } else {
                    return '';
                  }
                },
              },
            }
          },
        },
        plugins: [plugin],
      });
      this.multiLanguageForLebel();
    }

    private multiLanguageForLebel() {
      this.stackedBarChartData.options.scales['y'].title.text = this.translate.instant("HarizontalBar.days");
      this.stackedBarChartLabel = this.stackedBarChartData.options.scales['y'].title.text.toString();
      this.stackedBarChartData.update();
    }
    // // download option
    downloadAsJPEG(){
      let Receivablefilename
      if(this.isReceivable){
        Receivablefilename = 'PendingReceivables.jpeg';
      }else{
        Receivablefilename = 'PendingPayables.jpeg';
      }
      const chartCanvas = document.getElementById(
        'StackedBarChart'
      ) as HTMLCanvasElement;
      const ctx = chartCanvas.getContext('2d');

      // Get the heading text
      let headingText
      if(!this.isReceivable){
      headingText ='Pending Payables';
      }else{
        headingText ='Pending Receivables';
      }

      // Create a new canvas to combine the heading and chart
      const combinedCanvas = document.createElement('canvas');
      const combinedCtx = combinedCanvas.getContext('2d');

      // Set the canvas size to match the chart canvas plus the heading height
      combinedCanvas.width = chartCanvas.width;
      combinedCanvas.height = chartCanvas.height + 30; // Adjust the value as needed for the heading height

      // Draw the heading on the combined canvas
      combinedCtx.fillStyle = '#FFF'; // Set the background color if needed
      combinedCtx.fillRect(0, 0, combinedCanvas.width, combinedCanvas.height); // Fill the background
      combinedCtx.font = '24px Arial'; // Set the heading font
      combinedCtx.fillStyle = '#688f99'; // Set the heading color
      combinedCtx.textAlign = 'left'; // Left-align the heading
      combinedCtx.fillText(headingText, 10, 20); // Draw the heading, adjust '10' for the desired left margin

      // Draw the chart canvas on the combined canvas, below the heading
      combinedCtx.drawImage(chartCanvas, 0, 30); // Adjust the value as needed to position the chart below the heading

      // Convert the combined canvas to a data URL and trigger the download
      const imglink = document.createElement('a');
      const canvass = document.getElementById('StackedBarChart') as HTMLCanvasElement;
      imglink.download = Receivablefilename;
      // imglink.href = canvass.toDataURL('image/png',1);
      imglink.href = combinedCanvas.toDataURL('image/jpeg', 1);
      imglink.click();
    }

    downloadAsPDF(){
      let Receivablefilename
      if(!this.isReceivable){
        Receivablefilename = 'PendingPayables.pdf';
      }else{
        Receivablefilename = 'PendingReceivables.pdf';
      }
      const canvass = document.getElementById('StackedBarChart') as HTMLCanvasElement;
      // const canvasimg = canvass.toDataURL('image/png',1);
      // const chartCanvas = document.getElementById('BarChart') as HTMLCanvasElement;

      // Get the heading text and color
      let headingText
      if(!this.isReceivable){
      headingText ='Pending Payables';
      }else{
        headingText ='Pending Receivables';
      }
      const headingColor = '#688f99'; // Replace this with your desired color
      const combinedCanvas = document.createElement('canvas');
      combinedCanvas.width = canvass.width;
      combinedCanvas.height = canvass.height + 30; // Adjust the value as needed for the heading height

      // Get the 2D context of the combined canvas
      const combinedCtx = combinedCanvas.getContext('2d');

      // Draw the heading on the combined canvas
      combinedCtx.fillStyle = '#ffffff'; // Set the background color to transparent
      combinedCtx.fillRect(0, 0, combinedCanvas.width, combinedCanvas.height); // Fill the canvas with the transparent background

      combinedCtx.fillStyle = headingColor; // Set the heading color
      combinedCtx.font = '24px Arial'; // Set the heading font
      combinedCtx.textAlign = 'left'; // Left-align the heading
      combinedCtx.fillText(headingText, 10, 20); // Draw the heading, adjust '10' for the desired left margin

      // Draw the chart canvas on the combined canvas, below the heading
      combinedCtx.drawImage(canvass, 0, 40); // Adjust the value as needed to position the chart below the heading

      // Convert the combined canvas to a data URL
      const combinedImage = combinedCanvas.toDataURL('image/jpeg', 1);

      const pdf = new jsPDF();
      pdf.addImage(combinedImage,'JPEG',15,15,180,80);
      pdf.save(Receivablefilename);
    }
    toggleFullScreen() {
      if (this.hasFullscreenSupport && !this.isFullscreen) {
        const elem = this.StackedBarChartDiv.nativeElement;
        fscreen.requestFullscreen(elem) || elem['mozRequestFullscreen'] || elem['msRequestFullscreen'];
        this.showOrHideIcon=false;
        this.zoomchat=true;
        this.fullshow=false;
      } else {
        fscreen.exitFullscreen();
        this.showOrHideIcon=true;
        this.zoomchat=false;
        this.fullshow=true;

      }
    }
@HostListener('fullscreenchange', ['$event'])
@HostListener('webkitfullscreenchange', ['$event'])
@HostListener('mozfullscreenchange', ['$event'])
@HostListener('MSFullscreenChange', ['$event'])
screenChange(event) {
 this.toggleFullScreen();
}

async downloadAsExcel() {
  const data = this.jsout.content;

  // File name
  let Receivablefilename;
  if (!this.isReceivable) {
    Receivablefilename = 'PendingPayables.xlsx';
  } else {
    Receivablefilename = 'PendingReceivables.xlsx';
  }
  // Create a new workbook and worksheet using ExcelJS
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet(Receivablefilename, {
    views: [{ state: 'normal' }],
  });

  // Set bold style for the header row
  const headerRow = worksheet.addRow(['Company', 'Day_0_to_5', 'Day_6_to_15', 'Day_16_to_30', 'Day_31_to_60', 'Day_61_to_90']);
  headerRow.font = { bold: true };

  // Add data rows to the worksheet
  const jsobj = this.convertObjectIntoExcelFormat(this.jsout.content);
  jsobj.forEach((rowData) => worksheet.addRow(Object.values(rowData)));

    // Adjust the column width based on content
  // worksheet.columns.forEach((column) => {
  //   const maxLength = Math.max(...column.values.map((cell) => cell.toString().length));
  //   column.width = Math.min(maxLength + 2, 30); // Adjust the column width as needed
  // });

  // Generate Excel file and download
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  FileSaver.saveAs(blob, Receivablefilename);
}

    convertObjectIntoExcelFormat(content: any) : any{
       this.jsobject = [];
      content.forEach(element => {
        let singleData = new StackedBarExcelData;
        singleData.company = element.company;
        singleData.day_0_to_5 = element.count[0];
        singleData.day_6_to_15 = element.count[1];
        singleData.day_16_to_30 = element.count[2];
        singleData.day_31_to_60 = element.count[3];
        singleData.day_61_to_90 = element.count[4];

        this.jsobject.push(singleData);
      });
      return this.jsobject;

    }
  }
  export class StackedBarExcelData{
    company: string;
    day_0_to_5: number;
    day_6_to_15: number;
    day_16_to_30: number;
    day_31_to_60: number;
    day_61_to_90: number;
  }

  export class InsuredAndTpArray{
    insurenceCompanyNames:string[];
    tpCompanyNames:string[];
  }

  export class DataSetPieChart{
    label:string;
    data:number[];
    company:string;
    backgroundColor:string;
    nameLabel:string;
    countLabel: string;
  }
