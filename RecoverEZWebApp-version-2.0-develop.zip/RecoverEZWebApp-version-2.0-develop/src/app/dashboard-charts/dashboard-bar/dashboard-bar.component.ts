import { DatePipe } from '@angular/common';
import { Component, ViewChild, Input, HostListener } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DashboardChartService } from 'src/app/service/dashboard-chart.service';
import jsPDF from 'jspdf';
import * as XLSX from 'xlsx';
import fscreen from 'fscreen';
import { DashboardBarConfigComponent, FilterData } from '../dashboard-bar-config/dashboard-bar-config.component';
import { Chart } from 'chart.js/auto';
import { DashboardService } from 'src/app/service/dashboard.service';
import { AccessMappingSectionDto } from 'src/app/models/user-role-management/section-dto';
import * as FileSaver from 'file-saver';
import * as ExcelJS from 'exceljs';
import { TranslateService } from '@ngx-translate/core';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

@Component({
  selector: 'app-dashboard-bar',
  templateUrl: './dashboard-bar.component.html',
  styleUrls: ['./dashboard-bar.component.scss']
})



export class DashboardBarComponent{

  barChartData:any;
  jsout:any;
  hasFullscreenSupport: boolean = fscreen.fullscreenEnabled;
  isFullscreen: boolean;
  filterData:FilterData;
  zoomchat=false;
  fullshow=true;
  datavalues:any=[];
  isPayable :boolean;
  @ViewChild('barChartDiv') barChartDiv!: { nativeElement: any };
  elem:any;
  showOrHideIcon=true

  @Input() filterListFromDashboard:InsuredAndTpArray;

  @Input() receivableBarChartAccessData: AccessMappingSectionDto;

  @Input() payableBarChartAccessData: AccessMappingSectionDto;

  @Input() selectedCurrencyId = -1;

  isDownloadEnabled = true;
  receivablelabel: string;
  payablelabel: string;
  transLabels :any[];
  selectedInsuredAndTpArray: InsuredAndTpArray;

  constructor(
    public chartService: DashboardChartService,public dialog: MatDialog, public datepipe: DatePipe,private dashboardService:DashboardService,private translate: TranslateService) {

      if (this.hasFullscreenSupport) {
        fscreen.addEventListener('fullscreenchange', () => {
          this.isFullscreen = (fscreen.fullscreenElement !== null);
        }, false);
      }
      this.isPayable = (sessionStorage.getItem("toggleButtonStatus") == "false");

    this.translate.onLangChange.subscribe(() => {
      this.processDataAndInitializeChart(this.jsout, this.isPayable);
    });
  }

  ngOnInit() {
    this.isDownloadEnabled = (this.isPayable && this.receivableBarChartAccessData.isDownload) || (!this.isPayable && this.payableBarChartAccessData.isDownload);
    this.dashboardService.isCheck.pipe( debounceTime(300), distinctUntilChanged()).subscribe(value=>{
      this.isPayable=value;
      this.filterData = {
        xlabel : 'Period',
        xvalue : 'Month',
        ylabel : 'Count',
        yvalue : 10000
      };
      this.selectedInsuredAndTpArray = new InsuredAndTpArray();
      this.selectedInsuredAndTpArray.insurenceCompanyNames = []
      this.selectedInsuredAndTpArray.tpCompanyNames = []
      this.barchart(this.isPayable,this.selectedInsuredAndTpArray,this.filterData.xlabel, this.filterData.xvalue,this.filterData.ylabel, this.filterData.yvalue);
      this.isDownloadEnabled = (this.isPayable && this.receivableBarChartAccessData.isDownload) || (!this.isPayable && this.payableBarChartAccessData.isDownload);
    });

    this.filterData = {
      xlabel : 'Period',
      xvalue : 'Month',
      ylabel : 'Count',
      yvalue : 10000
    };
    this.selectedInsuredAndTpArray = new InsuredAndTpArray();
      this.selectedInsuredAndTpArray.insurenceCompanyNames = []
      this.selectedInsuredAndTpArray.tpCompanyNames = []
    // this.barchart(this.isPayable,this.selectedInsuredAndTpArray,this.filterData.xlabel, this.filterData.xvalue,this.filterData.ylabel, this.filterData.yvalue);
    this.chartService.currencyValueChangeEvent.subscribe((value: number) => {
      this.selectedCurrencyId = value;
      this.barchart(this.isPayable,this.selectedInsuredAndTpArray,this.filterData.xlabel, this.filterData.xvalue,this.filterData.ylabel, this.filterData.yvalue);
    });
  }

  barChartDataMethod(companyList:InsuredAndTpArray){
    this.selectedInsuredAndTpArray = companyList;
    this.barchart(this.isPayable,this.selectedInsuredAndTpArray,this.filterData.xlabel,this.filterData.xvalue,this.filterData.ylabel,this.filterData.yvalue)
  }

  barchart(isPayable2:boolean,companyList,xlab:string,xval:string,ylab:string,yval:number){
    this.chartService.barChartData(companyList,xlab,xval,ylab,yval,this.selectedCurrencyId).subscribe((res:any)=>{
      if(res){
        this.jsout=res;
        this.processDataAndInitializeChart(this.jsout, isPayable2);
      }
    });
  }

  private processDataAndInitializeChart(res: any, isPayable2: boolean) {
    let receivable: any;
    let payable: any;
    let barChartLabel: any;
    receivable = res['content'].map((item: any) => item.receivable);
    payable = res['content'].map((item: any) => item.payable);
    barChartLabel = res['content'].map((item: any) => item.month);
    this.transLabels = barChartLabel;

    if (this.barChartData) {
      this.barChartData.clear();
      this.barChartData.destroy();
    }

    if (isPayable2) {
      this.datavalues = [
        {
          data: receivable,
          label: this.receivablelabel,
          backgroundColor: '#688F99',
        },
        {
          data: payable,
          label: this.payablelabel,
          backgroundColor: 'rgb(255,155,107)',
        }
      ];
    } else {
      this.datavalues = [
        {
          data: payable,
          label: this.payablelabel,
          backgroundColor: 'rgb(255,155,107)',
        },
        {
          data: receivable,
          label: this.receivablelabel,
          backgroundColor: '#688F99',
        }
      ];
    }
    this.barChartData = new Chart('BarChart', {
      type: 'bar',
      data: {
        labels: barChartLabel,
        datasets: this.datavalues
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: true,
            position: 'bottom',
            align: 'start',
            labels: {
              font: {
                size: 14.5,
                family: 'Inter'
              },
              boxWidth: 14
            }
          }
        },
        scales: {
          y: {
            grid: {
              display: false
            },
            ticks: {
              font: {
                size: 14.5,
                family: 'Inter'
              },
              precision: 0
            }
          },
          x: {
            grid: {
              display: false
            },
            ticks: {
              font: {
                size: 14.5,
                family: 'Inter'
              },
              precision: 0
            }
          }
        },
        aspectRatio: 2.5
      },
      plugins: [this.customCanvasBackgroundColorPlugin()]
    });
    this.multilangLabel();
  }

  private customCanvasBackgroundColorPlugin() {
    return {
      id: 'customCanvasBackgroundColor',
      beforeDraw: (chart, args, options) => {
        const { ctx } = chart;
        ctx.save();
        ctx.globalCompositeOperation = 'destination-over';
        ctx.fillStyle = options.color || '#FFFFFF';
        ctx.fillRect(0, 0, chart.width, chart.height);
        ctx.restore();
      }
    };
  }

  private multilangLabel() {
    if (this.transLabels) {
      this.barChartData.data.labels = this.transLabels.map(x => this.translate.instant(`Bar_chart.${x}`));
    }
    this.payablelabel = this.translate.instant("Bar_chart.payable");
    this.receivablelabel = this.translate.instant("Bar_chart.receivable");
    if (this.isPayable) {
      this.barChartData.data.datasets[0].label = this.receivablelabel;
      this.barChartData.data.datasets[1].label = this.payablelabel;
    } else {
      this.barChartData.data.datasets[1].label = this.receivablelabel;
      this.barChartData.data.datasets[0].label = this.payablelabel;
    }
    this.barChartData.update();
  }

  ngOnDestroy() {
    if (this.hasFullscreenSupport) {
      fscreen.removeEventListener('fullscreenchange');
    }
  }


  //bar chart popup into fulscreen
  toggleFullScreen() {
    this.elem = this.barChartDiv.nativeElement;

    if (this.hasFullscreenSupport && !this.isFullscreen) {
      fscreen.requestFullscreen(this.elem) ;
      this.showOrHideIcon=false
      this.zoomchat=true;
      this.fullshow=false;

    } else {

      fscreen.exitFullscreen();
      this.showOrHideIcon=true
      this.zoomchat=false;
      this.fullshow=true;



    }


  }
@HostListener('fullscreenchange', ['$event'])
@HostListener('webkitfullscreenchange', ['$event'])
@HostListener('mozfullscreenchange', ['$event'])
@HostListener('MSFullscreenChange', ['$event'])
screenChange(event) {
 this.toggleFullScreen();
}



  //config popup
  openDialog(companyList:InsuredAndTpArray): void {
    this.selectedInsuredAndTpArray = companyList;
    const dialogRef = this.dialog.open(DashboardBarConfigComponent, {
      // width: '60%',
      // height: '35%',
      data: this.filterData
    });
    dialogRef.afterClosed().subscribe((result:FilterData) => {
      if(result !== undefined){
        this.filterData.xlabel = result.xlabel;
        this.filterData.xvalue = result.xvalue;
        this.filterData.ylabel = result.ylabel;
        this.filterData.yvalue = result.yvalue;
        this.barchart(this.isPayable,this.selectedInsuredAndTpArray,this.filterData.xlabel,this.filterData.xvalue,this.filterData.ylabel,this.filterData.yvalue);
      }
    });
  }

  // download option
  //download chart as image
  downloadAsJPEG(){
    let Receivablefilename
    if(!this.isPayable){
      Receivablefilename = 'TotalNoOfPayableandReceivables.jpeg';
    }else{
      Receivablefilename = 'TotalNoOfReceivablesandPayables.jpeg';
    }

    const chartCanvas = document.getElementById(
      'BarChart'
    ) as HTMLCanvasElement;
    const ctx = chartCanvas.getContext('2d');

    // Get the heading text
    let headingText
    if(!this.isPayable){
    headingText ='Total No. Of Payables and Receivables';
    }else{
      headingText ='Total No. Of Receivables And Payables';
    }
    // Create a new canvas to combine the heading and chart
    const combinedCanvas = document.createElement('canvas');
    const combinedCtx = combinedCanvas.getContext('2d');

    // Set the canvas size to match the chart canvas plus the heading height
    combinedCanvas.width = chartCanvas.width;
    combinedCanvas.height = chartCanvas.height + 30; // Adjust the value as needed for the heading height

    // Draw the heading on the combined canvas
    combinedCtx.fillStyle = '#FFF'; // Set the background color if needed
    combinedCtx.fillRect(0, 0, combinedCanvas.width, combinedCanvas.height); // Fill the background
    combinedCtx.font = '24px Arial'; // Set the heading font
    combinedCtx.fillStyle = '#688f99'; // Set the heading color
    combinedCtx.textAlign = 'left'; // Left-align the heading
    combinedCtx.fillText(headingText, 10, 20); // Draw the heading, adjust '10' for the desired left margin

    // Draw the chart canvas on the combined canvas, below the heading
    combinedCtx.drawImage(chartCanvas, 0, 40); // Adjust the value as needed to position the chart below the heading

    // Convert the combined canvas to a data URL and trigger the download
    const imglink = document.createElement('a');
    const canvass = document.getElementById('BarChart') as HTMLCanvasElement;
    imglink.download = Receivablefilename;
    imglink.href = combinedCanvas.toDataURL('image/jpeg', 1);
    imglink.click();
  }

  //download chart as image
  downloadAsPDF(){
    let Receivablefilename
    if(!this.isPayable){
      Receivablefilename = 'TotalNoOfPayableandReceivables.pdf';
    }else{
      Receivablefilename = 'TotalNoOfReceivablesandPayables.pdf';
    }
    const chartCanvas = document.getElementById('BarChart') as HTMLCanvasElement;

      // Get the heading text and color
      let headingText
      if(!this.isPayable){
      headingText ='Total No. of Payables and Receivables';
      }else{
        headingText ='Total No. of Receivables and Payables';
      }
      const headingColor = '#688f99'; // Replace this with your desired color
      const combinedCanvas = document.createElement('canvas');
      combinedCanvas.width = chartCanvas.width;
      combinedCanvas.height = chartCanvas.height + 30; // Adjust the value as needed for the heading height

      // Get the 2D context of the combined canvas
      const combinedCtx = combinedCanvas.getContext('2d');

      // Draw the heading on the combined canvas
      combinedCtx.fillStyle = '#ffffff'; // Set the background color to transparent
      combinedCtx.fillRect(0, 0, combinedCanvas.width, combinedCanvas.height); // Fill the canvas with the transparent background

      combinedCtx.fillStyle = headingColor; // Set the heading color
      combinedCtx.font = '24px Arial'; // Set the heading font
      combinedCtx.textAlign = 'left'; // Left-align the heading
      combinedCtx.fillText(headingText, 10, 20); // Draw the heading, adjust '10' for the desired left margin

      // Draw the chart canvas on the combined canvas, below the heading
      combinedCtx.drawImage(chartCanvas, 0, 40); // Adjust the value as needed to position the chart below the heading

      // Convert the combined canvas to a data URL
      const combinedImage = combinedCanvas.toDataURL('image/jpeg', 1);

      // Create a new jsPDF instance
    // const canvass = document.getElementById('BarChart') as HTMLCanvasElement;
    // const canvasimg = canvass.toDataURL('image/png',1);

    let pdf = new jsPDF();
    pdf.addImage(combinedImage,'JPEG',15,15,180,80);
    pdf.save(Receivablefilename);
  }

  // download chart data as Excel
  async downloadAsExcel(){
    const data = this.jsout.content;
    const header = Object.keys(data[0]);

      // file name
  let Receivablefilename: string;
  if (!this.isPayable) {
    Receivablefilename = 'TotalNoOfPayableandReceivables.xlsx';
  } else {
    Receivablefilename = 'TotalNoOfReceivablesandPayables.xlsx';
  }

  // Capitalize the first letter of each header
  const headerFormatted = header.map(this.capitalizeFirstLetter);

  // Create a new workbook and worksheet using ExcelJS
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet(Receivablefilename, {
    views: [{ state: 'normal' }],
  });

  // Set bold style for the header row
  const headerRow = worksheet.addRow(headerFormatted);
  headerRow.font = { bold: true };

  // Add data rows to the worksheet
  data.forEach((rowData) => worksheet.addRow(Object.values(rowData)));

  // Adjust the column width based on content
  for (let i = 0; i < header.length; i++) {
    const column = worksheet.getColumn(i + 1); // Columns are 1-indexed
    const columnData = [headerFormatted[i], ...data.map((row) => row[header[i]])];
    const columnMaxWidth = Math.max(...columnData.map((cell) => cell.toString().length));
    column.width = Math.min(columnMaxWidth + 2, 50); // Limit maximum width to 50 characters
  }

  // Generate Excel file and download
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  FileSaver.saveAs(blob, Receivablefilename);
  }
  capitalizeFirstLetter(input: string): string {
    if (typeof input !== 'string') {
      return input;
    }
    return input.charAt(0).toUpperCase() + input.slice(1);
  }



}

export class InsuredAndTpArray{
  insurenceCompanyNames:string[];
  tpCompanyNames:string[];
}
