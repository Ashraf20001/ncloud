import { DashboardClaimDetailsComponent } from './../dashboard-charts/dashbord-claim-details/dashboard-claim-details.component';
import { DashboardVerticalBarComponent } from './../dashboard-charts/dashboard-vertical-bar/dashboard-vertical-bar.component';
import { DashboardHorizontalStackedBarComponent } from './../dashboard-charts/dashboard-horizontal-stacked-bar/dashboard-horizontal-stacked-bar.component';
import { DashboardHorizontalBarComponent } from './../dashboard-charts/dashboard-horizontal-bar/dashboard-horizontal-bar.component';
import { DashboardBarComponent } from './../dashboard-charts/dashboard-bar/dashboard-bar.component';
import { DashboardPieComponent } from './../dashboard-charts/dashboard-pie/dashboard-pie.component';
import { Component, OnInit, ViewChild } from '@angular/core';
import { appConst } from '../service/app.const';
import { AppService } from '../service/role access/service/app.service';
import { AdminService } from '../service/admin.service';
import { AccessMappingPageDto } from '../models/user-role-management/access-Mapping-PageDto ';
import { DashboardHeaderComponent } from './dashboard-header/dashboard-header.component';
import { Router } from '@angular/router';
import { zip } from 'rxjs';
import { AccessMappingSectionDto } from '../models/user-role-management/section-dto';
import { MatDialog } from '@angular/material/dialog';
import { DropDownOptionDto } from '../models/dropdown-option-dto';
import { DashboardService } from '../service/dashboard.service';
import { DashboardChartService } from '../service/dashboard-chart.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})

export class DashboardComponent implements OnInit {

  insurenceTpListFromChart:InsuredAndTpArray;
  @ViewChild(DashboardHeaderComponent) dashboardHeader:DashboardHeaderComponent;
  @ViewChild(DashboardPieComponent) pieChart:DashboardPieComponent;
  @ViewChild(DashboardBarComponent) barChart:DashboardBarComponent;
  @ViewChild(DashboardHorizontalBarComponent) horizontalBarChart:DashboardHorizontalBarComponent;
  @ViewChild(DashboardHorizontalStackedBarComponent) stackedBarChart:DashboardHorizontalStackedBarComponent;
  @ViewChild(DashboardVerticalBarComponent) verticalChart:DashboardVerticalBarComponent;
  @ViewChild(DashboardClaimDetailsComponent) claimDetailsChart:DashboardClaimDetailsComponent;

  receivableContent: any;
  payableContent: any;

  receivablePageInfo: any;
  payablePageInfo: any;
  public appConst = appConst;
  receivablePageId = appConst.PAGE_NAME.DASHBOARD.RECEIVABLE_DASHBOARD.PAGEID;
  payablePageId = appConst.PAGE_NAME.DASHBOARD.PAYABLE_DASHBOARD.PAGEID;
  isReceivableDashboard = true; // true means payable dashboard; false means receivable dashboard
  privilegeName = appConst.PAGE_NAME.DASHBOARD.RECEIVABLE_DASHBOARD.BUTTON_ACCESS.QUICKLINKS;
  menuHeaderList: any;
  currencyOptionList: DropDownOptionDto[] = [];
  selectedCurrencyId = -1;

  receivableDashboardPageAccessData: AccessMappingPageDto;
  payableDashboardPageAccessData: AccessMappingPageDto;
  isDashboardEnabled = true;

  receivablePieChartAccessData: AccessMappingSectionDto;
  payablePieChartAccessData: AccessMappingSectionDto;

  receivableBarChartAccessData: AccessMappingSectionDto;
  payableBarChartAccessData: AccessMappingSectionDto;

  receivableHorizontalBarChartAccessData: AccessMappingSectionDto;
  payableHorizontalBarChartAccessData: AccessMappingSectionDto;

  receivableHorizontalStackedBarChartAccessData: AccessMappingSectionDto;
  payableHorizontalStackedBarChartAccessData: AccessMappingSectionDto;

  receivableVerticalBarChartAccessData: AccessMappingSectionDto;
  payableVerticalBarChartAccessData: AccessMappingSectionDto;

  receivableClaimsDetailsChartAccessData: AccessMappingSectionDto;
  payableClaimsDetailsChartAccessData: AccessMappingSectionDto;

  collectFilterCompanyList(event:InsuredAndTpArray){
    this.insurenceTpListFromChart = event;
    this.dashboardHeader?.DashboardDetails(this.insurenceTpListFromChart);
    this.barChart?.barChartDataMethod(this.insurenceTpListFromChart);
    this.pieChart?.pieChartBrowse1rMtd(this.insurenceTpListFromChart);
    this.horizontalBarChart?.barChartMethod(this.insurenceTpListFromChart);
    this.stackedBarChart?.stackedBarChartMtd(this.insurenceTpListFromChart);
    this.verticalChart?.barChartMethodMtd(this.insurenceTpListFromChart);
    this.claimDetailsChart?.getRecentClaimsMtd(this.insurenceTpListFromChart);
  }

  constructor(private router: Router, private appService : AppService, private adminService: AdminService, 
    private dashboardService: DashboardService, private dashboardChartService: DashboardChartService){

  }

  ngOnInit(): void {
    this.getPageAccessDetails();
  }

  getCurrencyList(): void {
    this.dashboardService.getCurrencyDropDownData().subscribe((response: any) => {
      if(response && response.content) {
        this.currencyOptionList = response.content;
        this.selectedCurrencyId = this.currencyOptionList && this.currencyOptionList.length > 0 ? this.currencyOptionList[0].optionId : -1;
        this.onCurrencyChange(this.selectedCurrencyId);
      }
    });
  }

  floatCheck=false;
   rotate(){
     this.floatCheck=!this.floatCheck;
     }

  getPageAccessDetails(): void {
    zip(
      this.appService.getPageAccess(appConst.PAGE_NAME.DASHBOARD.RECEIVABLE_DASHBOARD.PAGE_IDENTITY),
      this.appService.getPageAccess(appConst.PAGE_NAME.DASHBOARD.PAYABLE_DASHBOARD.PAGE_IDENTITY)
    )
    .subscribe((responseList: any) => {
      if(responseList) {
        this.receivableDashboardPageAccessData = responseList[0].content;
        this.payableDashboardPageAccessData = responseList[1].content;

        this.receivableContent = responseList[0].content;
        this.payableContent = responseList[1].content;
        this.isDashboardEnabled = this.receivableDashboardPageAccessData.isEnabled || this.payableDashboardPageAccessData.isEnabled;
        if(!this.isDashboardEnabled) {
          // this.router.navigateByUrl('dashboard/access-denied');
        } else {
          if(this.appService.menuListFromHeader) {
            this.menuHeaderList = this.appService.menuListFromHeader;
          } else {
            this.getMenuItems();
          }
          if(this.receivableDashboardPageAccessData.isEnabled && this.payableDashboardPageAccessData.isEnabled){
            this.getReceivablePrivilege();
            }
            if(!this.receivableDashboardPageAccessData.isEnabled && this.payableDashboardPageAccessData.isEnabled){

            this.getPayablePrivilege();
            }
            if(this.receivableDashboardPageAccessData.isEnabled && !this.payableDashboardPageAccessData.isEnabled){

              this.getReceivablePrivilege();
              }
          if(this.receivableDashboardPageAccessData && this.receivableDashboardPageAccessData.sectionData) {
            //bar chart
            this.receivableBarChartAccessData = this.receivableDashboardPageAccessData?.sectionData[0];
            //pie chart
            this.receivablePieChartAccessData = this.receivableDashboardPageAccessData?.sectionData[1];
            //horizontal bar
            this.receivableHorizontalBarChartAccessData = this.receivableDashboardPageAccessData?.sectionData[2];
            //details
            this.receivableClaimsDetailsChartAccessData = this.receivableDashboardPageAccessData?.sectionData[3];
            //vertical
            this.receivableVerticalBarChartAccessData = this.receivableDashboardPageAccessData?.sectionData[4];
            //stacked
            this.receivableHorizontalStackedBarChartAccessData = this.receivableDashboardPageAccessData?.sectionData[5];
          }
          if(this.payableDashboardPageAccessData && this.payableDashboardPageAccessData.sectionData) {
            //bar chart
            this.payableBarChartAccessData = this.payableDashboardPageAccessData?.sectionData[0];
            //pie chart
            this.payablePieChartAccessData = this.payableDashboardPageAccessData?.sectionData[1];
            //horizontal bar
            this.payableHorizontalBarChartAccessData = this.payableDashboardPageAccessData?.sectionData[2];
            //details
            this.payableClaimsDetailsChartAccessData = this.payableDashboardPageAccessData?.sectionData[3];
            //vertical
            this.payableVerticalBarChartAccessData = this.payableDashboardPageAccessData?.sectionData[4];
            //stacked
            this.payableHorizontalStackedBarChartAccessData = this.payableDashboardPageAccessData?.sectionData[5];
          }
        }
        this.getCurrencyList();
      }
    });
  }

  onCurrencyChange(currencyId: number): void {
    this.dashboardChartService.currencyValueChangeEvent.emit(currencyId);
  }

  getReceivablePrivilege(){
    this.appService.getPrivilegeForPage(this.receivablePageId).subscribe((res: any)=>{
      this.receivablePageInfo = res.content;
      this.getReceivablePageInfo(this.receivablePageId);
    });
  }

  getPayablePrivilege(){
    this.appService.getPrivilegeForPage(this.payablePageId).subscribe((res: any)=>{
      this.payablePageInfo = res.content;
      this.getPayablePageInfo(this.payablePageId);
    });
  }

  getReceivablePageInfo(pageID: number): boolean{
    const pageValue = this.receivablePageInfo && (this.receivablePageInfo.length === 0 || this.receivablePageInfo.find((element: any) => element.pageId === pageID));
    return pageValue;
  }

  getPayablePageInfo(pageID: number): boolean{
    const pageValue = this.payablePageInfo && (this.payablePageInfo.length === 0 || this.payablePageInfo.find((element: any) => element.pageId === pageID));
    return pageValue;
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    const pageInfo = !this.isReceivableDashboard ? this.receivablePageInfo : this.payablePageInfo;
    if(pageInfo && pageInfo.length > 0) {
      const privillege = pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege ? privillege.isEnabled : false;;
    }
    return isEnabled;
  }

  checkUserIsAdmin(){
    return this.adminService.isAssociationUser();
  }

  checkUserIsAdminForReportLoss(){
    return !this.adminService.isAssociationUser();
  }

  setToggleChange(isReceivable: boolean): void {
    this.isReceivableDashboard = isReceivable;
    if(this.isReceivableDashboard) {
      if(!this.payablePageInfo ){
        this. getPayablePrivilege();
       }
      this.privilegeName = appConst.PAGE_NAME.DASHBOARD.RECEIVABLE_DASHBOARD.BUTTON_ACCESS.QUICKLINKS;
    } else {
      this.privilegeName = appConst.PAGE_NAME.DASHBOARD.PAYABLE_DASHBOARD.BUTTON_ACCESS.QUICKLINKS;
    }
  }

  getMenuHeader(pageName: string): boolean{
    const menuHeader = this.menuHeaderList?.find((element) => element.menuName === pageName);
    return menuHeader;
  }

  getMenuItems(){
    this.appService.getMenubyRole().subscribe((res: any)=>{
      this.menuHeaderList = res.content;
    });
  }

  isBarChartEnabled(): boolean {
    return (!this.isReceivableDashboard && this.receivableBarChartAccessData?.isView) ||
      (this.isReceivableDashboard && this.payableBarChartAccessData?.isView);
  }

  isPieChartEnabled(): boolean {
    return (!this.isReceivableDashboard && this.receivablePieChartAccessData?.isView) ||
      (this.isReceivableDashboard && this.payablePieChartAccessData?.isView);
  }

  isHorizontalBarChartEnabled(): boolean {
    return (!this.isReceivableDashboard && this.receivableHorizontalBarChartAccessData?.isView) ||
      (this.isReceivableDashboard && this.payableHorizontalBarChartAccessData?.isView);
  }

  isClaimDetailsEnabled(): boolean {
    return (!this.isReceivableDashboard && this.receivableClaimsDetailsChartAccessData?.isView) ||
      (this.isReceivableDashboard && this.payableClaimsDetailsChartAccessData?.isView);
  }

  isVerticalBarChartEnabled(): boolean {
    return (!this.isReceivableDashboard && this.receivableVerticalBarChartAccessData?.isView) ||
      (this.isReceivableDashboard && this.payableVerticalBarChartAccessData?.isView);
  }

  isHorizontalStackedBarChartEnabled(): boolean {
    return (!this.isReceivableDashboard && this.receivableHorizontalStackedBarChartAccessData?.isView) ||
      (this.isReceivableDashboard && this.payableHorizontalStackedBarChartAccessData?.isView);
  }

  redirectToGarage(index:any){
   // sessionStorage.setItem('activeIndex', index);
  }


}
export class InsuredAndTpArray{
  insurenceCompanyNames:string[];
  tpCompanyNames:string[];

}
