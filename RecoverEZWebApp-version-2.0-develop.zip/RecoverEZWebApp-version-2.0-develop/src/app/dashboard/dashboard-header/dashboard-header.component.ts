import { ReceivableService } from 'src/app/service/receivable.service';
import { MatDialog } from '@angular/material/dialog';
/* eslint-disable prefer-const */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { Subscription, zip } from 'rxjs';
import { ErrorHandlerDirective } from 'src/app/common/directives/errorHandler.directive';
import { DashboardNotificDetailsService } from 'src/app/service/dashboard-notific-details.service';
import { DashboardService } from 'src/app/service/dashboard.service';
import {  FormGroup, FormBuilder, Validators } from '@angular/forms';
import {MatAutocompleteSelectedEvent} from '@angular/material/autocomplete';
import { DashboardChartService } from 'src/app/service/dashboard-chart.service';
import { AdminService } from 'src/app/service/admin.service';
import { AppService } from 'src/app/service/role access/service/app.service';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { DropDownOptionDto } from 'src/app/models/dropdown-option-dto';
import { ReportLossService } from 'src/app/service/report-loss.service';

@Component({
  selector: 'app-dashboard-header',
  templateUrl: './dashboard-header.component.html',
  styleUrls: ['./dashboard-header.component.scss']
})
export class DashboardHeaderComponent implements OnInit {

  @Output() filterCompanyList = new EventEmitter<InsuredAndTpArray>();
  @Output() isReceivableToggle = new EventEmitter<boolean>();
  @Output() selectedCurrencyChanged = new EventEmitter<number>();

  @Input() receivableContent: any;
  @Input() payableContent: any;
  @Input() currencyOptionList: DropDownOptionDto[] = [];
  @Input() selectedCurrencyId = -1;

  receivable_data:any;
  payable_data:any;
  CountSubscribtion: Subscription;
  DashboardSubscription:Subscription;
  state=false;
  state1=false;
  @Output() showPayableTab =  new EventEmitter<boolean>();
  insuredAndTpData: InsuredAndTpArray = new InsuredAndTpArray();

  ngOnInit(): void {
    const Emptylist:InsuredAndTpArray = new InsuredAndTpArray();

    Emptylist.insurenceCompanyNames = []
    Emptylist.tpCompanyNames = []
    this.sendValues();
    // this.DashboardDetails(Emptylist);
    this.getPageAccessDetails();
  }


  /**
   * DASHBOARD DEATILS PAYABLE AND RECEIVABLE
   */

  DashboardDetails(companyList:InsuredAndTpArray){
    this.insuredAndTpData = companyList;
   this.DashboardSubscription = zip(
      this.DashboardNotificationService.getdashboardnotificationForReceivable(companyList, this.selectedCurrencyId),
      this.DashboardNotificationService.getdashboardnotificationForPayable(companyList, this.selectedCurrencyId)
    ).subscribe((res:any)=>{
     if(res){
      this.receivable_data = res[0].content;
      this.payable_data = res[1].content;
     }
    },(error:Response)=>{
      this.errorhandler.getMessage(error);
    })
  }
  /**
   * DESTROY SUBSCRIPTION
   */
  ngOnDestroy(){
    if(this.DashboardSubscription){
      this.DashboardSubscription.unsubscribe();
    }
  }
  isChecked(value:any): void {
    sessionStorage.setItem('toggleButtonStatus', value);
    const Emptylist:InsuredAndTpArray = new InsuredAndTpArray();
    Emptylist.insurenceCompanyNames = []
    Emptylist.tpCompanyNames = []

    if(this.isReceivableAccess && !this.isPayableAccess) {
      this.state = false;
    } else if(!this.isReceivableAccess && this.isPayableAccess) {
      this.state = true;
    } else {
      this.state = value;
    }
    this.isReceivableToggle.emit(this.state);
    this.DashboardDetails(Emptylist);
    this.showPopup = false;
    this.dasboardService.toggleTrueOrNot(!this.state);
    // this.dashboardchartService.toggleTrueOrNot(!this.state);
    this.InsuredCompany=[];
    this.TpCompany=[];
  }

  popUp(){
    this.showPopup = !this.showPopup;
  }

  checkUserIsAdmin(){
    return this.adminService.isAssociationUser();
  }

  showPopup = false;
  reportdata: FormGroup;

  InsuredCompany: string[] = [];
  TpCompany: string[] = [];

  totalInsuredCompany: string;
  totalTpCompany: string;

  selectedInsuredCompany: string[]=[];
  selectedTpCompany: string[]=[];

  separatorKeysCodes: number[];
  separatorKeysCodes1: number[];
  allCompanyName=[];
  allCompanyNameCopy=[];
  tpCompanyListDuplicate=[];
  allCompanyNameDuplicate=[];
  menuHeader:any;

  constructor(private appservice: AppService, private DashboardNotificationService :DashboardNotificDetailsService,private errorhandler: ErrorHandlerDirective,private dasboardService:DashboardService,
    public dialog: MatDialog, private formBuilder: FormBuilder,private company:ReceivableService,private dashboardchartService:DashboardChartService, private adminService: AdminService,
    private router: Router,private actiateRouter : ActivatedRoute,private translate: TranslateService, private reportlossservice:ReportLossService) {
    this.translate.use(sessionStorage.getItem('Language'));
    this.reportdata = this.formBuilder.group({
      selectedInsuredCompany: ["", [Validators.required]],
      selectedTpCompany: ["", [Validators.required]]
    });
    if(this.checkUserIsAdmin()){
      this.getCompanyNames();
    }
    if(sessionStorage.getItem("toggleButtonStatus")){
      this.state = (sessionStorage.getItem("toggleButtonStatus") == "true");
    }
    this.dasboardService.toggleTrueOrNot(this.state);
    this.dashboardchartService.currencyValueChangeEvent.subscribe((value: number) => {
      this.selectedCurrencyId = value;
      this.DashboardDetails(this.insuredAndTpData);
    });
  }
  
  onCurrencyChange(data): void {
    this.selectedCurrencyId = +data.target.value;
    this.selectedCurrencyChanged.emit(this.selectedCurrencyId);
  }

  getCompanyNames(){
    // this.company.getCompanyPayables().subscribe((response)=>{
    this.reportlossservice.getReportLossDetails().subscribe((response)=>{
      if (response) {
        response.forEach(element => {
          this.allCompanyName.push(element.name);
          this.allCompanyNameCopy.push(element.name);
          this.allCompanyNameDuplicate.push(element.name);
          this.tpCompanyListDuplicate.push(element.name);
        });
      }
    })
  }


  selectedInsuredName(event: MatAutocompleteSelectedEvent): void {
    // this.InsuredCompany.push(event.option.viewValue);
    if ((event.option.viewValue || '').trim()) {
      if(!this.InsuredCompany.includes(event.option.viewValue.trim())) {
        this.InsuredCompany.push(event.option.viewValue.trim());
      }
    }
    const index = this.allCompanyNameCopy.indexOf(event.option.viewValue.trim());
    if (index >= 0) {
      this.allCompanyNameCopy.splice(index, 1);
      this.tpCompanyListDuplicate = this.allCompanyNameCopy;
    }
    this.reportdata.controls['selectedInsuredCompany'].setValue(this.InsuredCompany);
    this.selectedInsuredCompany = this.InsuredCompany;
    this.totalInsuredCompany = this.InsuredCompany.length.toString();
  }

  removeInsuredName(ListName: string): void {
    const index = this.InsuredCompany.indexOf(ListName);
    if (index >= 0) {
      this.InsuredCompany.splice(index, 1);
    }
    this.allCompanyNameCopy.unshift(ListName);
    this.tpCompanyListDuplicate =  this.allCompanyNameCopy;
  }

  searchFunc(event){
    let filterValue =event.target.value.toLowerCase();
    if(filterValue != null && filterValue != undefined && filterValue !==""){
      let SearchList= this.allCompanyNameDuplicate.filter(data => data.toLowerCase().includes(filterValue));
      this.allCompanyName =SearchList;
    }else{
      this.allCompanyName = this.allCompanyNameDuplicate;
      filterValue='';
    }
  }

  search(event){
    let filterValue =event.target.value.toLowerCase();
    if(filterValue != null && filterValue != undefined && filterValue !==""){
      let SearchList= this.tpCompanyListDuplicate.filter(data => data.toLowerCase().includes(filterValue));
      this.allCompanyNameCopy =SearchList;
    }else{
      this.allCompanyNameCopy = this.tpCompanyListDuplicate;
      filterValue='';
    }
  }

  selectedTpName(event: MatAutocompleteSelectedEvent): void {
    // this.TpCompany.push(event.option.viewValue);
    if ((event.option.viewValue || '').trim()) {
      if(!this.TpCompany.includes(event.option.viewValue.trim())) {
        this.TpCompany.push(event.option.viewValue.trim());
      }

      const index = this.allCompanyNameDuplicate.indexOf(event.option.viewValue.trim());
      if (index >= 0) {
        this.allCompanyNameDuplicate.splice(index, 1);
        this.allCompanyNameCopy = this.allCompanyNameDuplicate;
      }
    }

    this.reportdata.controls['selectedTpCompany'].setValue(this.TpCompany);
    this.selectedTpCompany = this.TpCompany;
    this.totalTpCompany = this.TpCompany.length.toString();
  }

  removeTpName(ListName: string): void {
    const index = this.TpCompany.indexOf(ListName);
    if (index >= 0) {
      this.TpCompany.splice(index, 1);
    }

    this.allCompanyName.push(ListName);
    this.allCompanyNameDuplicate = this.allCompanyNameCopy;
  }

  sendValues(){
   const selectedCompany = new InsuredAndTpArray();
   selectedCompany.insurenceCompanyNames = this.selectedInsuredCompany;
   selectedCompany.tpCompanyNames = this.selectedTpCompany;
  //  if (this.reportdata.valid) {
    this.filterCompanyList.emit(selectedCompany);
    // console.log(selectedCompany);
    this.showPopup = false;

  //  }
  }
  callreceivableList(stage:string){ 
    this.company.setBackToRcvleCard_PayableCard(false);
    this.router.navigateByUrl("/receivable-list/recTable?stage="+stage+"&cur="+this.selectedCurrencyId);

  }
  callPayableList(stage:string){
    this.company.setBackToRcvleCard_PayableCard(false);
    this.showPayableTab.emit(true);
    this.router.navigateByUrl("/payable/Payable-table?stage="+stage+"&cur="+this.selectedCurrencyId);
  }

  isReceivableAccess:boolean;
  isPayableAccess:boolean;
  getPageAccessDetails(): void {
    this.isReceivableAccess=this.receivableContent?.isEnabled;
   // this.state = !this.isReceivableAccess;
    if (this.isReceivableAccess) {
      // this.isChecked(this.state);
    }

    this.isPayableAccess=this.payableContent?.isEnabled;
    this.state = this.state && this.isPayableAccess;
    if (this.isPayableAccess) {
      // this.isChecked(this.state);
    }

    this.isChecked(this.state);
  }
}

export class InsuredAndTpArray{
  insurenceCompanyNames:string[];
  tpCompanyNames:string[];
}
