import { FileUploadDialogComponent } from './receivable-list-card/receivable-bulk-history/file-upload-dialog/file-upload-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { BulkUploadService } from './../service/bulk-upload.service';
import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { appConst } from '../service/app.const';
import { ReceivableService } from '../service/receivable.service';
import { AppService } from '../service/role access/service/app.service';
import { ReceivableListCardComponent } from './receivable-list-card/receivable-list-card.component';
import { AdminService } from '../service/admin.service';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-receivable-list',
  templateUrl: './receivable-list.component.html',
  styleUrls: ['./receivable-list.component.scss']
})

export class ReceivableListComponent implements OnInit,OnDestroy{
  searchvalue:any;
  buttonDisable :boolean;
  backIcon:boolean;
  pageInfo: any;
  editclicked:boolean;
  closeIcon:boolean = false;
  public appConst = appConst;
  listPageId = appConst.PAGE_NAME.RECEIVABLE.RECEIVABLE_LIST.PAGEID;
  cardPageId = appConst.PAGE_NAME.RECEIVABLE.RECEIVABLE_CARD.PAGEID;
  downloadEnable: boolean;
  receivableList = new  ReceivableListDto();
  constructor(private route:Router,private router : ActivatedRoute,
    private receivable:ReceivableService,
    private appService : AppService,
    private bulkUploadService:BulkUploadService,
    private toastr:ToastrService,
    private adminService: AdminService,
    public dialog: MatDialog,
    private toaster:ToastrService,
    private translate: TranslateService
    ){
    this.receivable.getCheckbox().subscribe((value:boolean) => {
      if(value){
        this.buttonDisable=value;
      }else{
        this.redirectToReceivableCard();
        this.buttonDisable=value;
      }
    })
    this.getButtonSts();
    this.getCurrentUrl();
  }

  ngOnInit(): void {
    this.getPrivilege();
  }

  currentRoute: string;

  getCurrentUrl(){
    this.currentRoute = window.location.href;
    this.route.events.subscribe((event: any) => {
      if (event instanceof NavigationEnd) {
        this.currentRoute = event.url
      }
    });

  }

  checkUserIsAdmin(): boolean {
    return this.adminService.isAssociationUser()
  }

  onClick() {
    this.route.navigate(['recTable'],{
          relativeTo:this.router
    });
    sessionStorage.setItem('ViewReportLoss',"Receivable");
    this.backIcon=true;
    this.editclicked =false;
    this.downloadEnable=false;
    this.setButtonSts();
  }
 

  goBack() {
    this.searchvalue = '';
    this.closeIcon = false;
    this.editclicked = true;
    this.route.navigate(['recList'], {
      relativeTo: this.router
    });
    this.backIcon = false;
    this.downloadEnable = true;
    this.setButtonSts();
  }
  reportLoss(){
    this.route.navigateByUrl("report-loss");
    sessionStorage.setItem('ViewReportLoss',"Receivable");
  }
  search(){
    this.trimLeadingSpace();
    this.closeIcon=true;
    this.route.navigate([], { queryParams: {recSearchQuery: this.searchvalue }, queryParamsHandling: 'merge' })
  }

  removeValue(){
    this.searchvalue = '';
    this.closeIcon = false;
    this.route.navigate([], { queryParams: {recSearchQuery: this.searchvalue }, queryParamsHandling: 'merge' })
  }

  handleKeyup(event: KeyboardEvent) {
    if (event.key === 'Backspace' && this.searchvalue === '' && this.closeIcon) {
      this.closeIcon = false;
    }
  }

  trimLeadingSpace() {
    this.searchvalue = this.searchvalue.replace(/^\s+/g, '');
  }

  getPrivilege(){
    this.appService.getPrivilegeForPage(this.cardPageId).subscribe((res: any)=>{
      this.pageInfo = res.content;
      this.getPageInfo(this.cardPageId);
    });
  }

  getPageInfo(pageID: number): boolean{
    if(this.pageInfo){
    const pageValue = this.pageInfo && (this.pageInfo.length === 0 || this.pageInfo.find((element: any) => element.pageId === pageID));
    return pageValue.isEnabled;
  }
  return false;
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege ? privillege.isEnabled : false;
    }
    return isEnabled;
  }

  showHistoryTable = true;


  showUploadHistory(){
    if (this.showHistoryTable) {
      this.route.navigate(['bulkHistory'],{
        relativeTo:this.router
  });
  this.showHistoryTable = !this.showHistoryTable;

}else{
  this.route.navigate(['recList'],{
    relativeTo:this.router
});
  this.showHistoryTable = !this.showHistoryTable;
}
  }

  goBackToCard(){
    this.route.navigate(['recList'],{
      relativeTo:this.router
});
this.showHistoryTable = !this.showHistoryTable;

  }

  downloadSampleExcel(){
    this.bulkUploadService.downLoadSampleExcelFile().subscribe((response)=>{
      if (response) {
        this.toastr.success(this.translate.instant("Toaster_Message.sample_bulk_upload"));
        const blob = new Blob([response],
          { type: 'application/vnd.ms-excel' });
        const file = new File([blob], 'report.xlsx',
          { type: 'application/vnd.ms-excel' });
        const fileURL = URL.createObjectURL(file);
        const a         = document.createElement('a');
        a.href        = fileURL;
        a.target      = '_blank';
        a.download    = "Bulk-upload-sample-excel"+'.xlsx';
        document.body.appendChild(a);
        a.click();
      }
    })
  }

  openDialog() {
    const dialogRef = this.dialog.open(FileUploadDialogComponent,{disableClose: true });

    dialogRef.afterClosed().subscribe(result => {
      // console.log(`Dialog result: ${result}`);
    });
  }

  /**
   *Download Payable-List
   * @param value
   * @param downloadType
   */
   downloadReceivableList(){
    this.receivableList.list = JSON.parse(localStorage.getItem("companyId"));
    this.receivableList.limit = 0;
    this.receivableList.skip = 0;
    this.receivableList.stageName = null;
    this.receivable.exportReceivableListAsExcel( this.receivableList).subscribe((response:any)=>{
      if (response) {
        const blob = new Blob([response],
          { type: 'application/vnd.ms-excel' });
        const file = new File([blob], 'Receivable_List.xlsx',
          { type: 'application/vnd.ms-excel' });
        const fileURL = URL.createObjectURL(file);
        const a         = document.createElement('a');
        a.href        = fileURL;
        a.target      = '_blank';
        a.download    = "Receivable_List"+'.xlsx';
        document.body.appendChild(a);
        a.click();
        this.toaster.success(this.translate.instant("Toaster_Message.Receivable_list_download"));
      }
    });

}
   /**
   * RedirectToReceivableCard
   */
    private redirectToReceivableCard() {
      this.receivable.getBackToRcvleCard_PayableCard().subscribe((value: boolean) => {
        if (value) {
          this.goBack();
        }
      });
    }

    
  private getButtonSts() {
    this.backIcon = sessionStorage.getItem("backIcon") === "true";
    this.downloadEnable = sessionStorage.getItem("downloadEnable") === "true";
    this.editclicked = sessionStorage.getItem("editclicked") === "true";
  }

  private setButtonSts() {
    sessionStorage.setItem("backIcon", JSON.stringify(this.backIcon));
    sessionStorage.setItem("downloadEnable", JSON.stringify(this.downloadEnable));
    sessionStorage.setItem("editclicked", JSON.stringify(this.editclicked));
  }

  /**
   * Destroy
   */
    ngOnDestroy(): void {
      // sessionStorage.removeItem("backIcon");
      // sessionStorage.removeItem("downloadEnable");
      // sessionStorage.removeItem("editclicked");
    }
}
export class ReceivableListDto{
  list:string[];
  limit:number;
  skip:number;
  stageName:string
}
