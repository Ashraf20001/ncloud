import { PayableReceivableDto } from './../../models/payable-receivable-dto';
/* eslint-disable @typescript-eslint/no-inferrable-types */
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ReceivableService } from 'src/app/service/receivable.service';
import { AppService } from 'src/app/service/role access/service/app.service';
import { appConst } from 'src/app/service/app.const';
import { AccessMappingPageDto } from 'src/app/models/user-role-management/access-Mapping-PageDto ';

@Component({
  selector: 'app-receivable-list-card',
  templateUrl: './receivable-list-card.component.html',
  styleUrls: ['./receivable-list-card.component.scss']
})

export class ReceivableListCardComponent implements OnInit{
  allCompanies:PayableReceivableDto;
  cardDetails:any[];
  searchvalue: string;
  cardCompanyIdList = [];
  completedCheck= [];
  searchList;
  companyList:string[]= [];
  completed:boolean=false;
  allComplete: boolean = false;
  showCard: boolean = true;

  showHistoryTable = false;

  pageInfo: any;
  public appConst = appConst;
  pageId= appConst.PAGE_NAME.RECEIVABLE.RECEIVABLE_CARD.PAGEID;
  receivableCardPageAccessDto: AccessMappingPageDto;
  isCardEnabled = true;
  dataNotFound: boolean;

  constructor(private receiveService: ReceivableService, private route: ActivatedRoute, private router: Router, private appService : AppService) {
    this.route.queryParams.subscribe((queryParams: any) => {
      this.searchvalue = queryParams['recSearchQuery'];
      this.searchvalue = queryParams['recSearchQuery'];
       if(this.searchvalue === undefined || this.searchvalue === null || this.searchvalue ===""){
        this.showCard=true;
       }else{
        this.showCard=false;
       }
       this.filter(this.searchvalue);
    });

  }
  filter(searchvalue: string) {
    if(searchvalue !== undefined){
      this.searchList = this.cardDetails.filter((m) => String(m.companyName.toUpperCase()).includes(searchvalue.toUpperCase()));
      this.dataNotFound = true;
      if(this.searchList.length > 0){
        this.dataNotFound = false;
      }
    }
  }
  ngOnInit() {
    this.getPageAccessData();
  }

  doProcess(): void {
    this.getPrivilege();
    this.receiveService.setCheckbox(false);
    this.receiveService.getCompanyReceivables().subscribe(response => {
      this.searchList = response;
      this.isCardEnabled=false;
      this.dataNotFound = true;
      if(this.searchList.length > 0){
        this.dataNotFound = false;
        this.isCardEnabled = true ;
      }
      this.cardDetails = response;
      this.allCompanies=response[0];
    });
    // this.receiveService.getAllReceivables().subscribe(response => {
    //   this.allCompanies=response;
    // });
  }

  getReceivable(companyId, event, i :number) {
    this.CheckCheckBox(event.checked,companyId);
  }


  CheckCheckBox(check:boolean, companyId){
    const index = this.companyList.indexOf(companyId);
    if(check == true){
      this.companyList.push(companyId);
      this.passCompanyId(this.companyList);
    } else if(index == -1){
      const indexValue = this.cardCompanyIdList.indexOf(companyId);
      this.cardCompanyIdList.splice(indexValue , 1);
      this.allComplete = false;
      this.passCompanyId(this.cardCompanyIdList);
    }
    else{
      this.companyList.splice(index , 1);
      this.allComplete = false;
      this.passCompanyId(this.companyList);
    }
    if(this.companyList.length==0 && this.cardCompanyIdList.length==0){
      this.receiveService.setCheckbox(false);
    }

    else{
      this.receiveService.setCheckbox(true);
    }
  }

  passCompanyId(CompanyId:any){
    const arr = JSON.stringify(CompanyId);
    localStorage.setItem("companyId", arr);
  }

  AllCompanys(completed: boolean){
    if(completed == true){
      this.completedCheck =[];
      this.receiveService.setCheckbox(true);
      this.companyList=[];
      this.passCompanyId(this.companyList);
      this.cardCompanyIdList=[];
      for(let i=0;i< this.cardDetails.length; i++){
        this.cardCompanyIdList.push(this.cardDetails[i].companyId);
        this.completedCheck.push(completed);
      }
    }else{
      this.receiveService.setCheckbox(false);
      this.completedCheck =[];
      this.cardCompanyIdList=[];
      this.allComplete = completed;
    }

  }


  getPrivilege(){
    this.appService.getPrivilegeForPage(this.pageId).subscribe((res: any)=>{
      this.pageInfo = res.content;
      this.getPageInfo(this.pageId);
    });
  }

  getPageInfo(pageID: number): boolean{
    const pageValue = this.pageInfo && (this.pageInfo.length === 0 || this.pageInfo.find((element: any) => element.pageId === pageID));
    return pageValue;
  }

  getPageAccessData(): void {
    this.appService.getPageAccess(appConst.PAGE_NAME.RECEIVABLE.RECEIVABLE_CARD.PAGE_IDENTITY).subscribe((response: any) => {
      this.receivableCardPageAccessDto = response.content;
      this.isCardEnabled = this.receivableCardPageAccessDto.isEnabled;
      if(this.isCardEnabled) {
        this.doProcess();
      }
    });
  }
}
