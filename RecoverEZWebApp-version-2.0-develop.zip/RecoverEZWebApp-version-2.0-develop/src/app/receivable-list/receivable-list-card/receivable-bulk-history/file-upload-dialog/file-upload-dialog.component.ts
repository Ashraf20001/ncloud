import { ToastrService } from 'ngx-toastr';
import { BulkUploadService } from './../../../../service/bulk-upload.service';
import { Component, ElementRef, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ReceivableBulkHistoryComponent } from '../receivable-bulk-history.component';
import { ReportLossStatus } from 'src/app/common/enum/enum';
import { Inject } from '@angular/core';
import { TotalrecordsPopupComponent } from '../totalrecords-popup/totalrecords-popup.component';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-file-upload-dialog',
  templateUrl: './file-upload-dialog.component.html',
  styleUrls: ['./file-upload-dialog.component.scss']
})
export class FileUploadDialogComponent {
  @ViewChild('fileDropRef') hiddenInput: ElementRef;
  fileName = 'Drag and drop file or';
  fileType:any;
  public uplodaHistorydialog: MatDialogRef<ReceivableBulkHistoryComponent>
  isOpened: boolean = true;
  isUploadFile: boolean;
  constructor(private bulkUploadService:BulkUploadService,private toastr:ToastrService,public dialog: MatDialog, @Inject(MAT_DIALOG_DATA) public data: any, private translate:TranslateService){}

  file: File = null; // Variable to store file

  filemap = new Map<string,string>([
    [ "pdf", "assets/file/pdf.svg" ],
    [ "xlsx", "assets/file/xlsx.svg" ],
    [ "xls", "assets/file/xls.svg" ],
    [ "doc", "assets/file/doc.svg" ],
     [ "docx", "assets/file/docx.svg" ],
     [ "img", "assets/file/img.svg" ],
     [ "jpeg", "assets/file/jpeg.svg"],
     [ "jpg", "assets/file/jpg.svg" ],
     [ "png", "assets/file/png.svg"],
     [ "svg", "assets/file/svg.svg"]
]);

  // On file Select
  onChange(event) {
    if(event.target.files.length >=1){
    this.isUploadFile =true;
    this.file = event.target.files[0];
    this.fileName = this.file.name;
    const str = this.fileName.split(".");      // Split the string using dot as separator
    const filename = str.pop();
    for (const key of this.filemap.keys()) {
      if(key===filename){
        this.fileType=this.filemap.get(key).toString();
      }

    }
    if(this.fileType===null||this.fileType===undefined){
      this.fileType="assets/file/file.svg";
    }
  }
  this.hiddenInput.nativeElement.value = null;
  this.hiddenInput.nativeElement.click();
}

  // OnClick of button Upload
  onUpload() {
  this.bulkUploadService.bulkUpload(this.file).subscribe((response)=>{
      if (response['content']) {
        this.toastr.success(this.translate.instant("Toaster_Message.File_in_progress"));
        const dialogRef = this.dialog.open(TotalrecordsPopupComponent,{
          data: {
            isShowReUpload : false,
          uploadId: response['content'].uploadId,
          totalCount : response['content'].totalCount,
        successCount :  response['content'].successCount,
        failureCount: response['content'].failureCount,
        showUploadedMsg: true
          },
          disableClose: true 
        });

    dialogRef.afterClosed().subscribe(result => {
          // console.log(`Dialog result: ${result}`);
        });
      }
    });
  }
  /*
   * click exit button
   */
onExit(){
    this.dialog.closeAll();
  }

  /*
   * click cancel button
   */
onCancel(){
    this.dialog.closeAll();
  }
  /*
   * on Click Upload History
   */
onClickUploadHistory(){
    const dialogRef = this.dialog.open(ReceivableBulkHistoryComponent,{
      data :this.isOpened,
      // height: '569px',
      width: '1561px',
      // height:'84%', 
      maxWidth: '91.5vw',
      disableClose: true 
    });
    dialogRef.afterClosed().subscribe(result => {
      // console.log(`Dialog result: ${result}`);
    });
  }
  /**
   * Download reportLoss File
   */
  downloadRepostLessFile() {
    this.bulkUploadService.downLoadSampleExcelFile().subscribe((response) => {
      if (response) {
        this.toastr.success(this.translate.instant("Toaster_Message.sample_bulk_upload"));
        const blob = new Blob([response], { type: 'application/vnd.ms-excel' });
        const file = new File([blob], 'report.xlsx', {
          type: 'application/vnd.ms-excel',
        });
        const fileURL = URL.createObjectURL(file);
        const a = document.createElement('a');
        a.href = fileURL;
        a.target = '_blank';
        a.download = 'Bulk-upload-sample-excel' + '.xlsx';
        document.body.appendChild(a);
        a.click();
      }
    });
  }
   /**
   *  FILE DOWLOAD ONLY DRAFT STATUS
   */
  downloadDraftFile() {
    if (this.data.status === ReportLossStatus.draft || this.data.status === null) {
      return true;
    }
    return false;
  }
  DeleteFile(){
    this.file=null;
    this.isUploadFile=false;
    this.fileName = "";
    // this.fileType=[];
  }
}
