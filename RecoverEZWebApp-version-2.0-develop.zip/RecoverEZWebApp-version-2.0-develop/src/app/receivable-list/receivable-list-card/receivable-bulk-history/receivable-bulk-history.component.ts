import { ToastrService } from 'ngx-toastr';
import { BulkUploadService, ErrorHistory } from './../../../service/bulk-upload.service';
import { CompanyId } from './../../receivable-list-table/receivable-list-table.component';
import { ActivatedRoute, Router } from '@angular/router';
import { ReceivableService, ClaimTable } from 'src/app/service/receivable.service';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Component, Inject, ViewChild } from '@angular/core';
import { AppService } from 'src/app/service/role access/service/app.service';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { PopupComponent } from 'src/app/common/components/popup/popup.component';
import { appConst } from 'src/app/service/app.const';
import { TotalrecordsPopupComponent } from './totalrecords-popup/totalrecords-popup.component';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-receivable-bulk-history',
  templateUrl: './receivable-bulk-history.component.html',
  styleUrls: ['./receivable-bulk-history.component.scss']
})
export class ReceivableBulkHistoryComponent {
  displayedColumns: string[] = ['Upload Id', 'Date','Total Count' ,'Success Count', 'Failure Count','Status','Uploaded By','view'];
  dataSource :MatTableDataSource<BulkUploadHistory>;
  searchvalue:string;
  @ViewChild(MatPaginator,{ static: true }) paginator: MatPaginator;
  @ViewChild(MatPaginator) page:MatPaginator;
  element;
  companyId = new CompanyId();
  elements:BulkUploadHistory[]=[];
   ZERO=0;
   TEN=10;
  searchList;
  totalLength: any;
  tableList:any;
  showtabledata: []=[];

  pageInfo: any;
  public appConst = appConst;
  pageIds= appConst.PAGE_NAME.RECEIVABLE.RECEIVABLE_LIST.PAGEID;

  errorHistory:ErrorHistory[];

  uploadId:number;
  successCount:number;
  failureCount:number;
  totalCount:number;
  status:string;
  pageId:number;
  createdBy:string;
  createdDate:string;
  identity:string;
  public dialogPopUp: MatDialogRef<ReceivableBulkHistoryComponent>;

  constructor(private paginatorName: MatPaginatorIntl,private toastr:ToastrService,private route:ActivatedRoute,private router:Router,private dialog:MatDialog, 
    private appService : AppService,private bulkUploadService:BulkUploadService,@Inject(MAT_DIALOG_DATA) public data: any, private translate:TranslateService){
    this.paginatorName.itemsPerPageLabel = this.translate.instant("paginator.rowsPerPage");
    this.companyId.list= JSON.parse(localStorage.getItem("companyId"));
    this.bulkUploadHistory();
    this.route.queryParams.subscribe((queryParams: any) => {
      this.searchvalue = queryParams['recSearchQuery'];
      this.dataSource.filter = this.searchvalue.trim().toLowerCase();
      if (this.dataSource.paginator) {
        this.dataSource.paginator.firstPage();
      }
    });
    localStorage.removeItem("companyId");
  }
  ngOnInit(): void {
    this.getPrivilege();
    this.paginatorName.itemsPerPageLabel = this.translate.instant("paginator.rowsPerPage");
    this.translate.onLangChange.subscribe(() => {
      this.paginatorName.itemsPerPageLabel = this.translate.instant("paginator.rowsPerPage");
    });
  }

  bulkUploadHistory() {
    this.bulkUploadService.getErrorHistory().subscribe((response)=>{
      if (response) {
        this.errorHistory = response['content'];

        this.tableList=response['content'];
        this.showtabledata= this.tableList.slice(this.ZERO, this.TEN);
        this.dataSource=new MatTableDataSource(this.showtabledata);
        this.totalLength = response.content.length;
      }
    })
  }
  EndValue:any;
  startsWith:any;
  changePage(event){
    this.showtabledata= this.tableList.slice(this.tableList,event.pageSize);
    if(event.pageIndex != this.ZERO){
       this.EndValue= event.pageSize+(event.pageSize *event.pageIndex );
      this.startsWith = event.pageSize *event.pageIndex;
      this.showtabledata= this.tableList.slice(this.startsWith,this.EndValue );
    }else{
      this.showtabledata= this.tableList.slice(event.pageIndex,event.pageSize );
    }

    this.dataSource=new MatTableDataSource(this.showtabledata);
  }

  editFunc(value:any){
    this.router.navigate(['report-loss/'], { queryParams: { claimId: value.claimId } })
  }
  Delete(claimId:string){
    const dialogRef = this.dialog.open(PopupComponent, {
      width: '30%',
   height:'20%',
      data: {
       message: "Are you sure you want to delete?",
        okButton: "Ok",
         cancelButton: "Cancel"
       }
    });
   dialogRef.afterClosed().subscribe(result => {
      if (result) {

      }
    });
    return false;
  }

  getPrivilege(){
    this.appService.getPrivilegeForPage(this.pageIds).subscribe((res: any)=>{
      this.pageInfo = res.content;
      this.getPageInfo(this.pageIds);
    });
  }

  getPageInfo(pageID: number): boolean{
    const pageValue = this.pageInfo && (this.pageInfo.length === 0 || this.pageInfo.find((element: any) => element.pageId === pageID));
    return pageValue;
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege ? privillege.isEnabled : false;
    }
    return isEnabled;
  }

  reload() {
    this.bulkUploadHistory();
  }
  /*
   * On Click Close Button
   */
  onExit() {
    if(this.data){
      this.dialogPopUp.close();
    }
    this.dialog.closeAll();
  }
   /*
   *  Total Records PopUp
   */
  report_popup(data: any) {
    const dialogRef = this.dialog.open(TotalrecordsPopupComponent, {
      width: '2300px',
      // height: '569px',
      maxWidth:'91.5vw',
      data: {
        isShowReUpload : true,
        uploadId:data.uploadId,
        totalCount :data.totalCount,
        successCount : data.successCount,
        failureCount:data.failureCount
      },
      disableClose: true 
    });

        dialogRef.afterClosed().subscribe((data:any) => {
          this.bulkUploadHistory();
    });

  }
}
export class BulkUploadHistory{
  uploadId:number;
  successCount:number;
  failureCount:number;
  totalCount:number;
  status:string;
  identity:string;
  storageId:FileStorageDetails;
}

export class FileStorageDetails{
  url:string;
  uploadType:string;
  reportType:string;
  storageType:string;
  referenceId:number;
}
