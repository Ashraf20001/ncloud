import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReceivableBulkHistoryComponent } from './receivable-bulk-history.component';

describe('ReceivableBulkHistoryComponent', () => {
  let component: ReceivableBulkHistoryComponent;
  let fixture: ComponentFixture<ReceivableBulkHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReceivableBulkHistoryComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ReceivableBulkHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
