import { Component, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ViewChild } from '@angular/core';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { BulkUploadService } from 'src/app/service/bulk-upload.service';
import { Inject } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Subject, Subscription, debounceTime } from 'rxjs';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { TranslateService } from '@ngx-translate/core';
import { BulkImportFieldMapDTO } from 'src/app/models/report-loss-dto/bulk-import-field-map-dto';

@Component({
  selector: 'app-totalrecords-popup',
  templateUrl: './totalrecords-popup.component.html',
  styleUrls: ['./totalrecords-popup.component.scss'],
})
export class TotalrecordsPopupComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  totalRecordList: any;
  dataSource = new MatTableDataSource<BulkImportTempDataDto>();
  fieldMapList: BulkImportFieldMapDTO[] = [];
  displayedColumns: string[] = [];
  totalLength: number;
  pageIndex: number = 1;
  failureCount: number;
  successCount: number;
  totalCount: number;
  intervalId1: any;
  intervalId2: any;
  isViewErrorPage = true;
  progress:string;
  private subscription: Subscription;
  ZERO = 0;
  SEVEN = 7;
  currentPageIndex: number;
  customPageIndex: number = 0;
  endingIndex: number = 10;
  dataNotFound: boolean;
  sortingDto = new SortingDto()
  ascOrDeasc: boolean = false;
  columnName: string;
  pageChangedEvent = new Subject<number>();
  success: boolean;
  isUploadFile :boolean;
  isShowReuploadDiv= true;
  showUploadedMsg = false;

  constructor(
    public dialog: MatDialogRef<TotalrecordsPopupComponent>,
    private dialodPopUp :MatDialog,
    private router: Router,
    private bulkUploadService: BulkUploadService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private toaster: ToastrService,
    private ngxLoader: NgxUiLoaderService,
    private translate: TranslateService,
    private paginatorName: MatPaginatorIntl,private toastr:ToastrService
  ) {
    this.isShowReuploadDiv = this.data.isShowReUpload;
    this.showUploadedMsg = this.data.showUploadedMsg;
    if (paginatorName) {
      this.translateLabels(paginatorName);
    }
    this.translate.onLangChange.subscribe(() => {
      this.translateLabels(paginatorName);
    });
  }

  ngOnInit(): void {
    this.ngxLoader.start();
    this.sortingDto.limit = this.ZERO;
    this.sortingDto.skip = this.SEVEN;
    this.getFieldMapList();
    this.getBuloadTableList();
    this.pageChangedEvent.pipe(debounceTime(300)).subscribe((data: number) => {
      this.changePageIndex();
    });
  }

  private getFieldMapList(): void {
    this.bulkUploadService.getBulkImportFieldMapList().subscribe((response: BulkImportFieldMapDTO[]) => {
      this.fieldMapList = response;
      if(this.fieldMapList && this.fieldMapList.length > 0) {
        this.displayedColumns = this.fieldMapList.map((value: BulkImportFieldMapDTO) => value.bulkImportFieldName);
        this.displayedColumns.unshift('index');
      }
    });
  }

  private getBuloadTableList() {
    if (this.isViewErrorPage) {
      this.getBulkUploadErorDataInTableList();
    } else {
      this.getBulkUploadSuccessDataInTableList();
    }
  }

  /*
   * Get BulkUploadErorData TableList
   */
  getBulkUploadErorDataInTableList() {
    this.success=false;
    clearInterval(this.intervalId2);
    this.getBulkUploadErrorDataMtd();
    this.intervalId1 = setInterval(() => {
      this.getBulkUploadErrorDataMtd();
    }, 5000);
    this.isViewErrorPage = true;
  }
  getBulkUploadErrorDataMtd() {
    this.bulkUploadService.getBulkUploadErrorData(this.data.uploadId, this.sortingDto).subscribe((res) => {
      if (res['content']) {
        this.dataNotFound = false;
        this.failureCount = res['content'].bulkImportHistoryDto.failureCount;
        this.successCount = res['content'].bulkImportHistoryDto.successCount;
        this.progress = res['content'].bulkImportHistoryDto.status;
        this.totalCount = res['content'].bulkImportHistoryDto.totalCount;
        this.totalRecordList = res['content'].bulkImportTempDataDtoList;
        if (res['content'].bulkImportHistoryDto.status === "COMPLETED"
          || res['content'].bulkImportHistoryDto.status === "FAILED"
          || res['content'].bulkImportHistoryDto.status === "No Data") {
          clearInterval(this.intervalId1);
          if(this.showUploadedMsg) {
            this.toastr.success(this.translate.instant("Toaster_Message.file_uploaded"));
            this.showUploadedMsg = false;
          }
          this.ngxLoader.stop();
        }
        this.dataSource = new MatTableDataSource<BulkImportTempDataDto>(
          this.totalRecordList
        );
        this.totalLength = this.failureCount;
        if (this.totalRecordList.length != 0) {
          this.dataNotFound = false;
        } else {
          this.dataNotFound = true;
        }
      } else {
        this.dataNotFound = true;
      }
        });
  }

  /*
   * Get BulkUploadErorData TableList
   */
  getBulkUploadSuccessDataInTableList() {
    this.success=true;
    clearInterval(this.intervalId1);
    this.getBulkUploadSuccessDataMtd();
    this.intervalId2 = setInterval(() => {
      this.getBulkUploadSuccessDataMtd();
    }, 5000);
    this.isViewErrorPage = false;
  }
  getBulkUploadSuccessDataMtd() {
    this.bulkUploadService.getBulkUploadSuccessData(this.data.uploadId, this.sortingDto).subscribe((res) => {
      if (res['content']) {
        this.dataNotFound = false;
        this.failureCount = res['content'].bulkImportHistoryDto.failureCount;
        this.successCount = res['content'].bulkImportHistoryDto.successCount;
        this.progress = res['content'].bulkImportHistoryDto.status;
        this.totalCount = res['content'].bulkImportHistoryDto.totalCount;
        this.totalRecordList = res['content'].bulkImportTempDataDtoList;
        if (res['content'].bulkImportHistoryDto.status === "COMPLETED"
          || res['content'].bulkImportHistoryDto.status === "FAILED") {
          clearInterval(this.intervalId2);
          if(this.showUploadedMsg) {
            this.toastr.success(this.translate.instant("Toaster_Message.file_uploaded"));
            this.showUploadedMsg = false;
          }
          this.ngxLoader.stop();
        }
        this.dataSource = new MatTableDataSource<BulkImportTempDataDto>(this.totalRecordList);
        this.totalLength = this.successCount;
        if (this.totalRecordList.length != 0) {
          this.dataNotFound = false;
        } else {
          this.dataNotFound = true;
        }
      } else {
        this.dataNotFound = true;
      }
        });
  }

  getColor(fieldName:string, description:string){
    const isRed = description.includes(fieldName) || description.includes("Duplicate Row");
    return isRed;
  }

  /*
   *  Destroy
   */
  ngOnDestroy(): void {
    clearInterval(this.intervalId1);
    clearInterval(this.intervalId2);
    this.subscription?.unsubscribe();
  }

  /*
   * Delete Error Data
   */
  deleteErrorData(data:any){
    let uploadIdentity :string = data.identity;
    this.bulkUploadService.deleteErrorData(uploadIdentity).subscribe(res =>{
      if(res){
        this.getBuloadTableList();
      }
    })
  }

  /*
   * Download Error Data
   */
  downloadErrorData() {
    this.bulkUploadService
      .getErrorDataExcel(this.data.uploadId, !this.isViewErrorPage)
      .subscribe((response) => {
        if (response) {
          const blob = new Blob([response], {
            type: 'application/vnd.ms-excel',
          });
          const file = new File([blob], 'Error_History.xlsx', {
            type: 'application/vnd.ms-excel',
          });
          const fileURL = URL.createObjectURL(file);
          const a = document.createElement('a');
          a.href = fileURL;
          a.target = '_blank';
          a.download = 'Error_History' + '.xlsx';
          document.body.appendChild(a);
          a.click();
          this.toaster.success(this.translate.instant("Toaster_Message.Error_data_download"));
        }
      });
  }


  changePage(event){
    if(event.pageIndex > event.previousPageIndex ){
      //previous
      this.customPageIndex = event.pageIndex+1;
    }else{
      // next
      this.customPageIndex =  this.customPageIndex-1;
    }
    if (event.pageIndex != this.ZERO) {
      this.sortingDto.skip = event.pageSize;
      this.sortingDto.limit = event.pageSize * event.pageIndex;
      this.endingIndex = event.pageSize;
      this.pageIndex = this.customPageIndex;
    } else {
      this.sortingDto.skip = event.pageSize;
      this.sortingDto.limit = event.pageIndex;
      this.endingIndex = event.pageSize;
      this.pageIndex = event.pageIndex + 1;
    }
    this.getBuloadTableList();
  }

  pageindex(): void {
    this.pageChangedEvent.next(this.pageIndex);
  }

  changePageIndex(): void {
    if (this.pageIndex > 0) {
      const totalPageIndex = this.totalLength / this.endingIndex + 1;
      if(this.pageIndex > totalPageIndex) {
        this.pageIndex = this.customPageIndex === 0 ? 1 : this.customPageIndex;
        return;
      }
      this.customPageIndex = this.pageIndex;
      this.currentPageIndex = this.pageIndex - 1;
      this.sortingDto.skip = this.endingIndex;
      this.sortingDto.limit = this.endingIndex * this.currentPageIndex;
      this.getBuloadTableList();
    }
  }

  onKeyDown(event: KeyboardEvent) {
    if (event.keyCode === 190) {
      event.preventDefault();
    }
  }

  columnSorting(data: string) {
    if (this.columnName === data) {
      this.columnName = '';
      this.ascOrDeasc = true;
    } else {
      this.ascOrDeasc = false;
      this.columnName = data;
    }
    this.sortingDto.isAscending = this.ascOrDeasc;
    this.sortingDto.columnName = data;
    this.getBuloadTableList();
  }

  ngAfterViewInit() {
    if (this.dataSource !== undefined && this.dataSource !== null) {
      this.dataSource.paginator = this.paginator;
    }
  }

  closeTab() {
    this.dialog.close('pis');
  }

  fileName: any;
  file: File=null;
  fileType: string;
  fullscreen=true;
  four = "col-12 col-sm-12 col-md-12 col-lg-4 col-xl-4 col-xxl-3 ";
  eight = "col-12 col-sm-12 col-md-12 col-lg-8 col-xl-8 col-xxl-9";

  filemap = new Map<string,string>([ [ "pdf", "/assets/file/pdf.svg" ], [ "xlsx", "/assets/file/xlsx.svg" ], [ "xls", "/assets/file/xls.svg" ], [ "doc", "/assets/file/doc.svg" ], [ "docx", "/assets/file/docx.svg" ], [ "img", "/assets/file/img.svg" ], [ "jpeg", "/assets/file/jpeg.svg"], [ "jpg", "/assets/file/jpg.svg" ], [ "png", "/assets/file/png.svg"], [ "svg", "/assets/file/svg.svg"] ]);
  // On file Select
  onChange(event) {
    if(event.target.files.length >=1){
    this.isUploadFile =true;
    this.file = event.target.files[0];
    this.fileName = this.file.name;
    const str = this.fileName.split(".");
    // Split the string using dot as separator
    const filename = str.pop();
    for (const key of this.filemap.keys()) {
      if (key === filename) {
        this.fileType = this.filemap.get(key).toString();
      }
    }
    if (this.fileType === null || this.fileType === undefined) {
      this.fileType = '/assets/file/file.svg';
    }
  }
}

  ocClickBack() {
    this.closeTab();
  }

  redirectToReportLoss(identity:string){
    this.dialodPopUp.closeAll()
    clearInterval(this.intervalId1);
    clearInterval(this.intervalId2);
    this.router.navigateByUrl('/receivable-list').then(() => {
      this.router.navigateByUrl('/report-loss?uploadIdentity='+identity);
    });
  }
  /*
   *  OnClick  uploadFile
   */
  onUpload(){

    this.bulkUploadService.bulkUpload(this.file).subscribe((response)=>{
      if (response) {
        this.toaster.success(this.translate.instant("Toaster_Message.File_uploaded"))
        this.closeTab();
      }
    });
  }

  onCancel(){
    this.closeTab();
  }

  scrollBar=true;
  fullscreenc() {
    this.fullscreen = !this.fullscreen;
    this.four = "";
    this.eight = "col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12";
    this.scrollBar=false;
  }
  not_fullscreenc() {
    this.fullscreen = !this.fullscreen;
    this.four = "col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3 col-xxl-3"
      ; this.eight = "col-12 col-sm-12 col-md-9 col-lg-9 col-xl-9 col-xxl-9";
    this.scrollBar=true;
  }
  DeleteFile(){
    this.file=null;
    this.isUploadFile=false;
  }

  translateLabels(paginatorName: MatPaginatorIntl) {
    paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    paginatorName.firstPageLabel = this.translate.instant('Paginator.FirstPage');
    paginatorName.lastPageLabel = this.translate.instant('Paginator.LastPage');
    paginatorName.nextPageLabel = this.translate.instant('Paginator.NextPage');
    paginatorName.previousPageLabel = this.translate.instant('Paginator.PreviousPage');
    this.translate.get('paginatorName').subscribe((labels) => {
      this.paginatorName = labels;
    });
  }
}

export class BulkImportTempDataDto {
  uploadId: number;
  status: boolean;
  errorDescription: string;
  inRegistrationNo: string;
  inMake: string;
  inModel: string;
  inPurchaseDate: Date;
  inSumInsured: number;
  tpName: string;
  tpPolicyNumber: string;
  tpClaimNo: string;
  tpRegistrationNo: string;
  tpRegistrationType: string;
  tpMake: string;
  tpModel: string;
  ldDateOfLoss: Date;
  ldClaimNumber: string;
  ldReportedDate: Date;
  ldPolicyNumber: string;
  ldReserveAmount: number;
  ldPoliceReportNumber: string;
  ldIsTotalLoss: boolean;
  garageName: string;
  garageLocation: string;
  garageContactDetails: string;
  garageType: string;
  garageInvoiceName: string;
  sdSurveyAllocationDate: string;
  sdSurveyDueDate: Date;
  sdSurveyReportName: string;
  srTotalLoss: boolean;
  srSpareParts: number;
  srLabourCost: number;
  srSurveyAmount: number;
  insurerName: number;
  identity:string;
  uploadDataId:number;
  createdBy:number;
  modifiedDate:Date;
  modifiedBy:number;
  createdDate:Date;
}
export class SortingDto {
  skip: number;
  limit: number;
  columnName: string;
  isAscending: boolean;
}
