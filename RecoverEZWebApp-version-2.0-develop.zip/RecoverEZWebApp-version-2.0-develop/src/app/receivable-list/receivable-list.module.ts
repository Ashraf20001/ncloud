import { DemoMaterialModule } from './../common/components/material-module';
import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { ReceivableListCardComponent } from "./receivable-list-card/receivable-list-card.component";
import { ReceivableListTableComponent } from "./receivable-list-table/receivable-list-table.component";
import { ReceivableListComponent } from "./receivable-list.component";
import { ReceivableListRoutingModule } from "./receivable-list-routing.module";
import {  TranslateModule } from '@ngx-translate/core';
import { ReceivableBulkHistoryComponent } from './receivable-list-card/receivable-bulk-history/receivable-bulk-history.component';
import { FileUploadDialogComponent } from './receivable-list-card/receivable-bulk-history/file-upload-dialog/file-upload-dialog.component';
import {MatDialogModule} from '@angular/material/dialog';
import { TotalrecordsPopupComponent } from './receivable-list-card/receivable-bulk-history/totalrecords-popup/totalrecords-popup.component';
@NgModule({
  declarations:[
    ReceivableListCardComponent,
    ReceivableListTableComponent,
    ReceivableListComponent,
    ReceivableBulkHistoryComponent,
    FileUploadDialogComponent,
    TotalrecordsPopupComponent,
  ],
  imports:[
    CommonModule,
    FormsModule,
    ReceivableListRoutingModule,
    TranslateModule,
    DemoMaterialModule,
    MatDialogModule

  ]
})

export class ReceivableListModule{

}
