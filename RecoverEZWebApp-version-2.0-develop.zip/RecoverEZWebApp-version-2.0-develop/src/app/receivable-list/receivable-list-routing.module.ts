import { ReceivableBulkHistoryComponent } from './receivable-list-card/receivable-bulk-history/receivable-bulk-history.component';
import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { ReceivableListCardComponent } from "./receivable-list-card/receivable-list-card.component";
import { ReceivableListTableComponent } from "./receivable-list-table/receivable-list-table.component";
import { ReceivableListComponent } from "./receivable-list.component";


const routes : Routes =  [
  {
    path: '', component: ReceivableListComponent,
    children : [
      {
        path: 'recList',  component: ReceivableListCardComponent
      },
      {
        path: 'recTable',  component: ReceivableListTableComponent
      },
      {
        path: 'bulkHistory',  component: ReceivableBulkHistoryComponent
      },
      {
        path: '',  redirectTo: 'recList', pathMatch: "full"
      },
    ]
  }
]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class ReceivableListRoutingModule { }
