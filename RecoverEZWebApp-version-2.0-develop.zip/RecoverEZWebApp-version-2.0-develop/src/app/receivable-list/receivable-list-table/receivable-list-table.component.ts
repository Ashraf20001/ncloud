import { HttpParams } from '@angular/common/http';
import { AfterViewInit, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { PopupComponent } from 'src/app/common/components/popup/popup.component';
import { appConst } from 'src/app/service/app.const';
import { ClaimTable, ReceivableService } from 'src/app/service/receivable.service';
import { AppService } from 'src/app/service/role access/service/app.service';
import { MatPaginatorIntl } from '@angular/material/paginator';
import { AdminService } from 'src/app/service/admin.service';
import { AccessMappingPageDto } from 'src/app/models/user-role-management/access-Mapping-PageDto ';
import { Q } from '@angular/cdk/keycodes';
import { Subject, Subscription, debounceTime } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-receivable-list-table',
  templateUrl: './receivable-list-table.component.html',
  styleUrls: ['./receivable-list-table.component.scss']
})

export class ReceivableListTableComponent implements OnInit,OnDestroy,AfterViewInit{
  displayedColumns: string[] = ['claim', 'insuredname','notatfault', 'atfault','totallossamount','date','stageandsection','status','edit','delete'];
  dataSource :MatTableDataSource<ClaimTable>;
  searchvalue:string;

  element;
  receivableVo = new CompanyId();
  elements:ClaimTable[]=[];
   ZERO=0;
   TEN=10;
  searchList;
  totalLength: any;
  tableList:any;
  showtabledata: []=[];
  dataNotFound=false;
  stageName:string;
  totalcount = new CompanyId();


  pageInfo: any;
  public appConst = appConst;
  pageId= appConst.PAGE_NAME.RECEIVABLE.RECEIVABLE_LIST.PAGEID;
  associateUser: boolean;
  isReceivableListEnabled = true;
  receivableListPageAccessDto: AccessMappingPageDto;
  endingIndex: number=10;
  private subscriptions = new Subscription();
  currentPageIndex: number;
  customPageIndex: number = 0;
  pageChangedEvent = new Subject<number>();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  currencyId = -1;

  constructor(private paginatorName: MatPaginatorIntl,
    private detector: ChangeDetectorRef
    ,private datas:ReceivableService,private route:ActivatedRoute,private router:Router,private dialog:MatDialog, private appService : AppService,
    private adminService: AdminService, private translate: TranslateService){
  }
  ngAfterViewInit(): void {

    if(this.paginatorName) {
      this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    }
  }


  ngOnInit(): void {
    this.translateLabels();
    this.getPageAccessData();
    this.translate.onLangChange.subscribe(() => {
      this.translateLabels();
    });
    this.pageChangedEvent.pipe(debounceTime(300)).subscribe((data: number) => {
      this.changePageIndex();
    });
    this.translate.onLangChange.subscribe(() => {
      if (this.paginator) {
        this.paginator._intl.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
        this.paginator._changePageSize(this.paginator.pageSize);
        this.detector.detectChanges();
      }
    });
    if(this.paginatorName) {
      this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    }
  }

  doProcess(): void {
    this.associateUser = this.adminService.isAssociationUser();
      if(!this.associateUser){
        this.displayedColumns = ['claim', 'insuredname', 'atfault','totallossamount','date','stageandsection','status','edit','delete'];
      }
    this.receivableVo.list= JSON.parse(localStorage.getItem("companyId"));

    this.route.queryParams.subscribe((queryParams: any) => {
      let isSearch = false;
      if(queryParams['recSearchQuery']) {
        isSearch = true;
        this.searchvalue = queryParams['recSearchQuery'];
      }else{
        this.searchvalue = '';
      }
      if(queryParams['stage']) {
        this.stageName=queryParams['stage'] ;
        this.receivableVo.stageName=queryParams['stage'];
      }
      if(queryParams['cur']) {
        this.currencyId = +queryParams['cur'];
        this.receivableVo.currencyId = this.currencyId;
      }
      if(this.searchvalue){
        this.getTotalCountForFilterdReceivableList(this.receivableVo,this.searchvalue);
      //this.dataSource.filter = this.searchvalue.trim().toLowerCase();
      }
      if (this.dataSource?.paginator) {
        this.dataSource.paginator.firstPage();
      }
      if(!isSearch) {
        this.dataNotFound = false;
        this.getTotalCount(this.receivableVo);
      }
    });


    this.getPrivilege();
    if(this.paginator) {
      this.paginator._intl.itemsPerPageLabel= this.translate.instant("paginator.rowsPerPage");
    }
  }



  getReceivableList() {
    this.receivableVo.stageName=this.stageName;
    this.datas.getReceivableList(this.receivableVo).subscribe((response: any) => {
      this.tableList = response.content;
      if (this.tableList.length != 0) {
        this.dataSource = new MatTableDataSource(this.tableList);
        this.dataNotFound = false;
      }else{
        this.dataSource = new MatTableDataSource(this.tableList);
        this.dataNotFound = true;
      }


    });
  }


  getTotalCount(companyName:any){



    this.datas.getReceivableTotalCount(companyName).subscribe((response:any)=>{
      this.totalLength = response.content;
    this.receivableVo.limit=this.ZERO;
    this.receivableVo.skip=this.TEN;
    this.getReceivableList();
    });
  }

  changePage(event){
    if(event.pageIndex > event.previousPageIndex ){
      //previous
      this.customPageIndex = event.pageIndex+1;
    }else{
     // next
     this.customPageIndex =  this.customPageIndex-1;
    }
    if(event.pageIndex != this.ZERO){
      this.receivableVo.skip= event.pageSize;
      this.receivableVo.limit = event.pageSize *event.pageIndex;
      this.endingIndex = event.pageSize;
      this.pageIndex = this.customPageIndex;
    }else{
      this.receivableVo.skip= event.pageSize;
      this.receivableVo.limit = event.pageIndex;
      this.endingIndex = event.pageSize;
      this.pageIndex = event.pageIndex + 1;
    }
    if(!this.searchvalue){
      this.getReceivableList();
    }else{
      this.getTotalCountForFilterdReceivableList(this.receivableVo,this.searchvalue)
    }

  }

  pageindex(): void {
    this.pageChangedEvent.next(this.pageIndex);
  }

  changePageIndex(): void {
    if(this.pageIndex > 0) {
      const totalPageIndex = this.totalLength / this.endingIndex + 1;
      if(this.pageIndex > totalPageIndex) {
        this.pageIndex = this.customPageIndex === 0 ? 1 : this.customPageIndex;
        return;
      }
      this.customPageIndex = this.pageIndex;
      this.currentPageIndex = this.pageIndex-1;
      this.receivableVo.skip= this.endingIndex;
      this.receivableVo.limit =this.endingIndex *this.currentPageIndex;
      if(!this.searchvalue){
        this.getReceivableList();
      }else{
        this.getTotalCountForFilterdReceivableList(this.receivableVo,this.searchvalue)
      }
    }
  }

  onKeyDown(event: KeyboardEvent) {
    if (event.keyCode === 190) {
      event.preventDefault();
    }
  }

  pageIndex = 1;

  editFunc(value:any){
    this.router.navigate(['report-loss/'], { queryParams: { claimId: value.claimIdentity} })
  }
  Delete(claimIdentity:string){
    if(!this.associateUser) {
    const dialogRef = this.dialog.open(PopupComponent, {
   width: 'auto',
   height:'auto',
       data: {
       message: "Are you sure you want to delete?",
        okButton: "Ok",
         cancelButton: "Cancel"
       }
   });
   dialogRef.afterClosed().subscribe(result => {
    if (result) {
this.datas.DeleteReceivabletList(claimIdentity).subscribe((data)=>{
this.getTotalCount(this.receivableVo);
});
    }
   });
   return false;
  }
}

  getPrivilege(){
    this.appService.getPrivilegeForPage(this.pageId).subscribe((res: any)=>{
      this.pageInfo = res.content;
      this.getPageInfo(this.pageId);
    });
  }

  getPageInfo(pageID: number): boolean{
    const pageValue = this.pageInfo && (this.pageInfo.length === 0 || this.pageInfo.find((element: any) => element.pageId === pageID));
    return pageValue;
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege ? privillege.isEnabled : false;
    }
    return isEnabled;
  }




  imageSectionList = [
    {
      image:"assets/reportloss/stage/Notification Stage.svg",
      title:"Notification Stage"
    },
    {
      image:"assets/reportloss/stage/Claim Inspection Stage.svg",
      title:"Claim Inspection Stage"
    },
    {
      image:"assets/reportloss/stage/Liability Confirmation Stage.svg",
      title:"Liability Confirmation Stage"
    },
    {
      image:"assets/reportloss/stage/newsettlementStage.svg",
      title:"Settlement Stage"
    }
  ]

  getUrl(item: string): string {
    let src = '';
    if(item){
    const img = this.imageSectionList.find((img) => img.title === item);
    if(img) {
      src = img.image;
    }
  }
    return src;
  }

  getPageAccessData(): void {
    this.appService.getPageAccess(appConst.PAGE_NAME.RECEIVABLE.RECEIVABLE_LIST.PAGE_IDENTITY).subscribe((response: any) => {
      this.receivableListPageAccessDto = response.content;
      this.isReceivableListEnabled = this.receivableListPageAccessDto.isEnabled;
      if(this.isReceivableListEnabled) {
        this.doProcess();
      }
    });
  }
  /*
   * Get SearchValue For ReceivableListCount
   */
  getTotalCountForFilterdReceivableList(receivableVo : CompanyId,searchValue : string){
    receivableVo.searchValue = searchValue;
    this.subscriptions = this.datas.getFilteredReceivableListCount(receivableVo).subscribe((response : any) => {
      if(response){
        this.totalLength = response.content;
        this.getSearchValueForReceivableList(receivableVo);
      }
    })
  }
   /*
   * Get SearchValue For ReceivableList
   */
    getSearchValueForReceivableList(receivableVo : CompanyId){
      this.subscriptions = this.datas.getReceivableListFilter(receivableVo).subscribe((response: any) => {
        this.tableList = response.content;
        if(this.tableList.length != 0){
          this.dataNotFound = false;
          this.dataSource = new MatTableDataSource(this.tableList);
        }else{
          this.dataSource = new MatTableDataSource(this.tableList);
          this.dataNotFound = true;
       }
      });
    }
    translateLabels() {
      this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
      this.paginatorName.firstPageLabel = this.translate.instant('Paginator.FirstPage');
      this.paginatorName.lastPageLabel = this.translate.instant('Paginator.LastPage');
      this.paginatorName.nextPageLabel = this.translate.instant('Paginator.NextPage');
      this.paginatorName.previousPageLabel = this.translate.instant('Paginator.PreviousPage');
    }
    /*
    *   unsubscribe
    */
    ngOnDestroy(): void {
     this.subscriptions.unsubscribe;
    }

  }
export class CompanyId{
  list:string[];
  skip:number;
  limit:number;
  stageName:string;
  searchValue:string;
  currencyId: number;
}


