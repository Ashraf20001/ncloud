import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { AuthService } from './service/auth.service';
import { Renderer2 } from '@angular/core';
import { LanguageService } from './service/language.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  title = 'recoveryPortalFrontend';
  selectroute = false;
  Router: any;
  language1: string;
  language2: string;
  culang: string;
  lang: string;

  constructor(private router: Router, private activatedRoute: ActivatedRoute, public translate: TranslateService,
    private service: AuthService, public renderer: Renderer2, private langauageService: LanguageService) {
      
    this.router.events.subscribe((event: any) => {
      if (event instanceof NavigationEnd) {
        this.selectroute = event.url !== '/' && !event.url.includes('login');
        if (event.url.includes('common-reset-password')) {
          this.selectroute = false;
        }
      }
    });
    this.setMultiLanguage(translate);
  }

  ngOnInit() {
    this.dashboardrouting();
  }

  dashboardrouting() {
    this.router.events.subscribe((url: any) =>(url));
  }

  private setMultiLanguage(translate: TranslateService) {
    translate.addLangs(['English', 'Arabic']);
    translate.setDefaultLang('English');
    const browserLang = 'English';
    translate.use(browserLang.match(/English|Arabic/) ? browserLang : 'English');
    this.lang = sessionStorage?.getItem('Language')?sessionStorage?.getItem('Language'):'English';
    if (this.lang && this.lang != "null") {
      this.changeLang(this.lang);
    } else {
      this.changeLang(this.translate.currentLang);
    }
  }


  changeLang(lang: string) {
    if (lang === 'Arabic') {
      this.renderer.setAttribute(document.body, 'dir', 'rtl');
      this.renderer.addClass(document.body, 'arabic');
      sessionStorage.setItem('Language', lang);
      localStorage.setItem('Language', lang);
    }
    else {
      this.renderer.setAttribute(document.body, 'dir', 'ltr');
      this.renderer.removeClass(document.body, 'arabic');
      sessionStorage.setItem('Language', lang);
      localStorage.setItem('Language', lang);
    }
    setTimeout(() => {
      this.translate.use(lang);
    }, 1000);
  }

  showReportLoss(data: { claimId: string, isReceivable: boolean }): void {
    this.router.navigateByUrl('/report-loss?claimId=' + data.claimId + "&rec=" + data.isReceivable);
  }
}
