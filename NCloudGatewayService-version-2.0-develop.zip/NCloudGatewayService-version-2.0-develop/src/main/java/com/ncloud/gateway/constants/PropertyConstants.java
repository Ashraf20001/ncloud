package com.ncloud.gateway.constants;

/**
 * The Class PropertyConstants.
 */
public class PropertyConstants {

	/** The Constant DIGITAL_PAPER_URI. */
	public final static String DIGITAL_PAPER_URI = "digital-paper.uri";
	
	/** The Constant COMMON_SERVICE_URI. */
	public final static String COMMON_SERVICE_URI = "common-service.uri";
	
	/** The Constant AUTHENTICATION_URI. */
	public final static String AUTHENTICATION_URI = "auth-service.uri";
	
	/** The Constant DATA_LAKE_URI. */
	public final static String DATA_LAKE_URI = "data-lake.uri";
	
	/** The Constant NOTIFICATION_URI. */
	public final static String NOTIFICATION_URI = "notification.uri";
	
	/** The Constant RECOVERY_URI. */
	public final static String RECOVERY_URI = "recovery.uri";
}
