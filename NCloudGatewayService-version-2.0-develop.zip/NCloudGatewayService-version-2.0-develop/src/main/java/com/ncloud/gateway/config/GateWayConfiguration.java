package com.ncloud.gateway.config;

import java.util.Arrays;
import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder.Builder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.reactive.CorsWebFilter;
import org.springframework.web.cors.reactive.UrlBasedCorsConfigurationSource;

/**
 * The Class GateWayConfiguration.
 */
@Configuration
public class GateWayConfiguration {
	
	/**
	 * EnvironmentProperties
	 */
	@Autowired
	private com.ncloud.gateway.config.EnvironmentProperties environmentProperties;
	
	/** The Constant COMMON_PREDICATE. */
	private static final String COMMON_PREDICATE = "/api/**";
	
	/** The Constant DIGITAL_PREIDCATE. */
	private static final String DIGITAL_PREIDCATE = "/digital-paper/**";
	
	/** The Constant AUTH_PREDICATE. */
	private static final String AUTH_PREDICATE = "/auth-service/**";
	
	/** The Constant DATA_LAKE_PREDICATE. */
	private static final String DATA_LAKE_PREDICATE = "/data-lake/**";
	
	/** The Constant NOTIFICATION_PREDICATE. */
	private static final String NOTIFICATION_PREDICATE = "/notify/**";
	
	/** The Constant RECOVERY_PREDICATE. */
	private static final String RECOVERY_PREDICATE = "/recovery/**";
	
	 
	/**
	 * 
	 * @param routeLocatorBuilder
	 * @return
	 * 
	 * change in order of adding routes will effect routing
	 * 
	 */
	@Bean
	public RouteLocator myRoutes(RouteLocatorBuilder routeLocatorBuilder) {
		Builder builder = routeLocatorBuilder.routes();
		addRoute(builder, COMMON_PREDICATE, environmentProperties.getCommonServiceUri());
		addRoute(builder, DIGITAL_PREIDCATE, environmentProperties.getDigitalPaperUri());
		addRoute(builder, DATA_LAKE_PREDICATE, environmentProperties.getDatalakeUri());
		addRoute(builder, AUTH_PREDICATE, environmentProperties.getAuthenticationuri());
		addRoute(builder, NOTIFICATION_PREDICATE, environmentProperties.getNotificationUri());
		addRoute(builder, RECOVERY_PREDICATE, environmentProperties.getRecoveryUri());
		return builder.build();
	}

	/**
	 * 
	 * @param builder
	 * @param predicates url matcher
	 * @param uri  route uri where request need to be routed
	 */
	private void addRoute(Builder builder, String predicates, String uri) {
		builder.route(p -> p.path(predicates).filters(a -> a.addRequestHeader("Accept", "application/json")).uri(uri));
	}
	
	/**
	 * Cors web filter.
	 *
	 * @return the cors web filter
	 */
	@Bean
    public CorsWebFilter corsWebFilter() {

        final CorsConfiguration corsConfig = new CorsConfiguration();
        corsConfig.setAllowedOrigins(Collections.singletonList("*"));
        corsConfig.setMaxAge(3600L);
        corsConfig.setAllowedMethods(Arrays.asList("GET", "POST"));
        corsConfig.addAllowedHeader("*");
        corsConfig.setAllowedOrigins(Arrays.asList("*"));
        corsConfig.setAllowedMethods(Collections.singletonList("*"));
        corsConfig.setAllowCredentials(false);
        corsConfig.setAllowedHeaders(Collections.singletonList("*"));
        corsConfig.setExposedHeaders(Arrays.asList("Authorization"));

        final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", corsConfig);

        return new CorsWebFilter(source);
    }  
}
