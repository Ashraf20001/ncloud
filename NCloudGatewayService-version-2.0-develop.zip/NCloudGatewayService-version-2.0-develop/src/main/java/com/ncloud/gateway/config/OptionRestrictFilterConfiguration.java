package com.ncloud.gateway.config;

import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import reactor.core.publisher.Mono;

/**
 * The Class OptionRestrictFilterConfiguration.
 */
@Component
public class OptionRestrictFilterConfiguration implements GlobalFilter{

	/**
	 * Filter.
	 *
	 * @param exchange the exchange
	 * @param chain the chain
	 * @return the mono
	 */
	@Override
	public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
		String httpMethod = exchange.getRequest().getMethodValue();
        if ("OPTIONS".equalsIgnoreCase(httpMethod)) {
            exchange.getResponse().setStatusCode(HttpStatus.FORBIDDEN);
            return exchange.getResponse().setComplete();
        }
        return chain.filter(exchange);
	}

}
