package com.ncloud.gateway.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * The Class PropertyValueProvider.
 */
@Component
@ConfigurationProperties(prefix = "gateway")
public class PropertyValueProvider {
		
		/** The digital paper uri. */
		private String digitalPaperUri;
		
		/** The common service uri. */
		private String commonServiceUri;
		
		/** The auth service uri. */
		private String authServiceUri;
		
		/** The data lake uri. */
		private String dataLakeUri;
		
		/** The notification uri. */
		private String notificationUri;
		
		/** The recovery uri. */
		private String recoveryUri;

		/**
		 * Gets the digital paper uri.
		 *
		 * @return the digital paper uri
		 */
		public String getDigitalPaperUri() {
			return digitalPaperUri;
		}

		/**
		 * Sets the digital paper uri.
		 *
		 * @param digitalPaperUri the new digital paper uri
		 */
		public void setDigitalPaperUri(String digitalPaperUri) {
			this.digitalPaperUri = digitalPaperUri;
		}

		/**
		 * Gets the common service uri.
		 *
		 * @return the common service uri
		 */
		public String getCommonServiceUri() {
			return commonServiceUri;
		}

		/**
		 * Sets the common service uri.
		 *
		 * @param commonServiceUri the new common service uri
		 */
		public void setCommonServiceUri(String commonServiceUri) {
			this.commonServiceUri = commonServiceUri;
		}

		/**
		 * Gets the auth service uri.
		 *
		 * @return the auth service uri
		 */
		public String getAuthServiceUri() {
			return authServiceUri;
		}

		/**
		 * Sets the auth service uri.
		 *
		 * @param authServiceUri the new auth service uri
		 */
		public void setAuthServiceUri(String authServiceUri) {
			this.authServiceUri = authServiceUri;
		}

		/**
		 * Gets the data lake uri.
		 *
		 * @return the data lake uri
		 */
		public String getDataLakeUri() {
			return dataLakeUri;
		}

		/**
		 * Sets the data lake uri.
		 *
		 * @param dataLakeUri the new data lake uri
		 */
		public void setDataLakeUri(String dataLakeUri) {
			this.dataLakeUri = dataLakeUri;
		}

		/**
		 * Gets the notification uri.
		 *
		 * @return the notification uri
		 */
		public String getNotificationUri() {
			return notificationUri;
		}

		/**
		 * Sets the notification uri.
		 *
		 * @param notificationUri the new notification uri
		 */
		public void setNotificationUri(String notificationUri) {
			this.notificationUri = notificationUri;
		}

		/**
		 * Gets the recovery uri.
		 *
		 * @return the recovery uri
		 */
		public String getRecoveryUri() {
			return recoveryUri;
		}

		/**
		 * Sets the recovery uri.
		 *
		 * @param recoveryUri the new recovery uri
		 */
		public void setRecoveryUri(String recoveryUri) {
			this.recoveryUri = recoveryUri;
		}
		
		
}
