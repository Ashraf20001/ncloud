package com.ncloud.gateway.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

/**
 * The Class EnvironmentProperties.
 */
@Configuration
public class EnvironmentProperties {

	/** The configuration properties. */
	@Autowired
	private PropertyValueProvider configurationProperties;
	
	/**
	 * Gets the digital paper uri.
	 *
	 * @return the digital paper uri
	 */
	public String getDigitalPaperUri() {
		return configurationProperties.getDigitalPaperUri();
	}
	
	/**
	 * Gets the datalake uri.
	 *
	 * @return the datalake uri
	 */
	public String getDatalakeUri() {
		return configurationProperties.getDataLakeUri();
	}
	
	/**
	 * Gets the common service uri.
	 *
	 * @return the common service uri
	 */
	public String getCommonServiceUri() {
		return configurationProperties.getCommonServiceUri();
	}
	
	/**
	 * Gets the authenticationuri.
	 *
	 * @return the authenticationuri
	 */
	public String getAuthenticationuri() {
		return configurationProperties.getAuthServiceUri();
	}
	
	/**
	 * Gets the notification uri.
	 *
	 * @return the notification uri
	 */
	public String getNotificationUri() {
		return configurationProperties.getNotificationUri();
	}
	
	/**
	 * Gets the recovery uri.
	 *
	 * @return the recovery uri
	 */
	public String getRecoveryUri() {
		return configurationProperties.getRecoveryUri();
	}
	
}
