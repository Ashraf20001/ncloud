export const environment = {
  production: true,
  API_BASE_URL : 'http://164.52.217.22:6063',
  AUTH_URL : 'http://164.52.217.22:6063',
  WEB_SOCKET_URL : "http://164.52.211.89:6063/digital-paper/ws"
};
