// export const environment = {
//   production: false,
//   API_BASE_URL : 'http://localhost:6060',
//   AUTH_URL : 'http://localhost:6060',
//   WEB_SOCKET_URL : "http://localhost:6063/digital-paper/ws"
//   // API_BASE_URL: 'http://10.10.12.43:8500'
// };
// export const environment = {
//   production: false,
//   API_BASE_URL : 'http://10.10.11.172:6060',
//   AUTH_URL : 'http://10.10.11.172:6060',
//   WEB_SOCKET_URL : "http://10.10.11.172:6063/digital-paper/ws"
//   // API_BASE_URL: 'http://10.10.12.43:8500'
// };
export const environment = {
  production: false,
  API_BASE_URL : 'http://164.52.217.22:6063',
  AUTH_URL : 'http://164.52.217.22:6063',
  WEB_SOCKET_URL : "http://164.52.211.89:6063/digital-paper/ws"
  // API_BASE_URL: 'http://10.10.12.43:8500'
};
