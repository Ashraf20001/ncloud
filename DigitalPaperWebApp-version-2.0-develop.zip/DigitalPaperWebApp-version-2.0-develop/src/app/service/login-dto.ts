import { PlatformDetailsDto } from "./platform-details-dto";

export interface LoginDto{
     username:string;
     password:string;
      platformDetailsDto:PlatformDetailsDto
}