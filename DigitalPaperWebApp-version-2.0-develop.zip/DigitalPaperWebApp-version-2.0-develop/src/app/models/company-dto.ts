export class CompanyDetails{
    emInsAddress?:string;
    emInsCompanyId?:number;
    emInsEmail?:string;
    emInsIsActive?:boolean;
    emInsLocation?:string;
    emInsLogo?:string;
    emInsMaxPayableAmount?:string;
    emInsMaxTime?:string;
    emInsName?:string;
    emInsPassword?:string;
    emInsPhone?:string;
    emInsShortName?:string;
    companyLogo = 'assets/no-logo.svg';
  }
  