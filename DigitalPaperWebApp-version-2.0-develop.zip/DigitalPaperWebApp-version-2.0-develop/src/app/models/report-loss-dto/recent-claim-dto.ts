export class RecentClaimsDto{
  claimId : number;
  historyMessage : string;
}