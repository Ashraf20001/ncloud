export enum DataTypeEnum {
  dropDownFieldType = 'Dropdown',
  dropDownAliasName = 'Drop Down',
  multiselectFieldType = 'MultiSelect',
  radioFieldType = 'Radio',
}
