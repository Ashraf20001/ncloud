export class SortingObject {
    columnName : String;
    type : boolean;
}