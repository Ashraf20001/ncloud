export class UserProfileData {
    userId:number;
    emailId:string;
    userName:string;
    // userRoleList:UserRoleDto[];
    userRoleList:any[];
    addedDate:string;
    status:boolean;
    userIdentity:string;
    phoneNumber:string;
    password:string;
    profileUrl:string;
}