export class AuthorityPaperDetailsDto {
    companyId:number;
    insuredComapny: String;
    stockCount: number;
    availableStock: number;
    paperIssued: number;
}