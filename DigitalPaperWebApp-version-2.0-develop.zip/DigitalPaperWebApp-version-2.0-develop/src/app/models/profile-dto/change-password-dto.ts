export class ChangePasswordDto{
    oldPassword:string;
    newPassword:string;
    confirmPassword:string;
}