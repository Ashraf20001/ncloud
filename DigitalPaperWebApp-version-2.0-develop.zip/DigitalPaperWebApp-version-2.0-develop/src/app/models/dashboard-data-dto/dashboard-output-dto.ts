export class DashboardOutputDto{
    dashBoardValues:GraphData[];
}



export class GraphData {

    xaxis: string;

    yaxis: number;

}