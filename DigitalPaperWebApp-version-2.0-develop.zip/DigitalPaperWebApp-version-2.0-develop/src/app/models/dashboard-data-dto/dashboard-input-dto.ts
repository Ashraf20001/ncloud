export class DashboardInputDto{
    fromDate:Date;
    toDate: Date;
    filterType:string;
}
