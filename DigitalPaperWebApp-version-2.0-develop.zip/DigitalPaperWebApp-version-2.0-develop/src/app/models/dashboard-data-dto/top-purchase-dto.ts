export class TopPurchaseDto{
    stockCount:number;
    companies:string
}