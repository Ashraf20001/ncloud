export class PurchaseHistoryNotificationDTO {
    notificationMsg: string;
    actedBy: number;
    orderId: number;
    createdDate:any;
    imageUrl:string;
    notificationId:number;
    replaceableData:string;
    action:string
}
