export class FilterOrSortingFilter {
    columnName!: string;
    condition!: string;
    filterOrSortingType!: string;
    intgerValueList: any[] = [];
    valueList: any[] = [];
    isAscending!: boolean;
    type!: string;
    value!: string;
    value2!: string;

}