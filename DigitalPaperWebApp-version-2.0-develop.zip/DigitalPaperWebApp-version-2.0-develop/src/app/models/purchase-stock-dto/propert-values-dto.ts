export class PropertyValues {
    propertyValue : string;
    propertyName : string;
}