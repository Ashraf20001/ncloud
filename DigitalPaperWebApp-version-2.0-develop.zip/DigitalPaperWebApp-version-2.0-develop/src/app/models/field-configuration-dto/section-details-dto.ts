export class SectionDetailsDto {
  platformId:any;
  sectionName:string;
  pageIdentity:string;
  subSectionIdentity:string;
}
