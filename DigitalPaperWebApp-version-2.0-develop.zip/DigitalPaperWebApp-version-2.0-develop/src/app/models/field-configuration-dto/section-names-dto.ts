export class SectionNamesDto {
  sectionName:string;
  identity:string;
}
