export class FieldConfig{
  platformId!:any;
	updatedFields:any;
	deletedFields:any;
}
