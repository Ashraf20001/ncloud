export class DropDownListDto{
  value : any
  viewValue : any
}