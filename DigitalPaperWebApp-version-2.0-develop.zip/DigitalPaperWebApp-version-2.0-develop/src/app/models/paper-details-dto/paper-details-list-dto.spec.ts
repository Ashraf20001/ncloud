import { PaperDetailsListDto } from './paper-details-list-dto';

describe('PaperDetailsListDto', () => {
  it('should create an instance', () => {
    expect(new PaperDetailsListDto()).toBeTruthy();
  });
});
