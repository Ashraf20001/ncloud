import { Subscription } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { MenuSectionNames } from 'src/app/common/enum/enum';
import { FieldGroupDTO } from 'src/app/models/field-group-dto';
import { Field } from 'src/app/models/report-loss-dto/field';
import { MetaDataDto } from 'src/app/models/report-loss-dto/meta-data-dto';
import { Section } from 'src/app/models/report-loss-dto/section';
import { AccessMappingSectionDto } from 'src/app/models/user-role-management/section-dto';
import { MY_FORMATS } from 'src/app/reports/reports.component';
import { appConst } from 'src/app/service/app.const';
import { DropDownServiceService } from 'src/app/service/drop-down-service.service';
import { PaperService } from 'src/app/service/paper-details/paper-service.service';
import { AppService } from 'src/app/service/role access/service/app.service';
import { UserManagementService } from 'src/app/service/user-management.service';
import * as moment from 'moment';
import { DateConversionService } from 'src/app/service/date-conversion.service';

@Component({
  selector: 'app-manual',
  templateUrl: './manual.component.html',
  styleUrls: ['./manual.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }
  ],
})
export class ManualComponent implements OnInit, OnDestroy {

  metaDataDto: MetaDataDto;
  paperFieldData: Field[];
  vehicleFieldData: Field[];
  isEditUser = false;
  editableData =null;
  dropdownData: string[] = [];
  mackDropdownList: string[] = [];
  isActive = false;
  usageDropDown: string[] = [];
  multiselect: string[] = [];
  propertyArray: string[] = []
  mapOfObject: any;
  paperType = "NORMAL";
  paperDetailsAccessMappingDetails: AccessMappingSectionDto;
  generatePaperManualAccessData: AccessMappingSectionDto;
  paperDetailsAccessData: AccessMappingSectionDto;
  vehicleDetailsAccessData: AccessMappingSectionDto;
  file: File = null; // Variable to store file
  fileType: string;
  fileField: Field;
  fileName: string;
  minDate = new Date();
  errorDataSubscription:Subscription;
  fromDate:string;
  toDate:string;
  generateButtonDisable: boolean;

  constructor(private service: UserManagementService,
    private dropDownService: DropDownServiceService, private paperService: PaperService, private toaster: ToastrService, private appService: AppService,
    private route: Router, private activeRouter: ActivatedRoute, private translate: TranslateService, private dateService:DateConversionService) {
  }
  ngOnInit(): void {
    this.editableData  =null;
    this.getPageAccessDetails();
    this.getFieldData();
   this.errorDataSubscription = this.paperService.selectedProduct$.subscribe((data) => {
      this.editableData = data;
      this.propertyArray = Object.getOwnPropertyNames(this.editableData);
      this.mapOfObject = new Map(this.propertyArray.map(e => [e, this.editableData[e]]));
    })
  }

  ngOnDestroy(): void {

    this.errorDataSubscription.unsubscribe();
  }


  getPageAccessDetails() {
    this.appService.getPageAccess(appConst.PAGE_NAME.PAPER_DETAILS.PAGE_IDENTITY).subscribe(response => {
      if (response) {
        this.paperDetailsAccessMappingDetails = response['content'];
        this.generatePaperManualAccessData = this.paperDetailsAccessMappingDetails.sectionData.find(x => x.sectionName === MenuSectionNames.Generate_Paper_Manual);
        this.paperDetailsAccessData = this.paperDetailsAccessMappingDetails.sectionData.find(x => x.sectionName === MenuSectionNames.Paper_Details);
        this.vehicleDetailsAccessData = this.paperDetailsAccessMappingDetails.sectionData.find(x => x.sectionName === MenuSectionNames.Vehicle_Details);
      }
    })
  }

  createMetaDataDto() {
    this.metaDataDto.sectionList.forEach(sectionList => {
      if (sectionList) {
        this.propertyArray.forEach(element => {
          sectionList.fieldList.find(e => e.aliasName === element ? e.value = this.mapOfObject.get(element) : null)
        });

        this.editableData['Error Fields']?.forEach(element => {
          sectionList.fieldList.find(e => e.aliasName === element ? e.hasError = true : false)
        });

        sectionList.fieldList.forEach(field => {
          if ((field.fieldType === 'pDate' || field.fieldType === 'fDate') && field.value !== null && field.value !== undefined) {
            const dateArray = field.value.split("/");
            const day = parseInt(dateArray[0], 10);
            const month = parseInt(dateArray[1], 10) - 1; // Months are zero-based in JavaScript
            const year = parseInt(dateArray[2], 10);

            const date = new Date(year, month, day);
            const dateValue=date.toISOString();
            field.value = this.dateService.convertAdjustedISOString(dateValue);          
          }
        });
      }
    });
  }


  getDropDownData() {
    const parentFieldMap = this.dropDownService.getParentFieldMap();
    parentFieldMap.forEach(parentField => {
      const metaData = this.metaDataDto?.sectionList.find(x=>x.sectionId==='105').fieldList.find((dt) => dt.fieldName === parentField.parentFieldName);
      const childMetaData = this.metaDataDto?.sectionList.find(x=>x.sectionId==='105').fieldList.find((dt) => dt.fieldName === parentField.childFieldName);
      if (childMetaData && childMetaData?.dropDownList === undefined) {
        this.getChildDropDowValue(null, metaData);
      }
      if (metaData || metaData.dropDownList === undefined) {
        this.buildDropDownValues(parentField.parentFieldName, metaData, null)
      }

    });
  }

  getChildDropDowValue(metaData: any, data: any) {
    const childFieldName = this.dropDownService.getChildFieldName(data.fieldName);
    const childmetaData = this.metaDataDto?.sectionList.find(x=>x.sectionId==='105').fieldList.find((dt) => dt.fieldName === childFieldName);

    this.buildDropDownValues(childFieldName, childmetaData, data.value);

  }

  buildDropDownValues(fieldName: string, metaData: Field, value: string) {
    if (fieldName && fieldName != '') {

      this.dropDownService.getOption(metaData.fieldId, value, null).subscribe(data => {
        if (data) {
          metaData.dropDownList = data;
        }
      })
    }
  }



  generatePaper() {
    const uploadType = this.activeRouter.snapshot.paramMap.get('uploadType');
    const actionType = this.activeRouter.snapshot.paramMap.get('actionType');

    const sectionList=this.metaDataDto.sectionList;
    sectionList.forEach((section)=>{
      section.fieldList.forEach((field)=>{
        if((field.fieldType==='fDate' || field.fieldType==='pDate') && field.value!=null){
          const value:any=field.value;
          let isMoment=null;
          if(value instanceof moment){
            isMoment=true;
          }
          if(isMoment){
            if(field.aliasName==='Effective From'){
              if(this.fromDate===undefined || this.fromDate===null){
                const date=this.dateService.convertAdjustedISOString(value._d);
                this.fromDate=date;
                field.value=this.fromDate;
              }
            }
          }else if (value instanceof Object){       
            if(field.aliasName==='Effective From'){
              if(this.fromDate===undefined || this.fromDate===null){
                const date=this.dateService.convertAdjustedISOString(value);
                this.fromDate=date;
                field.value=this.fromDate;
              }
            }
          }
          else{
            if(field.aliasName==='Effective From'){
              if(this.fromDate===undefined || this.fromDate===null){
                const date=this.dateService.convertAdjustedISOString(value);
                this.fromDate=date;
                field.value=this.fromDate;
              }
            }
            if(field.aliasName==='Expiry Date'){
              if(this.toDate===undefined || this.toDate===null){
                const date=this.dateService.convertAdjustedISOString(value);
                this.toDate=date;
                field.value=this.toDate;
              }
            }
          }      
         
        }
      })
    });

    this.metaDataDto.sectionList=sectionList;

    this.generateButtonDisable=true;

    this.service.saveFieldMetaData(this.metaDataDto, uploadType, actionType).subscribe((data: any) => {
      if (data != null) {
        this.toaster.success(this.translate.instant('Toaster_success.digital_paper'));
        this.route.navigate(['paper-details']);
      }

    },(error)=>{
      this.generateButtonDisable=false;
    })
  }

  getDropdownList(fieldData: any) {
    if (fieldData.aliasName == "Model" && fieldData.value == null) {
      const value = this.metaDataDto.sectionList[1].fieldList[3].value;
      this.dropDownService.getOption(fieldData.fieldId, value, fieldData.fieldName).subscribe((data) => {
        if (data) {
          this.dropdownData = data;
        }
      });
    }
  }

  getChildDropDownData(fieldData: any) {
    // let fieldData = this.metaDataDto.sectionList[1].fieldList[3];
    if (fieldData.aliasName == "Make") {
      const value = null;
      this.dropDownService.getOption(fieldData.fieldId, value, fieldData.fieldName).subscribe((data) => {
        if (data) {
          this.mackDropdownList = data;
        }
      });
    }

    if (fieldData.aliasName == "Model") {
      const data = this.metaDataDto.sectionList[1].fieldList[3];
      this.dropDownService.getChildDropDownList(data.fieldId, data.value, data.fieldName).subscribe(data => {
        if (data) {
          this.dropdownData = data;
        }
      });
    }

    if (fieldData.fieldType === 'MultiSelect') {
      // this.multiselect = [];
      // fieldData.dropDownList.forEach(element => {
      //   this.multiselect.push(element.fieldOptionName);
      // });
    }

  }

  setDateValue(data: any, value: any) {
    const date = new Date(value);
    date.setHours(12);
    date.setMinutes(30);
    date.setSeconds(45);
    data.value = date ;
  }
  getFieldData() {
    const uploadType = this.activeRouter.snapshot.paramMap.get('uploadType');
    const pageId = "c741ae6b5c3a49b888d2592a51c6bu8u";
    this.service.getFieldMetaDataForGeneratePaper(pageId).subscribe((data: any) => {
      this.isActive = data.isActive;
      this.metaDataDto = data.metaData;
      if (this.editableData !== null) {
        this.createMetaDataDto();
      }
      this.metaDataDto?.sectionList.forEach(
        value => {
          if (value.sectionId === '104') {
            this.paperFieldData = value.fieldList;
            if (uploadType == undefined) {
              this.paperFieldData.forEach(field => {
                field.value = null;
                field.hasError = false;
              });
            }
          }
          else if (value.sectionId === '105') {
            this.vehicleFieldData = value.fieldList;
            if (uploadType == undefined) {
              this.vehicleFieldData.forEach(field => {
                field.value = null;
                field.hasError = false;
              });
            }
          }
        }
      )
      this.getDropDownData();
    });
  }



  getStringInput(items: Field) {
    if (items.fieldType === 'String') {
      return true;
    }
    return false;
  }

  getDateInput(items: Field) {
    if (items.fieldType === 'pDate' || items.fieldType === 'fDate') {
      return true;
    }
    return false;
  }


  getNumberInput(items: Field) {
    if (items.fieldType === 'Integer') {
      if (items.value !== null) {
        this.isEditUser = true;
      }
      return true;
    }
    return false;
  }

  getDropdownInput(items: Field) {
    if (items.fieldType === 'Dropdown') {
      return true;
    }
    else {
      return false;
    }
  }

  getMultiSelect(items: Field) {
    if (items.fieldType === 'MultiSelect') {
      return true;
    }
    else {
      return false;
    }
  }

  getCheckBox(items: Field) {
    if (items.fieldType === 'checkbox') {
      return true;
    } else {
      return false;
    }
  }

  getRadioButton(items: Field) {
    if (items.fieldType === 'Radio') {
      return true;
    } else {
      return false;
    }
  }

  getFileUploadInput(items: Field) {
    if (items.fieldType === 'file') {
      return true;
    } else {
      return false;
    }
  }

  getTextInput(items: Field) {
    if (items.fieldType === 'text' || items.fieldType === 'Long' || items.fieldType === 'Double' ||  items.fieldType === 'Boolean') {
      return true;
    } else {
      return false;
    }
  }

  onChange(event) {

    if (event !== undefined) {
      this.file = event.target.files[0];
      this.fileName = this.file.name;
      this.fileType = this.file.type;
      if (this.fileType !== "image/png" && this.fileType !== "image/jpg" && this.fileType !== "image/jpeg") {
        this.toaster.error(this.translate.instant('Toaster_error.valid_image'));
        this.fileName = '';
        this.fileField.value = '';
      }
    }
  }

  clearDateField(field: Field) {
    field.value = null;
  }

  // Changing the input border colour based on user input
  onEnteringInput(field:Field){
      if(field.hasError){
        field.hasError=false;
      }
  }

  onChangingFields(field:Field){
    if(field.hasError){
      field.hasError=false;
    }
  }

  onDateChangingEvent(field:Field){
    if(field.hasError){
      field.hasError=false;
    }
  }

  setMinDate(event:any){
    this.minDate=event.value._d;
  }

}
