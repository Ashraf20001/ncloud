import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { UserTypePopupComponent } from './user-type-popup/user-type-popup.component';
import { MatDialog } from '@angular/material/dialog';
import { Observable, ReplaySubject } from 'rxjs';
import { ImplementConfigServiceService } from 'src/app/implement-config-service.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { ReportsCardComponent } from 'src/app/reports/reports-card/reports-card.component';
import { ImplementConfigurationEnum } from 'src/app/common/enum/enum';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-implement-config',
  templateUrl: './implement-config.component.html',
  styleUrls: ['./implement-config.component.scss'],
})
export class ImplementConfigComponent implements OnInit {

  active = true;
  inactive = false;
  ispaperAutoGen = true;
  implementConfigureVarNameList: implementConfigurationVo[] = [];
  insuranceDropDownDataList: string[] = [];
  inmplementConfigure: FormGroup;
  implementConfigurationVo: implementConfigurationVo[] = [];
  implementConfigurationVoCopy = new implementConfigurationVo();
  @ViewChild('paperConfigImpl') paperConfigImpl !: ElementRef;
  htmlTemplate: string;
  isShowInsuranceUser = false;

  constructor(public dialog: MatDialog,
    public service: ImplementConfigServiceService,
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private translate: TranslateService) {

    this.inmplementConfigure = this.formBuilder.group({
      allocationBasedOn: [""],
      insuranceUserType: [""],
      digitalPaperCost: [""],
      sharePercentage: ["", [Validators.required]],
      paperAutoGeneration: ["", [Validators.required]],
      paperExpirationMail: ["", [Validators.required]],
      minimumPaperLimit: ["", [Validators.required]],
      prefix: ["", [Validators.required]],
      suffix: ["", [Validators.required]],

    });

  }

  ngAfterViewInit() {
    this.htmlTemplate = this.paperConfigImpl.nativeElement.innerHTML;
  }
  ngOnInit(): void {

    this.setColumnNameInList(ImplementConfigurationEnum.ALLOCATION_BASED_ON);
    this.setColumnNameInList(ImplementConfigurationEnum.DIGITAL_PAPER_COST);
    this.setColumnNameInList(ImplementConfigurationEnum.INSURANCE_USER_TYPE);
    this.setColumnNameInList(ImplementConfigurationEnum.SHARE_PERCENTAGE);
    this.setColumnNameInList(ImplementConfigurationEnum.PAPER_AUTO_GENERATION_FORMATE);
    this.setColumnNameInList(ImplementConfigurationEnum.PAPER_EXPIRATION_MAIL);
    this.setColumnNameInList(ImplementConfigurationEnum.MINIMUM_PAPER_LIMIT);
    this.setColumnNameInList(ImplementConfigurationEnum.SUFFIX);
    this.setColumnNameInList(ImplementConfigurationEnum.PREFIX);

    this.getInsuredDropDownData();
    this.reArrageOrder(this.implementVar_name);
    this.getImplementConfigurationData(this.implementConfigureVarNameList);
  }

  setColumnNameInList(name: string) {

    const columnName = new implementConfigurationVo();
    columnName.columnName = name;
    this.implementConfigureVarNameList.push(columnName);

  }
  getImplementConfigurationData(dataList: implementConfigurationVo[]) {
    this.service.getSavedConfiguration(dataList).subscribe((data: any) => {
      if (data.content.length !== 0) {
        data.content.forEach(element => {

          if (element.columnName === ImplementConfigurationEnum.ALLOCATION_BASED_ON) {
            if (element.value === "None") {
              this.isShowInsuranceUser = true;
            } else {
              this.isShowInsuranceUser = false;
            }
            this.inmplementConfigure.controls['allocationBasedOn'].setValue(element.value);
          } else if (element.columnName === ImplementConfigurationEnum.DIGITAL_PAPER_COST) {
            this.inmplementConfigure.controls['digitalPaperCost'].setValue(element.value);
          } else if (element.columnName === ImplementConfigurationEnum.INSURANCE_USER_TYPE) {
            this.inmplementConfigure.controls['insuranceUserType'].setValue(element.insuranceUserValue);
          } else if (element.columnName === ImplementConfigurationEnum.SHARE_PERCENTAGE) {
            this.inmplementConfigure.controls['sharePercentage'].setValue(element.value);
          } else if (element.columnName === ImplementConfigurationEnum.PAPER_EXPIRATION_MAIL) {
            this.inmplementConfigure.controls['paperExpirationMail'].setValue(element.value);
          } else if (element.columnName === ImplementConfigurationEnum.MINIMUM_PAPER_LIMIT) {
            this.inmplementConfigure.controls['minimumPaperLimit'].setValue(element.value);
          } else if (element.columnName === ImplementConfigurationEnum.SUFFIX) {
            this.inmplementConfigure.controls['suffix'].setValue(element.value);
          } else if (element.columnName === ImplementConfigurationEnum.PREFIX) {
            this.inmplementConfigure.controls['prefix'].setValue(element.value);
          } else if(element.columnName === ImplementConfigurationEnum.PAPER_AUTO_GENERATION_FORMATE){
            // const value = this.inmplementConfigure.get("prefix").value + this.inmplementConfigure.get("suffix").value;
            this.inmplementConfigure.controls['paperAutoGeneration'].setValue(element.value);
          }
        });
      }
    })
  }

  getInsuredDropDownData() {
    this.service.getInsuredUserList().subscribe((data: any) => {
      this.insuranceDropDownDataList = data.content;
    })
  }
  paperFields() {
    this.active = true;
    this.inactive = false;
  }

  setSuffixInPaperDetails() {
    const preficValue = this.inmplementConfigure.get("prefix").value ;
    const suffixValue = this.inmplementConfigure.get("suffix").value;
    let value ='';
    if(suffixValue !== null && suffixValue !== undefined){
       value = preficValue + suffixValue;
    }else{
      value = preficValue;
    }
    this.inmplementConfigure.controls['paperAutoGeneration'].setValue(value);
  }

  saveImplementConfiguration() {

    if (this.inmplementConfigure.valid) {

      this.getImplementConfigurationObject(ImplementConfigurationEnum.ALLOCATION_BASED_ON, 'allocationBasedOn');
      this.getImplementConfigurationObject(ImplementConfigurationEnum.DIGITAL_PAPER_COST, 'digitalPaperCost');
      this.getImplementConfigurationObject(ImplementConfigurationEnum.INSURANCE_USER_TYPE, 'insuranceUserType');
      this.getImplementConfigurationObject(ImplementConfigurationEnum.SHARE_PERCENTAGE, 'sharePercentage');
      this.getImplementConfigurationObject(ImplementConfigurationEnum.PAPER_AUTO_GENERATION_FORMATE, 'paperAutoGeneration');
      this.getImplementConfigurationObject(ImplementConfigurationEnum.PAPER_EXPIRATION_MAIL, 'paperExpirationMail');
      this.getImplementConfigurationObject(ImplementConfigurationEnum.MINIMUM_PAPER_LIMIT, 'minimumPaperLimit');
      this.getImplementConfigurationObject(ImplementConfigurationEnum.SUFFIX, 'suffix');
      this.getImplementConfigurationObject(ImplementConfigurationEnum.PREFIX, 'prefix');

      this.service.saveImplementationConfiguration(this.implementConfigurationVo).subscribe((data: any) => {
        if (data.content !== '') {
          this.ngAfterViewInit();
          this.saveDigitalPaperTemplate();
        }
      })

    } else {
      this.toastr.error(this.translate.instant('Toaster_error.mandatory_fields'));
    }
  }
  saveDigitalPaperTemplate() {
    if (this.htmlTemplate !== null && this.htmlTemplate !== undefined) {

      this.service.saveDigitalPaperTemplate(this.htmlTemplate).subscribe((data: any) => {
        if(data.content){
          this.toastr.success(this.translate.instant('Toaster_success.save'));
        }
      });
    }
  }
  getImplementConfigurationObject(columnname: string, value: string) {
    const obj1 = new implementConfigurationVo();
    if (columnname === "Insurance User Type") {
      obj1.columnName = columnname;
      obj1.insuranceUserValue = this.inmplementConfigure.get(value).value;
    } else {
      obj1.columnName = columnname;
      obj1.value = this.inmplementConfigure.get(value).value;
    }
    this.implementConfigurationVo.push(obj1);
  }

  disableForInsurance() {
    this.isShowInsuranceUser = !this.isShowInsuranceUser;
  }
  waterMark() {
    this.active = false;
    this.inactive = true;
  }
  implementVar_name = [
    { name: 'Insured name', value: '@InuredName' },
    { name: 'Effective From', value: '@EffectiveFrom' },
    { name: 'Policy Number', value: '@PolicyNumber' },
    { name: 'Effective To', value: '@EffectiveTo' },
    { name: 'Registration No', value: '@RegistrationNo' },
    { name: 'Chassis No', value: '@ChassisNo' },
    { name: 'Licensed to Carry', value: '@LicensedToCarry' },
    { name: 'Make', value: '@Make' },
    { name: 'Model', value: '@Model' },
    { name: 'Usage', value: '@Usage' },
    { name: 'Insurer', value: '@Insurer' },
    { name: 'DP Generated by', value: '@UserName' },
  ];

  header: any[] = [];
  content: any[] = [];
  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.implementVar_name, event.previousIndex, event.currentIndex);
    this.header = [];
    this.content = [];
    this.reArrageOrder(this.implementVar_name);
  }

  reArrageOrder(movies: any) {
    const duplicatMovies1 = movies;
    const duplicatMovies2 = movies;
    this.header = duplicatMovies2.slice(0, 4);
    this.content = duplicatMovies1.slice(4, movies.length);
  }

  openDialog(): void {

    const dialogRef = this.dialog.open(UserTypePopupComponent, {
      width: '441px',
      height: '239px',
      data:{
       insuredUserType:this.insuranceDropDownDataList
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.getInsuredDropDownData();
      }

    });
  }
  action = "Generate Paper";
  file: File = null;
  filename = null;
  fileNameList: updateFileList[] = [];
  fileList: File[] = [];
  caption = 'Choose an image';

  captionPdf = 'Choose a PDF';

  base64Output: string;
  onFileSelected(event) {
    this.convertFile(event.target.files[0]).subscribe(base64 => {
      this.base64Output = base64;
    });
  }
  convertFile(file: File): Observable<string> {
    const result = new ReplaySubject<string>(1);
    const reader = new FileReader();
    reader.readAsBinaryString(file);
    reader.onload = (event) => result.next(btoa(event.target.result.toString()));
    return result;
  }
  image: any;
  opacityImage: number;
  onChange(event: any) {
    this.opacityValue = 100;
    const files = event.target.files[0];


    const file = files;
    const fileName = file.name;

    this.fileList.push(file);
    this.convertFile(file).subscribe(base64 => {
      const fileOk = new updateFileList();
      fileOk.name = fileName;
      fileOk.file = base64;
      fileOk.fileType = file.type;
      // this.fileNameList.push(fileOk);
      this.image = fileOk.file;
      this.filename = fileOk.name;

    });


  }
  DeleteFile() {
    this.filename = null;
    this.fileNameList = [];
    this.image = null;
  }
  opacityValue = 100;
  opcaity($event: any) {
    const data = Number($event.target.value)

    const imgvalue = data / 100;
    this.opacityImage = imgvalue;


  }

}

export class updateFileList {
  name: string;
  file: any;
  size: any;
  fileType: string;
}


export class implementConfigurationVo {

  columnName: string;
  value: string;
  id: number
  insuranceUserValue: string[];
}


