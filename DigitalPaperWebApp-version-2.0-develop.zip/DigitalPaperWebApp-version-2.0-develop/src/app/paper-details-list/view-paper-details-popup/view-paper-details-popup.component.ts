import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { PaperDetailsListDto } from 'src/app/models/paper-details-dto/paper-details-list-dto';
import { FileTypeEnum } from 'src/app/models/report-loss-dto/FileTypeEnum';
import { AuthorityPaperService } from 'src/app/service/authority-paper.service';
import { PaperDetailService } from 'src/app/service/paper-details.service';

@Component({
  selector: 'app-view-paper-details-popup',
  templateUrl: './view-paper-details-popup.component.html',
  styleUrls: ['./view-paper-details-popup.component.scss']
})
export class ViewPaperDetailsPopupComponent {
  paperDetailsDto = new PaperDetailsListDto();
  emailDataVo:PaperDetailsListDto[]=[];
  fileUrl: string;
  constructor(public dialogRef: MatDialogRef<ViewPaperDetailsPopupComponent>, @Inject(MAT_DIALOG_DATA) public data: DialogData,private paperService: PaperDetailService,
  private authorityPaperService : AuthorityPaperService,
  private toaster:ToastrService, private translate : TranslateService) {

    dialogRef.disableClose = true;
    this.paperDetailsDto.createdDate = this.data.revokeData.createdDate;
    this.paperDetailsDto.pdDigiltaPaperId = this.data.revokeData.pdDigiltaPaperId;
    this.paperDetailsDto.pdInsuredName = this.data.revokeData.pdInsuredName;
    this.paperDetailsDto.digitalPaperId = this.data.revokeData.digitalPaperId;
    this.paperDetailsDto.pdPolicyNumber = this.data.revokeData.pdPolicyNumber;
    this.paperDetailsDto.pdEffectiveFrom = this.data.revokeData.pdEffectiveFrom;
    this.paperDetailsDto.pdExpireDate = this.data.revokeData.pdExpireDate;
    this.paperDetailsDto.pdPhoneNumber = this.data.revokeData.pdPhoneNumber;
    this.paperDetailsDto.pdEmailId = this.data.revokeData.pdEmailId;
    this.paperDetailsDto.vdRegistrationNumber = this.data.revokeData.vdRegistrationNumber;
    this.paperDetailsDto.vdChassis = this.data.revokeData.vdChassis;
    this.paperDetailsDto.vdLicensedToCarry = this.data.revokeData.vdLicensedToCarry;
    this.paperDetailsDto.vdMake = this.data.revokeData.vdMake;
    this.paperDetailsDto.vdModel = this.data.revokeData.vdModel;
    this.paperDetailsDto.vdUsage = this.data.revokeData.vdUsage;
    this.paperDetailsDto.insurer = this.data.revokeData.insurer;
    this.paperDetailsDto.companyId = this.data.revokeData.companyId;
    this.paperDetailsDto.companyName = this.data.revokeData.companyName;
    this.paperDetailsDto.fileURL = this.data.revokeData.fileURL;
  }

  closeDialog() {
    this.dialogRef.close('Pizza!');
  }

  getImage(item:PaperDetailsListDto){
    this.fileUrl=item.fileURL;
    return this.fileUrl;
  }

  emailShare(data:PaperDetailsListDto){
    this.emailDataVo =[];
    this.emailDataVo.push(data);

    this.authorityPaperService.sendEmail(this.emailDataVo).subscribe((data:any)=>{
      if(data.content !== ''){
        this.toaster.success(this.translate.instant('Toaster_success.email'));
      }
  });

  }

  onDownloading(){
    this.paperService.getImageFromUrl(this.fileUrl).subscribe((value)=>{
      if(value){
        const blob = new Blob([value], { type: FileTypeEnum.PNG });
        const downloadLink = document.createElement('a');
        downloadLink.style.display = 'none';
        document.body.appendChild(downloadLink);
        downloadLink.setAttribute('href', window.URL.createObjectURL(blob));
        downloadLink.setAttribute('download', "PaperImage");
        downloadLink.click();
        document.body.removeChild(downloadLink);
      }
    })
  }
}
export class DialogData {
  revokeData: PaperDetailsListDto;

}
