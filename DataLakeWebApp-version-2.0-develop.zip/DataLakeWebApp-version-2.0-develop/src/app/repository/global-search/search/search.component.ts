// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-search',
//   templateUrl: './search.component.html',
//   styleUrls: ['./search.component.scss']
// })
// export class SearchComponent {

// }
import {FilterOrSortingVo} from 'src/app/models/Filter-dto/filter-object-backend';
import {Component, ElementRef, EventEmitter, HostListener, Input, OnInit, Output, Renderer2, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup, FormsModule, ReactiveFormsModule} from '@angular/forms';
import {BehaviorSubject, Observable} from 'rxjs';
import {startWith, map, distinctUntilChanged} from 'rxjs/operators';
import {NgFor, AsyncPipe} from '@angular/common';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { HeaderService } from '../../../service/header/header.service';
import { SearchService } from 'src/app/service/search.service';
import { HttpParams } from '@angular/common/http';
import { FilterObject } from 'src/app/models/Filter-dto/filter-object';
import { SearchSharedService } from '../searchshared.service';
import { SearchBarComponent } from 'src/app/common/components/search-bar/search-bar.component';
import {TranslateService} from '@ngx-translate/core';
import { AppService } from 'ncloud-common-ui';
import { AccessMappingPageDto } from 'ncloud-common-ui/lib/dto/access-Mapping-PageDto ';
import { appConst } from 'src/app/service/app.const';
import { ToastrService } from 'ngx-toastr';

export interface StateGroup {
  letter: string;
  names: string[];
}

export const _filter = (opt: string[], value: string): string[] => {
  const filterValue = value.toLowerCase();

  return opt.filter(item => item.toLowerCase().includes(filterValue));
};

/**
 * @title Option groups autocomplete
 */
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {
  @Input() value: string = undefined;
  min=0;
 maximum=10;
filterVoObject:FilterOrSortingVo[]= [];
advancedFilterVo:FilterObject[]=[];
  StateGroup: any;
  showIcon:boolean = true;
  // stateForm:FormGroup
 searchborder=true;
  dropDownName: any;

  @ViewChild('searchbar') searchBar : SearchBarComponent;
  @Output() searchResult = new EventEmitter<any>();
  @Output() filterValue = new EventEmitter<any>();
  @Input() toSearch : string;
  searchQuery:string;
  currentRoute: string;
  repositoryName: string;
  repositoryIdentity: any;
  selectedValue: any;
  repository: string = undefined;
  show_remove=false;
  @Input() RepoClose;

 canShowCancelIcon = false;
 canViewrepositoryCloseIcon  = false;
 companyCardPageAccessMap: AccessMappingPageDto;
  isPageAccess = false;
  pageInfo: any;
  appCon = appConst;
  searchValue: string = '';
  hashmapvalue: { [key: string]: any; };
  repositorySearch=true;

  constructor(private renderer: Renderer2, private appService: AppService, private el: ElementRef, private _formBuilder: FormBuilder, private behaviorSub: SearchSharedService, private route: Router, private headerService: HeaderService, private searchService: SearchService, private activateRoute: ActivatedRoute, public translate: TranslateService,private tosterservice : ToastrService) {
    this.getCurrentUrl();

  }
  stateForm = this._formBuilder.group({
    stateGroup: '',

  });


  filteredUsers: any[] = [];
  filterCriteria = '';

  applyFilter(data:any) {

    if(data==="")
    {
this.clearSearch()
    }
    console.log(data);
    this.filteredUsers = this.StateGroup.filter(user =>
      user.repositoryName.toLowerCase().includes(data.toLowerCase())
    );
  }
  // selectedOption!:any;
  clearSearch() {

    this.filteredUsers = this.StateGroup;
  }
  // options = [
  //   { id: 1, name: 'Alice', age: 25 },
  //   { id: 2, name: 'Bob', age: 30 },
  //   { id: 3, name: 'Charlie', age: 22 },
  //   { id: 4, name: 'David', age: 28 }
  // ];

  optionsOpen= false;



  toggleOptions(): void {
    this.optionsOpen =!this.optionsOpen ;
  }

  selectOption(event): void {
    // this.selectedOption = option;
    this.optionsOpen = false;
    this.getAdavancedSearchObject(event.repositoryName)
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: Event): void {
    const clickedInside = this.el.nativeElement.contains(event.target);
    if (!clickedInside) {
      this.optionsOpen = false;
    }
  }





  /**
   * @function search
   */
  search(){
    this.searchQuery = this.searchBar.searchFilterControl.value;
    if(this.currentRoute.includes('repo-search')){
      if(this.repository == undefined){
        this.repository = this.value;
      }
      this.searchQuery = this.searchQuery === null || this.searchQuery === undefined ? "" : this.searchQuery;
      const param = { repositoryName: this.repository, recSearchQuery: this.searchQuery, isGlobalSearch: false }
      this.route.navigate(['search/repo-search'], { queryParams: param });
      
    }else {
      if(this.searchQuery != null){
      this.route.navigate(['search/global-search'], {queryParams : {recSearchQuery : this.searchQuery, isGlobalSearch: true}})
      }else{
        this.tosterservice.error(this.translate.instant("Toaster_error.Please Enter a Value to Search"))
          setTimeout(() => {
            this.tosterservice.clear();
        }, 2000);
      }
    }
  
  }

   /**
   *
   * @param name
   */
   getRepositoryName(name:any){
    this.repository = name.repositoryName;
    const param = {repositoryName : name.repositoryName, recSearchQuery: this.searchBar.searchFilterControl.value, isGlobalSearch: false}
    this.route.navigate(['search/repo-search'],{queryParams:param});
  }

  showsearch(){
  this.show_search= ! this.show_search;

  }
  show_search=false;
  // search=true;
  // keyup(){
  //   this.search=false;
  // }
  getCurrentUrl() {
    this.currentRoute = window.location.href;
    this.route.events.subscribe((event: any) => {
      if (event instanceof NavigationEnd) {
        this.currentRoute = event.url
      }
    });

  }
  CloseSearch(){
    this.route.navigate(['search']);
  }

  stateGroups: StateGroup[] = [
    {
      letter: 'A',
      names: ['Alabama'],
    },
    {
      letter: 'C',
      names: ['California'],
    },
    {
      letter: 'D',
      names: ['Delaware'],
    },
    {
      letter: 'F',
      names: ['Florida'],
    },
    {
      letter: 'G',
      names: ['Georgia'],
    },
{
      letter: 'G',
      names: ['heorgia'],
    },
  ];

  stateGroupOptions: Observable<StateGroup[]>;



  ngOnInit() {
    //TODO need to change
    this.stateGroupOptions = this.stateForm.get('stateGroup')!.valueChanges.pipe(
      startWith(''),
      map(value => this._filterGroup(value || '')),
    );
    if(this.value === null || this.value === undefined){
      this.value = 'Search.select';
      this.showIcon = false
    }
    this.getRepositoryApprovedNameList(this.filterVoObject);
    this.getPageAccessData();
  }

  /**
   * Page Access for create repository
   */
  getPageAccessData(): void {
    this.appService.getPageAccess(appConst.PAGE_NAME.SEARCH.REPOSITORY_SEARCH.SEARCH.PAGE_IDENTITY).subscribe((response: any) => {
      this.companyCardPageAccessMap = response.content;
      this.isPageAccess = this.companyCardPageAccessMap.isEnabled;
      if(this.isPageAccess){

        this.getPrivilege();
      }
    });
  }

  getPrivilege(){
    this.appService.getPrivilegeForPage(appConst.PAGE_NAME.SEARCH.REPOSITORY_SEARCH.SEARCH.PAGE_ID).subscribe((res: any)=>{
      this.pageInfo = res.content;
    });
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege?.isEnabled;
    }
    return isEnabled;
  }

  getRepositoryApprovedNameList(filterVoObject: FilterOrSortingVo[]) {
    const params = new HttpParams()
    .set('search', this.searchValue)
    .set("isApproved", true)
    this.headerService.getRepositoryDetailsapproved(filterVoObject, params).subscribe((data: any) => {
      this.StateGroup = data;
      this.filteredUsers=this.StateGroup
  });
}



/**
 * Advanced Search Filter
 */
getAdavancedSearchObject(selectedVal){
  if(selectedVal){
    this.repositoryIdentity = selectedVal; //TODO need chaange
    const param = new HttpParams().set("repositoryName",selectedVal);
    this.searchService.getAdvancedFilterObjects(param).subscribe((res:any)=>{
      this.advancedFilterVo = [];
      const temp :any[]=[];
      temp.push(res);
      temp[0].forEach(element => {
      let tmpFilter: FilterObject= this.buildFileterObject(element, element.fieldType);
      this.advancedFilterVo.push(tmpFilter);
      });
      this.behaviorSub.response.next(this.advancedFilterVo);
    });
  }
}


/**
 *
 * @param element
 * @param fieldVal
 * @returns
 */
private buildFileterObject(element: any, fieldVal:any): FilterObject {
  if(fieldVal === "Text Box"){
    return {
      columnName: element.columnName,
      condition: 'Like',
      aliasName: element.fieldName,
      type: 'field',
      value: [],
      dropdown: [],
      radio: [],
      dataType:"",
      max:50
    };
  } else if(fieldVal === "Dropdown"){
    return {
      columnName: element.columnName,
      condition: 'Like',
      aliasName: element.fieldName,
      type: 'dropdown',
      value: [],
      dropdown: element.listofFieldOptions.map(item => item.fieldOptionName),
      radio: [],
      dataType:"",
      max:50
    };
  } else if(fieldVal === "Date"){
    return {
      columnName: element.columnName,
      aliasName: element.fieldName,
      condition: 'Equal',
      type: 'dates',
      value: [],
      dropdown: [],
      radio: [],
      dataType:"",
      max:50
    };
  }
}

getfilter(event){
  const hashMap: { [key: string]: any } = event.reduce((acc, item) => {
    if (item?.value !== null && item?.value !== undefined) {
      acc[item.columnName] = item.value;
    }
    return acc;
  }, {});
  this.filterValue.emit(hashMap);
  this.hashmapvalue = hashMap;
  this.search();
  // console.log(hashMap);
  // this.repositoryName = "kaisen";
  // const param = new HttpParams().set("repositoryName", this.repositoryName);
  // this.searchService.getAdvancedFilterList(param, hashMap).subscribe((res:any)=>{
  //   console.log(res);
  // })
}


  private _filterGroup(value: string): StateGroup[] {
    if (value) {
      return this.stateGroups
        .map(group => ({letter: group.letter, names: _filter(group.names, value)}))
        .filter(group => group.names.length > 0);
    }

    return this.stateGroups;
  }
  onsearch(e) {
    const val = e.toLowerCase();
    const temp = this.stateGroups.filter(x => {
      if (x[val].toLowerCase().indexOf(val) !== -1 || !val) {
        return x;
      }
    });
    this.stateGroups = temp;
  }
  searching(){
    this.RepoClose=false;
    const queryParams={filterClose:this.RepoClose}
    this.route.navigate(['/search'],{queryParams})
    this.show_remove=false
  }
  searchfilter=false;
  heights="true";
  height="false"
  searchings(event:any){

    this.searchfilter=true;
    if(event!=undefined)
    {
      const queryParams={tableheight:this.heights}
     this.route.navigate(['/search/global-search'], {queryParams : {recSearchQuery : this.searchQuery,tableheighto:this.height}});
     this.show_remove=true;
    }
      }
}
