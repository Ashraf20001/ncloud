import { NotificationService } from 'src/app/service/notification.service';
import { AfterViewInit, ChangeDetectorRef, Component, ViewChild } from '@angular/core';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { HeaderService } from 'src/app/service/header/header.service';
import { SheareToCustomerPopupComponent } from '../sheare-to-customer-popup/sheare-to-customer-popup.component';
import { MatDialog } from '@angular/material/dialog';
import { FilterOrSortingVo } from 'src/app/models/Filter-dto/filter-object-backend';
import { ManageRepositoryCardDetails } from 'src/app/models/repository-details';
import { GlobalSearchService } from '../../../service/global-search.service';
import { CustomSortingVo } from '../../../models/Filter-dto/CustomSortingVo';
import { SearchComponent } from '../search/search.component';
import { SearchService } from 'src/app/service/search.service';
import { HttpParams } from '@angular/common/http';
import { Subject, debounceTime, distinctUntilChanged } from 'rxjs';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { FilterObject } from 'ncloud-common-ui/lib/dto/Filter-dto/filter-object';
import { SearchSharedService } from '../searchshared.service';
import { TranslateService } from '@ngx-translate/core';
import { AccessMappingPageDto } from 'ncloud-common-ui/lib/dto/access-Mapping-PageDto ';
import { appConst } from 'src/app/service/app.const';
import { AppService } from 'ncloud-common-ui';
import { ToastrService } from 'ngx-toastr';
import { HeaderDto } from 'src/app/models/header/header-dto';

/**
 * @title Table with pagination
 */
@Component({
  selector: 'app-repository-search',
  templateUrl: './repository-search.component.html',
  styleUrls: ['./repository-search.component.scss']
})

export class RepositorySearchComponent implements AfterViewInit {
  displayedColumns: string[];
  dataSource = new MatTableDataSource<PeriodicElement>([]);
  selectedcolumns: any
  name = [];
  repositories: any[];
  primaryId: number[];
  min = 0;
  max = 5;
  filter: FilterOrSortingVo[] = []

  @ViewChild(SearchComponent) filterValue: SearchComponent;
  scratchListForRepository: any;
  tempColumns: header[];
  repositoryList: any;
  dataColumns: string[];
  identity: any;
  advancedFilterVo: FilterObject[] = [];
  totalLength: number = 0;
  customSortingVo: CustomSortingVo[];
  columnName: string;
  count: any;
  activeRepository: string = "";
  toSearchQuery: string = "";
  filterMap = new Map<any, any>();
  ZERO = 0;
  repositoryName: string;
  changeColor: number;
  remainder: number;
  maximum: number;
  isAscOrder = false;
  minLength = 0;
  maxLength = 7;
  dataNotFound: boolean;
  endingIndex = 5;
  pagesize: number;
  pageIndex = 1;
  repositoryIdentity: string;
  isShowImage: boolean = false;
  isShow: boolean = true;
  currentRoute: string;
  companyCardPageAccessMap: AccessMappingPageDto;
  pageInfo: any;
  appCon = appConst;
  pageSizeOptions:number[]=[9,18,27,36];
  isGlobalSearch : boolean =  true;
  showtable:boolean;
  pageChangedEvent = new Subject<number>();
  customPageIndex : number = 0;
  @ViewChild('searchcp') searchCp : SearchComponent;
  showRepository: string;
  showSearchQuery: string;
  validatePage: any;
  isSharePrivilege: boolean;
  globalSearchResult: any;
  dasplayNames: any;
  columnNames: any;
  isShowTable:boolean = true;
  resultsFound: boolean = false;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  ishighlight: boolean = false;
  constructor(private activateRoute: ActivatedRoute,public translate:TranslateService,private appService:AppService, private route:Router, private behaviorSub: SearchSharedService, private paginatorName: MatPaginatorIntl,private tosterservice:ToastrService,
    private detector: ChangeDetectorRef,private headerService: HeaderService,  private globalSearchService: GlobalSearchService, private searchService: SearchService, private dialog: MatDialog, private notificaionService: NotificationService) {
      if(this.paginatorName) {
        this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
      }
    this.activateRoute.queryParams.subscribe((data: any) => {
      // this.filterMap = new Map<any, any>();
      this.toSearchQuery = data['recSearchQuery']
      this.isGlobalSearch = JSON.parse(data['isGlobalSearch']);
      this.activeRepository = data['repositoryName'];
      
        if(this.isGlobalSearch == true){
          this.pageSizeOptions = [7, 14, 21, 28];
          this.globalSearch();
        }else{
          if(Object.keys(data).length >= 3){
          this.repositorySearch(false);
          }else{
            this.isShowTable = false
            this.resultsFound = false
            this.totalLength = 0
            this.ishighlight = false
            if( Object.keys(this.filterMap).length < 0){
              this.tosterservice.error(this.translate.instant("Toaster_error.Please Enter a Value to Search"))
              setTimeout(() => {
                this.tosterservice.clear();
            }, 2000);
            }
          }
        }
      
      if (this.activeRepository) {
        this.isShowImage = true;
        this.isShow = false;

      }

    })
  }



  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    if(this.currentRoute.includes('global-search')){
      this.searchCp.canShowCancelIcon = true;
    }else if(this.currentRoute.includes('repo-search')){
      // this.dataSource.paginator.pageSize = 9;
      this.searchCp.canShowCancelIcon = false;
      this.searchCp.canViewrepositoryCloseIcon = true;
    }
    if(this.paginatorName) {
      this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    }
  }
  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.getCurrentUrl();
    this.getPrivilege();
    this.paginatorName.itemsPerPageLabel=this.translate.instant("Search.Rows");
    this.pageChangedEvent.pipe(debounceTime(300)).subscribe((data: number) => {

  this.changePageIndex();

});
this.translate.onLangChange.subscribe(() => {
  if (this.paginator) {
    this.paginator._intl.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    this.paginator._changePageSize(this.paginator.pageSize);
    this.detector.detectChanges();
  }
});
if(this.paginatorName) {
  this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
}
  }

  /**
   *
   */
  getPrivilege(){
    this.appService.getPrivilegeForPage(appConst.PAGE_NAME.SEARCH.REPOSITORY_SEARCH.SEARCH.PAGE_ID).subscribe((res: any)=>{
      this.pageInfo = res.content;

    });
  }

  /**
   *
   * @param privillegeName
   * @returns
   */
  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege?.isEnabled;
    }
    return isEnabled;
  }

  /**
   * @function global-search
   * @param query
   */
  private globalSearch() {
    if (this.toSearchQuery !== undefined) {
      const params = new HttpParams().set('searchQuery', this.toSearchQuery).set('skip', 0).set('limit', 7);
      this.repositories = [];
      this.displayedColumns = [];
      this.dataSource = new MatTableDataSource([]);
      this.totalLength = 0;
      if(!this.toSearchQuery){
        this.behaviorSub.response.next(false);
        this.isShowTable = false;
        this.resultsFound = false;
      }
      
      if(this.toSearchQuery || Object.keys(this.filterMap).length > 0){
        this.behaviorSub.response.next(true);
      this.searchService.globalSearch(params).subscribe((response: any) => {
        this.globalSearchResult = response.content;
        if (this.globalSearchResult.length > 0) {
            this.dataNotFound=false;
            this.resultsFound = true;
          this.repositories = this.globalSearchResult.map((element: any) => element.index);
          this.highlightRepository(this.repositories[0], false);
        }else{
          this.totalLength = 0;
          this.minLength = 0;
          this.maxLength = 0;
          this.dataNotFound=true;
          this.resultsFound = false;
          this.paginator.pageIndex = 0;
          this.paginator.pageSize = 7;
          this.dataSource = new MatTableDataSource([]);
          this.repositories = [];
        }
      
    });
  } else{
    this.tosterservice.error(this.translate.instant("Toaster_error.Please Enter a Value to Search"))
          setTimeout(() => {
            this.tosterservice.clear();
        }, 2000);
    this.route.navigate(['search/global-search'], {queryParams : {isGlobalSearch: true}})

  }
}
  }

  /**
   *
   * @param repository
   */
  highlightRepository(repository: string, isUserTriggered: boolean) {
    this.isShowTable = true;
    this.minLength = 0;
    this.maxLength = 7;
    // this.paginator.pageIndex = 0;
    // this.paginator.pageSize = 7;
    this.activeRepository = repository;
    this.searchCp.getAdavancedSearchObject(this.activeRepository);
    this.getTableHeaders();
    this.repositorySearch(true);
    // this.repositorySearch(true);
    // if (isUserTriggered) {
    // } 
    // else {
    //   this.behaviorSub.selectedValue.next(this.activeRepository);
    //   this.repositoryRecordsCount();
    //   this.getTableHeaders();
    //   this.dataSource = new MatTableDataSource([]);
    //   this.dataSource = new MatTableDataSource(this.globalSearchResult[0].matchedObject);
    // }
  }

  /**
   *
   */
  private repositoryRecordsCount() {
    this.toSearchQuery = this.toSearchQuery === undefined ? "" :this.toSearchQuery;
    const httpParams = new HttpParams().set('query', this.toSearchQuery.toLowerCase()).set('searchType', this.isGlobalSearch ? 1 : 2);
    let filterSortingVo : CustomFilterSortingVo = {
      filterMap: this.filterMap,
      sortingMap: null // TO BE CHANGED
    }
    if(this.toSearchQuery != ""){
      this.ishighlight = true;
    }
    if(this.toSearchQuery !="" || Object.keys(this.filterMap).length > 0)  { 
    this.searchService.repositoryRecordsCount(this.activeRepository, httpParams, filterSortingVo).subscribe((data: any) => {
      let response = data.content;
      this.totalLength = response;
    });
  }else{
    this.totalLength = 0
    // this.tosterservice.error('Please Enter Value to Search')
  }

  }

  /**
   * @function table-headers
   */
  private getTableHeaders() {
    const httpParams = new HttpParams().set('repositoryName', this.activeRepository);
    this.globalSearchService.getTableHeaders(httpParams).subscribe((data) => {
      this.tempColumns = [];
      this.tempColumns = data['content'];
      this.displayedColumns = [];
      const mockHeader : header = {
        displayName: 'Action',
        columnName: 'dclm_action',
        id: 0
      }
      this.tempColumns.push(mockHeader);
      this.displayedColumns = this.tempColumns.map(ele => ele.columnName);
    });
  }

  /**
   *
   */
  private repositorySearch(isPagination : boolean) {
    if (!isPagination) {
      if(this.isGlobalSearch == true){
        this.minLength = 0;
        this.maxLength = 7;
      }else{
      this.minLength = 0;
      this.maxLength = 9;
      }
      this.displayedColumns = [];
      this.isShowTable = false
      this.resultsFound = false
    }
    this.behaviorSub.selectedValue.next(this.activeRepository);
    
      this.repositoryRecordsCount();
      this.toSearchQuery = this.toSearchQuery === undefined ? "" :this.toSearchQuery;
      const params = new HttpParams()
        .set('filterValue', this.toSearchQuery.toLowerCase())
        .set('skip', this.minLength)
        .set('limit', this.maxLength)
        .set('searchType', this.isGlobalSearch ? 1 : 2);
        let filterSortingVo : CustomFilterSortingVo = {
          filterMap: this.filterMap,
          sortingMap: null // TO BE CHANGED
        }
        if(this.toSearchQuery !="" || Object.keys(this.filterMap).length > 0)  {
         this.globalSearchService.repositorySearch(params, this.activeRepository, filterSortingVo).subscribe((data) => {
        // if (data?.content?.matchedObject) {
        //   this.searchService.getRecordsFromPSql(reqParams, data.content.matchedObject).subscribe((response: any) => {
        //     if (response?.content) {
        //       this.dataSource = new MatTableDataSource(response.content);
        //       this.dataNotFound = false;
        //       this.resultsFound = true;
        //     }
        //   })
        // } else {
        //   this.dataNotFound = true;
        //   this.resultsFound = false;
        // }
        this.isShowTable = true;
        if(this.isShowTable){
          this.getTableHeaders();
          
        }
        let response = data['content'];
        this.dataSource = new MatTableDataSource([]);
        if(response?.matchedObject != null && response?.matchedObject?.length > 0) {
          this.dataNotFound=false;
          this.dataSource = new MatTableDataSource(response.matchedObject);
          this.resultsFound = true;
        }else{
         this.dataNotFound=true;
         this.resultsFound = false;
        }

      });
        }else{
          this.dataSource = new MatTableDataSource([]);
          this.dataNotFound=true;
          this.tosterservice.error(this.translate.instant("Toaster_error.Please Enter a Value to Search"))
          setTimeout(() => {
            this.tosterservice.clear();
        }, 2000);
          const param = { repositoryName: this.activeRepository, isGlobalSearch: false }
          this.route.navigate(['search/repo-search'], { queryParams: param });
        }
  }

  sendmail(element) {
    const dialogRef = this.dialog.open(SheareToCustomerPopupComponent, {
      width: '550px',
      height: '435px',
      data: {
        value: element.dclm_identity,
        repoName:this.activeRepository,
      },


    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        //  console.log('1')
      }
    });
  }

  /**
   * pageNation
   */
  pageindex() {
    this.pageChangedEvent.next(this.pageIndex);
  }
  changePageIndex() {
    if (this.pageIndex > 0) {
      if (this.pageIndex != null) {
        this.maxLength = this.endingIndex * this.pageIndex;
        this.minLength = this.endingIndex * (this.pageIndex - 1);
        const totalPageIndex = this.totalLength / this.endingIndex + 1;
      if(this.pageIndex > totalPageIndex) {
        this.pageIndex = this.customPageIndex === 0 ? 1 : this.customPageIndex;
        return;
      }
        this.setSortingVO(this.primaryId, this.columnName, this.isAscOrder);
        this.repositorySearch(true);
      }
    }
  }

  /**
   *
   * @param event
   */
  getFilterValue(event) {
    this.filterMap = event;
    this.repositorySearch(false);
  }

  /**
   *
   * @param data
   */
  tableSorting(data) {
    console.log(data);
    const bulkUploadDetails = data.target.innerText.trim();
    this.columnName = this.getEntityColumnName(bulkUploadDetails);
    this.isAscOrder = !this.isAscOrder;
    this.setSortingVO(this.primaryId, this.columnName, this.isAscOrder);
  }

  /**
   *
   * @param item
   * @returns
   */
  getEntityColumnName(item: string): string {
    let value = ''; if (item) {
      const data = this.tempColumns.find((column) => column.displayName === item);
      if (data) {
        value = data.columnName;
      }
    }
    return value;
  }

  /**
   * SortingFilterVo Dto
   */
  sortingFilterVo: CustomSortingVo = {
    columnName: "",
    isAsc: false,
    repositoryPrimaryId: []
  }

  /**
   *
   * @param repositoryId
   * @param value
   * @param condition
   */
  setSortingVO(repositoryId: number[], value: string, condition: boolean) {
    if (value != null && condition != null) {
      this.sortingFilterVo.columnName = value;
      this.sortingFilterVo.isAsc = condition;
      this.sortingFilterVo.repositoryPrimaryId = repositoryId
      this.customSortingVo = [];
      this.customSortingVo.push(this.sortingFilterVo);
    }

  }
  /**
   * page backward
   */
  onpagebackward() {
    if (this.repositoryList.length == 0) {
      this.dataNotFound = false;
    }
  }

  /**
   *
   * @param event
   */
  changePage(event) {
    if(event.pageIndex > event.previousPageIndex ){
      this.customPageIndex = event.pageIndex+1;
    }else{
     this.customPageIndex =  this.customPageIndex-1;
    }
    if (event.pageIndex != this.ZERO) {
      this.maxLength = event.pageSize;
      this.minLength = event.pageSize * event.pageIndex;
      this.endingIndex = event.pageSize;
      if (this.pagesize != event.pageSize) {
        this.maximumcount(event.pageSize);
        this.pageIndex = 1;
      }
    } else {
      this.maxLength = event.pageSize;

      this.minLength = event.pageSize * event.pageIndex;
      this.endingIndex = event.pageSize;
      if (this.pagesize != event.pageSize) {
        this.maximumcount(event.pageSize); this.pageIndex = 1;
      }
    }
    this.setSortingVO(this.primaryId, this.columnName, this.isAscOrder);
    this.repositorySearch(true);
  }

  /**
   *
   * @param event
   */
  maximumcount(event) {
    this.pagesize = event;
    this.maximum = this.totalLength / this.pagesize
    this.remainder = this.totalLength % this.pagesize;
    if (this.remainder != 0) {
      this.maximum = this.maximum + 1;
    }
  }

  getCurrentUrl() {
    this.currentRoute = window.location.href;
    this.route.events.subscribe((event: any) => {
      if (event instanceof NavigationEnd) {
        this.currentRoute = event.url
      }
    });
  }

  onKeyDown(event: KeyboardEvent) {
    if (event.keyCode === 190) {
      event.preventDefault();
    }
  }
}

export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;

}

export interface CustomFilterSortingVo {
  filterMap : any;
  sortingMap : CustomSortingVo;
}

export interface header {
  displayName: string;
  columnName: string;
  id:number;
}

