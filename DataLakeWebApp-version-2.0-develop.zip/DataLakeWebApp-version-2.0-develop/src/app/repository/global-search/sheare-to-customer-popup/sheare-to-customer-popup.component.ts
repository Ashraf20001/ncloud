import { HttpParams } from '@angular/common/http';
import { Component, Inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { HeaderService } from 'src/app/service/header/header.service';
import { SearchService } from 'src/app/service/search.service';
import { TranslateService } from '@ngx-translate/core';
import { appConst } from 'src/app/service/app.const';
import { AppService } from 'ncloud-common-ui';

@Component({
  selector: 'app-sheare-to-customer-popup',
  templateUrl: './sheare-to-customer-popup.component.html',
  styleUrls: ['./sheare-to-customer-popup.component.scss']
})
export class SheareToCustomerPopupComponent {

  mailId: FormControl = new FormControl();
  showSuccess = true;
  mailID: any;
  id: number;
  repositoryIdentity: String;
  repositoryname: string;
  fieldObject: string;
  myMap: Map<string, string>;
  myHashMap: Map<string, any>;
  disablebutton : boolean = false;
  pageInfo: any;
  appCon = appConst;

  constructor(public dialogRef: MatDialogRef<SheareToCustomerPopupComponent>,public translate:TranslateService, 
    public searchService: SearchService, public headerService: HeaderService, private tosterservice:ToastrService,@Inject(MAT_DIALOG_DATA) public data: { value: string, repoName:string },private appService: AppService) {

    dialogRef.disableClose = true;
    this.fieldObject = data.value
    this.repositoryname = data.repoName
  }
  emailRegex =  /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+[@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)]*$/;

  ngOnInit(): void {
  }
  emailControl = new FormControl('', [
    Validators.required,
    Validators.pattern(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+[@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)]*$/)
  ]);

  shareDetails() {
    if (this.emailControl.status === 'VALID') {
      this.mailID = this.emailControl.value;
        this.sendMail(this.fieldObject, this.mailID,this.repositoryname);
    } else {
      this.tosterservice.error(this.translate.instant('Toaster_error.Invalid Email Id'));
    }

  }

  /**
   *
   * @param fieldObject
   * @param mailID
   */
  sendMail(fieldObject: string, mailID: any, repositoryname:string) {
    this.disablebutton = true;
    this.searchService.MailService(fieldObject,mailID,repositoryname).subscribe((data: any) => {
      if(data){
         this.showSuccess = false;
         setTimeout(() => {
          this.closeDialog();
        }, 3000);
      }
    });
  }

  closeDialog() {
    this.disablebutton = false;
    this.dialogRef.close();
  }

  getPrivilege(){
    this.appService.getPrivilegeForPage(appConst.PAGE_NAME.SEARCH.REPOSITORY_SEARCH.SEARCH.PAGE_ID).subscribe((res: any)=>{
      this.pageInfo = res.content;
    });
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege?.isEnabled;
    }
    return isEnabled;
  }

}


