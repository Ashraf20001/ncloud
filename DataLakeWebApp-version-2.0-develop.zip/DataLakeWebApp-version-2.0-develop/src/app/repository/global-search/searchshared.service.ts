import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { RepositoryField } from "src/app/models/repository-field";
import { SearchComponent } from "./search/search.component";
import { FilterObject } from "src/app/models/Filter-dto/filter-object";

@Injectable({
    providedIn: 'root'
  })
  export class SearchSharedService {

    
    response = new BehaviorSubject<any>([]);
    selectedValue = new BehaviorSubject<string>("");
    filterObject = new BehaviorSubject<any>([]);
    
    /**
     * @function get-field-configuration
     */
    getSearchSub(){
      return this.response;
    }

    /**
     * 
     * @returns 
     */
    getSearchFilterObject(){
      return this.filterObject;
    }

    /**
     * 
     * @returns 
     */
    getSelectedValue(){
      return this.selectedValue;
    }

    clearFilter(){
      this.response.next([])
      // this.selectedValue.next([])
    }
  }