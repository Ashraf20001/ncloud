import { NgModule } from "@angular/core";

import { AppCommonModule } from "../../common/components/app-common.module";
import { DemoMaterialModule } from "src/app/common/components/material-module";
import { CommonModule } from "@angular/common";
import { GlobalSearchRoutingMoudle } from "./global-search-routing.module";
import { GlobalSearchComponent } from "./global-search.component";
import { SearchComponent } from './search/search.component';
import { RepositorySearchComponent } from './repository-search/repository-search.component';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { SheareToCustomerPopupComponent } from './sheare-to-customer-popup/sheare-to-customer-popup.component';
import { CustomDirectiveModule } from "../../common/directives/custom-directive.module";
import {TranslateModule, TranslatePipe} from "@ngx-translate/core";







@NgModule({
    declarations: [
      GlobalSearchComponent,
      SearchComponent,
      RepositorySearchComponent,
      SheareToCustomerPopupComponent
    ],
    imports: [
        AppCommonModule,
        DemoMaterialModule,
        CommonModule,
        GlobalSearchRoutingMoudle,
        FormsModule,
        ReactiveFormsModule,
        CustomDirectiveModule,TranslateModule
    ]
})
export class GlobalSearchModule{

}
