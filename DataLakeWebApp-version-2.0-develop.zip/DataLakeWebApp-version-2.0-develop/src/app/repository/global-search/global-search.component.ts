import { Component } from '@angular/core';
import { AppService } from 'ncloud-common-ui';
import { AccessMappingPageDto } from 'ncloud-common-ui/lib/dto/access-Mapping-PageDto ';
import { appConst } from 'src/app/service/app.const';

@Component({
  selector: 'app-global-search',
  templateUrl: './global-search.component.html',
  styleUrls: ['./global-search.component.scss']
})
export class GlobalSearchComponent {

  companyCardPageAccessMap: AccessMappingPageDto;
  isPageAccess = false;
  pageInfo: any;
  appCon = appConst;

  constructor(private appService: AppService){}

  ngOnInit(){
    this.getPageAccessData();
  }

  /**
   * Page Access for create repository
   */
  getPageAccessData(): void {
    this.appService.getPageAccess(appConst.PAGE_NAME.SEARCH.REPOSITORY_SEARCH.SEARCH.PAGE_IDENTITY).subscribe((response: any) => {
      this.companyCardPageAccessMap = response.content;
      this.isPageAccess = this.companyCardPageAccessMap.isEnabled;
    });
  }

}
