import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GlobalSearchComponent } from './global-search.component';
import { RepositorySearchComponent } from './repository-search/repository-search.component';





const routes: Routes = [
  {
    path:'',
    component:GlobalSearchComponent,
    children:[
      {
        path: 'global',
        component : GlobalSearchComponent
      }

    ]


  },
  {
    path:'global-search',
    component:RepositorySearchComponent
  },
  {
    path:'repo-search',
    component:RepositorySearchComponent
  },
  {
    path: '',
    redirectTo: 'global',
    pathMatch: 'full',
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GlobalSearchRoutingMoudle { }


