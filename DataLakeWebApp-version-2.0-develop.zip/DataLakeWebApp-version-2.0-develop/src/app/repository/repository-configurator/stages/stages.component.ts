import { CdkDragDrop, moveItemInArray, copyArrayItem } from '@angular/cdk/drag-drop';
import { Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { RepositorySharedService } from '../repository_.service';
import { RepositoryField } from 'src/app/models/repository-field';
import * as _ from 'lodash';
import { RenameRepositoryComponent } from './rename-repository/rename-repository.component';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-stages',
  templateUrl: './stages.component.html',
  styleUrls: ['./stages.component.scss']
})
export class StagesComponent {

  tempCount = 1;
  selectedField:any;
  repositoryName:string;
  fieldList: any[] = [];
  deletedFields = [];
  @Output() collectFieldData = new EventEmitter<any>();
  @Output() getFieldList = new EventEmitter<any>();
  repositoryStatus: any;
  isReadOnly: boolean = false;
  @Input() value : any;
  @Input() identity : any;
  isCreator: boolean = true;
  receivedValue: boolean;
  readOnly: boolean = false;

  constructor(private repositorySharedService: RepositorySharedService, public dialog: MatDialog,private route: ActivatedRoute){
    this.route.queryParams.subscribe((querParams : any) => {
      this.repositoryStatus = querParams['status']
      this.readOnly = querParams['readOnly'];
      if(this.repositoryStatus =='Submitted' && this.readOnly){
        this.isReadOnly = true;
      } else if(this.repositoryStatus == 'Approved' || this.repositoryStatus == 'Rejected' || this.repositoryStatus == 'Disabled'){
        this.isReadOnly = true;
      }
    })
    

   }

   ngOnInit(): void{
   
   }

/**
 * @function destination-dropped
 * @param event
 */
  destinationDropped(event: CdkDragDrop<RepositoryField[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      copyArrayItem(event.previousContainer.data, event.container.data, event.previousIndex, event.currentIndex);
        let newField = _.cloneDeep(this.fieldList[event.currentIndex]);
        if(newField.fieldType === 'Date'){
          newField.dataType = 'Date';
        }
        newField.fieldName = '';
        newField.tempId = this.tempCount;
        this.tempCount++;
        this.fieldList[event.currentIndex] = newField;
        this.emitSelectedField(newField);
    }
  }

  /**
   * @function emit-seletced-field
   * @param field
   */
  emitSelectedField(field: RepositoryField) {
    if(this.selectedField != undefined){
      this.collectFieldData.emit(this.selectedField);
    }
    this.selectedField = field;
    this.repositorySharedService.moveToConfigurator.next(this.selectedField);
  }
/**
 * @function delete-field
 * @param index
 */
  removeField(index : number, field : RepositoryField){
    if(field.fieldIdentity){
      this.deletedFields.push(field.fieldIdentity);
    }
    this.fieldList.splice(index,1);
  }

  renameRerpository(){
    const dialogRef = this.dialog.open(RenameRepositoryComponent, {
      width: '340px',
      height: '165px',

      data: {
        name: this.value,
        identity : this.identity,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if(result === true){
        this.getFieldList.emit(this.identity);
      }
    });
  }


}
