
import { DialogRef } from '@angular/cdk/dialog';
import { HttpParams } from '@angular/common/http';
import { Component, EventEmitter, Inject, Input, Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { FieldDTO } from 'src/app/models/field-dto';
import { HeaderService } from 'src/app/service/header/header.service';

@Component({
  selector: 'app-rename-repository',
  templateUrl: './rename-repository.component.html',
  styleUrls: ['./rename-repository.component.scss']
})
export class RenameRepositoryComponent {
  // @Output() messageEvent = new EventEmitter<string>();
  renameControl: FormControl = new FormControl();
  DataForm: any;
  identity: string;
  element: FieldRepositoryDto;
  // value: string;
  constructor(public urlService: HeaderService,public translate:TranslateService ,private toastr : ToastrService,public dialogRef: MatDialogRef<RenameRepositoryComponent>,public dialog: MatDialog,@Inject(MAT_DIALOG_DATA) public data : {name : string , identity : string},) { }

  closed = true;



  close() {
    this.closed = !this.closed;
  }
  closeTab() {
    this.dialog.closeAll();
  }
  ngOnInit(){
    this.renameControl.setValue(this.data.name);
    this.identity = this.data.identity;

  }

  //Get RepositoryName From User
  renameRepository() {
    let fieldRepositoryDto: FieldRepositoryDto = {
      repositoryIdentity: this.identity,
      repositoryName: this.renameControl.value,
    }
    this.updateRenameRepository(fieldRepositoryDto);
    // this.dialogRef.close("true");
    // this.closeTab();
  }


  /**
 * @param fieldRepositoryDto
 * @returns
 */
  updateRenameRepository(fieldRepositoryDto) {
    this.urlService.renameRepository(fieldRepositoryDto).subscribe((data:any) => {
        // this.value = data['content'];
        // this.closeTab();
        this.dialogRef.close(true);
        this.toastr.success(this.translate.instant('Toaster_success.Update RepositoryName Successfully'));
    });


  }


}

export interface FieldRepositoryDto{
  repositoryIdentity : string;
  repositoryName : string;

}



