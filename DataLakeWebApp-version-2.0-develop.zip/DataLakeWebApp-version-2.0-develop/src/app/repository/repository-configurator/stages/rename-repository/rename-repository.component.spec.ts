import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RenameRepositoryComponent } from './rename-repository.component';

describe('RenameRepositoryComponent', () => {
  let component: RenameRepositoryComponent;
  let fixture: ComponentFixture<RenameRepositoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RenameRepositoryComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RenameRepositoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
