import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


const routes: Routes = [
  // {
  //   path:'dash', component:,
  //   children: [
  //     {
  //       path:'field-configure',
  //       loadChildren: ()=> import('./create-new-repository/create-new-repository.module').then(m=> m.CreateNewRepositoryModule)
  //     },

  //     {
  //       path: '',
  //       redirectTo: 'field-configure',
  //       pathMatch: 'full',
  //     }
  //     // {
  //     //   path:'',redirectTo:'page-config/field-configure',pathMatch:'full'
  //     // },

  //   ]
  // }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RepositoryConfiguratorRoutingModule { }
