import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DemoMaterialModule } from 'src/app/common/components/material-module';
import {MatTabsModule} from '@angular/material/tabs';
import { AppCommonModule } from 'src/app/common/components/app-common.module';
import { ManageRepositoryModule } from '../manage-repository/manage-repository.module';
import { FieldsComponent } from './fields/fields.component';

import { StagesComponent } from './stages/stages.component';
import { RepositoryConfiguratorRoutingModule } from './repository-configurator-routing.module';
import { ConfigurationComponent } from './configuration/configuration.component';
import { RepositoryConfiguratorComponent } from './repository-configurator.component';
import { FormGroup, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { CustomInputDirective } from 'src/app/common/directives/custom-input.directive';
import { RenameRepositoryComponent } from './stages/rename-repository/rename-repository.component';






@NgModule({
  declarations: [
    FieldsComponent,
    StagesComponent,
    ConfigurationComponent,
    RepositoryConfiguratorComponent,
    RenameRepositoryComponent,
    CustomInputDirective
  ],
  imports: [
    CommonModule,
    TranslateModule,
    MatTabsModule,
    DemoMaterialModule,
    AppCommonModule,
    ManageRepositoryModule,
    RepositoryConfiguratorRoutingModule,
    ReactiveFormsModule
  ]
})
export class RepositoryfigurationMainModule { }
