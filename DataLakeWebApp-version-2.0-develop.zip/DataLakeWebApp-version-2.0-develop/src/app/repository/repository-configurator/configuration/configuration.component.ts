import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { RepositorySharedService } from '../repository_.service';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { distinctUntilChanged } from 'rxjs';
import * as _ from 'lodash';
import { ActivatedRoute } from '@angular/router';
import { RepositoryConfiguratorComponent } from '../repository-configurator.component';


@Component({
  selector: 'app-configuration',
  templateUrl: './configuration.component.html',
  styleUrls: ['./configuration.component.scss']
})
export class ConfigurationComponent implements OnInit {

  /**
   * @var variables
   */
  selectedField: any;
  fieldForm!: FormGroup;
  repositoryField: any = null;
  existingOptions: any;
  optionEnable: any;
  dropDownEnable: boolean
  enableDataType: boolean = true;
  deletedOptions = new Map<string,string[]>();
  updatedOptions = new Map<string,string[]>();
  repositoryStatus: string;
  isReadOnly: boolean = false;
  // @Input()  isDisable: any;

  data_Type_Data: any[] = [
    // { value: '0', viewValue: 'Decimal' },
    { value: '1', viewValue: 'String' },
    // { value: '2', viewValue: 'Boolean' },
    { value: '3', viewValue: 'Number' }
  ];
  isCreator: boolean = true;
  receivedValue: boolean;
  readOnly: boolean = false;

  /**
   * @function constructor
   * @param behaviourSub
   * @param fb
   */
  constructor(private behaviourSub: RepositorySharedService, private fb: FormBuilder,private activeRoute: ActivatedRoute) {
    this.activeRoute.queryParams.subscribe((res:any)=>{
            this.repositoryStatus = res['status'];
            this.readOnly = res['readOnly'];
            if (this.repositoryStatus == 'Submitted' && this.readOnly) {
              this.isReadOnly = true;
            } else if (this.repositoryStatus == 'Approved' || this.repositoryStatus == 'Rejected' || this.repositoryStatus == 'Disabled') {
              this.isReadOnly = true;
            }
           const authorityType = sessionStorage.getItem('userRoleStatus');
            // if(authorityType === "APPROVER"){
            //   this.isCreator = false;
            // }
         });
  }
  uploadAccessFor = [{userType : 'Insurance Company', isChecked : false}, {userType : 'Association', isChecked : false}];
  /**
   * @function ng-on-init
   */
  ngOnInit(): void {
    this.repositoryField = null;
    this.formBuilder();
    
    

    this.behaviourSub.clearConfiguration();
    this.behaviourSub.getConfiguration().pipe(distinctUntilChanged()).subscribe((result) => {
      this.formBuilder();
      this.repositoryField = result;
      if(result != null){
        this.bindFieldData();
        this.bindDropDownOptions();
      }
    })
  }

  /**
   * @function build-form-group
   */
  buildUploadAccessFormGorup(type : string, isSelected : boolean) {
    return this.fb.group({
      userType : type,
      isChecked : isSelected
    })
  }

  /**
   * @function enable-disable-configuration
   */
  private bindDropDownOptions() {
    this.existingOptions = _.cloneDeep(this.repositoryField.listofFieldOptions); // existing options in edit flow
    if (this.repositoryField.fieldType == 'Dropdown') {
      const options = this.fieldForm.get('listofFieldOptions') as FormArray;
      options.reset();
      this.fieldForm.patchValue(this.repositoryField.listofFieldOptions);
      this.repositoryField.listofFieldOptions.forEach(opt => options.push(this.fb.group(opt)));
      this.dropDownEnable = true;
    } else {
      this.dropDownEnable = false;
    }
    this.enableDataType = this.repositoryField.fieldType === 'Text Box' ? true : false;
  }

  /**
   * @function bindFieldData
   */
  private bindFieldData() {
    this.fieldForm.controls['fieldName'].setValue(this.repositoryField.fieldName);
    this.fieldForm.controls['mandatory'].setValue(this.repositoryField.isMandatory);
    this.searchTypeConfiguration();  
    if (!this.repositoryField.dataType) {
      this.fieldForm.controls['dataType'].setValue(this.data_Type_Data[0].viewValue);
    }
    else {
      this.fieldForm.controls['dataType'].setValue(this.repositoryField.dataType);
    }
    this.fieldForm.controls['errorMessage'].setValue(this.repositoryField.errorMessage);
  }

/**
 * @function search-type-binding
 */
  private searchTypeConfiguration() {
    if(this.repositoryField.searchType != null){
      if (this.repositoryField.searchType == 'Global Search') {
        this.fieldForm.controls['globalSearch'].setValue(true);
      this.fieldForm.controls['repositorySearch'].setValue(false);
    }
    else if (this.repositoryField.searchType == 'Repository Search') {
      this.fieldForm.controls['globalSearch'].setValue(false);
      this.fieldForm.controls['repositorySearch'].setValue(true);
    }
    else if (this.repositoryField.searchType == 'Both') {
      this.fieldForm.controls['globalSearch'].setValue(true);
      this.fieldForm.controls['repositorySearch'].setValue(true);
    }
    else {
      this.fieldForm.controls['globalSearch'].setValue(false);
      this.fieldForm.controls['repositorySearch'].setValue(false);
    }
  }
  else{
    this.fieldForm.controls['globalSearch'].setValue(this.repositoryField.globalSearch);
    this.fieldForm.controls['repositorySearch'].setValue(this.repositoryField.repositorySearch);
  }
  }

  /**
   * @function formBuilder
   */
  private formBuilder() {
    this.fieldForm = this.fb.group({
      fieldName: [''],
      mandatory: [''],
      globalSearch: [''],
      repositorySearch: [''],
      dataType: [''],
      errorMessage: [''],
      uploadAccess : this.fb.array([this.buildUploadAccessFormGorup(this.uploadAccessFor[0].userType, this.uploadAccessFor[0].isChecked),
                                    this.buildUploadAccessFormGorup(this.uploadAccessFor[1].userType, this.uploadAccessFor[1].isChecked)]),
      listofFieldOptions: this.fb.array([])
    });
  }

  /**
   * @function init-dropdown-options
   */
  createOptionFormGroup() {
    return this.fb.group({
      fieldOptionName: '',
      fieldOptionIdentity : '',
    })
  }

  /**
   * @function add-new-dropdown
   * @param index
   */
  addOptionFormGroup(index : number) {
    const options = this.fieldForm.get('listofFieldOptions') as FormArray;
    options.insert(index, this.createOptionFormGroup());
  }

  /**
   * @function remove-existing-dropdown
   * @param index
   */
  deleteOptionFormGroup(index: number) {
    const options = this.dropDownData;
    const optionIdentity = options.value[index].fieldOptionIdentity;
    if(optionIdentity !== ''){
      let deletedOptionsList = [];
      let preDeletedOptions = this.deletedOptions.get(this.repositoryField.fieldIdentity);
      if(preDeletedOptions){
        deletedOptionsList.push(...preDeletedOptions);
      }
      deletedOptionsList.push(optionIdentity);
      this.deletedOptions.set(this.repositoryField.fieldIdentity, deletedOptionsList);
      // this.deletedOptions.set(emails.value[index].fieldOptionIdentity);
    }
    options.removeAt(index);
  }

  /**
   * @function event-trigger-for-collecting-dropdown-options
   * @param changedInput
   * @param index
   */
  monitorInputChange(changedInput : any, index : number){
    const optionIdentity = this.dropDownData.value[index].fieldOptionIdentity;
   if(optionIdentity !== ''){
      this.existingOptions.forEach((options : any) => {
        if(options.fieldOptionIdentity === optionIdentity && changedInput.value !== options.fieldOptionName){
          let optionIdentityList = [];
          let preAddedOptions = this.updatedOptions.get(this.repositoryField.fieldIdentity);
          if(preAddedOptions){
            optionIdentityList.push(...preAddedOptions);
          }
          optionIdentityList.push(optionIdentity);
          this.updatedOptions.set(this.repositoryField.fieldIdentity, optionIdentityList);
          return;
        }
      });
   }
  }

  /**
   * @function build-dropdown-data
   */
  get dropDownData() {
    return this.fieldForm.get('listofFieldOptions') as FormArray;
  }

  /**
   * @function build-dropdown-data
   */
  get uploadAccess() {
    return this.fieldForm.get('uploadAccess') as FormArray;
  }

  /**
   * @function update-field-search-type
   * @param event
   */
  updateFieldSearchType(event : any){
    if(this.fieldForm.controls['globalSearch'].value && this.fieldForm.controls['repositorySearch'].value){
      this.repositoryField.searchType = 'Both';
    }
    else if(!(this.fieldForm.controls['globalSearch'].value) && this.fieldForm.controls['repositorySearch'].value){
      this.repositoryField.searchType = 'Repository Search';
    }
    else if(!(this.fieldForm.controls['repositorySearch'].value) && this.fieldForm.controls['globalSearch'].value){
    this.repositoryField.searchType = 'Global Search';
    }
    else{
      this.repositoryField.searchType = null;
    }
  }
}
