import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { RepositoryField } from "src/app/models/repository-field";

@Injectable({
    providedIn: 'root'
  })
  export class RepositorySharedService {

    /**
     * @function moveToConfigurator
     */
    moveToConfigurator = new BehaviorSubject(RepositoryField);
    
    /**
     * @function get-field-configuration
     */
    getConfiguration(){
      return this.moveToConfigurator;
    }

    /**
     * @function clear-configuration
     */
    clearConfiguration(){
      this.moveToConfigurator = new BehaviorSubject(null); 
    }
  }