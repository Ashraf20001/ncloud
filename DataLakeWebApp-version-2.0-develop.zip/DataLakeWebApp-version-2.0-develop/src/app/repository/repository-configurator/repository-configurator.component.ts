import { CdkDragEnter, CdkDragExit } from '@angular/cdk/drag-drop';
import { Component, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { ActivatedRoute, Router } from '@angular/router';
import { RepositoryField } from 'src/app/models/repository-field';
import { ConfigurationComponent } from './configuration/configuration.component';
import { StagesComponent } from './stages/stages.component';
import { RepositoryService } from 'src/app/service/repository-management/repository-service';
import { HttpParams } from '@angular/common/http';
import * as _ from 'lodash';
import { ToastrService } from 'ngx-toastr';
import { MatDialog } from '@angular/material/dialog';
import { CommentsPopupComponent } from 'src/app/common/components/comments-popup/comments-popup.component';
import { AppService } from 'ncloud-common-ui';
import { AccessMappingPageDto } from 'ncloud-common-ui/lib/dto/access-Mapping-PageDto ';
import { appConst } from 'src/app/service/app.const';
import { TranslateService } from '@ngx-translate/core';
import { NotificationService } from 'src/app/service/notification.service';


@Component({
  selector: 'app-repository-configurator',
  templateUrl: './repository-configurator.component.html',
  styleUrls: ['./repository-configurator.component.scss']
})
export class RepositoryConfiguratorComponent {

  fieldconfigure_Class ="fieldconfigure"
  scheduler_Class ="scheduler";
  main_page="main-page";
  api_integration="api";
  isReadOnly = false;
  canViewSave = false;
  repoNameType:string
  enterfieldname:string
  repoForm!:FormGroup
  updatedFields = new Set([]);
  @ViewChild(ConfigurationComponent) configuration: ConfigurationComponent;
  @ViewChild(StagesComponent) stages: StagesComponent;
  appCon = appConst;
  canViewSubmit = false;
  canViewDraft  = false;
  canViewCancel = true;

  isCloneFlow  = false;
  repositoryStatus  = '';
  repositoryName = '';
  repositoryID  = '';
  repositoryIdentity = '';
  repoVersion;
  fieldConfiguratorList: any[] = [];
  viewableActions : string[] = [];
  isRepoCloned = false;
  consolidatedOptionsList: any[] = [];

  userRoleStatus: string;
  isCreator =false;
  actionBtn: string;
  isCommented =false;
  uploadAccess: any;
  canViewPage: any = true;
  pageInfo: any;
  temp: string[];
  superAdmin: string;
  repositoryFieldValidate: any;
  currentEvent: string;
  repositoryFormMap = new Map();
  uploadAccessFor: any;
  fetchedFieldsList = [];
  // pageStatus: any;

  /**
   * @function constructor
   * @param router
   * @param route
   * @param formBuilder
   * @param repositoryService
   */
  constructor(private router: Router, private route: ActivatedRoute,public dialog: MatDialog, private appService : AppService,
    private formBuilder: FormBuilder,private notificationService: NotificationService, 
   private repositoryService: RepositoryService, private toastr : ToastrService, public translate: TranslateService) {

      this.route.queryParams.subscribe(params => {
        this.isCloneFlow = (params['isClone']) ? params['isClone'] : false;
        this.repositoryStatus = params['status'];
        // this.pageStatus = params['pagestatus'];
        if(params['isDisabled'] == 'false' || this.isCloneFlow || params['repoInit'] == 'true'){
          this.getPrivilege();
        }else{
          this.actionButtons = [];
        }
    });

    this.route.params.subscribe(param => {
      this.repositoryIdentity = param['identity'];
      if(this.repositoryIdentity){
      const params = new HttpParams().set("repositoryIdentity", this.repositoryIdentity);
        this.getfieldsRepository(params);
      }
    })

      this.appService.getPageAccess(appConst.PAGE_NAME.REPOSITORY.CREATE_NEW_REPOSITORY.PAGE_IDENTITY).subscribe((response: any) => {
        if(response){
          let content = response.content;
          this.canViewPage = content.isEnabled;
        }
      });

      const params =  new HttpParams().set('identity', this.repositoryIdentity);
      this.notificationService.updateNotification(params).subscribe((data: any) => {
        console.log("Notifiication Read Updated "+data.content)
      });
  }

  actionButtons : buttonDto[] = [
    {
    name: 'Cancel',
    style: 'cancel-btn',
    image: null,
  }]

  creatorButtons: buttonDto[] = [
  {
    name: 'Save As Draft',
    style: 'black-btn',
    image: null
  }, {
    name: 'Submit',
    style: 'black-btn',
    image: null
  }]

  approverButtons: buttonDto[] = [
    {
    name: 'Request To Modify',
    style: 'reqbutton',
    image: null
  },
  {
    name: 'Reject',
    style: 'rejected_btn',
    image: '/assets/repository_icon/rejected.svg'
  },
  {
    name: 'Approve',
    style: 'approved_btn',
    image: '/assets/repository_icon/approved.svg'
  }]


  superAdminAccessButtons: buttonDto[] = [{
    name: 'Cancel',
    style: 'cancel-btn',
    image: null
  },
    {
    name: 'Save As Draft',
    style: 'black-btn',
    image: null
  }, {
    name: 'Approve',
    style: 'approved_btn',
    image: '/assets/repository_icon/approved.svg'
  }]

  privelegeDto : string[] = [];

  mapper : privelegeDto[] = [
    {
      privelegeName: 'Draft Repository',
      displayName: 'Save As Draft'
    },
    {
      privelegeName: 'Submit Repository',
      displayName: 'Submit'
    },
    {
      privelegeName: 'Reject Repository',
      displayName: 'Reject'
    },
    {
      privelegeName: 'Approve Repository',
      displayName: 'Approve'
    },
    {
      privelegeName: 'Request To Modify',
      displayName: 'Request To Modify'
    }
]


  private getfieldsRepository(params: HttpParams) {
    this.repositoryService.getRepositoryDetails(params).subscribe((response: any) => {
      this.repositoryIdentity = response.repositoryIdentity;
      this.repositoryStatus = response.repositoryStatus;
      this.uploadAccess = response.uploadAccess;
      this.isCommented = response.isCommented;
      if (this.isCommented && this.repositoryStatus == 'Submitted') {
        this.actionButtons.splice(0, 1);
      }
      this.configuration.uploadAccessFor.map(ele => {
        if (ele.userType == response.uploadAccess || response.uploadAccess == 'Both') {
          ele.isChecked = true;
        }
      });
      this.bindDataForRepositoryForm(response);
    });
  }

  getPrivilege(){
    this.appService.getPrivilegeForPage(appConst.PAGE_NAME.REPOSITORY.CREATE_NEW_REPOSITORY.PAGE_ID).subscribe((res: any)=>{
      this.pageInfo = res.content;
      this.privelegeDto = this.pageInfo.filter((prv) => prv.isEnabled == true).map((privelege) => privelege.privilegeName);
    // this.privelegeDto = this.pageInfo.map((privelege) => privelege.privilegeName);
    this.temp = this.mapper.filter((x) => this.privelegeDto.includes(x.privelegeName)).map((y) => y.displayName)

    if (!this.repositoryIdentity || this.isCloneFlow) {
      this.actionButtons.push(...this.creatorButtons.filter(item => this.temp.includes(item.name)))
    }else{
      if(this.repositoryStatus == 'Drafted'){
        this.actionButtons.push(...this.creatorButtons.filter(item => this.temp.includes(item.name)))
        this.actionButtons.map(item => item.name == 'Save As Draft' ? item.name = 'Save' : item);
      }
      else if (this.repositoryStatus == 'Submitted') {
        this.actionButtons = this.approverButtons.filter(item => this.temp.includes(item.name))
        if(this.actionButtons.length == 0){
          this.isReadOnly = true;
          const queryParams = { readOnly : this.isReadOnly};
          this.router.navigate([], {relativeTo : this.route, queryParams, queryParamsHandling : 'merge'})
        }
      }
      else if(this.repositoryStatus == 'Approved' || this.repositoryStatus == 'Rejected'){
        this.isReadOnly = true;
        this.actionButtons = [];
      }
    }
  })
  }

  /**
   * @function bind-default-values
   * @param response
   */
  private bindDataForRepositoryForm(response: any) {
    this.repoForm.controls['repoName'].setValue(response.repositoryName);
    this.repoForm.controls['repoId'].setValue(response.repositoryId);
    this.repoForm.controls['repoDesc'].setValue(response.repositoryDesc);
    // this.fetchedFieldsList = _.cloneDeep(response.fieldsConfiguratorDto);
    this.stages.fieldList = [];
    this.stages.fieldList.push(...response.fieldsConfiguratorDto);
    this.repositoryName = response.repositoryName;
    this.repositoryID = response.repositoryId;
    this.repoVersion=response.repositoryVersion;
    this.stages.emitSelectedField(this.stages.fieldList[0]);
    this.stages.fieldList.forEach(ele => {
      if (ele.fieldType == 'Dropdown') {
        ele.icon = '/assets/repository_icon/drop_down.svg';
      } else if (ele.fieldType == 'Text Box') {
        ele.icon = '/assets/Text_Box.svg';
      } else if (ele.fieldType == 'Date') {
        ele.icon = '/assets/repository_icon/date.svg';
      }
    });
    this.fetchedFieldsList = _.cloneDeep(response.fieldsConfiguratorDto);
    // this.orderizeFields();
  }

  /**
   * TAB CHANGE EVENT
   * @param event
   *
   */
  noReturnPredicate() {
    return false;
  }
  onSourceListExited(event: CdkDragExit<any>) {
    this.FiledItem_Data.splice(event.container.data(event.item) + 1, 0, { ...event.item.data, temp: true });
  }
  onSourceListEntered(event: CdkDragEnter<any>) {
    remove(this.FiledItem_Data, { temp: true });
  }


  tabs: TabDTO[] = [
    {
      name: 'Manage Repository',
      url: 'field-configure',
      class: 'fieldconfigure'
    },
    {
      name: 'Scheduler',
      url: 'scheduler',
      class: 'scheduler'
    },
    {
      name: 'API Integration',
      url: 'api-integration',
      class: 'api'
    }
  ];

  FiledItem_Data: RepositoryField[] = [
    {
      fieldId: null, icon: '/assets/Text_Box.svg', fieldName: 'Text Box', fieldType: 'Text Box',
      isMandatory: false, dataType: '', posistion: null, errorMessage: '', listofFieldOptions: null, searchType : null,
      minlength: null, maxlength: null, regex: null, tempId:null, fieldIdentity:null
    },
    {
      fieldId: null, icon: '/assets/repository_icon/drop_down.svg',fieldName: 'Drop Down', fieldType: 'Dropdown', searchType : null,
      isMandatory: false, dataType: '', posistion: null, errorMessage: '', listofFieldOptions: [{fieldOptionName:'',fieldOptionIdentity:null}],
      minlength: null, maxlength: null, regex: null, tempId:null, fieldIdentity:null
    },
    {
      fieldId: null, icon: '/assets/repository_icon/date.svg', fieldName: 'Date', fieldType: 'Date', searchType : null,
      isMandatory: false, dataType: '', posistion: null, errorMessage: '', listofFieldOptions: null,
      minlength: null, maxlength: null, regex: null, tempId:null, fieldIdentity:null
    },
  ]

  ngOnInit():void{
    this.repositoryFormMap.set('repoName', 'RepositoryName');
    this.repositoryFormMap.set('repoId', 'RepositoryID');
    this.repositoryFormMap.set('repoDesc', 'RepositoryDescription');
    this.repoForm = this.formBuilder.group({
      repoName: ["",[Validators.required, Validators.maxLength(28), Validators.pattern('^[a-zA-Z\\s]+$')]],
      repoId: ["",[Validators.required, Validators.maxLength(8), Validators.pattern(/^[0-9.]+$/)]],
      repoDesc: ["",[Validators.required, Validators.pattern('^[a-zA-Z\\s]+$')]]
    })
    this.userRoleStatus = sessionStorage.getItem('userRoleStatus');
    this.route.queryParams.subscribe((querParams: any) => {
      this.repositoryFieldValidate = querParams['repositoryStatus']
    })

    if(sessionStorage.getItem('userRoleStatus') === 'CREATOR'){
       if(this.repositoryFieldValidate === 'Submitted'){
        this.isReadOnly = true;
        this.isCreator = true;
       }else{
        this.isReadOnly = false;
        this.isCreator = false;
       }
    }

    if(this.repositoryStatus == 'Disabled'){
      this.isReadOnly = true;
    }


  }

  SuperAdminAccess() {
    if (this.superAdmin === "Settings") {
      this.actionButtons.push(...this.superAdminAccessButtons);
    }
  }


  /**
   * @function tab-change-handler
   * @param event
   */
  tabChange(event: MatTabChangeEvent): void {
    const tab = this.tabs.find((t: TabDTO) => t.name === event.tab.textLabel);
    if(tab) {
      this.router.navigate([tab.url], { relativeTo: this.route });
    }
  }

  /**
   * @function route-card-view
   */
  routeToRepositoryCardView(){
      this.router.navigate(['repository'])
    }
    

  

  openDialog():void{
    const dialog = this.dialog.open(CommentsPopupComponent, {
     width: '65vw', height: '70vh',
     disableClose: true,
      data:{
        repositoryIdentity: this.repositoryIdentity,
        isCreator: this.isCreator,
        action: 'Request to modify'
      }

    });
    dialog.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');

    });
  }

  /**
   * @function collect-configuration-data
   * @param field
   */
  fetchUnSavedField(field:RepositoryField){
    /** FETCH & ADD UNSAVED FIELD FOR SAVE/UPDATE */
    let uploadAccessControl = this.configuration.fieldForm.controls['uploadAccess'].value;
    this.configuration.uploadAccessFor = uploadAccessControl;
    const tempField = _.cloneDeep(field);
    field.fieldName = this.configuration.fieldForm.controls['fieldName'].value;
    field.isMandatory = this.configuration.fieldForm.controls['mandatory'].value;
    // field.posistion = tempField.position;
    this.collectDataForSearchType(field);
    field.dataType = this.configuration.fieldForm.controls['dataType'].value;
    field.errorMessage = this.configuration.fieldForm.controls['errorMessage'].value;
    field.listofFieldOptions = this.configuration.fieldForm.controls['listofFieldOptions'].value;
    if(field.fieldIdentity){
      const isEqual = _.isEqual(tempField,field);
      if(!isEqual){
        this.updatedFields.add(field.fieldIdentity);
      }
    }
  }

  /**
   * @function collect-serach-type
   * @param field
   */
  private collectDataForSearchType(field: RepositoryField) {
    if (this.configuration.fieldForm.controls['globalSearch'].value && this.configuration.fieldForm.controls['repositorySearch'].value) {
      field.searchType = 'Both';
    }
    else if (!(this.configuration.fieldForm.controls['globalSearch'].value) && this.configuration.fieldForm.controls['repositorySearch'].value) {
      field.searchType = 'Repository Search';
    }
    else if (!(this.configuration.fieldForm.controls['repositorySearch'].value) && this.configuration.fieldForm.controls['globalSearch'].value) {
      field.searchType = 'Global Search';
    }
    else {
      field.searchType = null;
    }
  }

  get repoName(){
    return this.repoForm.get('repoName')
  }

  get repoId(){
    return this.repoForm.get('repoId')
  }

  get repoDesc(){
    return this.repoForm.get('repoDesc')
  }

  /**
   * @function build-repository
  */
  buildRepository(status: string) {
    const fieldConfiguratorDtoList: FieldConfiguratorDto[] = this.initDtoBuild();
    var fieldRepositoryDto: FieldRepositoryDto = this.buildRepositoryDto(fieldConfiguratorDtoList, status);
    return fieldRepositoryDto;
  }

  getUpdatedRepositoryName(event){
    if(event){
      const params = new HttpParams().set("repositoryIdentity", event);
        this.getfieldsRepository(params);
    }
  }

  /**
   * @function repository-validation
   */
  private repositoryValidator() {
    let isDraft = false;
    if(this.currentEvent == 'Save As Draft' || this.currentEvent == 'Save'){
      isDraft = true;
    }
    if (this.repoForm.status !== 'VALID') {
      for(let formControl of Object.keys(this.repoForm.controls)){
        const control = this.repoForm.get(formControl);
        const fieldName = this.repositoryFormMap.get(formControl);
        if (control.errors?.['required']) {
          this.toastr.error( this.translate.instant('Toaster_error.'+fieldName)  + " " +this.translate.instant('Toaster_error.is_mandatory'));
          return true;
        }
        else if (control.errors?.['pattern']) {
          this.toastr.error(this.translate.instant('Toaster_error.'+fieldName) + " " +this.translate.instant('Toaster_error.is_invalid'));
          return true;
        }
      }
    }
    if (this.configuration.repositoryField != null) {
      this.fetchUnSavedField(this.stages.selectedField);
    }
    this.fieldOrderChecker();
    if (this.stages.fieldList.length > 0 || isDraft) {
      let fields = [...this.stages.fieldList.filter(item => item.fieldName.trim().length != 0).map((item: any) => item.fieldName.toLocaleLowerCase())];
      const fieldSet = [...new Set(fields)];
      if (fields.length != fieldSet.length && !isDraft) {
        this.toastr.error(this.translate.instant('Toaster_error.field_unique'));
        return true;
      }
      for (let field of this.stages.fieldList) {
        if ((field.fieldName == '' || field.fieldName.length < 1) && !isDraft) {
          // this.toastr.error("Invalid Field Name  at " + this.getOrdinal(field.posistion) + " Position");
          this.toastr.error(this.translate.instant("Toaster_error.Please fill out all Field Names")); // To Be Discussed!!!!!!
          return true;
        } else if (field.fieldType == 'Dropdown') {
          let optionList = [];
          optionList = field.listofFieldOptions.filter(option => option.fieldOptionName == '');
          if (optionList.length > 0 && !isDraft) {
            this.toastr.error(this.translate.instant("Toaster_error.Please provide Options for field ")+ field.fieldName);
            return true;
          }
          // Duplicate Option check
          const uniqueValues = new Set();
          let hasDuplicates = false;
          let duplicateValue;
          let duplicateOption = field.listofFieldOptions.filter(option => option.fieldOptionName);
          for (const value of duplicateOption) {
            const lowercaseValue = value.fieldOptionName.toLowerCase();

            if (uniqueValues.has(lowercaseValue)) {
              duplicateValue = value.fieldOptionName;
              hasDuplicates = true;
              break;
            }
            uniqueValues.add(lowercaseValue);
          }
          if (hasDuplicates) {
            this.toastr.error(this.translate.instant("Toaster_error.Duplicate_Option_msg1")+" " + duplicateValue +" "+ this.translate.instant("Toaster_error.Duplicate_Option_msg2"));
            return true;
          }
        }
      }
    } else {
      this.toastr.error(this.translate.instant('Toaster_error.Please Add Fields to Save Repository'));
      return true;
    }
    return false;
  }

  /**
   *
   */
  private fieldOrderChecker() {
    this.orderizeFields();
    const existingFields: any[] = this.stages.fieldList.filter(x => x.fieldIdentity != null); // exisiting fields
    if (existingFields) {
      existingFields.forEach(exsFld => {
        let mstrFld = this.fetchedFieldsList.filter(field => field.fieldIdentity == exsFld.fieldIdentity);
        const isEqual = _.isEqual(mstrFld[0], exsFld);
        if ((!isEqual && !this.updatedFields.has(exsFld))) {
          this.updatedFields.add(exsFld.fieldIdentity);
        }
      });
    }
  }

  /** */
  private orderizeFields() {
    for (let i = 0; i < this.stages.fieldList.length; i++) {
      const field = this.stages.fieldList[i];
      field.posistion = i + 1;
    }
  }

  /**
   * @function fetch-ordinal
   * @param number
   * @returns
   */
  getOrdinal(number: number): string {
    const lastDigit = number % 10;
    const secondLastDigit = Math.floor(number / 10) % 10;

    if (secondLastDigit === 1 || lastDigit === 0 || lastDigit >= 4) {
      return number + "th";
    } else if (lastDigit === 1) {
      return number + "st";
    } else if (lastDigit === 2) {
      return number + "nd";
    } else if (lastDigit === 3) {
      return number + "rd";
    }else{
      return number + "th";
    }
  }

  /**
   * @function build-repository-dto
   * @param fieldConfiguratorDtoList
   * @param status
   * @returns
   */
  private buildRepositoryDto(fieldConfiguratorDtoList: FieldConfiguratorDto[], status: string): FieldRepositoryDto {
    this.getUploadAccessFor();
    return {
      repositoryName: this.repoForm.value.repoName,
      repositoryId: this.repoForm.value.repoId,
      repositoryDesc: this.repoForm.value.repoDesc,
      repositoryIdentity: this.repositoryIdentity,
      uploadAccess : this.uploadAccess,
      isCloned: null,
      fieldsConfiguratorDto: fieldConfiguratorDtoList,
      repositoryStatus: status,
      deletedFields: this.stages.deletedFields,
      action: status,
      effectiveTo : null
    };
  }

  /**
   * @function upload-access-for-repository
   */
  private getUploadAccessFor() {
    let uploadAccessList = [];
    uploadAccessList = this.configuration.uploadAccessFor.filter((control: any) => control.isChecked == true);
    if (uploadAccessList.length == 2) {
      this.uploadAccess = 'Both';
    } else if (uploadAccessList.length === 1) {
      this.uploadAccess = uploadAccessList[0].userType;
    } else {
      this.uploadAccess = 'None';
    }
  }

/**
 * @function build-field-configuration
 */
  private initDtoBuild() {
    const fieldList = this.stages.fieldList;
    const updatedFields = this.buildUpdatedFields();
    const fieldConfiguratorDtoList: FieldConfiguratorDto[] = [];
    if (fieldList.length >= 1) {
      this.iterateFieldsToBeUpdated(updatedFields, fieldConfiguratorDtoList);
    }
    return fieldConfiguratorDtoList;
  }

  /**
   * @function iterate-fields-update
   * @param updatedFields
   * @param fieldConfiguratorDtoList
   */
  private iterateFieldsToBeUpdated(updatedFields: any[], fieldConfiguratorDtoList: FieldConfiguratorDto[]) {
    for (let field of updatedFields) {
      let fieldConfiguratorDto: FieldConfiguratorDto = buildRawFieldConfiguratorDto();
      if(field.fieldType == 'Dropdown'){
        this.checkForOptionsUpdate(field);
      }
      this.buildFieldConfigurator(fieldConfiguratorDto, field);
      fieldConfiguratorDtoList.push(fieldConfiguratorDto);
    }

    /**
     * @function raw-field-configurator
     * @returns
     */
    function buildRawFieldConfiguratorDto(): FieldConfiguratorDto {
      return {
        fieldId: null,
        fieldName: null,
        fieldType: null,
        dataType: null,
        listofFieldOptions: null,
        isMandatory: null,
        searchType: null,
        errorMessage: null,
        fieldIdentity: null,
        posistion: 0,
        identity: null,
        deletedOptions: null
      };
    }
  }

  /**
   * @function check-for-options-update
   * @param field
   */
  private checkForOptionsUpdate(field: any) {
    if (this.repositoryIdentity) {
      this.consolidatedOptionsList = [];
      let dropDownOptions = this.configuration.updatedOptions;
      let updatedOptions = dropDownOptions.get(field.fieldIdentity);
      if (updatedOptions) {
        this.consolidatedOptionsList = field.listofFieldOptions.filter(options => updatedOptions.includes(options.fieldOptionIdentity));
      }
      let unTrackedOptions = field.listofFieldOptions.filter(newOptions => newOptions.fieldOptionIdentity == '');
      if (unTrackedOptions) {
        this.consolidatedOptionsList.push(...unTrackedOptions);
      }
    }
  }

  /**
   * @function build-field-configurator
   * @param fieldConfiguratorDto
   * @param field
   */
  private buildFieldConfigurator(fieldConfiguratorDto: FieldConfiguratorDto, field: any) {
    fieldConfiguratorDto.fieldId = field.fieldId;
    fieldConfiguratorDto.fieldName = field.fieldName;
    fieldConfiguratorDto.fieldType = field.fieldType;
    fieldConfiguratorDto.dataType = field.dataType;
    fieldConfiguratorDto.isMandatory = field.isMandatory;
    fieldConfiguratorDto.errorMessage = field.errorMessage;
    fieldConfiguratorDto.posistion = field.posistion;
    fieldConfiguratorDto.searchType = field.searchType;
    fieldConfiguratorDto.listofFieldOptions = ( !field.fieldIdentity || this.isRepoCloned) ? field.listofFieldOptions : this.consolidatedOptionsList;
    fieldConfiguratorDto.fieldIdentity = field.fieldIdentity;
    fieldConfiguratorDto.deletedOptions = this.repositoryIdentity ? this.configuration.deletedOptions.get(field.fieldIdentity) : [];
  }

/**
 * @function approve-repository
 * @param action
 */
  approve(action: string) {
    if (this.repositoryValidator()) {
      return;
    }
    const fieldRepositoryDto: FieldRepositoryDto = this.buildRepository(action);
    this.repositoryService.approveRepository(fieldRepositoryDto).subscribe((response: any) => {
      this.afterReponse('Toaster_success.Repository Approved Successfully');
    });
  }

  /**
   * @function reject-repository
   * @param action
   */
  reject(action : string){
    if (this.repositoryValidator()) {
      return;
    }
    const params = new HttpParams()
    .set("repositoryIdentity",this.repositoryIdentity)
    .set("action",action);
    this.repositoryService.rejectRepository(params).subscribe((response: any) => {
      this.afterReponse('Toaster_success.Repository Rejected Successfully');
    });
  }

  /**
   * @function save-submit-clone-repository
   * @param action
   */
  saveOrSubmit(action: string) {
    if (this.repositoryValidator()) {
      return;
    }
    if (this.repositoryIdentity && !this.isCloneFlow) {
       /** SAVE AS DRAFT/ SUBMIT - NORMAL UPDATE FLOW */
      const fieldRepositoryDto: FieldRepositoryDto = this.buildRepository(action);
      this.repositoryService.saveRepository(fieldRepositoryDto).subscribe((response: any) => {
        if(action==="Submitted"){
          this.afterReponse('Toaster_success.repo_submit');
        } else {
          this.afterReponse('Toaster_success.repo_success');
        }
        
      });
    } else if (this.isCloneFlow) {
      /** SAVE AS DRAFT/SUBMIT - CLONE UPDATE FLOW */
      const updatedFields = this.buildUpdatedFields();
      if (this.repositoryName !== this.repoName.value || this.repositoryID !== this.repoId.value) {
        this.isRepoCloned = false;
      }
      else if (updatedFields.length > 0 || this.stages.deletedFields.length > 0) {
        this.isRepoCloned = true;
      } else {
        this.toastr.error(this.translate.instant('Toaster_error.Please do some changes to clone the repository'));
        return;
      }
      this.cloneRepository(action);
    }
    else {
      /** CREATE NEW REPOSITORY - SAVE AS DRAFT/SUBMIT */
      this.submit(action);
    }
  }

  /**
   * @function clone-repository
   * @param action
   */
  private cloneRepository(action: string) {
    this.cleanFieldAndDropdownOptions();
    const fieldConfiguratorDto = this.buildRepositoryDto(this.stages.fieldList, action);
    fieldConfiguratorDto.isCloned = this.isRepoCloned;
    this.repositoryService.cloneRepository(fieldConfiguratorDto).subscribe((response: any) => {
      this.afterReponse('Toaster_success.Repository Cloned Successfully');
    });
  }

  /**
   * @function after-response
   * @param message
   */
  private afterReponse(message : string) {
    this.toastr.success(this.translate.instant((message)));
    this.routeToRepositoryCardView();
  }

  /**
   * @function clean-fields
   */
  private cleanFieldAndDropdownOptions() {
    /** CLEAR FIELD IDENITY -  TO CREATE NEW CLONE */
    this.stages.fieldList.map(ele => {
      ele.fieldIdentity = null;
      ele.listofFieldOptions.map(ele => ele.fieldOptionIdentity = null);
    });
  }

  /**
   * @function build-updated-fields
   * @returns
   */
  private buildUpdatedFields() {
    const fields = this.stages.fieldList;
    let editedFields = [];
    editedFields.push(...this.updatedFields);
    const updatedFields = fields.filter(field => editedFields.includes(field.fieldIdentity) || field.fieldIdentity == null);
    return updatedFields;
  }

  /**
   * @function submit-repository
   * @param action
   */
  submit(action : string){
    const fieldRepositoryDto: FieldRepositoryDto = this.buildRepository(action);
    this.repositoryService.submitRepository(fieldRepositoryDto).subscribe((response: any) => {
      if(action === "Drafted"){
           this.afterReponse('Toaster_success.Repository saved as draft successfully');
        }else{
           this.afterReponse('Toaster_success.Repository submitted successfully');
       }

    });
  }

  /**
   * @function event-handler
   * @param event
   */
  eventHandler(event : any){
    this.currentEvent = event;
    switch (event) {
      case 'Cancel':
        this.routeToRepositoryCardView();
        break;

      case 'Save As Draft':
        this.saveOrSubmit('Drafted');
        break;

      case 'Save':
        this.saveOrSubmit('Drafted');
        break;

      case 'Submit':
        this.saveOrSubmit('Submitted');
        break;

      case 'Approve':
        this.approve('Approved');
        break;

      case 'Reject':
        this.reject('Rejected');
        break;

      case 'Request To Modify':
        this.openDialog();
        break;

      default:
        break;
    }
  }
}

export interface FieldRepositoryDto{
  repositoryName: string,
  repositoryId:String,
  repositoryDesc:string,
  repositoryIdentity:string,
  uploadAccess:string,
  repositoryStatus:string,
  isCloned : boolean;
  deletedFields:string[],
  fieldsConfiguratorDto :FieldConfiguratorDto[],
  action:string
  effectiveTo:any;
}
export interface FieldConfiguratorDto{
  fieldId:any;
  fieldName:string;
  fieldType:string;
  dataType:string;
  listofFieldOptions:any[];
  isMandatory:Boolean;
  searchType:string;
  errorMessage:string;
  fieldIdentity:string;
  posistion:number;
  identity:string;
  deletedOptions:string[];
}

export interface privelegeDto{
  displayName : string;
  privelegeName : string;
}


export interface TabDTO {
  name: string;
  url: string;
  class: string;
}

export interface buttonDto {
  name : string;
  style : string;
  image : string;
}
function remove(FiledItem_Data: RepositoryField[], arg1: { temp: boolean; }) {
  throw new Error('Function not implemented.');
}


