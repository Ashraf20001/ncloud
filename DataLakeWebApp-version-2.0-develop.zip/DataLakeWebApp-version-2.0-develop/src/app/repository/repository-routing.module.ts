import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RepositoryConfiguratorComponent } from './repository-configurator/repository-configurator.component';
import { AuthGuard } from '../service/guard/auth.guard';

const routes: Routes = [
  {
    path:'',
    loadChildren: () => import('./manage-repository/manage-repository.module').then(m => m.ManageRepositoryModule)
  },
  {
    path: 'configure-repository',
    component : RepositoryConfiguratorComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'edit-repository/:identity',
    component : RepositoryConfiguratorComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'clone-repository/:identity',
    component : RepositoryConfiguratorComponent,
    canActivate: [AuthGuard]
  },
  {
    path: '',
    redirectTo: 'manage-repository',
    pathMatch: 'full',
  }


];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RepositoryRoutingMoudle { }


