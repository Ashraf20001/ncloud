import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatIconModule } from "@angular/material/icon";
import { TranslateModule } from "@ngx-translate/core";
import { RepositoryRoutingMoudle } from "./repository-routing.module";
import { DemoMaterialModule } from "../common/components/material-module";
import { RepositoryComponent } from "./repository.component";
import { RepositoryfigurationMainModule } from "./repository-configurator/repository-configurator.module";
import { BulkUploadFileComponent } from './bulk-upload/bulk-upload-file/bulk-upload-file.component';
import { RenameRepositoryComponent } from './repository-configurator/stages/rename-repository/rename-repository.component';
import { TotalRecordsComponent } from './bulk-upload/total-records/total-records.component';
import { UploadFileHistoryPopUpComponent } from './bulk-upload/upload-file-history-pop-up/upload-file-history-pop-up.component';
import { CustomDirectiveModule } from "../common/directives/custom-directive.module";
import {SchedulerModule} from "./manage-repository/scheduler/scheduler.module";
import {SchedulerRoutingMoudle} from "./manage-repository/scheduler/scheduler-routing.module";
import { CustomInputDirective } from "../common/directives/custom-input.directive";



@NgModule({
  declarations:[
    RepositoryComponent,
    // RenameRepositoryComponent,
    BulkUploadFileComponent,
    TotalRecordsComponent,
    UploadFileHistoryPopUpComponent,
    // CustomInputDirective

  ],
  imports:[
    CommonModule,MatIconModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule,
    RepositoryRoutingMoudle,
    DemoMaterialModule,
    RepositoryfigurationMainModule,
    CustomDirectiveModule,
  ]
})
export class RepositoryModule{

}
