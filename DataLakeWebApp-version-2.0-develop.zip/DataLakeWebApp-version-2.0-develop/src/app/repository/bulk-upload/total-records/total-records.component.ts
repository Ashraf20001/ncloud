import { AfterViewInit, ChangeDetectorRef, Component, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { FileTypeEnum } from 'src/app/models/report-loss-dto/FileTypeEnum';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { FilterOrSortingVo } from 'src/app/models/Filter-dto/filter-object-backend';
import { HeaderService } from 'src/app/service/header/header.service';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { I } from '@angular/cdk/keycodes';
import { Subject, Subscription, debounceTime, interval, tap } from 'rxjs';
import { BulkUpload } from 'src/app/common/enum/enum';
import { ToastrService } from 'ngx-toastr';
import { zip } from 'rxjs';
import { updateFileList } from '../bulk-upload-file/bulk-upload-file.component';
import { BulkUploadService } from 'src/app/service/bulk-upload/bulk-upload.service';
import { BulkUploadHistoryDto } from 'src/app/models/user-role-management/BulkUploadHistoryDto';
import { CustomSortingVo } from '../../../models/Filter-dto/CustomSortingVo';
import { HttpParams } from '@angular/common/http';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { AccessMappingPageDto } from 'ncloud-common-ui/lib/dto/access-Mapping-PageDto ';
import { appConst } from 'src/app/service/app.const';
import { AppService } from 'ncloud-common-ui';
import { TranslateService } from '@ngx-translate/core';


export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  status: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, name: 'Hydrogen', weight: 1.0079, status: 'Active'},
  {position: 2, name: 'Helium', weight: 4.0026, status: 'Inactive'},
  {position: 3, name: 'Lithium', weight: 6.941, status: 'Active'},
  {position: 4, name: 'Beryllium', weight: 9.0122, status: 'Active'},
  {position: 5, name: 'Boron', weight: 10.811, status: 'Active'},
  {position: 6, name: 'Carbon', weight: 12.0107, status: 'Active'},
  {position: 7, name: 'Nitrogen', weight: 14.0067, status: 'Inactive'},
  {position: 8, name: 'Oxygen', weight: 15.9994, status: 'Inactive'},
  {position: 9, name: 'Fluorine', weight: 18.9984, status: 'Inactive'},
  {position: 10, name: 'Neon', weight: 20.1797, status: 'Inactive'},
];

@Component({
  selector: 'app-total-records',
  templateUrl: './total-records.component.html',
  styleUrls: ['./total-records.component.scss']
})



export class TotalRecordsComponent implements AfterViewInit {
  bulkUploadHistoryDto : BulkUploadHistoryDto = new BulkUploadHistoryDto();

  tempColumns: header[] = [];
  dataSource: any;

  file: File = null;
  totalLength: number;
  pagesize = 7;
  minLength = 0;
  maxLength = 7;
  endingIndex =7;
  ZERO = 0;
  TEN = 10;
  SEVEN = 7;
  fileNameList: updateFileList[] = [];
  browseFile = false;
  filename : string;
  data: any[];
  error: boolean = true ;
  success: boolean;
  totalCount: number;
  errorCount: number;
  successCount: number;
  bulkRevoke: boolean;
  bulkUpload = true;
  download=true;
  filterVo: FilterOrSortingVo[] = [];
  records : string = this.translate.instant('Upload.errors');
  count : number = 0;

  errorSuccessData: any;
  maximum: number;
  remainder: number;
  Error_Msg=false;
  currentRoute: string;
  bulkUploadId: string;
  dataNotFound: boolean;
  errorFieldArray:any[]=[];
  isAscending=false;
  repositoryName:any;
  pageChangedEvent = new Subject<number>();


  paperService: any;
  bulkRevokeService: any;
  service: any;
  status: boolean = true;
  bulkUploadCount: any;
  identity:any;
  bulkUploadList: any;
  displayedColumns: string[];
  totalBulkUploadList: any;
  fieldMapperList: any;
  columnName: string;
  bulkUploadIdentity: string;
  customSortingVo: CustomSortingVo[] = [];
  repoId: any;
  uploadStatus: string;
  private subscription: Subscription;
  companyCardPageAccessMap: AccessMappingPageDto;
  pageInfo: any;
  appCon = appConst;
  isPageAccess = false;
  customPageIndex: number = 0;
  showStatus: string;
  nodata_center=false;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  repositoryStatus: any;
  disableButtons: boolean = false;

  constructor( private paginatorName: MatPaginatorIntl,
    private detector: ChangeDetectorRef, private route: Router,
    private activateRoute: ActivatedRoute,public translate:TranslateService,private appService: AppService,private ngxLoader: NgxUiLoaderService,private toaster: ToastrService,private tosterservice:ToastrService,private bulkUploadService:BulkUploadService, private headerService:HeaderService) {
      this.bulkUpload = this.getCurrentUrl();
    if (paginatorName) {
      if(this.paginatorName) {
        this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
      }

    }
    this.activateRoute.queryParams.subscribe((params) => {
      this.bulkUploadId = params['identity'];
      this.repoId = params['repoId'];
      this.bulkUploadIdentity = this.bulkUploadId;
      this.identity = this.bulkUploadId;
      this.filename = params['filename'];
      this.repositoryName = params['repoName']
      this.repositoryStatus = params['repostatus']

    })


  }


  ngAfterViewInit(): void {

    if(this.paginatorName) {
      this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    }
  }


  ngOnInit(): void {
    this.getPageAccessData();
    this.pageChangedEvent.pipe(debounceTime(300)).subscribe((data: number) => {
      this.changePageIndex();

    });

    this.translate.onLangChange.subscribe(() => {
      if (this.paginator) {
        this.paginator._intl.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
        this.paginator._changePageSize(this.paginator.pageSize);
        this.detector.detectChanges();
      }
    });
    if(this.paginatorName) {
      this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    }
  }




   /**
   * Page Access
   */
   getPageAccessData(): void {
    this.appService.getPageAccess(appConst.PAGE_NAME.BULKUPLOAD.BULK_UPLOAD.PAGE_IDENTITY).subscribe((response: any) => {
      this.companyCardPageAccessMap = response.content;
      this.isPageAccess = this.companyCardPageAccessMap.isEnabled;
      if(this.isPageAccess) {
        this.ngxLoader.start();
        if (this.bulkUploadIdentity) {
         this.getBulkUploadCounts(this.bulkUploadIdentity);
        }

        this.subscription = interval(5000).subscribe(() => {
          if (this.uploadStatus === 'Completed' || this.uploadStatus === 'Failed') {
            this.ngxLoader.stop();
            this.subscription.unsubscribe();
          }
            this.getBulkUploadCounts(this.bulkUploadIdentity);
            this.getTotalRecordsCount(this.identity,this.status,this.minLength,this.customSortingVo, false);
            this.getBulkUploadList(this.identity,this.minLength,this.status,this.maxLength,this.customSortingVo);
            this.error = true;
            this.records = this.error ?  this.translate.instant('Upload.errors') : this.translate.instant('Upload.success');
            this.download = this.error ? true : false;
            this.count = this.error ? this.errorCount : this.successCount;
        });
        this.getPrivilege();
      }
    });
  }

  /**
   * @returns
   */
  getPrivilege(){
    this.appService.getPrivilegeForPage(appConst.PAGE_NAME.BULKUPLOAD.BULK_UPLOAD.PAGE_ID).subscribe((res: any)=>{
      this.pageInfo = res.content;
    });
  }

  /**
   *
   * @param privillegeName
   * @returns
   */
  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege?.isEnabled;
    }
    return isEnabled;
  }


filenav(){
  this.route.navigate(["/upload/upload-file"],{ queryParams: {uploadfile: true, identity: this.repoId,repoName : this.repositoryName,status:this.repositoryStatus}});
}
  changePage(event) {
    this.pageIndex = event.pageIndex+1;
    if(event.pageIndex > event.previousPageIndex ){
      this.customPageIndex = event.pageIndex+1;
    }else{
     this.customPageIndex =  this.customPageIndex-1;
    }
      if (event.pageIndex != this.ZERO) {
        this.maxLength = event.pageSize;
        this.minLength = event.pageSize * event.pageIndex;
        this.endingIndex = event.pageSize;
        if (this.pagesize != event.pageSize) {
          this.maximumcount(event.pageSize);
          this.pageIndex = 1;
      }
    }else {
        this.maxLength = event.pageSize;
        this.minLength = event.pageIndex; this.endingIndex = event.pageSize;
        if (this.pagesize != event.pageSize) {
          this.maximumcount(event.pageSize); this.pageIndex = 1;
        }
    }
    this.getBulkUploadList(this.identity,this.minLength,this.status,this.maxLength,this.customSortingVo);
  }

  maximumcount(event) {
    this.pagesize = event;
    this.maximum = this.totalLength / this.pagesize
    this.remainder = this.totalLength % this.pagesize;
    if (this.remainder != 0) {
      this.maximum = this.maximum + 1;
    }
  }

  pageIndex = 1;
  pageindex() {
    this.pageChangedEvent.next(this.pageIndex);
  }
  changePageIndex(){

    if (this.pageIndex > 0) {
      if (this.pageIndex != null) {
        this.maximum = this.endingIndex * this.pageIndex;
        this.maxLength = this.endingIndex;
        this.minLength = this.endingIndex * (this.pageIndex - 1);
        const totalPageIndex = this.totalLength / this.endingIndex + 1;
      if(this.pageIndex > totalPageIndex) {
        this.pageIndex = this.customPageIndex === 0 ? 1 : this.customPageIndex;
        return;
      }
      this.getBulkUploadList(this.identity,this.minLength,this.status,this.maxLength,this.customSortingVo);
      }
    }
  }

  /**
   * page backward
   */
  onpagebackward() {
    if (this.bulkUploadList.length == 0) {
      this.dataNotFound = false;
    }
  }

/**
 *
 * @param status
 */
  is_successRecords(status:boolean){
      this.error = status ? true : false;
      this.records = status ? this.translate.instant('Upload.errors') : this.translate.instant('Upload.success');
      this.download = status ? true : false;
      this.count = status ? this.errorCount : this.successCount;
      this.status = status;
      this.minLength = 0;
      this.maxLength = 7;
      this.pageIndex = 1;
      this.getTotalRecordsCount(this.identity,status,this.minLength,this.customSortingVo, false);
  }


  onChange(event: any) {

    this.file = event.target.files[0];
    const fileOk = new updateFileList;
    fileOk.fileType = event.target.files[0].type;
    if(!fileOk.fileType.includes('application/vnd'))
    {
      this.tosterservice.error('Please select Excel file')
    }
    else{
      fileOk.size = event.target.files[0].size * 0.000977;
      fileOk.name = event.target.files[0].name;
      this.filename = fileOk.name;
      this.fileNameList.push(fileOk);
    }
  }
  DeleteFile()
  {
    this.filename=null;
    this.fileNameList=[];
  }
  dataColumns: string[] = [];
  four = "col-12 col-sm-12 col-md-12 col-lg-3 col-xl-3 col-xxl-3 ";
  eight = "col-12 col-sm-12 col-md-12 col-lg-9 col-xl-9 col-xxl-9";
  fullscreen = true;
  scrollBar=true;
  fullscreenc() {
    this.fullscreen = !this.fullscreen;
    this.four = "";
    this.eight = "col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12";
    this.scrollBar=false;
    this.nodata_center=true;
  }
  not_fullscreenc() {
    this.fullscreen = !this.fullscreen;
    this.four = "col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3 col-xxl-3"
      ; this.eight = "col-12 col-sm-12 col-md-9 col-lg-9 col-xl-9 col-xxl-9";
      this.scrollBar=true;
      this.nodata_center=false;
  }


  Refresh_Page(){
    this.getBulkUploadCounts(this.bulkUploadIdentity);
    this.getTotalRecordsCount(this.identity,this.status,this.minLength,this.customSortingVo, false);
    this.toaster.success(this.translate.instant('Toaster_success.Success'))
  }
  /**
   *
   * @param bulkUploadId
   * @param status
   * @param minLength
   * @param customSortingVo
   */
  getTotalRecordsCount(bulkUploadId: string, status: boolean, minLength: number, customSortingVo: CustomSortingVo[], isSystemTriggered : boolean) {
    const params = new HttpParams()
      .set('skip', minLength)
      .set('uploadIdentity', bulkUploadId)
      .set('status', status)
      .set('limit', this.maxLength);
    this.bulkUploadService.getBulkUploadCount(customSortingVo,params).subscribe((data) => {
      this.bulkUploadCount = data;
      this.totalLength = this.bulkUploadCount['content'];
      if(!isSystemTriggered){
        this.getBulkUploadList(this.identity,this.minLength,this.status,this.maxLength,this.customSortingVo);
      }
    });
  }

  /**
   *
   * @param bulkUploadIdentity
   */
  getBulkUploadCounts(bulkUploadIdentity: String) {
    this.bulkUploadService.getBulkUploadCountsDetails(bulkUploadIdentity).subscribe((response: any) => {
      this.bulkUploadHistoryDto = response;
      this.errorCount = this.bulkUploadHistoryDto.failureCount;
      this.successCount = this.bulkUploadHistoryDto.successCount;
      this.totalCount = this.bulkUploadHistoryDto.totalCount;
      this.uploadStatus = this.bulkUploadHistoryDto.status;
      this.showStatus = (this.uploadStatus === 'New') ? this.showStatus =  'In Progress':this.bulkUploadHistoryDto.status;
      // this.getBulkUploadList(this.identity,this.minLength,this.status,this.maxLength,this.customSortingVo);
    });
  }

  /**
   *
   * @param identity
   * @param minLength
   * @param status
   * @param maxLength
   * @param customSortingVo
   */
  getBulkUploadList(identity: string, minLength: number,status:boolean, maxLength: number, customSortingVo: CustomSortingVo[]) {
    const params = new HttpParams()
      .set('skip', minLength)
      .set('uploadIdentity', identity)
      .set('status', status)
      .set('limit', maxLength);
    this.bulkUploadService.getBulkUploadList(customSortingVo,params).subscribe((data) => {
      this.displayedColumns = []
      this.tempColumns = [];
      this.errorFieldArray = [];
         this.totalBulkUploadList = data['content'];
         this.bulkUploadList = data['content'].successErrorList;
         this.tempColumns = data['content'].fieldMapperDto;
         let totalFields = this.tempColumns.map(x => x.columnName);
         if(status === true){
         if (this.bulkUploadList) {
          this.bulkUploadList.forEach((element) => {
            if(element['err_flds'] == null && element['error'] == 'Duplicate Records'){
              this.errorFieldArray.push(totalFields);
            }else{
              this.errorFieldArray.push(element['err_flds']);
            }
          });
        }
      }
      if (this.bulkUploadList === null || this.bulkUploadList.length === 0) {
        this.dataNotFound = true;
      } else {
        this.dataNotFound = false;
        this.customPageIndex = (this.endingIndex*this.pageIndex)/this.endingIndex;
      }


         this.dataSource = new MatTableDataSource(this.bulkUploadList);
         if (this.bulkUploadList[0] != null) {
          this.dataColumns = Object.getOwnPropertyNames(this.bulkUploadList[0]);
          console.log(this.tempColumns)
          this.displayedColumns = this.tempColumns.map(ele => ele.columnName);
         }
    })

  }

/**
 *
 * @param data
 */
  tableSorting(data){
    console.log(data);
    let bulkUploadDetails = data.target.innerText.trim();
    this.columnName = this.getEntityColumnName(bulkUploadDetails);
    this.isAscending=!this.isAscending;
    this.setSortingVO(this.columnName,this.isAscending);
   this.getBulkUploadList(this.identity,this.minLength,this.status,this.maxLength,this.customSortingVo)
  }

  /**
   *
   * @param item
   * @returns
   */
 // method for getting corresponding entitiy name
 getEntityColumnName(item: string): string {
  let value = ''; if (item) {
    const data = this.tempColumns.find((column) => column.displayName === item);
    if (data) {
      value = data.columnName;
    }
  }
  return value;
}

onKeyDown(event: KeyboardEvent) {
  if (event.keyCode === 190) {
    event.preventDefault();
  }
}

  /**
   *
   * @param value
   * @param condition
   */
  // sorting condition method
  setSortingVO(value: string, condition: boolean) {
    if (value != null && condition != null) {
      this.sortingFilterVo.columnName = value;
      this.sortingFilterVo.isAsc = condition;
      this.customSortingVo=[];
      this.customSortingVo.push(this.sortingFilterVo);
    }

  }


/**
   *
   * @param condition
   *
   */
//errorRecordsDownloading method
  errorRecordsDownloading() {
    this.disableButtons = true;
    if (this.bulkUpload) {
      const params = new HttpParams()
      .set('uploadIdentity', this.identity)
      .set('status', this.status)
      .set('limit', this.errorCount)
      this.bulkUploadService.excelDownload(params).subscribe(data => {
        if(data){
          this.donwloadFile(data);
        }
      });
    } else {
      const pageIdentity = "c741ae6b5c3a49b888d2592a51c6bu8u";
      this.bulkRevokeService.downloadErrorFile(pageIdentity,this.bulkUploadId).subscribe(datas => {
        if (datas) {
          this.donwloadFile(datas);
        } else {
          this.toaster.error(this.translate.instant('Toaster_error.Invalid Data to Excel Report'));
        }
      })
    }

  }

  private donwloadFile(value: any) {
    const blob = new Blob([value], { type: FileTypeEnum.EXCEL });
    const downloadLink = document.createElement('a');
    downloadLink.style.display = 'none';
    document.body.appendChild(downloadLink);
    downloadLink.setAttribute('href', window.URL.createObjectURL(blob));
    const downloadName  =  this.filename.split('.xlsx');
    downloadLink.setAttribute('download', downloadName[0]+"-Error-Data"+'.xlsx');
    downloadLink.click();
    document.body.removeChild(downloadLink);
    this.disableButtons = false;
  }

  // sorting filter vo
  sortingFilterVo: CustomSortingVo = {
    columnName: "",
    isAsc:false,
    repositoryPrimaryId:[]
  }

  getCurrentUrl() {
    this.currentRoute = window.location.href;
    this.route.events.pipe(tap((event: any) => {
      if (event instanceof NavigationEnd) {
        this.currentRoute = event.url
        if (this.currentRoute.includes('bulk-upload')) {
          this.bulkUpload = true;
        }
       else if (this.currentRoute.includes('bulk-revoke')) {
          this.bulkUpload = false;
        }

      }
    })).subscribe();
    return this.bulkUpload;
  }
/**
 *
 * @param value
 * @param index
 * @returns
 */
  getColor(value:any, index: number){
    console.clear()
    console.log(this.errorFieldArray)
       const isRed = this.errorFieldArray[index]?.includes(value);
      return isRed;
     }


     ngOnDestroy():void{
      this.ngxLoader.stop();
     }
  }
 export interface header{
  displayName : string;
  columnName : string;
 }
