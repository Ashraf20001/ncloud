import { Component, Inject } from '@angular/core';
import { HeaderService } from 'src/app/service/header/header.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { HttpParams } from '@angular/common/http';
import { BulkUploadService } from 'src/app/service/bulk-upload/bulk-upload.service';
import { Router } from '@angular/router';

export interface DialogData {
  repoName: any;
  repoStatus: any;
  repoId: string;
}

@Component({
  selector: 'app-upload-file-history-pop-up',
  templateUrl: './upload-file-history-pop-up.component.html',
  styleUrls: ['./upload-file-history-pop-up.component.scss']
})

export class UploadFileHistoryPopUpComponent {
  date: Date=new Date();
  time: Date=new Date();
  bulkUpload: any;
  noDataFound : boolean = true;

  constructor( @Inject(MAT_DIALOG_DATA) public data: DialogData,public dialogRef: MatDialogRef<UploadFileHistoryPopUpComponent>,private bulkUploadService:BulkUploadService, private router: Router )
{

dialogRef.disableClose = true;
}

bulkUploadDataList:bulkUploadDataList[]=[]
  closeDialog() {
    this.dialogRef.close();
  }
ngOnInit()
{
  this.bulkUploadList();
}

  bulkUploadList() {
    const params = new HttpParams().set('repositoryIdentity', this.data.repoId)
  this.bulkUploadService.getBulkUploadDetails(params).subscribe((data)=>{
    this.bulkUpload = data;
    this.bulkUploadDataList=[];
    if(this.bulkUpload.length > 0){
      this.noDataFound = false;
    this.bulkUpload.forEach((value)=>{
     const element = new bulkUploadDataList();
     element.FileName = value.fileName;
     element.error = value.failureCount;
     element.success = value.successCount;
     element.totalFiles = value.totalCount;
     element.uploadDate = value.createdDate,
     element.uploadTime = value.time,
     element.identity = value.identity,
     element.repoIdentity = value.repoIdentity
     this.bulkUploadDataList.push(element);
    })
  }else{
    this.noDataFound = true;
  }

  })

}
/**
 *
 * @param uploadIdentity
 * @param repoIdentity
 */
UploadFile(uploadIdentity:string,repoIdentity:string,fileName:string){
 this.router.navigate(['upload/total-records'], { queryParams: { uploadfile: true, identity:uploadIdentity ,repoId : repoIdentity,repostatus:this.data.repoStatus,repoName:this.data.repoName,filename:fileName} });
 this.closeDialog();
}
}

export class bulkUploadDataList {
  FileName: string;
  uploadDate: any;
  uploadTime: any;
  totalFiles: any;
  success: number;
  error:number;
  identity:string;
  repoIdentity:string;
}
