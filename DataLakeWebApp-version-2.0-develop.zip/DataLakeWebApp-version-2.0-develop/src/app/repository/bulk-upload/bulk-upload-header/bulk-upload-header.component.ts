import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-bulk-upload-header',
  templateUrl: './bulk-upload-header.component.html',
  styleUrls: ['./bulk-upload-header.component.scss']
})
export class BulkUploadHeaderComponent implements OnInit{
  canShowBackIcon : boolean = false;
  repositoryName: string;
  slash='/'
  totalname 
  headerrepo;
  pageStatus: string;

  constructor(private activatedRoute: ActivatedRoute,private router:Router) {}

  ngOnInit() {
    // Note: Below 'queryParams' can be replaced with 'params' depending on your requirements
    this.activatedRoute.queryParams.subscribe(params => {
      this.repositoryName = (params['repoName']) ? 'All Repository / ' + params['repoName'] : 'All Repository';
      this.canShowBackIcon = (params['repoName']) ? true : false;
      // this.pageStatus = params['pagestatus'];
      this.totalname=this.repositoryName
      const s=this.totalname.split("/");
      this.headerrepo= " /"+s[1];
      
    });
  }

/**
 * @function redirect-card-view
 */
  redirectToCardView(){
      this.router.navigate(['/upload/card-view']);
    }
    
}


