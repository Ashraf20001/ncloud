import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FileTypeEnum } from 'src/app/models/report-loss-dto/FileTypeEnum';

import { AccessMappingSectionDto } from 'src/app/models/user-role-management/section-dto';
import { AppService } from 'src/app/service/role access/service/app.service';
import { UploadFileHistoryPopUpComponent } from '../upload-file-history-pop-up/upload-file-history-pop-up.component';
import { BulkUploadService } from 'src/app/service/bulk-upload/bulk-upload.service';
import { HttpParams } from '@angular/common/http';
import { appConst } from 'src/app/service/app.const';
import { AccessMappingPageDto } from 'ncloud-common-ui/lib/dto/access-Mapping-PageDto ';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-bulk-upload-file',
  templateUrl: './bulk-upload-file.component.html',
  styleUrls: ['./bulk-upload-file.component.scss']
})
export class BulkUploadFileComponent {

  bulkUpload =true;
  currentRoute:string;
  repoIdentity:any;
  action = "Upload";
  repositoryName: any;
  fileTypeList: string[]=[];
  currentDate =  new Date();
  valideDate: boolean;
  repositoryStatus: any;
  isDisable: boolean;
  repoStatus: any;
  pageStatus: boolean;
  isDisableBtn: boolean = false;
  constructor(
    public dialog: MatDialog,
    private router: Router,
    private activeRoute : ActivatedRoute,
    private toaster: ToastrService,
    public translate:TranslateService,
    private appService:AppService,private tosterservice:ToastrService,
    private uploadService: BulkUploadService
  ) {
    this.getPageAccessData();
    this.activeRoute.queryParams.subscribe((res)=>{
      this.repoIdentity = res['identity'];
      this.repositoryName = res['repoName'];
      this.repositoryStatus = res['status'];
      this.repoStatus = res['pagestatus'];
    })
   this.isDisable =  this.repositoryStatus === 'Disabled'? true : false;
   this.getUrl();
  }
  uploadType = 'NORMAL';


  paperDetailsAccessMappingDetails:AccessMappingSectionDto;
  generatePaperBulkAccessDetails:AccessMappingSectionDto;
  bulkRevokeAccessDetails:AccessMappingSectionDto;
  companyCardPageAccessMap: AccessMappingPageDto;
  pageInfo: any;
  appCon = appConst;
  isPageAccess = false;

   /**
   * Page Access
   */
   getPageAccessData(): void {
    this.appService.getPageAccess(appConst.PAGE_NAME.BULKUPLOAD.BULK_UPLOAD.PAGE_IDENTITY).subscribe((response: any) => {
      this.companyCardPageAccessMap = response.content;
      this.isPageAccess = this.companyCardPageAccessMap.isEnabled;
      if(this.isPageAccess) {
        this.getPrivilege();
      }
    });
  }

  /**
   *
   */
  getPrivilege(){
    this.appService.getPrivilegeForPage(appConst.PAGE_NAME.BULKUPLOAD.BULK_UPLOAD.PAGE_ID).subscribe((res: any)=>{
      this.pageInfo = res.content;
    });
  }

  /**
   *
   * @param privillegeName
   * @returns
   */
  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege?.isEnabled;
    }
    return isEnabled;
  }

  uploadFile(){
    const formData = new FormData();
    if(this.file){
      formData.append("file", this.file);
    }
    this.isDisableBtn = true;
    const parmas = new HttpParams().set("repositoryIdentity", this.repoIdentity);
    this.uploadService.bulkUploadFile(formData, parmas).subscribe((res:any)=>{
      this.router.navigate(['upload/total-records'],{ queryParams: {uploadfile: true ,identity: res.content,repoId: this.repoIdentity,filename:this.filename,repoName:this.repositoryName }});
      console.log(res);
    },(error:any)=>{
      this.isDisableBtn=false;
      console.log(error);
    })
  }

  totalrecords(){
    this.uploadFile();
  }
  upload_file_history(){
    const dialogRef = this.dialog.open(UploadFileHistoryPopUpComponent, {
      width: '1561px',
      // height: '569px',
      data: {
        repoId: this.repoIdentity,
        repoStatus: this.repositoryStatus,
        repoName:this.repositoryName
      },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
      //  console.log('1')
      }
    });
  }

  getUrl() {
    const actionType = sessionStorage.getItem("revoke");
        if (actionType == "Bulk Revoke") {
          this.bulkUpload = false;
        }
       else {
          this.bulkUpload = true;
        }
  }

  /**
   * Download sample file for repository download
   */
  downloadSampleFile(){
    const param = new HttpParams().set("repositoryIdentity", this.repoIdentity)
    this.uploadService.downloadSampleXlsxFile(param).subscribe((res)=>{
      if (res) {
        this.toaster.success(this.translate.instant('Toaster_success.Sample file downloaded successfully'));
        const blob = new Blob([res], { type: 'application/vnd.ms-excel' });
        const file = new File([blob], this.repositoryName+'.xlsx', {
          type: 'application/vnd.ms-excel',
        });
        const fileURL = URL.createObjectURL(file);
        const a = document.createElement('a');
        a.href = fileURL;
        a.target = '_blank';
        a.download = this.repositoryName + '.xlsx';
        document.body.appendChild(a);
        a.click();
      }
    })
  }

  BulkUpload: any[] = [
    {
      name: 'Normal',
      check: false,
    },
    { name: 'Fleet', check: false },
  ];

  BulkUploadNormalFeet(event: any) {
    // this.Amount = event               //use is code in backend
    if (event === 'Normal') {
      this.uploadType = 'NORMAL';
      this.BulkUpload[0].check = true;
      this.BulkUpload[1].check = false;
      // this.reallocate=true;
    } else if (event === 'Fleet') {
      this.uploadType = 'FLEET';
      this.BulkUpload[0].check = false;
      this.BulkUpload[1].check = true;
      // this.reallocate=false;
    }
  }
  file: any;
  fileNameList: updateFileList[] = [];
  browseFile=false;
  filename=null;
   generateRevoke:boolean;
  generatePaper: boolean;

  onChange(event: any) {
    this.file = event.target.files[0];
    const fileData = new updateFileList();
    fileData.fileType = event.target.files[0].type;
    this.fileTypeList.push('application/vnd.ms-excel');
    this.fileTypeList.push('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    // 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    if(this.fileTypeList.includes(fileData.fileType))
    {
      fileData.size = this.file.size/ (1024 * 1024);
      fileData.name = event.target.files[0].name;
        this.filename = fileData.name;
        this.fileNameList.push(fileData);
    //   if (fileData.size <= 100) {
    // }
    // else {
    //   this.toaster.error(this.translate.instant("Toaster_error.Filesizeexceeds100MBlimit"));
    // }
    } else{

      this.toaster.error(this.translate.instant("Toaster_error.InvalidFileFormat"));
    }

  }
  DeleteFile()
  {
    this.isDisableBtn = false
    this.filename=null;
    this.fileNameList=[];
  }









  displayedColumns: string[] = [
    'Digital Paper No',
    'Policy No',
    'Insured Name',
    'Registration No',
    'Effective From',
    'Effective to',
    'Status',
    'View',
    'Revoke',
  ];


  sampleFileColumns: string[] = ['Digital Paper','Policy Number',]
  // sampleExcelDownload() {
  //   if (this.bulkUpload?this.generatePaperBulkAccessDetails?.isDownload:this.bulkRevokeAccessDetails?.isDownload) {
  //     if(this.bulkUpload) {
  //       const pageIdentity = "c741ae6b5c3a49b888d2592a51c6bu8u";
  //       this.authorityPaperService.bulkUploadSampleExcelDownload(pageIdentity).subscribe((result)=>{
  //         if (result) {
  //           this.donwloadFile(result, 'Excel');
  //         } else {
  //           this.toaster.error('Invalid Data to Excel Report');
  //         }
  //       })
  //     } else {
  //       this.authorityPaperService
  //       .downloadSampleExcel(this.sampleFileColumns)
  //       .subscribe((datas) => {
  //         console.log(datas);
  //         if (datas) {
  //           this.donwloadFile(datas, 'Excel');
  //         } else {
  //           this.toaster.error('Invalid Data to Excel Report');
  //         }
  //       });
  //     }
  //   }
  // }

  private donwloadFile(value: any, downloadType: string) {
    const blob = new Blob([value], { type: FileTypeEnum.EXCEL });
    const downloadLink = document.createElement('a');
    downloadLink.style.display = 'none';
    document.body.appendChild(downloadLink);
    downloadLink.setAttribute('href', window.URL.createObjectURL(blob));
    downloadLink.setAttribute('download', 'Excel');
    downloadLink.click();
    document.body.removeChild(downloadLink);
  }

  getCurrentUrl() {
    this.currentRoute = window.location.href;
    this.router.events.subscribe((event: any) => {
      if (event instanceof NavigationEnd) {
        this.currentRoute = event.url
      }
    });
}
}
export class updateFileList {
  name: string;
  file: any;
  size: any;
  fileType: string;
}
