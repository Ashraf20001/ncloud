import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BulkUploadFileComponent } from './bulk-upload-file.component';

describe('BulkUploadFileComponent', () => {
  let component: BulkUploadFileComponent;
  let fixture: ComponentFixture<BulkUploadFileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BulkUploadFileComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BulkUploadFileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
