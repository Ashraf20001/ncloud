import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BulkUploadComponent } from './bulk-upload.component';
import { BulkUploadCardComponent } from './bulk-upload-card/bulk-upload-card.component';
import { BulkUploadFileComponent } from './bulk-upload-file/bulk-upload-file.component';
import { TotalRecordsComponent } from './total-records/total-records.component';
import {BulkUploadListComponent} from './bulk-upload-list/bulk-upload-list.component';






const routes: Routes = [
  {
    path:'',
    component:BulkUploadComponent,
    children:[
      {
        path: '',
        component : BulkUploadCardComponent
      },
      {
        path: 'card-view',
        component : BulkUploadCardComponent
      },
      {
        path: 'upload-file',
        component : BulkUploadFileComponent
      },
      {
        path: 'total-records',
        component : TotalRecordsComponent
      },
     {
        path: 'total-records',
        component : TotalRecordsComponent
      },
     {
        path: 'card-list-view',
        component : BulkUploadListComponent
      },
    ]

  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BulkUploadRoutingMoudle { }


