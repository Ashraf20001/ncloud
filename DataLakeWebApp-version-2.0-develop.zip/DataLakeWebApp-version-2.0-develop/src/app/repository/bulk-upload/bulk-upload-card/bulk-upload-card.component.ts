import { MatTableDataSource } from '@angular/material/table';
import { FilterOrSortingVo } from './../../../models/Filter-dto/filter-object-backend';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FilterObject } from 'src/app/models/Filter-dto/filter-object';
import { ManageRepositoryCardDetails } from 'src/app/models/repository-details';
import { HeaderService } from 'src/app/service/header/header.service';
import {TranslateService} from '@ngx-translate/core';
import { AccessMappingPageDto } from 'ncloud-common-ui/lib/dto/access-Mapping-PageDto ';
import { appConst } from 'src/app/service/app.const';
import { AppService } from 'ncloud-common-ui';
import { HttpParams } from '@angular/common/http';

@Component({
  selector: 'app-bulk-upload-card',
  templateUrl: './bulk-upload-card.component.html',
  styleUrls: ['./bulk-upload-card.component.scss'],
})
export class BulkUploadCardComponent implements OnInit {
  dataSource: any;
  totalLength: any;
  value: any;
  searchValue: string = '';
  dataNotFound: boolean = false;
  userRoleStatus: string = '';
  isAuthorityUser: any;
  values: string;
  results: void;
  // pageStatus: boolean = true;
  constructor(private route: Router, private headerservice: HeaderService,public translate:TranslateService,private appService: AppService) {

    this.isAuthorityUser = sessionStorage.getItem('userTypeId');
   
  }
  bulkuploadfilter: FilterOrSortingVo[] = [];
  show_card = true;
  min = 0;
  max = 10;
  upload = 'Approved';
  filterSort: FilterOrSortingVo[] = [];
  repositoryDetails: ManageRepositoryCardDetails[] = [];
  filterObject: FilterObject[] = [
    {
      columnName: 'repoVersion',
      condition: 'Equal',
      aliasName: this.translate.instant('repository_list.version'),
      type: 'field',
      value: [],
      dropdown: [],
      radio: [],
      dataType: '',
      max:50
    },
    {
      columnName: 'fieldCount',
      condition: 'Equal',
      aliasName: this.translate.instant('repository_list.no_of_data'),
      type: 'field',
      value: [],
      dropdown: [],
      radio: [],
      dataType: '',
      max:50
    },
  ];
   identity: string;
  repoName: string;
  companyCardPageAccessMap: AccessMappingPageDto;
  isPageAccess = false;
  pageInfo: any;
  appCon = appConst;
  cardshow() {
    this.show_card = !this.show_card;
    this.route.navigate(['upload/card-list-view']);
  }
  getfilter(event) {
    //this.bulkuploadfilter = event;
    this.getUploadList(this.min, this.max, event,this.searchValue);
   if(event.length!=0)
{
}
  }

  /**
   * @param repository
   */
  uploadFile(repository: ManageRepositoryCardDetails) {
    this.route.navigate(['upload/upload-file'], {
      queryParams: {
        identity: repository.identity, repoName: repository.repositoryName, status: repository.repositoryStatus
      }
    });
  }

  getUploadList(min, max, filtersort: any,searchValue) {
    const params = new HttpParams()
    .set('min', min)
    .set('max', max)
    .set('search', searchValue)
    .set("isApproved", false)
    this.headerservice
      .getRepositoryDetailsapproved(filtersort, params)
      .subscribe((data) => {
        this.repositoryDetails = null;
        this.repositoryDetails = data;
        if (this.repositoryDetails === null || this.repositoryDetails.length === 0) {
               this.dataNotFound = true;
              } else {
                this.dataNotFound = false;
              }
        this.dataSource = new MatTableDataSource<ManageRepositoryCardDetails>(
          this.repositoryDetails
         
        );
        
      });
  }
  getRepositorycount(filtersort: FilterOrSortingVo[]) {
    this.headerservice.getListOfCount(filtersort,this.searchValue,this.userRoleStatus).subscribe((Response) => {
      console.log(Response);
      this.totalLength = Response;
      this.max = this.totalLength;
      this.getUploadList(this.min, this.max, filtersort,this.searchValue);
    });
  }
  ngOnInit() {
    this.getPageAccessData();
   
  }

  /**
   * Page Access for create repository
   */
  getPageAccessData(): void {
    this.appService.getPageAccess(appConst.PAGE_NAME.BULKUPLOAD.BULK_UPLOAD.PAGE_IDENTITY).subscribe((response: any) => {
      this.companyCardPageAccessMap = response.content;
      this.isPageAccess = this.companyCardPageAccessMap.isEnabled;
      if(this.isPageAccess){
        this.getRepositorycount(this.bulkuploadfilter);
        this.getPrivilege();
      }
    });
  }

  /**
   * Privilege Access
   */
  getPrivilege(){
    this.appService.getPrivilegeForPage(appConst.PAGE_NAME.BULKUPLOAD.BULK_UPLOAD.PAGE_ID).subscribe((res: any)=>{
      this.pageInfo = res.content;
    });
  }

  getSearchValueList(event){
    this.searchValue = event;
    this.getUploadList(this.min, this.max, this.bulkuploadfilter ,this.searchValue);
  }

  /**
   *
   * @param privillegeName
   * @returns
   */
  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege?.isEnabled;
    }
    return isEnabled;
  }
}
