import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BulkUploadCardComponent } from './bulk-upload-card.component';

describe('BulkUploadCardComponent', () => {
  let component: BulkUploadCardComponent;
  let fixture: ComponentFixture<BulkUploadCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BulkUploadCardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BulkUploadCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
