import { Component } from '@angular/core';
import { MatPaginatorIntl } from '@angular/material/paginator';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-bulk-upload',
  templateUrl: './bulk-upload.component.html',
  styleUrls: ['./bulk-upload.component.css']
})
export class BulkUploadComponent {

  constructor(private router:Router,private Activateroute:ActivatedRoute,private paginatorName: MatPaginatorIntl) {
    // this.router.navigate(['card-view'],{relativeTo:this.Activateroute})
    paginatorName.itemsPerPageLabel = 'Rows per page';
  }

}
