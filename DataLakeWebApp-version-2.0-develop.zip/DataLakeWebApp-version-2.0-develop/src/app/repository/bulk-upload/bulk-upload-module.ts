import { NgModule } from "@angular/core";
import { BulkUploadComponent } from "./bulk-upload.component";
import { BulkUploadCardComponent } from "./bulk-upload-card/bulk-upload-card.component";
import { BulkUploadListComponent } from "./bulk-upload-list/bulk-upload-list.component";
import { BulkUploadRoutingMoudle } from "./bulk-upload-routing.module";
import { BulkUploadHeaderComponent } from "./bulk-upload-header/bulk-upload-header.component";
import { AppCommonModule } from "../../common/components/app-common.module";
import { DemoMaterialModule } from "src/app/common/components/material-module";
import { CommonModule } from "@angular/common";
import {FormsModule} from "@angular/forms";
import {TranslateModule} from "@ngx-translate/core";





@NgModule({
    declarations: [
        BulkUploadComponent,
        BulkUploadHeaderComponent,
        BulkUploadCardComponent,
        BulkUploadListComponent,
    ],
    imports: [
        BulkUploadRoutingMoudle,
        AppCommonModule,
        DemoMaterialModule,
        CommonModule,
        FormsModule,TranslateModule
    ]
})
export class BulkUploadModule{

}
