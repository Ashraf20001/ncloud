import { HttpParams } from '@angular/common/http';
import { AfterViewInit, ChangeDetectorRef, Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import {TranslateService} from '@ngx-translate/core';
import { AppService } from 'ncloud-common-ui';
import { AccessMappingPageDto } from 'ncloud-common-ui/lib/dto/access-Mapping-PageDto ';
import { ToastrService } from 'ngx-toastr';
import { Subject, debounceTime } from 'rxjs';
import {FilterObject} from 'src/app/models/Filter-dto/filter-object';
import { FilterOrSortingVo } from 'src/app/models/Filter-dto/filter-object-backend';
import { ManageRepositoryCardDetails } from 'src/app/models/repository-details';
import { appConst } from 'src/app/service/app.const';
import { HeaderService } from 'src/app/service/header/header.service';

@Component({
  selector: 'app-bulk-upload-list',
  templateUrl: './bulk-upload-list.component.html',
  styleUrls: ['./bulk-upload-list.component.scss'],
})
export class BulkUploadListComponent implements OnInit,AfterViewInit{
  totalLength: any;
  pagesize: any;
  remainder: number;
  endingIndex = 10;
  ZERO = 0;
  ten = 10;
  RepositorySort: boolean = false;
  Noofdatas: boolean = false;
  NoofVersion: boolean = false;
  searchValue: string = '';
  @ViewChild(MatPaginator) paginator: MatPaginator;
  pageStatus: boolean;

  constructor(private route: Router, private headerservice: HeaderService,private paginatorName: MatPaginatorIntl,
    private detector: ChangeDetectorRef,private appService: AppService,private tosterservice:ToastrService,private translate:TranslateService) {
    if(this.paginatorName) {
      this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    }


}
  min = 0;
  max = 10;
  filterSort: FilterOrSortingVo[] = [];
  displayedColumns: string[] = [
    'repository',
    'no_of_records',
    'version',
    'upload',
  ];
  repositoryDetails: ManageRepositoryCardDetails[] = [];
  dataSource = new MatTableDataSource<ManageRepositoryCardDetails>();
  maximum: number;
  pageIndex = 1;
  customPageIndex: number=0;
  dataNotFound: boolean = false;
  isAscOrder: boolean = false;
  isGotToPageDissabel = false;
  private _getFilterVo: FilterOrSortingVo[] = [];
  show_edit = true;
  companyCardPageAccessMap: AccessMappingPageDto;
  isPageAccess = false;
  pageInfo: any;
  appCon = appConst;
  pageChangedEvent = new Subject<number>();
  filterObject: FilterObject[] = [
    {
      columnName: 'repoVersion',
      condition: 'Equal',
      aliasName: 'repository_list.version',
      type: 'field',
      value: [],
      dropdown: [],
      radio: [],
      dataType: '',
      max:9
    },
    {
      columnName: 'fieldCount',
      condition: 'Equal',
      aliasName: 'repository_list.no_of_data',
      type: 'field',
      value: [],
      dropdown: [],
      radio: [],
      dataType: '',
      max:9
    },
  ];
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  scheduler_edit() {
    this.show_edit = !this.show_edit;
  }
  //@Input()
  //set getFiltervo(value: FilterOrSortingVo[]) {
  //  this._getFilterVo = value;
  //  if (value !== null) {
  //    this.filterSort = this._getFilterVo;
  //    if (this.max !== undefined && this.filterSort != undefined) {
  //      this.getUploadList(this.min, this.max, this.filterSort);
  //    }
  //  }
  //}


  @ViewChild(MatSort) sort: MatSort;
  // eslint-disable-next-line @angular-eslint/use-lifecycle-interface
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;


    if(this.paginatorName) {
      this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    }
  }
  sortingmethod(event:string) {
    const UploadListColumnName = event;
    if (UploadListColumnName === 'Version') {
      this.isAscOrder = !this.isAscOrder;
      this.RepositorySort = false;
      this.NoofVersion = !this.NoofVersion;
      this.Noofdatas = false;
      const columnName = this.getEntityColumnName(UploadListColumnName);
      this.setSortingVO(columnName, this.isAscOrder);
      this.getUploadList(this.min, this.max, this.filterSort,this.searchValue);
    } else if (UploadListColumnName === 'Repository Name') {
      this.isAscOrder = !this.isAscOrder;
      this.RepositorySort = !this.RepositorySort;
      this.NoofVersion = false;
      this.Noofdatas = false;
      const columnName = this.getEntityColumnName(UploadListColumnName);
      this.setSortingVO(columnName, this.isAscOrder);
      this.getUploadList(this.min, this.max, this.filterSort,this.searchValue);
    } else if (UploadListColumnName === 'No of Fields') {
      this.isAscOrder = !this.isAscOrder;
      this.RepositorySort = false;
      this.NoofVersion = false;
      this.Noofdatas = !this.Noofdatas;
      const columnName = this.getEntityColumnName(UploadListColumnName);
      this.setSortingVO(columnName, this.isAscOrder);
      this.getUploadList(this.min, this.max, this.filterSort,this.searchValue);
    }
  }
  getEntityColumnName(SchdedulerColumnName: string) {
    let value = '';
    if (SchdedulerColumnName) {
      const data = this.sortingEntityArray.find(
        (column) => column.tableColumnName === SchdedulerColumnName
      );
      if (data) {
        value = data.entityColumnName;
      }
    }
    return value;
  }

/**
   * @param repository
   */
uploadFile(repository: ManageRepositoryCardDetails) {
  this.route.navigate(['upload/upload-file'], { queryParams: { identity: repository.identity, repoName: repository.repositoryName} });
}

  setSortingVO(columnName: string, isAscOrder: boolean) {
    if (columnName != null && isAscOrder != null) {
      this.sortingFilterVo.columnName = columnName;
      this.sortingFilterVo.isAscending = isAscOrder;
    }
    const data = this.filterSort.find(
      (element) => element.filterOrSortingType === 'SORTING'
    );
    if (data) {
      const index: number = this.filterSort.indexOf(data);
      this.filterSort.splice(index, 1);
    }
    this.filterSort.push(this.sortingFilterVo);
  }
  sortingEntityArray = [
    {
      tableColumnName: 'Repository Name',
      entityColumnName: 'repositoryName',
      type: 'String',
    },
    {
      tableColumnName: 'Version',
      entityColumnName: 'repoVersion',
      type: 'Integer',
    },
    {
      tableColumnName: 'No of Fields',
      entityColumnName: 'fieldCount',
      type: 'Integer',
    },
  ];
  sortingFilterVo: FilterOrSortingVo = {
    columnName: '',
    condition: '',
    filterOrSortingType: 'SORTING',
    intgerValueList: [],
    valueList: [],
    isAscending: false,
    type: '',
    value: '',
    value2: '',
  };
  getUploadList(min, max, filtersort: any,searchValue) {
    const params = new HttpParams()
    .set('min', min)
    .set('max', max)
    .set('search', searchValue)
    .set("isApproved", false)
    this.headerservice
      .getRepositoryDetailsapproved(filtersort, params)
      .subscribe((data) => {
        this.repositoryDetails = null;
        this.repositoryDetails = data;
        if (
          this.repositoryDetails === null ||
          this.repositoryDetails.length === 0
        ) {
          this.isGotToPageDissabel = false;
          this.dataNotFound = true;
        } else {
          this.isGotToPageDissabel = false;
          this.dataNotFound = false;
          this.customPageIndex = max/this.endingIndex;
        }
        this.dataSource = new MatTableDataSource<ManageRepositoryCardDetails>(
          this.repositoryDetails
        );
        console.log(data);
      });
  }

  getSearchValueList(event){
    this.searchValue = event;
    this.getRepositorycount(this.filterSort,this.searchValue);
    this.getUploadList(this.min, this.max, this.filterSort,this.searchValue);
  }
  getRepositorycount(filtersort: FilterOrSortingVo[] ,search) {
    this.headerservice.getApprovedListOfCount(filtersort,search).subscribe((Response) => {
      console.log(Response);
      this.totalLength = Response;
      this.max = this.ten;
      // this.getUploadList(this.min, this.max, filtersort,this.searchValue);
      this.maximumcount(this.max);
    });
  }
  maximumcount(event) {
    this.pagesize = event;
    this.maximum = this.totalLength / this.pagesize;
    this.remainder = this.totalLength % this.pagesize;
    if (this.remainder != 0) {
      this.maximum = this.maximum + 1;
    }
  }
  onKeyDown(event: KeyboardEvent) {
    if (event.keyCode === 190) {
      event.preventDefault();
    }
  }

  changePage(event) {
    if(event.pageIndex > event.previousPageIndex ){
      this.customPageIndex = event.pageIndex+1;
    }else{
     this.customPageIndex =  this.customPageIndex-1;
    }
    if (event.pageIndex != this.ZERO) {
      this.pageIndex = event.pageIndex + 1;
      this.max = event.pageSize;
      this.min = event.pageSize * event.pageIndex;
      this.endingIndex = event.pageSize;
      if (this.pagesize != event.pageSize) {
        this.maximumcount(event.pageSize);
      }
    } else {
      this.pageIndex = 1;
      this.max = event.pageSize;
      this.min = event.pageIndex;
      this.endingIndex = event.pageSize;
      if (this.pagesize != event.pageSize) {
        this.maximumcount(event.pageSize);
      }
    }
    this.getUploadList(this.min, this.max, this.filterSort,this.searchValue);
  }
  onpagebackward() {
    if (this.getUploadList.length == 0) {
      this.dataNotFound = false;
    }
  }
  pageindex() {
    this.pageChangedEvent.next(this.pageIndex);
  }
  changePageIndex() {
    if (this.pageIndex > 0) {
      if (this.pageIndex != null) {
        this.maximum = this.endingIndex * this.pageIndex;
        this.min = this.endingIndex * (this.pageIndex - 1);
        console.log('pageindex');
        const totalPageIndex = this.totalLength / this.endingIndex + 1;
        if(this.min > totalPageIndex){
          if(this.pageIndex > totalPageIndex) {
            this.pageIndex = this.customPageIndex === 0 ? 1 : this.customPageIndex;
            return;
          }
          this.getUploadList(this.min, this.maximum, this.filterSort,this.searchValue);
        }
         else {
          this.customPageIndex = this.min/this.endingIndex;
           this.min =0;
           this.maximum = 10;
           if(this.pageIndex > totalPageIndex) {
            this.pageIndex = this.customPageIndex === 0 ? 1 : this.customPageIndex;
            return;
          }

           this.getUploadList(this.min, this.maximum, this.filterSort,this.searchValue);
        }

      }
    }
  }
 cardshow() {

    this.route.navigate(['upload/card-view']);
  }
  getfilter(event) {

const regexPattern = /^(?:[0-9]+|null)$/;
const inputString = event[0].value;
const inputStrings = event[1].value;

const isMatch = regexPattern.test(inputString);
const isMatchs = regexPattern.test(inputStrings);
if(isMatch && isMatchs){
  if(this.max!=undefined)
  {
    this.filterSort = event;
    this.getRepositorycount(event,this.searchValue);
      this.getUploadList(this.min, this.max, event,this.searchValue);
  }
} else{
  this.tosterservice.error(this.translate.instant('Toaster_error.Data Type Not Valid. Please Provide Data With Valid Data Type'));
}
  }
  ngOnInit() {
    // this.pageStatus = false;
    this.translate.onLangChange.subscribe(() => {
      if (this.paginator) {
        this.paginator._intl.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
        this.paginator._changePageSize(this.paginator.pageSize);
        this.detector.detectChanges();
      }
    });
    if(this.paginatorName) {
      this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    }
    this.getPageAccessData();
    this.pageChangedEvent.pipe(debounceTime(300)).subscribe((data: number) => {
     this.changePageIndex();
    });
  }

  /**
   * Page Access for create repository
   */
  getPageAccessData(): void {
    this.appService.getPageAccess(appConst.PAGE_NAME.BULKUPLOAD.BULK_UPLOAD.PAGE_IDENTITY).subscribe((response: any) => {
      this.companyCardPageAccessMap = response.content;
      this.isPageAccess = this.companyCardPageAccessMap.isEnabled;
      if(this.isPageAccess){
        this.getUploadList(this.min, this.max, this.filterSort,this.searchValue);
        this.getRepositorycount(this.filterSort,this.searchValue);
        this.getPrivilege();
      }
    });
  }

  /**
   * Privilege Access
   */
  getPrivilege(){
    this.appService.getPrivilegeForPage(appConst.PAGE_NAME.BULKUPLOAD.BULK_UPLOAD.PAGE_ID).subscribe((res: any)=>{
      this.pageInfo = res.content;
    });
  }

  /**
   *
   * @param privillegeName
   * @returns
   */
  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege?.isEnabled;
    }
    return isEnabled;
  }
}
