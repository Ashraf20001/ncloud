import { Clipboard } from '@angular/cdk/clipboard';
import { HttpParams } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatAutocompleteTrigger } from '@angular/material/autocomplete';
import { AppService } from 'ncloud-common-ui';
import { AccessMappingPageDto } from 'ncloud-common-ui/lib/dto/access-Mapping-PageDto ';
import { Observable, map, startWith } from 'rxjs';
import {FilterOrSortingVo} from 'src/app/models/Filter-dto/filter-object-backend';
import { appConst } from 'src/app/service/app.const';
import { HeaderService } from 'src/app/service/header/header.service';

@Component({
  selector: 'app-api-integration',
  templateUrl: './api-integration.component.html',
  styleUrls: ['./api-integration.component.scss']
})
export class ApiIntegrationComponent implements OnInit {

  repositoryList: any;

  selectedRepositoryName= "<Repo Name>";
  selectedRepositoryIdentity: any;
  requestRepositoryObj: any;

  filedName: any;
  openbrace="<";
  closebrace=">"
  addDataResponseText: any;
value3:any;
  repositorySearchQuery:any
 repositoryRespondQuery:any;

  value4: any;
  value5: any;
  value6: any;
  companyCardPageAccessMap: AccessMappingPageDto;
  pageInfo: any;
  appCon = appConst;
  isPageAccess = false;
  min=0;
 maximum=0;
filterVoObject:FilterOrSortingVo[]= [];
  form = new FormGroup({
    sr: new FormControl()
  });
  searchValue = '';
  userRoleStatus = '';
  globalRespondQuery: any;
  selectedRepositoryAPIName = "<Repo Name>";


  constructor(private headerService: HeaderService, private appService: AppService, private clipBoard : Clipboard,private _formBuilder: FormBuilder){

  }


  ngOnInit(): void {
    this.getPageAccessData();




  }

  /**
   * Page Access
   */
  getPageAccessData(): void {
    this.appService.getPageAccess(appConst.PAGE_NAME.API_INTEGRATION.API.PAGE_IDENTITY).subscribe((response: any) => {
      this.companyCardPageAccessMap = response.content;
      this.isPageAccess = this.companyCardPageAccessMap.isEnabled;
      if(this.isPageAccess) {
        this.getRepositoryNameList(this.min,this.maximum,this.filterVoObject);
      }
    });
  }


  // GET call for the Repository Details
  getRepositoryNameList(min, maximum ,filterVoObject) {
    const params = new HttpParams()
    .set('min', min)
    .set('max', maximum)
    .set('search', this.searchValue)
    .set("isApproved", true)
    this.headerService.getRepositoryDetailsapproved(filterVoObject, params).subscribe((data: any) => {

      this.repositoryList = data;
      this.filteredOptions = this.myControl.valueChanges.pipe(
        startWith(''),
        map(value => this._filter(value || '')),
      );

    })
  }
 repositoryCount(filterVoObject: FilterOrSortingVo[]) {
    this.headerService.getListOfCount(filterVoObject,this.searchValue,this.userRoleStatus).subscribe(Response => {
      console.log(Response);
      this.min=0;
      this.getRepositoryNameList(this.min, this.maximum, filterVoObject);
    })

  }

// On change of selected value from the Repository Name dropdown
  onChange(event: any): void{
    const repository = this.repositoryList.filter(repo => repo.repositoryName == event.option.value);
    this.selectedRepositoryName = repository[0]?.repositoryName;
    this.selectedRepositoryIdentity = repository[0]?.identity;
    this.selectedRepositoryAPIName = repository[0]?.repositoryApiName
    this.getRepositoryObjectbyIdentity(this.selectedRepositoryIdentity);
    this.addDataResponseText="Data Added Successfully"
  }

// Get Repository by Identity and fieldName format to display
  getRepositoryObjectbyIdentity(identity : any): void{
    this.headerService.getRepositoryDetailsbyIdentity(identity).subscribe((res: any)=> {
      this.requestRepositoryObj = res;
      const repositoryData = {};
      if(this.requestRepositoryObj && this.requestRepositoryObj.fieldsConfiguratorDto && this.requestRepositoryObj.fieldsConfiguratorDto.length){
        this.requestRepositoryObj.fieldsConfiguratorDto.forEach(element => {
          if (element.fieldType === 'Dropdown') {
            element.dataType = element.fieldType;
          }
          else if (element.dataType === null) {
            element.dataType = 'String';
          }
          else {
            element.dataType = element.dataType;
          }
          repositoryData[element.columnName] = ""+[element.dataType]+"";
        });
      }
      this.filedName = repositoryData;
      this.repositorySearchQuery={
        "searchQuery":"Enter Search Value"
      };
      this.repositoryRespondQuery = {
        "content":[{
          "index":"RepositoryName",
          "matchedObject":[{
            "field1":"value1",
          "field2":"value2",
          "field3":"value3",
          },{
            "field1":"value1",
          "field2":"value2",
          "field3":"value3",
          }]
        }]
      }
      this.globalRespondQuery = {
        "content":[{
          "index":"RepositoryName1",
          "matchedObject":[{
            "field1":"value1",
          "field2":"value2",
          "field3":"value3",
          },
        {
          "field1":"value1",
          "field2":"value2",
          "field3":"value3",
        }]
        },{
          "index":"RepositoryName2",
          "matchedObject":[{
            "field1":"value1",
            "field2":"value2",
            "field3":"value3",
          }]
        }
      ]

      }

    })
  }

  //Copying the text in the clipboard Add Data
  getData(){
    return document.getElementById("addData").innerText;
  }
  getData2(){
    this.clipBoard.copy(this.addDataResponseText);
  }
  getData3(){

    return document.getElementById("api-status").innerText;
  }

  getData4(){

    return document.getElementById("api-status4").innerText;
  }

  getData5(){

    return document.getElementById("api-status5").innerText;
  }
  getData6(){

    return document.getElementById("api-status6").innerText;
  }


  //auto complete dropdown
  myControl = new FormControl('');

  filteredOptions: Observable<string[]>;


  private _filter(value: string): string[] {

    const filterValue = value.toLowerCase();
    const req = this.repositoryList.map(x => x.repositoryName);
    return req.filter(Option => Option.toLowerCase().includes(filterValue));
  }
}

