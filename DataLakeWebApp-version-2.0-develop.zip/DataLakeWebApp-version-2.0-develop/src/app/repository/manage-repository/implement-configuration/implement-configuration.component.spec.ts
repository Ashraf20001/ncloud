import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImplementConfigurationComponent } from './implement-configuration.component';

describe('ImplementConfigurationComponent', () => {
  let component: ImplementConfigurationComponent;
  let fixture: ComponentFixture<ImplementConfigurationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ImplementConfigurationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ImplementConfigurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
