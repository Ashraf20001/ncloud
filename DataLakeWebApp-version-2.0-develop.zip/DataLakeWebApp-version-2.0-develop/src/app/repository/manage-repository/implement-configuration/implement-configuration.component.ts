import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { RepositoryConfigurationDto } from 'src/app/models/entity-management-dto/RepositoryConfigurationDto';
import { HeaderService } from 'src/app/service/header/header.service';

@Component({
  selector: 'app-implement-configuration',
  templateUrl: './implement-configuration.component.html',
  styleUrls: ['./implement-configuration.component.scss']
})
export class ImplementConfigurationComponent {
  repositoryCost: any;
  sharePercentage: any;
  constructor( private headerService : HeaderService,private toastr : ToastrService,private router:Router){

  }
  repositoryConfigurationDto : RepositoryConfigurationDto = new RepositoryConfigurationDto;
sharedPercent : string;
repoCost : string;

ngOnInit(){ 
  this.getSuperAdmin();
}

cancel(){
  this.router.navigateByUrl('repository/manage-repository/card-view');
}

save()
{
  this.repositoryConfigurationDto.repositoryCost = this.repoCost;
  this.repositoryConfigurationDto.sharePercentage = this.sharedPercent; 
  this.superAdmin(this.repositoryConfigurationDto);
  this.toastr.success('Details added successfully.');
  // this.getSuperAdmin();
}

 /**
   * @param repositoryConfigurationDto
   * @returns
   */
 superAdmin(repositoryConfigurationDto){
  this.headerService.superAdminDetails(repositoryConfigurationDto).subscribe((data) => {
    
      })
       
}

getSuperAdmin(){
  this.headerService.getSuperAdminDetails().subscribe((data:any) => {
      this.repositoryConfigurationDto = data;
      this.repoCost = this.repositoryConfigurationDto.repositoryCost;
      this.sharedPercent = this.repositoryConfigurationDto.sharePercentage;
      })
}

}
