import { Component } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { TabDTO } from '../repository.component';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { MatPaginatorIntl } from '@angular/material/paginator';
import { I18nServiceService } from 'src/app/service/i18n-service.service';
import { TranslateService } from '@ngx-translate/core';
import { HeaderDto } from 'src/app/models/header/header-dto';
import { Menu } from 'ncloud-common-ui/lib/dto/menu-dto';
import { HeaderComponent } from 'ncloud-common-ui';
import { appConst } from 'src/app/service/app.const';

@Component({
  selector: 'app-manage-repository',
  templateUrl: './manage-repository.component.html',
  styleUrls: ['./manage-repository.component.scss']
})
export class ManageRepositoryComponent {

  transactionTabIndex= 0;
  isEdit = false;
  currentRoute = "";
  isAdmin = false;

  RepositoryAdminTab=RepositoryTab;

  navigationTabs: TabDTO[];

  settingsTab: TabDTO = {
    label:"Managment.implement",
    url: 'implement-configuration',
    labelClass: 'implement-configuration'
  }

  value: string;

  constructor(public i18Service:I18nServiceService,
    private route: ActivatedRoute, public translate: TranslateService, public router: Router) {
  }

  ngOnInit(): void {
    this.loadTranslatedNavigationTabs();
  }

  loadTranslatedNavigationTabs(){
    this.navigationTabs= [
      {
        label:"Managment.manage",
        url: 'manage-repository',
        labelClass: 'Manage-Repository'
      },
      {
        label:"Managment.scheduler",
        url: 'scheduler',
        labelClass: 'scheduler'
      },
      {
        label:"Managment.api",
        url: 'api-integration',
        labelClass: 'api'
      },
    ];
    this.checkAdminAccessTab();
  }

  checkAdminAccessTab():void{
    this.value = sessionStorage.getItem('menuname');
    if(this.value === this.RepositoryAdminTab.Settings){
      this.navigationTabs.push(this.settingsTab);
    }
    else{
      this.navigationTabs.splice(this.navigationTabs.length, 1);
    }
  }


  getCurrentUrl() {
    this.currentRoute = window.location.href;
    this.router.events.subscribe((event: any) => {
      if (event instanceof NavigationEnd) {
        this.currentRoute = event.url
      }
    });
  }


}


export enum RepositoryTab {
  Settings= 'Settings'
}
