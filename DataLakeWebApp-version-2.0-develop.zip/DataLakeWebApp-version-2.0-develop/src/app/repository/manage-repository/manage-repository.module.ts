import { NgModule } from "@angular/core";
import { CommonModule, DatePipe } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatIconModule } from "@angular/material/icon";
import { TranslateModule } from "@ngx-translate/core";
import { ManageRepositoryComponent } from "./manage-repository.component";
import { ManageRepositoryRoutingMoudle } from "./manage-repository-routing.module";
import { DemoMaterialModule } from "src/app/common/components/material-module";
import { AppCommonModule } from "../../common/components/app-common.module";
import {MatTableModule} from '@angular/material/table';
import { ApiIntegrationComponent } from './api-integration/api-integration.component';
import { ImplementConfigurationComponent } from './implement-configuration/implement-configuration.component';
import { RepositoryNavigationComponent } from './repository-navigation/repository-navigation.component';



@NgModule({
    declarations: [
        ManageRepositoryComponent,
        ApiIntegrationComponent,
        ImplementConfigurationComponent,
        RepositoryNavigationComponent,

    ],
    imports: [
        CommonModule, MatIconModule,
        MatFormFieldModule,
        FormsModule,
        ReactiveFormsModule,
        TranslateModule,
        ManageRepositoryRoutingMoudle,
        DemoMaterialModule,
        AppCommonModule,MatTableModule
    ],
providers: [DatePipe],
})
export class ManageRepositoryModule{

}
