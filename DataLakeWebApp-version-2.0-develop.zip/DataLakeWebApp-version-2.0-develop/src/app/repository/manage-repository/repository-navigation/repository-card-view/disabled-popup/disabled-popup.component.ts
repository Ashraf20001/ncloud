import { HttpParams } from '@angular/common/http';
import { Component, Inject } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { HeaderService } from 'src/app/service/header/header.service';
import { LOCALE_ID } from '@angular/core';
import { DatePipe } from '@angular/common';
import { DateAdapter, MAT_DATE_LOCALE, MAT_DATE_FORMATS } from '@angular/material/core';
import { MomentDateAdapter } from "@angular/material-moment-adapter";
import { TranslateService } from '@ngx-translate/core';

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL'
  },

  display: {
    dateInput: 'DD-MM-YYYY',
    monthYearLabel: 'YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'YYYY'
  }

};


@Component({
  selector: 'app-disabled-popup',
  templateUrl: './disabled-popup.component.html',
  styleUrls: ['./disabled-popup.component.scss'],
  providers: [DatePipe,
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }]
})

export class DisabledPopupComponent {
  dateControl: FormControl = new FormControl();
  selectedDate: any;
  repositoryIdentity: string
  minDate = new Date();
  timeZone: any;
  dateFormat = 'yyyy-MM-dd'; // To Be Dynamic !!!!!!!!!!!!!!!!!!!!!!!!!!!!

  constructor(public dialogRef: MatDialogRef<DisabledPopupComponent>,public translate:TranslateService ,public urlService: HeaderService,
    @Inject(MAT_DIALOG_DATA) public data: { name: string }, private toastr: ToastrService,
    @Inject(LOCALE_ID) private locale: string, private datePipe: DatePipe) {

    dialogRef.disableClose = true;
    this.repositoryIdentity = data.name;
    this.timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone
  }


  /**
   * @function acknowledge-disble
   */
  disable() {
    this.selectedDate = this.dateControl.value;
    if (this.selectedDate) {
      this.selectedDate = this.datePipe.transform(this.selectedDate, this.dateFormat, this.timeZone, this.locale);
        this.dateControl.setValue(this.selectedDate);
        this.disableRepository(this.repositoryIdentity, this.selectedDate);
      } else {
        this.toastr.error(this.translate.instant('Toaster_error.Please Enter Valid Date'));
      }
      }

  /**
   * @function disable-repository
   * @param repositoryIdentity
   * @param date
   */
  disableRepository(repositoryIdentity: string, effectiveTo: any) {
    const params = new HttpParams()
      .set('repositoryIdentity', repositoryIdentity)
      .set('date', effectiveTo);
    this.urlService.disableRepository(params).subscribe((response) => {
      if (response) {
        this.toastr.success(this.translate.instant('Toaster_success.RepositoryDisabledSuccessfully'));
        this.closeDisablePopup();
      }
    });
  }

  /**
   * @function close-dialog
   */
  closeDisablePopup() {
    this.dialogRef.close(true);
  }
}


