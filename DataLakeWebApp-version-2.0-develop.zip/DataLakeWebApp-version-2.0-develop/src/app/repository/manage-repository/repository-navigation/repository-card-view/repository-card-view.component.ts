import { TranslateService } from '@ngx-translate/core';
import { HttpParams } from '@angular/common/http';
import { Component, SimpleChanges } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { FilterOrSortingVo } from 'src/app/models/Filter-dto/filter-object-backend';
import { HeaderService } from 'src/app/service/header/header.service';
import { ManageRepositoryCardDetails } from 'src/app/models/repository-details';
import { DisabledPopupComponent } from './disabled-popup/disabled-popup.component';
import {CommentsPopupComponent} from 'src/app/common/components/comments-popup/comments-popup.component';
import {FilterObject} from 'src/app/models/Filter-dto/filter-object';
import { appConst } from 'src/app/service/app.const';
import { AppService } from 'ncloud-common-ui';
import { AccessMappingPageDto } from 'ncloud-common-ui/lib/dto/access-Mapping-PageDto ';
import { RepositoryService } from 'src/app/service/repository-management/repository-service';
@Component({
  selector: 'app-repository-card-view',
  templateUrl: './repository-card-view.component.html',
  styleUrls: ['./repository-card-view.components.scss']
})
export class RepositoryCardViewComponent{
min = 0;
maximum : any;
isCreator =false;
filterVos:FilterOrSortingVo[]=[];
repositoryDetails:ManageRepositoryCardDetails[] =[];
listpage = true;
listfiltervo:FilterOrSortingVo[]=[];
cardviewVo:FilterOrSortingVo[]=[];
appcons = appConst;
currentDate =  new Date();
filterObjectforlistview: FilterObject[] = [
     {

       columnName: 'fieldCount',
       condition: 'Equal',
       aliasName: this.translate.instant('repository_list.no_of_data'),
       type: 'field',
       value: [],
       dropdown: [],
       radio: [],
        dataType:'',
        max:11
     },
     {
       columnName: 'repoStatus',
       condition: 'IN',
       aliasName: this.translate.instant('repository_list.status'),
       type: 'chips',
       value: [],
       dropdown: ['Approved','Submitted','Rejected','Drafted', 'Disabled'],
       radio: [],
 dataType:'',
 max:11
     },
   ];
  userRoleStatus: string;
  approved:any=undefined;
  companyCardPageAccessMap: AccessMappingPageDto;
  isCardPageEnabled = false;
  pageInfo: any;
  searchValue="";
  dataNotFound = false;
  // pageStatus: boolean = true;
filterLabels()
{
this.filterObjectforlistview= [
     {

       columnName: 'fieldCount',
       condition: 'Equal',
       aliasName: this.translate.instant('repository_list.no_of_data'),
       type: 'field',
       value: [],
       dropdown: [],
       radio: [],
        dataType:'',
        max:9
     },
     {
       columnName: 'repoStatus',
       condition: 'IN',
       aliasName: this.translate.instant('repository_list.status'),
       type: 'chips',
       value: [],
       dropdown: ['Approved','Submitted','Rejected','Drafted', 'Disabled'],
       radio: [],
 dataType:'',
 max:50
     },
   ];
}
  constructor(private router:Router, private appService:AppService, private repositoryService: RepositoryService,public translate: TranslateService,private activatedRoute:ActivatedRoute,private headerService:HeaderService,private dialog: MatDialog){
  }
  ngOnInit():void {
    this.userRoleStatus = sessionStorage.getItem('userRoleStatus');
    if(this.userRoleStatus === "APPROVER"){
      this.isCreator = true;
    }
    this.getPageAccessData();
    this.filterLabels();
    //this.repositoryDetails
  }

  getPrivilege(){
    this.appService.getPrivilegeForPage(appConst.PAGE_NAME.REPOSITORY.REPOSITORY_CARD.PAGE_ID).subscribe((res: any)=>{
      this.pageInfo = res.content;
    });
  }

  getPageAccessData(): void {
    this.appService.getPageAccess(appConst.PAGE_NAME.REPOSITORY.REPOSITORY_CARD.PAGE_IDENTITY).subscribe((response: any) => {
      this.companyCardPageAccessMap = response.content;
      this.isCardPageEnabled = this.companyCardPageAccessMap.isEnabled;
      if(this.isCardPageEnabled) {
        this.doProcess();
      }
    });
  }

  doProcess(): void {
    this.getPrivilege();
    this.repositoryCount(this.filterVos);
  }

  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege?.isEnabled;
    }
    return isEnabled;
  }

   /**
   * @param  filterVos
   * @returns getListOfCount
   */
  repositoryCount(FilterVos:FilterOrSortingVo[]){
    this.headerService.getListOfCount(this.filterVos,this.searchValue,this.userRoleStatus).subscribe(Response => {
      this.maximum = Response;
    this.getRepositoryList(this.min, this.maximum, this.filterVos,this.userRoleStatus,this.searchValue);
    });


  }

   /**
   * @param min
   * @param maximum
   * @param filterVos
   * @returns RepositoryCardDetails
   */

  getRepositoryList(min  ,maximum , filterVos ,userRoleStatus,event){
      // this.repositoryDetails = null;
     this.headerService.getRepositoryDetails(this.min ,this.maximum,filterVos,userRoleStatus,event).subscribe((data:ManageRepositoryCardDetails[]) => {
     this.repositoryDetails=data;

     if (this.repositoryDetails === null || this.repositoryDetails.length === 0) {
      this.dataNotFound = true;
    } else {
      this.dataNotFound = false;
    }
       });
 }

 isCurrentDateEqual(repository : any){
  if(repository.effectiveTo){
  const effectiveToDate = new Date(repository.effectiveTo);
  return (this.currentDate >= effectiveToDate);
  }else{
    return false;
  }
 }

getfilter(event)
{
console.log(event);
this.listfiltervo=event;
if(this.maximum!=undefined)
{

  this.getRepositoryList(this.min,this.maximum,event,this.userRoleStatus,this.searchValue);
}
}
getSearchValueList(event){
  this.searchValue = event;
  this.getRepositoryList(this.min,this.maximum,this.filterVos,this.userRoleStatus, this.searchValue);
}

  disabled_popup(identity : string){

    const dialogRef = this.dialog.open(DisabledPopupComponent, {
    width: '500px',
    height: '320px',
      data: {
        name: identity,
      },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result === true) {
        this.getRepositoryList(this.min, this.maximum, this.filterVos,this.userRoleStatus,this.searchValue);
      }
    });
  }

  closeTab()
  {
    this.dialog.closeAll();
  }

opencoments()
{
 const dialogRef = this.dialog.open(CommentsPopupComponent, {
      width: '72vw', height: '75vh',
      data: {
        //notificationData:value
      },

    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {

        //this.showClaim(result, result.index);
      }

    });

}
  route(){
    this.router.navigate(['/repository/configure-repository'])
  }
  listview(){

    this.listpage =! this.listpage;
    // this.pageStatus = false;
    this.router.navigate(['/repository/manage-repository/grid-view']);
  }
  cardview(){
    this.listpage =! this.listpage
    this.repositoryCount(this.filterVos)
  }
  createnew_repo(){
    this.router.navigate(['repository/configure-repository'], {queryParams : {repoInit : true}})
  }

  editRepository(identity:string, index : any){
    const params =  new HttpParams().set('identity', identity);
    this.repositoryService.getRepositoryStatus(params).subscribe((data : any) =>{
      let response = data.content;
      this.router.navigate(['/repository/edit-repository/'+identity], {queryParams : {status : response.status, isDisabled : response.isDisabled }})
    })
  }

  cloneRepository(identity:string, index : any){
    this.router.navigate(['/repository/clone-repository/' + identity], {queryParams : {isClone : true}})
  }
}

