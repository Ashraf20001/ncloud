import {Routes} from "@angular/router";
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AuthGuard } from 'src/app/service/guard/auth.guard';
import { RepositoryCardViewComponent } from "./repository-card-view/repository-card-view.component";
import { RepositoryGridViewComponent } from "./repository-grid-view/repository-grid-view.component";
import { RepositoryNavigationComponent } from "./repository-navigation.component";

const routes: Routes = [
  {
    path:'',
    component:RepositoryNavigationComponent,
    children:[
      {
        path: 'card-view',
        component : RepositoryCardViewComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'grid-view',
        component : RepositoryGridViewComponent,
        canActivate: [AuthGuard]
      },

      {
        path: '',
        redirectTo: 'card-view',
        pathMatch: 'full'
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RepositoryNavigationRoutingMoudle { }
