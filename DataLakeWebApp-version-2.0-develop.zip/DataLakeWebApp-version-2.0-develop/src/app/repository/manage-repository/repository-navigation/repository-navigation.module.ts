import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { AppCommonModule } from 'src/app/common/components/app-common.module';
import { DemoMaterialModule } from 'src/app/common/components/material-module';
import { RepositoryNavigationRoutingMoudle } from './repository-navigation-routing.module';
import { RepositoryCardViewComponent } from './repository-card-view/repository-card-view.component';
import { RepositoryGridViewComponent } from './repository-grid-view/repository-grid-view.component';
import { DisabledPopupComponent } from './repository-card-view/disabled-popup/disabled-popup.component';


@NgModule({
  declarations: [
    RepositoryCardViewComponent,
    RepositoryGridViewComponent,
    DisabledPopupComponent,
  ],
  imports: [

    TranslateModule,
    CommonModule,
    MatIconModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule,
    RepositoryNavigationRoutingMoudle,
    DemoMaterialModule,
    AppCommonModule,
    MatTableModule,
  ],
  providers: [DatePipe],
})
export class RepositoryNavigationModule {}
