import { AfterViewInit, ChangeDetectorRef, Component, Input } from '@angular/core';
import { ViewChild } from '@angular/core';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import {FilterObject, Filtervo} from 'src/app/models/Filter-dto/filter-object';
import { FilterOrSortingVo } from 'src/app/models/Filter-dto/filter-object-backend';
import { ManageRepositoryCardDetails } from 'src/app/models/repository-details';
import { HeaderService } from 'src/app/service/header/header.service';
import {DisabledPopupComponent} from '../repository-card-view/disabled-popup/disabled-popup.component';
import {MatDialog} from '@angular/material/dialog';
import {Router} from '@angular/router';
import { AccessMappingPageDto } from 'ncloud-common-ui/lib/dto/access-Mapping-PageDto ';
import { appConst } from 'src/app/service/app.const';
import { AppService, ErrorHandlerDirective } from 'ncloud-common-ui';
import { Subject, debounceTime } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import {TranslateService} from '@ngx-translate/core';
import { HttpParams } from '@angular/common/http';
import { RepositoryService } from 'src/app/service/repository-management/repository-service';
@Component({
  selector: 'app-repository-grid-view',
  templateUrl: './repository-grid-view.component.html',
  styleUrls: ['./repository-grid-view.component.scss'],
})
export class RepositoryGridViewComponent implements AfterViewInit {

  showtabledata: any[];
  userRoleStatus: any;
filterObjectforlistview: FilterObject[] = [
     {

       columnName: 'fieldCount',
       condition: 'Equal',
       aliasName: 'repository_list.no_of_data',
       type: 'field',
       value: [],
       dropdown: [],
       radio: [],
       dataType:'',
       max:9
     },
     {
       columnName: 'repoStatus',
       condition: 'IN',
       aliasName: 'repository_list.status',
       type: 'chips',
       value: [],
       dropdown: ['Approved','Submitted','Rejected','Drafted', 'Disabled'],
       radio: [],
        dataType:'',
        max:50
     },
   ];
  customPageIndex: number=0;
  searchValue: string="";
  @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor(private paginatorName: MatPaginatorIntl,private detector: ChangeDetectorRef, private tosterservice:ToastrService,private appService: AppService,
    private errorHandler:ErrorHandlerDirective, private headerService: HeaderService,private dialog: MatDialog,private router:Router,
    private translate: TranslateService, private repositoryService : RepositoryService) {

      if(this.paginatorName) {
        this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
      }


  }

  displayedColumns: string[] = ['tablename', 'noOfdata', 'version', 'status', 'View/Edit', 'Clone', 'Disable'];

  displayedColumn: string[] = [];

  dataSource = new MatTableDataSource<ManageRepositoryCardDetails>();
  min: any = 0;
  isGotToPageDissabel = false;
  totalLength: any;
  ZERO = 0;
  TEN = 10;
  remainder: number;
  maximum: number;
  isAscOrder= false;
  minLength = 0;
  maxLength = 10;
  dataNotFound: boolean;
  endingIndex = 10;
  pagesize: number;
  upload:string=undefined;
  filterVoObject: FilterOrSortingVo[] = [];
  repositoryDetails: ManageRepositoryCardDetails[] = [];
  private _getFilterVo:FilterOrSortingVo[]=[];
  approved:any=undefined;
  getFiltervo:FilterOrSortingVo[]=[];
 isCreator:boolean =false;
 companyCardPageAccessMap: AccessMappingPageDto;
  pageInfo: any;
  appCon = appConst;
  isPageAccess = false;
  currentDate =  new Date();
//@Input()
//set getFiltervo(value: FilterOrSortingVo[]) {
//  this._getFilterVo = value;
//  if (value !== null) {
//    this.filterVoObject= this._getFilterVo;
//    if(this.maxLength !==undefined && this.filterVoObject != undefined){
//      // this.getRepositoryList(this.minLength, this.maxLength, this.filterVoObject);
//    }

//  }
//}


  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }


  @ViewChild(MatSort) sort: MatSort;
  pageChangedEvent = new Subject<number>();
  ngOnInit() {
    this.translate.onLangChange.subscribe(() => {
this.translate.instant('Pagination.Rows_per_page');
  })
    this.userRoleStatus = sessionStorage.getItem('userRoleStatus');
    if(this.userRoleStatus === "APPROVER"){
      this.isCreator = true;
    }
   /* if(this.userRoleStatus === "CREATOR"){
      this.displayedColumns.splice(4,0,'Clone');
      this.displayedColumns.splice(5,0,"Disable");
    }*/
    this.getPageAccessData();
    this.pageChangedEvent.pipe(debounceTime(300)).subscribe((data: number) => {
      this.changePageIndex();
    });

this.translate.onLangChange.subscribe(() => {
  if (this.paginator) {
    this.paginator._intl.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    this.paginator._changePageSize(this.paginator.pageSize);
    this.detector.detectChanges();
  }
});
if(this.paginatorName) {
  this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
}
  }

  /**
   * Page Access
   */
  getPageAccessData(): void {
    this.appService.getPageAccess(appConst.PAGE_NAME.REPOSITORY.REPOSITORY_GRID.PAGE_IDENTITY).subscribe((response: any) => {
      this.companyCardPageAccessMap = response.content;
      this.isPageAccess = this.companyCardPageAccessMap.isEnabled;
      if(this.isPageAccess) {
        this.repositoryCount(this.filterVoObject,this.searchValue)
        this.getRepositoryList(this.min, this.maxLength,this.filterVoObject,this.searchValue);
        this.getPrivilege();
      }
    });
  }

  /**
   *
   */
  getPrivilege(){
    this.appService.getPrivilegeForPage(appConst.PAGE_NAME.REPOSITORY.REPOSITORY_GRID.PAGE_ID).subscribe((res: any)=>{
      this.pageInfo = res.content;
    });
  }

  /**
   *
   * @param privillegeName
   * @returns
   */
  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege?.isEnabled;
    }
    return isEnabled;
  }

  ngAfterViewInit() {
    if (this.dataSource !== undefined && this.dataSource !== null) {
      this.dataSource.paginator = this.paginator;
    }
    if(this.paginatorName) {
      this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    }
  }
  pageIndex = 1;
  pageindex(){
    this.pageChangedEvent.next(this.pageIndex);
  }
  changePageIndex() {
    if (this.pageIndex > 0) {
      if (this.pageIndex != null) {
        this.maxLength = this.endingIndex * this.pageIndex;
        this.minLength = this.endingIndex * (this.pageIndex - 1);
        const totalPageIndex = this.totalLength / this.endingIndex + 1;
      if(this.pageIndex > totalPageIndex) {
        this.pageIndex = this.customPageIndex === 0 ? 1 : this.customPageIndex;
        return;
      }
        this.getRepositoryList(this.minLength, this.maxLength, this.filterVoObject,this.searchValue);
      }
    }
  }
  onKeyDown(event: KeyboardEvent) {
    if (event.keyCode === 190) {
      event.preventDefault();
    }
  }
  onpagebackward() {
    if (this.getRepositoryList.length == 0) {
      this.dataNotFound = false;
    }

  }
  repositoryName=false;
  noOfField=false;
  version=false;
  status=false;

  shortingmethod(event:string) {

    const RepositoryColumnName = event.trim();


    if (RepositoryColumnName === 'Repository Name') {
      this.repositoryName=!this.repositoryName;
      this.isAscOrder = !this.isAscOrder;
      this.noOfField=false;
      this.version=false;
      this.status=false;


        const columnName = this.getEntityColumnName(RepositoryColumnName);
        this.setSortingVO(columnName, this.isAscOrder);
        this.getRepositoryList(this.min,this.maxLength,this.filterVoObject, this.searchValue);

    } else if(RepositoryColumnName === 'Version'){
      this.repositoryName=false;
      this.noOfField=false;
      this.version=!this.version;
      this.status=false;
      this.isAscOrder = !this.isAscOrder;
        const columnName = this.getEntityColumnName(RepositoryColumnName);
        this.setSortingVO(columnName, this.isAscOrder);
        this.getRepositoryList(this.min,this.maxLength,this.filterVoObject, this.searchValue);
    } else if(RepositoryColumnName === 'Status'){
      this.isAscOrder = !this.isAscOrder;
      this.repositoryName=false;
      this.noOfField=false;
      this.version=false;
      this.status=!this.status;
        const columnName = this.getEntityColumnName(RepositoryColumnName);
        this.setSortingVO(columnName, this.isAscOrder);
        this.getRepositoryList(this.min,this.maxLength,this.filterVoObject, this.searchValue);
    }
    else if (RepositoryColumnName === 'No of Fields'){
      this.isAscOrder = !this.isAscOrder;
      this.repositoryName=false;
      this.noOfField=!this.noOfField;
      this.version=false;
      this.status=false;
        const columnName = this.getEntityColumnName(RepositoryColumnName);
        this.setSortingVO(columnName, this.isAscOrder);
        this.getRepositoryList(this.min,this.maxLength,this.filterVoObject, this.searchValue);
    }
  }
  setSortingVO(columnName: string, isAscOrder: boolean) {
    if (columnName != null && isAscOrder != null) {
      this.sortingFilterVo.columnName = columnName;
      this.sortingFilterVo.isAscending = isAscOrder;
    }
    const data = this.filterVoObject.find((element) => element.filterOrSortingType === 'SORTING');
    if (data) {
      const index: number = this.filterVoObject.indexOf(data);
      this.filterVoObject.splice(index, 1);
    }
    this.filterVoObject.push(this.sortingFilterVo);
  }

  sortingFilterVo: FilterOrSortingVo =
    {
      columnName: "",
      condition: "",
      filterOrSortingType: "SORTING",
      intgerValueList: [],
      valueList: [],
      isAscending: false,
      type: "",
      value: "",
      value2: "",
    }
  getEntityColumnName(RepositoryColumnName: string) {
    let value = '';
    if (RepositoryColumnName) {
      const data = this.sortingEntityArray.find((column) => column.tableColumnName === RepositoryColumnName);
      if (data) {
        value = data.entityColumnName;
      }
    }
    return value;


  }

  sortingEntityArray = [
    {
      tableColumnName: "Repository Name",
      entityColumnName: "repoTableName",
      type: "String"
    },
    {
      tableColumnName: "Version",
      entityColumnName: "repoVersion",
      type: "Integer"
    },
    {
      tableColumnName: "Status",
      entityColumnName: "repoStatus",
      type: "Integer"
    },
    {
      tableColumnName: "No of Fields",
      entityColumnName: "fieldCount",
      type: "Integer"
    },
  ]

cardView=false;
  cardview(){
    this.cardView =! this.cardView;
    this.router.navigate(['repository']);
  }
 createnew_repo(){
    this.router.navigate(['repository/configure-repository'], {queryParams : {repoInit : true}})
  }
  repositoryCount(filterVoObject: FilterOrSortingVo[],searchValue) {
    this.headerService.getListOfCount(filterVoObject,searchValue,this.userRoleStatus).subscribe(Response => {
      console.log(Response);
      this.totalLength = Response;
      this.maximum = this.TEN;
      this.maximumcount(this.TEN);
    })

  }
  maximumcount(event) {
    this.pagesize = event;
    this.maximum = this.totalLength / this.pagesize
    this.remainder = this.totalLength % this.pagesize;
    if (this.remainder != 0) {
      this.maximum = this.maximum + 1;
    }
  }
  disabled_popup(identity : string){

    const dialogRef = this.dialog.open(DisabledPopupComponent, {
      width: '500px',
      height: '320px',
      data: {
        name: identity,
      },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
      //  console.log('1')
      }
    });
  }
  getRepositoryList(min: number, maximum: number, filterVoObject: FilterOrSortingVo[],search:string) {
   this.repositoryDetails = null;
    this.headerService.getRepositoryDetails(min, maximum,filterVoObject,this.userRoleStatus,search).subscribe((data: ManageRepositoryCardDetails[]) => {
      this.repositoryDetails = data;
      if (this.repositoryDetails === null || this.repositoryDetails.length === 0) {
        this.dataNotFound = true;
      } else {
        this.isGotToPageDissabel = false;
        this.customPageIndex = maximum/this.endingIndex;
        this.dataNotFound = false;
      }
      this.showtabledata = [];
      this.dataSource = new MatTableDataSource<ManageRepositoryCardDetails>(this.repositoryDetails);
    },

    (error:Response)=>{
      this.errorHandler.getMessage(error);
    })
  }

  getSearchValueList(event){
    this.searchValue = event;
    this.repositoryCount(this.filterVoObject,this.searchValue);
    this.getRepositoryList(this.min,this.maxLength,this.filterVoObject, this.searchValue);
  }

  changePage(event) {
    if(event.pageIndex > event.previousPageIndex ){
      this.customPageIndex = event.pageIndex+1;
    }else{
     this.customPageIndex =  this.customPageIndex-1;
    }
    if (event.pageIndex != this.ZERO) {
      this.pageIndex = event.pageIndex + 1;
      this.maxLength = event.pageSize;
      this.minLength = (event.pageSize * event.pageIndex);
      this.endingIndex = event.pageSize;
      this.pageIndex = this.customPageIndex;
      if (this.pagesize != event.pageSize) {
        this.maximumcount(event.pageSize);
      }
    } else {
      this.pageIndex = 1;
      this.maxLength = event.pageSize;
      this.minLength = event.pageIndex;
      this.endingIndex = event.pageSize;
      if (this.pagesize != event.pageSize) {
        this.maximumcount(event.pageSize);

      }
    }
    this.getRepositoryList(this.minLength, this.maxLength, this.filterVoObject,this.searchValue);
  }

 isCurrentDateEqual(repository : any){
  if(repository.effectiveTo){
  const effectiveToDate = new Date(repository.effectiveTo);
  return (this.currentDate >= effectiveToDate);
  }else{
    return false;
  }
 }

  editRepository(identity:string, element : any){
    const params =  new HttpParams().set('identity', identity);
    this.repositoryService.getRepositoryStatus(params).subscribe((data : any) =>{
      let response = data.content;
      this.router.navigate(['/repository/edit-repository/'+identity], {queryParams : {status : response.status, isDisabled : response.isDisabled}})
    })
  }

  cloneRepository(identity:string, index : any){
    this.router.navigate(['/repository/clone-repository/' + identity], {queryParams : {isClone : true}})
  }
getfilter(event)
{
const regexPattern = /^(?:[0-9]+|null)$/;
const inputString = event[0].value;
const isMatch = regexPattern.test(inputString);
if(isMatch){
  if(this.maximum!=undefined)
{
  this.filterVoObject = event;
  this.getRepositoryList(this.min,this.maxLength,event,this.searchValue);
  this.repositoryCount(event,this.searchValue);
  this.pageIndex = 1;
}
}else{
  this.tosterservice.error(this.translate.instant('Toaster_error.Data Type Not Valid. Please Provide Data With Valid Data Type'));
}
}
}

