import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RepositoryGridViewComponent } from './repository-grid-view.component';

describe('RepositoryGridViewComponent', () => {
  let component: RepositoryGridViewComponent;
  let fixture: ComponentFixture<RepositoryGridViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RepositoryGridViewComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RepositoryGridViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
