import { Component } from '@angular/core';

@Component({
  selector: 'app-repository-navigation',
  templateUrl: './repository-navigation.component.html',
  styleUrls: ['./repository-navigation.component.scss']
})
export class RepositoryNavigationComponent {

}
