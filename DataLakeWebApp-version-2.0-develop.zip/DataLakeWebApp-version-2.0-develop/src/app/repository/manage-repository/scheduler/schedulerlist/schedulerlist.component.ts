import { FilterOrSortingVo } from 'src/app/models/Filter-dto/filter-object-backend';
import { AfterViewInit, ChangeDetectorRef, Component, ViewChild } from '@angular/core';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { HeaderService } from 'src/app/service/header/header.service';
import { NotificationService } from 'src/app/service/notification.service';
import { ManageRepositoryCardDetails } from 'src/app/models/repository-details';
import { AccessMappingPageDto } from 'ncloud-common-ui/lib/dto/access-Mapping-PageDto ';
import { appConst } from 'src/app/service/app.const';
import { AppService } from 'ncloud-common-ui';
import { Subject, debounceTime } from 'rxjs';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'app-schedulerlist',
  templateUrl: './schedulerlist.component.html',
  styleUrls: ['./schedulerlist.component.scss']
})
export class SchedulerlistComponent implements AfterViewInit {
 response: any;
  isPageAccess = false;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor(private paginatorName: MatPaginatorIntl,
    private detector: ChangeDetectorRef,private router:Router, private route: ActivatedRoute, private appService: AppService, private notification: NotificationService,private headerService:HeaderService,private toastr: ToastrService,private translate :TranslateService){
      if(this.paginatorName) {
        this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
      }

  }

  displayedColumns: string[] = [ 'Notification Name','Message','Triggered Status','Remainder Period', 'Status','Edit' ];
  // dataSource = new MatTableDataSource(ELEMENT_DATA);
maximum: any;
dataNotFound:boolean;
show_edit=true;
  schedulerDetails: SchedulerDetails[] = [];
  endingIndex = 10;
  maxLength: number = 10;
  minLength: number = 0;
  totalLength: any;
  pagesize: number;
  customPageIndex: number=0;
  element: any;
  identity: string;

  dataSource = new MatTableDataSource(this.schedulerDetails);
  // maximum: any;
  // pageIndex: any = 1;
  // dataNotFound: boolean;
  // show_edit = true;
  min: number = 0;
  max: number = 10;
  remainder: number;
  isGotToPageDissabel: boolean = false;
  filterVoObject: FilterOrSortingVo[] = [];
 isAscOrder= false;
 companyCardPageAccessMap: AccessMappingPageDto;
  pageInfo: any;
  appCon = appConst;

  pageChangedEvent = new Subject<number>();
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }


  scheduler_edit(identity : string) {
    this.identity = identity;
    this.show_edit = !this.show_edit;
    this.router.navigate(['..', 'edit', this.identity ],{relativeTo:this.route});
  }

  listvaluechanged($event) {
    this.show_edit = true;
  }


  @ViewChild(MatSort) sort: MatSort;
  // eslint-disable-next-line @angular-eslint/use-lifecycle-interface
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    if(this.paginatorName) {
      this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    }
  }
 pageIndex = 1;
  pageindex() {
    this.pageChangedEvent.next(this.pageIndex);
  }
  changePageIndex() {
    if (this.pageIndex > 0) {
      if (this.pageIndex != null) {
        this.maxLength = this.endingIndex * this.pageIndex;
        this.minLength = this.endingIndex * (this.pageIndex - 1);
        console.log('pageindex');
        const totalPageIndex = this.totalLength / this.endingIndex + 1;
      if(this.pageIndex > totalPageIndex) {
        this.pageIndex = this.customPageIndex === 0 ? 1 : this.customPageIndex;
        return;
      }
        this.getschdeulerList(this.minLength, this.maxLength,this.filterVoObject);
      }
    }
  }
  onpagebackward() {
    if (this.getschdeulerList.length == 0) {
      this.dataNotFound = false;
    }
  }
  maximumcount(event) {
    this.pagesize = event;
    this.maximum = this.totalLength / this.pagesize;
    this.remainder = this.totalLength % this.pagesize;
    if (this.remainder != 0) {
      this.maximum = this.maximum + 1;
    }
  }
  changepageindex(event) {
    if(event.pageIndex > event.previousPageIndex ){
      this.customPageIndex = event.pageIndex+1;
    }else{
     this.customPageIndex =  this.customPageIndex-1;
    }
    if (event.pageIndex != this.min) {
      this.pageIndex = event.pageIndex + 1;
      this.maxLength = event.pageSize;
      this.minLength = event.pageSize * event.pageIndex;
      this.endingIndex = event.pageSize;
      if (this.pagesize != event.pageSize) {
        this.maximumcount(event.pageSize);
      }
    } else {
      this.pageIndex = 1;
      this.maxLength = event.pageSize;
      this.minLength = event.pageIndex;
      this.endingIndex = event.pageSize;
      if (this.pagesize != event.pageSize) {
        this.maximumcount(event.pageSize);
      }
    }
    this.getschdeulerList(this.minLength, this.maxLength,this.filterVoObject);
  }
  getSchedulerrecord() {
    this.notification
      .getSchedulerCount()
      .subscribe((data) => {
        console.log(data);
        this.totalLength = data;
        this.maximumcount(this.totalLength);
      });
  }
  getschdeulerList(Min, Max,filtervo) {
    this.notification.getnotification(Min, Max,filtervo).subscribe((data: SchedulerDetails[]) => {
        this.schedulerDetails = null;
        this.schedulerDetails = data;
        let dummyScheduler=[];
      data.forEach(a => {
            let SchedulerCopy : SchedulerDetails = {
              notificationName: a.notificationName,
           message: a.message,
           triggeredStatus: a.triggeredStatus,
           remainder: a.remainder,
           status: a.status === true? 'Active':'InActive',
           identity:a.identity,
            }
            dummyScheduler.push(SchedulerCopy);
          });
         this.schedulerDetails=dummyScheduler;
        if (this.schedulerDetails.length == 0 ||this.schedulerDetails == null ) {
          this.dataNotFound = true;
          this.isGotToPageDissabel = true;
        }else if(this.schedulerDetails.length <=9){
          this.isGotToPageDissabel=true;
        } else {
          this.dataNotFound = false;
          this.isGotToPageDissabel = false;
          this.customPageIndex = Max/this.endingIndex;
        }
        this.dataSource = new MatTableDataSource<SchedulerDetails>(
          this.schedulerDetails
        );
      });
  }

  ngOnInit() {
    this.translate.onLangChange.subscribe(() => {
this.translate.instant('Pagination.Rows_per_page');
  })
    this.getSchedulerrecord();
    this.getPageAccessData();
    this.pageChangedEvent.pipe(debounceTime(300)).subscribe((data: number) => {

      this.changePageIndex();

    });
    this.translate.onLangChange.subscribe(() => {
      if (this.paginator) {
        this.paginator._intl.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
        this.paginator._changePageSize(this.paginator.pageSize);
        this.detector.detectChanges();
      }
    });
    if(this.paginatorName) {
      this.paginatorName.itemsPerPageLabel = this.translate.instant('Paginator.ItemsPerPageLabel');
    }
  }

  /**
   * Page Access
   */
  getPageAccessData(): void {
    this.appService.getPageAccess(appConst.PAGE_NAME.SCHEDULER.SCHEDULER_LIST.PAGE_IDENTITY).subscribe((response: any) => {
      this.companyCardPageAccessMap = response.content;
      this.isPageAccess = this.companyCardPageAccessMap.isEnabled;
      if(this.isPageAccess) {
        this.getschdeulerList(this.min, this.max,this.filterVoObject);
        this.getPrivilege();
      }
    });
  }

  /**
   *
   */
  getPrivilege(){
    this.appService.getPrivilegeForPage(appConst.PAGE_NAME.SCHEDULER.SCHEDULER_LIST.PAGE_ID).subscribe((res: any)=>{
      this.pageInfo = res.content;
    });
  }

  /**
   *
   * @param privillegeName
   * @returns
   */
  checkPrivillege(privillegeName: string): boolean {
    let isEnabled = true;
    if(this.pageInfo && this.pageInfo.length > 0) {
      const privillege = this.pageInfo.find((prv: any) => prv.privilegeName === privillegeName);
      isEnabled = privillege?.isEnabled;
    }
    return isEnabled;
  }

  notificationName=false;
  message=false;
  triggeredStatus=false;
  remainderPeriod=false;
  status=false;
  sortingmethod(data : any) {
    // const SchdedulerColumnName = event.target.innerText.trim();
    const SchdedulerColumnName  = data;
    if (SchdedulerColumnName === 'Repository Name') {
      this.isAscOrder = !this.isAscOrder;
      this.notificationName= !this.notificationName;
      this.message=false;
      this.triggeredStatus=false;
      this.remainderPeriod=false;
      this.status=false;
        const columnName = this.getEntityColumnName(SchdedulerColumnName);
        this.setSortingVO(columnName, this.isAscOrder);
        this.getschdeulerList(this.minLength,this.maxLength,this.filterVoObject);
    }else if(SchdedulerColumnName === 'Message'){
      this.isAscOrder = !this.isAscOrder;
      this.notificationName=false;
      this.message=!this.message;
      this.triggeredStatus=false;
      this.remainderPeriod=false;
      this.status=false;
        const columnName = this.getEntityColumnName(SchdedulerColumnName);
        this.setSortingVO(columnName, this.isAscOrder);
        this.getschdeulerList(this.minLength,this.maxLength,this.filterVoObject);
    } else if(SchdedulerColumnName === 'Status'){
      this.isAscOrder = !this.isAscOrder;
      this.notificationName=false;
      this.message=false;
      this.triggeredStatus=false;
      this.remainderPeriod=false;
      this.status=!this.status;
        const columnName = this.getEntityColumnName(SchdedulerColumnName);
        this.setSortingVO(columnName, this.isAscOrder);
        this.getschdeulerList(this.minLength,this.maxLength,this.filterVoObject);
    }
    else if (SchdedulerColumnName === 'Triggered Status'){
      this.isAscOrder = !this.isAscOrder;
      this.notificationName=false;
      this.message=false;
      this.triggeredStatus=!this.triggeredStatus;
      this.remainderPeriod=false;
      this.status=false;
        const columnName = this.getEntityColumnName(SchdedulerColumnName);
        this.setSortingVO(columnName, this.isAscOrder);
        this.getschdeulerList(this.minLength,this.maxLength,this.filterVoObject);
    }  else if (SchdedulerColumnName === 'Remainder Period'){
      this.isAscOrder = !this.isAscOrder;
      this.notificationName=false;
      this.message=false;
      this.triggeredStatus=false;
      this.remainderPeriod=!this.remainderPeriod;
      this.status=false;
        const columnName = this.getEntityColumnName(SchdedulerColumnName);
        this.setSortingVO(columnName, this.isAscOrder);
        this.getschdeulerList(this.minLength,this.maxLength,this.filterVoObject);
    }
  }
  setSortingVO(columnName: string, isAscOrder: boolean) {
    if (columnName != null && isAscOrder != null) {
      this.sortingFilterVo.columnName = columnName;
      this.sortingFilterVo.isAscending = isAscOrder;
    }
    const data = this.filterVoObject.find((element) => element.filterOrSortingType === 'SORTING');
    if (data) {
      const index: number = this.filterVoObject.indexOf(data);
      this.filterVoObject.splice(index, 1);
    }
    this.filterVoObject.push(this.sortingFilterVo);
  }

  sortingFilterVo: FilterOrSortingVo =
    {
      columnName: "",
      condition: "",
      filterOrSortingType: "SORTING",
      intgerValueList: [],
      valueList: [],
      isAscending: false,
      type: "",
      value: "",
      value2: "",
    }

  getEntityColumnName(SchdedulerColumnName: string) {
    let value = '';
    if (SchdedulerColumnName) {
      const data = this.sortingEntityArray.find((column) => column.tableColumnName === SchdedulerColumnName);
      if (data) {
        value = data.entityColumnName;
      }
    }
    return value;

  }
   sortingEntityArray = [
    {
      tableColumnName: "Remainder Period",
      entityColumnName: "remainder",
      type: "Integer"
    },
    {
      tableColumnName: "Repository Name",
      entityColumnName: "notificationName",
      type: "String"
    },
    {
      tableColumnName: "Triggered Status",
      entityColumnName: "triggeredStatus",
      type: "String"
    },
    {
      tableColumnName: "Status",
      entityColumnName: "status",
      type: "String"
    },
   {
      tableColumnName: "Message",
      entityColumnName: "message",
      type: "String"
    },
  ]

  deleteOption(identity: string) {
    this.headerService.updateSchedulerDelete(identity).subscribe((data: any) => {
      if(data){
      this.getSchedulerrecord();
      this.getschdeulerList(this.min, this.max, this.filterVoObject);
      this.showToast();
    }
    });
  }

showToast() {
  this.toastr.success(this.translate.instant('Toaster_success.Repository has been deleted Successfully'));
}
onKeyDown(event: KeyboardEvent) {
  if (event.keyCode === 190) {
    event.preventDefault();
  }
}
}
export class SchedulerDetails {
  notificationName: string;
  message: string;
  triggeredStatus: string;
  remainder: number;
  status: any;
  identity:string;
}
//const ELEMENT_DATA: RepositoryDetails[] = [
//  { Notification_Name :'Remainder',Message:'Upload data for Blacklisted Customer',Triggered_Status:'Approved',Remainder_Period:'30 days', status:'Active'},


export class RepositoryDetails
{
  Notification_Name:string;
  Message:string;
  Triggered_Status:string;
  Remainder_Period:string;
  status:string;


}
const ELEMENT_DATA: RepositoryDetails[] = [
  { Notification_Name :'Remainder',Message:'Upload data for Blacklisted Customer',Triggered_Status:'Approved',Remainder_Period:'30 days', status:'Active'},

];




