import { NgModule } from '@angular/core';
import { SchedulerComponent } from './scheduler.component';
import { SchedulerlistComponent } from './schedulerlist/schedulerlist.component';
import { CommonModule, DatePipe } from '@angular/common';
import { SchedulerRoutingMoudle } from './scheduler-routing.module';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { AppCommonModule } from 'src/app/common/components/app-common.module';
import { DemoMaterialModule } from 'src/app/common/components/material-module';
import { ManageRepositoryRoutingMoudle } from '../manage-repository-routing.module';
import {SchedulerEditComponent} from './scheduler-edit/scheduler-edit.component';
import {RepeatPopupComponent} from './scheduler-edit/repeat-popup/repeat-popup.component';

@NgModule({
  declarations: [SchedulerComponent, SchedulerlistComponent, SchedulerEditComponent, RepeatPopupComponent],
  imports: [
    SchedulerRoutingMoudle,
    TranslateModule,
    CommonModule,
    MatIconModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule,
    ManageRepositoryRoutingMoudle,
    DemoMaterialModule,
    AppCommonModule,
    MatTableModule,
  ],
  providers: [DatePipe],
})
export class SchedulerModule {}
