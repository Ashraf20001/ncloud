import {Routes} from "@angular/router";
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AuthGuard } from 'src/app/service/guard/auth.guard';
import {SchedulerComponent} from "./scheduler.component";
import {SchedulerlistComponent} from "./schedulerlist/schedulerlist.component";
import {SchedulerEditComponent} from "./scheduler-edit/scheduler-edit.component";

const routes: Routes = [
  {
    path:'', 
    component:SchedulerComponent,
    children:[
      {
        path: 'list',
        component : SchedulerlistComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'edit/:id',
        component : SchedulerEditComponent,
        canActivate: [AuthGuard]
      },
      {
        path: '',
        redirectTo: 'list',
        pathMatch: 'full'
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SchedulerRoutingMoudle { }
