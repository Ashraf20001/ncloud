import {Component, EventEmitter, Inject, Input, LOCALE_ID, Output} from "@angular/core";
import {FormControl} from "@angular/forms";
import {MatDialog} from "@angular/material/dialog";
import {Router,ActivatedRoute} from "@angular/router";
import {ToastrService} from "ngx-toastr";
import {RepositoryScheduleDetailsDto} from "src/app/models/RepositoryScheduleDetailsDto";
import {HeaderService} from "src/app/service/header/header.service";
import {RepeatPopupComponent} from "./repeat-popup/repeat-popup.component";
import * as _ from 'lodash';
import { TranslateService } from "@ngx-translate/core";
import { DatePipe } from "@angular/common";

@Component({
  selector: 'app-scheduler-edit',
  templateUrl: 'scheduler-edit.component.html',
  styleUrls: ['scheduler-edit.component.scss']
})
export class SchedulerEditComponent {
  element: RepositoryScheduleDetailsDto[];
  format: any;
  repositoryScheduleDetailsDto: RepositoryScheduleDetailsDto = new RepositoryScheduleDetailsDto();
  startdate: any;
  periodValue: any ;
  time: any;
  schedularDto: any;
  range = new Date();
  times = "12:00 AM";
  @Input() identity: any;
  repository: any;
  selectedDay: any;
  selectedOnMonth: any;
  selectedDays: any;
  dateTime:any;
  remainderPeriods:any;
  validateObject: any;
  repeatCount: any;
  repeatOn: any;
  repeatOnDay: any;
  repeatOnMonth: any;
  triggeredStatus: any;
  repositoryName: any;
  repeatformat: string;
  remainderPeriodmain: any;
  repeatFormat: any;
  formats: string;
  timeZone: any;
  dateFormat = 'yyyy-MM-dd'; 
  // week: string = "Week";
  constructor(private dialog: MatDialog,public translate:TranslateService,private header :HeaderService,private toastr: ToastrService,private route:Router,private routes:ActivatedRoute, @Inject(LOCALE_ID) private locale: string, private datePipe: DatePipe ){
    this.timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone
  }
  notificationMessage: any
  remainderPeriod: FormControl = new FormControl();
  enddate: any;
  repositoryDto = new RepositoryScheduleDetailsDto();
  @Output() listEvent = new EventEmitter<boolean>();
  isActive: boolean;
  isDataChanged = false;
  back_to_list() {
    this.listEvent.emit();
    this.route.navigateByUrl('/repository/scheduler');
  }
  onToggling(event: any) {
    this.isActive = event.checked;
  }
  states = [
    'Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut', 'Delaware',
    'Florida', 'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky'
  ];
  period = [
     'Every Weekly (Mon-Fri)', 'Daily', 'Weekly', 'Monthly', 'Yearly', 'Custom'
  ]
  periodData = [
    {
      key: 'no-repeat',
      value: 'Does not repeat'
    },

  ];

  defaultValue = { hour: 13, minute: 30 };
  timeChangeHandler(event: any) { }
  invalidInputHandler() { }

  timeperiod: string
  selectedPeriod(event: any) {
    if (event == 'Weekly') {
      this.format = 'WEEK'
    } else if (event == 'Monthly') {
      this.format = 'MONTH'
    } else if (event == 'Yearly') {
      this.format = 'YEAR'
    } else if (event == 'Daily') {
      this.format = 'DAY'
    } else if( event == 'Every Weekly (Mon-Fri)'){
      this.format = 'Every Weekly (Mon-Fri)'
    }
    this.repeatFormat = this.format
      const dialogRef = this.dialog.open(RepeatPopupComponent, {
        width: '650px',
        // height: '470px',
        data: {
          timeperiod: this.timeperiod,
          startDate: this.startdate,
          endDate: this.enddate,
          remainderPeriod: this.remainderPeriod,
          notificationMessage: this.notificationMessage,
          isActive: this.isActive,
          time: this.time,
          identity: this.identity,
          selectedDays: this.selectedDays,
          selectedDay: this.selectedDay,
          repeatOn: this.repeatOn,
          repeatOnDay: this.repeatOnDay,
          repeatOnMonth: this.repeatOnMonth,
          selectedOnMonth: this.selectedOnMonth,
          repeatCount: this.repeatCount,
          times: this.time,
          format: this.format,
          triggeredStatus : this.triggeredStatus,
          repositoryName : this.repositoryName
        },
      });
      dialogRef.afterClosed().subscribe((result) => {
        console.log(result);
        if (result) {
          this.startdate = result.startdate;
          this.enddate = result.endDate;
          this.format = result.repeatFormat;
          this.timeperiod = result.timeperiod;
          this.remainderPeriod = result.remainderPeriod;
          this.selectedDays = result.selectedDays;
          this.selectedDay = result.selectedDay;
          this.repeatOn = result.repeatOn;
          this.repeatOnDay = result.repeatOnDay;
          if(result.repeatOnMonth === 'January'){
            this.repeatOnMonth = 'JAN'
         }else if (result.repeatOnMonth === 'February'){
           this.repeatOnMonth = 'FEB'
         }else if (result.repeatOnMonth === 'March'){
           this.repeatOnMonth = 'MAR'
         }else if(result.repeatOnMonth === 'April'){
           this.repeatOnMonth = 'APR'
         }else if(result.repeatOnMonth === 'May'){
           this.repeatOnMonth = 'MAY'
         }else if(result.repeatOnMonth === 'June'){
           this.repeatOnMonth = 'JUN'
         }else if(result.repeatOnMonth === 'July'){
           this.repeatOnMonth = 'JUL'
         }else if (result.repeatOnMonth === 'August'){
          this.repeatOnMonth = 'AUG'
        }else if(result.repeatOnMonth === 'September'){
          this.repeatOnMonth = 'SEP'
        }else if(result.repeatOnMonth === 'October'){
          this.repeatOnMonth = 'OCT'
        }else if(result.repeatOnMonth === 'November'){
          this.repeatOnMonth = 'NOV'
        }else if(result.repeatOnMonth === 'December'){
          this.repeatOnMonth = 'DEC'
        }

          // this.repeatOnMonth = result.repeatOnMonth;
          this.selectedOnMonth = result.selectedOnMonth;
          this.repeatCount = result.repeatCount;
          this.repeatFormat = result.repeatFormat
          this.format = result.repeatFormat
          result.time = this.time;
          if (this.format == 'Weekly')  {
            result.repeatFormat = 'WEEK'
          } else if (this.format == 'Monthly') {
            result.repeatFormat = 'MONTH'
          } else if (this.format == 'Yearly') {
            result.repeatFormat= 'YEAR'
          } else if (this.format == 'Daily') {
            result.repeatFormat = 'DAY'
          }
          this.schedularDto = result;
          console.log(this.schedularDto);
        }
      });

  }

  ngOnInit(){
  // this.times=new Date(1,2,12).getTime();
   console.log(this.times);
     this.routes.params.subscribe((params : any) => {
      this.identity = params['id']
    });
    this.header.getSchedulerDetails(this.identity).subscribe((data:any) => {
      this.repositoryScheduleDetailsDto = data;
      this.validateObject = _.cloneDeep(data);
      this.startdate = data.startdate;
      if(this.startdate){
        const datePart = data.endDate.split('T')[0];
        const date1 = new Date(datePart);
        const date2 = new Date(this.startdate);
        if(date2 > date1){
          this.enddate = this.startdate;
        }else{
          this.enddate = datePart;
        }
      }
      this.isActive = data.isActive;
      this.selectedDay = data.selectedDay;
      this.selectedOnMonth = data.selectedOnMonth;
      this.selectedDays = data.selectedDays;
      this.remainderPeriods = data.remainderPeriod+" "+'days';
      this.remainderPeriod = data.remainderPeriod;
      this.time = data.time;
      this.repeatCount = data.repeatCount
      this.repeatOn = data.repeatOn;
      this.repeatOnDay = data.repeatOnDay;
      this.repeatOnMonth = data.repeatOnMonth
      this.triggeredStatus = this.translate.instant('ReporitoryStatuss.'+ data.triggeredStatus)
      this.repositoryName = data.repositoryName
      this.notificationMessage = data.notificationMessage
      this.repeatFormat = data.repeatFormat
      if (data.repeatFormat === 'WEEK') {
        this.format = 'Weekly';
      } else if (data.repeatFormat === 'MONTH') {
        this.format = 'Monthly'
      } else if (data.repeatFormat === 'YEAR') {
        this.format = 'Yearly'
      } else if (data.repeatFormat === 'DAY') {
        this.format = 'Daily'
      } else if (data.repeatFormat === 'REPEAT'){
        this.format = 'Does not repeat'
      }

    });
  }

  activeStatus() {
    this.isActive = !this.isActive;
    this.isDataChanged = true;
  }
  // TimePeriods(time) {
  //   this.time= time;

  // }
  onDateSelected(event:any){
     if(event){
      // const date1 = new Date(this.enddate);
      const date2 = new Date(this.enddate);
      if(date2 < event){
        this.enddate = this.startdate
      }else{
        this.enddate = this.enddate;
      }
    }

  }

  saveSchedulerList() {
    if(this.notificationMessage.length <= 200){
      if(!this.schedularDto) {
        this.schedularDto = {
          notificationMessage: this.notificationMessage,
          startdate: this.startdate,
          endDate: this.enddate,
          repeatFormat: this.repeatFormat,
          schedulerIdentity: this.identity,
          selectedDay: this.selectedDay,
          selectedDays: this.selectedDays,
          repeatOn: this.repeatOn,
          remainderPeriod : this.remainderPeriod,
          repeatOnDay: this.repeatOnDay,
          repeatOnMonth: this.repeatOnMonth,
          selectedOnMonth: this.selectedOnMonth,
          isActive: this.isActive,
          time: this.time,
          triggeredStatus:  this.translate.instant('ReporitoryStatus.'+ this.triggeredStatus),
          repositoryName: this.repositoryName,
          repeatCount: this.repeatCount
        }
    }
    this.startdate = this.datePipe.transform(this.startdate, this.dateFormat, this.timeZone, this.locale);
    this.schedularDto.startdate = this.startdate;
    this.enddate = this.datePipe.transform(this.enddate, this.dateFormat, this.timeZone, this.locale);
    this.schedularDto.endDate = this.enddate;
    this.schedularDto.time = this.time;
    this.schedularDto.remainderPeriod = this.remainderPeriod;
    this.schedularDto.isActive = this.isActive;
    this.header.updateSchedulerList(this.schedularDto).subscribe((data: any) => {
      this.toastr.success(this.translate.instant('Toaster_success.Dataupdatedsuccessfully'));
      this.route.navigateByUrl('/repository/scheduler/list');
    });
  } else {
    this.toastr.error(this.translate.instant('Toaster_success.error_message'));
}
}
}
