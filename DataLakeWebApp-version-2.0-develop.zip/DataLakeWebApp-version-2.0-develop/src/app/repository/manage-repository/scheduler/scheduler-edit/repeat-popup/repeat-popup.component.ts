import {DatePipe} from '@angular/common';
import { Component, Inject, inject } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatDialogRef } from '@angular/material/dialog';
import { Data } from '@angular/router';
import { kMaxLength } from 'buffer';
import { RepositoryScheduleDetailsDto } from 'src/app/models/RepositoryScheduleDetailsDto';
import { HeaderService } from 'src/app/service/header/header.service';

@Component({
  selector: 'app-repeat-popup',
  templateUrl: './repeat-popup.component.html',
  styleUrls: ['./repeat-popup.component.scss']
})
export class RepeatPopupComponent {


  timePeroid:string;
  repositoryScheduleDetailsDto:RepositoryScheduleDetailsDto = new RepositoryScheduleDetailsDto();
  startdate: any;
  selectedday: FormControl =  new FormControl();
  repeatCnt: FormControl = new FormControl();
  enddate: any;
  periodValue: any;
  remainderPeriod: any;
  identity: any;
  notificationMessage: any;
  isActive: boolean;
  time: any;
  selectedDays: any;
  repeatOn: any;
  repeatOnMonth: any;
  selectedOnMonth: any;
  repeatOnDay: any;
  selectedOption: string;
  dayOfWeek : string[] = [];
  defaultWeek:string[] = ["MON","TUE","WED","THU","FRI"];
  arrayList: string;
  selectedDay: any;
  schedularIdentity : any;
  times: any;
  repeatCount: any;
  format: any;
  dayFormat: string;
  weekFormat: string;
  monthlyFormat: string;
  date: number;
  triggerStatus: any;
  repositoryName: any;
  selectedmonthlyFormat: string;
  toshow: boolean = false;
  toshows: boolean = true;
  disable: boolean = false;
  selectedOptions: string;
constructor( @Inject(MAT_DIALOG_DATA) public data:DailogData,public datepipe:DatePipe,public dialogRef: MatDialogRef<RepeatPopupComponent> )
{
  
this.timePeroid=data['timeperiod'];
this.startdate = data['startDate'];
this.format = data['format'];
// this.periodValue = data['periodValue'];
this.remainderPeriod = data['remainderPeriod'];
this.identity = data['identity']
this.notificationMessage = data['notificationMessage'];
this.isActive = data['isActive'];
this.time = data['time'];
this.repositoryName = data['repositoryName'];
// this.identity = data['identity'];
this.selectedDays = data['selectedDays']
this.selectedDay = data['selectedDay'];
this.repeatOn = data['repeatOn'];
this.repeatOnDay = data['repeatOnDay'];
this.repeatOnMonth = data['repeatOnMonth'];
this.selectedOnMonth = data['selectedOnMonth'];
this.repeatCount = data['repeatCount'];
this.enddate = data['endDate'];
this.month=this.selectedOnMonth
this.date=this.selectedDay
this.times = data['times'];
this.triggerStatus = data['triggeredStatus'];
this.startdateonly=new Date(this.startdate);
dialogRef.disableClose = true;
if (this.format == 'Every Weekly (Mon-Fri)'){
  this.timePeroid = 'Weekly'
  const val = 'MON,TUE,WED,THU,FRI'
  const checkvalueDays = val.split(',');
  checkvalueDays.forEach((value: string) => {
    const index = this.days.findIndex((day: Week) => day.value === value);
    if(index !== -1) {
      this.changeColor[index] = true;
      this.dayOfWeek.push(value);
      this.selectedDays = this.dayOfWeek.join();
    }
  })
}else if (this.selectedDays) {
  this.dayOfWeek = []
  const checkvalueDays = this.selectedDays.split(',');
  checkvalueDays.forEach((value: string) => {
    const index = this.days.findIndex((day: Week) => day.value === value);
    if(index !== -1) {
      this.changeColor[index] = true;
      this.dayOfWeek.push(value);
    }
  });
}

if (this.format == 'Custom'){
  this.timePeroid = 'Daily'
}

// this.timePeroid = this.format
if (this.format == 'WEEK')  {
  this.timePeroid = 'Weekly'
  this.disable = false;
} else if (this.format == 'MONTH') {
  this.timePeroid = 'Monthly'
  this.disable = false;
} else if (this.format == 'YEAR') {
  this.timePeroid = 'Yearly'
  this.disable = true;
} else if (this.format == 'DAY') {
  this.timePeroid = 'Daily'
  this.disable = false;
}

this.validateSelectedOnMonth(this.selectedOnMonth);
this.validateRoleOnday(this.repeatOn);
 this.validateWeekdays(this.repeatOnDay);
 this.validateOnYear(this.repeatOnMonth);
}
  validateSelectedOnMonth(selectedOnMonth: any) {
    if(selectedOnMonth === 'JAN'){
      this.selectedmonthlyFormat = 'January'
   }else if (selectedOnMonth === 'FEB'){
     this.selectedmonthlyFormat = 'February'
   }else if (selectedOnMonth === 'MAR'){
     this.selectedmonthlyFormat = 'March'
   }else if(selectedOnMonth === 'APR'){
     this.selectedmonthlyFormat = 'April'
   }else if(selectedOnMonth === 'MAY'){
     this.selectedmonthlyFormat = 'May'
   }else if(selectedOnMonth === 'JUN'){
     this.selectedmonthlyFormat = 'June'
   }else if(selectedOnMonth === 'JUL'){
     this.selectedmonthlyFormat = 'July'
   }else if (selectedOnMonth === 'AUG'){
    this.selectedmonthlyFormat = 'August'
  }else if(selectedOnMonth === 'SEP'){
    this.selectedmonthlyFormat = 'September'
  }else if(selectedOnMonth === 'OCT'){
    this.selectedmonthlyFormat = 'October'
  }else if(selectedOnMonth === 'NOV'){
    this.selectedmonthlyFormat = 'November'
  }else if(selectedOnMonth === 'DEC'){
    this.selectedmonthlyFormat = 'December'
  }
  }
  validateOnYear(repeatOnMonth: any) {
    if(repeatOnMonth === 'JAN'){
      this.monthlyFormat = 'January'
   }else if (repeatOnMonth === 'FEB'){
     this.monthlyFormat = 'February'
   }else if (repeatOnMonth === 'MAR'){
     this.monthlyFormat = 'March'
   }else if(repeatOnMonth === 'APR'){
     this.monthlyFormat = 'April'
   }else if(repeatOnMonth === 'MAY'){
     this.monthlyFormat = 'May'
   }else if(repeatOnMonth === 'JUN'){
     this.monthlyFormat = 'June'
   }else if(repeatOnMonth === 'JUL'){
     this.monthlyFormat = 'July'
   }else if (repeatOnMonth === 'AUG'){
    this.monthlyFormat = 'August'
  }else if(repeatOnMonth === 'SEP'){
    this.monthlyFormat = 'September'
  }else if(repeatOnMonth === 'OCT'){
    this.monthlyFormat = 'October'
  }else if(repeatOnMonth === 'NOV'){
    this.monthlyFormat = 'November'
  }else if(repeatOnMonth === 'DEC'){
    this.monthlyFormat = 'December'
  }

  }
  validateWeekdays(repeatOnDay: any) {
    if(repeatOnDay === 'MON'){
      this.weekFormat = 'Monday'
   }else if (repeatOnDay === 'TUE'){
     this.weekFormat = 'Tuesday'
   }else if (repeatOnDay === 'WED'){
     this.weekFormat = 'Wednesday'
   }else if(repeatOnDay === 'THU'){
     this.weekFormat = 'Thursday'
   }else if(repeatOnDay === 'FRI'){
     this.weekFormat = 'Friday'
   }else if(repeatOnDay === 'SAT'){
     this.weekFormat = 'Saturday'
   }else if(repeatOnDay === 'SUN'){
     this.weekFormat = 'Sunday'
   }

  }
  validateRoleOnday(repeatOn: any) {
    if(repeatOn === 'FIRST'){
      this.dayFormat = 'First'
    }else if(repeatOn === 'SECOND'){
      this.dayFormat = 'Second'
    }else if(repeatOn === 'THIRD'){
      this.dayFormat = 'Third'
    }else if(repeatOn === 'FOURTH'){
      this.dayFormat = 'Fourth'
    }else if(repeatOn === 'Last'){
      this.dayFormat = 'Last'
    }
  }
  onDateSelected(event:any){
    console.log(event+"<<<<<<<<<<<<");
    if(event){
     // const date1 = new Date(this.enddate);
     const date2 = new Date(this.enddate);
     if(date2 < event){
       this.enddate = this.startdate
     }else{
       this.enddate = this.enddate;
     }
   }

 }
month:string;
year:number;
weekday:string;
ngOnInit(){
  this.selectedOption = this.periodValue;
  console.log(this.startdateonly.getDate());
  this.date=this.startdateonly.getDate();
  this.month=this.Yearly[this.startdateonly.getMonth()];
  this.year=this.startdateonly.getFullYear();
  this.weekday=this.weekdays[this.startdateonly.getDay()];
}


  datafield=[
    'Daily','Weekly','Monthly','Yearly'
  ]
  changeColor= [false, false, false,false,false,false,false];
  days: Week[] = [{ value: 'SUN', viewValue: 'S' },{ value: 'MON', viewValue: 'M' }, { value: 'TUE', viewValue: 'T' },
                  { value: 'WED', viewValue: 'W' }, { value: 'THU', viewValue: 'T' },
                  { value: 'FRI', viewValue: 'F' }, { value: 'SAT', viewValue: 'S' },
                  ];


  monthdays=['First','Second','Third','Fourth','Last']
  weekdays =['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']
  Yearly = ['January','February','March','April','May','June','July','August','September','October','November','December']
 startdateonly:Date;
  validatedays(day : any){
    if(this.dayOfWeek.includes(day.value)){
      const index = this.dayOfWeek.indexOf(day.value);
      this.dayOfWeek.splice(index, 1);
    }else{
      this.dayOfWeek.push(day.value);
    }
    this.selectedDays = this.dayOfWeek.join();
  }

  closeDialog() {
    const repositorySchedule:
    RepositoryScheduleDetailsDto={
      notificationMessage: this.notificationMessage,
      repeatCount: this.repeatCount,
      startdate: this.startdate,
      endDate: this.enddate,
      repeatFormat: this.timePeroid,
      schedulerIdentity: this.identity,
      selectedDays: this.selectedDays,
      selectedDay: this.selectedDay,
      repeatOn: this.repeatOn,
      repeatOnDay: this.repeatOnDay,
      repeatOnMonth: this.repeatOnMonth,
      remainderPeriod: this.remainderPeriod,
      selectedOnMonth: this.selectedOnMonth,
      isActive: this.isActive,
      time: this.time,
      triggeredStatus: this.triggerStatus,
      repositoryName: this.repositoryName
    }
    this.dialogRef.close(repositorySchedule);
  }
  monthdaysDetails(date){
    if(date === 'First'){
      this.repeatOn = 'FIRST';
    }else if (date === 'Second'){
      this.repeatOn = 'SECOND';
    }else if(date === 'Third'){
      this.repeatOn = 'THIRD'
    }else if (date === 'Fourth'){
      this.repeatOn = 'FOURTH'
    } else if (date ==='Fifth'){
      this.repeatOn = 'FIFTH'
    }

  }
  weekdaysDetails(date){
    if(date === 'Monday'){
       this.repeatOnDay = 'MON'
    }else if (date === 'Tuesday'){
      this.repeatOnDay = 'TUE'
    }else if (date === 'Wednesday'){
      this.repeatOnDay = 'WED'
    }else if(date === 'Thursday'){
      this.repeatOnDay = 'THU'
    }else if(date === 'Friday'){
      this.repeatOnDay = 'FRI'
    }else if(date === 'Saturday'){
      this.repeatOnDay = 'SAT'
    }else if(date === 'Sunday'){
      this.repeatOnDay = 'SUN'
    }
  }
  selectedYear(year){
    if(year === 'January'){
      this.selectedOnMonth = 'JAN'
   }else if (year === 'February'){
     this.selectedOnMonth = 'FEB'
   }else if (year === 'March'){
     this.selectedOnMonth = 'MAR'
   }else if(year === 'April'){
     this.selectedOnMonth = 'APR'
   }else if(year === 'May'){
     this.selectedOnMonth = 'MAY'
   }else if(year === 'June'){
     this.selectedOnMonth = 'JUN'
   }else if(year === 'July'){
     this.selectedOnMonth = 'JUL'
   }else if (year === 'August'){
    this.selectedOnMonth = 'AUG'
  }else if(year === 'September'){
    this.selectedOnMonth = 'SEP'
  }else if(year === 'October'){
    this.selectedOnMonth = 'OCT'
  }else if(year === 'November'){
    this.selectedOnMonth = 'NOV'
  }else if(year === 'December'){
    this.selectedOnMonth = 'DEC'
  }



  }

  selectedYears(year){
    if(year === 'January'){
      this.monthlyFormat = 'JAN'
   }else if (year === 'February'){
     this.monthlyFormat = 'FEB'
   }else if (year === 'March'){
     this.monthlyFormat = 'MAR'
   }else if(year === 'April'){
     this.monthlyFormat = 'APR'
   }else if(year === 'May'){
     this.monthlyFormat = 'MAY'
   }else if(year === 'June'){
     this.monthlyFormat = 'JUN'
   }else if(year === 'July'){
     this.monthlyFormat = 'JUL'
   }else if (year === 'August'){
    this.monthlyFormat = 'AUG'
  }else if(year === 'September'){
    this.monthlyFormat = 'SEP'
  }else if(year === 'October'){
    this.monthlyFormat = 'OCT'
  }else if(year === 'November'){
    this.monthlyFormat = 'NOV'
  }else if(year === 'December'){
    this.monthlyFormat = 'DEC'
  }

  this.selectedOnMonth = this.monthlyFormat;
  }

  selectperiods(selectedperiod: string) {
    this.timePeroid = selectedperiod
    this.disable = selectedperiod === 'Yearly' 
  }
  removeValue(value){
    if(value){
    this.toshow = false;
    this.toshows = true;
    }else{
      this.selectedOnMonth = null;
      this.selectedDay = null;
      this.toshows = false;
      this.toshow = true;
    }
  }
  

  saveSchedulerListDetails(){
    const repositorySchedule:
    RepositoryScheduleDetailsDto={
      notificationMessage: this.notificationMessage,
      repeatCount: this.repeatCount,
      startdate: this.startdate,
      endDate: this.enddate,
      repeatFormat: this.timePeroid,
      schedulerIdentity: this.identity,
      selectedDays: this.selectedDays,
      selectedDay: this.selectedDay,
      repeatOn: this.repeatOn,
      repeatOnDay: this.repeatOnDay,
      repeatOnMonth: this.monthlyFormat,
      remainderPeriod: this.remainderPeriod,
      selectedOnMonth: this.selectedOnMonth,
      isActive: this.isActive,
      time: this.time,
      triggeredStatus: this.triggerStatus,
      repositoryName: this.repositoryName
    }
    this.dialogRef.close(repositorySchedule);

  }


 
  // setRadioChecked(option: string) {
  //   this.selectedOption = option;
  // }


}
export class DailogData{
  timeperiod:string;
}

export interface Week{
  viewValue:string;
  value:string;
}
