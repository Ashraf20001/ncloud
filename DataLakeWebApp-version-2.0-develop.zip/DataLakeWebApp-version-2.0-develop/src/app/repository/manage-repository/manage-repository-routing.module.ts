import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ManageRepositoryComponent } from './manage-repository.component';
import { AuthGuard } from 'src/app/service/guard/auth.guard';
import { ApiIntegrationComponent } from './api-integration/api-integration.component';
import { ImplementConfigurationComponent } from './implement-configuration/implement-configuration.component';



const routes: Routes = [
  {
    path:'', component:ManageRepositoryComponent,
    children:[
      {
        path:'manage-repository',
        loadChildren:() =>import('./repository-navigation/repository-navigation.module').then(m=>m.RepositoryNavigationModule),
        canActivate: [AuthGuard]
      },

      {
        path: 'scheduler',
        loadChildren: () => import('./scheduler/scheduler.module').then(m => m.SchedulerModule),
        canActivate: [AuthGuard]
      },
      {
        path: 'api-integration',
        component : ApiIntegrationComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'implement-configuration',
        component : ImplementConfigurationComponent,
        canActivate: [AuthGuard]
      },
      {
        path: '',
        redirectTo: 'manage-repository',
        pathMatch: 'full'
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ManageRepositoryRoutingMoudle { }
