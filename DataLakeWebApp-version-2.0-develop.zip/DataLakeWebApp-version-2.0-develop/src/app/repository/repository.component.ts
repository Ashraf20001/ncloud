import { Component } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-repository',
  templateUrl: './repository.component.html',
  styleUrls: ['./repository.component.scss']
})
export class RepositoryComponent {



  fieldconfigure_Class ="fieldconfigure"
  scheduler_Class ="scheduler";
  main_page="main-page";
  api_integration="api";

  tabs: TabDTO[] = [
    {
      label: 'Manage Repository',
      url: 'card-view',
      labelClass: 'fieldconfigure'
    },
    {
      label: 'Scheduler',
      url: 'scheduler',
      labelClass: 'scheduler'
    },
    {
      label: 'API Integration',
      url: 'api-integration',
      labelClass: 'api'
    }
  ];

  constructor(private router: Router, private route: ActivatedRoute){
    this.router.navigate(['field-configure'], {relativeTo:this.route})
  }

  /**
   * TAB CHANGE EVENT
   * @param event
   */
  tabChange(event: MatTabChangeEvent): void {
    const tab = this.tabs.find((t: TabDTO) => t.label === event.tab.textLabel);
    if(tab) {
      this.router.navigate([tab.url], { relativeTo: this.route });
    }
  }
}


export interface TabDTO {
  label: string;
  url: string;
  labelClass: string;
}


