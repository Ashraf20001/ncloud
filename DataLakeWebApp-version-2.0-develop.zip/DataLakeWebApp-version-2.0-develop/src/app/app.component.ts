import { Component, OnInit, Renderer2 } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'recoveryPortalFrontend';
  selectroute = false;
  Router: any;

  constructor(private router: Router, private activatedRoute: ActivatedRoute,public translate: TranslateService,public renderer: Renderer2) {
    this.router.events.subscribe((event: any) => {
      if (event instanceof NavigationEnd) {
        // console.log('event url - ', event.url);
        this.selectroute = event.url !== '/' && !event.url.includes('login')&&!event.url.includes('/common-reset-password/');
      }
    });

  }
}
