/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-empty-function */
import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { ExpireTime } from 'src/app/common/enum/enum';
import { AuthService } from 'src/app/service/auth.service';
import { appConst } from 'src/app/service/app.const';
import { AppService } from 'src/app/service/role access/service/app.service';
import { PlatformDetailsDto } from 'src/app/models/platform-details-dto';

@Component({
  selector: 'app-authority-login',
  templateUrl: './authority-login.component.html',
  styleUrls: ['./authority-login.component.scss']
})

export class AuthorityLoginComponent {
  responsedata: any;
  platformDetails: PlatformDetailsDto[];
  userRoleStatus : any;
  show:boolean=false;
  field: PlatformDetailsDto;

  constructor(private service:AuthService,public router:Router,public translate: TranslateService ,private tosterservice:ToastrService,private appService:AppService){
    // sessionStorage.clear();
    // localStorage.clear();
    translate.addLangs(['English','Arabic']);
    translate.setDefaultLang('English');
    // document.documentElement.style.setProperty('--wbCol','red');
  }
  title = 'AUTHORITY LOGIN'

  Login = new FormGroup({
    username: new FormControl("", [Validators.required,this.noSpaceAllowed]),
    password: new FormControl("", [Validators.required,this.noSpaceAllowed])
  });

  ngOnInit(): void {
    this.service.getPlatformDetails().subscribe((data)=>{
      this.platformDetails=data;
    })
  }

  imageList=[
    {
      aliasName:"Recover EZ",
      image:"assets/portal1.svg",
      title:"Recovery EZ"
    },
    {
      aliasName:"Digital Paper",
      image:"assets/icons/authority_details.svg",
      title:"Digital Paper"
    }
  ]


  // changeLang(lang: string) {
  //   this.translate.use(lang);
  // }

  noSpaceAllowed(control:FormControl){
    if (control.value!= null && control.value.indexOf(' ')!= -1) {
      return {noSpaceAllowed:true}
    }
    return null;
}
  getUrl(title:string){
      let image=''
      const data = this.imageList.find((element)=> element.aliasName===title);
      image=data?.image;
      return image;
  }
  passPlatformDetails(details:PlatformDetailsDto){
    this.field=details;
    const arr = JSON.stringify(details);
    localStorage.setItem("platformDetails", arr);
  }
loginEna(){
  this.show= false;
}

ProceedLogin() {
  this.show=true;
  if(this.Login.valid){
    this.service.ProceedLogin(this.Login.value.username,this.Login.value.password,true).subscribe((result)=>{
      if (result) {
        this.responsedata = result;
        this.service.loginResponse = result;
        sessionStorage.setItem("platformIdentity","e31c7ccb51d047e7930b5cf5908ae9de");
        sessionStorage.setItem('token',this.responsedata.accessToken);
        localStorage.setItem('identity',this.responsedata.identity);
        sessionStorage.setItem('username',this.responsedata.username);
        sessionStorage.setItem('platFormDetails', this.responsedata.platformDetailsDto.platformId)
        
        this.service.getUserRolePrivillege().subscribe((data: any) => { // To be Removed Later
          console.log(data.content);
          this.userRoleStatus = data.content;
          sessionStorage.setItem('userRoleStatus', this.userRoleStatus);
        })
          if (this.responsedata.userTypeId != null && this.responsedata.userTypeId.userTypeId === 1) {
            sessionStorage.setItem('role', 'TRUE');
          }
          this.service.autoLogout(ExpireTime.expirationTime);
          if (this.responsedata.firstTimeLogin == true) {
            this.router.navigate(['login/reset-password']);
          } else if (this.responsedata.userTypeId.userTypeId === 1) {
            this.router.navigate(['/repository']);
            // this.getMenuRoleData();
          } else {
            this.router.navigate(['']);
            this.tosterservice.error('Invalid User')
          }
        
      
      }
    })
  }


}

getMenuRoleData(){
  this.appService.getMenubyRole().subscribe((response)=>{
    if (response) {
      console.log('');
      let menuName = '';
        if (response['content'] && response['content'].length !== 0) {
          menuName = response['content'][0].menuName
        }
        this.router.navigate([this.getUrlToNavigate(menuName)]);
      //after login it will redirect to given url
      this.tosterservice.success(
        'Login successfull',
        '',
        {
      timeOut:1600},
      );
        // this.tosterservice.success( 'Login successfully');
        setTimeout(() => {
          console.log("")
      }, 500);
    }
  })
}

getUrlToNavigate(menuName:string){
  switch (menuName) {
    case appConst.MENU_CONSTANTS.MENUNAME.DASHBOARD.NAME:
      return appConst.MENU_CONSTANTS.MENUNAME.DASHBOARD.URL;

      case appConst.MENU_CONSTANTS.MENUNAME.PAGECONFIGURATOR.NAME:
      return appConst.MENU_CONSTANTS.MENUNAME.PAGECONFIGURATOR.URL;

      case appConst.MENU_CONSTANTS.MENUNAME.ENTITYMANAGEMENT.NAME:
      return appConst.MENU_CONSTANTS.MENUNAME.ENTITYMANAGEMENT.URL;

      case appConst.MENU_CONSTANTS.MENUNAME.REPORTS.NAME:
      return appConst.MENU_CONSTANTS.MENUNAME.REPORTS.URL;

      case appConst.MENU_CONSTANTS.MENUNAME.USERMANAGEMENT.NAME:
      return appConst.MENU_CONSTANTS.MENUNAME.USERMANAGEMENT.URL;

      default:
      return 'page-not-found'

  }
}



  openForgotPassword(){
    this.router.navigateByUrl('login/forgot-password')
  }

  giveInsurence(){
    // this.router.navigate(['..', 'insurance-company']).then(() => console.log("success"));
    this.router.navigateByUrl('login/insurance-company').then(() => console.log("success"));
  }

  showPassword=false;
  togglePasswordVisibility()
   {
     this.showPassword = !this.showPassword;
   }

}


