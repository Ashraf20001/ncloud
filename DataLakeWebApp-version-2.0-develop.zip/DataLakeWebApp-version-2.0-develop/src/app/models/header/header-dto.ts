import { PlatformDetailsDto } from "../platform-details-dto";
import { Menu } from "./menu";

export interface HeaderDto {
  menuDetails:Menu[];
  platformDetails:PlatformDetailsDto
  companyLogoPath:string;

}
