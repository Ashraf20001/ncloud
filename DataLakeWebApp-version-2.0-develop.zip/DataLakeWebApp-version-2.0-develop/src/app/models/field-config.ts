export class FieldConfig{
  pageId!:any;
	updatedFields:any;
	deletedFields:any;
}