export class BulkUploadHistoryDto{
     successCount: number; 
     failureCount : number;
     totalCount : number;
     status:string;
     repositoryIdentity : string;
}