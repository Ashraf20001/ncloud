import {  MenuDto } from './menu-dto';
export class RoleDto{
  roleId:number;
  menuData:MenuDto[];
}

export class UserDto{
  menuData:MenuDto[];
}