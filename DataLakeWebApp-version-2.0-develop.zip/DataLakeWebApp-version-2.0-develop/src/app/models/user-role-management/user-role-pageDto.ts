import { RoleDto } from './role-dto';
import { FieldGroupDTO } from './../field-group-dto';
export class UserRolePage{
  isActive:boolean;
  roleDetails:FieldGroupDTO;
  accessMapping:RoleDto;
}
