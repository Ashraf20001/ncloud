export class PurchaseHistoryNotificationDTO {
    notificationMsg: string;
    actedBy: number;
    orderId: number;
    createdDate:any;
    imageUrl:string;
    notificationId:number;
    identity:string;
    repositoryIdentity:any;
    isRepoCmts:any;
    status: any;
}
