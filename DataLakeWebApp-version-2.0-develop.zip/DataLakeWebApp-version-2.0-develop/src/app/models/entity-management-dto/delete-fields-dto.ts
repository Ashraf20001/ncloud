export class DeletedFieldDto{
  sectionName : any;
  fieldId : string[];
}