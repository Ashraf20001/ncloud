export class RepositoryConfigurationDto{
    repositoryCost : string
    sharePercentage : string
  }