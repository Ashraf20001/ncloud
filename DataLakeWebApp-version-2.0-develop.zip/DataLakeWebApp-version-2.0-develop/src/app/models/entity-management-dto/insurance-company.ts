import { MetaDataDto } from "../report-loss-dto/meta-data-dto";
export class InsuranceCompanyDto{
        emInsCompanyId: number;
        emInsName: string;
        emInsPhone: string;
        emInsEmail: string;
        emInsPassword: string;
        emInsLocation: string;
        emInsAddress: string;
        emInsMaxPayableAmount: number;
        emMaxTime: number;
        emInsLogo: string;
        emInsShortName: string;
        emInsIsActive:string;
        emInsExceedDate:Date;

}

export interface FileUploadDTO {
        fileList: File[];
        referenceId?: string;
        companyId?:string;
        fieldName: string;
      }
