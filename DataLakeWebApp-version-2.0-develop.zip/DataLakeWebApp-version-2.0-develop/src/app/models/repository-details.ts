export class ManageRepositoryCardDetails
{
  repositoryName:string;
  repositoryStatus:string;
  repositoryVersion:number;
  numberOfFields:number;
  identity:string;
  isActive:boolean;
  uploadAccess:number;
  effectiveTo:any
}
