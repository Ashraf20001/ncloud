export interface NotificationDto {
    template: any;
    notificationContent:string;
    identity:string;
    repositoryIdentity:string;
    createdDate:any;
    logoUrl:string;
    isRepoCmts:boolean;
    isRead:boolean;
    status:string;
    notificationJson:string
}
