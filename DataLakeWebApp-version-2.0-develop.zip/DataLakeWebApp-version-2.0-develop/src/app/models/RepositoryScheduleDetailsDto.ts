
export class RepositoryScheduleDetailsDto{
    notificationMessage:string;
    repeatCount:number;
    startdate:string;
    endDate:string;
    repeatFormat:string;
    schedulerIdentity:string;
    selectedDays:string;
    selectedDay:number;
    repeatOn:string;
    repeatOnDay:string;
    repeatOnMonth:string;
    remainderPeriod:number;
    selectedOnMonth:string;
    isActive:boolean;
    time:string;
    triggeredStatus:string;
    repositoryName:string;
}