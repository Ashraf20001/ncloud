export class RepositoryField{
    icon:string;
    fieldId: string;
    fieldName: string;
    fieldType: string;
    dataType:string;
    posistion:number;
    errorMessage:string;
    isMandatory:boolean;
    listofFieldOptions:any;
    searchType:string;
    // globalSearch:boolean;
    // repositorySearch:boolean;
    minlength:number;
    maxlength:number;
    regex:string;
    tempId:number;
    fieldIdentity:string;
}