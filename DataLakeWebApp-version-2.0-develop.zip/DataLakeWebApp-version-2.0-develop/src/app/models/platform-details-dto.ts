export interface PlatformDetailsDto {
    platformId : number;
    platformName : string;
    platformIdentity:string;
    platformLogoPath : string
}
