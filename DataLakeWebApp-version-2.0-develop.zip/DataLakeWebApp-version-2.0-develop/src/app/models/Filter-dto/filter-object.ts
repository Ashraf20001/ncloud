export class FilterObject {
  columnName:string;
  condition:string;
  aliasName: string;
  type: string;
  value: string[];
  dropdown: any[];
  radio: RadioButtonObject[];
  dropdownCopy?:string[];
  dataType:string;
  max:number
}

export interface Filtervo
{
columnName:string,
condition:string,
filterOrSortingType:string,
intgerValueList:[],
isAscending:false,
type:any,
value:any,
value2:any,
valueList:any
}
export class RadioButtonObject {
  name: string;
  value: boolean;
}
