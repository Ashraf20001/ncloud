export class CustomSortingVo{
    columnName:string;
    isAsc:boolean;
    repositoryPrimaryId:number[];
  }