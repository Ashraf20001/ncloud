import { Component, OnInit, Renderer2 } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { AuthService } from 'ncloud-common-ui';

import { NgxUiLoaderService } from 'ngx-ui-loader';

@Component({
  selector: 'app-language',
  templateUrl: './language.component.html',
  styleUrls: ['./language.component.scss'],
})
export class LanguageComponent {
  title = 'recoveryPortalFrontend';
  selectroute = false;
  Router: any;

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public translate: TranslateService,
    private service: AuthService,
    public renderer: Renderer2
  ) {
    this.router.events.subscribe((event: any) => {
      if (event instanceof NavigationEnd) {
        this.selectroute = event.url !== '/' && !event.url.includes('login');
        if (event.url.includes('common-reset-password')) {
          this.selectroute = false;
        }
      }
    });

    translate.addLangs(['English', 'French']); //'Arabic'

    translate.setDefaultLang('English');

    // const browserLang = 'English';
    const browserLang =
      sessionStorage.getItem('Language') !== null
        ? sessionStorage.getItem('Language')
        : 'English';

    this.lang = browserLang;

    translate.use(
      browserLang.match(/English|French/) ? browserLang : 'English'
    );
  }
  lang: string;

  ngOnInit(): void {
    // this.dashboardrouting();
    this.lang = sessionStorage.getItem('Language');
    if (this.lang) {
      this.changeLang(this.lang);
    } else {
      this.lang = 'English';
    }
  }

  // dashboardrouting() {
  //   this.router.events.subscribe((url: any) =>
  //   (url));
  //   //   if(this.route.snapshot.routeConfig.path==='login'){

  //   //     this.selectroute=false;
  //   // }else if(this.route.snapshot.routeConfig.path==='common-reset-password/:userIdentity/:userName'){
  //   //   this.selectroute=false;
  //   // }
  // }

  changeLang(lang: string) {
    this.renderer.setAttribute(document.body, 'dir', 'ltr');
    if (lang === 'French') {
      this.renderer.addClass(document.body, 'french');
      this.renderer.removeClass(document.body, 'english');
      sessionStorage.setItem('Language', lang);
      this.lang = 'French';
    } else if (lang === 'English') {
      this.renderer.addClass(document.body, 'english');
      this.renderer.removeClass(document.body, 'french');
      sessionStorage.setItem('Language', lang);
      this.lang = 'English';
    }

    //  }

    setTimeout(() => {
      this.translate.use(lang);
    }, 1000);


  }
  openclose = false;
  opendrown() {
    this.openclose = !this.openclose;
  }
  clsoedropdown() {
    this.openclose = false;
  }
  closePopUp() {
    this.openclose = false;
  }
}
