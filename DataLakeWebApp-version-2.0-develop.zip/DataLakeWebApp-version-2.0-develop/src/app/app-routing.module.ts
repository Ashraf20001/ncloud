import { LoginModule } from './login/login.module';
/* eslint-disable @typescript-eslint/no-unused-vars */
import { CommonResetPasswordComponent } from './common/components/common-reset-password/common-reset-password.component';
import { AuthGuard } from './service/guard/auth.guard';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PagenotfoundComponent } from './common/components/pagenotfound/pagenotfound.component';
import { RouteDashboard } from './service/routeDashboard.service';



const routes: Routes = [
  {
    path: 'login',
    canActivate: [RouteDashboard],
    loadChildren: () =>
      import('ncloud-common-ui').then((m) => m.LoginModule),
  },
  {
    path: 'entitymanagement',
    loadChildren: () =>
      import('ncloud-common-ui').then((m) => m.EntityManagementModule),
      canActivate: [AuthGuard]
  },
  {
    path: 'common-reset-password/:userIdentity/:userName',
    component: CommonResetPasswordComponent,
  },
  {
    path: 'repository',
    loadChildren: () => import('./repository/repository.module').then((m) => m.RepositoryModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'upload',
    loadChildren: () => import('./repository/bulk-upload/bulk-upload-module').then((m) => m.BulkUploadModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'search',
    loadChildren: () => import('./repository/global-search/global-search.module').then((m) => m.GlobalSearchModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'usermanagement',
    loadChildren: () => import('ncloud-common-ui').then((m) => m.UserManagementModule),
    canActivate: [AuthGuard]
  },
  { path: 'export-import', 
    loadChildren: () => import('ncloud-common-ui').then(m => m.ExportImportModule) },
  {
    path: 'profile',
    loadChildren: () =>
      import('ncloud-common-ui').then((m) => m.ProfileModule),
      canActivate: [AuthGuard]
  },
  { path: '', redirectTo: 'login/insurance-company', pathMatch: 'full' },
  // Route for 404 request
  { path: '**', component: PagenotfoundComponent, },

];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      useHash: true,
      onSameUrlNavigation: 'reload'
    }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
