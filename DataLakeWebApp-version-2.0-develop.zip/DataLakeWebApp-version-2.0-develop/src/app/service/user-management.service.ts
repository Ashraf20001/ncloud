import { MenuDto } from './../models/user-role-management/menu-dto';
import { userPageDto } from './../models/user-role-management/user_pageDto';
/* eslint-disable prefer-const */
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { UserRolePage } from './../models/user-role-management/user-role-pageDto';
import { UserRoleDto } from './../models/user-role-management/userRoleDto';
import { MetaDataDto } from 'src/app/models/report-loss-dto/meta-data-dto';
import { RoleDto, UserDto } from './../models/user-role-management/role-dto';
/* eslint-disable @typescript-eslint/no-empty-function */
import { FieldGroupDTO } from './../models/field-group-dto';
import { Field } from './../models/report-loss-dto/field';
import { FieldDTO } from './../models/field-dto';
import { FieldValueDTO } from './../models/field-value-dto';
import { Section } from './../models/report-loss-dto/section';
import { BehaviorSubject, of } from 'rxjs';
import { Injectable } from '@angular/core';
import { appConst } from './app.const';
import { FilterOrSortingVo } from '../models/Filter-dto/filter-object-backend';

@Injectable({
  providedIn: 'root'
})
export class UserManagementService {

  private baseUrl = environment.API_BASE_URL;

  constructor(private http: HttpClient) { }


  private ClickAddnew = new BehaviorSubject<boolean>(false);

  public ClickAdd$ = this.ClickAddnew.asObservable();


  getAccessMappingDetails(pageid:string,userRoleId:string){
    if (userRoleId!==null) {
      return this.http.get<any>(this.baseUrl + "/api/get-role-page-info?page_id="+ pageid + "&role_id="+ userRoleId )
    }else{
      return this.http.get<any>(this.baseUrl + "/api/get-role-page-info?page_id="+ pageid )

    }
  }
  getFieldMetaData(pageId:string) {
    return this.http.get<any>(this.baseUrl + "/api/paper-details/get-metadata?pageId="+pageId);
  }

  saveFieldMetaData(data:MetaDataDto) {

    const fieldGroupDTO: FieldGroupDTO = this.convertToFieldGroup(data.sectionList,UserManagementService.DIGITAL_PAPER_DTO);


    return this.http.post(this.baseUrl+"/digital-paper/save",fieldGroupDTO);
  }

  sendUserRoleData(data:MetaDataDto,accessMap:RoleDto,isActive:boolean){
    const fieldGroupDTO: FieldGroupDTO = this.convertToFieldGroup(data.sectionList,UserManagementService.USER_MANAGEMENT_ROLE__GROUP_NAME);
    const sendUserRoleDetails = new UserRolePage();
    sendUserRoleDetails.roleDetails = fieldGroupDTO;
    sendUserRoleDetails.accessMapping = accessMap;
    sendUserRoleDetails.isActive = isActive;
    // http://localhost:9090/api/user-role/saveOrUpdate?role_id=22
    console.log(sendUserRoleDetails);
    return this.http.post(this.baseUrl + "/api/user-role/saveOrUpdate",sendUserRoleDetails)
  }

  sendUserData(data:MetaDataDto,notification:MenuDto[],isActive:boolean){
    const fieldGroupDTO: FieldGroupDTO = this.convertToFieldGroup(data.sectionList,UserManagementService.USER_MANAGEMENT_GROUP_NAME);
    const sendUserDetails = new userPageDto();
    const userDto = new UserDto()
    userDto.menuData = notification;
    sendUserDetails.isActive = isActive;
    sendUserDetails.userDetails = fieldGroupDTO;
    sendUserDetails.enableNotification = userDto;
    return this.http.post(this.baseUrl + "/api/user-management/saveOrUpdate" + "?platform_id=" + "e31c7ccb51d047e7930b5cf5908ae9de",sendUserDetails)
    // console.log(sendUserDetails);


    // return null;
  }

  private static USER_MANAGEMENT_ROLE__GROUP_NAME = 'UserRoleManagementDto';
  private static DIGITAL_PAPER_DTO = 'DigitalPaperDto';
  private static USER_MANAGEMENT_GROUP_NAME = 'UserManagementDto';
  public convertToFieldGroup(sectionList: Section[],groupName:string): FieldGroupDTO {
    const fieldGroupDTO: FieldGroupDTO = {
      groupName: groupName,
      fieldValues: [],
      fieldGroups: []
    };

    sectionList.forEach((section: Section) => {
      this.getFieldGroupDTO(section, fieldGroupDTO);
    });
    return fieldGroupDTO;
  }

  private getFieldGroupDTO(section: Section, parentFieldGroup: FieldGroupDTO): FieldGroupDTO {
    if(section !== undefined && section !== null) {
      const fieldGroup: FieldGroupDTO = {
        groupName: section.sectionName,
        fieldValues: [],
        fieldGroups: []
      };
      if(section.fieldList && section.fieldList.length > 0) {
        section.fieldList.forEach((field: Field) => {
          const fieldDTO: FieldDTO = {
            fieldId: field.fieldId,
            aliasName:field.aliasName,
            fieldName: field.fieldName,
            fieldType: field.fieldType,
            fieldDefault: field.defaultValues,
            minlength:field.minLength,
            maxlength:field.maxLength,
            regex:field.regex

          };
          const fieldValueDTO: FieldValueDTO = {
            field: fieldDTO,
            value: field.value
          };
          fieldGroup.fieldValues.push(fieldValueDTO);
        });
      }
      console.log('parent - ', parentFieldGroup, 'child - ', fieldGroup);
      if(section.sectionList && section.sectionList.length > 0) {
        section.sectionList.forEach((subSection: Section) => {
          this.getFieldGroupDTO(subSection, fieldGroup);
        });
      }
      parentFieldGroup.fieldGroups.push(fieldGroup);
    }
    return parentFieldGroup;
  }

  getCardDetails(min:number,max:number){
    return this.http.get<CardDetails>(this.baseUrl + "/api/get-role-card"+'?min=' + min+'&max='+max);
  }

  getTotalCountForUserRole(){
    return this.http.get<CardDetails>(this.baseUrl + "/api/get-role-list-count");
  }

   getUserDetails(pageId:string,userId:any){

    if (userId !== 'null' && userId !== null) {
      return this.http.get<any>(this.baseUrl + "/api/get-user-management-page-info?page_id="+ pageId +"&user_id=" + userId)
    }else{
      return this.http.get<any>(this.baseUrl + "/api/get-user-management-page-info?page_id="+ pageId)

    }
  }

  getUserManagementTableList(min:number,max:number){

    return this.http.get<any>(this.baseUrl + "/api/get-user-management-list"+'?min=' + min+'&max='+max)
  }

  getUserManagementTableCount(){

    return this.http.get<any>(this.baseUrl + "/api/get-user-management-count")
  }

  deleteUserDetails(id:number){
    return this.http.post(this.baseUrl + "/api/user-management/deleteUser?user_id="+id,{})
  }

  deleteUserRoleDetails(id:number){
    return this.http.post(this.baseUrl + "/api/user-role/deleteRole?role_id="+id,{})
  }


  getPageBasedOnRoles(list:number[]){
    const listOfRole = new ListOfRoles();
    listOfRole.listOfRoles = list;
    return this.http.post<any>(this.baseUrl + "/api/user-management/showPages"  ,listOfRole)
  }


  downloadUserExcelList(){
   return this.http.get(this.baseUrl + "/api/user-management/download-excel" , {responseType: 'blob'})
  }


  downloadRoleExcelList(){
    return this.http.get(this.baseUrl + "/api/user-role/download-excel" , {responseType: 'blob'})
   }

   setAddNew(value:boolean){
      return this.ClickAddnew.next(value);
  }

  getDropdownData(){
    const filter:FilterOrSortingVo[] = [];
    return this.http.post<AllocationUserTypeDto[]>(this.baseUrl + "/api/user-role/get-user-type",filter)
  }

  getOneStockPoolCount(identity:string){
    return this.http.post(this.baseUrl + "/digital-paper/allocation-pool/get-stock-pool?id=" + identity,{})
  }

  getAllStockPool(filterObject:FilterOrSortingVo[],identity:string,min:number, max:number){
    if (identity!== null) {
      return this.http.post(this.baseUrl + "/digital-paper/allocation-pool/get-all-stockpool?id=" + identity + "&min=" + min + "&max="+ max,filterObject)
    }else{
      return this.http.post(this.baseUrl + "/digital-paper/allocation-pool/get-all-stockpool?min=" + min + "&max="+ max,filterObject)
    }
  }

  getStatusChange(identity:string, status:boolean){
    return this.http.post(this.baseUrl + "/digital-paper/allocation-pool/change-stockpool-status?status=" + status +"&id="+ identity,{})
  }

  getTotalCountForUserType() {
    return this.http.get<any>(this.baseUrl + "/digital-paper/allocation-pool/get-stockpool-count")
  }

  getAllocationType() {
    return this.http.get<any>(this.baseUrl + "/digital-paper/allocation-pool/get-allocation-type");
  }

}

export class CardDetails{
  roleId:number;
  roleName:string;
  description:string;
  userCount:number;
  isActive:boolean;
  inActiveDate:string;
  isMapped:boolean;
  roleIdentity:string;
}

export class ListOfRoles{
  listOfRoles:number[];
}

export class AllocationUserTypeDto{
  userTypeName:string;
  identity:string;
}
