
export class ConstantService{
  public static readonly unknownError = 'Unknown error occured'
  public static readonly dashboard = 'Dashboard'
  public static readonly  reportList='/get-report-for-list'
  public static readonly data_lake = '/data-lake';
  public static readonly download_file = '/api/downloadFile';

  }

