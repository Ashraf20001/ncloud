import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GlobalSearchService {

  /**
   * @param httpParams 
   * @returns 
   */
  getTableHeaders(httpParams: HttpParams) {
    return this.http.get<any>(this.baseUrl+'/data-lake/search/table-header', { params: httpParams });
  }
  
  repositorySearch(httpParams : HttpParams, repository : string, filterVo : any) {
    return this.http.post<any>(this.baseUrl+'/data-lake/search/'+ repository +'/repository-search', filterVo, { params: httpParams });
  }

  private baseUrl = environment.API_BASE_URL;

  constructor(private http:HttpClient) { }
}
