/* eslint-disable @typescript-eslint/no-empty-function */
import { ResetPasswordRequest } from './../models/reset-password-request';
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable no-var */
/* eslint-disable prefer-const */
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from './../../environments/environment';
import { ActivatedRoute, Router } from '@angular/router';
import { PlatformDetailsDto } from '../models/platform-details-dto';
import { LoginDto } from '../models/login-dto';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  loginResponse: any;

  constructor(private http: HttpClient, private router: Router) { }

  apiurl = environment.API_BASE_URL + '/auth-service/auth/signin'; // authentication url from backend
  // apiurl = 'http://10.10.12.43:8500/api/auth/signin'
  // const BASE_API_URL =  + this.apiurl

  resetFirstTimeUrl = environment.API_BASE_URL + '/auth-service/auth/resetpassword';

  sendMailIdToResetPasswordUrl =
    environment.API_BASE_URL + '/auth-service/auth/forgetPassword';

  // sendMailIdToResetPasswordUrl =
  //   environment.API_BASE_URL + '/api/auth/forgetPassword';

  commonResetPasswordUrl =
    environment.API_BASE_URL + '/auth-service/auth/updatepassword';

  platformUrl = environment.API_BASE_URL + '/api';

  datalakeUrl = environment.API_BASE_URL + '/data-lake/repository'


  // connecting backend and verifing user credentials
  ProceedLogin(username: string, password: string, isAuthority: boolean) {
    // const platformDetails= JSON.parse(localStorage.getItem("platformDetails"));
    const platformDetails = {
      platformId: 3,
      platformName: 'Data Lake',
      platformIdentity: 'e31c7ccb51d047e7930b5cf5908ae9de',
      platformLogoPath : '/assets/headericon/platformicon/platform_logo.svg'
    };
    let userType;
    if (isAuthority === true) {
      userType = {
        userTypeId: 1,
        userTypeName: 'ASSOCIATION'
      }
    } else {
      userType = {
        userTypeId: 2,
        userTypeName: 'INSURANCE_COMPANY'
      }
    }

    const loginDto: LoginDto = {
      username: username,
      password: password,
      platformDetailsDto: platformDetails,
      userTypeDto: userType
    };
    return this.http.post(this.apiurl, loginDto);
  }

  //checking user is still loggedin or not
  IsLoggedIn() {
    let myCurrentToken = sessionStorage.getItem('token') != null;
    return myCurrentToken;
  }

  //checking jwt oken is still in session storage
  GetToken() {
    return sessionStorage.getItem('token');
  }

  //getting role details from payload of jwt token
  HaveAccess() {
    var logintoken = sessionStorage.getItem('token') || '';
    var _extractedtoken = logintoken.split('.')[1];
    var _atobdata = atob(_extractedtoken);
    var _finaldata = JSON.parse(_atobdata);
    if (_finaldata.role == 'admin') {
      return true;
    } else {
      alert('you not having access');
      return false;
    }
  }

  logout() {
    this.router.navigate(['']);
    sessionStorage.clear();
  }

  autoLogout(expirationTime: number) {
    setTimeout(() => {
      this.logout();
    }, expirationTime);
  }

  resetFirstTimePassword(request: ResetPasswordRequest) {
    return this.http.put(this.resetFirstTimeUrl, request);
  }

  commonResetPassword(request: ResetPasswordRequest) {
    return this.http.put(this.commonResetPasswordUrl, request);
  }

  sendMailToResetPassword(emailId: string) {
    return this.http.post(
      this.sendMailIdToResetPasswordUrl + '?emailId=' + emailId,
      {}
    );
  }

  // Buffer.from("hello",'id').toString('binary')

  // console.log(Buffer.from("Hello World").toString('base64'));
  // SGVsbG8gV29ybGQ=
  // console.log(Buffer.from("SGVsbG8gV29ybGQ=", 'base64').toString('binary'))
  // Hello World

  getPlatformDetails() {
    return this.http.get<PlatformDetailsDto[]>(
      this.platformUrl + '/getPlatformDetails'
    );
  }
  getUserRolePrivillege(){
    return this.http.get(this.datalakeUrl + '/check-authority-type');
  }
  isAuthenticated(){
    const logintoken = sessionStorage.getItem('token')
    return logintoken?true:false;
  }
}

export class UserTypeDto {
  userTypeId: number;
  userTypeName: string;
}
