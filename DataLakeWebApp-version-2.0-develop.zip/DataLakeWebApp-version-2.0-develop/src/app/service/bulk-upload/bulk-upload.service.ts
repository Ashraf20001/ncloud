import { Injectable } from "@angular/core";
import { ConstantService } from "../constants.service";
import { environment } from "src/environments/environment";
import { HttpClient, HttpParams } from "@angular/common/http";
import { BulkUploadHistoryDto } from "src/app/models/user-role-management/BulkUploadHistoryDto";

@Injectable({
    providedIn: 'root'
  })
  export class BulkUploadService{
  

    baseURL =  environment.API_BASE_URL+ ConstantService.data_lake;

    constructor(private http: HttpClient){
    }

    /**
     * 
     * @param param 
     * @returns 
     */
    downloadSampleXlsxFile(param:any){
        return this.http.get(this.baseURL +'/bulk-upload/download-sample-file',{params : param, responseType: 'blob'});
    }

    /**
     * 
     * @param file 
     * @param param 
     * @returns 
     */
    bulkUploadFile(file:FormData, param:any){
      return this.http.post(this.baseURL+'/bulk-upload/upload-file',file,{params:param});
    }

   /**
    * 
    * @param customSortingVo 
    * @param params 
    * @returns 
    */
    getBulkUploadCount(customSortingVo, params){
      return this.http.post(this.baseURL+'/bulk-upload/success-error-records/count',customSortingVo, { params: params});
    }

    /**
     * 
     * @param customSortingVo 
     * @param params 
     * @returns 
     */
    getBulkUploadList(customSortingVo,params){
      return this.http.post(this.baseURL+'/bulk-upload/success-error-records/list',customSortingVo, { params: params});
    }

    /**
     * 
     * @param params 
     * @returns 
     */
    getBulkUploadDetails(params) {
      return this.http.get(this.baseURL+'/bulk-upload/upload-history', {params:params});
    }

    getBulkUploadCountsDetails(bulkUploadIdentity : String){
      return this.http.get<BulkUploadHistoryDto[]>(this.baseURL +'/bulk-upload/total-records-count?bulkUploadIdentity='+ bulkUploadIdentity);
    }

    excelDownload(param:any){
      return this.http.get(this.baseURL+"/bulk-upload/success-error-records/download",{params:param, responseType: 'blob' });
    }
  

  }