import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of } from "rxjs";
import { ManageRepositoryCardDetails } from "src/app/models/repository-details";
import { RepositoryScheduleDetailsDto } from "src/app/models/RepositoryScheduleDetailsDto";



@Injectable({
  providedIn: 'root'
})
export class HeaderService {

  post(id: any, element: any) {
    throw new Error('Method not implemented.');
  }

  private baseUrl = environment.API_BASE_URL;
  constructor(private http:HttpClient) {
  }

IsLoggedIn(){
  let myCurrentToken = sessionStorage.getItem('token')!= null
  return myCurrentToken;
}


  /**
   *
   * @returns HeaderDto
   */
  getMenuDetails() {
    return this.http.get(this.baseUrl+'/api/app-header/platform-menu-details');
  }

   /**
   * @param min
   * @param maximum
   * @param filterVos
   * @returns ManageRepositoryCardDetails
   */
  getRepositoryDetails(min, maximum, filterVos,userRoleStatus,event){
    const params = new HttpParams()
    .set('min', min)
    .set('max', maximum)
    .set('userRoleStatus',userRoleStatus)
    .set('search',event)
    return this.http.post<ManageRepositoryCardDetails[]>(this.baseUrl+'/data-lake/repository/repository-list',filterVos, { params: params });
  }
  getRepositoryDetailsapproved(filterVos : any, params : any){
    return this.http.post<ManageRepositoryCardDetails[]>(this.baseUrl+'/data-lake/repository/repository-approved-list',filterVos, { params: params });
  }
  public getRepositoryDetailsbyIdentity(identity: any): Observable<any> {
    const params = new HttpParams()
    .set('repositoryIdentity',identity)
    if (identity!== null) {
      return this.http.get<any>(this.baseUrl + '/data-lake/repository/repository-details/', {params: params});
    }
  }

  getAllRepositoryDetails(min, maximum, myArray){
  const params = new HttpParams()
  .set('min', min)
  .set('max', maximum);
  return this.http.post<ManageRepositoryCardDetails[]>(this.baseUrl+'/data-lake/repository/repository-list', myArray, { params: params});
  }

  /**
   * @param filterVos
   * @returns Count of repository
   */
  getListOfCount( filterVos,search,userRoleStatus){
    const params = new HttpParams()
    .set('search',search)
    .set('userRoleStatus',userRoleStatus)
    return this.http.post(this.baseUrl+'/data-lake/repository/repository-count',filterVos,{ params: params});
  }

  getApprovedListOfCount( filterVos,search){
    const params = new HttpParams()
    .set('search',search)
    .set('isApproved', false)
    return this.http.post(this.baseUrl+'/data-lake/repository/repository-approved-count',filterVos,{ params: params});
  }

  updateSchedulerList(repositorySchedule) {
    return this.http.post(this.baseUrl+'/data-lake/repository/update-scheduler',repositorySchedule)
  }
  
  /**
   * @param fieldRepositoryDto
   * @returns
   */
  renameRepository(fieldRepositoryDto){
    return this.http.put(this.baseUrl+'/data-lake/repository/update-repositoryname',fieldRepositoryDto);
  }
  
  /**
   * @param schedulerIdentity 
   * @returns 
   */
  updateSchedulerDelete(schedulerIdentity){
    return this.http.put(this.baseUrl+'/data-lake/repository/scheduler-delete?schedulerIdentity='+schedulerIdentity, {});
  }

 
  getUserRolePrivillege(){
    return this.http.get(this.baseUrl + '/data-lake/repository/get-role');
  }

  
  /**
   * @param schedulerIdentity 
   * @returns RepositoryScheduleDetailsDto
   */
  getSchedulerDetails(schedulerIdentity : any) {
    return this.http.get<RepositoryScheduleDetailsDto[]>(this.baseUrl + '/data-lake/repository/get-scheduler-details?schedulerIdentity='+schedulerIdentity);
  }

  /**
   * @param params
   * @returns
   */
  disableRepository(params : any){
    return this.http.put(this.baseUrl+'/data-lake/repository/disable-repository',params);
  }

  /**
   * @param repositoryConfigurationDto
   * @returns
   */
  superAdminDetails(repositoryConfigurationDto){
    return this.http.post(this.baseUrl+'/api/super-admin',repositoryConfigurationDto);
  }

  /**
   * @param 
   * @returns
   */
  getSuperAdminDetails(){
    return this.http.get(this.baseUrl+'/api/get-super-admin-details');
  }



 


}
