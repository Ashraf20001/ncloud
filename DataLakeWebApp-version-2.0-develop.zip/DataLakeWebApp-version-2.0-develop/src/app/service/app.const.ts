export const appConst = {

  PAGE_NAME: {
    DASHBOARD:
    {
      RECEIVABLE_DASHBOARD: {
        PAGENAME: 'dashboard',
        PAGEID: 2,
        PAGE_IDENTITY: 'rcvybunimokvybuv',
        BUTTON_ACCESS : {
          QUICKLINKS: 'Quick Links'
        }
      },
      PAYABLE_DASHBOARD: {
        PAGENAME: 'dashboard',
        PAGEID: 29,
        PAGE_IDENTITY: '0189b4a60b634f9da710f8a9904264a4',
        BUTTON_ACCESS: {
          QUICKLINKS: 'Quick Links'
        }
      }
    },
    RECEIVABLE: {
      RECEIVABLE_CARD:
      {
        PAGENAME: 'receivablecard',
        PAGEID: 3,
        PAGE_IDENTITY: 'mntbrvefjynthbgvfcd',
        BUTTON_ACCESS : {
          VIEWRECEIVABLE: 'View Receivable',
          REPORTALOSS:'Report Loss',
          DOWNLOAD: 'Download Receivable'
        }
      },
      RECEIVABLE_LIST:
      {
        PAGENAME: 'receivablelist',
        PAGEID: 7,
        PAGE_IDENTITY: 'ef1bcae549bf45de9d1e315aab6e83d8'
      },
      RECEIVABLE_REPORTLOSS:
      {
        PAGENAME: 'reportloss',
        PAGEID: 1,
        PAGE_IDENTITY: 'sdjashbsdadajdkui',
        BUTTON_ACCESS : {
          ACCEPT: 'Accepted',
          REJECT:'Rejected',
          NEED_MORE_DETAILS: 'Need More Details',
          SAVE: 'Save',
          ASSIGN_SURVEYOR: 'Assign Surveyor',
          DISPUTE: 'Dispute',
          DETAILS_PROVIDED: 'Details Provided',
          REOPEN: 'Reopen',
          APPROVED: 'Approve',
          RESUBMIT: 'Resubmit',
          DISPUTE_REOPEN: 'Dispute Reopen',
          REPORT_LOSS_COMMON_SAVE: 'Report Loss Save'
        }
      }
    },
    PAYABLE: {
      PAYABLE_CARD:
      {
        PAGENAME: 'payablecard',
        PAGEID: 4,
        PAGE_IDENTITY: 'cvbntfyntbrvecd',
        BUTTON_ACCESS : {
          VIEWPAYABLE: 'View Payable',
          DOWNLOAD: 'Download Payable'
        }
      },
      PAYABLE_LIST:
      {
        PAGENAME: 'payablelist',
        PAGEID: 8,
        PAGE_IDENTITY: '1ccec1083cdd4bdc94103c41e2c19741'
      }
    },
    REPORTS: {
      REPORTS_CARD:
      {
        PAGENAME: 'reportscard',
        PAGEID: 5,
        PAGE_IDENTITY: 'rvynrtvybunicvn',
        BUTTON_ACCESS : {
          GENERATE_REPORT: 'Generate Report',
          DOWNLOAD: 'Report Download',
          EDIT: 'Report Edit',
        }
      },
      REPORTS_GENERATE:
      {
        PAGENAME: 'reportsgenerate',
        PAGEID: 9,
        PAGE_IDENTITY: '4c306b3a92224b79b0cd9eab82fd13a8',
        BUTTON_ACCESS : {
          GENERATE_REPORT: 'Generate Report',
          PREVIEW_REPORT: 'Preview Report'
        }
      },
    },
    USERMANAGEMENT: {
      USERMANAGEMENT_USERROLE : {
        USERMANAGEMENT_USERROLE_CARD:
        {
          PAGENAME: 'usermanagementuserrolecard',
          PAGEID: 6,
          PAGE_IDENTITY: 'xcvybunijoksxdctvyu',
          BUTTON_ACCESS : {
            ADDNEW: 'Add User Role',
            EDIT: 'Edit User Role',
            DELETE: 'Delete User Role',
            CLONE: 'Clone User Role'
          }
        },
        USERMANAGEMENT_USERROLE_LIST:
        {
          PAGENAME: 'usermanagementuserrolelist',
          PAGEID: 10,
          PAGE_IDENTITY: '5a843f1272854675a4f9d42e7cde82b1'
        },
        USERMANAGEMENT_USERROLE_ADD:
        {
          PAGENAME: 'usermanagementuserroleaddedit',
          PAGEID: 11,
          PAGE_IDENTITY: '9f3caaba-3812-11ee-9620-00ffe4d07894',
          PLATFORM_ID:'a129f254-3539-11ee-b22e-f6efad2fa5e2',
          BUTTON_ACCESS : {
            SAVE:'Save User Role',
          }
        },
      },
      
      USERMANAGEMENT_USER : {
        USERMANAGEMENT_USER_CARD:
        {
          PAGENAME: 'usermanagementusercard',
          PAGEID: 12,
          PAGE_IDENTITY: '7dec9f37fc944f6193fa24f8d0a02483',
          BUTTON_ACCESS : {
            ADDNEW: 'Add New User',
            EDIT: 'Edit User',
            DELETE: 'Delete User',
            CLONE: 'Clone User'
          }
        },
        USERMANAGEMENT_USER_LIST:
        {
          PAGENAME: 'usermanagementuserlist',
          PAGEID: 13,
          PAGE_IDENTITY: 'adfcecc47f3848d49be20c243c32a418',
          BUTTON_ACCESS : {
            ADDNEW: 'Add New User',
            EDIT: 'Edit User',
            DELETE: 'Delete User',
            CLONE: 'Clone User'
          }
        },
        USERMANAGEMENT_USER_ADD:
        {
          PAGENAME: 'usermanagementuseraddedit',
          PAGEID: 14,
          PAGE_IDENTITY: '8b891619527447b38b2090890cf14cc8',
          BUTTON_ACCESS : {
            SAVE:'Save User',
          }
        },
      },
      USERMANAGEMENT_APPROVALLIMIT : {
        USERMANAGEMENT_APPROVALLIMIT_CARD:
        {
          PAGENAME: 'usermanagementapprovallimitcard',
          PAGEID: 15,
          PAGE_IDENTITY: '5dd111e036214c65b31da2e2150adad5',
          BUTTON_ACCESS : {
            ADDNEW: 'Add New Approval Limit',
            EDIT: 'Edit Approval Limit',
            DELETE: 'Delete Approval Limit',
            CLONE: 'Clone Approval Limit'
          }
        },
        USERMANAGEMENT_APPROVALLIMIT_LIST:
        {
          PAGENAME: 'usermanagementapprovallimitlist',
          PAGEID: 16,
          PAGE_IDENTITY: 'f2cd3a53cf5e42f080eb52fd4865f726',
          BUTTON_ACCESS : {
            ADDNEW: 'Add New Approval Limit',
            EDIT: 'Edit Approval Limit',
            DELETE: 'Delete Approval Limit',
            CLONE: 'Clone Approval Limit'
          }
        },
        USERMANAGEMENT_APPROVALLIMIT_ADD:
        {
          PAGENAME: 'usermanagementapprovallimitaddedit',
          PAGEID: 17,
          PAGE_IDENTITY: 'f921882c0b214238a87ffb34b4540e1f',
          BUTTON_ACCESS : {
            SAVE:'Save Approval Limit',
          }
        },
      }
    },
    PAGECONFIGURATOR:
    {
      PAGE_CONFIGURATOR_CARD:
      {
        PAGENAME: 'pageconfiguratorcard',
        PAGEID: 18,
        PAGE_IDENTITY: '9613e9d92f94483fbf3e3eac6462297b',
        BUTTON_ACCESS : {
          LAUNCHINPORTAL: 'Launch in Portal',
        }
      },
      FIELD_CONFIGURATOR:
      {
        PAGENAME: 'fieldconfigurator',
        PAGEID: 19,
        PAGE_IDENTITY: 'f1a5a9b8b5a742e09dadcc1cca6a5a03',
        BUTTON_ACCESS : {
          SAVE:'Save',
        }
      },
      SCHEDULER:
      {
        SCHEDULER_CARD:
        {
          PAGENAME: 'schedularcard',
          PAGEID: 20,
          PAGE_IDENTITY: 'c741ae6b5c3a49b888d2592a51c6b580',
          BUTTON_ACCESS : {
            EDIT: 'Edit',
            DELETE: 'Delete'
          }
        },
        SCHEDULER_LIST:
        {
          PAGENAME: 'schedulerlist',
          PAGEID: 23,
          PAGE_IDENTITY: '4248cdbc93874202ba335b9d7dafeee7'
        },
        SCHEDULER_ADD:
        {
          PAGENAME: 'scheduleraddedit',
          PAGEID: 24,
          PAGE_IDENTITY: '04ed8fab9bd345ff9d9ffaa7915cd086',
          BUTTON_ACCESS : {
            SAVE:'Save',
          }
        }
      }
    },
    REPOSITORY: {
      REPOSITORY_CARD: {
        PAGE_NAME: 'Repository card',
        PAGE_ID: 53,
        PAGE_IDENTITY: '798d09b3-5244-11ee-ac9d-0200a434d2f9',
        BUTTON_ACCESS: {
          ADD: 'Create New Repository',
          EDIT: 'Edit Repository',
          CLONE: 'Clone Repository',
          VIEW: 'View Repository',
          DISABLE: 'Disable Repository'
        }
      },
      REPOSITORY_GRID: {
        PAGE_NAME: 'Repository Grid',
        PAGE_ID: 44,
        PAGE_IDENTITY: '79454424-5233-11ee-ac9d-0200a434d2f9',
        BUTTON_ACCESS: {
          ADD: 'Create New Repository',
          EDIT: 'Edit Repository',
          CLONE: 'Clone Repository',
          VIEW: 'View Repository',
          DISABLE: 'Disable Repository'
        }
      },
      CREATE_NEW_REPOSITORY: {
        PAGE_NAME: 'Create New Repository',
        PAGE_ID: 43,
        PAGE_IDENTITY: '793c6236-5233-11ee-ac9d-0200a434d2f9',
        BUTTON_ACCESS: {
          SAVE: 'Save Repository',
          DRAFT: 'Draft Repository',
          SUBMIT: 'Submit Repository',
          APPROVE: 'Approve Repository',
          REJECT: 'Reject Repository',
          MODIFY: 'Request To Modify'
        }
      }
    },
    SCHEDULER:{
      SCHEDULER_LIST:{
        PAGE_NAME:'Scheduler',
        PAGE_ID:45,
        PAGE_IDENTITY:'794e374f-5233-11ee-ac9d-0200a434d2f9',
        BUTTON_ACCESS:{
          EDIT_ACCESS:'Edit Scheduler',
          DELETE_ACCESS:'Delete Scheduler'
        }
      }
    },
    API_INTEGRATION:{
      API:{
        PAGE_NAME:'Api Integration',
        PAGE_ID:46,
        PAGE_IDENTITY:'79560b12-5233-11ee-ac9d-0200a434d2f9'
      }
    },
    BULKUPLOAD:{
      BULK_UPLOAD:{
        PAGE_NAME:'Bulk Upload',
        PAGE_ID:48,
        PAGE_IDENTITY:'79691831-5233-11ee-ac9d-0200a434d2f9',
        BUTTON_ACCESS:{
          UPLOAD_ACCESS:'Upload',
          DOWNLOAD_ACCESS:'Download Error Records',
          UPLOAD_HISTORY:'View Upload History',
          VIEW: "View"
        }
      }
    },
    SEARCH:{
      REPOSITORY_SEARCH:{
        SEARCH:{
          PAGE_NAME:'Search',
          PAGE_ID:47,
          PAGE_IDENTITY:'795e7b4d-5233-11ee-ac9d-0200a434d2f9',
          BUTTON_ACCESS:{
            SEARCH:'Search',
            SHARE_DETAILS:'Share Records'
          }
        }
      }
    },
    ENTITYMANAGEMENT:
    {
      INSURANCECOMPANY:
        {
        INSURANCECOMPANY_CARD:
          {
            PAGENAME: 'emcompanycard',
            PAGEID: 21,
            PAGE_IDENTITY: '6e1af0b2a37c422eade138c7cc255e44',
            BUTTON_ACCESS : {
              ADD: 'Insurance Company Add',
              EDIT: 'Insurance Company Edit',
              CLONE: 'Insurance Company Clone',
              DELETE: 'Insurance Company Delete'
            }
          },
        INSURANCECOMPANY_LIST:
          {
            PAGENAME: 'emcompanylist',
            PAGEID: 25,
            PAGE_IDENTITY: 'b316494470ac4803a5fced114f048b96'
          },
        INSURANCECOMPANY_ADD:
          {
            PAGENAME: 'emcompanyaaddedit',
            PAGEID: 26,
            PAGE_IDENTITY: '29',
            BUTTON_ACCESS : {
              Save: 'Insurance Company Save'
            }
          },
        },

      GARAGE:
      {
        GARAGE_CARD:
          {
            PAGENAME: 'emgaragecard',
            PAGEID: 22,
            PAGE_IDENTITY: 'b981ad80c6654124b394ed390fdb0a0d',
            BUTTON_ACCESS : {
              ADD: 'Garage Add',
              EDIT: 'Garage Edit',
              CLONE: 'Garage Clone',
              DELETE: 'Garage Delete'
            }
          },
        GARAGE_LIST:
          {
            PAGENAME: 'emgaragelist',
            PAGEID: 27,
            PAGE_IDENTITY: 'b316494470ac4803a5fced114f048b96'
          },
        GARAGE_ADD:
          {
            PAGENAME: 'emgarageaaddedit',
            PAGEID: 28,
            PAGE_IDENTITY: '30',
            BUTTON_ACCESS : {
              Save: 'Garage Save'
            }
          },
      },
    },
  },

  MENU_CONSTANTS:
  {
    MENUNAME:{
      DASHBOARD :{
        NAME:'Dashboard',
        URL:'/dashboard/dash'
      } ,
      PAGECONFIGURATOR : {
        NAME:'Page Configurator',
        URL:'/page-config'
      } ,
      PURCHASESTOCK : {
        NAME:'Purchase Stock',
        URL:'/page-config'
      } ,
      PAPERDETAILS:{
        NAME: 'Paper Details',
        URL: '/report-loss'
      } ,
      ENTITYMANAGEMENT:{
        NAME:'Entity Management',
        URL:'/entitymanagement'
      } ,
      REPORTS:{
        NAME:'Reports',
        URL:'/report-Data/reports-card'
      } ,
      USERMANAGEMENT:{
        NAME:'User Management',
        URL:'/usermanagement'
      }
    }
  }

};
