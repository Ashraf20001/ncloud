import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService } from './auth.service';
import { HeaderService } from './header/header.service';
import { HeaderDto } from '../models/header/header-dto';
import { Menu } from '../models/header/menu';

@Injectable({
  providedIn: 'root',
})
export class RouteDashboard implements CanActivate {

  constructor(private authService: AuthService, private router: Router, private headerService: HeaderService) {
  }

  canActivate(): boolean {
    if (this.authService.isAuthenticated()) {
      return false;
    } else {
      return true;
    }

  }

}
