import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";
import { ConstantService } from "./constants.service";
import { HttpClient, HttpParams } from "@angular/common/http";

const baseUrl = environment.API_BASE_URL;
@Injectable({
  providedIn: 'root'
})
export class SearchService {

    /**
   * @param environment
   * @function Base-URL
   */
  baseURL =  environment.API_BASE_URL+ ConstantService.data_lake;

  constructor(private http: HttpClient){
  }

  /**
   * 
   * @param param 
   */
  getAdvancedFilterObjects(param:any){
    return this.http.get(this.baseURL+"/search/advance-filter", {params : param});
  }

  /**

  /**
  * @param param
  * @param searchValue
  * @returns
  */
  getAdvancedFilterList(param: any, searchValue: any) {
    return this.http.post(this.baseURL + "/search/advanced-filter-list", searchValue, { params: param });
  }

  /**
   * @param params
   */
  globalSearch(params: HttpParams) {
    return this.http.get(this.baseURL+"/search/global-search", {params : params});
  }

  /**
   * @param repository
   */
  repositoryRecordsCount(repository : string, params : HttpParams, filterVo : any) {
    return this.http.post(this.baseURL+"/search/" + repository + "/total-records-count", filterVo, {params : params});
  }

    
  /**
   * @param params
   * @returns
   */
  MailService(mailDetails : any,mailID:string,repositoryname:string){
    return this.http.post(this.baseURL+'/search/mail-services?email='+mailID+'&repositoryName='+repositoryname + '&identity='+mailDetails, null);
  }
  

}