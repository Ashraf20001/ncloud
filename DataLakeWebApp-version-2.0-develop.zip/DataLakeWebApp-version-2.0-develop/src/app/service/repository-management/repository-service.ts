import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";
import { ConstantService } from "../constants.service";
import { FieldRepositoryDto } from "src/app/repository/repository-configurator/repository-configurator.component";
import { HttpClient, HttpParams } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class RepositoryService{

  /**
   * @param environment
   * @function Base-URL
   */
  baseURL =  environment.API_BASE_URL+ ConstantService.data_lake;

  constructor(private http: HttpClient){
  }

  /**
   * @function submit-repository
   * @param fieldRepositoryDto 
   */
  submitRepository(fieldRepositoryDto : FieldRepositoryDto){
    return this.http.post(this.baseURL + '/repository/submit-repostiory', fieldRepositoryDto);
  }

  /**
   * @function update-repository
   * @param fieldRepositoryDto 
   */
  saveRepository(fieldRepositoryDto : FieldRepositoryDto){
    return this.http.post(this.baseURL + '/repository/save-repository', fieldRepositoryDto);
  }

  /**
   * @function approve-repository
   * @param repositoryIdentity 
   */
  approveRepository(fieldRepositoryDto : FieldRepositoryDto){
    return this.http.post(this.baseURL+'/repository/approve-repository', fieldRepositoryDto);
  }

  
  /**
   * @function approve-repository
   * @param repositoryIdentity 
   */
  rejectRepository(param : any){
    return this.http.post(this.baseURL+'/repository/reject-repository',null, {params : param});
  }

  /**
   * @function clone-repository
   * @param fieldRepositoryDto 
   */
  cloneRepository(fieldRepositoryDto : FieldRepositoryDto){
    return this.http.post(this.baseURL + '/repository/clone-respository', fieldRepositoryDto);
  }

  /**
   * @function fetch-repository-details
   * @param param 
   */
  getRepositoryDetails(param : any){
    return this.http.get(this.baseURL + '/repository/repository-details', {params : param});
  }

  /**
   * 
   * @param params 
   * @returns 
   */
  getRepositoryStatus(params: HttpParams) {
    return this.http.get(this.baseURL + '/repository/repository-status', {params : params});
  }

}