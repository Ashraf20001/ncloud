import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from "src/environments/environment";
import { NotificationDTO } from '../models/notification-dto';
import { PurchaseHistoryNotificationDTO } from '../models/purchase-history-notification-dto';

const baseUrl = environment.API_BASE_URL;
@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  constructor(private http: HttpClient) { }

  /**
   * NOTIFICATION LIST
   * @returns
   */
  getNotificationList(): Observable<NotificationDTO[]> {
    return this.http.get<NotificationDTO[]>(baseUrl + '/api/claim/notification');
  }


  getNotificationListForDataLake(baseUrl: any, param?: any) {
    return this.http.get<any>(baseUrl + '/notification', { params: param });
  }


  downloadImageByImageName(imageName: string): Observable<any> {
    return this.http.get(baseUrl + '/api/downloadFile/' + imageName, { responseType: 'blob' });
  }

  /**
   * NOTIFICATION COUNT
   * @returns
   */
  getNotificationCount(baseUrl: any) {
    return this.http.get(baseUrl + '/get-notification-Count');
  }

  getNotificationListPurchaseHistory(): Observable<PurchaseHistoryNotificationDTO[]> {
    return this.http.get<PurchaseHistoryNotificationDTO[]>(baseUrl + '/get-notification');
  }

  updateNotification(params: HttpParams) {
    return this.http.put(baseUrl + '/data-lake/update-notification-unread',null,{ params: params });
  }
  getListOfDatas(filterVos, max) {
    const params = new HttpParams()
      .set('min', 0)
      .set('max', max);
    return this.http.post(baseUrl + '/data-lake/repository/repository-list', filterVos, { params: params });
  }
  Savecomments(Comments) {
    return this.http.post(baseUrl + '/data-lake/repository/save-comments', Comments);
  }
  getcomments(repoid) {
    const params = new HttpParams()
      .set('repositoryIdentity', repoid);
    return this.http.get(baseUrl + '/data-lake/repository/get-comments', { params: params });
  }
  getnotification(min, max, filtervos) {
    const params = new HttpParams()
      .set('min', min)
      .set('max', max);
    return this.http.post(baseUrl + '/data-lake/repository/get-scheduler-list', filtervos, { params: params });
  }

  getSchedulerCount() {
    return this.http.get(baseUrl + '/data-lake/repository/scheduler-count');
  }
}
