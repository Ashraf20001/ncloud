/* eslint-disable @typescript-eslint/no-explicit-any */
import { ErrorCode, ErrorCodeToIgnore } from './../common/enum/enum';
import { ConstantService } from './constants.service';
import { HttpErrorResponse, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { throwError, Observable, of } from 'rxjs';
import { catchError, concatMap, retryWhen } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';

@Injectable({
  providedIn: 'root',
})
export class HttpErrorInterceptorService implements HttpInterceptor {

  constructor(private toaster:ToastrService,public translate:TranslateService){}

  //checking if there is error for every http request
  intercept(request: HttpRequest<any>, next: HttpHandler) {
    return next.handle(request)
        .pipe(
            retryWhen(error => this.retryRequest(error,1)),
            catchError((error: HttpErrorResponse) => {
                const errorMessage = this.setError(error);
                console.log(error);
                return throwError(errorMessage);
            })
        );
}



  // Retry the request in case of errror
  retryRequest(error: Observable<unknown>, retryCount: number): Observable<unknown>
  {
      return error.pipe(
          concatMap((checkErr: HttpErrorResponse, count: number) => {

              if(count <= retryCount)
              {
                  switch(checkErr.status)
                  {
                  case ErrorCode.serverDown :
                      return of(checkErr);

                  // case ErrorCode.unauthenticated :
                  //     return of(checkErr);

                  }
              }
              return throwError(checkErr);
          })
      );
  }


  //setting error
  setError(error: HttpErrorResponse): string {

      let errorMessage = ConstantService.unknownError;
      let applicationException = JSON.parse(error?.error?.localizedMessage);
      if(error.status=== 400)
      {
        const errorIdList = JSON.parse(error.error.message);

        const msg =`Error Data.${errorIdList.errorIds[0].errorCode}`;
        errorMessage = this.translate.instant(msg);
        errorMessage = this.setDynamicErrorFromBackend(errorMessage,errorIdList.errorIds[0].hints)
        // this.errorCapture.setErrorObject(errorIdList.errorIds[0].errorCode);

        if(errorIdList.errorIds[0].errorCode !== ErrorCodeToIgnore.companyLogoError){
          this.toaster.error(errorMessage);
        }
          return error.statusText;
      }
      
      if(applicationException?.errorIds[0]?.errorCode != null && applicationException?.errorIds[0]?.errorCode != undefined){
        this.getTranslatedErrorMessages(applicationException?.errorIds[0]?.errorCode);
      }else{
      if(error.error instanceof ErrorEvent) {
          // Client side error
          errorMessage = error.error.message;
      } else {
          // server side error
          if(error.status=== ErrorCode.unauthorised)
          {
            const errorIdList = JSON.parse(error.error.message);
            const errorMessage = errorIdList.errorIds[0].errorMessage;
            this.toaster.error(this.translate.instant("Toaster_error.couldn't connect to server"));
              return error.statusText
          }
          if(error.status=== 400)
          {
            const errorIdList = JSON.parse(error.error.message);
            const errorMessage = errorIdList.errorIds[0].errorMessage;
            if(errorIdList.errorIds[0].errorCode !== ErrorCodeToIgnore.companyLogoError){
              this.toaster.error(errorMessage);
            }
              return error.statusText;
          }

          if (error.error.message && error.status!==ErrorCode.serverDown) {
              {const errorIdList = JSON.parse(error.error.message);
                errorMessage = errorIdList.errorIds[0].errorMessage;}
                this.toaster.error(errorMessage);
                return error.statusText
          }

          if (!error.error.message && error.error && error.status!==ErrorCode.serverDown) {
              const errorIdList = JSON.parse(error.error.message)
              errorMessage = errorIdList.errorIds[0].errorMessage;}
          }
      this.toaster.error(errorMessage);
      return errorMessage;
        }
  }

  getTranslatedErrorMessages(errorCode: string) : string{
    const errorMsg:string=this.translate.instant('Error Data.'+ errorCode);
    // if(hints!=undefined && hints!=null){
    //   hints.forEach((hint)=>{
    //     let value=hint.hintValue
    //     if(hint.hintKey===ErrorHints.fieldName || hint.hintKey===ErrorHints.aliasName || hint.hintKey===ErrorHints.fieldFormat){
    //       value=this.translate.instant('GENERATE_PAPER_MANUAL.'+value);
    //     }
    //     if(hint.hintKey===ErrorHints.pool){
    //       value=this.translate.instant('pool_names.'+value);
    //     }
    //     errorMsg=errorMsg.replace(hint.hintKey,value);
    //   });
    // }
    this.toaster.error(errorMsg);
    return errorMsg;
  }

  setDynamicErrorFromBackend(errorMessage: string, hints: any[]): string {
    let msgg = errorMessage;
    if (hints) {
      hints.forEach(hint => {
        msgg = msgg.replace(hint.hintKey, hint.hintValue);
      });
    }
    return msgg;
  }
}
