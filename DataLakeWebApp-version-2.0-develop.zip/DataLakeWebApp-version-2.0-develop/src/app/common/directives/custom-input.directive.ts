import { Directive, HostListener, ElementRef, Input } from '@angular/core';
import { NgControl } from '@angular/forms';

@Directive({
  selector: '[allowCharacters]'
})
export class CustomInputDirective {

  @Input('allowCharacters') regex: string;

  constructor(private el: ElementRef, private inputControl: NgControl) {}

  /**
   * @function custom-directive
   * @param event 
   */
  @HostListener('input', ['$event']) onInput(event: Event): void {
    const inputElement = this.el.nativeElement as HTMLInputElement;
    const initialValue = inputElement.value;
    // REGEX VALIDATIONS - ALLOW APLHABETS AND SPACE
    const pattern = new RegExp(`${this.regex}`, 'g')
    const sanitizedValue = initialValue.replace(pattern, '');
    if (initialValue !== sanitizedValue) {
      inputElement.value = sanitizedValue;
      this.inputControl.control.setValue(sanitizedValue, { emitEvent: false });
      event.stopPropagation();
    }
  }
}