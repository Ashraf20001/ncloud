/* eslint-disable no-prototype-builtins */
import { Component, Inject } from '@angular/core';
import { EventEmitter, OnDestroy, OnInit, Output } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { I18nServiceService } from 'src/app/service/i18n-service.service';
import * as Stomp from 'stompjs';
import * as SockJS from 'sockjs-client';
import { HttpParams } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { NotificationService } from 'src/app/service/notification.service';
import { Subscription } from 'rxjs';
import { ErrorHandlerDirective } from '../../directives/errorHandler.directive';
import { NotificationDTO } from 'src/app/models/notification-dto';

import { appConst } from 'src/app/service/app.const';
import { AdminService } from 'src/app/service/admin.service';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { PlatFormTypeEnum } from '../../enum/platformtype.enum';
import { NotificationDto } from 'src/app/models/repository-notification-dto';
import { RepositoryService } from 'src/app/service/repository-management/repository-service';
import { TranslateService } from '@ngx-translate/core';
import { AppService } from 'ncloud-common-ui';
import { NotificationRequestDto } from 'ncloud-common-ui/lib/dto/notification-request-dto';


@Component({
  selector: 'app-notification-popup',
  templateUrl: './notification-popup.component.html',
  styleUrls: ['./notification-popup.component.scss']
})
export class NotificationPopupComponent implements OnInit,OnDestroy{

  showmessage=false;
  companyId:number;
  imgUrl='';
  stompClient: any;
  socket: any;
  notificationCount: any = 0;
  companyName: any = '';
  currentCompanyName: string;
  noNotification = false;
  notificationSubscribtion: Subscription;
  notoficationCountSubscription:Subscription;
  notificationDetailsList: NotificationDTO[];
  allNotifications: any[];

  // purchaseHistoryDetailsList:PurchaseHistoryNotificationDTO[];
  menuHeaderList: any;
  notification_Data:any[]=[
    {
      profileImg: 'assets/prfile.svg',
      content:'Garage details has been added for',
      claimId:'1235',
      company:'Partner Insurance Limited',
    },
    {
      profileImg:'assets/prfile.svg',
      content:'Garage details has been added for ',
      claimId:'1235',
      company:'Partner Insurance Limited',
    },
  ]
  public appConst = appConst;

  @Output() showClaimEvent = new EventEmitter<{ claimId: number, isReceivable: boolean }>();
  @Output() fullViewNotification=new EventEmitter<boolean>();
  isReceivable = true;
  fromNotification = false;
  platFormId: any;
  baseUrls: any;
  userId: NotificationDto[];
  profileImage: any;
  value: any;
  imageUrl: any;
  image: any;

constructor(  @Inject(MAT_DIALOG_DATA) public data: DialogData,public dialog: MatDialog,public translate:TranslateService,private route:Router,  public i18nConf: I18nServiceService, private activatedRoute: ActivatedRoute,
  private notificationService: NotificationService,private errorHandler: ErrorHandlerDirective, private appservice: AppService, private adminService: AdminService,public dialogRef: MatDialogRef<NotificationPopupComponent>, private repositoryService : RepositoryService){
  this.getCurrentUrl();
  // this.i18nConf = i18nConf;
  // this.i18nConf.setUpConf();
  this.getLoggedInUserCompanyId();
  this.currentCompanyName  = sessionStorage.getItem("companyName");


  // this.allNotifications=data.notificationData;


}
  currentRoute: string;

getCurrentUrl(){
  this.currentRoute = window.location.href;
  this.route.events.subscribe((event: any) => {
    if (event instanceof NavigationEnd) {
      this.currentRoute = event.url
    }
  });

}

  isAdmin:boolean;

  ngOnInit(): void {
  // this.getMenuItems();
  // this.notificationCountGET();
  // this.isAdmin = this.adminService.isAssociationUser();
  this.activatedRoute.queryParams.subscribe((queryParams: any) => {
    if(!this.fromNotification) {
      this.isReceivable = queryParams["rec"] !== undefined ? queryParams["rec"] !== 'false' : true;
    }
  });

   this.notificationGET();

  this.translate.onLangChange.subscribe(() => {

    this. notificationGET();

    })
  // this.purchaseHistoryNotificationGet()
  // this.purchaseHistoryNotificationGet();

  }

baseUrl = environment.API_BASE_URL ;
  collapsed=true;
  nav1='dashboard'
  nav2='reportloss'
  nav3='receivable'
  nav4='payable'
  nav5='user'




 /**
   * WEBSCKET CONNECTION & SUBSCRIPTION
   */
  connectWebSocket() {
    // this.socket = new SockJS(this.baseUrl + '/api/ws');
    // this.stompClient = Stomp.over(this.socket);
    // const _this = this;
    // _this.stompClient.connect({}, function (frame: any) {
    //   _this.stompClient.subscribe(
    //     '/topic/notification/' + _this.companyName,
    //     function (response: any) {
    //       _this.onMessageReceived(response);
    //     }
    //   );
    // });
  }

  /**
   * NOTIFICATION COUNT ADDITION - WEBSOCKET
   * @param response
   */
  onMessageReceived(response: any) {
    console.log(JSON.parse(response.body));
    const notification = JSON.parse(response.body);
    if(notification != null || notification != undefined){
      this.notificationDetailsList.push(notification);
      this.notificationCount = this.notificationCount + 1;
    }
  }

  /**
   * GET COMPANY ID OF LOGGED-IN USER
   */
  getLoggedInUserCompanyId(){
    // const identity = sessionStorage.getItem("userIdentity");
    // const params =  new HttpParams().set("user_id",identity);
    // this.dashboardService.getLoggedInUserCompanyId(params).subscribe((data:any)=>{
    //   const name = data.companyId?.name;
    //   this.companyId = data.companyId.companyId;
    //   if(name != null){
    //     this.companyName = name;
    //     this.connectWebSocket();
    //   }
    //   this.dashboardService.getCompanyLogo(this.companyId).subscribe((response)=>{
    //     if (response) {
    //       this.imgUrl = response['content']
    //     }
    //   })
    // })
  }
  /**
   * NOTIFICATION GET CALL METHOD
   */


  temp: NotificationDto[] ;
  notificationGET(){
    this.platFormId = sessionStorage.getItem('platformDetails');
    const platformDetails = JSON.parse(this.platFormId);
    if (platformDetails.platformId == PlatFormTypeEnum.DATA_LAKE) {
      if(sessionStorage.getItem('companyId')) {
        const notificationRequestData : NotificationRequestDto = {
          claimId: -1,
          status: '',
          companyName: sessionStorage.getItem('companyName'),
          isReceivable: '',
          logoUrl: '',
          lastActed: '',
          platformId: PlatFormTypeEnum.DATA_LAKE
        }
        this.appservice.getNotificationListForDataLakeIC(notificationRequestData).subscribe((res: any) => {
          this.notificationDetailsList = res;
          if(this.notificationDetailsList.length > 0){
           this.allNotifications = this.notificationDetailsList
           this.allNotifications.map(x => {
             if (x.status) {
               let notificationTemplate = this.translate.instant(`NotificationTemplate.${x.status.toLowerCase()}`);
               const parsedObject = JSON.parse(x.notificationJson);
               const keyValueList = [];
               for (const key in parsedObject) {
                 if (parsedObject.hasOwnProperty(key)) {
                   keyValueList.push({ key, value: parsedObject[key] });
                 }
               }
               keyValueList.forEach(({ key, value }) => {
                 const regex = new RegExp(key, "g");
                 notificationTemplate = notificationTemplate.replace(regex, value);
               });
               if (!notificationTemplate.includes('NotificationTemplate')) {
                 x.template = notificationTemplate;
               }
             }
           });
           console.log("notification...."+this.allNotifications);
         }
         });

      }else if(sessionStorage.getItem('companyId') === null|| sessionStorage.getItem('companyId') === undefined || sessionStorage.getItem('userRoleStatus') != null){
        this.notificationDetailsList = [];
      this.baseUrls = this.baseUrl + "/data-lake";
      const param = new HttpParams().set('isViewAllNotifications', true)
      this.notificationService.getNotificationListForDataLake(this.baseUrls, param).subscribe((response: any) => {
        if (response) {
          // const notifications : NotificationDto[] = response.content;

          this.allNotifications = response.content;

          if (this.allNotifications.length > 0) {
            this.allNotifications=this.allNotifications.map(notification => ({
             ...notification,
             imageUrl: notification.logoUrl
               ? `${this.baseUrl + '/api/downloadFile/'}/${notification.logoUrl}`
               : 'assets/no-logo.svg'
           }));
          //  this.allNotifications=this.notifications;
         }

          this.allNotifications.map(x => {
            if (x.status) {
              let notificationTemplate = this.translate.instant(`NotificationTemplate.${x.status.toLowerCase()}`);
              const parsedObject = JSON.parse(x.notificationJson);
              const keyValueList = [];
              for (const key in parsedObject) {
                if (parsedObject.hasOwnProperty(key)) {
                  keyValueList.push({ key, value: parsedObject[key] });
                }
              }
              keyValueList.forEach(({ key, value }) => {
                const regex = new RegExp(key, "g");
                notificationTemplate = notificationTemplate.replace(regex, value);
              });
              if (!notificationTemplate.includes('NotificationTemplate')) {
                x.template = notificationTemplate;
              }
            }
          });
        }
      })
    } else {
      this.notificationSubscribtion = this.notificationService.getNotificationList().subscribe((res: any) => {
        if (res) {
          this.notificationDetailsList = res;
        }
      }, (error: Response) => {
        this.errorHandler.getMessage(error);
      })
    }
  }
}


  /**
   * NOTIFICATION COUNT CALL GET METHOD
   */
  notificationCountGET(){
    this.platFormId = sessionStorage.getItem('platFormDetails')
    if(this.platFormId === PlatFormTypeEnum.DATA_LAKE){
      this.baseUrl = this.baseUrl+"/data-lake";
    } else if(this.platFormId === PlatFormTypeEnum.DIGITAL_PAPER){
      this.baseUrl = this.baseUrl+"/digital-paper"
    }
    this.notoficationCountSubscription = this.notificationService.getNotificationCount(this.baseUrl).subscribe((res:any)=>{
      const result = res;
      this.notificationCount = result?.totalCount;
    },(error:Response)=>{
      this.errorHandler.getMessage(error);
    })
  }
  /**
   * DESTROY THE SUBSCRIBTION
   */
  ngOnDestroy(): void {
    if(this.notificationSubscribtion){
      this.notificationSubscribtion.unsubscribe();
    }
    if(this.notoficationCountSubscription){
      this.notoficationCountSubscription.unsubscribe();
    }
  }

  getNotificationLogo(notification: NotificationDTO): string {
    let name = '';
    name = notification.lastActedCompany;
    if(name === 'AXA insurance') {
      name = 'AXA';
    }
    const logo = '/assets/company_logo/' + name + '_Logo.png';
    return logo;
  }

  showClaim(notification: NotificationDTO, index : number): void {
    this.notificationDetailsList.splice(index,1)
    notification.index=index;
    this.dialogRef.close(notification);
  }

  getMenuHeader(pageName: string): boolean{
    const menuHeader = this.menuHeaderList?.find((element) => element.menuName === pageName);
    return menuHeader;
  }

  getMenuItems(){
    this.appservice.getMenubyRole().subscribe((res: any)=>{
      this.menuHeaderList = res.content;
    });
  }
  getLogo(){
    if (this.imgUrl!=='') {
      return this.imgUrl;
    }else{
      return 'assets/no-logo.svg';
    }
  }

  notificationMsg(notification : any) {
    this.closeTab();
    if(notification.repositoryIdentity){
      const params =  new HttpParams().set('identity', notification.repositoryIdentity);
      this.repositoryService.getRepositoryStatus(params).subscribe((data : any) =>{
        let response = data.content;
        this.route.navigate(['/repository/edit-repository/'+notification.repositoryIdentity], {queryParams : {status : response.status, isDisabled : response.isDisabled}})
      })
      this.notificationCount--;
      this.notificationService.updateNotification(params).subscribe((data: any) => {
        console.log("update "+data.content)
      });
    }
  }

closed=true;
close(){
    this.closed =!this.closed;
  }
  closeTab()
  {
    this.dialog.closeAll();
  }
}
export class DialogData {

  notificationData:any;
}
