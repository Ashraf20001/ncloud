import { Component,Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-popup',
  templateUrl: './popup.component.html',
  styleUrls: ['./popup.component.scss']
})
export class PopupComponent implements OnInit{
  constructor(public dialogRef: MatDialogRef<PopupComponent>,
    @Inject(MAT_DIALOG_DATA) public data: Data) {

     }
     ngOnInit(): void {
         
     }
     
  cancel(value:boolean){
    this.data.clickOk = value;
  this.dialogRef.close(false);
  }
  submit(value:boolean){
    this.data.clickOk = value;
    this.dialogRef.close(true);
  }
}
export interface Data{
  okButton:string;
  cancelButton:string;
  message:string
  clickOk:boolean;

}