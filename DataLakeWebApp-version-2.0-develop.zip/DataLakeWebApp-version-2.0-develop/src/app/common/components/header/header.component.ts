import { EventEmitter, OnDestroy, OnInit, Output } from '@angular/core';
import { Component } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { I18nServiceService } from 'src/app/service/i18n-service.service';
import * as Stomp from 'stompjs';
import * as SockJS from 'sockjs-client';
import { HttpParams } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { NotificationService } from 'src/app/service/notification.service';
import { Subscription } from 'rxjs';
import { ErrorHandlerDirective } from '../../directives/errorHandler.directive';
import { NotificationDTO } from 'src/app/models/notification-dto';
import { AppService } from 'src/app/service/role access/service/app.service';
import { appConst } from 'src/app/service/app.const';
import { AdminService } from 'src/app/service/admin.service';
import { NotificationPopupComponent } from '../notification-popup/notification-popup.component';
import { MatDialog } from '@angular/material/dialog';
import { PurchaseHistoryNotificationDTO } from 'src/app/models/purchase-history-notification-dto';
import { HeaderService } from 'src/app/service/header/header.service';
import { HeaderDto } from 'src/app/models/header/header-dto';
import { Menu } from 'src/app/models/header/menu';
import { PlatFormTypeEnum } from '../../enum/platformtype.enum';


@Component({
  selector: 'app-headers',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})

export class HeaderComponent implements OnInit, OnDestroy {


  showmessage = false;
  companyId: number;
  imgUrl = '';
  stompClient: any;
  socket: any;
  notificationCount: number = 0;
  companyName: any = '';
  currentCompanyName: string;
  noNotification = false;
  notificationSubscribtion: Subscription;
  notoficationCountSubscription: Subscription;
  notificationDetailsList: NotificationDTO[];
  menuHeaderList: any;
  notification_Data: any[] = [
    {
      profileImg: 'assets/prfile.svg',
      content: 'Garage details has been added for',
      claimId: '1235',
      company: 'Partner Insurance Limited',
    },
    {
      profileImg: 'assets/prfile.svg',
      content: 'Garage details has been added for ',
      claimId: '1235',
      company: 'Partner Insurance Limited',
    },
  ]
  public appConst = appConst;

  @Output() showClaimEvent = new EventEmitter<{ claimId: number, isReceivable: boolean }>();
  @Output() fullViewNotification = new EventEmitter<boolean>();
  isReceivable = true;
  fromNotification = false;
  showOrNot=false;
  headerShowOrNot=false;
  platFormId: any;
  baseUrls: any;
  notificationMessage: any[];

  constructor(public dialog: MatDialog, private route: Router, public i18nConf: I18nServiceService, private activatedRoute: ActivatedRoute,
    private notificationService: NotificationService,private errorHandler: ErrorHandlerDirective, private appservice: AppService, private adminService: AdminService, private headeService : HeaderService) {
    this.getCurrentUrl();
    this.i18nConf = i18nConf;
    this.i18nConf.setUpConf();
    this.getLoggedInUserCompanyId();
    this.currentCompanyName = sessionStorage.getItem("companyName");
    this.getheaderlist();
  }
  currentRoute: string;
  menuList : Menu[] = [];
  platformName : string;
  platformLogo : string;

  /**
   * MENU DETAILS
   */
  getheaderlist(){

    this.headeService.getMenuDetails().subscribe((reponse:HeaderDto) =>{
      if(reponse){
        this.menuList = [];
        this.menuList = reponse.menuDetails;
        this.platformName = reponse.platformDetails.platformName;
        this.platformLogo = reponse.platformDetails.platformLogoPath;
      }
    })
  }

  getCurrentUrl() {
    this.currentRoute = window.location.href;
    this.route.events.subscribe((event: any) => {
      if (event instanceof NavigationEnd) {
        this.currentRoute = event.url
      }
    });

  }
  isAdmin: boolean;

  ngOnInit(): void {
    // this.getMenuItems();
    this.platFormId = sessionStorage.getItem('platFormDetails');
    this.notificationGET();
    // this.notificationCountGET();
    this.isAdmin = this.adminService.isAssociationUser();
    this.activatedRoute.queryParams.subscribe((queryParams: any) => {
      if (!this.fromNotification) {
        this.isReceivable = queryParams["rec"] !== undefined ? queryParams["rec"] !== 'false' : true;
      }
    });
    this.getNotificationCount();

  }
totalCount
  getNotificationCountForDataLake(){
    this.notificationService.getNotificationCount(this.baseUrl).subscribe((data: any) => {
      if (data) {
        this.notificationCount=data.content
      if(this.notificationCount>100){
        this.notificationCount=99;
        this.totalCount = this.notificationCount + "+";
      }
      else{
        this.totalCount = this.notificationCount;
      }
}
    });
  }
  getNotificationCount(){
    if(this.platFormId == PlatFormTypeEnum.DATA_LAKE){
      this.baseUrl = this.baseUrl+"/data-lake";
    } else if(this.platFormId === PlatFormTypeEnum.DIGITAL_PAPER){
      this.baseUrl = this.baseUrl+"/digital-paper"
    }
    this.notificationService.getNotificationCount(this.baseUrl).subscribe((data: any) => {
      if (data) {
        this.notificationCount = data.content;
        // this.purchaseHistoryNotificationGet();
      }
    });
  }

  baseUrl = environment.API_BASE_URL;
  collapsed = true;
  nav1 = 'dashboard'
  nav2 = 'reportloss'
  nav3 = 'receivable'
  nav4 = 'payable'
  nav5 = 'user'




  /**
    * WEBSCKET CONNECTION & SUBSCRIPTION
    */
  connectWebSocket() {
    // this.socket = new SockJS(this.baseUrl + '/api/ws');
    // this.stompClient = Stomp.over(this.socket);
    // const _this = this;
    // _this.stompClient.connect({}, function (frame: any) {
    //   _this.stompClient.subscribe(
    //     '/topic/notification/' + _this.companyName,
    //     function (response: any) {
    //       _this.onMessageReceived(response);
    //     }
    //   );
    // });
  }

  /**
   * NOTIFICATION COUNT ADDITION - WEBSOCKET
   * @param response
   */
  onMessageReceived(response: any) {
    // console.log(JSON.parse(response.body));
    // let notification = JSON.parse(response.body);
    // if (notification != null || notification != undefined) {
    //   this.notificationDetailsList.push(notification);
    //   this.notificationCount = this.notificationCount + 1;
    // }
  }

  /**
   * GET COMPANY ID OF LOGGED-IN USER
   */
  getLoggedInUserCompanyId() {
    // const identity = sessionStorage.getItem("userIdentity");
    // const params = new HttpParams().set("user_id", identity);
    // this.dashboardService.getLoggedInUserCompanyId(params).subscribe((data: any) => {
    //   const name = data.companyId.name;
    //   this.companyId = data.companyId.companyId;
    //   if (name != null) {
    //     this.companyName = name;
    //     this.connectWebSocket();
    //   }
    //   this.dashboardService.getCompanyLogo(this.companyId).subscribe((response) => {
    //     if (response) {
    //       this.imgUrl = response['content']
    //     }
    //   })
    // })
  }
  /**
   * NOTIFICATION GET CALL METHOD
   */
  notificationGET() {
this.platFormId =3;
    if(this.platFormId == PlatFormTypeEnum.DATA_LAKE){
      this.baseUrls = this.baseUrl+"/data-lake";
      const param = new HttpParams().set('isViewAllNotifications', false)
      this.notificationService.getNotificationListForDataLake(this.baseUrls, param).subscribe((res:any)=>{
        if(res.content){
          let tempArr = []
          res.content.forEach(result => {
            let purchaseHstryDetailsList : PurchaseHistoryNotificationDTO = {
              notificationMsg: result.notificationContent,
              actedBy: 0,
              orderId: 0,
              imageUrl: '',
              notificationId: 0,
              identity: result.identity,
              createdDate: result.createdDate,
              repositoryIdentity: '',
              isRepoCmts: false,
              status: ''
            }
            tempArr.push(purchaseHstryDetailsList);
          });
          this.purchaseHistoryDetailsList = tempArr;
        }
      })
    }else {
      this.notificationSubscribtion = this.notificationService.getNotificationList().subscribe((res: any) => {
      if (res) {
        this.notificationDetailsList = res;
      }
    }, (error: Response) => {
      this.errorHandler.getMessage(error);
    })
  }
  }
  /**
   * NOTIFICATION COUNT CALL GET METHOD
   */
  notificationCountGET() {
    // this.notoficationCountSubscription = this.notificationService.getNotificationCount().subscribe((res: any) => {
    //   let result = res;
    //   this.notificationCount = result?.totalCount;
    // }, (error: Response) => {
    //   this.errorHandler.getMessage(error);
    // })
  }
  /**
   * DESTROY THE SUBSCRIBTION
   */
  ngOnDestroy(): void {
    if (this.notificationSubscribtion) {
      this.notificationSubscribtion.unsubscribe();
    }
    if (this.notoficationCountSubscription) {
      this.notoficationCountSubscription.unsubscribe();
    }
  }

  getNotificationLogo(notification: NotificationDTO): string {
    let name = '';
    name = notification.lastActedCompany;
    if (name === 'AXA insurance') {
      name = 'AXA';
    }
    const logo = '/assets/company_logo/' + name + '_Logo.png';
    return logo;
  }

  showClaim(notification: NotificationDTO, index: number): void {
    this.notificationDetailsList.splice(index, 1)
    this.notificationCount--;
    this.isReceivable = notification.receivable;
    this.fromNotification = true;
    this.showClaimEvent.emit({
      claimId: notification.claimId,
      isReceivable: this.isReceivable
    });
  }

  getMenuHeader(pageName: string): boolean {
    const menuHeader = this.menuHeaderList?.find((element) => element.menuName === pageName);
    return menuHeader;
  }

  getMenuItems() {
    this.appservice.getMenubyRole().subscribe((res: any) => {
      this.menuHeaderList = res.content;
    });
  }
  getLogo() {
    if (this.imgUrl !== '') {
      return this.imgUrl;
    } else {
      return 'assets/no-logo.svg';
    }
  }

  notification_fullview() {

    this.fullViewNotification.emit();


  }
  popup_fullscreen(value:any ) {
    this.showmessage = true;
    const dialogRef = this.dialog.open(NotificationPopupComponent, {
      width: '600px', height: '731px',
      data: {
        notificationData:value
      },

    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {

        this.showClaim(result, result.index)
      }

    });
  }
  purchaseHistoryDetailsList: PurchaseHistoryNotificationDTO[];

  purchaseHistoryNotificationGet() {

    this.notificationService.getNotificationListPurchaseHistory().subscribe((data: any) => {
      if (data) {
        this.purchaseHistoryDetailsList = data.content;
      }
    });
  }
  notificationMsg(data:PurchaseHistoryNotificationDTO) {
    if(this.isAdmin){
    this.route.navigate(['authority-paper-details/transaction-history'],{ queryParams: { notificationId: data.actedBy }});
    }else{
      this.route.navigate(['/purchase-stock'],{ queryParams: { notificationId: data.actedBy }});
    }


    if (this.notificationCount > 0) {
      this.notificationCount--;
    }


    // this.notificationService.updateNotification(data.notificationId).subscribe((data: any) => {
    //   this.purchaseHistoryNotificationGet();
    // });
      }
}



