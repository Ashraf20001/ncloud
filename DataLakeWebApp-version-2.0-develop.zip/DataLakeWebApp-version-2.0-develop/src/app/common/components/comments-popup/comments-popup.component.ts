import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
//import { HeaderService } from 'src/app/service/header/header.service';
//import { HeaderService } from './../../../service/header/header.service';
//import { NotificationService } from 'src/app/service/notification.service';
//import { NotificationService } from './../../../service/notification.service';
import { Component, Inject } from '@angular/core';
import { NotificationPopupComponent } from '../notification-popup/notification-popup.component';
import { NotificationService } from 'src/app/service/notification.service';
import { ErrorHandlerDirective } from '../../directives/errorHandler.directive';
import { AdminService } from 'src/app/service/admin.service';
import { I18nServiceService } from 'src/app/service/i18n-service.service';
import { AppService } from 'src/app/service/role access/service/app.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { HttpParams } from '@angular/common/http';
import { RepositoryService } from 'src/app/service/repository-management/repository-service';
import { environment } from 'src/environments/environment';
import { ConstantService } from 'src/app/service/constants.service';
import { TranslateService } from '@ngx-translate/core';
import * as Stomp from 'stompjs';
import  SockJS from 'sockjs-client';

const baseUrl = environment.API_BASE_URL + ConstantService.download_file;
export interface commentsDto {
  message: string;
  status: string;
  isCreator: any;
  createdDate;
  createdTime;
  repoIdentity: any;
  repositoryName;
  action: string;
  isRightCmts:boolean;
  userName:string
  logoUrl?: string;
  imageUrl?: String;
}

export interface DialogData {
  repositoryIdentity: string;
  repositoryName: string;
  isCreator: boolean;
  action: string
}

@Component({
  selector: 'app-comments-popup',
  templateUrl: './comments-popup.component.html',
  styleUrls: ['./comments-popup.component.scss']
})
export class CommentsPopupComponent {
  dates: Date = new Date();
  commentsDto:commentsDto[]=[];
  obj: string;
  sendcomments: commentsDto;
  repoIdentity: string;
  userRoleStatus: string;
  isUserRole: boolean;
  allCommants: commentsDto[] =[];
  allComments: commentsDto[];
  stompClient: any;
  socket: any;
  popupDiv = false;

  constructor(@Inject(MAT_DIALOG_DATA) public data: DialogData, public dialog: MatDialog,public translate:TranslateService, private toaster:ToastrService, private route: Router, public i18nConf: I18nServiceService, private activatedRoute: ActivatedRoute,
    private notificationService: NotificationService, private errorHandler: ErrorHandlerDirective, private appservice: AppService, private adminService: AdminService, public dialogRef: MatDialogRef<NotificationPopupComponent>, private repositoryService : RepositoryService) {
      // this.connectWebSocket();
  }

  ngOnInit(): void {
    this.sendcomments =
    {
      message: this.obj,
      status: undefined,
      isCreator: false,
      createdDate: undefined,
      createdTime: undefined,
      repoIdentity: this.data.repositoryIdentity,
      repositoryName: this.data.repositoryName,
      action: this.data.action,
      isRightCmts:false,
      userName:''
    }

    this.getcomments();

  }

  /**
   *
   */
  send(): void {
    if(!this.obj){
      // this.toaster.error(this.translate.instant('Toaster_error.Please enter comment'));
      this.popupDiv = true;
      return;
    } else {
      this.popupDiv = false;
    }
    let comments: commentsDto = {
      message: this.obj,
      status: '',
      isCreator: sessionStorage.getItem("userRoleStatus"),
      createdDate: undefined,
      createdTime: undefined,
      repoIdentity: this.data.repositoryIdentity,
      repositoryName: this.data.repositoryName,
      action: this.data.action,
      isRightCmts: undefined,
      userName: ''
    }

    this.notificationService.Savecomments(comments).subscribe((data: any) => {
      if(data.content){
        this.toaster.success(this.translate.instant('Toaster_success.Repository modification request has been sent successfully'));
        this.getcomments();
      }
    });
    this.obj = undefined;
  }
  closeTab() {
    this.dialog.closeAll();
        //  this.route.navigate(['/repository']);
  }

  navigateUrl(event:any){
    this.closeTab()
    const params =  new HttpParams().set('identity', event.repoIdentity);
    this.repositoryService.getRepositoryStatus(params).subscribe((data : any) =>{
      let response = data.content;
      this.route.navigate(['/repository/edit-repository/'+ event.repoIdentity], {queryParams : {status : response.status, isDisabled : response.isDisabled}})
    })
    // this.route.navigate(['/repository/edit-repository/' + event.repoIdentity]);
  }

  /**
   *
   */
  getcomments() {
    this.repoIdentity = this.data.repositoryIdentity;
    this.notificationService.getcomments(this.repoIdentity).subscribe((data: any) => {
      this.commentsDto = data;
      this.userRoleStatus = sessionStorage.getItem('userRoleStatus');
      this.commentsDto.forEach(comment => {
        if (comment.isCreator == this.userRoleStatus) {
          comment.isRightCmts = true;
        }
      })
      if (this.commentsDto.length > 0) {
        this.commentsDto = this.commentsDto.map(comments => ({
          ...comments,
           imageUrl: comments.logoUrl
            ?  `${baseUrl}/${comments.logoUrl}`
            : '/assets/icons/r3.svg'
        }));
      }
    })
  }

  /**
   * WEBSCKET CONNECTION & SUBSCRIPTION
   */
  connectWebSocket() {
    const companyName =  sessionStorage.getItem('companyName')
     this.socket = new SockJS(environment.API_BASE_URL+'/data-lake/notify');
     this.stompClient = Stomp.over(this.socket);
     const _this = this;
     _this.stompClient.connect({}, function (frame: any) {
       _this.stompClient.subscribe(
         '/topic/notification/',
         function (response: any) {
           _this.onMessageReceived(response);
         }
       );
     });
   }
 
   /**
    * NOTIFICATION COUNT ADDITION - WEBSOCKET
    * @param response
    */
   onMessageReceived(response: any) {
     const socketResponse = JSON.parse(response.body);
     if(socketResponse == true){
      this.getcomments();
     }
   }

   removemessage() {
    this.popupDiv = false;
   }
}
