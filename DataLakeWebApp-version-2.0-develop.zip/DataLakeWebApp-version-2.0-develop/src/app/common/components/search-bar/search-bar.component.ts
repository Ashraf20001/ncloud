import { HeaderService } from 'src/app/service/header/header.service';
import { DatePipe, formatDate } from "@angular/common";
import { AfterViewInit, Component, EventEmitter, Inject, Input, LOCALE_ID, OnChanges, OnInit,Output, SimpleChanges, ViewChild } from "@angular/core";
import { FormControl, FormGroup } from "@angular/forms";
import { MatAutocompleteSelectedEvent } from "@angular/material/autocomplete";
import { ActivatedRoute, Router } from "@angular/router";
import { Observable, distinctUntilChanged } from "rxjs";
import { FilterObject, Filtervo } from "src/app/models/Filter-dto/filter-object";
import { FilterOrSortingVo } from "src/app/models/Filter-dto/filter-object-backend";
import { SearchSharedService } from 'src/app/repository/global-search/searchshared.service';
import { FormBuilder, Validators } from '@angular/forms';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_LOCALE, MAT_DATE_FORMATS } from '@angular/material/core';
import { MY_FORMATS } from 'src/app/repository/manage-repository/repository-navigation/repository-card-view/disabled-popup/disabled-popup.component';

@Component({
  selector: 'app-search-bar',
  templateUrl: './search-bar.component.html',
  styleUrls: ['./search-bar.component.scss'],
  providers :[DatePipe,
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }]
})
export class SearchBarComponent implements OnInit,OnChanges {

  @Output() emitFilterValue = new EventEmitter<FilterOrSortingVo[]>();
  @Output() emitSearchValue = new EventEmitter<string>();
  @Input() filterObjectFromParent:FilterObject[];
  @Input() advancedFilterVo:any[];
  @Input() searchdisable : any;
  @Input() bordernone:boolean;
  @Input() isRepositorySearch:boolean;

  minDate : any;
  Statuses=Status
  ShowIcon:boolean = false;
  ShowIcons:boolean = false;

  searchFilterControl = new FormControl();
  canShowSearchIcon : boolean = true;
  @Input() canShowCancelIcon : boolean;
  @Input() isGlobalSearch : boolean = false;
  @Input() search : string;
  @Input() isCardview=false;
  dataValue: any;
  value: any;
  RepoClose: boolean;
  repositoryName: any;
  searchText: any;
  timeZone : any
  dateFormat = 'dd-MM-yyyy'; // To Be Dynamic !!!!!!!!!!!!!!!!!!!!!!!!!!!!
  searchInputIsDisabled: boolean;
  searchData: string;
  closeIconEnable: boolean;
  showSearchValue: boolean = true;
  
  constructor(private router: Router,public headerservice:HeaderService, private route : Router, @Inject(LOCALE_ID) private locale: string,
    private searchShareSub:SearchSharedService,private activateRoute: ActivatedRoute, private datePipe : DatePipe) {
    // this.clearAll();
    this.filterObject = [];
    this.timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;

  }
  show=true;
  ngOnInit(): void {
    // if(!this.isCardview && !this.isGlobalSearch){
    //   this.searchFilterControl.disable()
    // }
    this.activateRoute.queryParams.subscribe((data: any) => {
      this.dataValue = data['validateRepository'];
      this.repositoryName = data['repositoryName'];
      this.value = data['filterClose'];
    });
    if(!this.repositoryName){
    this.searchShareSub.clearFilter();
    }
    if(this.search){
      this.searchFilterControl.setValue(this.search)
    }
    if(this.value !== 'false'){
    this.searchShareSub.response.pipe(distinctUntilChanged()).subscribe((res)=>{
      this.filterObject = [];
      if(res){
        this.filterObject = res;
      }
      // if(this.filterObject.length > 0 && this.filterObject != undefined){
      //   this.ShowIcons = true;
      // }else{
      //   this.ShowIcons = false;
      // }
    })
    if(this.filterObjectFromParent){
    this.filterObject=this.filterObjectFromParent;
    }
  }
console.log(this.bordernone);

// this.filterObject=this.filterObjectFromParent;
//     this.clearAll();
}

  /*
  *  Get FilterObject From Parent
  */
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['filterObjectFromParent']?.currentValue!== undefined) {
      this.filterObject = this.filterObjectFromParent;
    }
    if(changes['isRepositorySearch']?.currentValue!== undefined){
      this.closeIconEnable=false;
      this.showSearchValue = false;
    }
    // if(changes['advancedFilterVo']?.currentValue!==undefined){
    //   this.filterObject = this.advancedFilterVo;
    // }
  }
 

  readOnly = true;
  showFilter = false;
  filterObjectBackend: FilterOrSortingVo[];
  //filterObject: FilterObject[] = []

   filterObject: FilterObject[] = [
//      {

//        columnName: 'fieldCount',
//        condition: 'Equal',
//        aliasName: 'No of Fields',
//        type: 'field',
//        value: [],
//        dropdown: [],
//        radio: [],
//         dataType:''
//      },
//      {
//        columnName: 'repoStatus',
//        condition: 'IN',
//        aliasName: 'Status',
//        type: 'chips',
//        value: [],
//        dropdown: ['Approved','Submitted','Rejected','Drafted'],
//        radio: [],
// dataType:''
//      },
   ];

  validateTypeIsField(type: any) {
    if (type.type === 'field') {
      return true;
    } else {
      return false;
    }
  }

  validateTypeIsDates(type: any) {
    if (type.type === 'dates') {
      return true;
    } else {
      return false;
    }
  }

  validateTypeIsFields(type: any) {
    if (type.type === 'fields') {
      return true;
    } else {
      return false;
    }
  }

  validateTypeIsChips(type: any) {
    if (type.type === 'chips') {
      return true;
    } else {
      return false;
    }
  }

  validateTypeIsRadio(type: any) {
    if (type.type === 'radio') {
      return true;
    } else {
      return false;
    }
  }

  validateTypeIsDropdown(type: any) {
    if (type.type === 'dropdown') {
      return true;
    } else {
      return false;
    }
  }

  displayFn(option: any): string {
    return '';
  }

  remove(ListName: string, item: any): void {
    const index = item.value.indexOf(ListName);
    item.value.splice(index, 1);
    item.dropdown.push(ListName);

    let ind: any = this.Statuses[ListName]
    let list = this.StatusIntList.indexOf(ind);
    this.StatusIntList.splice(list, 1);
  }

 StatusIntList:number[]=[];
  selectedColumn( event: MatAutocompleteSelectedEvent, fieldData: FilterObject): void {
    if (fieldData.value.length !== 0) {
      const isPresent = fieldData.value.find((element) => event.option.viewValue === element);

      if (!isPresent) {
        // fieldData.value.push(event.option.viewValue);
        // let s:number=this.Statuses[event.option.viewValue]
        // this.StatusIntList?.push(s);
        this.addValuesToDropdownField(event, fieldData);

      }
    }else{
      // fieldData.value.push(event.option.viewValue);
      // this.StatusIntList=[];
      // let a:number=this.Statuses[event.option.viewValue]
      // this.StatusIntList?.push(a);
      this.StatusIntList=[];
      this.addValuesToDropdownField(event, fieldData);
    }
  }

  private addValuesToDropdownField(event: MatAutocompleteSelectedEvent, fieldData: FilterObject) {
    const indexValue = event.option.value;
    const originalValue = fieldData.dropdown.at(indexValue);
    const valueToBeAdded = originalValue ? originalValue : event.option.viewValue;
    fieldData.value.push(valueToBeAdded);
    let s: any = this.Statuses[valueToBeAdded];
    this.StatusIntList?.push(s);
  }

removeDuplicates(data)
{
 return data.filter((value,index)=>data.indexOf(value)===index)
}
  searchOption(event, item: FilterObject) {
    if (item.dropdownCopy === undefined) {
      item.dropdownCopy = item.dropdown;
    }
    const filterValue = event.target.value.toLowerCase();
        let SearchList = [];
    if (filterValue != null && filterValue != undefined && filterValue !== '') {
      SearchList = item.dropdownCopy.filter((data) =>
        data.toLowerCase().includes(filterValue)
      );
      item.dropdown = SearchList;
    } else {
      item.dropdown = item.dropdownCopy;
    }
    SearchList = [];
    this.showFilter = true;
  }

  refreshSearchOption(event, item: FilterObject) {
        if (item.dropdownCopy !== undefined) {
      item.dropdown = item.dropdownCopy;
    }
    item.value.forEach(element => {
      item.dropdown = item.dropdown.filter(item=>item!==element);
    });
    this.showFilter = true;
  }

  clearAll() {
    console.log(this.filterObject)
    const filterObjectVoList: FilterOrSortingVo[] = [];
    // this.filterObject.length = 0;
    this.filterObject?.forEach((element) => {
      element.value = [];
    // element.dropdown=[];
     element.dropdown= ['Approved','Submitted','Rejected','Drafted', 'Disabled'];
      if (element.radio !== null) {
        element.radio.forEach((element3) => {
          element3.value = null;
        });
      }
    });
    if(this.searchFilterControl.value.trim()){
    this.searchFilter();
    }
    this.showFilter = true;
  // this.emitFilterValue.emit(filterObjectVoList);
  // this.showFilter = false;
  }

  searchFilter() {

    const filterObjectVoList: FilterOrSortingVo[] = [];
    this.filterObject.forEach((element) => {
      const filterObjectVo = new FilterOrSortingVo();
      filterObjectVo.columnName = element.columnName;
      filterObjectVo.condition = element.condition;
      filterObjectVo.filterOrSortingType = 'FILTER';
      filterObjectVo.type = null;

      if(element.type==='dates'){
        this.minDate =  this.datePipe.transform(element.value[0], this.dateFormat, this.timeZone, this.locale);
        filterObjectVo.value = this.minDate;
        // filterObjectVo.value2 = element.value[1];
        // this.minDate=new Date(element.value[0]);
        // return;
      }

     else if (element.type !== 'fields') {

      if (element.type !== 'radio') {
        if (element.type !== 'chips') {
          if (element.value !== null) {
            filterObjectVo.value = element.value[0];
          }
          if (element.value[1] !== null || element.value[1] !== undefined) {
            filterObjectVo.value2 = element.value[1];
          }
          filterObjectVo.columnName==="repoVersion" ? filterObjectVo.type = "Double" : filterObjectVo.type = "Integer";
        } else {
          // filterObjectVo.valueList=[];
          element.value.forEach((element1) => {
          this.Statuses[element1]
            filterObjectVo.valueList.push(element1);
            filterObjectVo.intgerValueList=this.StatusIntList;
          });
          filterObjectVo.columnName==="repoVersion" ? filterObjectVo.type = "Double" : filterObjectVo.type = "Integer";
        }
      } else {
        if (element.radio[1].value !== null) {
          const value = !element.radio[1].value;
          filterObjectVo.value = value.toString();
        }
        filterObjectVo.type = element.dataType;
      }
    }
    // else{
    //   if ((element.value[0] !== '' || element.value[0] !== undefined) && (element.value[1] === '' || element.value[1] === undefined)) {
    //     filterObjectVo.condition = "Gt"
    //     filterObjectVo.value = element.value[0];
    //   }
    //   else if ((element.value[1] !== '' || element.value[1] !== undefined) && (element.value[0] === '' || element.value[0] === undefined)) {
    //     filterObjectVo.condition = "Lt"
    //     filterObjectVo.value = element.value[1];
    //   }
    //   else if ((element.value[1] !== '' || element.value[1] !== undefined) && (element.value[0] !== '' || element.value[0] !== undefined)) {
    //     filterObjectVo.condition = "BW"
    //     filterObjectVo.value = element.value[0];
    //     filterObjectVo.value2 = element.value[1];
    //   }
    //   filterObjectVo.type = element.dataType;
    // }
      if (filterObjectVo.value === undefined || filterObjectVo.value === '') {
        filterObjectVo.value = null;
      }
      if (filterObjectVo.value2 === undefined || filterObjectVo.value === ''  ) {
        filterObjectVo.value2 = null;
      }
      filterObjectVoList.push(filterObjectVo);
    });
    this.emitFilterValue.emit(filterObjectVoList);
    this.searchShareSub.filterObject.next(filterObjectVoList);
    this.openFilter()
  }

  closePopUp(){
    this.showFilter = false;
  }

  openFilter() {
    this.showFilter = !this.showFilter;
    this.searchInputIsDisabled =  this.showFilter;
    if(this.showSearchValue){
    this.removeSearchValue();
  }else{
    this.searchInputIsDisabled = false;
  }
  }

  checkedRadio(name: string, item: FilterObject) {
    if (name === 'Active') {
      item.radio[0].value = true;
      item.radio[1].value = false;
    } else {
      item.radio[0].value = false;
      item.radio[1].value = true;
    }
  }

  routeToSearch(){
    this.filterObject = []
    this.clearAll
    this.RepoClose=false;
    const queryParams={filterClose:this.RepoClose}
    this.route.navigate(['search'],{queryParams});
  }
  searchValue(event){
      this.emitSearchValue.emit(event.trim());
}

Search(event) {
  
  if(this.searchFilterControl.value){
    this.searchData = this.searchFilterControl.value.trim();
    if(!this.isRepositorySearch){
      this.closeIconEnable = true;
    }
  }else{
    this.searchData = this.searchFilterControl.value;
    this.closeIconEnable = false;
  }
  this.emitSearchValue.emit(this.searchData);
}


removeSearchValue() {
  this.searchFilterControl.setValue("");
  this.searchData =  this.searchFilterControl.value.trim();
  this.closeIconEnable = false;
  this.emitSearchValue.emit(this.searchData);
}


onOutSideClick() {
  this.searchInputIsDisabled =  false;
  if(this.showFilter){
   this.showFilter = false;
  }
}


}
//export interface Filtervo
//{
//columnName:string,
//condition:string,
//filterOrSortingType:string,
//intgerValueList:[],
//isAscending:false,
//type:any,
//value:any,
//value2:any,
//valueList:anyS
//}
export enum Status {
  Submitted=1,
  Drafted=2,
  Approved=3,
  Rejected=4,
  Disabled=5
}
