export const environment = {
    production: false,
    API_BASE_URL : 'http://localhost:6060'
};
