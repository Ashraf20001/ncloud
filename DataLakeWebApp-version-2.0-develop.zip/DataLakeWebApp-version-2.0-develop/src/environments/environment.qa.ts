export const environment = {
    production: false,
    API_BASE_URL : 'http://10.10.11.172:6060',
    WEB_SOCKET_URL:'http://10.10.10.247:6064/data-lake/ws',
    NOTIFY_SOCKET_URL:'http://10.10.14.19:8601/notify/ws'
};
