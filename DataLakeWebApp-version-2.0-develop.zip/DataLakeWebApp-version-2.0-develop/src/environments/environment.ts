export const environment = {
  production: false,
  // API_BASE_URL : 'http://10.10.10.247:6060'
  API_BASE_URL : 'http://localhost:6060',
  WEB_SOCKET_URL:'http://localhost:6064/data-lake/ws',
  NOTIFY_SOCKET_URL:'http://localhost:8601/notify/ws'
};
