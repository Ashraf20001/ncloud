export const environment = {
  production: true,
  API_BASE_URL : 'http://164.52.217.22:6063',
  WEB_SOCKET_URL:'http://164.52.201.177:6064/data-lake/ws',
  NOTIFY_SOCKET_URL:'http://164.52.217.22:8601/notify/ws'
};
