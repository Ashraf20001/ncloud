package com.Notification.Config;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.Notification.Model.EnvironmentProperties;
import com.mchange.v2.c3p0.ComboPooledDataSource;

/**
 * The Class dataSourceConfig.
 */
@Configuration
@EnableTransactionManagement
public class dataSourceConfig {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(dataSourceConfig.class);

	/** The environmentproperties. */
	@Autowired
	private EnvironmentProperties environmentproperties;

	/** The master data source. */
	private final ComboPooledDataSource masterDataSource = new ComboPooledDataSource();

	/**
	 * Gets the data source.
	 *
	 * @return the data source
	 */
	@Autowired
	@Bean(name = "masterDataSource")
	@Primary
	public DataSource getDataSource() {
		try {
			masterDataSource.setDriverClass(environmentproperties.getMysqlDriver());
			masterDataSource.setJdbcUrl(environmentproperties.getJdbcUrl());
			masterDataSource.setPassword(environmentproperties.getMySqlPassword());
			masterDataSource.setUser(environmentproperties.getMysqlUserName());
			logger.info("MySql username : " + environmentproperties.getMysqlUserName());
			logger.info("MySql password : " + environmentproperties.getMySqlPassword());
			String idleConnectionTestPeriod = environmentproperties.getMysqlIdleConnectionTestPeriod();
			if(idleConnectionTestPeriod != null && !idleConnectionTestPeriod.isBlank()) {
				masterDataSource.setIdleConnectionTestPeriod(Integer.parseInt(idleConnectionTestPeriod)); 
			}
			String maxIdleTimeout = environmentproperties.getMysqlMaxIdleTimeout();
			if(maxIdleTimeout != null && !maxIdleTimeout.isBlank()) {
				masterDataSource.setMaxIdleTime(Integer.parseInt(maxIdleTimeout));
			}
			String maxIdleTimeExcessConnections = environmentproperties.getMysqlMaxIdleTimeExcessConnections();
			if(maxIdleTimeExcessConnections != null && !maxIdleTimeExcessConnections.isBlank()) {
				masterDataSource.setMaxIdleTimeExcessConnections(Integer.parseInt(maxIdleTimeExcessConnections));
			}
			String connectionCheckout = environmentproperties.getMysqlConnectionCheckout();
			if(connectionCheckout != null && !connectionCheckout.isBlank()) {
				masterDataSource.setTestConnectionOnCheckout(Boolean.parseBoolean(connectionCheckout));
			}
			String minPoolSize = environmentproperties.getMysqlMinPoolSize();
			if(minPoolSize != null && !minPoolSize.isBlank()) {
				masterDataSource.setMinPoolSize(Integer.parseInt(minPoolSize));
			}
			String maxPoolSize = environmentproperties.getMysqlMaxPoolSize();
			if(maxPoolSize != null && !maxPoolSize.isBlank()) {
				masterDataSource.setMaxPoolSize(Integer.parseInt(maxPoolSize));
			}
			masterDataSource.setPreferredTestQuery(environmentproperties.getMysqlPreferedQuery());
			
		} catch (Exception e) {
			logger.error("Can't Set Data Source" + e);
		}
		return masterDataSource;
	}

}
