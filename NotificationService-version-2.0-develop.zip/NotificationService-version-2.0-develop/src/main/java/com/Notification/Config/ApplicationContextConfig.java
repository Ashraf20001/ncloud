package com.Notification.Config;

import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBuilder;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * The Class ApplicationContextConfig.
 */
@Configuration
@ComponentScan("com.Notification")
@EnableTransactionManagement
@EnableAutoConfiguration(exclude = HibernateJpaAutoConfiguration.class)
@EnableAsync
public class ApplicationContextConfig implements WebMvcConfigurer{

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ApplicationContextConfig.class);

	/**
	 * Property config in dev.
	 *
	 * @return the property sources placeholder configurer
	 */
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	/**
	 * Gets the hibernate session factory.
	 *
	 * @param routingDataSource the routing data source
	 * @param hibernateProperties the hibernate properties
	 * @return the hibernate session factory
	 */
	@Autowired
	@Bean(name = "sessionFactory")
	public SessionFactory getHibernateSessionFactory(RoutingDataSource routingDataSource,
			HibernateProperties hibernateProperties) {

		LocalSessionFactoryBuilder localSessionFactoryBuilder = new LocalSessionFactoryBuilder(routingDataSource);
		localSessionFactoryBuilder.addProperties(hibernateProperties.getHibernateProperties());
		localSessionFactoryBuilder.scanPackages("com.Notification.entity");
		logger.info("Session Factory Created");
		return localSessionFactoryBuilder.buildSessionFactory();

	}
	

	/**
	 * Gets the hibernate transaction manager.
	 *
	 * @param sessionFactory the session factory
	 * @return the hibernate transaction manager
	 */
	@Autowired
	@Bean(name = "transactionmanager")
	public HibernateTransactionManager getHibernateTransactionManager(SessionFactory sessionFactory) {
		HibernateTransactionManager transactionmanager = new HibernateTransactionManager(sessionFactory);
		logger.info("TransactionManager Created");
		return transactionmanager;

	}
	
	/**
	 * Gets the hibernate template.
	 *
	 * @param sessionFactory the session factory
	 * @return the hibernate template
	 */
	@Autowired
	@Bean(name = "hibernatetemplate")
	public HibernateTemplate getHibernateTemplate(SessionFactory sessionFactory) {
		HibernateTemplate hibernatetemplate = new HibernateTemplate(sessionFactory);
		logger.info("hibernateTemplate Created");
		return hibernatetemplate;

	}

	

}
