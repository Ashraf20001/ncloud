package com.Notification.Config;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

/**
 * The Class RoutingDataSource.
 */
@Configuration
@Qualifier("datasource")
public class RoutingDataSource extends AbstractRoutingDataSource {

	/** The master data source. */
	@Autowired
	@Qualifier("masterDataSource")
	private DataSource masterDataSource;

	/**
	 * Sets the data source.
	 */
	@PostConstruct
	public void setDataSource() {

		Map<Object, Object> targetDataSource = new HashMap<>();
		targetDataSource.put("Master", masterDataSource);
		setTargetDataSources(targetDataSource);
		setDefaultTargetDataSource(masterDataSource);

	}

	/**
	 * Determine current lookup key.
	 *
	 * @return the object
	 */
	@Override
	protected Object determineCurrentLookupKey() {
		// TODO Auto-generated method stub
		return null;
	}

}
