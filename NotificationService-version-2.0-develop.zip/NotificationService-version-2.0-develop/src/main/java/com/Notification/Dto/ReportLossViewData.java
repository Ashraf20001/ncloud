package com.Notification.Dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class ReportLossViewData.
 */
@Data
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ReportLossViewData {
	
	/** The claim id. */
	//claimDetails
    private Integer claimId;
    
    /** The state. */
    private String state;
    
    /** The claim sequence id. */
    private String claimSequenceId;


    /** The in insured info id. */
    //InsurerInfo
    private int inInsuredInfoId;
    
    /** The in vehicle id. */
    private int inVehicleId;
    
    /** The in insured name. */
    private String inInsuredName;
    
    /** The in insurer name. */
    private String inInsurerName;
    
    /** The in registration no. */
    private String inRegistrationNo;
    
    /** The in make. */
    private String inMake;
    
    /** The in model. */
    private String inModel;
    
    /** The in purchase date. */
    private LocalDateTime inPurchaseDate;
    
    /** The in sum insured. */
    private Double inSumInsured;

    /** The third party info id. */
    //ThirdPartyInfo
    private int thirdPartyInfoId;
    
    /** The tp vehicle id. */
    private int tpVehicleId;
    
    /** The tp name. */
    private String tpName;
    
    /** The tp policy number. */
    private String tpPolicyNumber;
    
    /** The tp claim no. */
    private String tpClaimNo;
    
    /** The tp registration no. */
    private String tpRegistrationNo;
    
    /** The tp registration type. */
    private String tpRegistrationType;
    
    /** The tp make. */
    private String tpMake;
    
    /** The tp model. */
    private String tpModel;

    /** The loss details id. */
    //loss details
    private int lossDetailsId;
    
    /** The ld date of loss. */
    private LocalDateTime ldDateOfLoss;
    
    /** The ld claim number. */
    private String ldClaimNumber;
    
    /** The ld reported date. */
    private LocalDateTime ldReportedDate;
    
    /** The ld policy number. */
    private String ldPolicyNumber;
    
    /** The ld reserve amount. */
    private Double ldReserveAmount;
    
    /** The ld police report number. */
    private String ldPoliceReportNumber;
    
    /** The ld is total loss. */
    private boolean ldIsTotalLoss;

  /** The estimated total loss amount. */
  //total loss
    private String estimatedTotalLossAmount;
    
    /** The police report id. */
    //police report
    private int policeReportId;
    
    /** The pr document upload. */
    private String prDocumentUpload	;

    /** The garage id. */
    //garageInfo
    private int garageId;
    
    /** The garage name. */
    private String garageName;
    
    /** The garage location. */
    private String garageLocation;
    
    /** The garage contact details. */
    private String garageContactDetails;
    
    /** The garage type. */
    private String garageType;
    
    /** The garage invoice name. */
    private String garageInvoiceName;

    /** The survey details id. */
    //survey Details
    private int surveyDetailsId;
    
    /** The sd survey name. */
    private String sdSurveyName;
    
    /** The sd survey allocation date. */
    private LocalDateTime sdSurveyAllocationDate;
    
    /** The sd survey due date. */
    private LocalDateTime sdSurveyDueDate;
    
    /** The sd survey report name. */
    private String sdSurveyReportName;

/** The survey report id. */
//  survey report
    private int surveyReportId;
    
    /** The sr total loss. */
    private boolean srTotalLoss;
    
    /** The sr spare parts. */
    private Double srSpareParts;
    
    /** The sr labour cost. */
    private Double srLabourCost	;
    
    /** The sr survey amount. */
    private Double srSurveyAmount;
    
    /** The sr survey report upload. */
    private String srSurveyReportUpload	;

/** The recovery details id. */
//    recovery details
    private int recoveryDetailsId;
    
    /** The rd police report fee. */
    private Double rdPoliceReportFee;
    
    /** The rd towing charge. */
    private Double rdTowingCharge;
    
    /** The rd inspection fee. */
    private Double rdInspectionFee;
    
    /** The rd other expenses. */
    private Double rdOtherExpenses;
    
    /** The rd cash settlement. */
    private Double rdCashSettlement;
    
    /** The rd spare parts. */
    private Double rdSpareParts;
    
    /** The rd labour cost. */
    private Double rdLabourCost;
    
    /** The rd TP survey amount. */
    private Double rdTPSurveyAmount;
    
    /** The rd claim amount. */
    private Double rdClaimAmount;

/** The reserve review id. */
//    reserve review
    private int reserveReviewId;
    
    /** The rr reserve amount. */
    private Double rrReserveAmount;
    
    /** The rr TP survey amount. */
    private Double rrTPSurveyAmount;
    
    /** The rr total claim amount. */
    private Double rrTotalClaimAmount;

/** The garage invoice id. */
//    garage invoice
    private int garageInvoiceId;
    
    /** The gi document. */
    private String giDocument;
    
    /** The gi garage invoice no. */
    private String giGarageInvoiceNo;

/** The debit note id. */
//    debit note number
    private int debitNoteId;
    
    /** The dn debit note number. */
    private String dnDebitNoteNumber;
    
    /** The dn debit note document. */
    private String dnDebitNoteDocument;

    /** The credit note id. */
    //    credit note number
    private int creditNoteId;
    
    /** The cn credit note number. */
    private String cnCreditNoteNumber;
    
    /** The cn credit note document. */
    private String cnCreditNoteDocument;
    
    /** The stage name. */
    //stage and section
    private String stageName;
    
    /** The section name. */
    private String sectionName;
    

}
