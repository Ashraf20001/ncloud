package com.Notification.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class UserProfleDto.
 */
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UserProfleDto {
	
	/** The user name. */
	private String userName;
	
	/** The user id. */
	private Integer userId;
	
	/** The identity. */
	private String identity;

}
