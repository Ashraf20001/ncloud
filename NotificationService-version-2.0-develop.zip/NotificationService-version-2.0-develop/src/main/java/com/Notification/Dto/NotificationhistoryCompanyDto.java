package com.Notification.Dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class NotificationhistoryCompanyDto.
 */
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class NotificationhistoryCompanyDto {
	
	/** The id. */
	private int id;	
	  
	
	/** The template. */
	private String template;
	
	
	/** The is read. */
	private boolean isRead;
	
	
	/** The claim id. */
	private Integer claimId;
	
	
	/** The status. */
	private String status;
	
	
	/** The last acted. */
	private int lastActed;
	
	
	/** The to notify. */
	private int toNotify;
	
	
	/** The is deleted. */
	private boolean isDeleted;

	
	/** The identity. */
	private String identity;

	
	/** The created date. */
	private Date createdDate;

	
	/** The created by. */
	private int createdBy;
	
	
	/** The modified date. */
	private Date modifiedDate;

	
	/** The modified by. */
	private int modifiedBy;
	

}
