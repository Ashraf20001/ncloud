package com.Notification.Dto;

import lombok.Data;

/**
 * The Class RepositoryScheduleDto.
 */
@Data
public class RepositoryScheduleDto {

	/** The repository name. */
	private String repositoryName;
	
	/** The notification message. */
	private String notificationMessage;

	/** The is active scheduler. */
	private Boolean isActiveScheduler;

	/** The is active repository. */
	private Boolean isActiveRepository;
}
