package com.Notification.Controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Notification.Dto.NotificationCountDto;
import com.Notification.Dto.NotificationDetailsDto;
import com.Notification.Dto.NotificationDto;
import com.Notification.Dto.NotificationHistoryDto;
import com.Notification.Service.NotificationService;
import com.recoveryportal.exception.core.ApplicationException;

/**
 * The Class NotificationController.
 */
@RestController
public class NotificationController {

	/** The notification service. */
	@Autowired
	private NotificationService notificationService;

	/**
	 * Update notification to mark as read.
	 *
	 * @param notificationDetailsDto the notification details dto
	 */
	@PostMapping("/updateNotification")
	public void updateNotification(@RequestBody NotificationDetailsDto notificationDetailsDto) {
		notificationService.updateNotification(notificationDetailsDto);
	}

	/**
	 * Save notification.
	 *
	 * @param notificationDetailsDto the notification details dto
	 * @return the string
	 * @throws ApplicationException the application exception
	 */
	@PostMapping("/saveNotification")
	public String SaveNotification(@RequestBody NotificationDetailsDto notificationDetailsDto)
			throws ApplicationException {
		return notificationService.saveNotification(notificationDetailsDto);
	}
	
	/**
	 * Approval notification build template.
	 *
	 * @param notificationDetailsDto the notification details dto
	 * @throws ApplicationException the application exception
	 */
	@PostMapping("/approval-limit-Notification")
	public void approvalLimitNotification(@RequestBody NotificationDetailsDto notificationDetailsDto)
			throws ApplicationException {
	notificationService.approvalLimiNotification(notificationDetailsDto);
	}
	
	

	/**
	 * Send notification.
	 *
	 * @param NotificationDto the notification dto
	 * @throws ApplicationException the application exception
	 */
	@PostMapping("/sendNotification")
	public void sendNotification(@RequestBody NotificationDto NotificationDto) throws ApplicationException {
		notificationService.sendNotification(NotificationDto);

	}
	
	/**
	 * Update notification by approvalId to mark as read.
	 *
	 * @param approvalId the approval id
	 * @throws ApplicationException the application exception
	 */
	@PostMapping("/update-approval-limit-Notification")
	public void sendNotification(@RequestParam("approvalId") Integer approvalId) throws ApplicationException {
		notificationService.updateNotification(approvalId);

	}
	

	/**
	 * Gets the notification history.
	 *
	 * @param NotificationDto the notification dto
	 * @return the notification history
	 */
	@PostMapping("/getNotificationHistory")
 	public List<NotificationHistoryDto> getNotificationHistory(@RequestBody NotificationDto NotificationDto) {
		return notificationService.getNotificationHistory(NotificationDto);
 		
 	}
	
	/**
	 * Gets the notification history count.
	 *
	 * @param NotificationDto the notification dto
	 * @return the notification history count
	 */
	@PostMapping("/getNotificationHistoryCount")
 	public NotificationCountDto getNotificationHistoryCount(@RequestBody NotificationDto NotificationDto) {
		return notificationService.getNotificationHistoryCount(NotificationDto);
 		
 	}
	
	/**
	 * Build wallet notification template to companies.
	 *
	 * @param notificationDetailsDto the notification details dto
	 * @return the string
	 * @throws ApplicationException the application exception
	 */
	@PostMapping("/wallet-notification")
 	public String NotificationForWallet(@RequestBody NotificationDetailsDto notificationDetailsDto) throws ApplicationException {
		return notificationService.saveNotificationForWallet(notificationDetailsDto);
 		
 	}
	
	/**
	 * Send notification for data lake while Repository Creation, Approve and Reject.... .
	 *
	 * @param notificationDto the notification dto
	 * @param uploadFlow the upload flow
	 */
	@PostMapping("/data-lake/sendNotification")
	public void sendNotificationForDataLake(@RequestBody NotificationDto notificationDto, @RequestParam("uploadFlow") boolean uploadFlow) {
		Map<String, List<String>> companyNameList = notificationService.sendRepositoryNotification(notificationDto,uploadFlow);
		notificationService.triggerReminderEmail(companyNameList);
	}
	
	/**
	 * Update notification {Mark As Read} by repository identity and tonotify.
	 *
	 * @param userId the user id
	 * @param companyName the company name
	 * @param repositoryId the repository id
	 */
	@PostMapping("/data-lake/mark-notification-as-read")
	public void updateNotificationbyRepositoryIdentityandTonotify(@RequestParam Integer userId,String companyName,Integer repositoryId ) {
		notificationService.updateNotificationbyRepositoryIdentityandTonotify(userId,companyName,repositoryId);
	}
	
	/**
	 * Generate wallet payment reminder for all unpaid company.
	 *
	 * @param notificationDto the notification dto
	 */
	@PostMapping("/wallet-payment-reminder")
	public void generateWalletPaymentReminder(@RequestBody NotificationDto notificationDto) {
		notificationService.generatePaymentReminderNotification(notificationDto);
	}
}
