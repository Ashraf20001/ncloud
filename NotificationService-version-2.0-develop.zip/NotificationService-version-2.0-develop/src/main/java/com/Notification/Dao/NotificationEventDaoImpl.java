package com.Notification.Dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.Notification.common.filetrs.BaseDao;
import com.Notification.entity.NotificationEvent;

import com.recoveryportal.constants.core.TableConstants;

/**
 * The Class NotificationEventDaoImpl.
 */
@Transactional
@Repository
public class NotificationEventDaoImpl extends BaseDao implements NotificationEventDao {
	
	/**
	 * Gets the notification event by event name.
	 *
	 * @param state the state
	 * @return the notification event by event name
	 */
	@Override
	public NotificationEvent getNotificationEventByEventName(String state) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<NotificationEvent> criteria = builder.createQuery(NotificationEvent.class);
		Root<NotificationEvent> root = criteria.from(NotificationEvent.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.EVENT_NAME), state)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
		return (NotificationEvent) getResultList(createQuery(builder, criteria, root, predicates)).stream()
				.findFirst().orElse(null);
	}

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
		// TODO Auto-generated method stub
		
	}
}
