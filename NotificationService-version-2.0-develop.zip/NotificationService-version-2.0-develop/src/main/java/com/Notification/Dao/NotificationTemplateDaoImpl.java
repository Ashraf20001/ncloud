package com.Notification.Dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.Notification.common.filetrs.BaseDao;
import com.Notification.entity.NotificationEvent;
import com.Notification.entity.NotificationTemplate;
import com.recoveryportal.constants.core.TableConstants;

/**
 * The Class NotificationTemplateDaoImpl.
 */
@Transactional
@Repository
public class NotificationTemplateDaoImpl extends BaseDao implements NotificationTemplateDao {



/**
 * Register data filters.
 */
@Override
public void registerDataFilters() {
	// TODO Auto-generated method stub
	
}

/**
 * Gets the template by event id.
 *
 * @param eventId the event id
 * @param currentState the current state
 * @return the template by event id
 */
@Override
public NotificationTemplate getTemplateByEventId(NotificationEvent eventId, String currentState) {
	CriteriaBuilder builder = getCriteriaBuilder();
	CriteriaQuery<NotificationTemplate> criteria = builder.createQuery(NotificationTemplate.class);
	Root<NotificationTemplate> root = criteria.from(NotificationTemplate.class);
	criteria.select(root);
	List<Predicate> predicates = new ArrayList<>();
	predicates.add(builder.and(builder.equal(root.get(TableConstants.NOTIFICATION_EVENT), eventId)));
	predicates.add(builder.and(builder.equal(builder.lower(root.get(TableConstants.STATE)), currentState.toLowerCase())));
	predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
	return (NotificationTemplate) getResultList(createQuery(builder, criteria, root, predicates)).stream()
			.findFirst().orElse(null);
	
}

/**
 * Gets the notification template by event.
 *
 * @param event the event
 * @return the notification template by event
 */
@Override
public NotificationTemplate getNotificationTemplateByEvent(NotificationEvent event) {
	CriteriaBuilder builder = getCriteriaBuilder();
	CriteriaQuery<NotificationTemplate> criteria = builder.createQuery(NotificationTemplate.class);
	Root<NotificationTemplate> root = criteria.from(NotificationTemplate.class);
	criteria.select(root);
	List<Predicate> predicates = new ArrayList<>();
	predicates.add(builder.and(builder.equal(root.get(TableConstants.NOTIFICATION_EVENT), event)));
	predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), Boolean.FALSE)));
	return (NotificationTemplate) getResultList(createQuery(builder, criteria, root, predicates)).stream()
			.findFirst().orElse(null);
}
}
