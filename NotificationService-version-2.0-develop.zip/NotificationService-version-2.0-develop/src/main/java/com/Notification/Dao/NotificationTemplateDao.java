package com.Notification.Dao;

import com.Notification.entity.NotificationEvent;
import com.Notification.entity.NotificationTemplate;

/**
 * The Interface NotificationTemplateDao.
 */
public interface NotificationTemplateDao {

	/**
	 * Gets the template by event id.
	 *
	 * @param eventId the event id
	 * @param currentState the current state
	 * @return the template by event id
	 */
	NotificationTemplate getTemplateByEventId(NotificationEvent eventId, String currentState);

	/**
	 * Gets the notification template by event.
	 *
	 * @param event the event
	 * @return the notification template by event
	 */
	NotificationTemplate getNotificationTemplateByEvent(NotificationEvent event);
	
	
}
