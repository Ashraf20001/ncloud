package com.Notification.Dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.Notification.Model.NotificationTableConstants;
import com.Notification.common.filetrs.BaseDao;
import com.Notification.entity.NotificationHistory;
import com.Notification.entity.NotificationHistoryUserMap;
import com.recoveryportal.constants.core.ApplicationConstants;
import com.recoveryportal.constants.core.TableConstants;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.utils.core.ApplicationUtils;

/**
 * The Class NotificationHistoryDaoImpl.
 */
@Repository
@Transactional
public class NotificationHistoryDaoImpl extends BaseDao implements NotificationHistoryDao {
	
	
	
	/**
	 * Save notification.
	 *
	 * @param notificationHistory the notification history
	 * @return the notification history
	 * @throws ApplicationException the application exception
	 */
	@Override
	public NotificationHistory saveNotification(NotificationHistory notificationHistory) throws ApplicationException {
		 save(notificationHistory, TableConstants.NOTIFICATION_HISTORY);
	        return notificationHistory;
	}

	
	/**
	 * Gets the all notifications.
	 *
	 * @param companyName the company name
	 * @param platformId the platform id
	 * @return the all notifications
	 */
	@Override
	public List<NotificationHistory> getAllNotifications(String companyName, Integer platformId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<NotificationHistory> criteria = builder.createQuery(NotificationHistory.class);
		Root<NotificationHistory> root = criteria.from(NotificationHistory.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.TO_NOTIFY), companyName)));
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.IS_READ))));
		if(ApplicationUtils.isValidId(platformId)) {
			predicates.add(builder.and(builder.equal(root.get(TableConstants.PLATFORM_ID), platformId))); // Data Lake
		}else {
			predicates.add(builder.and(builder.isNull(root.get(TableConstants.PLATFORM_ID))));
		}
		criteria.orderBy(builder.desc(root.get(TableConstants.CREATED_DATE)));
		return (List<NotificationHistory>) getResultList(createQuery(builder, criteria, root, predicates));
	}

	
	/**
	 * Gets the claim history for claim.
	 *
	 * @param claimId the claim id
	 * @return the claim history for claim
	 */
	@Override
	public List<NotificationHistory> getClaimHistoryForClaim(Integer claimId) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<NotificationHistory> criteria = builder.createQuery(NotificationHistory.class);
		Root<NotificationHistory> root = criteria.from(NotificationHistory.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.CLAIM_DETAILS).get(TableConstants.CLAIM_ID), claimId)));
		criteria.orderBy(builder.asc(root.get(TableConstants.CREATED_DATE)));
		return (List<NotificationHistory>) getResultList(createQuery(builder, criteria, root, predicates));
	}
	
	/**
	 * Gets the claim history for id.
	 *
	 * @param id the id
	 * @return the claim history for id
	 */
	@Override
	public NotificationHistory getClaimHistoryForId(Integer id) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<NotificationHistory> criteria = builder.createQuery(NotificationHistory.class);
		Root<NotificationHistory> root = criteria.from(NotificationHistory.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.NOTIFICATION_HISTORY_ID), id)));
		return (NotificationHistory) getResultList(createQuery(builder, criteria, root, predicates)).stream()
				.findFirst().orElse(null);
	}
	
	 /**
 	 * Update notificationby repository identityand tonotify.
 	 *
 	 * @param userId the user id
 	 * @param companyName the company name
 	 * @param repositoryId the repository id
 	 */
 	@Override
		public void updateNotificationbyRepositoryIdentityandTonotify(Integer userId, String companyName, int repositoryId) {
			CriteriaBuilder builder = getCriteriaBuilder();
			CriteriaUpdate<NotificationHistory> criteria = builder.createCriteriaUpdate(NotificationHistory.class);
			Root<NotificationHistory> root = criteria.from(NotificationHistory.class);
			criteria.set(root.get(TableConstants.IS_READ), true);
			criteria.set(root.get(TableConstants.MODIFIED_BY), userId);
			criteria.set(root.get(TableConstants.MODIFIED_DATE), new Date());
			Predicate companyPredicate = builder.equal(root.get(TableConstants.TO_NOTIFY), companyName);
			Predicate repositoryPredicate = builder.equal(root.get(TableConstants.CLAIM_ID), repositoryId);
			Predicate finalPredicate = builder.and(companyPredicate, repositoryPredicate);
			criteria.where(finalPredicate);
			createQueryupdate(criteria).executeUpdate();
		}
	 
	/**
	 * Gets the un read notification.
	 *
	 * @param claimId the claim id
	 * @param toNotifyCompany the to notify company
	 * @param repositoryIdentity the repository identity
	 * @return the un read notification
	 */
	@Override
	public List<NotificationHistory> getUnReadNotification(Integer claimId, String toNotifyCompany,String repositoryIdentity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<NotificationHistory> criteria = builder.createQuery(NotificationHistory.class);
		Root<NotificationHistory> root = criteria.from(NotificationHistory.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
		if(claimId != null) {
			predicates.add(builder.and(builder.equal(root.get(TableConstants.CLAIM_ID), claimId)));
		}
		if(repositoryIdentity != null) {
			predicates.add(builder.and(builder.equal(root.get(NotificationTableConstants.REPOSITORY_IDENTITY), repositoryIdentity)));
		}
		predicates.add(builder.and(builder.equal(root.get(TableConstants.TO_NOTIFY), toNotifyCompany)));
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.IS_READ))));
		return (List<NotificationHistory>) getResultList(createQuery(builder, criteria, root, predicates));
	}
	
	/**
	 * Update notification history.
	 *
	 * @param notificationHistory the notification history
	 */
	@Override
	public void updateNotificationHistory(NotificationHistory notificationHistory) {
		update(notificationHistory);
	}

	/**
	 * Check for exisiting remainder.
	 *
	 * @param claimId the claim id
	 * @param toNotify the to notify
	 * @return the notification history
	 */
	@Override
	public NotificationHistory checkForExisitingRemainder(Integer claimId, String toNotify) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<NotificationHistory> criteria = builder.createQuery(NotificationHistory.class);
		Root<NotificationHistory> root = criteria.from(NotificationHistory.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder
				.and(builder.equal(root.get(TableConstants.CLAIM_DETAILS).get(TableConstants.CLAIM_ID), claimId)));
		predicates.add(builder
				.and(builder.equal(root.get(TableConstants.STATUS), ApplicationConstants.NOTIFICATION_RECIEVED)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.LAST_ACTED), ApplicationConstants.SCHEDULER)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.TO_NOTIFY), toNotify)));
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.IS_READ))));
		return (NotificationHistory) getResultList(createQuery(builder, criteria, root, predicates)).stream()
				.findFirst().orElse(null);
	}
	
	/**
	 * Gets the un read notification history list by repository id.
	 *
	 * @param repositoryId the repository id
	 * @return the un read notification history list by repository id
	 * @throws ApplicationException the application exception
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<NotificationHistory> getUnReadNotificationHistoryListByRepositoryId(Integer repositoryId) throws ApplicationException {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<NotificationHistory> criteria = builder.createQuery(NotificationHistory.class);
		Root<NotificationHistory> root = criteria.from(NotificationHistory.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.ISDELETED))));
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.IS_READ))));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.CLAIM_ID), repositoryId)));
		return (List<NotificationHistory>) getResultList(createQuery(builder, criteria, root, predicates));
	}
	
	/**
	 * GET EXSISTING NOTIFICATION-HISTORY BY STATUS
	 */
	@SuppressWarnings("unchecked")
	public List<NotificationHistory> getNotificationHistoryByStatus(Integer claimId,String status,String toNotifyCompany) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<NotificationHistory> criteria = builder.createQuery(NotificationHistory.class);
		Root<NotificationHistory> root = criteria.from(NotificationHistory.class);
		criteria.select(root);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.ISDELETED), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.CLAIM_ID), claimId)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.STATUS), status)));
		criteria.orderBy(builder.asc(root.get(TableConstants.CREATED_DATE)));
		return (List<NotificationHistory>) getResultList(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Gets the report loss notification by user identity.
	 *
	 * @param userIdentity the user identity
	 * @return the report loss notification by user identity
	 */
	@Override
	public List<NotificationHistory> getReportLossNotificationByUserIdentity(String userIdentity) {
		CriteriaBuilder builder = getCriteriaBuilder();
		CriteriaQuery<NotificationHistory> criteria = builder.createQuery(NotificationHistory.class);
		Root<NotificationHistoryUserMap> root = criteria.from(NotificationHistoryUserMap.class);
		criteria.select(root.get(TableConstants.RL_NOTIFICATION_HISTORY));
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(builder.and(builder.equal(root.get(TableConstants.RL_NOTIFICATION_HISTORY).get(TableConstants.ISDELETED), false)));
		// update the below predicate when it is moved to user specific
		predicates.add(builder.and(builder.equal(root.get(TableConstants.RL_NOTIFICATION_HISTORY).get(TableConstants.IS_READ), false)));
		predicates.add(builder.and(builder.equal(root.get(TableConstants.USER_IDENTITY), userIdentity)));
		predicates.add(builder.and(builder.isFalse(root.get(TableConstants.IS_READ))));
		return (List<NotificationHistory>) getResultList(createQuery(builder, criteria, root, predicates));
	}

	/**
	 * Save notification history user map.
	 *
	 * @param notificationHistoryUserMap the notification history user map
	 * @return the notification history user map
	 * @throws ApplicationException the application exception
	 */
	@Override
	public NotificationHistoryUserMap saveNotificationHistoryUserMap(NotificationHistoryUserMap notificationHistoryUserMap) throws ApplicationException {
		save(notificationHistoryUserMap, TableConstants.NOTIFICATION_HISTORY_USER_MAP);
		return notificationHistoryUserMap;
	}

	/**
	 * Register data filters.
	 */
	@Override
	public void registerDataFilters() {
		// TODO Auto-generated method stub
		
	}


}
