package com.Notification.Dao;

import com.Notification.entity.NotificationEvent;

/**
 * The Interface NotificationEventDao.
 */
public interface NotificationEventDao {

	/**
	 * Gets the notification event by event name.
	 *
	 * @param state the state
	 * @return the notification event by event name
	 */
	public NotificationEvent getNotificationEventByEventName(String state);

}
