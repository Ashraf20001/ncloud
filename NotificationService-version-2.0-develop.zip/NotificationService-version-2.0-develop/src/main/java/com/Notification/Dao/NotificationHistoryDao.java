package com.Notification.Dao;

import java.util.List;

import com.Notification.entity.NotificationHistory;
import com.Notification.entity.NotificationHistoryUserMap;
import com.recoveryportal.exception.core.ApplicationException;

/**
 * The Interface NotificationHistoryDao.
 */
public interface NotificationHistoryDao {
	
	/**
	 * Save notification.
	 *
	 * @param notificationHistory the notification history
	 * @return the notification history
	 * @throws ApplicationException the application exception
	 */
	NotificationHistory saveNotification(NotificationHistory notificationHistory) throws ApplicationException;

	/**
	 * Gets the all notifications.
	 *
	 * @param companyName the company name
	 * @param platformId the platform id
	 * @return the all notifications
	 */
	List<NotificationHistory> getAllNotifications(String companyName, Integer platformId);

	/**
	 * Gets the claim history for claim.
	 *
	 * @param claimId the claim id
	 * @return the claim history for claim
	 */
	List<NotificationHistory> getClaimHistoryForClaim(Integer claimId);

	/**
	 * Gets the un read notification.
	 *
	 * @param claimId the claim id
	 * @param toNotifyCompany the to notify company
	 * @param repositoryIdentity the repository identity
	 * @return the un read notification
	 */
	List<NotificationHistory> getUnReadNotification(Integer claimId, String toNotifyCompany, String repositoryIdentity);

	/**
	 * Update notification history.
	 *
	 * @param notificationHistory the notification history
	 */
	void updateNotificationHistory(NotificationHistory notificationHistory);

	/**
	 * Check for exisiting remainder.
	 *
	 * @param claimId the claim id
	 * @param toNotify the to notify
	 * @return the notification history
	 */
	NotificationHistory checkForExisitingRemainder(Integer claimId, String toNotify);

	/**
	 * Gets the claim history for id.
	 *
	 * @param id the id
	 * @return the claim history for id
	 */
	NotificationHistory getClaimHistoryForId(Integer id);
	
	/**
	 * Gets the un read notification history list by repository id.
	 *
	 * @param repositoryId the repository id
	 * @return the un read notification history list by repository id
	 * @throws ApplicationException the application exception
	 */
	List<NotificationHistory> getUnReadNotificationHistoryListByRepositoryId(Integer repositoryId) throws ApplicationException;

	/**
	 * @param userid
	 * @param companyName
	 * @param repositoryId
	 */
	void updateNotificationbyRepositoryIdentityandTonotify(Integer userid, String companyName, int repositoryId);
	
	/**
	 * @param claimId
	 * @param status
	 * @param toNotifyCompany
	 * @return
	 */
	public List<NotificationHistory> getNotificationHistoryByStatus(Integer claimId,String status,String toNotifyCompany);

	/**
	 * Gets the report loss notification by user identity.
	 *
	 * @param userIdentity the user identity
	 * @return the report loss notification by user identity
	 */
	List<NotificationHistory> getReportLossNotificationByUserIdentity(String userIdentity);

	/**
	 * Save notification history user map.
	 *
	 * @param notificationHistoryUserMap the notification history user map
	 * @return the notification history user map
	 * @throws ApplicationException the application exception
	 */
	NotificationHistoryUserMap saveNotificationHistoryUserMap(NotificationHistoryUserMap notificationHistoryUserMap) throws ApplicationException;
}
