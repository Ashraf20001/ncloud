package com.Notification.Provider;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import com.Notification.Dto.NotificationDto;

/**
 * The Class KafkaProvider.
 */
@Component
public class KafkaProvider {
	
	
	/** The kafka template. */
	@Autowired
	KafkaTemplate<String,NotificationDto> kafkaTemplate;

	/** The Constant STOP_SCHEDULER. */
	private static final String STOP_SCHEDULER = "StopSchedular";
	
	/**
	 * Send notification dto.
	 *
	 * @param notificationDto the notification dto
	 */
	public void sendNotificationDto(NotificationDto notificationDto) {
		kafkaTemplate.send( STOP_SCHEDULER,notificationDto);
	}
	
}
