package com.Notification.Model;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class PropertyValueProvider.
 */
@Component
@ConfigurationProperties(prefix = "notification")
@Getter
@Setter
public class PropertyValueProvider {
	
	/** The mysql data source url. */
	private String mysqlDataSourceUrl;
	
	/** The mysql ip. */
	private String mysqlIp;
	
	/** The mysql port. */
	private String mysqlPort;
	
	/** The mysql username. */
	private String mysqlUsername;
	
	/** The mysql password. */
	private String mysqlPassword;
	
	/** The mysql data base. */
	private String mysqlDataBase;
	
	/** The mysql driver. */
	private String mysqlDriver;
	
	/** The recovery poratal uri. */
	private String recoveryPoratalUri;
	
	/** The frontend url. */
	private String frontendUrl;
	
	/** The common service company name list url. */
	private String commonServiceCompanyNameListUrl;
	
	/** The datalake repository schedule details url. */
	private String datalakeRepositoryScheduleDetailsUrl;
	
	/** The datalake repository uploadcompany details url. */
	private String datalakeRepositoryUploadcompanyDetailsUrl;
	
	/** The recoverez wallet upaid company list url. */
	private String recoverezWalletUpaidCompanyListUrl;
	
	/** The recoverez wallet payment reminder template url. */
	private String recoverezWalletPaymentReminderTemplateUrl;
	
	/** The recoverez notification reminder template url. */
	private String recoverezNotificationReminderTemplateUrl;
	
	/** The recoverez reportloss user list for notification url. */
	private String recoverezReportlossUserListForNotificationUrl;
	
	/** The company user mail. */
	private String companyUserMail;
	
	/** The mysql preferred query. */
	private String mysqlPreferredQuery;

	/** The mysql connection checkout. */
	private String mysqlConnectionCheckout;

	/** The mysql min poolsize. */
	private String mysqlMinPoolsize;

	/** The mysql max pool size. */
	private String mysqlMaxPoolSize;

	/** The mysql idle connection testperiod. */
	private String mysqlIdleConnectionTestperiod;

	/** The mysql max idle timeout. */
	private String mysqlMaxIdleTimeout;

	/** The mysql max idle excess connections. */
	private String mysqlMaxIdleExcessConnections;
	
	/** The currency format. */
	private String currencyFormat;
	
	/** The frontend datalake url. */
	private String frontendDatalakeUrl;

}
