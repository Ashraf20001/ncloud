package com.Notification.Model;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * The Enum PlatformEnum.
 */
@Getter
@AllArgsConstructor
public enum PlatformEnum {
	
	/** The recovery ez. */
	RECOVERY_EZ(1, "Recover EZ"),
	/** The digital paper. */
	DIGITAL_PAPER(2, "Digital Paper"),
	/** The data lake. */
	DATA_LAKE(3, "Data Lake");

	/** The platform id. */
	private Integer platformId;
	
	/** The platform name. */
	private String platformName;
	
	/**
	 * @param statusDesc
	 * @return
	 */
	public static Integer getPlatformIdByName(String platformName) {
		for (PlatformEnum enums : PlatformEnum.values()) {
			if (enums.getPlatformName().equals(platformName)) {
				return enums.getPlatformId();
			}
		}
		return null;
	}
	
	/**
	 * Gets the platform name by id.
	 *
	 * @param platformId the platform id
	 * @return the platform name by id
	 */
	public static String getPlatformNameById(Integer platformId) {
		for (PlatformEnum enums : PlatformEnum.values()) {
			if (enums.getPlatformId().equals(platformId)) {
				return enums.getPlatformName();
			}
		}
		return null;
	}
}
