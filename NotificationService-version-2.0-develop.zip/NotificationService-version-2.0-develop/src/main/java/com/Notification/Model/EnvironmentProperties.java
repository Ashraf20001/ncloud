package com.Notification.Model;

import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * The Class EnvironmentProperties.
 */
@Configuration
@RequiredArgsConstructor
public class EnvironmentProperties {
	
	
	/** The configuration properties. */
	private final PropertyValueProvider configurationProperties;
	
	
	/**
	 * Gets the jdbc url.
	 *
	 * @return the jdbc url
	 */
	public String getJdbcUrl() {
				
		String dataSourceUrl = configurationProperties.getMysqlDataSourceUrl();
		dataSourceUrl = dataSourceUrl.replace(PropertyConstants.MY_SQL_IP,configurationProperties.getMysqlIp());
		dataSourceUrl = dataSourceUrl.replace(PropertyConstants.MY_SQL_PORT,configurationProperties.getMysqlPort());
		dataSourceUrl = dataSourceUrl.replace(PropertyConstants.DB_NAME,configurationProperties.getMysqlDataBase());
		return dataSourceUrl;
	}
	
	
	/**
	 * Gets the my sql password.
	 *
	 * @return the my sql password
	 */
	public String getMySqlPassword() {
		return configurationProperties.getMysqlPassword();
	}
	
	
	/**
	 * Gets the mysql user name.
	 *
	 * @return the mysql user name
	 */
	public String getMysqlUserName() {
		return configurationProperties.getMysqlUsername();
	}
	
	/**
	 * Gets the mysql driver.
	 *
	 * @return the mysql driver
	 */
	public String getMysqlDriver() {
		return configurationProperties.getMysqlDriver();
	}
	
	/**
	 * Gets the recovery portal uri.
	 *
	 * @return the recovery portal uri
	 */
	public String getRecoveryPortalUri() {
		return configurationProperties.getRecoveryPoratalUri();
	}
	
	/**
	 * Gets the common service company name list url.
	 *
	 * @return the common service company name list url
	 */
	public String getCommonServiceCompanyNameListUrl() {
		return configurationProperties.getCommonServiceCompanyNameListUrl();
	}
	
	/**
	 * Gets the data lake repository scheduler details url.
	 *
	 * @return the data lake repository scheduler details url
	 */
	public String getDataLakeRepositorySchedulerDetailsUrl() {
		return configurationProperties.getDatalakeRepositoryScheduleDetailsUrl();
	}
	
	/**
	 * Gets the recoverez wallet upaid company name list url.
	 *
	 * @return the recoverez wallet upaid company name list url
	 */
	public String getRecoverezWalletUpaidCompanyNameListUrl() {
		return configurationProperties.getRecoverezWalletUpaidCompanyListUrl();
	}
	
	/**
	 * Gets the recoverez wallet payment reminder template url.
	 *
	 * @return the recoverez wallet payment reminder template url
	 */
	public String getRecoverezWalletPaymentReminderTemplateUrl() {
		return configurationProperties.getRecoverezWalletPaymentReminderTemplateUrl();
	}
	
	/**
	 * Gets the recoverez notification reminder template url.
	 *
	 * @return the recoverez notification reminder template url
	 */
	public String getRecoverezNotificationReminderTemplateUrl() {
		return configurationProperties.getRecoverezNotificationReminderTemplateUrl();
	}
	
	/**
	 * Gets the currency type.
	 *
	 * @return the currency type
	 */
	public String getCurrencyType() {
		return configurationProperties.getCurrencyFormat();
	}
	
	/**
	 * Gets the mysql idle connection test period.
	 *
	 * @return the mysql idle connection test period
	 */
	public String getMysqlIdleConnectionTestPeriod() {
		return configurationProperties.getMysqlIdleConnectionTestperiod();
	}
	
	/**
	 * Gets the mysql max idle timeout.
	 *
	 * @return the mysql max idle timeout
	 */
	public String getMysqlMaxIdleTimeout() {
		return configurationProperties.getMysqlMaxIdleTimeout();
	}
	
	/**
	 * Gets the mysql max idle time excess connections.
	 *
	 * @return the mysql max idle time excess connections
	 */
	public String getMysqlMaxIdleTimeExcessConnections() {
		return configurationProperties.getMysqlMaxIdleExcessConnections();
	}
	
	/**
	 * Gets the mysql connection checkout.
	 *
	 * @return the mysql connection checkout
	 */
	public String getMysqlConnectionCheckout() {
		return configurationProperties.getMysqlConnectionCheckout();
	}
	
	/**
	 * Gets the mysql min pool size.
	 *
	 * @return the mysql min pool size
	 */
	public String getMysqlMinPoolSize() {
		return configurationProperties.getMysqlMinPoolsize();
	}
	
	/**
	 * Gets the mysql max pool size.
	 *
	 * @return the mysql max pool size
	 */
	public String getMysqlMaxPoolSize() {
		return configurationProperties.getMysqlMaxPoolSize();
	}
	
	/**
	 * Gets the mysql prefered query.
	 *
	 * @return the mysql prefered query
	 */
	public String getMysqlPreferedQuery() {
		return configurationProperties.getMysqlPreferredQuery();
	}
	
	/**
	 * Gets the recoverez user list for notification.
	 *
	 * @return the recoverez user list for notification
	 */
	public String getRecoverezUserListForNotification() {
		return configurationProperties.getRecoverezReportlossUserListForNotificationUrl();
	}
		
	/**
	 * Gets the data lake websocket url.
	 *
	 * @return the data lake websocket url
	 */
	public String getDataLakeWebsocketUrl() {
		return configurationProperties.getFrontendDatalakeUrl();
	}
	
	/**
	 * Gets the websocket url.
	 *
	 * @return the websocket url
	 */
	public String getWebsocketUrl() {
		return configurationProperties.getFrontendUrl();
	}


	/**
	 * Gets the datalake service upload company name list url.
	 *
	 * @return the datalake service upload company name list url
	 */
	public String getDatalakeServiceUploadCompanyNameListUrl() {
		return configurationProperties.getDatalakeRepositoryUploadcompanyDetailsUrl();
	}


	/**
	 * Gets the insurance company email.
	 *
	 * @return the insurance company email
	 */
	public String getInsuranceCompanyEmail() {
		return configurationProperties.getCompanyUserMail();
	}

}
