package com.Notification.Model;

/**
 * The Class NotificationTableConstants.
 */
public class NotificationTableConstants {

	/** The Constant REPOSITORY_IDENTITY. */
	public static final String REPOSITORY_IDENTITY= "repositoryIdentity";
}
