package com.Notification.Model;

/**
 * The Class PropertyConstants.
 */
public class PropertyConstants {
	
	
	/** The Constant MY_SQL_IP. */
	public static final String MY_SQL_IP = "[MAIN_APP_MYSQL_IP]";
	
	/** The Constant MY_SQL_PORT. */
	public static final String MY_SQL_PORT = "[MAIN_APP_MYSQL_PORT]";
	
	/** The Constant DB_NAME. */
	public static final String DB_NAME = "[DB_NAME]";
	
	/** The Constant MY_SQL_PASSWORD. */
	public static final String MY_SQL_PASSWORD = "mysql.password";
	
	/** The Constant MY_SQL_USERNAME. */
	public static final String MY_SQL_USERNAME = "mysql.username";
	
	/** The Constant MY_SQL_DRIVER. */
	public static final String MY_SQL_DRIVER="mysqlDriver";
	
	/** The Constant RECOVERY_PORTAL_URI. */
	public static final String RECOVERY_PORTAL_URI="recoveryPoratal.uri";
	
	/** The Constant COMMON_SERVICE_COMPANY_NAME_LIST_URL. */
	public static final String COMMON_SERVICE_COMPANY_NAME_LIST_URL = "common.service.company.name.list.url";
	
	/** The Constant DATALAKE_REPOSITORY_SCHEDULER_DETAILS_URL. */
	public static final String DATALAKE_REPOSITORY_SCHEDULER_DETAILS_URL = "datalake.repository.schedule.details.url";
	
	/** The Constant RECOVEREZ_WALLET_UNPAID_COMPANY_LIST_URL. */
	public static final String RECOVEREZ_WALLET_UNPAID_COMPANY_LIST_URL = "recoverez.wallet.upaid.company.list.url";
	
	/** The Constant RECOVEREZ_WALLET_PAYMENT_REMINDER_TEMPLATE_URL. */
	public static final String RECOVEREZ_WALLET_PAYMENT_REMINDER_TEMPLATE_URL = "recoverez.wallet.payment.reminder.template.url";
	
	/** The Constant RECOVEREZ_NOTIFICATION_REMINDER_TEMPLATE_URL. */
	public static final String RECOVEREZ_NOTIFICATION_REMINDER_TEMPLATE_URL = "recoverez.notification.reminder.template.url";
	
	/** The Constant DATALAKE_REPOSITORY_UPLOAD_COMPANY_DETAILS_URL. */
	public static final String DATALAKE_REPOSITORY_UPLOAD_COMPANY_DETAILS_URL = "datalake.repository.uploadcompany.details.url";
	
	
	/** The Constant CURRENCY_TYPE. */
	public static final String CURRENCY_TYPE = "currency-format";
	
	/** The Constant MYSQL_IDLE_CONNECTION_TEST_PERIOD. */
	public static final String MYSQL_IDLE_CONNECTION_TEST_PERIOD = "notification.mysql.idleConnectionTestperiod";
    
    /** The Constant MYSQL_MAX_IDLE_TIMEOUT. */
    public static final String MYSQL_MAX_IDLE_TIMEOUT = "notification.mysql.maxIdleTimeout";
    
    /** The Constant MYSQL_MAX_IDLE_TIME_EXCESSCONNECTIONS. */
    public static final String MYSQL_MAX_IDLE_TIME_EXCESSCONNECTIONS = "notification.mysql.maxIdleExcessConnections";
    
    /** The Constant MYSQL_CONNECTION_CHECKOUT. */
    public static final String MYSQL_CONNECTION_CHECKOUT = "notification.mysql.connectionCheckout";
    
    /** The Constant MYSQL_MIN_POOL_SIZE. */
    public static final String MYSQL_MIN_POOL_SIZE = "notification.mysql.minPoolsize";
    
    /** The Constant MYSQL_MAX_POOL_SIZE. */
    public static final String MYSQL_MAX_POOL_SIZE = "notification.mysql.maxPoolSize";
    
    /** The Constant MYSQL_PREFERED_QUERY. */
    public static final String MYSQL_PREFERED_QUERY = "notification.mysql.preferredQuery";
    
    /** The Constant RECOVEREZ_USER_LIST_FOR_NOTIFICATION_URL. */
    public static final String RECOVEREZ_USER_LIST_FOR_NOTIFICATION_URL = "recoverez.reportloss.user.list.for.notification.url";
    
    /** The Constant DATALAKE_WEBSOCKET_URL. */
    public static final String DATALAKE_WEBSOCKET_URL = "frontend.datalake.url";
    
    /** The Constant WEBSOCKET_URL. */
    public static final String WEBSOCKET_URL = "frontend.url";
	
	/** The Constant COMPANY_USER_MAIL. */
	public static final String COMPANY_USER_MAIL = "company.user.mail";
}
