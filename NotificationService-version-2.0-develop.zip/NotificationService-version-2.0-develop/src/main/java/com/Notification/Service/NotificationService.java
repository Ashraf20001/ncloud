package com.Notification.Service;

import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.Notification.Dao.NotificationEventDao;
import com.Notification.Dao.NotificationHistoryDao;
import com.Notification.Dao.NotificationTemplateDao;
import com.Notification.Dto.NotificationCountDto;
import com.Notification.Dto.NotificationDetailsDto;
import com.Notification.Dto.NotificationDto;
import com.Notification.Dto.NotificationHistoryDto;
import com.Notification.Dto.ReportLossForNotificationDto;
import com.Notification.Dto.RepositoryScheduleDto;
import com.Notification.Model.EnvironmentProperties;
import com.Notification.Model.PlatformEnum;
import com.Notification.Provider.KafkaProvider;
import com.Notification.Provider.RestTemplateProvider;
import com.Notification.entity.NotificationEvent;
import com.Notification.entity.NotificationHistory;
import com.Notification.entity.NotificationHistoryUserMap;
import com.Notification.entity.NotificationTemplate;
import com.recoveryportal.constants.core.ApplicationConstants;
import com.recoveryportal.exception.core.ApplicationException;
import com.recoveryportal.exception.core.codes.ErrorCodes;
import com.recoveryportal.transfer.object.entity.SchedulerNotification;
import com.recoveryportal.utils.core.ApplicationUtils;

import freemarker.template.Configuration;
import freemarker.template.Template;

/**
 * The Class NotificationService.
 */
@Service
@Transactional
public class NotificationService {
	
	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(NotificationService.class);

	/** The kafkaprovider. */
	@Autowired
	KafkaProvider kafkaprovider;

	/** The environmentproperties. */
	@Autowired
	EnvironmentProperties environmentproperties;

	/** The notification history dao. */
	@Autowired
	private NotificationHistoryDao notificationHistoryDao;

	/** The notification event dao. */
	@Autowired
	private NotificationEventDao notificationEventDao;

	/** The notification template dao. */
	@Autowired
	NotificationTemplateDao notificationTemplateDao;

	/** The messaging template. */
	@Autowired
	SimpMessagingTemplate messagingTemplate;

	/** The Rest template provider. */
	@Autowired
	RestTemplateProvider RestTemplateProvider;
	
	/** The free marker config. */
	@Autowired
    private Configuration freeMarkerConfig;
	
	
	/**
	 * Update notification.
	 *
	 * @param notificationDetailsDto the notification details dto
	 */
	public void updateNotification(NotificationDetailsDto notificationDetailsDto) {
		ReportLossForNotificationDto reportLossData = notificationDetailsDto.getReportLossDto();

		Integer claimId = ApplicationUtils.isValidateObject(reportLossData)? reportLossData.getClaimId():null;
		Integer userId = notificationDetailsDto.getUserId() != null ? notificationDetailsDto.getUserId()
				:0;
		List<NotificationHistory> notificationHistoryList = new ArrayList<NotificationHistory>();
		notificationHistoryList = notificationHistoryDao.getUnReadNotification(
				claimId, notificationDetailsDto.getLoginUserCompanyName()
				,notificationDetailsDto.getRepositoryIdentity());
		if (!notificationHistoryList.isEmpty()) {
			for (NotificationHistory notificationHistory : notificationHistoryList) {
				updateNotificationHistory(userId, notificationHistory);
				notificationHistoryDao.updateNotificationHistory(notificationHistory);
			}
		}

	}
 
	/**
	 * Save notification.
	 *
	 * @param notificationDetailsDto the notification details dto
	 * @return the string
	 * @throws ApplicationException the application exception
	 */
	public String saveNotification(NotificationDetailsDto notificationDetailsDto)
			throws ApplicationException {
		
		ReportLossForNotificationDto reportLoss = notificationDetailsDto.getReportLossDto();
		NotificationEvent event = notificationEventDao
				.getNotificationEventByEventName(ApplicationConstants.STATUS_CHANGE);
		NotificationTemplate notificationtemplate = notificationTemplateDao.getTemplateByEventId(event,
				reportLoss.getState());
				String template = notificationtemplate.getContent();
		NotificationHistory NotificationHistory = new NotificationHistory();
		NotificationHistory = buildDtoForNotificationHistory(notificationDetailsDto,
		NotificationHistory, reportLoss, template);
				List<String> actionSatusList = ApplicationConstants.NEGATIVE_FLOW_STATUS;
		if (!actionSatusList.contains(NotificationHistory.getStatus().toUpperCase())) {
			List<NotificationHistory> existingNotificationHistoryList = notificationHistoryDao
					.getNotificationHistoryByStatus(reportLoss.getClaimId(), NotificationHistory.getStatus(),
							notificationDetailsDto.getLoginUserCompanyName());
			if (existingNotificationHistoryList.size() > 0) {
				for (NotificationHistory notificationHistory : existingNotificationHistoryList) {
					Integer userId = notificationDetailsDto.getUserId();
					updateNotificationHistory(userId, notificationHistory);
					notificationHistoryDao.updateNotificationHistory(notificationHistory);
				}
				return NotificationHistory.getTemplate();
			} else {
				notificationHistoryDao.saveNotification(NotificationHistory);
				buildDtoForNotification(NotificationHistory, notificationDetailsDto);
			}
		}else {
			notificationHistoryDao.saveNotification(NotificationHistory);
			buildDtoForNotification(NotificationHistory,notificationDetailsDto);
		}
		return NotificationHistory.getTemplate();
	}

	/**
	 * Approval limi notification.
	 *
	 * @param notificationDetailsDto the notification details dto
	 * @throws ApplicationException the application exception
	 */
	public void approvalLimiNotification(NotificationDetailsDto notificationDetailsDto) throws ApplicationException {
		NotificationEvent event = notificationEventDao
				.getNotificationEventByEventName(ApplicationConstants.STATUS_CHANGE);
		NotificationTemplate notificationtemplate = notificationTemplateDao.getTemplateByEventId(event,
				notificationDetailsDto.getState());
		String template = notificationtemplate.getContent();
		String minAmountFormatted = convertvalueWithFormat(notificationDetailsDto.getMinAmount());
		String maxAmountFormatted = convertvalueWithFormat(notificationDetailsDto.getMaxAmount());
		
		String finaltemplate = template.replaceAll(ApplicationConstants.MIN,minAmountFormatted).replaceAll(ApplicationConstants.MAX,maxAmountFormatted)
				.replaceAll(ApplicationConstants.ROLE_NAME, notificationDetailsDto.getRoleName());
		StringBuilder replaceableData = new StringBuilder();
		replaceableData
	    .append("{\"")
	    .append(ApplicationConstants.MIN).append("\":\"").append(convertvalueWithFormat( notificationDetailsDto.getMinAmount())).append("\",\"")
	    .append(ApplicationConstants.MAX).append("\":\"").append(convertvalueWithFormat( notificationDetailsDto.getMaxAmount())).append("\",\"")
	    .append(ApplicationConstants.ROLE_NAME).append("\":\"").append(notificationDetailsDto.getRoleName())
	    .append("\"}");
		NotificationHistory NotificationHistory = new NotificationHistory();
		NotificationHistory.setCreatedDate(new Date());
		NotificationHistory.setTemplate(finaltemplate);
		NotificationHistory.setToNotify(notificationDetailsDto.getThirdPartyTpname());
		NotificationHistory.setStatus(notificationDetailsDto.getState());
		NotificationHistory.setRePlacableTemplateData(replaceableData.toString());
		notificationHistoryDao.saveNotification(NotificationHistory);
		buildDtoFoApprovalNotification(notificationDetailsDto,finaltemplate,NotificationHistory);
}
	
	
	
	/**
	 * Builds the dto fo approval notification.
	 *
	 * @param notificationDetailsDto the notification details dto
	 * @param template the template
	 * @param notificationHistory the notification history
	 */
	private void buildDtoFoApprovalNotification(NotificationDetailsDto notificationDetailsDto,String template,NotificationHistory notificationHistory) {
		NotificationHistoryDto newNotification = new NotificationHistoryDto();
		newNotification.setTemplate(template);
		newNotification.setCreatedDate(new Date());
		newNotification.setToNotifyCompany(notificationDetailsDto.getThirdPartyTpname());
		newNotification.setImageUrl(notificationDetailsDto.getLogoByCompanyId());
		newNotification.setClaimId(1);
		newNotification.setLastActedCompany(notificationDetailsDto.getThirdPartyTpname());
		newNotification.setApprovalId(notificationHistory.getId());		
		newNotification.setStatus(notificationHistory.getStatus());	
		newNotification.setRePlacableTemplateData(notificationHistory.getRePlacableTemplateData());
		messagingTemplate.convertAndSend(ApplicationConstants.WEBSOCKET_ENDPOINT + newNotification.getToNotifyCompany(),
		newNotification);
	}

	/**
	 * Send notification.
	 *
	 * @param notificationDto the notification dto
	 * @throws ApplicationException the application exception
	 */
	public void sendNotification(NotificationDto notificationDto) throws ApplicationException {
		RestTemplate restTemplate = RestTemplateProvider.getRestTemplate();
		HttpHeaders httpheaders = RestTemplateProvider.getHttpHeaders();
		HttpEntity<NotificationDto> httpentity = new HttpEntity<>(notificationDto, httpheaders);
		String uri = environmentproperties.getRecoveryPortalUri();
		ResponseEntity<NotificationDto> response = restTemplate.exchange(uri, HttpMethod.POST, httpentity, NotificationDto.class);
		NotificationDto res = response.getBody();
		if (ApplicationUtils.isValidateObject(res)){
			notificationDto.setClaimSequenceId(res.getClaimSequenceId());
			notificationDto.setCompanyName(res.getCompanyName());
			notificationDto.setLogoUrl(res.getLogoUrl());	
			notificationDto.setLastActed(res.getLastActed());
			buildDtoForPushNotification(notificationDto);
		} else {
			kafkaprovider.sendNotificationDto(notificationDto);
		}

	}

	/**
	 * Builds the dto for push notification.
	 *
	 * @param notificationdto the notificationdto
	 * @throws ApplicationException the application exception
	 */
	public void buildDtoForPushNotification(NotificationDto notificationdto) throws ApplicationException {
		NotificationHistory notificationHistory = new NotificationHistory();
		if(ApplicationUtils.isValidateObject(notificationdto)) {
			saveNotificationHistory(notificationdto, notificationHistory);
			NotificationHistoryDto notificationHistoryDto = buildDtoForPushNotification(notificationHistory,notificationdto.getLogoUrl());
			if(notificationdto.getClaimId() == null) {
				messagingTemplate.convertAndSend("/topic/notification/" + notificationHistoryDto.getToNotifyCompany(),
						notificationHistoryDto);	
			} else {
				List<String> userIdentityList = getValidUserIdentityListForNotification(notificationdto.getClaimId(), notificationdto.getCompanyName());
				if(ApplicationUtils.isValidList(userIdentityList)) {
					for(String userIdentity: userIdentityList) {
						messagingTemplate.convertAndSend(ApplicationConstants.WEBSOCKET_ENDPOINT + notificationHistoryDto.getToNotifyCompany() + 
								ApplicationConstants.SLASH + userIdentity, notificationHistoryDto);
					}
					for(String userIdentity: userIdentityList) {
						NotificationHistoryUserMap notificationHistoryUserMap = new NotificationHistoryUserMap();
						notificationHistoryUserMap.setNotificationHistory(notificationHistory);
						notificationHistoryUserMap.setUserIdentity(userIdentity);
						notificationHistoryUserMap.setCreatedDate(notificationHistory.getCreatedDate());
						notificationHistoryUserMap.setModifiedDate(notificationHistory.getModifiedDate());
						notificationHistoryDao.saveNotificationHistoryUserMap(notificationHistoryUserMap);
					}
				}
			}
		}
	}
	
	/**
	 * Gets the valid user identity list for notification.
	 *
	 * @param claimId the claim id
	 * @param companyName the company name
	 * @return the valid user identity list for notification
	 */
	private List<String> getValidUserIdentityListForNotification(Integer claimId, String companyName) {
		List<String> userIdentityList = new ArrayList<>();
		RestTemplate restTemplate = RestTemplateProvider.getRestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<?> httpentity = new HttpEntity<>(headers);
		String uri = environmentproperties.getRecoverezUserListForNotification();
		String urlTemplate = UriComponentsBuilder.fromHttpUrl(uri).queryParam(ApplicationConstants.CLAIM_ID, claimId).queryParam(ApplicationConstants.NOTIFICATION_COMPANY_NAME, companyName).toUriString();
		ResponseEntity<String[]> response = restTemplate.exchange(urlTemplate, HttpMethod.GET, httpentity, String[].class);
		String[] data = response.getBody();
		if(data != null) {
			userIdentityList = Arrays.asList(data);
		}
		return userIdentityList;
	}

	/**
	 * Builds the dto for push notification.
	 *
	 * @param notificationHistory the notification history
	 * @param logoUrl the logo url
	 * @return the notification history dto
	 */
	public NotificationHistoryDto buildDtoForPushNotification(NotificationHistory notificationHistory, String logoUrl) {
		NotificationHistoryDto notificationHistoryDto = new NotificationHistoryDto();
		notificationHistoryDto.setClaimId(notificationHistory.getClaimId());
		notificationHistoryDto.setLastActedCompany(notificationHistory.getLastActed());
		notificationHistoryDto.setTemplate(notificationHistory.getTemplate());
		notificationHistoryDto.setToNotifyCompany(notificationHistory.getToNotify());
		notificationHistoryDto.setRead(notificationHistory.isRead());
		notificationHistoryDto.setCreatedDate(notificationHistory.getCreatedDate());
		notificationHistoryDto.setImageUrl(logoUrl);
		notificationHistoryDto.setStatus(notificationHistory.getStatus());
		notificationHistoryDto.setRePlacableTemplateData(notificationHistory.getRePlacableTemplateData());
		notificationHistoryDto.setRepositoryIdentity(notificationHistory.getRepositoryIdentity());
		return notificationHistoryDto;
	}

	

	/**
	 * Update notification history.
	 *
	 * @param userId the user id
	 * @param notificationHistory the notification history
	 */
	public void updateNotificationHistory(Integer userId, NotificationHistory notificationHistory) {

		if (ApplicationUtils.isValidateObject(notificationHistory)) {
			notificationHistory.setModifiedBy(userId);
			notificationHistory.setModifiedDate(new Date());
			notificationHistory.setRead(true);
		}
	}
	
	/**
	 * Save notification history.
	 *
	 * @param notificationdto the notificationdto
	 * @param notificationHistory the notification history
	 * @throws ApplicationException the application exception
	 */
	public void saveNotificationHistory(NotificationDto notificationdto, NotificationHistory notificationHistory)
			throws ApplicationException {
		StringBuilder builder = new StringBuilder();
		SchedulerNotification schedulerNotification = getNotificationTemplateForReminder(notificationdto.getStatus());
		if(ApplicationUtils.isValidateObject(schedulerNotification)){
			String template = schedulerNotification.getMessage();
			String reminder = schedulerNotification.getRemainder().toString();
			builder.append(template.replace(ApplicationConstants.CLAIM_NUMBER, notificationdto.getClaimSequenceId())
					.replace(ApplicationConstants.STATUS_BRACED, notificationdto.getStatus())
					.replace(ApplicationConstants.REMINDER_BRACED, reminder));
			StringBuilder replaceableData = new StringBuilder();
			replaceableData
					.append("{\"")
					.append(ApplicationConstants.CLAIM_NUMBER).append("\":\"").append(notificationdto.getClaimSequenceId()).append("\",\"")
					.append(ApplicationConstants.STATUS_BRACED).append("\":\"").append(notificationdto.getStatus()).append("\",\"")
					.append(ApplicationConstants.REMINDER_BRACED).append("\":\"").append(reminder)
					.append("\"}");
			notificationHistory.setRePlacableTemplateData(replaceableData.toString());
			notificationHistory.setClaimId(notificationdto.getClaimId());
			notificationHistory.setRead(false);
			notificationHistory.setStatus(schedulerNotification.getNotificationName());
			notificationHistory.setDeleted(false);
			notificationHistory.setCreatedDate(new Date());
			notificationHistory.setModifiedDate(new Date());
			notificationHistory.setLastActed(notificationdto.getLastActed());
			notificationHistory.setTemplate(builder.toString());
			notificationHistory.setToNotify(notificationdto.getCompanyName());
			notificationHistoryDao.saveNotification(notificationHistory);

		}
	}
	
	/**
	 * Builds the dto for notification history.
	 *
	 * @param notificationDetailsDto the notification details dto
	 * @param NotificationHistory the notification history
	 * @param reportLoss the report loss
	 * @param template the template
	 * @return the notification history
	 * @throws ApplicationException the application exception
	 */
	private NotificationHistory buildDtoForNotificationHistory(NotificationDetailsDto notificationDetailsDto, NotificationHistory NotificationHistory,
			ReportLossForNotificationDto reportLoss, String template) throws ApplicationException {
		NotificationHistory.setClaimId(reportLoss.getClaimId());
		NotificationHistory.setRead(false);
		NotificationHistory.setStatus(reportLoss.getState());
		NotificationHistory.setDeleted(false);
		NotificationHistory.setCreatedBy(notificationDetailsDto.getUserId());
		NotificationHistory.setCreatedDate(new Date());
		NotificationHistory.setModifiedBy(notificationDetailsDto.getUserId());
		NotificationHistory.setModifiedDate(new Date());
		buildNotificationTemplate(NotificationHistory, reportLoss, template,notificationDetailsDto);

		return NotificationHistory;

	}

	/**
	 * Builds the notification template.
	 *
	 * @param notificationHistory the notification history
	 * @param reportLoss the report loss
	 * @param template the template
	 * @param notificationDetailsDto the notification details dto
	 * @throws ApplicationException the application exception
	 */
	public void buildNotificationTemplate(NotificationHistory notificationHistory,
			ReportLossForNotificationDto reportLoss, String template,NotificationDetailsDto notificationDetailsDto
			) throws ApplicationException {
		if (notificationDetailsDto.getLoginUserCompanyName().equals(notificationDetailsDto.getThirdPartyTpname())) {
			notificationHistory.setToNotify(notificationDetailsDto.getInsurerName());
			notificationHistory.setLastActed(notificationDetailsDto.getThirdPartyTpname());		
			} else if (notificationDetailsDto.getLoginUserCompanyName().equals(notificationDetailsDto.getInsurerName())) {
			notificationHistory.setToNotify(notificationDetailsDto.getThirdPartyTpname());
			notificationHistory.setLastActed(notificationDetailsDto.getInsurerName());
		} else {
			throw new ApplicationException(ErrorCodes.INVALID_LOGGED_IN_USER);
		}
		StringBuilder finalMessage = new StringBuilder();
		finalMessage.append(template.replaceAll(ApplicationConstants.CLAIM_NUMBER, reportLoss.getClaimSequenceId())
				.replaceAll(ApplicationConstants.COMPANY_NAME, notificationDetailsDto.getLoginUserCompanyName()));
		StringBuilder replaceableData = new StringBuilder();
		replaceableData
		 .append("{\"")
	        .append(ApplicationConstants.CLAIM_NUMBER).append("\":\"").append(reportLoss.getClaimSequenceId()).append("\",\"")
	        .append(ApplicationConstants.COMPANY_NAME).append("\":\"").append(notificationDetailsDto.getLoginUserCompanyName())
	        .append("\"}");
		notificationHistory.setRePlacableTemplateData(replaceableData.toString());;
		notificationHistory.setTemplate(finalMessage.toString());
	}

	/**
	 * Builds the dto for notification.
	 *
	 * @param notification the notification
	 * @param notificationDetailsDto the notification details dto
	 * @throws ApplicationException the application exception
	 */
	private void buildDtoForNotification(NotificationHistory notification,NotificationDetailsDto notificationDetailsDto) throws ApplicationException {
		NotificationHistoryDto newNotification = new NotificationHistoryDto();
		newNotification.setClaimId(notification.getClaimId());
		if(notification.getTemplate() != null) {
			newNotification.setTemplate(notification.getTemplate());
		}
		newNotification.setRead(notification.isRead());
		newNotification.setCreatedDate(notification.getCreatedDate());
		newNotification.setToNotifyCompany(notification.getToNotify());
		newNotification.setLastActedCompany(notification.getLastActed());
		newNotification.setImageUrl(notificationDetailsDto.getLogoByCompanyId());
		newNotification.setStatus(notification.getStatus());
		newNotification.setRePlacableTemplateData(notification.getRePlacableTemplateData());
		if(ApplicationUtils.isValidObject(notificationDetailsDto.getReportLossDto())) {
			newNotification.setClaimIdentity(notificationDetailsDto.getReportLossDto().getClaimIdentity());
		}
		if(notification.getClaimId() == null) {
			messagingTemplate.convertAndSend(ApplicationConstants.WEBSOCKET_ENDPOINT + notification.getToNotify(),
					newNotification);
		} else {
			List<String> userIdentityList = getValidUserIdentityListForNotification(notification.getClaimId(), notification.getToNotify());
			if(ApplicationUtils.isValidList(userIdentityList)) {
				for(String userIdentity: userIdentityList) {
					messagingTemplate.convertAndSend(ApplicationConstants.WEBSOCKET_ENDPOINT + notification.getToNotify() + 
							ApplicationConstants.SLASH + userIdentity, newNotification);
				}
				for(String userIdentity: userIdentityList) {
					NotificationHistoryUserMap notificationHistoryUserMap = new NotificationHistoryUserMap();
					notificationHistoryUserMap.setNotificationHistory(notification);
					notificationHistoryUserMap.setUserIdentity(userIdentity);
					notificationHistoryUserMap.setCreatedDate(notification.getCreatedDate());
					notificationHistoryUserMap.setModifiedDate(notification.getModifiedDate());
					notificationHistoryDao.saveNotificationHistoryUserMap(notificationHistoryUserMap);
				}
			}
		}
	}

	/**
	 * Gets the notification history.
	 *
	 * @param notificationDto the notification dto
	 * @return the notification history
	 */
	public List<NotificationHistoryDto> getNotificationHistory(NotificationDto notificationDto) {
		List<NotificationHistoryDto> allNotifications = new ArrayList<NotificationHistoryDto>();

		List<NotificationHistory> notificationHistorylist = notificationHistoryDao.getAllNotifications(notificationDto.getCompanyName(), notificationDto.getPlatformId());

		//temporarily setting as null for recovery
		if(notificationDto.getPlatformId()== null){
			// remove report loss history notification history
			List<NotificationHistory> recoveryFilteredClaimNotificationList = notificationHistorylist.stream().filter(notificationHistory -> !ApplicationUtils.isValidId(notificationHistory.getClaimId())).toList();

			// get all report loss history by user
			List<NotificationHistory> recoveryClaimNotificationList = notificationHistoryDao.getReportLossNotificationByUserIdentity(notificationDto.getUserIdentity());

			if(ApplicationUtils.isValidList(recoveryClaimNotificationList)){
				// add all report loss notification to list
				notificationHistorylist = Stream.concat(recoveryFilteredClaimNotificationList.stream(), recoveryClaimNotificationList.stream()).toList();

				// sort the list
				notificationHistorylist = notificationHistorylist.stream().sorted(Comparator.comparing(NotificationHistory::getCreatedDate).reversed()).toList();
			} else {
				// assign the filtered list
				notificationHistorylist = recoveryFilteredClaimNotificationList;
			}
		}

		logger.info(notificationDto.getCompanyName()+notificationHistorylist.toString());
		buildDtoForNotificationHistory(allNotifications, notificationHistorylist);
         return allNotifications;

	}

	/**
	 * Gets the notification history count.
	 *
	 * @param notificationDto the notification dto
	 * @return the notification history count
	 */
	public NotificationCountDto getNotificationHistoryCount(NotificationDto notificationDto) {
		NotificationCountDto notificationCountDto = new NotificationCountDto();
		List<NotificationHistory> notificationHistorylist = notificationHistoryDao.getAllNotifications(notificationDto.getCompanyName(), notificationDto.getPlatformId());
		if (Boolean.FALSE.equals(ApplicationUtils.isValidList(notificationHistorylist))) {
			buildDtoForCount(notificationCountDto, notificationDto.getCompanyName(), 0L, 0L, 0L);
		} else {
			//temporarily setting as null for recovery
			if(notificationDto.getPlatformId()== null){
				// remove report loss history notification history
				List<NotificationHistory> recoveryFilteredClaimNotificationList = notificationHistorylist.stream().filter(notificationHistory -> !ApplicationUtils.isValidId(notificationHistory.getClaimId())).toList();

				// get all report loss history by user
				List<NotificationHistory> recoveryClaimNotificationList = notificationHistoryDao.getReportLossNotificationByUserIdentity(notificationDto.getUserIdentity());

				if(ApplicationUtils.isValidList(recoveryClaimNotificationList)){
					// add all report loss notification to list
					notificationHistorylist = Stream.concat(recoveryFilteredClaimNotificationList.stream(), recoveryClaimNotificationList.stream()).toList();

					// sort the list
					notificationHistorylist = notificationHistorylist.stream().sorted(Comparator.comparing(NotificationHistory::getCreatedDate).reversed()).toList();
				} else {
					// assign the filtered list
					notificationHistorylist = recoveryFilteredClaimNotificationList;
				}
			}
			Long readCount = notificationHistorylist.stream().filter(notification -> notification.isRead() == true)
					.distinct().count();
			Long unReadCount = notificationHistorylist.stream().filter(notification -> notification.isRead() == false)
					.distinct().count();
			Long totalCount = notificationHistorylist.stream().distinct().count();
			buildDtoForCount(notificationCountDto, notificationDto.getCompanyName(), readCount, unReadCount, totalCount);
		}
		return notificationCountDto;
	}

	/**
	 * Builds the dto for count.
	 *
	 * @param notificationCountDto the notification count dto
	 * @param comapanyName the comapany name
	 * @param readCount the read count
	 * @param unReadCount the un read count
	 * @param totalCount the total count
	 */
	private void buildDtoForCount(NotificationCountDto notificationCountDto, String comapanyName, Long readCount,
			Long unReadCount, Long totalCount) {
		notificationCountDto.setCompanyName(comapanyName);
		notificationCountDto.setReadCount(readCount);
		notificationCountDto.setUnReadCount(unReadCount);
		notificationCountDto.setTotalCount(totalCount);
	}

	/**
	 * Builds the dto for notification history.
	 *
	 * @param allNotifications the all notifications
	 * @param notificationHistorylist the notification historylist
	 */
	public void buildDtoForNotificationHistory(List<NotificationHistoryDto> allNotifications,
			List<NotificationHistory> notificationHistorylist) {
		for (NotificationHistory notification : notificationHistorylist) {
			NotificationHistoryDto notificationHistory = new NotificationHistoryDto();

			notificationHistory.setClaimId(notification.getClaimId());
			notificationHistory.setTemplate(notification.getTemplate());
			notificationHistory.setRead(notification.isRead());
			notificationHistory.setCreatedDate(notification.getCreatedDate());
			notificationHistory.setToNotifyCompany(notification.getToNotify());
			notificationHistory.setLastActedCompany(notification.getLastActed());
			notificationHistory.setStatus(notification.getStatus());
			notificationHistory.setApprovalId(notification.getId());
			notificationHistory.setRePlacableTemplateData(notification.getRePlacableTemplateData());
			notificationHistory.setRepositoryIdentity(notification.getRepositoryIdentity());
			allNotifications.add(notificationHistory);

		}

	}

	/**
	 * Update notification.
	 *
	 * @param approvalId the approval id
	 */
	public void updateNotification(Integer approvalId) {
    NotificationHistory notificationHistory =	notificationHistoryDao.getClaimHistoryForId(approvalId);
    notificationHistory.setRead(true);
    notificationHistoryDao.updateNotificationHistory(notificationHistory);	}
	
	/**
	 * Save notification for wallet.
	 *
	 * @param notificationDetailsDto the notification details dto
	 * @return the string
	 * @throws ApplicationException the application exception
	 */
	public String saveNotificationForWallet(NotificationDetailsDto notificationDetailsDto)
			throws ApplicationException {
		
			
			NotificationEvent event = notificationEventDao
					.getNotificationEventByEventName(ApplicationConstants.STATUS_CHANGE);
			NotificationTemplate notificationtemplate = notificationTemplateDao.getTemplateByEventId(event,
					notificationDetailsDto.getState());
			String template = notificationtemplate.getContent();
			NotificationHistory NotificationHistory = new NotificationHistory();
			NotificationHistory = buildentityFromDtoForWallet(notificationDetailsDto,
			NotificationHistory,template);
			notificationHistoryDao.saveNotification(NotificationHistory);
			buildDtoForNotification(NotificationHistory,notificationDetailsDto);
			return template;
			}

	/**
	 * Buildentity from dto for wallet.
	 *
	 * @param notificationDetailsDto the notification details dto
	 * @param notificationHistory the notification history
	 * @param template the template
	 * @return the notification history
	 */
	private NotificationHistory buildentityFromDtoForWallet(NotificationDetailsDto notificationDetailsDto,
			NotificationHistory notificationHistory, String template) {
		
		notificationHistory.setRead(false);
		notificationHistory.setStatus(notificationDetailsDto.getState());
		notificationHistory.setDeleted(false);
		notificationHistory.setCreatedBy(notificationDetailsDto.getUserId());
		notificationHistory.setCreatedDate(new Date());
		notificationHistory.setModifiedBy(notificationDetailsDto.getUserId());
		notificationHistory.setModifiedDate(new Date());
		notificationHistory.setToNotify(notificationDetailsDto.getThirdPartyTpname());
		notificationHistory.setLastActed(notificationDetailsDto.getInsurerName());
		notificationHistory.setPaymentId(notificationDetailsDto.getPaymentId());
		StringBuilder finalMessage = new StringBuilder();
		finalMessage.append(template.replaceAll(ApplicationConstants.TEMPLATE_PERIOD,notificationDetailsDto.getPeriod())
				.replaceAll(ApplicationConstants.COMPANY_NAME, notificationDetailsDto.getInsurerName())
				.replaceAll(ApplicationConstants.ASSOCIATION_NAME, notificationDetailsDto.getAssociationName()));
		notificationHistory.setTemplate(finalMessage.toString());
		
		StringBuilder replaceableData = new StringBuilder();
		replaceableData
		 .append("{\"")
	        .append(ApplicationConstants.TEMPLATE_PERIOD).append("\":\"").append(notificationDetailsDto.getPeriod()).append("\",\"")
	        .append(ApplicationConstants.ASSOCIATION_NAME).append("\":\"").append(notificationDetailsDto.getAssociationName()).append("\",\"")
	        .append(ApplicationConstants.COMPANY_NAME).append("\":\"").append(notificationDetailsDto.getInsurerName())
	        .append("\"}");
		notificationHistory.setRePlacableTemplateData(replaceableData.toString());
		return notificationHistory;
	}
	
	/**
	 * Send repository notification.
	 *
	 * @param notificationDto the notification dto
	 * @param uploadFlow the upload flow
	 * @return the map
	 */
	public Map<String, List<String>> sendRepositoryNotification(NotificationDto notificationDto, boolean uploadFlow) {
		List<String> companyNameList = new ArrayList<>();
		RepositoryScheduleDto repositoryScheduleDto = new RepositoryScheduleDto();
		if(ApplicationUtils.isValidateObject(notificationDto)) {
			if(uploadFlow) {
				        companyNameList = getCompanyNameList(notificationDto.getAssociationId());
				        repositoryScheduleDto = getRepositoryScheduleDetails(notificationDto.getStatus());
			}else {
				 companyNameList = getCompanyNameDetails(notificationDto.getAssociationId(),notificationDto.getFromDate());
				 String[] Identity = notificationDto.getStatus().split("_");
				 notificationDto.setStatus(Identity[0]);
		        repositoryScheduleDto = getRepositoryScheduleDetails(notificationDto.getStatus());
			}

//			if the scheduler is inactive / repository is disabled or not approved, then stop pushing the notification and delete the job
			if(repositoryScheduleDto != null && (
					(repositoryScheduleDto.getIsActiveScheduler() !=null && Boolean.FALSE.equals(repositoryScheduleDto.getIsActiveScheduler()))
					|| (repositoryScheduleDto.getIsActiveRepository() !=null && Boolean.FALSE.equals(repositoryScheduleDto.getIsActiveRepository()))
			)){
				kafkaprovider.sendNotificationDto(notificationDto);
				return null;
			}

			if(ApplicationUtils.isValidList(companyNameList) && repositoryScheduleDto != null) {
				String template = repositoryScheduleDto.getRepositoryName() +
                        ": " + repositoryScheduleDto.getNotificationMessage();
				for(String companyName: companyNameList) {
					try {
						NotificationHistory notificationHistory = saveNotificationHistory(companyName, template, notificationDto.getPlatformId(), notificationDto.getStatus());
						NotificationHistoryDto notificationHistoryDto = buildDtoForPushNotification(notificationHistory, "");
						messagingTemplate.convertAndSend(ApplicationConstants.WEBSOCKET_ENDPOINT + notificationHistory.getToNotify(),
								notificationHistoryDto);
					} catch(ApplicationException ae) {
						logger.info("Exception while saving notification history ====> "+ ae); 
					}
				}
			}
		}
		Map<String, List<String>> repoNameCompanyListMap = new HashMap<>();
		repoNameCompanyListMap.put(repositoryScheduleDto.getRepositoryName() , companyNameList);
		return repoNameCompanyListMap;
	}
	
	/**
	 * Gets the company name list.
	 *
	 * @param associationId the association id
	 * @return the company name list
	 */
	private List<String> getCompanyNameList(Integer associationId) {
		List<String> companyNameList = new ArrayList<>();
		if(ApplicationUtils.isValidId(associationId)) {
			RestTemplate restTemplate = RestTemplateProvider.getRestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			HttpEntity<?> httpentity = new HttpEntity<>(headers);
			String uri = environmentproperties.getCommonServiceCompanyNameListUrl();
			String urlTemplate = UriComponentsBuilder.fromHttpUrl(uri).queryParam(ApplicationConstants.ASSOCIATION_ID, associationId).toUriString();
			ResponseEntity<String[]> response = restTemplate.exchange(urlTemplate, HttpMethod.GET, httpentity, String[].class);
			String[] data = response.getBody();
			companyNameList = Arrays.asList(data);
		}
		return companyNameList;
	}
	
	/**
	 * Gets the company name details.
	 *
	 * @param associationId the association id
	 * @param fromDate the from date
	 * @return the company name details
	 */
	private List<String> getCompanyNameDetails(Integer associationId, Date fromDate) {
		List<String> companyNameList = new ArrayList<>();

		if (ApplicationUtils.isValidId(associationId)) {
			RestTemplate restTemplate = RestTemplateProvider.getRestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			HttpEntity<?> httpEntity = new HttpEntity<>(headers);
			
			String uri = environmentproperties.getDatalakeServiceUploadCompanyNameListUrl();
			UriComponentsBuilder urlTemplate = UriComponentsBuilder.fromHttpUrl(uri);
			
			urlTemplate.queryParam(ApplicationConstants.ASSOCIATION_ID, associationId);
			urlTemplate.queryParam("fromDate",fromDate);

			ResponseEntity<List<String>> response = restTemplate.exchange(urlTemplate.toUriString(), HttpMethod.GET,
					httpEntity, new ParameterizedTypeReference<List<String>>() {
					});
			companyNameList = response.getBody();
		}

	return companyNameList;
	
	}
	
	/**
	 * Gets the repository schedule details.
	 *
	 * @param repositoryIdentity the repository identity
	 * @return the repository schedule details
	 */
	private RepositoryScheduleDto getRepositoryScheduleDetails(String repositoryIdentity) {
		RepositoryScheduleDto data = null;
		if(ApplicationUtils.isValidIdentity(repositoryIdentity)) {
			RestTemplate restTemplate = RestTemplateProvider.getRestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			HttpEntity<?> httpEntity = new HttpEntity<>(headers);
			String uri = environmentproperties.getDataLakeRepositorySchedulerDetailsUrl();
			String urlTemplate = UriComponentsBuilder.fromHttpUrl(uri).queryParam(ApplicationConstants.REPOSITORY_IDENTITY, repositoryIdentity).toUriString();
			ResponseEntity<RepositoryScheduleDto> response = restTemplate.exchange(urlTemplate,  HttpMethod.GET, httpEntity, RepositoryScheduleDto.class);
			data = response.getBody();
		}
		return data;
	}
	
	/**
	 * Save notification history.
	 *
	 * @param companyName the company name
	 * @param template the template
	 * @param platformId the platform id
	 * @param status the status
	 * @return the notification history
	 * @throws ApplicationException the application exception
	 */
	private NotificationHistory saveNotificationHistory(String companyName, String template, Integer platformId, String status) throws ApplicationException {
		NotificationHistory notificationHistory = new NotificationHistory();
		boolean isStatusSetted=false;
		if(ApplicationUtils.isValidateObject(platformId)) {
			notificationHistory.setPlatformId(platformId); // Platform Differentiation
			if(platformId.equals(PlatformEnum.DATA_LAKE.getPlatformId())) {
				notificationHistory.setRepositoryIdentity(status);
				notificationHistory.setStatus(null);
				isStatusSetted=true;
			}
		}
		notificationHistory.setRead(false);
		notificationHistory.setToNotify(companyName);
		notificationHistory.setLastActed(null);
		notificationHistory.setTemplate(template);
		if(!isStatusSetted){
			notificationHistory.setStatus(status);
		}
		notificationHistory.setDeleted(false);
		notificationHistory.setCreatedBy(0);
		notificationHistory.setCreatedDate(new Date());
		notificationHistory.setModifiedBy(0);
		notificationHistory.setModifiedDate(new Date());
		notificationHistoryDao.saveNotification(notificationHistory);
		return notificationHistory;
	}
	

	/**
	 * Update notificationby repository identityand tonotify.
	 *
	 * @param userid the userid
	 * @param companyName the company name
	 * @param repositoryId the repository id
	 */
	public void updateNotificationbyRepositoryIdentityandTonotify(Integer userid, String companyName,
			int repositoryId) {
		notificationHistoryDao.updateNotificationbyRepositoryIdentityandTonotify(userid, companyName, repositoryId);

	}
	
	/**
	 * Generate payment reminder notification.
	 *
	 * @param notificationDto the notification dto
	 */
	public void generatePaymentReminderNotification(NotificationDto notificationDto) {
		Long reportTime = null;
		try {
			if(ApplicationUtils.isValidateObject(notificationDto)) {
				reportTime = Long.parseLong(notificationDto.getCompanyName()); // company name is report time
			}
		} catch(NumberFormatException e) {}
		List<String> companyNameList = getUnpaidCompanyNameList(reportTime);
		if(ApplicationUtils.isValidList(companyNameList)) {
			String template = getNotificationTemplateForPaymentReminder();
			for(String companyName: companyNameList) {
				try {
					NotificationHistory notificationHistory = saveNotificationHistory(companyName, template, null, notificationDto.getStatus());
					NotificationHistoryDto notificationHistoryDto = buildDtoForPushNotification(notificationHistory, "");
					messagingTemplate.convertAndSend(ApplicationConstants.WEBSOCKET_ENDPOINT + notificationHistory.getToNotify(),
							notificationHistoryDto);
				} catch(ApplicationException ae) {
					logger.info("Exception while saving notification history ====> "+ae); 
				}
			}
		}
	}
	
	/**
	 * Gets the unpaid company name list.
	 *
	 * @param reportTime the report time
	 * @return the unpaid company name list
	 */
	private List<String> getUnpaidCompanyNameList(Long reportTime) {
		List<String> companyNameList = new ArrayList<>();
		if(reportTime != null) {
			RestTemplate restTemplate = RestTemplateProvider.getRestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			HttpEntity<?> httpentity = new HttpEntity<>(headers);
			String uri = environmentproperties.getRecoverezWalletUpaidCompanyNameListUrl();
			String urlTemplate = UriComponentsBuilder.fromHttpUrl(uri).queryParam(ApplicationConstants.REPORT_TIME, reportTime).toUriString();
			ResponseEntity<String[]> response = restTemplate.exchange(urlTemplate, HttpMethod.GET, httpentity, String[].class);
			if(ApplicationUtils.isValidateObject(response)) {
				String[] data = response.getBody();
				logger.info("upaid company list =======> " + data.toString());
				companyNameList = Arrays.asList(data);
			}
		}
		return companyNameList;
	}
	
	/**
	 * Gets the notification template for payment reminder.
	 *
	 * @return the notification template for payment reminder
	 */
	private String getNotificationTemplateForPaymentReminder() {
		String template = "";
		RestTemplate restTemplate = RestTemplateProvider.getRestTemplate();
		String url = environmentproperties.getRecoverezWalletPaymentReminderTemplateUrl();
		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, null, String.class);
		if(ApplicationUtils.isValidateObject(response)) {
			template = response.getBody();
			logger.info("payment reminder template ======> " + template);
		}
		return template;
	}
	
	/**
	 * Gets the notification template for reminder.
	 *
	 * @param triggeredStatus the triggered status
	 * @return the notification template for reminder
	 */
	private SchedulerNotification getNotificationTemplateForReminder(String triggeredStatus) {
		SchedulerNotification schedulerNotification = null;
		RestTemplate restTemplate = RestTemplateProvider.getRestTemplate();
		String url = environmentproperties.getRecoverezNotificationReminderTemplateUrl();

		String urlTemplate = UriComponentsBuilder.fromHttpUrl(url)
				.queryParam(ApplicationConstants.TRIGGERED_STATUS, triggeredStatus).toUriString();

		ResponseEntity<SchedulerNotification> response = restTemplate.exchange(urlTemplate, HttpMethod.GET, null, SchedulerNotification.class);
		if(ApplicationUtils.isValidateObject(response)) {
			schedulerNotification = response.getBody();
			logger.info("Scheduler Notification reminder template ======> " + schedulerNotification);
		}
		return schedulerNotification;
	}
	
	/**
	 * Convertvalue with format.
	 *
	 * @param amount the amount
	 * @return the string
	 */
	public String convertvalueWithFormat(Double amount){
        DecimalFormat formatter = new DecimalFormat(environmentproperties.getCurrencyType());
        return  formatter.format(amount);
    }

	/**
	 * @param companyNameList
	 */
	public void triggerReminderEmail(Map<String, List<String>> companyNameList) {
		try {
			if(ApplicationUtils.isValidateObject(companyNameList)){
				logger.info("------------------------ reminder email triggered ------------------------------------ ");
				Map<String, List<String>> responseBody = getCompanyUserMailAddress(companyNameList);
				logger.info("-------------------------- mail prep for data upload reminder ------------------------------------ ");
				freeMarkerConfig.setClassForTemplateLoading(this.getClass(), ApplicationConstants.MAIL_TEMPLATE);
				Template markerTemplate = freeMarkerConfig.getTemplate(ApplicationConstants.UPLOAD_REMINDER_FTL);
				JavaMailSenderImpl customMailSender = buildJavaMailSender();
				for (Map.Entry<String, List<String>> entry : responseBody.entrySet()) {
					Map<String, Object> variables = new HashMap<>();
					StringWriter result = new StringWriter();
					variables.put(ApplicationConstants.REPOSITORY, companyNameList.keySet().stream().toList().get(0));
					variables.put(ApplicationConstants.NOTIFICATION_COMPANY_NAME, entry.getKey());
					markerTemplate.process(variables, result);
					MimeMessage message = customMailSender.createMimeMessage();
					MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
							StandardCharsets.UTF_8.name());
					String toAddress = entry.getValue().stream().collect(Collectors.joining(", "));
					helper.setTo(InternetAddress.parse(toAddress, false));
					helper.setText(result.toString(),true);
					helper.setSubject(ApplicationConstants.UPLOAD_REMINDER);
					customMailSender.send(message);
					logger.info("email sent for company >>>>>>>>>>>>>>>>>>>>>>> " + entry.getKey());
				}
			}
		} catch (Exception e) {
			logger.error(e.getLocalizedMessage());
			e.printStackTrace();
		}
		
	}

	/**
	 * @return
	 */
	private JavaMailSenderImpl buildJavaMailSender() {
		JavaMailSenderImpl customMailSender = new JavaMailSenderImpl();
		customMailSender.setHost("smtp.gmail.com");
		customMailSender.setPort(587);
		customMailSender.setProtocol("smtp");
		customMailSender.setUsername("ncloud782@gmail.com");
		customMailSender.setPassword("tllniaqeqagzpche");
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		customMailSender.setJavaMailProperties(props);
		return customMailSender;
	}

	/**
	 * @param companyNameList
	 * @return
	 */
	private Map<String, List<String>> getCompanyUserMailAddress(Map<String, List<String>> companyNameList) {
		String repoName = companyNameList.keySet().stream().findFirst().get();
		List<String> companyNames = companyNameList.get(repoName);
		RestTemplate restTemplate = RestTemplateProvider.getRestTemplate();
		HttpHeaders httpheaders = RestTemplateProvider.getHttpHeaders();
		HttpEntity<List<String>> httpentity = new HttpEntity<>(companyNames, httpheaders);
		String uri = environmentproperties.getInsuranceCompanyEmail();
		ParameterizedTypeReference<Map<String, List<String>>> responseType = new ParameterizedTypeReference<Map<String, List<String>>>() {};
		ResponseEntity<Map<String, List<String>>> response = restTemplate.exchange(uri, HttpMethod.POST, httpentity, responseType);
		Map<String, List<String>> responseBody = response.getBody();
		return responseBody;
	}
}
