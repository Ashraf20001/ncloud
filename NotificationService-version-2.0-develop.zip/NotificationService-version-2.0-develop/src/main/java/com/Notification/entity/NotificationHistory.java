package com.Notification.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class NotificationHistory.
 */
@Entity
@Data
@Table(name="notification_history")
@NoArgsConstructor
public class NotificationHistory {
	
	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "notification_history_id")
	private int id;	
	  
	/** The template. */
	@Column(name = "notification_template")
	private String template;
	
	/** The is read. */
	@Column(name = "is_read")
	private boolean isRead;
	
	/** The claim id. */
	@Column(name = "claim_Id")
	private Integer claimId;
	
	/** The status. */
	@Column(name = "status")
	private String status;
	
	/** The last acted. */
	@Column(name = "last_acted")
	private String lastActed;
	
	/** The to notify. */
	@Column(name = "to_notify")
	private String toNotify;
	
	/** The platform id. */
	@Column(name = "platform_id")
	private Integer platformId;
	
	/** The is deleted. */
	@Column(name="is_deleted")
	private boolean isDeleted;

	/** The identity. */
	@Column(name="identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;

	/** The created date. */
	@Column(name="created_date")
	private Date createdDate;

	/** The created by. */
	@Column(name="created_by")
	private int createdBy;
	
	/** The modified date. */
	@Column(name="modified_date")
	private Date modifiedDate;

	/** The modified by. */
	@Column(name="modified_by")
	private int modifiedBy;

	/** The payment id. */
	@Column(name="payment_id")
	private Integer paymentId;
	
	/** The re placable template data. */
	@Column(name = "rePlc_tmplt_Data")
	private String rePlacableTemplateData;
	
	/** The repository identity. */
	@Column(name="repository_identity")
	private String repositoryIdentity;

}
