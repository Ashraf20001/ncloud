package com.Notification.entity;

import java.time.LocalDateTime;
import java.util.List;

import com.recoveryportal.transfer.object.reportloss.entity.Comments;
import com.recoveryportal.transfer.object.reportloss.entity.CreditNote;
import com.recoveryportal.transfer.object.reportloss.entity.DebitNote;
import com.recoveryportal.transfer.object.reportloss.entity.GarageInfo;
import com.recoveryportal.transfer.object.reportloss.entity.GarageInvoice;
import com.recoveryportal.transfer.object.reportloss.entity.InsuredInfo;
import com.recoveryportal.transfer.object.reportloss.entity.LossDetails;
import com.recoveryportal.transfer.object.reportloss.entity.PoliceReport;
import com.recoveryportal.transfer.object.reportloss.entity.RecoveryDetails;
import com.recoveryportal.transfer.object.reportloss.entity.ReserveReview;
import com.recoveryportal.transfer.object.reportloss.entity.SurveyDetails;
import com.recoveryportal.transfer.object.reportloss.entity.SurveyReport;
import com.recoveryportal.transfer.object.reportloss.entity.ThirdPartyInfo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class ReportLoss.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ReportLoss {
    
    /** The claim id. */
    private Integer claimId;
   
    
    /** The comments. */
    private List<Comments> comments;
    
    /** The insured info. */
    private InsuredInfo insuredInfo;
    
    /** The third party info. */
    private ThirdPartyInfo thirdPartyInfo;
    
    /** The loss details. */
    private LossDetails lossDetails;
   
    /** The police report. */
    private PoliceReport policeReport;
   
    /** The garage info. */
    private GarageInfo garageInfo;
    
    /** The survey details. */
    private SurveyDetails surveyDetails;
    
    /** The survey report. */
    private SurveyReport surveyReport;
    
    /** The recovery details. */
    private RecoveryDetails recoveryDetails;
   
    /** The reserve review. */
    private ReserveReview reserveReview;
    
    /** The garage invoice. */
    private GarageInvoice garageInvoice;
    
    /** The debit note. */
    private DebitNote debitNote;
   
    /** The credit note. */
    private CreditNote creditNote;
    
    /** The state. */
    private String state;
    
    /** The created date. */
    private LocalDateTime createdDate;
    
    /** The created by. */
    private Integer createdBy;
    
    /** The modified date. */
    private LocalDateTime modifiedDate;
    
    /** The modified by. */
    private Integer modifiedBy;
   
    /** The identity. */
    private String identity;
    
    /** The is deleted. */
    private Boolean isDeleted = false;

     
    /** The last status. */
    private String lastStatus;
     
     
     /** The claim sequence id. */
     private String claimSequenceId;
     
     
     /** The stage name. */
     private String stageName;
     
     
     /** The section name. */
     private String sectionName;
}
