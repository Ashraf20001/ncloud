package com.Notification.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class NotificationHistoryUserMap.
 */
@Entity
@Data
@Table(name="notification_history_user_map")
@NoArgsConstructor
public class NotificationHistoryUserMap {

	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	/** The notification history. */
	@OneToOne
	@JoinColumn(name = "notification_history_id")
	private NotificationHistory notificationHistory;
	
	/** The user identity. */
	@Column(name = "user_identity")
	private String userIdentity;
	
	/** The is read. */
	@Column(name = "is_read")
	private boolean isRead;
	
	/** The created date. */
	@Column(name="created_at")
	private Date createdDate;
	
	/** The modified date. */
	@Column(name="modified_at")
	private Date modifiedDate;
	
	/** The identity. */
	@Column(name="identity")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String identity;
}
